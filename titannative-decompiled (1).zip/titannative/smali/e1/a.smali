.class public final enum Le1/a;
.super Ljava/lang/Enum;
.source "SourceFile"

.field public static final enum i:Le1/a;
.field public static final enum j:Le1/a;
.field public static final synthetic k:[Le1/a;

# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 0: new-instance v0, Le1/a;
    .line 2: const-string v1, "On"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Le1/a;->i:Le1/a;
    .line 10: new-instance v1, Le1/a;
    .line 12: const-string v2, "Off"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Le1/a;->j:Le1/a;
    .line 20: new-instance v2, Le1/a;
    .line 22: const-string v3, "Indeterminate"
    .line 24: const/4 v4, 2
    .line 25: invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 28: filled-new-array {v0, v1, v2}, [Le1/a;
    .line 31: move-result-object v0
    .line 32: sput-object v0, Le1/a;->k:[Le1/a;
    .line 34: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Le1/a;
    .registers 2

    .line 0: const-class v0, Le1/a;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Le1/a;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Le1/a;
    .registers 1

    .line 0: sget-object v0, Le1/a;->k:[Le1/a;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Le1/a;
    .line 8: return-object v0
.end method

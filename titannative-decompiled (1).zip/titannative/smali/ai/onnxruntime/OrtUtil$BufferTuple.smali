.class final Lai/onnxruntime/OrtUtil$BufferTuple;
.super Ljava/lang/Object;
.source "SourceFile"

.field final byteSize:J
.field final data:Ljava/nio/Buffer;
.field final isCopy:Z
.field final pos:I
.field final size:J

# direct methods
.method public constructor <init>(Ljava/nio/Buffer;IJJZ)V
    .registers 8

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lai/onnxruntime/OrtUtil$BufferTuple;->data:Ljava/nio/Buffer;
    .line 5: iput v2, v0, Lai/onnxruntime/OrtUtil$BufferTuple;->pos:I
    .line 7: iput-wide v3, v0, Lai/onnxruntime/OrtUtil$BufferTuple;->byteSize:J
    .line 9: iput-wide v5, v0, Lai/onnxruntime/OrtUtil$BufferTuple;->size:J
    .line 11: iput-boolean v7, v0, Lai/onnxruntime/OrtUtil$BufferTuple;->isCopy:Z
    .line 13: return-void
.end method

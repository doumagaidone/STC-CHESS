.class public final Lai/onnxruntime/R;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

.class public final enum Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.field public static final enum BLOCK_SPARSE:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.field public static final enum COO:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.field public static final enum CSRC:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.field public static final enum UNDEFINED:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.field private static final values:[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;

.field public final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 10

    .line 0: new-instance v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 2: const-string v1, "UNDEFINED"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;-><init>(Ljava/lang/String;II)V
    .line 8: sput-object v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->UNDEFINED:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 10: new-instance v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 12: const-string v3, "COO"
    .line 14: const/4 v4, 1
    .line 15: invoke-direct {v1, v3, v4, v4}, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;-><init>(Ljava/lang/String;II)V
    .line 18: sput-object v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->COO:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 20: new-instance v3, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 22: const-string v5, "CSRC"
    .line 24: const/4 v6, 2
    .line 25: invoke-direct {v3, v5, v6, v6}, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;-><init>(Ljava/lang/String;II)V
    .line 28: sput-object v3, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->CSRC:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 30: new-instance v5, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 32: const-string v7, "BLOCK_SPARSE"
    .line 34: const/4 v8, 3
    .line 35: const/4 v9, 4
    .line 36: invoke-direct {v5, v7, v8, v9}, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;-><init>(Ljava/lang/String;II)V
    .line 39: sput-object v5, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->BLOCK_SPARSE:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 41: filled-new-array {v0, v1, v3, v5}, [Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 44: move-result-object v7
    .line 45: sput-object v7, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->$VALUES:[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 47: const/4 v7, 5
    .line 48: new-array v7, v7, [Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 50: sput-object v7, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->values:[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 52: aput-object v0, v7, v2
    .line 54: aput-object v1, v7, v4
    .line 56: aput-object v3, v7, v6
    .line 58: aput-object v0, v7, v8
    .line 60: aput-object v5, v7, v9
    .line 62: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->value:I
    .line 5: return-void
.end method

# direct methods
.method public static mapFromInt(I)Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .registers 3

    .line 0: if-lez v2, :cond_10
    .line 2: sget-object v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->values:[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 4: array-length v1, v0
    .line 5: if-ge v2, v1, :cond_10
    .line 7: aget-object v2, v0, v2
    .line 9: return-object v2
    .line 10: sget-object v2, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->UNDEFINED:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 12: return-object v2
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->$VALUES:[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 8: return-object v0
.end method

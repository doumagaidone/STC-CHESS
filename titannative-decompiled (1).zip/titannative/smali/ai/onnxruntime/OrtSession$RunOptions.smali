.class public Lai/onnxruntime/OrtSession$RunOptions;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private closed:Z
.field private final nativeHandle:J

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 3: return-void
    .line 4: move-exception v0
    .line 5: new-instance v1, Ljava/lang/RuntimeException;
    .line 7: const-string v2, "Failed to load onnx-runtime library"
    .line 9: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 12: throw v1
.end method

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-boolean v0, v2, Lai/onnxruntime/OrtSession$RunOptions;->closed:Z
    .line 6: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 8: invoke-static {v0, v1}, Lai/onnxruntime/OrtSession$RunOptions;->createRunOptions(J)J
    .line 11: move-result-wide v0
    .line 12: iput-wide v0, v2, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 14: return-void
.end method

# direct methods
.method private native addRunConfigEntry(JJLjava/lang/String;Ljava/lang/String;)V
.end method

# direct methods
.method private checkClosed()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession$RunOptions;->closed:Z
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IllegalStateException;
    .line 7: const-string v1, "Trying to use a closed RunOptions"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# direct methods
.method private static native close(JJ)V
.end method

# direct methods
.method private static native createRunOptions(J)J
.end method

# direct methods
.method private native getLogLevel(JJ)I
.end method

# direct methods
.method private native getLogVerbosityLevel(JJ)I
.end method

# direct methods
.method private native getRunTag(JJ)Ljava/lang/String;
.end method

# direct methods
.method private native setLogLevel(JJI)V
.end method

# direct methods
.method private native setLogVerbosityLevel(JJI)V
.end method

# direct methods
.method private native setRunTag(JJLjava/lang/String;)V
.end method

# direct methods
.method private native setTerminate(JJZ)V
.end method

# virtual methods
.method public addRunConfigEntry(Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v7, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: move-object v0, v7
    .line 8: move-object v5, v8
    .line 9: move-object v6, v9
    .line 10: invoke-direct/range {v0 .. v6}, Lai/onnxruntime/OrtSession$RunOptions;->addRunConfigEntry(JJLjava/lang/String;Ljava/lang/String;)V
    .line 13: return-void
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtSession$RunOptions;->closed:Z
    .line 2: if-nez v0, :cond_15
    .line 4: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v2, v4, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 8: invoke-static {v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$RunOptions;->close(JJ)V
    .line 11: const/4 v0, 1
    .line 12: iput-boolean v0, v4, Lai/onnxruntime/OrtSession$RunOptions;->closed:Z
    .line 14: return-void
    .line 15: new-instance v0, Ljava/lang/IllegalStateException;
    .line 17: const-string v1, "Trying to close an already closed RunOptions"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# virtual methods
.method public getLogLevel()Lai/onnxruntime/OrtLoggingLevel;
    .registers 5

    .line 0: invoke-direct {v4}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v2, v4, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$RunOptions;->getLogLevel(JJ)I
    .line 10: move-result v0
    .line 11: invoke-static {v0}, Lai/onnxruntime/OrtLoggingLevel;->mapFromInt(I)Lai/onnxruntime/OrtLoggingLevel;
    .line 14: move-result-object v0
    .line 15: return-object v0
.end method

# virtual methods
.method public getLogVerbosityLevel()I
    .registers 5

    .line 0: invoke-direct {v4}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v2, v4, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$RunOptions;->getLogVerbosityLevel(JJ)I
    .line 10: move-result v0
    .line 11: return v0
.end method

# virtual methods
.method public getNativeHandle()J
    .registers 3

    .line 0: iget-wide v0, v2, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 2: return-wide v0
.end method

# virtual methods
.method public getRunTag()Ljava/lang/String;
    .registers 5

    .line 0: invoke-direct {v4}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v2, v4, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$RunOptions;->getRunTag(JJ)Ljava/lang/String;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public setLogLevel(Lai/onnxruntime/OrtLoggingLevel;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: invoke-virtual {v7}, Lai/onnxruntime/OrtLoggingLevel;->getValue()I
    .line 10: move-result v5
    .line 11: move-object v0, v6
    .line 12: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$RunOptions;->setLogLevel(JJI)V
    .line 15: return-void
.end method

# virtual methods
.method public setLogVerbosityLevel(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$RunOptions;->setLogVerbosityLevel(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public setRunTag(Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move-object v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$RunOptions;->setRunTag(JJLjava/lang/String;)V
    .line 12: return-void
.end method

# virtual methods
.method public setTerminate(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$RunOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$RunOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$RunOptions;->setTerminate(JJZ)V
    .line 12: return-void
.end method

.class public final Lai/onnxruntime/BuildConfig;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final BUILD_TYPE:Ljava/lang/String;
.field public static final DEBUG:Z
.field public static final LIBRARY_PACKAGE_NAME:Ljava/lang/String;

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

.class public abstract Lai/onnxruntime/OnnxSparseTensor$SparseTensor;
.super Ljava/lang/Object;
.source "SourceFile"

.field private final denseShape:[J
.field final indices:Ljava/nio/Buffer;
.field private final indicesShape:[J
.field private final numNonZero:J
.field private final type:Lai/onnxruntime/OnnxJavaType;
.field final values:Ljava/nio/Buffer;
.field private final valuesShape:[J

# direct methods
.method public constructor <init>(Ljava/nio/Buffer;[JLjava/nio/Buffer;[J[JLai/onnxruntime/OnnxJavaType;J)V
    .registers 9

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->indices:Ljava/nio/Buffer;
    .line 5: iput-object v2, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->indicesShape:[J
    .line 7: iput-object v3, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->values:Ljava/nio/Buffer;
    .line 9: iput-object v4, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->valuesShape:[J
    .line 11: iput-object v5, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->denseShape:[J
    .line 13: iput-object v6, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->type:Lai/onnxruntime/OnnxJavaType;
    .line 15: iput-wide v7, v0, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->numNonZero:J
    .line 17: invoke-virtual {v3}, Ljava/nio/Buffer;->remaining()I
    .line 20: move-result v1
    .line 21: int-to-long v1, v1
    .line 22: cmp-long v1, v1, v7
    .line 24: if-nez v1, :cond_39
    .line 26: sget-object v1, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 28: if-eq v6, v1, :cond_31
    .line 30: return-void
    .line 31: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 33: const-string v2, "String SparseTensors are not supported."
    .line 35: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 38: throw v1
    .line 39: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 41: new-instance v2, Ljava/lang/StringBuilder;
    .line 43: const-string v4, "Expected numNonZero and data.remaining to be equal, found "
    .line 45: invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 48: invoke-virtual {v2, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 51: const-string v4, " and "
    .line 53: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 56: invoke-virtual {v3}, Ljava/nio/Buffer;->remaining()I
    .line 59: move-result v3
    .line 60: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 63: const-string v3, " respectively"
    .line 65: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 68: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 71: move-result-object v2
    .line 72: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 75: throw v1
.end method

# virtual methods
.method public getDenseShape()[J
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->denseShape:[J
    .line 2: return-object v0
.end method

# virtual methods
.method public getIndices()Ljava/nio/Buffer;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->indices:Ljava/nio/Buffer;
    .line 2: return-object v0
.end method

# virtual methods
.method public getIndicesShape()[J
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->indicesShape:[J
    .line 2: return-object v0
.end method

# virtual methods
.method public abstract getIndicesType()Lai/onnxruntime/OnnxJavaType;
.end method

# virtual methods
.method public getNumNonZeroElements()J
    .registers 3

    .line 0: iget-wide v0, v2, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->numNonZero:J
    .line 2: return-wide v0
.end method

# virtual methods
.method public abstract getSparsityType()Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
.end method

# virtual methods
.method public getType()Lai/onnxruntime/OnnxJavaType;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->type:Lai/onnxruntime/OnnxJavaType;
    .line 2: return-object v0
.end method

# virtual methods
.method public getValues()Ljava/nio/Buffer;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->values:Ljava/nio/Buffer;
    .line 2: return-object v0
.end method

# virtual methods
.method public getValuesShape()[J
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensor;->valuesShape:[J
    .line 2: return-object v0
.end method

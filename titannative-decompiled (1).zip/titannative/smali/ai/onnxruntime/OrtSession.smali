.class public Lai/onnxruntime/OrtSession;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private final allocator:Lai/onnxruntime/OrtAllocator;
.field private closed:Z
.field private final inputNames:Ljava/util/Set;
.field private metadata:Lai/onnxruntime/OnnxModelMetadata;
.field private final nativeHandle:J
.field private final numInputs:J
.field private final numOutputs:J
.field private final outputNames:Ljava/util/Set;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 3: return-void
    .line 4: move-exception v0
    .line 5: new-instance v1, Ljava/lang/RuntimeException;
    .line 7: const-string v2, "Failed to load onnx-runtime library"
    .line 9: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 12: throw v1
.end method

# direct methods
.method private constructor <init>(JLai/onnxruntime/OrtAllocator;)V
    .registers 12

    .line 0: invoke-direct {v8}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-boolean v0, v8, Lai/onnxruntime/OrtSession;->closed:Z
    .line 6: iput-wide v9, v8, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 8: iput-object v11, v8, Lai/onnxruntime/OrtSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 10: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 12: invoke-direct {v8, v0, v1, v9, v10}, Lai/onnxruntime/OrtSession;->getNumInputs(JJ)J
    .line 15: move-result-wide v0
    .line 16: iput-wide v0, v8, Lai/onnxruntime/OrtSession;->numInputs:J
    .line 18: new-instance v0, Ljava/util/LinkedHashSet;
    .line 20: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 22: iget-wide v6, v11, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 24: move-object v1, v8
    .line 25: move-wide v4, v9
    .line 26: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession;->getInputNames(JJJ)[Ljava/lang/String;
    .line 29: move-result-object v1
    .line 30: invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 33: move-result-object v1
    .line 34: invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V
    .line 37: iput-object v0, v8, Lai/onnxruntime/OrtSession;->inputNames:Ljava/util/Set;
    .line 39: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 41: invoke-direct {v8, v0, v1, v9, v10}, Lai/onnxruntime/OrtSession;->getNumOutputs(JJ)J
    .line 44: move-result-wide v0
    .line 45: iput-wide v0, v8, Lai/onnxruntime/OrtSession;->numOutputs:J
    .line 47: new-instance v0, Ljava/util/LinkedHashSet;
    .line 49: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 51: iget-wide v6, v11, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 53: move-object v1, v8
    .line 54: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession;->getOutputNames(JJJ)[Ljava/lang/String;
    .line 57: move-result-object v9
    .line 58: invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 61: move-result-object v9
    .line 62: invoke-direct {v0, v9}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V
    .line 65: iput-object v0, v8, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 67: return-void
.end method

# direct methods
.method public constructor <init>(Lai/onnxruntime/OrtEnvironment;Ljava/lang/String;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)V
    .registers 12

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: invoke-virtual {v8}, Lai/onnxruntime/OrtEnvironment;->getNativeHandle()J
    .line 5: move-result-wide v2
    .line 6: invoke-virtual {v11}, Lai/onnxruntime/OrtSession$SessionOptions;->getNativeHandle()J
    .line 9: move-result-wide v5
    .line 10: move-object v4, v9
    .line 11: invoke-static/range {v0 .. v6}, Lai/onnxruntime/OrtSession;->createSession(JJLjava/lang/String;J)J
    .line 14: move-result-wide v8
    .line 15: invoke-direct {v7, v8, v9, v10}, Lai/onnxruntime/OrtSession;-><init>(JLai/onnxruntime/OrtAllocator;)V
    .line 18: return-void
.end method

# direct methods
.method public constructor <init>(Lai/onnxruntime/OrtEnvironment;[BLai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)V
    .registers 12

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: invoke-virtual {v8}, Lai/onnxruntime/OrtEnvironment;->getNativeHandle()J
    .line 5: move-result-wide v2
    .line 6: invoke-virtual {v11}, Lai/onnxruntime/OrtSession$SessionOptions;->getNativeHandle()J
    .line 9: move-result-wide v5
    .line 10: move-object v4, v9
    .line 11: invoke-static/range {v0 .. v6}, Lai/onnxruntime/OrtSession;->createSession(JJ[BJ)J
    .line 14: move-result-wide v8
    .line 15: invoke-direct {v7, v8, v9, v10}, Lai/onnxruntime/OrtSession;-><init>(JLai/onnxruntime/OrtAllocator;)V
    .line 18: return-void
.end method

# direct methods
.method private native closeSession(JJ)V
.end method

# direct methods
.method private native constructMetadata(JJJ)Lai/onnxruntime/OnnxModelMetadata;
.end method

# direct methods
.method private static native createSession(JJLjava/lang/String;J)J
.end method

# direct methods
.method private static native createSession(JJ[BJ)J
.end method

# direct methods
.method private native endProfiling(JJJ)Ljava/lang/String;
.end method

# direct methods
.method public static getHandle(Lai/onnxruntime/OnnxValue;)J
    .registers 4

    .line 0: instance-of v0, v3, Lai/onnxruntime/OnnxTensorLike;
    .line 2: if-eqz v0, :cond_9
    .line 4: check-cast v3, Lai/onnxruntime/OnnxTensorLike;
    .line 6: iget-wide v0, v3, Lai/onnxruntime/OnnxTensorLike;->nativeHandle:J
    .line 8: return-wide v0
    .line 9: instance-of v0, v3, Lai/onnxruntime/OnnxSequence;
    .line 11: if-eqz v0, :cond_18
    .line 13: check-cast v3, Lai/onnxruntime/OnnxSequence;
    .line 15: iget-wide v0, v3, Lai/onnxruntime/OnnxSequence;->nativeHandle:J
    .line 17: return-wide v0
    .line 18: instance-of v0, v3, Lai/onnxruntime/OnnxMap;
    .line 20: if-eqz v0, :cond_27
    .line 22: check-cast v3, Lai/onnxruntime/OnnxMap;
    .line 24: iget-wide v0, v3, Lai/onnxruntime/OnnxMap;->nativeHandle:J
    .line 26: return-wide v0
    .line 27: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 29: new-instance v1, Ljava/lang/StringBuilder;
    .line 31: const-string v2, "Unexpected OnnxValue subclass, should be {OnnxTensorLike, OnnxSequence, OnnxMap}, found "
    .line 33: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 36: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 39: move-result-object v3
    .line 40: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 43: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 46: move-result-object v3
    .line 47: invoke-direct {v0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 50: throw v0
.end method

# direct methods
.method private native getInputInfo(JJJ)[Lai/onnxruntime/NodeInfo;
.end method

# direct methods
.method private native getInputNames(JJJ)[Ljava/lang/String;
.end method

# direct methods
.method private native getNumInputs(JJ)J
.end method

# direct methods
.method private native getNumOutputs(JJ)J
.end method

# direct methods
.method private native getOutputInfo(JJJ)[Lai/onnxruntime/NodeInfo;
.end method

# direct methods
.method private native getOutputNames(JJJ)[Ljava/lang/String;
.end method

# direct methods
.method private native getProfilingStartTimeInNs(JJ)J
.end method

# direct methods
.method private native run(JJJ[Ljava/lang/String;[JJ[Ljava/lang/String;J[Lai/onnxruntime/OnnxValue;[JJ)[Z
.end method

# direct methods
.method private static wrapInMap([Lai/onnxruntime/NodeInfo;)Ljava/util/Map;
    .registers 6

    .line 0: new-instance v0, Ljava/util/LinkedHashMap;
    .line 2: array-length v1, v5
    .line 3: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->capacityFromSize(I)I
    .line 6: move-result v1
    .line 7: invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V
    .line 10: array-length v1, v5
    .line 11: const/4 v2, 0
    .line 12: if-ge v2, v1, :cond_26
    .line 14: aget-object v3, v5, v2
    .line 16: invoke-virtual {v3}, Lai/onnxruntime/NodeInfo;->getName()Ljava/lang/String;
    .line 19: move-result-object v4
    .line 20: invoke-interface {v0, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 23: add-int/lit8 v2, v2, 1
    .line 25: goto :goto_12
    .line 26: return-object v0
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_15
    .line 4: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v2, v4, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 8: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession;->closeSession(JJ)V
    .line 11: const/4 v0, 1
    .line 12: iput-boolean v0, v4, Lai/onnxruntime/OrtSession;->closed:Z
    .line 14: return-void
    .line 15: new-instance v0, Ljava/lang/IllegalStateException;
    .line 17: const-string v1, "Trying to close an already closed OrtSession."
    .line 19: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# virtual methods
.method public endProfiling()Ljava/lang/String;
    .registers 8

    .line 0: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: iget-wide v3, v7, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 4: iget-object v0, v7, Lai/onnxruntime/OrtSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 6: iget-wide v5, v0, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 8: move-object v0, v7
    .line 9: invoke-direct/range {v0 .. v6}, Lai/onnxruntime/OrtSession;->endProfiling(JJJ)Ljava/lang/String;
    .line 12: move-result-object v0
    .line 13: return-object v0
.end method

# virtual methods
.method public getInputInfo()Ljava/util/Map;
    .registers 9

    .line 0: iget-boolean v0, v8, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_22
    .line 4: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v4, v8, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 8: iget-object v0, v8, Lai/onnxruntime/OrtSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 10: iget-wide v6, v0, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 12: move-object v1, v8
    .line 13: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession;->getInputInfo(JJJ)[Lai/onnxruntime/NodeInfo;
    .line 16: move-result-object v0
    .line 17: invoke-static {v0}, Lai/onnxruntime/OrtSession;->wrapInMap([Lai/onnxruntime/NodeInfo;)Ljava/util/Map;
    .line 20: move-result-object v0
    .line 21: return-object v0
    .line 22: new-instance v0, Ljava/lang/IllegalStateException;
    .line 24: const-string v1, "Asking for inputs from a closed OrtSession."
    .line 26: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 29: throw v0
.end method

# virtual methods
.method public getInputNames()Ljava/util/Set;
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_7
    .line 4: iget-object v0, v2, Lai/onnxruntime/OrtSession;->inputNames:Ljava/util/Set;
    .line 6: return-object v0
    .line 7: new-instance v0, Ljava/lang/IllegalStateException;
    .line 9: const-string v1, "Asking for inputs from a closed OrtSession."
    .line 11: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 14: throw v0
.end method

# virtual methods
.method public getMetadata()Lai/onnxruntime/OnnxModelMetadata;
    .registers 9

    .line 0: iget-object v0, v8, Lai/onnxruntime/OrtSession;->metadata:Lai/onnxruntime/OnnxModelMetadata;
    .line 2: if-nez v0, :cond_19
    .line 4: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v4, v8, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 8: iget-object v0, v8, Lai/onnxruntime/OrtSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 10: iget-wide v6, v0, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 12: move-object v1, v8
    .line 13: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession;->constructMetadata(JJJ)Lai/onnxruntime/OnnxModelMetadata;
    .line 16: move-result-object v0
    .line 17: iput-object v0, v8, Lai/onnxruntime/OrtSession;->metadata:Lai/onnxruntime/OnnxModelMetadata;
    .line 19: iget-object v0, v8, Lai/onnxruntime/OrtSession;->metadata:Lai/onnxruntime/OnnxModelMetadata;
    .line 21: return-object v0
.end method

# virtual methods
.method public getNumInputs()J
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_7
    .line 4: iget-wide v0, v2, Lai/onnxruntime/OrtSession;->numInputs:J
    .line 6: return-wide v0
    .line 7: new-instance v0, Ljava/lang/IllegalStateException;
    .line 9: const-string v1, "Asking for inputs from a closed OrtSession."
    .line 11: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 14: throw v0
.end method

# virtual methods
.method public getNumOutputs()J
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_7
    .line 4: iget-wide v0, v2, Lai/onnxruntime/OrtSession;->numOutputs:J
    .line 6: return-wide v0
    .line 7: new-instance v0, Ljava/lang/IllegalStateException;
    .line 9: const-string v1, "Asking for outputs from a closed OrtSession."
    .line 11: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 14: throw v0
.end method

# virtual methods
.method public getOutputInfo()Ljava/util/Map;
    .registers 9

    .line 0: iget-boolean v0, v8, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_22
    .line 4: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v4, v8, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 8: iget-object v0, v8, Lai/onnxruntime/OrtSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 10: iget-wide v6, v0, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 12: move-object v1, v8
    .line 13: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession;->getOutputInfo(JJJ)[Lai/onnxruntime/NodeInfo;
    .line 16: move-result-object v0
    .line 17: invoke-static {v0}, Lai/onnxruntime/OrtSession;->wrapInMap([Lai/onnxruntime/NodeInfo;)Ljava/util/Map;
    .line 20: move-result-object v0
    .line 21: return-object v0
    .line 22: new-instance v0, Ljava/lang/IllegalStateException;
    .line 24: const-string v1, "Asking for outputs from a closed OrtSession."
    .line 26: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 29: throw v0
.end method

# virtual methods
.method public getOutputNames()Ljava/util/Set;
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession;->closed:Z
    .line 2: if-nez v0, :cond_7
    .line 4: iget-object v0, v2, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 6: return-object v0
    .line 7: new-instance v0, Ljava/lang/IllegalStateException;
    .line 9: const-string v1, "Asking for outputs from a closed OrtSession."
    .line 11: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 14: throw v0
.end method

# virtual methods
.method public getProfilingStartTimeInNs()J
    .registers 5

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: iget-wide v2, v4, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 4: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession;->getProfilingStartTimeInNs(JJ)J
    .line 7: move-result-wide v0
    .line 8: return-wide v0
.end method

# virtual methods
.method public run(Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 3

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 2: invoke-virtual {v1, v2, v0}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;Ljava/util/Set;)Lai/onnxruntime/OrtSession$Result;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# virtual methods
.method public run(Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 4

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 2: invoke-virtual {v1, v2, v0, v3}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;Ljava/util/Set;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# virtual methods
.method public run(Ljava/util/Map;Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: invoke-virtual {v2, v3, v0, v4, v1}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 8: move-result-object v3
    .line 9: return-object v3
.end method

# virtual methods
.method public run(Ljava/util/Map;Ljava/util/Set;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: invoke-virtual {v2, v3, v4, v0, v1}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 8: move-result-object v3
    .line 9: return-object v3
.end method

# virtual methods
.method public run(Ljava/util/Map;Ljava/util/Set;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v1, v2, v3, v0, v4}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 7: move-result-object v2
    .line 8: return-object v2
.end method

# virtual methods
.method public run(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v2, v3, v4, v0}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 4: move-result-object v2
    .line 5: return-object v2
.end method

# virtual methods
.method public run(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 25

    .line 0: move-object/from16 v15, v20
    .line 2: iget-boolean v0, v15, Lai/onnxruntime/OrtSession;->closed:Z
    .line 4: if-nez v0, :cond_488
    .line 6: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->isEmpty()Z
    .line 9: move-result v0
    .line 10: const-string v1, ") found "
    .line 12: const-wide/16 v2, 0
    .line 14: if-eqz v0, :cond_26
    .line 16: iget-wide v4, v15, Lai/onnxruntime/OrtSession;->numInputs:J
    .line 18: cmp-long v0, v4, v2
    .line 20: if-nez v0, :cond_23
    .line 22: goto :goto_26
    .line 23: move-object v3, v15
    .line 24: goto/16 :goto_456
    .line 26: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 29: move-result v0
    .line 30: int-to-long v4, v0
    .line 31: iget-wide v6, v15, Lai/onnxruntime/OrtSession;->numInputs:J
    .line 33: cmp-long v0, v4, v6
    .line 35: if-gtz v0, :cond_23
    .line 37: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->size()I
    .line 40: move-result v0
    .line 41: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->size()I
    .line 44: move-result v4
    .line 45: add-int/2addr v4, v0
    .line 46: if-eqz v4, :cond_426
    .line 48: int-to-long v5, v4
    .line 49: iget-wide v7, v15, Lai/onnxruntime/OrtSession;->numOutputs:J
    .line 51: cmp-long v0, v5, v7
    .line 53: if-gtz v0, :cond_426
    .line 55: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 58: move-result v0
    .line 59: new-array v7, v0, [Ljava/lang/String;
    .line 61: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 64: move-result v1
    .line 65: new-array v8, v1, [J
    .line 67: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 70: move-result-object v1
    .line 71: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 74: move-result-object v1
    .line 75: const/4 v4, 0
    .line 76: move v5, v4
    .line 77: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 80: move-result v6
    .line 81: const-string v9, ", expected one of "
    .line 83: if-eqz v6, :cond_164
    .line 85: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 88: move-result-object v6
    .line 89: check-cast v6, Ljava/util/Map$Entry;
    .line 91: iget-object v10, v15, Lai/onnxruntime/OrtSession;->inputNames:Ljava/util/Set;
    .line 93: invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 96: move-result-object v11
    .line 97: invoke-interface {v10, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 100: move-result v10
    .line 101: if-eqz v10, :cond_126
    .line 103: invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 106: move-result-object v9
    .line 107: check-cast v9, Ljava/lang/String;
    .line 109: aput-object v9, v7, v5
    .line 111: invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 114: move-result-object v6
    .line 115: check-cast v6, Lai/onnxruntime/OnnxTensorLike;
    .line 117: invoke-virtual {v6}, Lai/onnxruntime/OnnxTensorLike;->getNativeHandle()J
    .line 120: move-result-wide v9
    .line 121: aput-wide v9, v8, v5
    .line 123: add-int/lit8 v5, v5, 1
    .line 125: goto :goto_77
    .line 126: new-instance v0, Lai/onnxruntime/OrtException;
    .line 128: new-instance v1, Ljava/lang/StringBuilder;
    .line 130: const-string v2, "Unknown input name "
    .line 132: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 135: invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 138: move-result-object v2
    .line 139: check-cast v2, Ljava/lang/String;
    .line 141: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 144: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 147: iget-object v2, v15, Lai/onnxruntime/OrtSession;->inputNames:Ljava/util/Set;
    .line 149: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 152: move-result-object v2
    .line 153: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 156: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 159: move-result-object v1
    .line 160: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 163: throw v0
    .line 164: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->size()I
    .line 167: move-result v1
    .line 168: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->size()I
    .line 171: move-result v5
    .line 172: add-int v11, v5, v1
    .line 174: new-array v14, v11, [Ljava/lang/String;
    .line 176: new-array v12, v11, [Lai/onnxruntime/OnnxValue;
    .line 178: new-array v13, v11, [J
    .line 180: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 183: move-result-object v1
    .line 184: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 187: move-result-object v1
    .line 188: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 191: move-result v5
    .line 192: const-string v6, "Unknown output name "
    .line 194: if-eqz v5, :cond_283
    .line 196: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 199: move-result-object v5
    .line 200: check-cast v5, Ljava/util/Map$Entry;
    .line 202: iget-object v10, v15, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 204: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 207: move-result-object v2
    .line 208: invoke-interface {v10, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 211: move-result v2
    .line 212: if-eqz v2, :cond_247
    .line 214: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 217: move-result-object v2
    .line 218: check-cast v2, Ljava/lang/String;
    .line 220: aput-object v2, v14, v4
    .line 222: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 225: move-result-object v2
    .line 226: check-cast v2, Lai/onnxruntime/OnnxValue;
    .line 228: aput-object v2, v12, v4
    .line 230: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 233: move-result-object v2
    .line 234: check-cast v2, Lai/onnxruntime/OnnxValue;
    .line 236: invoke-static {v2}, Lai/onnxruntime/OrtSession;->getHandle(Lai/onnxruntime/OnnxValue;)J
    .line 239: move-result-wide v2
    .line 240: aput-wide v2, v13, v4
    .line 242: add-int/lit8 v4, v4, 1
    .line 244: const-wide/16 v2, 0
    .line 246: goto :goto_188
    .line 247: new-instance v0, Lai/onnxruntime/OrtException;
    .line 249: new-instance v1, Ljava/lang/StringBuilder;
    .line 251: invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 254: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 257: move-result-object v2
    .line 258: check-cast v2, Ljava/lang/String;
    .line 260: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 263: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 266: iget-object v2, v15, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 268: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 271: move-result-object v2
    .line 272: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 275: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 278: move-result-object v1
    .line 279: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 282: throw v0
    .line 283: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 286: move-result-object v1
    .line 287: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 290: move-result v2
    .line 291: if-eqz v2, :cond_375
    .line 293: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 296: move-result-object v2
    .line 297: check-cast v2, Ljava/lang/String;
    .line 299: iget-object v3, v15, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 301: invoke-interface {v3, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 304: move-result v3
    .line 305: if-eqz v3, :cond_345
    .line 307: move-object/from16 v3, v23
    .line 309: invoke-interface {v3, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 312: move-result v5
    .line 313: if-nez v5, :cond_320
    .line 315: aput-object v2, v14, v4
    .line 317: add-int/lit8 v4, v4, 1
    .line 319: goto :goto_287
    .line 320: new-instance v0, Lai/onnxruntime/OrtException;
    .line 322: new-instance v1, Ljava/lang/StringBuilder;
    .line 324: const-string v3, "Output '"
    .line 326: invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 329: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 332: const-string v2, "' was found in both the requested outputs and the pinned outputs"
    .line 334: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 337: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 340: move-result-object v1
    .line 341: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 344: throw v0
    .line 345: new-instance v0, Lai/onnxruntime/OrtException;
    .line 347: new-instance v1, Ljava/lang/StringBuilder;
    .line 349: invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 352: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 355: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 358: iget-object v2, v15, Lai/onnxruntime/OrtSession;->outputNames:Ljava/util/Set;
    .line 360: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 363: move-result-object v2
    .line 364: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 367: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 370: move-result-object v1
    .line 371: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 374: throw v0
    .line 375: if-nez v24, :cond_380
    .line 377: const-wide/16 v16, 0
    .line 379: goto :goto_386
    .line 380: invoke-virtual/range {v24 .. v24}, Lai/onnxruntime/OrtSession$RunOptions;->getNativeHandle()J
    .line 383: move-result-wide v1
    .line 384: move-wide/from16 v16, v1
    .line 386: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 388: iget-wide v3, v15, Lai/onnxruntime/OrtSession;->nativeHandle:J
    .line 390: iget-object v5, v15, Lai/onnxruntime/OrtSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 392: iget-wide v5, v5, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 394: int-to-long v9, v0
    .line 395: move-object v0, v12
    .line 396: int-to-long v11, v11
    .line 397: move-object/from16 v18, v13
    .line 399: move-wide v12, v11
    .line 400: move-object v11, v0
    .line 401: move-object/from16 v0, v20
    .line 403: move-object/from16 v21, v11
    .line 405: move-object v11, v14
    .line 406: move-object/from16 v19, v14
    .line 408: move-object/from16 v14, v21
    .line 410: move-object/from16 v15, v18
    .line 412: invoke-direct/range {v0 .. v17}, Lai/onnxruntime/OrtSession;->run(JJJ[Ljava/lang/String;[JJ[Ljava/lang/String;J[Lai/onnxruntime/OnnxValue;[JJ)[Z
    .line 415: move-result-object v0
    .line 416: new-instance v1, Lai/onnxruntime/OrtSession$Result;
    .line 418: move-object/from16 v3, v21
    .line 420: move-object/from16 v2, v19
    .line 422: invoke-direct {v1, v2, v3, v0}, Lai/onnxruntime/OrtSession$Result;-><init>([Ljava/lang/String;[Lai/onnxruntime/OnnxValue;[Z)V
    .line 425: return-object v1
    .line 426: new-instance v0, Lai/onnxruntime/OrtException;
    .line 428: new-instance v2, Ljava/lang/StringBuilder;
    .line 430: const-string v3, "Unexpected number of requestedOutputs & pinnedOutputs, expected [1,"
    .line 432: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 435: move-object/from16 v3, v20
    .line 437: iget-wide v5, v3, Lai/onnxruntime/OrtSession;->numOutputs:J
    .line 439: invoke-virtual {v2, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 442: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 445: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 448: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 451: move-result-object v1
    .line 452: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 455: throw v0
    .line 456: new-instance v0, Lai/onnxruntime/OrtException;
    .line 458: new-instance v2, Ljava/lang/StringBuilder;
    .line 460: const-string v4, "Unexpected number of inputs, expected [1,"
    .line 462: invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 465: iget-wide v4, v3, Lai/onnxruntime/OrtSession;->numInputs:J
    .line 467: invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 470: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 473: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 476: move-result v1
    .line 477: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 480: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 483: move-result-object v1
    .line 484: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 487: throw v0
    .line 488: move-object v3, v15
    .line 489: new-instance v0, Ljava/lang/IllegalStateException;
    .line 491: const-string v1, "Trying to score a closed OrtSession."
    .line 493: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 496: throw v0
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "OrtSession(numInputs="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-wide v1, v3, Lai/onnxruntime/OrtSession;->numInputs:J
    .line 9: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ",numOutputs="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-wide v1, v3, Lai/onnxruntime/OrtSession;->numOutputs:J
    .line 19: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ")"
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 30: move-result-object v0
    .line 31: return-object v0
.end method

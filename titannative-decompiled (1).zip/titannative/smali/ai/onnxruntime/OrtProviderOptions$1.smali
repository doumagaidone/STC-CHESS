.class synthetic Lai/onnxruntime/OrtProviderOptions$1;
.super Ljava/lang/Object;
.source "SourceFile"

.field static final synthetic $SwitchMap$ai$onnxruntime$OrtProvider:[I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OrtProvider;->values()[Lai/onnxruntime/OrtProvider;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Lai/onnxruntime/OrtProviderOptions$1;->$SwitchMap$ai$onnxruntime$OrtProvider:[I
    .line 9: sget-object v1, Lai/onnxruntime/OrtProvider;->CUDA:Lai/onnxruntime/OrtProvider;
    .line 11: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 14: move-result v1
    .line 15: const/4 v2, 1
    .line 16: aput v2, v0, v1
    .line 18: sget-object v0, Lai/onnxruntime/OrtProviderOptions$1;->$SwitchMap$ai$onnxruntime$OrtProvider:[I
    .line 20: sget-object v1, Lai/onnxruntime/OrtProvider;->DNNL:Lai/onnxruntime/OrtProvider;
    .line 22: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 25: move-result v1
    .line 26: const/4 v2, 2
    .line 27: aput v2, v0, v1
    .line 29: sget-object v0, Lai/onnxruntime/OrtProviderOptions$1;->$SwitchMap$ai$onnxruntime$OrtProvider:[I
    .line 31: sget-object v1, Lai/onnxruntime/OrtProvider;->OPEN_VINO:Lai/onnxruntime/OrtProvider;
    .line 33: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 36: move-result v1
    .line 37: const/4 v2, 3
    .line 38: aput v2, v0, v1
    .line 40: sget-object v0, Lai/onnxruntime/OrtProviderOptions$1;->$SwitchMap$ai$onnxruntime$OrtProvider:[I
    .line 42: sget-object v1, Lai/onnxruntime/OrtProvider;->ROCM:Lai/onnxruntime/OrtProvider;
    .line 44: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 47: move-result v1
    .line 48: const/4 v2, 4
    .line 49: aput v2, v0, v1
    .line 51: sget-object v0, Lai/onnxruntime/OrtProviderOptions$1;->$SwitchMap$ai$onnxruntime$OrtProvider:[I
    .line 53: sget-object v1, Lai/onnxruntime/OrtProvider;->TENSOR_RT:Lai/onnxruntime/OrtProvider;
    .line 55: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 58: move-result v1
    .line 59: const/4 v2, 5
    .line 60: aput v2, v0, v1
    .line 62: return-void
.end method

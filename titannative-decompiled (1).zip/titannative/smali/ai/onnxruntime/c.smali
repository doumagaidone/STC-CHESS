.class public final synthetic Lai/onnxruntime/c;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/function/Function;

# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0: check-cast v1, Ljava/lang/String;
    .line 2: invoke-static {v1}, Lai/onnxruntime/TensorInfo;->a(Ljava/lang/String;)Ljava/lang/String;
    .line 5: move-result-object v1
    .line 6: return-object v1
.end method

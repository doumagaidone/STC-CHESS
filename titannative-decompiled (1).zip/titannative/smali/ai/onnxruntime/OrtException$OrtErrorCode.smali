.class public final enum Lai/onnxruntime/OrtException$OrtErrorCode;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_ENGINE_ERROR:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_INVALID_ARGUMENT:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_INVALID_GRAPH:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_INVALID_PROTOBUF:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_JAVA_UNKNOWN:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_MODEL_LOADED:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_NOT_IMPLEMENTED:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_NO_MODEL:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_NO_SUCHFILE:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_OK:Lai/onnxruntime/OrtException$OrtErrorCode;
.field public static final enum ORT_RUNTIME_EXCEPTION:Lai/onnxruntime/OrtException$OrtErrorCode;
.field private static final values:[Lai/onnxruntime/OrtException$OrtErrorCode;

.field private final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 16

    .line 0: new-instance v0, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 2: const/4 v1, -1
    .line 3: const-string v2, "ORT_JAVA_UNKNOWN"
    .line 5: const/4 v13, 0
    .line 6: invoke-direct {v0, v2, v13, v1}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 9: sput-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_JAVA_UNKNOWN:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 11: new-instance v1, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 13: const-string v2, "ORT_OK"
    .line 15: const/4 v3, 1
    .line 16: invoke-direct {v1, v2, v3, v13}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 19: sput-object v1, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_OK:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 21: new-instance v2, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 23: const-string v4, "ORT_FAIL"
    .line 25: const/4 v5, 2
    .line 26: invoke-direct {v2, v4, v5, v3}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 29: sput-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 31: new-instance v3, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 33: const-string v4, "ORT_INVALID_ARGUMENT"
    .line 35: const/4 v6, 3
    .line 36: invoke-direct {v3, v4, v6, v5}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 39: sput-object v3, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_INVALID_ARGUMENT:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 41: new-instance v4, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 43: const-string v5, "ORT_NO_SUCHFILE"
    .line 45: const/4 v7, 4
    .line 46: invoke-direct {v4, v5, v7, v6}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 49: sput-object v4, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_NO_SUCHFILE:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 51: new-instance v5, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 53: const-string v6, "ORT_NO_MODEL"
    .line 55: const/4 v8, 5
    .line 56: invoke-direct {v5, v6, v8, v7}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 59: sput-object v5, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_NO_MODEL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 61: new-instance v6, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 63: const-string v7, "ORT_ENGINE_ERROR"
    .line 65: const/4 v9, 6
    .line 66: invoke-direct {v6, v7, v9, v8}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 69: sput-object v6, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_ENGINE_ERROR:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 71: new-instance v7, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 73: const-string v8, "ORT_RUNTIME_EXCEPTION"
    .line 75: const/4 v10, 7
    .line 76: invoke-direct {v7, v8, v10, v9}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 79: sput-object v7, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_RUNTIME_EXCEPTION:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 81: new-instance v8, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 83: const-string v9, "ORT_INVALID_PROTOBUF"
    .line 85: const/16 v11, 8
    .line 87: invoke-direct {v8, v9, v11, v10}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 90: sput-object v8, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_INVALID_PROTOBUF:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 92: new-instance v9, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 94: const-string v10, "ORT_MODEL_LOADED"
    .line 96: const/16 v12, 9
    .line 98: invoke-direct {v9, v10, v12, v11}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 101: sput-object v9, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_MODEL_LOADED:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 103: new-instance v10, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 105: const-string v11, "ORT_NOT_IMPLEMENTED"
    .line 107: const/16 v14, 10
    .line 109: invoke-direct {v10, v11, v14, v12}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 112: sput-object v10, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_NOT_IMPLEMENTED:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 114: new-instance v11, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 116: const-string v12, "ORT_INVALID_GRAPH"
    .line 118: const/16 v15, 11
    .line 120: invoke-direct {v11, v12, v15, v14}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 123: sput-object v11, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_INVALID_GRAPH:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 125: new-instance v12, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 127: const-string v14, "ORT_EP_FAIL"
    .line 129: const/16 v13, 12
    .line 131: invoke-direct {v12, v14, v13, v15}, Lai/onnxruntime/OrtException$OrtErrorCode;-><init>(Ljava/lang/String;II)V
    .line 134: sput-object v12, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 136: filled-new-array/range {v0 .. v12}, [Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 139: move-result-object v0
    .line 140: sput-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->$VALUES:[Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 142: new-array v0, v13, [Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 144: sput-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->values:[Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 146: invoke-static {}, Lai/onnxruntime/OrtException$OrtErrorCode;->values()[Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 149: move-result-object v0
    .line 150: array-length v1, v0
    .line 151: const/4 v13, 0
    .line 152: if-ge v13, v1, :cond_169
    .line 154: aget-object v2, v0, v13
    .line 156: sget-object v3, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_JAVA_UNKNOWN:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 158: if-eq v2, v3, :cond_166
    .line 160: sget-object v3, Lai/onnxruntime/OrtException$OrtErrorCode;->values:[Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 162: iget v4, v2, Lai/onnxruntime/OrtException$OrtErrorCode;->value:I
    .line 164: aput-object v2, v3, v4
    .line 166: add-int/lit8 v13, v13, 1
    .line 168: goto :goto_152
    .line 169: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OrtException$OrtErrorCode;->value:I
    .line 5: return-void
.end method

# direct methods
.method public static mapFromInt(I)Lai/onnxruntime/OrtException$OrtErrorCode;
    .registers 3

    .line 0: if-ltz v2, :cond_10
    .line 2: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->values:[Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 4: array-length v1, v0
    .line 5: if-ge v2, v1, :cond_10
    .line 7: aget-object v2, v0, v2
    .line 9: return-object v2
    .line 10: sget-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_JAVA_UNKNOWN:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 12: return-object v2
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OrtException$OrtErrorCode;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OrtException$OrtErrorCode;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->$VALUES:[Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OrtException$OrtErrorCode;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 8: return-object v0
.end method

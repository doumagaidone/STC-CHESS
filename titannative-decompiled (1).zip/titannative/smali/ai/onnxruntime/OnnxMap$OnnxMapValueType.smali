.class public final enum Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.field public static final enum DOUBLE:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.field public static final enum FLOAT:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.field public static final enum INVALID:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.field public static final enum LONG:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.field public static final enum STRING:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
.field private static final values:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;

.field final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 8

    .line 0: new-instance v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 2: const-string v1, "INVALID"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;-><init>(Ljava/lang/String;II)V
    .line 8: sput-object v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->INVALID:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 10: new-instance v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 12: const-string v3, "STRING"
    .line 14: const/4 v4, 1
    .line 15: invoke-direct {v1, v3, v4, v4}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;-><init>(Ljava/lang/String;II)V
    .line 18: sput-object v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->STRING:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 20: new-instance v3, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 22: const-string v4, "LONG"
    .line 24: const/4 v5, 2
    .line 25: invoke-direct {v3, v4, v5, v5}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;-><init>(Ljava/lang/String;II)V
    .line 28: sput-object v3, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->LONG:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 30: new-instance v4, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 32: const-string v5, "FLOAT"
    .line 34: const/4 v6, 3
    .line 35: invoke-direct {v4, v5, v6, v6}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;-><init>(Ljava/lang/String;II)V
    .line 38: sput-object v4, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->FLOAT:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 40: new-instance v5, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 42: const-string v6, "DOUBLE"
    .line 44: const/4 v7, 4
    .line 45: invoke-direct {v5, v6, v7, v7}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;-><init>(Ljava/lang/String;II)V
    .line 48: sput-object v5, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->DOUBLE:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 50: filled-new-array {v0, v1, v3, v4, v5}, [Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 53: move-result-object v0
    .line 54: sput-object v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->$VALUES:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 56: const/4 v0, 5
    .line 57: new-array v0, v0, [Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 59: sput-object v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->values:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 61: invoke-static {}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->values()[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 64: move-result-object v0
    .line 65: array-length v1, v0
    .line 66: if-ge v2, v1, :cond_79
    .line 68: aget-object v3, v0, v2
    .line 70: sget-object v4, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->values:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 72: iget v5, v3, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->value:I
    .line 74: aput-object v3, v4, v5
    .line 76: add-int/lit8 v2, v2, 1
    .line 78: goto :goto_66
    .line 79: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->value:I
    .line 5: return-void
.end method

# direct methods
.method public static mapFromInt(I)Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .registers 3

    .line 0: if-lez v2, :cond_10
    .line 2: sget-object v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->values:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 4: array-length v1, v0
    .line 5: if-ge v2, v1, :cond_10
    .line 7: aget-object v2, v0, v2
    .line 9: return-object v2
    .line 10: sget-object v2, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->INVALID:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 12: return-object v2
.end method

# direct methods
.method public static mapFromOnnxJavaType(Lai/onnxruntime/OnnxJavaType;)Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .registers 2

    .line 0: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 2: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v1, v0, v1
    .line 8: const/4 v0, 1
    .line 9: if-eq v1, v0, :cond_32
    .line 11: const/4 v0, 2
    .line 12: if-eq v1, v0, :cond_29
    .line 14: const/4 v0, 3
    .line 15: if-eq v1, v0, :cond_26
    .line 17: const/4 v0, 4
    .line 18: if-eq v1, v0, :cond_23
    .line 20: sget-object v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->INVALID:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 22: return-object v1
    .line 23: sget-object v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->STRING:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 25: return-object v1
    .line 26: sget-object v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->LONG:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 28: return-object v1
    .line 29: sget-object v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->DOUBLE:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 31: return-object v1
    .line 32: sget-object v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->FLOAT:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 34: return-object v1
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->$VALUES:[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OnnxMap$OnnxMapValueType;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 8: return-object v0
.end method

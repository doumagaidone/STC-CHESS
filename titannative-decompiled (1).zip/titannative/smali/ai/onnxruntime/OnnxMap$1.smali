.class synthetic Lai/onnxruntime/OnnxMap$1;
.super Ljava/lang/Object;
.source "SourceFile"

.field static final synthetic $SwitchMap$ai$onnxruntime$OnnxJavaType:[I
.field static final synthetic $SwitchMap$ai$onnxruntime$OnnxMap$OnnxMapValueType:[I

# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->values()[Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxMap$OnnxMapValueType:[I
    .line 9: const/4 v1, 1
    .line 10: sget-object v2, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->STRING:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 12: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 15: move-result v2
    .line 16: aput v1, v0, v2
    .line 18: const/4 v0, 2
    .line 19: sget-object v2, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxMap$OnnxMapValueType:[I
    .line 21: sget-object v3, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->LONG:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 23: invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I
    .line 26: move-result v3
    .line 27: aput v0, v2, v3
    .line 29: const/4 v2, 3
    .line 30: sget-object v3, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxMap$OnnxMapValueType:[I
    .line 32: sget-object v4, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->FLOAT:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 34: invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I
    .line 37: move-result v4
    .line 38: aput v2, v3, v4
    .line 40: const/4 v3, 4
    .line 41: sget-object v4, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxMap$OnnxMapValueType:[I
    .line 43: sget-object v5, Lai/onnxruntime/OnnxMap$OnnxMapValueType;->DOUBLE:Lai/onnxruntime/OnnxMap$OnnxMapValueType;
    .line 45: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 48: move-result v5
    .line 49: aput v3, v4, v5
    .line 51: invoke-static {}, Lai/onnxruntime/OnnxJavaType;->values()[Lai/onnxruntime/OnnxJavaType;
    .line 54: move-result-object v4
    .line 55: array-length v4, v4
    .line 56: new-array v4, v4, [I
    .line 58: sput-object v4, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 60: sget-object v5, Lai/onnxruntime/OnnxJavaType;->FLOAT:Lai/onnxruntime/OnnxJavaType;
    .line 62: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 65: move-result v5
    .line 66: aput v1, v4, v5
    .line 68: sget-object v1, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 70: sget-object v4, Lai/onnxruntime/OnnxJavaType;->DOUBLE:Lai/onnxruntime/OnnxJavaType;
    .line 72: invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I
    .line 75: move-result v4
    .line 76: aput v0, v1, v4
    .line 78: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 80: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT64:Lai/onnxruntime/OnnxJavaType;
    .line 82: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 85: move-result v1
    .line 86: aput v2, v0, v1
    .line 88: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 90: sget-object v1, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 92: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 95: move-result v1
    .line 96: aput v3, v0, v1
    .line 98: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 100: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UINT8:Lai/onnxruntime/OnnxJavaType;
    .line 102: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 105: move-result v1
    .line 106: const/4 v2, 5
    .line 107: aput v2, v0, v1
    .line 109: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 111: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT8:Lai/onnxruntime/OnnxJavaType;
    .line 113: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 116: move-result v1
    .line 117: const/4 v2, 6
    .line 118: aput v2, v0, v1
    .line 120: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 122: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT16:Lai/onnxruntime/OnnxJavaType;
    .line 124: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 127: move-result v1
    .line 128: const/4 v2, 7
    .line 129: aput v2, v0, v1
    .line 131: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 133: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT32:Lai/onnxruntime/OnnxJavaType;
    .line 135: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 138: move-result v1
    .line 139: const/16 v2, 8
    .line 141: aput v2, v0, v1
    .line 143: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 145: sget-object v1, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 147: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 150: move-result v1
    .line 151: const/16 v2, 9
    .line 153: aput v2, v0, v1
    .line 155: sget-object v0, Lai/onnxruntime/OnnxMap$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 157: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 159: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 162: move-result v1
    .line 163: const/16 v2, 10
    .line 165: aput v2, v0, v1
    .line 167: return-void
.end method

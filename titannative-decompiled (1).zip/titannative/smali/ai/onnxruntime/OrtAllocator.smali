.class  Lai/onnxruntime/OrtAllocator;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private closed:Z
.field final handle:J
.field private final isDefault:Z

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 3: return-void
    .line 4: move-exception v0
    .line 5: new-instance v1, Ljava/lang/RuntimeException;
    .line 7: const-string v2, "Failed to load onnx-runtime library"
    .line 9: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 12: throw v1
.end method

# direct methods
.method public constructor <init>(JZ)V
    .registers 5

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-boolean v0, v1, Lai/onnxruntime/OrtAllocator;->closed:Z
    .line 6: iput-wide v2, v1, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 8: iput-boolean v4, v1, Lai/onnxruntime/OrtAllocator;->isDefault:Z
    .line 10: return-void
.end method

# direct methods
.method private native closeAllocator(JJ)V
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtAllocator;->closed:Z
    .line 2: if-nez v0, :cond_19
    .line 4: iget-boolean v0, v4, Lai/onnxruntime/OrtAllocator;->isDefault:Z
    .line 6: if-nez v0, :cond_18
    .line 8: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 10: iget-wide v2, v4, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 12: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtAllocator;->closeAllocator(JJ)V
    .line 15: const/4 v0, 1
    .line 16: iput-boolean v0, v4, Lai/onnxruntime/OrtAllocator;->closed:Z
    .line 18: return-void
    .line 19: new-instance v0, Ljava/lang/IllegalStateException;
    .line 21: const-string v1, "Trying to close an already closed OrtAllocator."
    .line 23: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 26: throw v0
.end method

# virtual methods
.method public isClosed()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Lai/onnxruntime/OrtAllocator;->closed:Z
    .line 2: return v0
.end method

# virtual methods
.method public isDefault()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Lai/onnxruntime/OrtAllocator;->isDefault:Z
    .line 2: return v0
.end method

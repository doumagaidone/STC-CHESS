.class synthetic Lai/onnxruntime/OrtUtil$1;
.super Ljava/lang/Object;
.source "SourceFile"

.field static final synthetic $SwitchMap$ai$onnxruntime$OnnxJavaType:[I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxJavaType;->values()[Lai/onnxruntime/OnnxJavaType;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 9: sget-object v1, Lai/onnxruntime/OnnxJavaType;->FLOAT:Lai/onnxruntime/OnnxJavaType;
    .line 11: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 14: move-result v1
    .line 15: const/4 v2, 1
    .line 16: aput v2, v0, v1
    .line 18: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 20: sget-object v1, Lai/onnxruntime/OnnxJavaType;->DOUBLE:Lai/onnxruntime/OnnxJavaType;
    .line 22: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 25: move-result v1
    .line 26: const/4 v2, 2
    .line 27: aput v2, v0, v1
    .line 29: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 31: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UINT8:Lai/onnxruntime/OnnxJavaType;
    .line 33: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 36: move-result v1
    .line 37: const/4 v2, 3
    .line 38: aput v2, v0, v1
    .line 40: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 42: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT8:Lai/onnxruntime/OnnxJavaType;
    .line 44: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 47: move-result v1
    .line 48: const/4 v2, 4
    .line 49: aput v2, v0, v1
    .line 51: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 53: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT16:Lai/onnxruntime/OnnxJavaType;
    .line 55: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 58: move-result v1
    .line 59: const/4 v2, 5
    .line 60: aput v2, v0, v1
    .line 62: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 64: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT32:Lai/onnxruntime/OnnxJavaType;
    .line 66: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 69: move-result v1
    .line 70: const/4 v2, 6
    .line 71: aput v2, v0, v1
    .line 73: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 75: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT64:Lai/onnxruntime/OnnxJavaType;
    .line 77: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 80: move-result v1
    .line 81: const/4 v2, 7
    .line 82: aput v2, v0, v1
    .line 84: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 86: sget-object v1, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 88: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 91: move-result v1
    .line 92: const/16 v2, 8
    .line 94: aput v2, v0, v1
    .line 96: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 98: sget-object v1, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 100: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 103: move-result v1
    .line 104: const/16 v2, 9
    .line 106: aput v2, v0, v1
    .line 108: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 110: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 112: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 115: move-result v1
    .line 116: const/16 v2, 10
    .line 118: aput v2, v0, v1
    .line 120: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 122: sget-object v1, Lai/onnxruntime/OnnxJavaType;->FLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 124: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 127: move-result v1
    .line 128: const/16 v2, 11
    .line 130: aput v2, v0, v1
    .line 132: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 134: sget-object v1, Lai/onnxruntime/OnnxJavaType;->BFLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 136: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 139: move-result v1
    .line 140: const/16 v2, 12
    .line 142: aput v2, v0, v1
    .line 144: return-void
.end method

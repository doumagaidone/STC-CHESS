.class public final Lai/onnxruntime/OnnxModelMetadata;
.super Ljava/lang/Object;
.source "SourceFile"

.field private final customMetadata:Ljava/util/Map;
.field private final description:Ljava/lang/String;
.field private final domain:Ljava/lang/String;
.field private final graphDescription:Ljava/lang/String;
.field private final graphName:Ljava/lang/String;
.field private final producerName:Ljava/lang/String;
.field private final version:J

# direct methods
.method public constructor <init>(Lai/onnxruntime/OnnxModelMetadata;)V
    .registers 4

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: iget-object v0, v3, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 5: iput-object v0, v2, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 7: iget-object v0, v3, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 9: iput-object v0, v2, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 11: iget-object v0, v3, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 13: iput-object v0, v2, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 15: iget-object v0, v3, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 17: iput-object v0, v2, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 19: iget-object v0, v3, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 21: iput-object v0, v2, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 23: iget-wide v0, v3, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 25: iput-wide v0, v2, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 27: iget-object v3, v3, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 29: invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z
    .line 32: move-result v3
    .line 33: if-eqz v3, :cond_40
    .line 35: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 38: move-result-object v3
    .line 39: goto :goto_49
    .line 40: new-instance v3, Ljava/util/HashMap;
    .line 42: invoke-virtual {v2}, Lai/onnxruntime/OnnxModelMetadata;->getCustomMetadata()Ljava/util/Map;
    .line 45: move-result-object v0
    .line 46: invoke-direct {v3, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V
    .line 49: iput-object v3, v2, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 51: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/util/Map;)V
    .registers 10

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const-string v0, ""
    .line 5: if-nez v2, :cond_8
    .line 7: move-object v2, v0
    .line 8: iput-object v2, v1, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 10: if-nez v3, :cond_13
    .line 12: move-object v3, v0
    .line 13: iput-object v3, v1, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 15: if-nez v4, :cond_18
    .line 17: move-object v4, v0
    .line 18: iput-object v4, v1, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 20: if-nez v5, :cond_23
    .line 22: move-object v5, v0
    .line 23: iput-object v5, v1, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 25: if-nez v6, :cond_28
    .line 27: move-object v6, v0
    .line 28: iput-object v6, v1, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 30: iput-wide v7, v1, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 32: if-nez v9, :cond_38
    .line 34: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 37: move-result-object v9
    .line 38: iput-object v9, v1, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 40: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J[Ljava/lang/String;)V
    .registers 10

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const-string v0, ""
    .line 5: if-nez v2, :cond_8
    .line 7: move-object v2, v0
    .line 8: iput-object v2, v1, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 10: if-nez v3, :cond_13
    .line 12: move-object v3, v0
    .line 13: iput-object v3, v1, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 15: if-nez v4, :cond_18
    .line 17: move-object v4, v0
    .line 18: iput-object v4, v1, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 20: if-nez v5, :cond_23
    .line 22: move-object v5, v0
    .line 23: iput-object v5, v1, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 25: if-nez v6, :cond_28
    .line 27: move-object v6, v0
    .line 28: iput-object v6, v1, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 30: iput-wide v7, v1, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 32: if-eqz v9, :cond_76
    .line 34: array-length v2, v9
    .line 35: if-lez v2, :cond_76
    .line 37: new-instance v2, Ljava/util/HashMap;
    .line 39: invoke-direct {v2}, Ljava/util/HashMap;-><init>()V
    .line 42: iput-object v2, v1, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 44: array-length v2, v9
    .line 45: rem-int/lit8 v2, v2, 2
    .line 47: const/4 v3, 1
    .line 48: if-eq v2, v3, :cond_68
    .line 50: const/4 v2, 0
    .line 51: array-length v3, v9
    .line 52: if-ge v2, v3, :cond_82
    .line 54: iget-object v3, v1, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 56: aget-object v4, v9, v2
    .line 58: add-int/lit8 v5, v2, 1
    .line 60: aget-object v5, v9, v5
    .line 62: invoke-interface {v3, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 65: add-int/lit8 v2, v2, 2
    .line 67: goto :goto_51
    .line 68: new-instance v2, Ljava/lang/IllegalStateException;
    .line 70: const-string v3, "Asked for keys and values, but received an odd number of elements."
    .line 72: invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 75: throw v2
    .line 76: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 79: move-result-object v2
    .line 80: iput-object v2, v1, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 82: return-void
.end method

# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 8

    .line 0: const/4 v0, 1
    .line 1: if-ne v6, v7, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-eqz v7, :cond_89
    .line 7: invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 10: move-result-object v2
    .line 11: const-class v3, Lai/onnxruntime/OnnxModelMetadata;
    .line 13: if-eq v3, v2, :cond_16
    .line 15: goto :goto_89
    .line 16: check-cast v7, Lai/onnxruntime/OnnxModelMetadata;
    .line 18: iget-wide v2, v6, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 20: iget-wide v4, v7, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 22: cmp-long v2, v2, v4
    .line 24: if-nez v2, :cond_87
    .line 26: iget-object v2, v6, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 28: iget-object v3, v7, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 30: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 33: move-result v2
    .line 34: if-eqz v2, :cond_87
    .line 36: iget-object v2, v6, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 38: iget-object v3, v7, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 40: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 43: move-result v2
    .line 44: if-eqz v2, :cond_87
    .line 46: iget-object v2, v6, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 48: iget-object v3, v7, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 50: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 53: move-result v2
    .line 54: if-eqz v2, :cond_87
    .line 56: iget-object v2, v6, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 58: iget-object v3, v7, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 60: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 63: move-result v2
    .line 64: if-eqz v2, :cond_87
    .line 66: iget-object v2, v6, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 68: iget-object v3, v7, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 70: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 73: move-result v2
    .line 74: if-eqz v2, :cond_87
    .line 76: iget-object v2, v6, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 78: iget-object v7, v7, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 80: invoke-interface {v2, v7}, Ljava/util/Map;->equals(Ljava/lang/Object;)Z
    .line 83: move-result v7
    .line 84: if-eqz v7, :cond_87
    .line 86: goto :goto_88
    .line 87: move v0, v1
    .line 88: return v0
    .line 89: return v1
.end method

# virtual methods
.method public getCustomMetadata()Ljava/util/Map;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 2: invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public getCustomMetadataValue(Ljava/lang/String;)Ljava/util/Optional;
    .registers 3

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 2: invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v2
    .line 6: check-cast v2, Ljava/lang/String;
    .line 8: invoke-static {v2}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;
    .line 11: move-result-object v2
    .line 12: return-object v2
.end method

# virtual methods
.method public getDescription()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public getDomain()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public getGraphDescription()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public getGraphName()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public getProducerName()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public getVersion()J
    .registers 3

    .line 0: iget-wide v0, v2, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 2: return-wide v0
.end method

# virtual methods
.method public hashCode()I
    .registers 8

    .line 0: iget-object v0, v7, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 2: iget-object v1, v7, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 4: iget-object v2, v7, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 6: iget-object v3, v7, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 8: iget-object v4, v7, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 10: iget-wide v5, v7, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 12: invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 15: move-result-object v5
    .line 16: iget-object v6, v7, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 18: filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;
    .line 21: move-result-object v0
    .line 22: invoke-static {v0}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I
    .line 25: move-result v0
    .line 26: return v0
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "OnnxModelMetadata{producerName='"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lai/onnxruntime/OnnxModelMetadata;->producerName:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, "', graphName='"
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lai/onnxruntime/OnnxModelMetadata;->graphName:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, "', graphDescription='"
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v3, Lai/onnxruntime/OnnxModelMetadata;->graphDescription:Ljava/lang/String;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, "', domain='"
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v3, Lai/onnxruntime/OnnxModelMetadata;->domain:Ljava/lang/String;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, "', description='"
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-object v1, v3, Lai/onnxruntime/OnnxModelMetadata;->description:Ljava/lang/String;
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 52: const-string v1, "', version="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget-wide v1, v3, Lai/onnxruntime/OnnxModelMetadata;->version:J
    .line 59: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ", customMetadata="
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget-object v1, v3, Lai/onnxruntime/OnnxModelMetadata;->customMetadata:Ljava/util/Map;
    .line 69: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 72: const/16 v1, 125
    .line 74: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 77: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 80: move-result-object v0
    .line 81: return-object v0
.end method

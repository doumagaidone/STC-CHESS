.class public abstract interface Lai/onnxruntime/ValueInfo;
.super Ljava/lang/Object;
.source "SourceFile"

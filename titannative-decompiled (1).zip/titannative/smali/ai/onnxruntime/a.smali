.class public abstract synthetic Lai/onnxruntime/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static bridge synthetic A(Ljava/lang/Process;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Ljava/lang/Process;->isAlive()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic B(Landroid/view/autofill/AutofillValue;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/autofill/AutofillValue;->isList()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic C(Landroid/view/autofill/AutofillValue;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/autofill/AutofillValue;->isDate()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic D(Landroid/view/autofill/AutofillValue;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/autofill/AutofillValue;->isToggle()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic a()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_MOVE_WINDOW:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic b(Landroid/view/ViewStructure;)Landroid/view/autofill/AutofillId;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/ViewStructure;->getAutofillId()Landroid/view/autofill/AutofillId;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic c(Ljava/lang/Object;)Landroid/view/autofill/AutofillId;
    .registers 1

    .line 0: check-cast v0, Landroid/view/autofill/AutofillId;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic d(Ljava/lang/Object;)Landroid/view/autofill/AutofillManager$AutofillCallback;
    .registers 1

    .line 0: check-cast v0, Landroid/view/autofill/AutofillManager$AutofillCallback;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic e(Ljava/lang/Object;)Landroid/view/autofill/AutofillManager;
    .registers 1

    .line 0: check-cast v0, Landroid/view/autofill/AutofillManager;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic f(Ljava/lang/Object;)Landroid/view/autofill/AutofillValue;
    .registers 1

    .line 0: check-cast v0, Landroid/view/autofill/AutofillValue;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic g(Ljava/nio/file/Path;)Ljava/io/File;
    .registers 1

    .line 0: invoke-interface {v0}, Ljava/nio/file/Path;->toFile()Ljava/io/File;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic h(Landroid/view/autofill/AutofillValue;)Ljava/lang/CharSequence;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/autofill/AutofillValue;->getTextValue()Ljava/lang/CharSequence;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic i()Ljava/lang/Class;
    .registers 1

    .line 0: const-class v0, Landroid/view/autofill/AutofillManager;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic j(Ljava/nio/file/Path;)Ljava/lang/String;
    .registers 1

    .line 0: invoke-interface {v0}, Ljava/nio/file/Path;->toString()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic k(Ljava/time/LocalDate;)Ljava/lang/String;
    .registers 1

    .line 0: invoke-virtual {v0}, Ljava/time/LocalDate;->toString()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic l(Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;
    .registers 2

    .line 0: invoke-static {v0, v1}, Ljava/nio/file/Paths;->get(Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic m(Ljava/nio/file/Path;Ljava/lang/String;)Ljava/nio/file/Path;
    .registers 2

    .line 0: invoke-interface {v0, v1}, Ljava/nio/file/Path;->resolve(Ljava/lang/String;)Ljava/nio/file/Path;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic n([Ljava/nio/file/attribute/FileAttribute;)Ljava/nio/file/Path;
    .registers 2

    .line 0: const-string v0, "onnxruntime-java"
    .line 2: invoke-static {v0, v1}, Ljava/nio/file/Files;->createTempDirectory(Ljava/lang/String;[Ljava/nio/file/attribute/FileAttribute;)Ljava/nio/file/Path;
    .line 5: move-result-object v1
    .line 6: return-object v1
.end method

# direct methods
.method public static bridge synthetic o()Ljava/time/LocalDate;
    .registers 1

    .line 0: invoke-static {}, Ljava/time/LocalDate;->now()Ljava/time/LocalDate;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic p(Landroid/view/View;)V
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: invoke-virtual {v1, v0}, Landroid/view/View;->setImportantForAutofill(I)V
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic q(Landroid/view/View;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setFocusable(I)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic r(Landroid/view/View;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setDefaultFocusHighlightEnabled(Z)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic s(Landroid/view/ViewParent;Landroid/view/View;Landroid/view/View;)V
    .registers 3

    .line 0: invoke-interface {v0, v1, v2}, Landroid/view/ViewParent;->onDescendantInvalidated(Landroid/view/View;Landroid/view/View;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic t(Landroid/view/ViewStructure;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setAutofillType(I)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic u(Landroid/view/ViewStructure;Landroid/view/autofill/AutofillId;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/view/ViewStructure;->setAutofillId(Landroid/view/autofill/AutofillId;I)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic v(Landroid/view/ViewStructure;[Ljava/lang/String;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setAutofillHints([Ljava/lang/String;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic w(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/util/List;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAvailableExtraData(Ljava/util/List;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic x(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/c2;Landroid/content/IntentFilter;Landroid/os/Handler;)V
    .registers 10

    .line 0: const/4 v3, 0
    .line 1: const/4 v5, 2
    .line 2: move-object v0, v6
    .line 3: move-object v1, v7
    .line 4: move-object v2, v8
    .line 5: move-object v4, v9
    .line 6: invoke-virtual/range {v0 .. v5}, Landroid/accessibilityservice/AccessibilityService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;
    .line 9: return-void
.end method

# direct methods
.method public static bridge synthetic y(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/d2;Landroid/content/IntentFilter;)V
    .registers 4

    .line 0: const/4 v0, 4
    .line 1: invoke-virtual {v1, v2, v3, v0}, Landroid/accessibilityservice/AccessibilityService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic z(Landroid/view/autofill/AutofillValue;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/autofill/AutofillValue;->isText()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

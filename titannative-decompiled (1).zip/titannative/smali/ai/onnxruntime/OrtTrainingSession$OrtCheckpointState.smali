.class final Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private static final logger:Ljava/util/logging/Logger;

.field private closed:Z
.field final nativeHandle:J

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-class v0, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->logger:Ljava/util/logging/Logger;
    .line 12: return-void
.end method

# direct methods
.method public constructor <init>(J)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-wide v1, v0, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 5: const/4 v1, 0
    .line 6: iput-boolean v1, v0, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->closed:Z
    .line 8: return-void
.end method

# direct methods
.method private native addProperty(JJJLjava/lang/String;F)V
.end method

# direct methods
.method private native addProperty(JJJLjava/lang/String;I)V
.end method

# direct methods
.method private native addProperty(JJJLjava/lang/String;Ljava/lang/String;)V
.end method

# direct methods
.method private checkClosed()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->closed:Z
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IllegalStateException;
    .line 7: const-string v1, "Trying to use a closed OrtCheckpointState"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# direct methods
.method private native close(JJ)V
.end method

# direct methods
.method private native getFloatProperty(JJJJLjava/lang/String;)F
.end method

# direct methods
.method private native getIntProperty(JJJJLjava/lang/String;)I
.end method

# direct methods
.method private native getStringProperty(JJJJLjava/lang/String;)Ljava/lang/String;
.end method

# direct methods
.method private static native loadCheckpoint(JJLjava/lang/String;)J
.end method

# direct methods
.method public static loadCheckpoint(Ljava/lang/String;)Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .registers 6

    .line 0: sget-boolean v0, Lai/onnxruntime/OnnxRuntime;->trainingEnabled:Z
    .line 2: if-eqz v0, :cond_23
    .line 4: const-string v0, "checkpoint path must not be null"
    .line 6: invoke-static {v5, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .line 9: new-instance v0, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 11: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 13: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 15: invoke-static {v1, v2, v3, v4, v5}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->loadCheckpoint(JJLjava/lang/String;)J
    .line 18: move-result-wide v1
    .line 19: invoke-direct {v0, v1, v2}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;-><init>(J)V
    .line 22: return-object v0
    .line 23: new-instance v5, Ljava/lang/IllegalStateException;
    .line 25: const-string v0, "Training is not enabled in this build of ONNX Runtime."
    .line 27: invoke-direct {v5, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 30: throw v5
.end method

# direct methods
.method public static loadCheckpoint(Ljava/nio/file/Path;)Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .registers 1

    .line 0: invoke-static {v0}, Lai/onnxruntime/a;->j(Ljava/nio/file/Path;)Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: invoke-static {v0}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->loadCheckpoint(Ljava/lang/String;)Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 7: move-result-object v0
    .line 8: return-object v0
.end method

# direct methods
.method private native saveCheckpoint(JJJLjava/lang/String;Z)V
.end method

# virtual methods
.method public addProperty(Ljava/lang/String;F)V
    .registers 12

    .line 0: invoke-direct {v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v9, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: move-object v0, v9
    .line 10: move-object v7, v10
    .line 11: move v8, v11
    .line 12: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->addProperty(JJJLjava/lang/String;F)V
    .line 15: return-void
.end method

# virtual methods
.method public addProperty(Ljava/lang/String;I)V
    .registers 12

    .line 0: invoke-direct {v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v9, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: move-object v0, v9
    .line 10: move-object v7, v10
    .line 11: move v8, v11
    .line 12: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->addProperty(JJJLjava/lang/String;I)V
    .line 15: return-void
.end method

# virtual methods
.method public addProperty(Ljava/lang/String;Ljava/lang/String;)V
    .registers 12

    .line 0: invoke-direct {v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v9, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: move-object v0, v9
    .line 10: move-object v7, v10
    .line 11: move-object v8, v11
    .line 12: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->addProperty(JJJLjava/lang/String;Ljava/lang/String;)V
    .line 15: return-void
.end method

# virtual methods
.method public declared-synchronized close()V
    .registers 5

    .line 0: monitor-enter v4
    .line 1: iget-boolean v0, v4, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->closed:Z
    .line 3: if-nez v0, :cond_18
    .line 5: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v2, v4, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->close(JJ)V
    .line 12: const/4 v0, 1
    .line 13: iput-boolean v0, v4, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->closed:Z
    .line 15: goto :goto_25
    .line 16: move-exception v0
    .line 17: goto :goto_27
    .line 18: sget-object v0, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->logger:Ljava/util/logging/Logger;
    .line 20: const-string v1, "Closing a checkpoint twice"
    .line 22: invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V
    .line 25: monitor-exit v4
    .line 26: return-void
    .line 27: monitor-exit v4
    .line 28: throw v0
.end method

# virtual methods
.method public getFloatProperty(Lai/onnxruntime/OrtAllocator;Ljava/lang/String;)F
    .registers 13

    .line 0: invoke-direct {v10}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v10, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: iget-wide v7, v11, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 11: move-object v0, v10
    .line 12: move-object v9, v12
    .line 13: invoke-direct/range {v0 .. v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->getFloatProperty(JJJJLjava/lang/String;)F
    .line 16: move-result v11
    .line 17: return v11
.end method

# virtual methods
.method public getIntProperty(Lai/onnxruntime/OrtAllocator;Ljava/lang/String;)I
    .registers 13

    .line 0: invoke-direct {v10}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v10, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: iget-wide v7, v11, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 11: move-object v0, v10
    .line 12: move-object v9, v12
    .line 13: invoke-direct/range {v0 .. v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->getIntProperty(JJJJLjava/lang/String;)I
    .line 16: move-result v11
    .line 17: return v11
.end method

# virtual methods
.method public getStringProperty(Lai/onnxruntime/OrtAllocator;Ljava/lang/String;)Ljava/lang/String;
    .registers 13

    .line 0: invoke-direct {v10}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v10, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 9: iget-wide v7, v11, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 11: move-object v0, v10
    .line 12: move-object v9, v12
    .line 13: invoke-direct/range {v0 .. v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->getStringProperty(JJJJLjava/lang/String;)Ljava/lang/String;
    .line 16: move-result-object v11
    .line 17: return-object v11
.end method

# virtual methods
.method public declared-synchronized isClosed()Z
    .registers 2

    .line 0: monitor-enter v1
    .line 1: iget-boolean v0, v1, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->closed:Z
    .line 3: monitor-exit v1
    .line 4: return v0
    .line 5: move-exception v0
    .line 6: monitor-exit v1
    .line 7: throw v0
.end method

# virtual methods
.method public saveCheckpoint(Ljava/nio/file/Path;Z)V
    .registers 13

    .line 0: invoke-direct {v10}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->checkClosed()V
    .line 3: const-string v0, "checkpoint path must not be null"
    .line 5: invoke-static {v11, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .line 8: invoke-static {v11}, Lai/onnxruntime/a;->j(Ljava/nio/file/Path;)Ljava/lang/String;
    .line 11: move-result-object v8
    .line 12: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 14: sget-wide v4, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 16: iget-wide v6, v10, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 18: move-object v1, v10
    .line 19: move v9, v12
    .line 20: invoke-direct/range {v1 .. v9}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->saveCheckpoint(JJJLjava/lang/String;Z)V
    .line 23: return-void
.end method

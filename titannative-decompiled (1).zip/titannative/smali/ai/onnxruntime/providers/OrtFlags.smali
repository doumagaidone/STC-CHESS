.class public abstract interface Lai/onnxruntime/providers/OrtFlags;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static aggregateToInt(Ljava/util/EnumSet;)I
    .registers 3

    .line 0: invoke-virtual {v2}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 8: move-result v1
    .line 9: if-eqz v1, :cond_23
    .line 11: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 14: move-result-object v1
    .line 15: check-cast v1, Lai/onnxruntime/providers/OrtFlags;
    .line 17: invoke-interface {v1}, Lai/onnxruntime/providers/OrtFlags;->getValue()I
    .line 20: move-result v1
    .line 21: or-int/2addr v0, v1
    .line 22: goto :goto_5
    .line 23: return v0
.end method

# virtual methods
.method public abstract getValue()I
.end method

.class public final enum Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
.field public static final enum ALL_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
.field public static final enum BASIC_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
.field public static final enum EXTENDED_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
.field public static final enum NO_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;

.field private final id:I

# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 0: new-instance v0, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 2: const-string v1, "NO_OPT"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;-><init>(Ljava/lang/String;II)V
    .line 8: sput-object v0, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->NO_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 10: new-instance v1, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 12: const-string v2, "BASIC_OPT"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3, v3}, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;-><init>(Ljava/lang/String;II)V
    .line 18: sput-object v1, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->BASIC_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 20: new-instance v2, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 22: const-string v3, "EXTENDED_OPT"
    .line 24: const/4 v4, 2
    .line 25: invoke-direct {v2, v3, v4, v4}, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;-><init>(Ljava/lang/String;II)V
    .line 28: sput-object v2, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->EXTENDED_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 30: new-instance v3, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 32: const/4 v4, 3
    .line 33: const/16 v5, 99
    .line 35: const-string v6, "ALL_OPT"
    .line 37: invoke-direct {v3, v6, v4, v5}, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;-><init>(Ljava/lang/String;II)V
    .line 40: sput-object v3, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->ALL_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 42: filled-new-array {v0, v1, v2, v3}, [Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 45: move-result-object v0
    .line 46: sput-object v0, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->$VALUES:[Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 48: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->id:I
    .line 5: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->$VALUES:[Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 8: return-object v0
.end method

# virtual methods
.method public getID()I
    .registers 2

    .line 0: iget v0, v1, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->id:I
    .line 2: return v0
.end method

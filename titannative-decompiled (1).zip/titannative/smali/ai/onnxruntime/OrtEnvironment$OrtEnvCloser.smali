.class final Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field private final apiHandle:J
.field private final nativeHandle:J

# direct methods
.method public constructor <init>(JJ)V
    .registers 5

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-wide v1, v0, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;->apiHandle:J
    .line 5: iput-wide v3, v0, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;->nativeHandle:J
    .line 7: return-void
.end method

# virtual methods
.method public run()V
    .registers 5

    .line 0: iget-wide v0, v4, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;->apiHandle:J
    .line 2: iget-wide v2, v4, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;->nativeHandle:J
    .line 4: invoke-static {v0, v1, v2, v3}, Lai/onnxruntime/OrtEnvironment;->access$100(JJ)V
    .line 7: goto :goto_28
    .line 8: move-exception v0
    .line 9: sget-object v1, Ljava/lang/System;->err:Ljava/io/PrintStream;
    .line 11: new-instance v2, Ljava/lang/StringBuilder;
    .line 13: const-string v3, "Error closing OrtEnvironment, "
    .line 15: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 18: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 21: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 24: move-result-object v0
    .line 25: invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    .line 28: return-void
.end method

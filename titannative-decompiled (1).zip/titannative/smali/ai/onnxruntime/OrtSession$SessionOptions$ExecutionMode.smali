.class public final enum Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
.field public static final enum PARALLEL:Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
.field public static final enum SEQUENTIAL:Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;

.field private final id:I

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: new-instance v0, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 2: const-string v1, "SEQUENTIAL"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;-><init>(Ljava/lang/String;II)V
    .line 8: sput-object v0, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->SEQUENTIAL:Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 10: new-instance v1, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 12: const-string v2, "PARALLEL"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3, v3}, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;-><init>(Ljava/lang/String;II)V
    .line 18: sput-object v1, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->PARALLEL:Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 20: filled-new-array {v0, v1}, [Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 23: move-result-object v0
    .line 24: sput-object v0, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->$VALUES:[Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 26: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->id:I
    .line 5: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->$VALUES:[Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;
    .line 8: return-object v0
.end method

# virtual methods
.method public getID()I
    .registers 2

    .line 0: iget v0, v1, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->id:I
    .line 2: return v0
.end method

.class public Lai/onnxruntime/OrtSession$SessionOptions;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private closed:Z
.field private final configEntries:Ljava/util/Map;
.field private final customLibraryHandles:Ljava/util/List;
.field private final nativeHandle:J

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 3: return-void
    .line 4: move-exception v0
    .line 5: new-instance v1, Ljava/lang/RuntimeException;
    .line 7: const-string v2, "Failed to load onnx-runtime library"
    .line 9: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 12: throw v1
.end method

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-boolean v0, v2, Lai/onnxruntime/OrtSession$SessionOptions;->closed:Z
    .line 6: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 8: invoke-direct {v2, v0, v1}, Lai/onnxruntime/OrtSession$SessionOptions;->createOptions(J)J
    .line 11: move-result-wide v0
    .line 12: iput-wide v0, v2, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 14: new-instance v0, Ljava/util/ArrayList;
    .line 16: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 19: iput-object v0, v2, Lai/onnxruntime/OrtSession$SessionOptions;->customLibraryHandles:Ljava/util/List;
    .line 21: new-instance v0, Ljava/util/LinkedHashMap;
    .line 23: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 26: iput-object v0, v2, Lai/onnxruntime/OrtSession$SessionOptions;->configEntries:Ljava/util/Map;
    .line 28: return-void
.end method

# direct methods
.method private native addACL(JJI)V
.end method

# direct methods
.method private native addArmNN(JJI)V
.end method

# direct methods
.method private native addCPU(JJI)V
.end method

# direct methods
.method private native addCUDA(JJI)V
.end method

# direct methods
.method private native addCUDAV2(JJJ)V
.end method

# direct methods
.method private native addConfigEntry(JJLjava/lang/String;Ljava/lang/String;)V
.end method

# direct methods
.method private native addCoreML(JJI)V
.end method

# direct methods
.method private native addDirectML(JJI)V
.end method

# direct methods
.method private native addDnnl(JJI)V
.end method

# direct methods
.method private native addExecutionProvider(JJLjava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)V
.end method

# direct methods
.method private native addExternalInitializers(JJ[Ljava/lang/String;[J)V
.end method

# direct methods
.method private native addFreeDimensionOverrideByName(JJLjava/lang/String;J)V
.end method

# direct methods
.method private native addInitializer(JJLjava/lang/String;J)V
.end method

# direct methods
.method private native addNnapi(JJI)V
.end method

# direct methods
.method private native addOpenVINO(JJLjava/lang/String;)V
.end method

# direct methods
.method private native addROCM(JJI)V
.end method

# direct methods
.method private native addTensorrt(JJI)V
.end method

# direct methods
.method private native addTensorrtV2(JJJ)V
.end method

# direct methods
.method private native addTvm(JJLjava/lang/String;)V
.end method

# direct methods
.method private checkClosed()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession$SessionOptions;->closed:Z
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IllegalStateException;
    .line 7: const-string v1, "Trying to use a closed SessionOptions"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# direct methods
.method private native closeCustomLibraries([J)V
.end method

# direct methods
.method private native closeOptions(JJ)V
.end method

# direct methods
.method private native createOptions(J)J
.end method

# direct methods
.method private native disablePerSessionThreads(JJ)V
.end method

# direct methods
.method private native disableProfiling(JJ)V
.end method

# direct methods
.method private native enableProfiling(JJLjava/lang/String;)V
.end method

# direct methods
.method private native registerCustomOpLibrary(JJLjava/lang/String;)J
.end method

# direct methods
.method private native registerCustomOpsUsingFunction(JJLjava/lang/String;)V
.end method

# direct methods
.method private native setCPUArenaAllocator(JJZ)V
.end method

# direct methods
.method private native setExecutionMode(JJI)V
.end method

# direct methods
.method private native setInterOpNumThreads(JJI)V
.end method

# direct methods
.method private native setIntraOpNumThreads(JJI)V
.end method

# direct methods
.method private native setLoggerId(JJLjava/lang/String;)V
.end method

# direct methods
.method private native setMemoryPatternOptimization(JJZ)V
.end method

# direct methods
.method private native setOptimizationLevel(JJI)V
.end method

# direct methods
.method private native setOptimizationModelFilePath(JJLjava/lang/String;)V
.end method

# direct methods
.method private native setSessionLogLevel(JJI)V
.end method

# direct methods
.method private native setSessionLogVerbosityLevel(JJI)V
.end method

# virtual methods
.method public addACL(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addACL(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public addArmNN(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addArmNN(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public addCPU(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addCPU(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public addCUDA()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Lai/onnxruntime/OrtSession$SessionOptions;->addCUDA(I)V
    .line 4: return-void
.end method

# virtual methods
.method public addCUDA(I)V
    .registers 9

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractCUDA()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_19
    .line 9: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 11: iget-wide v4, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 13: move-object v1, v7
    .line 14: move v6, v8
    .line 15: invoke-direct/range {v1 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->addCUDA(JJI)V
    .line 18: return-void
    .line 19: new-instance v8, Lai/onnxruntime/OrtException;
    .line 21: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 23: const-string v1, "Failed to find CUDA shared provider"
    .line 25: invoke-direct {v8, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 28: throw v8
.end method

# virtual methods
.method public addCUDA(Lai/onnxruntime/providers/OrtCUDAProviderOptions;)V
    .registers 10

    .line 0: invoke-direct {v8}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractCUDA()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_23
    .line 9: invoke-virtual {v9}, Lai/onnxruntime/providers/StringConfigProviderOptions;->applyToNative()V
    .line 12: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 14: iget-wide v4, v8, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 16: iget-wide v6, v9, Lai/onnxruntime/OrtProviderOptions;->nativeHandle:J
    .line 18: move-object v1, v8
    .line 19: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession$SessionOptions;->addCUDAV2(JJJ)V
    .line 22: return-void
    .line 23: new-instance v9, Lai/onnxruntime/OrtException;
    .line 25: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 27: const-string v1, "Failed to find CUDA shared provider"
    .line 29: invoke-direct {v9, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 32: throw v9
.end method

# virtual methods
.method public addConfigEntry(Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v7
    .line 8: move-object v5, v8
    .line 9: move-object v6, v9
    .line 10: invoke-direct/range {v0 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->addConfigEntry(JJLjava/lang/String;Ljava/lang/String;)V
    .line 13: iget-object v0, v7, Lai/onnxruntime/OrtSession$SessionOptions;->configEntries:Ljava/util/Map;
    .line 15: invoke-interface {v0, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 18: return-void
.end method

# virtual methods
.method public addCoreML()V
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/providers/CoreMLFlags;
    .line 2: invoke-static {v0}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;
    .line 5: move-result-object v0
    .line 6: invoke-virtual {v1, v0}, Lai/onnxruntime/OrtSession$SessionOptions;->addCoreML(Ljava/util/EnumSet;)V
    .line 9: return-void
.end method

# virtual methods
.method public addCoreML(Ljava/util/EnumSet;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-static {v7}, Lai/onnxruntime/providers/OrtFlags;->aggregateToInt(Ljava/util/EnumSet;)I
    .line 10: move-result v5
    .line 11: move-object v0, v6
    .line 12: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addCoreML(JJI)V
    .line 15: return-void
.end method

# virtual methods
.method public addDirectML(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addDirectML(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public addDnnl(Z)V
    .registers 9

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractDNNL()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_19
    .line 9: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 11: iget-wide v4, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 13: move-object v1, v7
    .line 14: move v6, v8
    .line 15: invoke-direct/range {v1 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->addDnnl(JJI)V
    .line 18: return-void
    .line 19: new-instance v8, Lai/onnxruntime/OrtException;
    .line 21: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 23: const-string v1, "Failed to find DNNL shared provider"
    .line 25: invoke-direct {v8, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 28: throw v8
.end method

# virtual methods
.method public addExternalInitializers(Ljava/util/Map;)V
    .registers 10

    .line 0: invoke-direct {v8}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-interface {v9}, Ljava/util/Map;->isEmpty()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_10
    .line 9: return-void
    .line 10: invoke-interface {v9}, Ljava/util/Map;->size()I
    .line 13: move-result v0
    .line 14: new-array v6, v0, [Ljava/lang/String;
    .line 16: invoke-interface {v9}, Ljava/util/Map;->size()I
    .line 19: move-result v0
    .line 20: new-array v7, v0, [J
    .line 22: invoke-interface {v9}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 25: move-result-object v9
    .line 26: invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 29: move-result-object v9
    .line 30: const/4 v0, 0
    .line 31: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 34: move-result v1
    .line 35: if-eqz v1, :cond_64
    .line 37: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 40: move-result-object v1
    .line 41: check-cast v1, Ljava/util/Map$Entry;
    .line 43: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 46: move-result-object v2
    .line 47: check-cast v2, Ljava/lang/String;
    .line 49: aput-object v2, v6, v0
    .line 51: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 54: move-result-object v1
    .line 55: check-cast v1, Lai/onnxruntime/OnnxTensorLike;
    .line 57: iget-wide v1, v1, Lai/onnxruntime/OnnxTensorLike;->nativeHandle:J
    .line 59: aput-wide v1, v7, v0
    .line 61: add-int/lit8 v0, v0, 1
    .line 63: goto :goto_31
    .line 64: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 66: iget-wide v4, v8, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 68: move-object v1, v8
    .line 69: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession$SessionOptions;->addExternalInitializers(JJ[Ljava/lang/String;[J)V
    .line 72: return-void
.end method

# virtual methods
.method public addInitializer(Ljava/lang/String;Lai/onnxruntime/OnnxTensorLike;)V
    .registers 12

    .line 0: invoke-direct {v9}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;
    .line 6: move-result-object v0
    .line 7: invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    .line 10: move-result v0
    .line 11: if-nez v0, :cond_27
    .line 13: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 15: iget-wide v4, v9, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 17: invoke-virtual {v11}, Lai/onnxruntime/OnnxTensorLike;->getNativeHandle()J
    .line 20: move-result-wide v7
    .line 21: move-object v1, v9
    .line 22: move-object v6, v10
    .line 23: invoke-direct/range {v1 .. v8}, Lai/onnxruntime/OrtSession$SessionOptions;->addInitializer(JJLjava/lang/String;J)V
    .line 26: return-void
    .line 27: new-instance v10, Ljava/lang/IllegalArgumentException;
    .line 29: const-string v11, "Initializer name was blank"
    .line 31: invoke-direct {v10, v11}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 34: throw v10
.end method

# virtual methods
.method public addNnapi()V
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/providers/NNAPIFlags;
    .line 2: invoke-static {v0}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;
    .line 5: move-result-object v0
    .line 6: invoke-virtual {v1, v0}, Lai/onnxruntime/OrtSession$SessionOptions;->addNnapi(Ljava/util/EnumSet;)V
    .line 9: return-void
.end method

# virtual methods
.method public addNnapi(Ljava/util/EnumSet;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-static {v7}, Lai/onnxruntime/providers/OrtFlags;->aggregateToInt(Ljava/util/EnumSet;)I
    .line 10: move-result v5
    .line 11: move-object v0, v6
    .line 12: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addNnapi(JJI)V
    .line 15: return-void
.end method

# virtual methods
.method public addOpenVINO(Ljava/lang/String;)V
    .registers 9

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractOpenVINO()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_19
    .line 9: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 11: iget-wide v4, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 13: move-object v1, v7
    .line 14: move-object v6, v8
    .line 15: invoke-direct/range {v1 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->addOpenVINO(JJLjava/lang/String;)V
    .line 18: return-void
    .line 19: new-instance v8, Lai/onnxruntime/OrtException;
    .line 21: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 23: const-string v1, "Failed to find OpenVINO shared provider"
    .line 25: invoke-direct {v8, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 28: throw v8
.end method

# virtual methods
.method public addROCM()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Lai/onnxruntime/OrtSession$SessionOptions;->addROCM(I)V
    .line 4: return-void
.end method

# virtual methods
.method public addROCM(I)V
    .registers 9

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractROCM()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_19
    .line 9: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 11: iget-wide v4, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 13: move-object v1, v7
    .line 14: move v6, v8
    .line 15: invoke-direct/range {v1 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->addROCM(JJI)V
    .line 18: return-void
    .line 19: new-instance v8, Lai/onnxruntime/OrtException;
    .line 21: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 23: const-string v1, "Failed to find ROCM shared provider"
    .line 25: invoke-direct {v8, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 28: throw v8
.end method

# virtual methods
.method public addTensorrt(I)V
    .registers 9

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractTensorRT()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_19
    .line 9: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 11: iget-wide v4, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 13: move-object v1, v7
    .line 14: move v6, v8
    .line 15: invoke-direct/range {v1 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->addTensorrt(JJI)V
    .line 18: return-void
    .line 19: new-instance v8, Lai/onnxruntime/OrtException;
    .line 21: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 23: const-string v1, "Failed to find TensorRT shared provider"
    .line 25: invoke-direct {v8, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 28: throw v8
.end method

# virtual methods
.method public addTensorrt(Lai/onnxruntime/providers/OrtTensorRTProviderOptions;)V
    .registers 10

    .line 0: invoke-direct {v8}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractTensorRT()Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_23
    .line 9: invoke-virtual {v9}, Lai/onnxruntime/providers/StringConfigProviderOptions;->applyToNative()V
    .line 12: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 14: iget-wide v4, v8, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 16: iget-wide v6, v9, Lai/onnxruntime/OrtProviderOptions;->nativeHandle:J
    .line 18: move-object v1, v8
    .line 19: invoke-direct/range {v1 .. v7}, Lai/onnxruntime/OrtSession$SessionOptions;->addTensorrtV2(JJJ)V
    .line 22: return-void
    .line 23: new-instance v9, Lai/onnxruntime/OrtException;
    .line 25: sget-object v0, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 27: const-string v1, "Failed to find TensorRT shared provider"
    .line 29: invoke-direct {v9, v0, v1}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 32: throw v9
.end method

# virtual methods
.method public addTvm(Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move-object v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addTvm(JJLjava/lang/String;)V
    .line 12: return-void
.end method

# virtual methods
.method public addXnnpack(Ljava/util/Map;)V
    .registers 11

    .line 0: invoke-direct {v9}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: invoke-interface {v10}, Ljava/util/Map;->size()I
    .line 6: move-result v0
    .line 7: new-array v7, v0, [Ljava/lang/String;
    .line 9: invoke-interface {v10}, Ljava/util/Map;->size()I
    .line 12: move-result v0
    .line 13: new-array v8, v0, [Ljava/lang/String;
    .line 15: invoke-interface {v10}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 18: move-result-object v10
    .line 19: invoke-interface {v10}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 22: move-result-object v10
    .line 23: const/4 v0, 0
    .line 24: invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z
    .line 27: move-result v1
    .line 28: if-eqz v1, :cond_55
    .line 30: invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 33: move-result-object v1
    .line 34: check-cast v1, Ljava/util/Map$Entry;
    .line 36: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 39: move-result-object v2
    .line 40: check-cast v2, Ljava/lang/String;
    .line 42: aput-object v2, v7, v0
    .line 44: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 47: move-result-object v1
    .line 48: check-cast v1, Ljava/lang/String;
    .line 50: aput-object v1, v8, v0
    .line 52: add-int/lit8 v0, v0, 1
    .line 54: goto :goto_24
    .line 55: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 57: iget-wide v4, v9, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 59: const-string v6, "XNNPACK"
    .line 61: move-object v1, v9
    .line 62: invoke-direct/range {v1 .. v8}, Lai/onnxruntime/OrtSession$SessionOptions;->addExecutionProvider(JJLjava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)V
    .line 65: return-void
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtSession$SessionOptions;->closed:Z
    .line 2: if-nez v0, :cond_60
    .line 4: iget-object v0, v4, Lai/onnxruntime/OrtSession$SessionOptions;->customLibraryHandles:Ljava/util/List;
    .line 6: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 9: move-result v0
    .line 10: if-lez v0, :cond_49
    .line 12: iget-object v0, v4, Lai/onnxruntime/OrtSession$SessionOptions;->customLibraryHandles:Ljava/util/List;
    .line 14: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 17: move-result v0
    .line 18: new-array v0, v0, [J
    .line 20: const/4 v1, 0
    .line 21: iget-object v2, v4, Lai/onnxruntime/OrtSession$SessionOptions;->customLibraryHandles:Ljava/util/List;
    .line 23: invoke-interface {v2}, Ljava/util/List;->size()I
    .line 26: move-result v2
    .line 27: if-ge v1, v2, :cond_46
    .line 29: iget-object v2, v4, Lai/onnxruntime/OrtSession$SessionOptions;->customLibraryHandles:Ljava/util/List;
    .line 31: invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 34: move-result-object v2
    .line 35: check-cast v2, Ljava/lang/Long;
    .line 37: invoke-virtual {v2}, Ljava/lang/Long;->longValue()J
    .line 40: move-result-wide v2
    .line 41: aput-wide v2, v0, v1
    .line 43: add-int/lit8 v1, v1, 1
    .line 45: goto :goto_21
    .line 46: invoke-direct {v4, v0}, Lai/onnxruntime/OrtSession$SessionOptions;->closeCustomLibraries([J)V
    .line 49: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 51: iget-wide v2, v4, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 53: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$SessionOptions;->closeOptions(JJ)V
    .line 56: const/4 v0, 1
    .line 57: iput-boolean v0, v4, Lai/onnxruntime/OrtSession$SessionOptions;->closed:Z
    .line 59: return-void
    .line 60: new-instance v0, Ljava/lang/IllegalStateException;
    .line 62: const-string v1, "Trying to close a closed SessionOptions."
    .line 64: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 67: throw v0
.end method

# virtual methods
.method public disablePerSessionThreads()V
    .registers 5

    .line 0: invoke-direct {v4}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v2, v4, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$SessionOptions;->disablePerSessionThreads(JJ)V
    .line 10: return-void
.end method

# virtual methods
.method public disableProfiling()V
    .registers 5

    .line 0: invoke-direct {v4}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v2, v4, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtSession$SessionOptions;->disableProfiling(JJ)V
    .line 10: return-void
.end method

# virtual methods
.method public enableProfiling(Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move-object v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->enableProfiling(JJLjava/lang/String;)V
    .line 12: return-void
.end method

# virtual methods
.method public getConfigEntries()Ljava/util/Map;
    .registers 2

    .line 0: invoke-direct {v1}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: iget-object v0, v1, Lai/onnxruntime/OrtSession$SessionOptions;->configEntries:Ljava/util/Map;
    .line 5: invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;
    .line 8: move-result-object v0
    .line 9: return-object v0
.end method

# virtual methods
.method public getNativeHandle()J
    .registers 3

    .line 0: iget-wide v0, v2, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 2: return-wide v0
.end method

# virtual methods
.method public registerCustomOpLibrary(Ljava/lang/String;)V
    .registers 9

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: const-string v0, "path must not be null"
    .line 5: invoke-static {v8, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .line 8: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 10: iget-wide v4, v7, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 12: move-object v1, v7
    .line 13: move-object v6, v8
    .line 14: invoke-direct/range {v1 .. v6}, Lai/onnxruntime/OrtSession$SessionOptions;->registerCustomOpLibrary(JJLjava/lang/String;)J
    .line 17: move-result-wide v0
    .line 18: iget-object v8, v7, Lai/onnxruntime/OrtSession$SessionOptions;->customLibraryHandles:Ljava/util/List;
    .line 20: invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 23: move-result-object v0
    .line 24: invoke-interface {v8, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 27: return-void
.end method

# virtual methods
.method public registerCustomOpsUsingFunction(Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move-object v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->registerCustomOpsUsingFunction(JJLjava/lang/String;)V
    .line 12: return-void
.end method

# virtual methods
.method public setCPUArenaAllocator(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setCPUArenaAllocator(JJZ)V
    .line 12: return-void
.end method

# virtual methods
.method public setExecutionMode(Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-virtual {v7}, Lai/onnxruntime/OrtSession$SessionOptions$ExecutionMode;->getID()I
    .line 10: move-result v5
    .line 11: move-object v0, v6
    .line 12: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setExecutionMode(JJI)V
    .line 15: return-void
.end method

# virtual methods
.method public setInterOpNumThreads(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setInterOpNumThreads(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public setIntraOpNumThreads(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setIntraOpNumThreads(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public setLoggerId(Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move-object v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setLoggerId(JJLjava/lang/String;)V
    .line 12: return-void
.end method

# virtual methods
.method public setMemoryPatternOptimization(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setMemoryPatternOptimization(JJZ)V
    .line 12: return-void
.end method

# virtual methods
.method public setOptimizationLevel(Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-virtual {v7}, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->getID()I
    .line 10: move-result v5
    .line 11: move-object v0, v6
    .line 12: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setOptimizationLevel(JJI)V
    .line 15: return-void
.end method

# virtual methods
.method public setOptimizedModelFilePath(Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move-object v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setOptimizationModelFilePath(JJLjava/lang/String;)V
    .line 12: return-void
.end method

# virtual methods
.method public setSessionLogLevel(Lai/onnxruntime/OrtLoggingLevel;)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: invoke-virtual {v7}, Lai/onnxruntime/OrtLoggingLevel;->getValue()I
    .line 10: move-result v5
    .line 11: move-object v0, v6
    .line 12: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setSessionLogLevel(JJI)V
    .line 15: return-void
.end method

# virtual methods
.method public setSessionLogVerbosityLevel(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setSessionLogVerbosityLevel(JJI)V
    .line 12: return-void
.end method

# virtual methods
.method public setSymbolicDimensionValue(Ljava/lang/String;J)V
    .registers 12

    .line 0: invoke-direct {v8}, Lai/onnxruntime/OrtSession$SessionOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v8, Lai/onnxruntime/OrtSession$SessionOptions;->nativeHandle:J
    .line 7: move-object v0, v8
    .line 8: move-object v5, v9
    .line 9: move-wide v6, v10
    .line 10: invoke-direct/range {v0 .. v7}, Lai/onnxruntime/OrtSession$SessionOptions;->addFreeDimensionOverrideByName(JJLjava/lang/String;J)V
    .line 13: return-void
.end method

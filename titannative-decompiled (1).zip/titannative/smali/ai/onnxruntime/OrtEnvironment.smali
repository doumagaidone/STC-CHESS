.class public final Lai/onnxruntime/OrtEnvironment;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field public static final DEFAULT_NAME:Ljava/lang/String;
.field private static volatile INSTANCE:Lai/onnxruntime/OrtEnvironment;
.field private static volatile curLogLevel:Lai/onnxruntime/OrtLoggingLevel;
.field private static volatile curLoggingName:Ljava/lang/String;
.field private static final logger:Ljava/util/logging/Logger;

.field final defaultAllocator:Lai/onnxruntime/OrtAllocator;
.field final nativeHandle:J

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: const-class v0, Lai/onnxruntime/OrtEnvironment;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/OrtEnvironment;->logger:Ljava/util/logging/Logger;
    .line 12: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 15: return-void
    .line 16: move-exception v0
    .line 17: new-instance v1, Ljava/lang/RuntimeException;
    .line 19: const-string v2, "Failed to load onnx-runtime library"
    .line 21: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 24: throw v1
.end method

# direct methods
.method private constructor <init>()V
    .registers 3

    .line 0: sget-object v0, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_WARNING:Lai/onnxruntime/OrtLoggingLevel;
    .line 2: const-string v1, "java-default"
    .line 4: invoke-direct {v2, v0, v1}, Lai/onnxruntime/OrtEnvironment;-><init>(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)V
    .line 7: return-void
.end method

# direct methods
.method private constructor <init>(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)V
    .registers 8

    .line 0: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: invoke-virtual {v6}, Lai/onnxruntime/OrtLoggingLevel;->getValue()I
    .line 8: move-result v6
    .line 9: invoke-static {v0, v1, v6, v7}, Lai/onnxruntime/OrtEnvironment;->createHandle(JILjava/lang/String;)J
    .line 12: move-result-wide v6
    .line 13: iput-wide v6, v5, Lai/onnxruntime/OrtEnvironment;->nativeHandle:J
    .line 15: new-instance v0, Lai/onnxruntime/OrtAllocator;
    .line 17: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 19: invoke-static {v1, v2}, Lai/onnxruntime/OrtEnvironment;->getDefaultAllocator(J)J
    .line 22: move-result-wide v1
    .line 23: const/4 v3, 1
    .line 24: invoke-direct {v0, v1, v2, v3}, Lai/onnxruntime/OrtAllocator;-><init>(JZ)V
    .line 27: iput-object v0, v5, Lai/onnxruntime/OrtEnvironment;->defaultAllocator:Lai/onnxruntime/OrtAllocator;
    .line 29: invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;
    .line 32: move-result-object v0
    .line 33: new-instance v1, Ljava/lang/Thread;
    .line 35: new-instance v2, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;
    .line 37: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 39: invoke-direct {v2, v3, v4, v6, v7}, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;-><init>(JJ)V
    .line 42: invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V
    .line 45: invoke-virtual {v0, v1}, Ljava/lang/Runtime;->addShutdownHook(Ljava/lang/Thread;)V
    .line 48: return-void
.end method

# direct methods
.method private constructor <init>(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;Lai/onnxruntime/OrtEnvironment$ThreadingOptions;)V
    .registers 10

    .line 0: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: invoke-virtual {v7}, Lai/onnxruntime/OrtLoggingLevel;->getValue()I
    .line 8: move-result v2
    .line 9: invoke-static {v9}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->access$000(Lai/onnxruntime/OrtEnvironment$ThreadingOptions;)J
    .line 12: move-result-wide v4
    .line 13: move-object v3, v8
    .line 14: invoke-static/range {v0 .. v5}, Lai/onnxruntime/OrtEnvironment;->createHandle(JILjava/lang/String;J)J
    .line 17: move-result-wide v7
    .line 18: iput-wide v7, v6, Lai/onnxruntime/OrtEnvironment;->nativeHandle:J
    .line 20: new-instance v9, Lai/onnxruntime/OrtAllocator;
    .line 22: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 24: invoke-static {v0, v1}, Lai/onnxruntime/OrtEnvironment;->getDefaultAllocator(J)J
    .line 27: move-result-wide v0
    .line 28: const/4 v2, 1
    .line 29: invoke-direct {v9, v0, v1, v2}, Lai/onnxruntime/OrtAllocator;-><init>(JZ)V
    .line 32: iput-object v9, v6, Lai/onnxruntime/OrtEnvironment;->defaultAllocator:Lai/onnxruntime/OrtAllocator;
    .line 34: invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;
    .line 37: move-result-object v9
    .line 38: new-instance v0, Ljava/lang/Thread;
    .line 40: new-instance v1, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;
    .line 42: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 44: invoke-direct {v1, v2, v3, v7, v8}, Lai/onnxruntime/OrtEnvironment$OrtEnvCloser;-><init>(JJ)V
    .line 47: invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V
    .line 50: invoke-virtual {v9, v0}, Ljava/lang/Runtime;->addShutdownHook(Ljava/lang/Thread;)V
    .line 53: return-void
.end method

# direct methods
.method public static synthetic access$100(JJ)V
    .registers 4

    .line 0: invoke-static {v0, v1, v2, v3}, Lai/onnxruntime/OrtEnvironment;->close(JJ)V
    .line 3: return-void
.end method

# direct methods
.method private static native close(JJ)V
.end method

# direct methods
.method private static native createHandle(JILjava/lang/String;)J
.end method

# direct methods
.method private static native createHandle(JILjava/lang/String;J)J
.end method

# direct methods
.method public static getAvailableProviders()Ljava/util/EnumSet;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OnnxRuntime;->providers:Ljava/util/EnumSet;
    .line 2: invoke-virtual {v0}, Ljava/util/EnumSet;->clone()Ljava/util/EnumSet;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# direct methods
.method private static native getDefaultAllocator(J)J
.end method

# direct methods
.method public static declared-synchronized getEnvironment()Lai/onnxruntime/OrtEnvironment;
    .registers 3

    .line 0: const-class v0, Lai/onnxruntime/OrtEnvironment;
    .line 2: monitor-enter v0
    .line 3: sget-object v1, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 5: if-nez v1, :cond_19
    .line 7: sget-object v1, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_WARNING:Lai/onnxruntime/OrtLoggingLevel;
    .line 9: const-string v2, "ort-java"
    .line 11: invoke-static {v1, v2}, Lai/onnxruntime/OrtEnvironment;->getEnvironment(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)Lai/onnxruntime/OrtEnvironment;
    .line 14: move-result-object v1
    .line 15: monitor-exit v0
    .line 16: return-object v1
    .line 17: move-exception v1
    .line 18: goto :goto_23
    .line 19: sget-object v1, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 21: monitor-exit v0
    .line 22: return-object v1
    .line 23: monitor-exit v0
    .line 24: throw v1
.end method

# direct methods
.method public static getEnvironment(Lai/onnxruntime/OrtLoggingLevel;)Lai/onnxruntime/OrtEnvironment;
    .registers 2

    .line 0: const-string v0, "ort-java"
    .line 2: invoke-static {v1, v0}, Lai/onnxruntime/OrtEnvironment;->getEnvironment(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)Lai/onnxruntime/OrtEnvironment;
    .line 5: move-result-object v1
    .line 6: return-object v1
.end method

# direct methods
.method public static declared-synchronized getEnvironment(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)Lai/onnxruntime/OrtEnvironment;
    .registers 4

    .line 0: const-class v0, Lai/onnxruntime/OrtEnvironment;
    .line 2: monitor-enter v0
    .line 3: sget-object v1, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 5: if-nez v1, :cond_30
    .line 7: new-instance v1, Lai/onnxruntime/OrtEnvironment;
    .line 9: invoke-direct {v1, v2, v3}, Lai/onnxruntime/OrtEnvironment;-><init>(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)V
    .line 12: sput-object v1, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 14: sput-object v2, Lai/onnxruntime/OrtEnvironment;->curLogLevel:Lai/onnxruntime/OrtLoggingLevel;
    .line 16: sput-object v3, Lai/onnxruntime/OrtEnvironment;->curLoggingName:Ljava/lang/String;
    .line 18: goto :goto_57
    .line 19: move-exception v2
    .line 20: goto :goto_61
    .line 21: move-exception v2
    .line 22: new-instance v3, Ljava/lang/IllegalStateException;
    .line 24: const-string v1, "Failed to create OrtEnvironment"
    .line 26: invoke-direct {v3, v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 29: throw v3
    .line 30: invoke-virtual {v2}, Lai/onnxruntime/OrtLoggingLevel;->getValue()I
    .line 33: move-result v2
    .line 34: sget-object v1, Lai/onnxruntime/OrtEnvironment;->curLogLevel:Lai/onnxruntime/OrtLoggingLevel;
    .line 36: invoke-virtual {v1}, Lai/onnxruntime/OrtLoggingLevel;->getValue()I
    .line 39: move-result v1
    .line 40: if-ne v2, v1, :cond_50
    .line 42: sget-object v2, Lai/onnxruntime/OrtEnvironment;->curLoggingName:Ljava/lang/String;
    .line 44: invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 47: move-result v2
    .line 48: if-nez v2, :cond_57
    .line 50: sget-object v2, Lai/onnxruntime/OrtEnvironment;->logger:Ljava/util/logging/Logger;
    .line 52: const-string v3, "Tried to change OrtEnvironment's logging level or name while a reference exists."
    .line 54: invoke-virtual {v2, v3}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V
    .line 57: sget-object v2, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 59: monitor-exit v0
    .line 60: return-object v2
    .line 61: monitor-exit v0
    .line 62: throw v2
.end method

# direct methods
.method public static declared-synchronized getEnvironment(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;Lai/onnxruntime/OrtEnvironment$ThreadingOptions;)Lai/onnxruntime/OrtEnvironment;
    .registers 5

    .line 0: const-class v0, Lai/onnxruntime/OrtEnvironment;
    .line 2: monitor-enter v0
    .line 3: sget-object v1, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 5: if-nez v1, :cond_33
    .line 7: new-instance v1, Lai/onnxruntime/OrtEnvironment;
    .line 9: invoke-direct {v1, v2, v3, v4}, Lai/onnxruntime/OrtEnvironment;-><init>(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;Lai/onnxruntime/OrtEnvironment$ThreadingOptions;)V
    .line 12: sput-object v1, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 14: sput-object v2, Lai/onnxruntime/OrtEnvironment;->curLogLevel:Lai/onnxruntime/OrtLoggingLevel;
    .line 16: sput-object v3, Lai/onnxruntime/OrtEnvironment;->curLoggingName:Ljava/lang/String;
    .line 18: sget-object v2, Lai/onnxruntime/OrtEnvironment;->INSTANCE:Lai/onnxruntime/OrtEnvironment;
    .line 20: monitor-exit v0
    .line 21: return-object v2
    .line 22: move-exception v2
    .line 23: goto :goto_41
    .line 24: move-exception v2
    .line 25: new-instance v3, Ljava/lang/IllegalStateException;
    .line 27: const-string v4, "Failed to create OrtEnvironment"
    .line 29: invoke-direct {v3, v4, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 32: throw v3
    .line 33: new-instance v2, Ljava/lang/IllegalStateException;
    .line 35: const-string v3, "Tried to specify the thread pool when creating an OrtEnvironment, but one already exists."
    .line 37: invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 40: throw v2
    .line 41: monitor-exit v0
    .line 42: throw v2
.end method

# direct methods
.method public static getEnvironment(Ljava/lang/String;)Lai/onnxruntime/OrtEnvironment;
    .registers 2

    .line 0: sget-object v0, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_WARNING:Lai/onnxruntime/OrtLoggingLevel;
    .line 2: invoke-static {v0, v1}, Lai/onnxruntime/OrtEnvironment;->getEnvironment(Lai/onnxruntime/OrtLoggingLevel;Ljava/lang/String;)Lai/onnxruntime/OrtEnvironment;
    .line 5: move-result-object v1
    .line 6: return-object v1
.end method

# direct methods
.method private static native setTelemetry(JJZ)V
.end method

# virtual methods
.method public close()V
    .registers 1

    .line 0: return-void
.end method

# virtual methods
.method public createSession(Ljava/lang/String;)Lai/onnxruntime/OrtSession;
    .registers 3

    .line 0: new-instance v0, Lai/onnxruntime/OrtSession$SessionOptions;
    .line 2: invoke-direct {v0}, Lai/onnxruntime/OrtSession$SessionOptions;-><init>()V
    .line 5: invoke-virtual {v1, v2, v0}, Lai/onnxruntime/OrtEnvironment;->createSession(Ljava/lang/String;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .line 8: move-result-object v2
    .line 9: return-object v2
.end method

# virtual methods
.method public createSession(Ljava/lang/String;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .registers 5

    .line 0: const-string v0, "model path must not be null"
    .line 2: invoke-static {v2, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .line 5: new-instance v0, Lai/onnxruntime/OrtSession;
    .line 7: invoke-direct {v0, v1, v2, v3, v4}, Lai/onnxruntime/OrtSession;-><init>(Lai/onnxruntime/OrtEnvironment;Ljava/lang/String;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)V
    .line 10: return-object v0
.end method

# virtual methods
.method public createSession(Ljava/lang/String;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .registers 4

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtEnvironment;->defaultAllocator:Lai/onnxruntime/OrtAllocator;
    .line 2: invoke-virtual {v1, v2, v0, v3}, Lai/onnxruntime/OrtEnvironment;->createSession(Ljava/lang/String;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# virtual methods
.method public createSession([B)Lai/onnxruntime/OrtSession;
    .registers 3

    .line 0: new-instance v0, Lai/onnxruntime/OrtSession$SessionOptions;
    .line 2: invoke-direct {v0}, Lai/onnxruntime/OrtSession$SessionOptions;-><init>()V
    .line 5: invoke-virtual {v1, v2, v0}, Lai/onnxruntime/OrtEnvironment;->createSession([BLai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .line 8: move-result-object v2
    .line 9: return-object v2
.end method

# virtual methods
.method public createSession([BLai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .registers 5

    .line 0: const-string v0, "model array must not be null"
    .line 2: invoke-static {v2, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .line 5: new-instance v0, Lai/onnxruntime/OrtSession;
    .line 7: invoke-direct {v0, v1, v2, v3, v4}, Lai/onnxruntime/OrtSession;-><init>(Lai/onnxruntime/OrtEnvironment;[BLai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)V
    .line 10: return-object v0
.end method

# virtual methods
.method public createSession([BLai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .registers 4

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtEnvironment;->defaultAllocator:Lai/onnxruntime/OrtAllocator;
    .line 2: invoke-virtual {v1, v2, v0, v3}, Lai/onnxruntime/OrtEnvironment;->createSession([BLai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# virtual methods
.method public createTrainingSession(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lai/onnxruntime/OrtTrainingSession;
    .registers 11

    .line 0: new-instance v5, Lai/onnxruntime/OrtSession$SessionOptions;
    .line 2: invoke-direct {v5}, Lai/onnxruntime/OrtSession$SessionOptions;-><init>()V
    .line 5: move-object v0, v6
    .line 6: move-object v1, v7
    .line 7: move-object v2, v8
    .line 8: move-object v3, v9
    .line 9: move-object v4, v10
    .line 10: invoke-virtual/range {v0 .. v5}, Lai/onnxruntime/OrtEnvironment;->createTrainingSession(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtTrainingSession;
    .line 13: move-result-object v7
    .line 14: return-object v7
.end method

# virtual methods
.method public createTrainingSession(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtTrainingSession;
    .registers 16

    .line 0: sget-boolean v0, Lai/onnxruntime/OnnxRuntime;->trainingEnabled:Z
    .line 2: if-eqz v0, :cond_26
    .line 4: const-string v0, "train path must not be null"
    .line 6: invoke-static {v11, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .line 9: invoke-static {v10}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->loadCheckpoint(Ljava/lang/String;)Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 12: move-result-object v5
    .line 13: new-instance v10, Lai/onnxruntime/OrtTrainingSession;
    .line 15: move-object v1, v10
    .line 16: move-object v2, v9
    .line 17: move-object v3, v14
    .line 18: move-object v4, v15
    .line 19: move-object v6, v11
    .line 20: move-object v7, v12
    .line 21: move-object v8, v13
    .line 22: invoke-direct/range {v1 .. v8}, Lai/onnxruntime/OrtTrainingSession;-><init>(Lai/onnxruntime/OrtEnvironment;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 25: return-object v10
    .line 26: new-instance v10, Ljava/lang/IllegalStateException;
    .line 28: const-string v11, "Training is not enabled in this build of ONNX Runtime."
    .line 30: invoke-direct {v10, v11}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 33: throw v10
.end method

# virtual methods
.method public createTrainingSession(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtTrainingSession;
    .registers 13

    .line 0: iget-object v5, v7, Lai/onnxruntime/OrtEnvironment;->defaultAllocator:Lai/onnxruntime/OrtAllocator;
    .line 2: move-object v0, v7
    .line 3: move-object v1, v8
    .line 4: move-object v2, v9
    .line 5: move-object v3, v10
    .line 6: move-object v4, v11
    .line 7: move-object v6, v12
    .line 8: invoke-virtual/range {v0 .. v6}, Lai/onnxruntime/OrtEnvironment;->createTrainingSession(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtTrainingSession;
    .line 11: move-result-object v8
    .line 12: return-object v8
.end method

# virtual methods
.method public getNativeHandle()J
    .registers 3

    .line 0: iget-wide v0, v2, Lai/onnxruntime/OrtEnvironment;->nativeHandle:J
    .line 2: return-wide v0
.end method

# virtual methods
.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->version()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# virtual methods
.method public isTrainingEnabled()Z
    .registers 2

    .line 0: sget-boolean v0, Lai/onnxruntime/OnnxRuntime;->trainingEnabled:Z
    .line 2: return v0
.end method

# virtual methods
.method public setTelemetry(Z)V
    .registers 6

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: iget-wide v2, v4, Lai/onnxruntime/OrtEnvironment;->nativeHandle:J
    .line 4: invoke-static {v0, v1, v2, v3, v5}, Lai/onnxruntime/OrtEnvironment;->setTelemetry(JJZ)V
    .line 7: return-void
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "OrtEnvironment(name="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: sget-object v1, Lai/onnxruntime/OrtEnvironment;->curLoggingName:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ",logLevel="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: sget-object v1, Lai/onnxruntime/OrtEnvironment;->curLogLevel:Lai/onnxruntime/OrtLoggingLevel;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ",version="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v2}, Lai/onnxruntime/OrtEnvironment;->getVersion()Ljava/lang/String;
    .line 30: move-result-object v1
    .line 31: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 34: const-string v1, ")"
    .line 36: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 42: move-result-object v0
    .line 43: return-object v0
.end method

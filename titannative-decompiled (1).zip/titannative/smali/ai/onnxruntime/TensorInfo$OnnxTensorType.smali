.class public final enum Lai/onnxruntime/TensorInfo$OnnxTensorType;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX128:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E4M3FN:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E4M3FNUZ:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E5M2:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E5M2FNUZ:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field public static final enum ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED:Lai/onnxruntime/TensorInfo$OnnxTensorType;
.field private static final values:[Lai/onnxruntime/TensorInfo$OnnxTensorType;

.field public final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 25

    .line 0: new-instance v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 2: move-object v0, v1
    .line 3: const-string v2, "ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED"
    .line 5: const/4 v15, 0
    .line 6: invoke-direct {v1, v2, v15, v15}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 9: sput-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 11: new-instance v2, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 13: move-object v1, v2
    .line 14: const-string v3, "ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8"
    .line 16: const/4 v4, 1
    .line 17: invoke-direct {v2, v3, v4, v4}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 20: sput-object v2, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 22: new-instance v3, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 24: move-object v2, v3
    .line 25: const-string v4, "ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8"
    .line 27: const/4 v5, 2
    .line 28: invoke-direct {v3, v4, v5, v5}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 31: sput-object v3, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 33: new-instance v4, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 35: move-object v3, v4
    .line 36: const-string v5, "ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT16"
    .line 38: const/4 v6, 3
    .line 39: invoke-direct {v4, v5, v6, v6}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 42: sput-object v4, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 44: new-instance v5, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 46: move-object v4, v5
    .line 47: const-string v6, "ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16"
    .line 49: const/4 v7, 4
    .line 50: invoke-direct {v5, v6, v7, v7}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 53: sput-object v5, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 55: new-instance v6, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 57: move-object v5, v6
    .line 58: const-string v7, "ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT32"
    .line 60: const/4 v8, 5
    .line 61: invoke-direct {v6, v7, v8, v8}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 64: sput-object v6, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 66: new-instance v7, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 68: move-object v6, v7
    .line 69: const-string v8, "ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32"
    .line 71: const/4 v9, 6
    .line 72: invoke-direct {v7, v8, v9, v9}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 75: sput-object v7, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 77: new-instance v8, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 79: move-object v7, v8
    .line 80: const-string v9, "ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT64"
    .line 82: const/4 v10, 7
    .line 83: invoke-direct {v8, v9, v10, v10}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 86: sput-object v8, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 88: new-instance v9, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 90: move-object v8, v9
    .line 91: const-string v10, "ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64"
    .line 93: const/16 v11, 8
    .line 95: invoke-direct {v9, v10, v11, v11}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 98: sput-object v9, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 100: new-instance v10, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 102: move-object v9, v10
    .line 103: const-string v11, "ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16"
    .line 105: const/16 v12, 9
    .line 107: invoke-direct {v10, v11, v12, v12}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 110: sput-object v10, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 112: new-instance v11, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 114: move-object v10, v11
    .line 115: const-string v12, "ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT"
    .line 117: const/16 v13, 10
    .line 119: invoke-direct {v11, v12, v13, v13}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 122: sput-object v11, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 124: new-instance v12, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 126: move-object v11, v12
    .line 127: const-string v13, "ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE"
    .line 129: const/16 v14, 11
    .line 131: invoke-direct {v12, v13, v14, v14}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 134: sput-object v12, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 136: new-instance v13, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 138: move-object v12, v13
    .line 139: const-string v14, "ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING"
    .line 141: const/16 v15, 12
    .line 143: invoke-direct {v13, v14, v15, v15}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 146: sput-object v13, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 148: new-instance v14, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 150: move-object v13, v14
    .line 151: const-string v15, "ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL"
    .line 153: move-object/from16 v21, v0
    .line 155: const/16 v0, 13
    .line 157: invoke-direct {v14, v15, v0, v0}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 160: sput-object v14, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 162: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 164: move-object v14, v0
    .line 165: const-string v15, "ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX64"
    .line 167: move-object/from16 v22, v1
    .line 169: const/16 v1, 14
    .line 171: invoke-direct {v0, v15, v1, v1}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 174: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 176: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 178: const/16 v23, 0
    .line 180: move-object v15, v0
    .line 181: const-string v1, "ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX128"
    .line 183: move-object/from16 v24, v2
    .line 185: const/16 v2, 15
    .line 187: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 190: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX128:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 192: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 194: move-object/from16 v16, v0
    .line 196: const-string v1, "ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16"
    .line 198: const/16 v2, 16
    .line 200: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 203: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 205: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 207: move-object/from16 v17, v0
    .line 209: const-string v1, "ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E4M3FN"
    .line 211: const/16 v2, 17
    .line 213: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 216: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E4M3FN:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 218: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 220: move-object/from16 v18, v0
    .line 222: const-string v1, "ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E4M3FNUZ"
    .line 224: const/16 v2, 18
    .line 226: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 229: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E4M3FNUZ:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 231: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 233: move-object/from16 v19, v0
    .line 235: const-string v1, "ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E5M2"
    .line 237: const/16 v2, 19
    .line 239: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 242: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E5M2:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 244: new-instance v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 246: move-object/from16 v20, v0
    .line 248: const-string v1, "ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E5M2FNUZ"
    .line 250: const/16 v2, 20
    .line 252: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/TensorInfo$OnnxTensorType;-><init>(Ljava/lang/String;II)V
    .line 255: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT8E5M2FNUZ:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 257: move-object/from16 v0, v21
    .line 259: move-object/from16 v1, v22
    .line 261: move-object/from16 v2, v24
    .line 263: filled-new-array/range {v0 .. v20}, [Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 266: move-result-object v0
    .line 267: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->$VALUES:[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 269: const/16 v0, 21
    .line 271: new-array v0, v0, [Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 273: sput-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->values:[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 275: invoke-static {}, Lai/onnxruntime/TensorInfo$OnnxTensorType;->values()[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 278: move-result-object v0
    .line 279: array-length v1, v0
    .line 280: move/from16 v15, v23
    .line 282: if-ge v15, v1, :cond_295
    .line 284: aget-object v2, v0, v15
    .line 286: sget-object v3, Lai/onnxruntime/TensorInfo$OnnxTensorType;->values:[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 288: iget v4, v2, Lai/onnxruntime/TensorInfo$OnnxTensorType;->value:I
    .line 290: aput-object v2, v3, v4
    .line 292: add-int/lit8 v15, v15, 1
    .line 294: goto :goto_282
    .line 295: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->value:I
    .line 5: return-void
.end method

# direct methods
.method public static mapFromInt(I)Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .registers 3

    .line 0: if-lez v2, :cond_10
    .line 2: sget-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->values:[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 4: array-length v1, v0
    .line 5: if-ge v2, v1, :cond_10
    .line 7: aget-object v2, v0, v2
    .line 9: return-object v2
    .line 10: sget-object v2, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 12: return-object v2
.end method

# direct methods
.method public static mapFromJavaType(Lai/onnxruntime/OnnxJavaType;)Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .registers 2

    .line 0: sget-object v0, Lai/onnxruntime/TensorInfo$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 2: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v1, v0, v1
    .line 8: packed-switch v1, :data_48
    .line 11: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 13: return-object v1
    .line 14: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 16: return-object v1
    .line 17: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 19: return-object v1
    .line 20: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 22: return-object v1
    .line 23: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 25: return-object v1
    .line 26: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 28: return-object v1
    .line 29: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 31: return-object v1
    .line 32: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 34: return-object v1
    .line 35: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 37: return-object v1
    .line 38: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 40: return-object v1
    .line 41: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 43: return-object v1
    .line 44: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 46: return-object v1
    .line 47: nop
    .line 48: nop
    .line 49: move-result-wide v0
    .line 50: move v0, v0
    .line 51: nop
    .line 52: filled-new-array {}, B
    .line 55: nop
    .line 56: monitor-exit v0
    .line 57: nop
    .line 58: const-string/jumbo v0, "string@1572864"
    .line 61: nop
    .line 62: const/high16 v0, 0x0
    .line 64: const/4 v0, 0
    .line 65: nop
    .line 66: return v0
    .line 67: nop
    .line 68: move-result-object v0
    .line 69: nop
    .line 70: move-object/16 v0, v6
    .line 73: nop
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/TensorInfo$OnnxTensorType;->$VALUES:[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/TensorInfo$OnnxTensorType;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 8: return-object v0
.end method

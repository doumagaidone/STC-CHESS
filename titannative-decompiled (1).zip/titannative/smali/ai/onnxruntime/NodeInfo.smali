.class public Lai/onnxruntime/NodeInfo;
.super Ljava/lang/Object;
.source "SourceFile"

.field private final info:Lai/onnxruntime/ValueInfo;
.field private final name:Ljava/lang/String;

# direct methods
.method public constructor <init>(Ljava/lang/String;Lai/onnxruntime/ValueInfo;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lai/onnxruntime/NodeInfo;->name:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lai/onnxruntime/NodeInfo;->info:Lai/onnxruntime/ValueInfo;
    .line 7: return-void
.end method

# virtual methods
.method public getInfo()Lai/onnxruntime/ValueInfo;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/NodeInfo;->info:Lai/onnxruntime/ValueInfo;
    .line 2: return-object v0
.end method

# virtual methods
.method public getName()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/NodeInfo;->name:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "NodeInfo(name="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lai/onnxruntime/NodeInfo;->name:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ",info="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Lai/onnxruntime/NodeInfo;->info:Lai/onnxruntime/ValueInfo;
    .line 19: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 22: move-result-object v1
    .line 23: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: const-string v1, ")"
    .line 28: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 31: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 34: move-result-object v0
    .line 35: return-object v0
.end method

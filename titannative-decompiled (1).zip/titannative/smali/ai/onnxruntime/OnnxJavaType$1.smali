.class synthetic Lai/onnxruntime/OnnxJavaType$1;
.super Ljava/lang/Object;
.source "SourceFile"

.field static final synthetic $SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/TensorInfo$OnnxTensorType;->values()[Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 9: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 11: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 14: move-result v1
    .line 15: const/4 v2, 1
    .line 16: aput v2, v0, v1
    .line 18: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 20: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 22: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 25: move-result v1
    .line 26: const/4 v2, 2
    .line 27: aput v2, v0, v1
    .line 29: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 31: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 33: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 36: move-result v1
    .line 37: const/4 v2, 3
    .line 38: aput v2, v0, v1
    .line 40: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 42: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 44: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 47: move-result v1
    .line 48: const/4 v2, 4
    .line 49: aput v2, v0, v1
    .line 51: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 53: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 55: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 58: move-result v1
    .line 59: const/4 v2, 5
    .line 60: aput v2, v0, v1
    .line 62: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 64: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 66: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 69: move-result v1
    .line 70: const/4 v2, 6
    .line 71: aput v2, v0, v1
    .line 73: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 75: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 77: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 80: move-result v1
    .line 81: const/4 v2, 7
    .line 82: aput v2, v0, v1
    .line 84: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 86: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 88: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 91: move-result v1
    .line 92: const/16 v2, 8
    .line 94: aput v2, v0, v1
    .line 96: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 98: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 100: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 103: move-result v1
    .line 104: const/16 v2, 9
    .line 106: aput v2, v0, v1
    .line 108: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 110: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 112: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 115: move-result v1
    .line 116: const/16 v2, 10
    .line 118: aput v2, v0, v1
    .line 120: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 122: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 124: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 127: move-result v1
    .line 128: const/16 v2, 11
    .line 130: aput v2, v0, v1
    .line 132: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 134: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 136: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 139: move-result v1
    .line 140: const/16 v2, 12
    .line 142: aput v2, v0, v1
    .line 144: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 146: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 148: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 151: move-result v1
    .line 152: const/16 v2, 13
    .line 154: aput v2, v0, v1
    .line 156: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 158: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 160: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 163: move-result v1
    .line 164: const/16 v2, 14
    .line 166: aput v2, v0, v1
    .line 168: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 170: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 172: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 175: move-result v1
    .line 176: const/16 v2, 15
    .line 178: aput v2, v0, v1
    .line 180: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 182: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX64:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 184: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 187: move-result v1
    .line 188: const/16 v2, 16
    .line 190: aput v2, v0, v1
    .line 192: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 194: sget-object v1, Lai/onnxruntime/TensorInfo$OnnxTensorType;->ONNX_TENSOR_ELEMENT_DATA_TYPE_COMPLEX128:Lai/onnxruntime/TensorInfo$OnnxTensorType;
    .line 196: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 199: move-result v1
    .line 200: const/16 v2, 17
    .line 202: aput v2, v0, v1
    .line 204: return-void
.end method

.class public Lai/onnxruntime/OrtException;
.super Ljava/lang/Exception;
.source "SourceFile"

.field private static final serialVersionUID:J

.field private final errorCode:Lai/onnxruntime/OrtException$OrtErrorCode;

# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .registers 3

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtException$OrtErrorCode;->mapFromInt(I)Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 3: move-result-object v1
    .line 4: invoke-direct {v0, v1, v2}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Error code - "
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 10: const-string v1, " - message: "
    .line 12: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 15: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 18: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 21: move-result-object v4
    .line 22: invoke-direct {v2, v4}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V
    .line 25: iput-object v3, v2, Lai/onnxruntime/OrtException;->errorCode:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 27: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 0: invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V
    .line 3: sget-object v1, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_JAVA_UNKNOWN:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 5: iput-object v1, v0, Lai/onnxruntime/OrtException;->errorCode:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 7: return-void
.end method

# virtual methods
.method public getCode()Lai/onnxruntime/OrtException$OrtErrorCode;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtException;->errorCode:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 2: return-object v0
.end method

.class public final Lai/onnxruntime/OrtUtil;
.super Ljava/lang/Object;
.source "SourceFile"

.field private static final logger:Ljava/util/logging/Logger;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-class v0, Lai/onnxruntime/OrtUtil;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/OrtUtil;->logger:Ljava/util/logging/Logger;
    .line 12: return-void
.end method

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static capacityFromSize(I)I
    .registers 5

    .line 0: int-to-double v0, v4
    .line 1: const-wide/high16 v2, 0x3fe8
    .line 3: div-double/2addr v0, v2
    .line 4: const-wide/high16 v2, 0x3ff0
    .line 6: add-double/2addr v0, v2
    .line 7: double-to-int v4, v0
    .line 8: return v4
.end method

# direct methods
.method public static convertBoxedPrimitiveToArray(Lai/onnxruntime/OnnxJavaType;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0: sget-object v0, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 2: invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v3
    .line 6: aget v3, v0, v3
    .line 8: const/4 v0, 0
    .line 9: const/4 v1, 1
    .line 10: packed-switch v3, :data_92
    .line 13: const/4 v3, 0
    .line 14: return-object v3
    .line 15: new-array v3, v1, [Z
    .line 17: check-cast v4, Ljava/lang/Boolean;
    .line 19: invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z
    .line 22: move-result v4
    .line 23: aput-boolean v4, v3, v0
    .line 25: return-object v3
    .line 26: new-array v3, v1, [J
    .line 28: check-cast v4, Ljava/lang/Long;
    .line 30: invoke-virtual {v4}, Ljava/lang/Long;->longValue()J
    .line 33: move-result-wide v1
    .line 34: aput-wide v1, v3, v0
    .line 36: return-object v3
    .line 37: check-cast v4, Ljava/lang/Integer;
    .line 39: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    .line 42: move-result v3
    .line 43: filled-new-array {v3}, [I
    .line 46: move-result-object v3
    .line 47: return-object v3
    .line 48: new-array v3, v1, [S
    .line 50: check-cast v4, Ljava/lang/Short;
    .line 52: invoke-virtual {v4}, Ljava/lang/Short;->shortValue()S
    .line 55: move-result v4
    .line 56: aput-short v4, v3, v0
    .line 58: return-object v3
    .line 59: new-array v3, v1, [B
    .line 61: check-cast v4, Ljava/lang/Byte;
    .line 63: invoke-virtual {v4}, Ljava/lang/Byte;->byteValue()B
    .line 66: move-result v4
    .line 67: aput-byte v4, v3, v0
    .line 69: return-object v3
    .line 70: new-array v3, v1, [D
    .line 72: check-cast v4, Ljava/lang/Double;
    .line 74: invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D
    .line 77: move-result-wide v1
    .line 78: aput-wide v1, v3, v0
    .line 80: return-object v3
    .line 81: new-array v3, v1, [F
    .line 83: check-cast v4, Ljava/lang/Float;
    .line 85: invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F
    .line 88: move-result v4
    .line 89: aput v4, v3, v0
    .line 91: return-object v3
    .line 92: nop
    .line 93: move-object/from16 v0, v1
    .line 95: nop
    .line 96: aget-boolean v0, v0, v0
    .line 98: if-gtz v0, :cond_98
    .line 100: cmp-long v0, v0, v0
    .line 102: cmp-long v0, v0, v0
    .line 104: fill-array-data v0, :data_1769576
    .line 107: nop
    .line 108: return-wide v0
    .line 109: nop
    .line 110: move-wide/from16 v0, v0
.end method

# direct methods
.method public static elementCount([J)J
    .registers 8

    .line 0: const-wide/16 v0, 1
    .line 2: const/4 v2, 0
    .line 3: array-length v3, v7
    .line 4: if-ge v2, v3, :cond_47
    .line 6: aget-wide v3, v7, v2
    .line 8: const-wide/16 v5, 0
    .line 10: cmp-long v5, v3, v5
    .line 12: if-ltz v5, :cond_18
    .line 14: mul-long/2addr v0, v3
    .line 15: add-int/lit8 v2, v2, 1
    .line 17: goto :goto_3
    .line 18: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 20: new-instance v1, Ljava/lang/StringBuilder;
    .line 22: const-string v2, "Received negative value in shape "
    .line 24: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 27: invoke-static {v7}, Ljava/util/Arrays;->toString([J)Ljava/lang/String;
    .line 30: move-result-object v7
    .line 31: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 34: const-string v7, " ."
    .line 36: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 42: move-result-object v7
    .line 43: invoke-direct {v0, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 46: throw v0
    .line 47: return-wide v0
.end method

# direct methods
.method private static flattenString([Ljava/lang/Object;Ljava/util/ArrayList;)V
    .registers 8

    .line 0: array-length v0, v6
    .line 1: const/4 v1, 0
    .line 2: if-ge v1, v0, :cond_96
    .line 4: aget-object v2, v6, v1
    .line 6: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 9: move-result-object v3
    .line 10: invoke-virtual {v3}, Ljava/lang/Class;->isArray()Z
    .line 13: move-result v4
    .line 14: if-eqz v4, :cond_76
    .line 16: invoke-virtual {v3}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    .line 19: move-result-object v4
    .line 20: invoke-virtual {v4}, Ljava/lang/Class;->isArray()Z
    .line 23: move-result v4
    .line 24: if-eqz v4, :cond_32
    .line 26: check-cast v2, [Ljava/lang/Object;
    .line 28: invoke-static {v2, v7}, Lai/onnxruntime/OrtUtil;->flattenString([Ljava/lang/Object;Ljava/util/ArrayList;)V
    .line 31: goto :goto_53
    .line 32: invoke-virtual {v3}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    .line 35: move-result-object v4
    .line 36: const-class v5, Ljava/lang/String;
    .line 38: invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 41: move-result v4
    .line 42: if-eqz v4, :cond_56
    .line 44: check-cast v2, [Ljava/lang/String;
    .line 46: invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 49: move-result-object v2
    .line 50: invoke-virtual {v7, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    .line 53: add-int/lit8 v1, v1, 1
    .line 55: goto :goto_2
    .line 56: new-instance v6, Ljava/lang/IllegalStateException;
    .line 58: new-instance v7, Ljava/lang/StringBuilder;
    .line 60: const-string v0, "Found a non-String, non-array element type, "
    .line 62: invoke-direct {v7, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 65: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 68: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 71: move-result-object v7
    .line 72: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 75: throw v6
    .line 76: new-instance v6, Ljava/lang/IllegalStateException;
    .line 78: new-instance v7, Ljava/lang/StringBuilder;
    .line 80: const-string v0, "Found an element type where there should have been an array. Class = "
    .line 82: invoke-direct {v7, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 85: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 88: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 91: move-result-object v7
    .line 92: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 95: throw v6
    .line 96: return-void
.end method

# direct methods
.method public static flattenString(Ljava/lang/Object;)[Ljava/lang/String;
    .registers 2

    .line 0: instance-of v0, v1, [Ljava/lang/String;
    .line 2: if-eqz v0, :cond_7
    .line 4: check-cast v1, [Ljava/lang/String;
    .line 6: return-object v1
    .line 7: new-instance v0, Ljava/util/ArrayList;
    .line 9: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 12: check-cast v1, [Ljava/lang/Object;
    .line 14: invoke-static {v1, v0}, Lai/onnxruntime/OrtUtil;->flattenString([Ljava/lang/Object;Ljava/util/ArrayList;)V
    .line 17: const/4 v1, 0
    .line 18: new-array v1, v1, [Ljava/lang/String;
    .line 20: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 23: move-result-object v1
    .line 24: check-cast v1, [Ljava/lang/String;
    .line 26: return-object v1
.end method

# direct methods
.method public static newBooleanArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newByteArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newDoubleArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newFloatArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newIntArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newLongArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newShortArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static newStringArray([J)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->transformShape([J)[I
    .line 3: move-result-object v1
    .line 4: const-class v0, Ljava/lang/String;
    .line 6: invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static prepareBuffer(Ljava/nio/Buffer;Lai/onnxruntime/OnnxJavaType;)Lai/onnxruntime/OrtUtil$BufferTuple;
    .registers 13

    .line 0: sget-object v0, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 2: if-eq v12, v0, :cond_224
    .line 4: sget-object v0, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 6: if-eq v12, v0, :cond_224
    .line 8: invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I
    .line 11: move-result v0
    .line 12: int-to-long v0, v0
    .line 13: iget v2, v12, Lai/onnxruntime/OnnxJavaType;->size:I
    .line 15: int-to-long v3, v2
    .line 16: mul-long/2addr v0, v3
    .line 17: mul-int/lit8 v2, v2, 8
    .line 19: const v3, 0x7fffffff
    .line 22: sub-int/2addr v3, v2
    .line 23: int-to-long v2, v3
    .line 24: cmp-long v0, v0, v2
    .line 26: if-gtz v0, :cond_192
    .line 28: invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I
    .line 31: move-result v0
    .line 32: iget v1, v12, Lai/onnxruntime/OnnxJavaType;->size:I
    .line 34: mul-int/2addr v0, v1
    .line 35: invoke-virtual {v11}, Ljava/nio/Buffer;->isDirect()Z
    .line 38: move-result v1
    .line 39: const/4 v2, 0
    .line 40: if-eqz v1, :cond_53
    .line 42: invoke-virtual {v11}, Ljava/nio/Buffer;->position()I
    .line 45: move-result v1
    .line 46: iget v12, v12, Lai/onnxruntime/OnnxJavaType;->size:I
    .line 48: mul-int/2addr v1, v12
    .line 49: move-object v4, v11
    .line 50: move v5, v1
    .line 51: goto/16 :goto_175
    .line 53: invoke-virtual {v11}, Ljava/nio/Buffer;->position()I
    .line 56: move-result v1
    .line 57: invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;
    .line 60: move-result-object v3
    .line 61: invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;
    .line 64: move-result-object v4
    .line 65: invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    .line 68: move-result-object v3
    .line 69: sget-object v4, Lai/onnxruntime/OrtUtil$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 71: invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I
    .line 74: move-result v5
    .line 75: aget v4, v4, v5
    .line 77: packed-switch v4, :data_250
    .line 80: new-instance v11, Ljava/lang/IllegalStateException;
    .line 82: new-instance v0, Ljava/lang/StringBuilder;
    .line 84: const-string v1, "Impossible to reach here, managed to cast a buffer as an incorrect type, found "
    .line 86: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 89: invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 92: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 95: move-result-object v12
    .line 96: invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 99: throw v11
    .line 100: invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asLongBuffer()Ljava/nio/LongBuffer;
    .line 103: move-result-object v12
    .line 104: move-object v3, v11
    .line 105: check-cast v3, Ljava/nio/LongBuffer;
    .line 107: invoke-virtual {v12, v3}, Ljava/nio/LongBuffer;->put(Ljava/nio/LongBuffer;)Ljava/nio/LongBuffer;
    .line 110: move-result-object v12
    .line 111: goto :goto_167
    .line 112: invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asIntBuffer()Ljava/nio/IntBuffer;
    .line 115: move-result-object v12
    .line 116: move-object v3, v11
    .line 117: check-cast v3, Ljava/nio/IntBuffer;
    .line 119: invoke-virtual {v12, v3}, Ljava/nio/IntBuffer;->put(Ljava/nio/IntBuffer;)Ljava/nio/IntBuffer;
    .line 122: move-result-object v12
    .line 123: goto :goto_167
    .line 124: invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asShortBuffer()Ljava/nio/ShortBuffer;
    .line 127: move-result-object v12
    .line 128: move-object v3, v11
    .line 129: check-cast v3, Ljava/nio/ShortBuffer;
    .line 131: invoke-virtual {v12, v3}, Ljava/nio/ShortBuffer;->put(Ljava/nio/ShortBuffer;)Ljava/nio/ShortBuffer;
    .line 134: move-result-object v12
    .line 135: goto :goto_167
    .line 136: move-object v12, v11
    .line 137: check-cast v12, Ljava/nio/ByteBuffer;
    .line 139: invoke-virtual {v3, v12}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
    .line 142: move-result-object v12
    .line 143: goto :goto_167
    .line 144: invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asDoubleBuffer()Ljava/nio/DoubleBuffer;
    .line 147: move-result-object v12
    .line 148: move-object v3, v11
    .line 149: check-cast v3, Ljava/nio/DoubleBuffer;
    .line 151: invoke-virtual {v12, v3}, Ljava/nio/DoubleBuffer;->put(Ljava/nio/DoubleBuffer;)Ljava/nio/DoubleBuffer;
    .line 154: move-result-object v12
    .line 155: goto :goto_167
    .line 156: invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;
    .line 159: move-result-object v12
    .line 160: move-object v3, v11
    .line 161: check-cast v3, Ljava/nio/FloatBuffer;
    .line 163: invoke-virtual {v12, v3}, Ljava/nio/FloatBuffer;->put(Ljava/nio/FloatBuffer;)Ljava/nio/FloatBuffer;
    .line 166: move-result-object v12
    .line 167: invoke-virtual {v11, v1}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;
    .line 170: invoke-virtual {v12}, Ljava/nio/Buffer;->rewind()Ljava/nio/Buffer;
    .line 173: move-object v4, v12
    .line 174: move v5, v2
    .line 175: new-instance v12, Lai/onnxruntime/OrtUtil$BufferTuple;
    .line 177: int-to-long v6, v0
    .line 178: invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I
    .line 181: move-result v0
    .line 182: int-to-long v8, v0
    .line 183: if-eq v4, v11, :cond_186
    .line 185: const/4 v2, 1
    .line 186: move v10, v2
    .line 187: move-object v3, v12
    .line 188: invoke-direct/range {v3 .. v10}, Lai/onnxruntime/OrtUtil$BufferTuple;-><init>(Ljava/nio/Buffer;IJJZ)V
    .line 191: return-object v12
    .line 192: new-instance v0, Ljava/lang/IllegalStateException;
    .line 194: new-instance v1, Ljava/lang/StringBuilder;
    .line 196: const-string v2, "Cannot allocate a direct buffer of the requested size and type, size "
    .line 198: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 201: invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I
    .line 204: move-result v11
    .line 205: invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 208: const-string v11, ", type = "
    .line 210: invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 213: invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 216: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 219: move-result-object v11
    .line 220: invoke-direct {v0, v11}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 223: throw v0
    .line 224: new-instance v11, Ljava/lang/IllegalStateException;
    .line 226: new-instance v0, Ljava/lang/StringBuilder;
    .line 228: const-string v1, "Cannot create a "
    .line 230: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 233: invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 236: const-string v12, " tensor from a buffer"
    .line 238: invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 241: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 244: move-result-object v12
    .line 245: invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 248: throw v11
    .line 249: nop
    .line 250: nop
    .line 251: move-result-object v0
    .line 252: move v0, v0
    .line 253: nop
    .line 254: aput-byte v0, v0, v0
    .line 256: 0x43 ; unknown opcode
    .line 257: nop
    .line 258: if-gez v0, :cond_258
    .line 260: if-gez v0, :cond_260
    .line 262: cmpl-double v0, v0, v0
    .line 264: new-array v0, v0, B
    .line 266: const-wide/32 v0, 0x3b0000
    .line 269: nop
    .line 270: move/16 v0, v3
    .line 273: nop
    .line 274: cmpl-double v0, v0, v0
    .line 276: cmpl-double v0, v0, v0
.end method

# direct methods
.method private static reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .registers 10

    .line 0: invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z
    .line 7: move-result v0
    .line 8: const-string v1, "Found element type when expecting an array. Class "
    .line 10: if-eqz v0, :cond_82
    .line 12: check-cast v8, [Ljava/lang/Object;
    .line 14: array-length v0, v8
    .line 15: const/4 v2, 0
    .line 16: move v3, v2
    .line 17: if-ge v3, v0, :cond_81
    .line 19: aget-object v4, v8, v3
    .line 21: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 24: move-result-object v5
    .line 25: invoke-virtual {v5}, Ljava/lang/Class;->isArray()Z
    .line 28: move-result v6
    .line 29: if-eqz v6, :cond_63
    .line 31: invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    .line 34: move-result-object v5
    .line 35: invoke-virtual {v5}, Ljava/lang/Class;->isPrimitive()Z
    .line 38: move-result v6
    .line 39: if-nez v6, :cond_51
    .line 41: const-class v6, Ljava/lang/String;
    .line 43: if-ne v5, v6, :cond_46
    .line 45: goto :goto_51
    .line 46: invoke-static {v7, v4, v9}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 49: move-result v9
    .line 50: goto :goto_60
    .line 51: invoke-static {v4}, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I
    .line 54: move-result v5
    .line 55: invoke-static {v7, v9, v4, v2, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 58: add-int/2addr v5, v9
    .line 59: move v9, v5
    .line 60: add-int/lit8 v3, v3, 1
    .line 62: goto :goto_17
    .line 63: new-instance v7, Ljava/lang/IllegalStateException;
    .line 65: new-instance v8, Ljava/lang/StringBuilder;
    .line 67: invoke-direct {v8, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 70: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 73: invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 76: move-result-object v8
    .line 77: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 80: throw v7
    .line 81: return v9
    .line 82: new-instance v7, Ljava/lang/IllegalStateException;
    .line 84: new-instance v9, Ljava/lang/StringBuilder;
    .line 86: invoke-direct {v9, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 89: invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 92: move-result-object v8
    .line 93: invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 96: invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 99: move-result-object v8
    .line 100: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 103: throw v7
.end method

# direct methods
.method public static reshape([B[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newByteArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([D[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newDoubleArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([F[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newFloatArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([I[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newIntArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([J[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newLongArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([Ljava/lang/String;[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newStringArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([S[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newShortArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static reshape([Z[J)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-static {v2}, Lai/onnxruntime/OrtUtil;->newBooleanArray([J)Ljava/lang/Object;
    .line 3: move-result-object v2
    .line 4: const/4 v0, 0
    .line 5: invoke-static {v1, v2, v0}, Lai/onnxruntime/OrtUtil;->reshape(Ljava/lang/Object;Ljava/lang/Object;I)I
    .line 8: return-object v2
.end method

# direct methods
.method public static transformShape([J)[I
    .registers 7

    .line 0: array-length v0, v6
    .line 1: if-eqz v0, :cond_61
    .line 3: array-length v0, v6
    .line 4: const/16 v1, 8
    .line 6: if-gt v0, v1, :cond_61
    .line 8: array-length v0, v6
    .line 9: new-array v0, v0, [I
    .line 11: const/4 v1, 0
    .line 12: array-length v2, v6
    .line 13: if-ge v1, v2, :cond_60
    .line 15: aget-wide v2, v6, v1
    .line 17: const-wide/16 v4, 0
    .line 19: cmp-long v4, v2, v4
    .line 21: if-ltz v4, :cond_36
    .line 23: const-wide/32 v4, 0x7fffffff
    .line 26: cmp-long v4, v2, v4
    .line 28: if-gtz v4, :cond_36
    .line 30: long-to-int v2, v2
    .line 31: aput v2, v0, v1
    .line 33: add-int/lit8 v1, v1, 1
    .line 35: goto :goto_12
    .line 36: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 38: new-instance v1, Ljava/lang/StringBuilder;
    .line 40: const-string v2, "Invalid shape for a Java array, expected non-negative entries smaller than Integer.MAX_VALUE. Found "
    .line 42: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 45: invoke-static {v6}, Ljava/util/Arrays;->toString([J)Ljava/lang/String;
    .line 48: move-result-object v6
    .line 49: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 52: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 55: move-result-object v6
    .line 56: invoke-direct {v0, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 59: throw v0
    .line 60: return-object v0
    .line 61: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 63: const-string v0, "Arrays with less than 1 and greater than 8 dimensions are not supported."
    .line 65: invoke-direct {v6, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 68: throw v6
.end method

# direct methods
.method public static transformShape([I)[J
    .registers 7

    .line 0: array-length v0, v6
    .line 1: if-eqz v0, :cond_54
    .line 3: array-length v0, v6
    .line 4: const/16 v1, 8
    .line 6: if-gt v0, v1, :cond_54
    .line 8: array-length v0, v6
    .line 9: new-array v0, v0, [J
    .line 11: const/4 v1, 0
    .line 12: array-length v2, v6
    .line 13: if-ge v1, v2, :cond_53
    .line 15: aget v2, v6, v1
    .line 17: int-to-long v2, v2
    .line 18: const-wide/16 v4, 1
    .line 20: cmp-long v4, v2, v4
    .line 22: if-ltz v4, :cond_29
    .line 24: aput-wide v2, v0, v1
    .line 26: add-int/lit8 v1, v1, 1
    .line 28: goto :goto_12
    .line 29: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 31: new-instance v1, Ljava/lang/StringBuilder;
    .line 33: const-string v2, "Invalid shape for a Java array, expected positive entries smaller than Integer.MAX_VALUE. Found "
    .line 35: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 38: invoke-static {v6}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;
    .line 41: move-result-object v6
    .line 42: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 45: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 48: move-result-object v6
    .line 49: invoke-direct {v0, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 52: throw v0
    .line 53: return-object v0
    .line 54: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 56: const-string v0, "Arrays with less than 1 and greater than 8 dimensions are not supported."
    .line 58: invoke-direct {v6, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 61: throw v6
.end method

# direct methods
.method public static validateShape([J)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: const/4 v1, 0
    .line 2: move v3, v0
    .line 3: move v2, v1
    .line 4: array-length v4, v8
    .line 5: if-ge v2, v4, :cond_32
    .line 7: aget-wide v4, v8, v2
    .line 9: const-wide/16 v6, 0
    .line 11: cmp-long v6, v4, v6
    .line 13: if-lez v6, :cond_17
    .line 15: move v6, v0
    .line 16: goto :goto_18
    .line 17: move v6, v1
    .line 18: and-int/2addr v3, v6
    .line 19: long-to-int v6, v4
    .line 20: int-to-long v6, v6
    .line 21: cmp-long v4, v6, v4
    .line 23: if-nez v4, :cond_27
    .line 25: move v4, v0
    .line 26: goto :goto_28
    .line 27: move v4, v1
    .line 28: and-int/2addr v3, v4
    .line 29: add-int/lit8 v2, v2, 1
    .line 31: goto :goto_4
    .line 32: if-eqz v3, :cond_40
    .line 34: array-length v8, v8
    .line 35: const/16 v2, 8
    .line 37: if-gt v8, v2, :cond_40
    .line 39: goto :goto_41
    .line 40: move v0, v1
    .line 41: return v0
.end method

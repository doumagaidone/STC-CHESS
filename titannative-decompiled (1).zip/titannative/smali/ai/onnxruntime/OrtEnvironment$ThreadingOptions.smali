.class public final Lai/onnxruntime/OrtEnvironment$ThreadingOptions;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private closed:Z
.field private final nativeHandle:J

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 3: return-void
    .line 4: move-exception v0
    .line 5: new-instance v1, Ljava/lang/RuntimeException;
    .line 7: const-string v2, "Failed to load onnx-runtime library"
    .line 9: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 12: throw v1
.end method

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-boolean v0, v2, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->closed:Z
    .line 6: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 8: invoke-static {v0, v1}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->createThreadingOptions(J)J
    .line 11: move-result-wide v0
    .line 12: iput-wide v0, v2, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 14: return-void
.end method

# direct methods
.method public static synthetic access$000(Lai/onnxruntime/OrtEnvironment$ThreadingOptions;)J
    .registers 3

    .line 0: iget-wide v0, v2, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 2: return-wide v0
.end method

# direct methods
.method private checkClosed()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->closed:Z
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IllegalStateException;
    .line 7: const-string v1, "Trying to use a closed ThreadingOptions"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# direct methods
.method private native closeThreadingOptions(JJ)V
.end method

# direct methods
.method private static native createThreadingOptions(J)J
.end method

# direct methods
.method private native setGlobalDenormalAsZero(JJ)V
.end method

# direct methods
.method private native setGlobalInterOpNumThreads(JJI)V
.end method

# direct methods
.method private native setGlobalIntraOpNumThreads(JJI)V
.end method

# direct methods
.method private native setGlobalSpinControl(JJI)V
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->closed:Z
    .line 2: if-nez v0, :cond_15
    .line 4: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v2, v4, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 8: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->closeThreadingOptions(JJ)V
    .line 11: const/4 v0, 1
    .line 12: iput-boolean v0, v4, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->closed:Z
    .line 14: return-void
    .line 15: new-instance v0, Ljava/lang/IllegalStateException;
    .line 17: const-string v1, "Trying to close a closed ThreadingOptions."
    .line 19: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# virtual methods
.method public setGlobalDenormalAsZero()V
    .registers 5

    .line 0: invoke-direct {v4}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->checkClosed()V
    .line 3: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v2, v4, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 7: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->setGlobalDenormalAsZero(JJ)V
    .line 10: return-void
.end method

# virtual methods
.method public setGlobalInterOpNumThreads(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->checkClosed()V
    .line 3: if-ltz v7, :cond_15
    .line 5: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 7: iget-wide v3, v6, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 9: move-object v0, v6
    .line 10: move v5, v7
    .line 11: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->setGlobalInterOpNumThreads(JJI)V
    .line 14: return-void
    .line 15: new-instance v7, Ljava/lang/IllegalArgumentException;
    .line 17: const-string v0, "Number of threads must be non-negative."
    .line 19: invoke-direct {v7, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 22: throw v7
.end method

# virtual methods
.method public setGlobalIntraOpNumThreads(I)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->checkClosed()V
    .line 3: if-ltz v7, :cond_15
    .line 5: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 7: iget-wide v3, v6, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 9: move-object v0, v6
    .line 10: move v5, v7
    .line 11: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->setGlobalIntraOpNumThreads(JJI)V
    .line 14: return-void
    .line 15: new-instance v7, Ljava/lang/IllegalArgumentException;
    .line 17: const-string v0, "Number of threads must be non-negative."
    .line 19: invoke-direct {v7, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 22: throw v7
.end method

# virtual methods
.method public setGlobalSpinControl(Z)V
    .registers 8

    .line 0: invoke-direct {v6}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: iget-wide v3, v6, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->nativeHandle:J
    .line 7: move-object v0, v6
    .line 8: move v5, v7
    .line 9: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OrtEnvironment$ThreadingOptions;->setGlobalSpinControl(JJI)V
    .line 12: return-void
.end method

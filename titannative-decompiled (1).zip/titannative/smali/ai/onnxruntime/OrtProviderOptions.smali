.class public abstract Lai/onnxruntime/OrtProviderOptions;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private static final logger:Ljava/util/logging/Logger;

.field protected closed:Z
.field protected final nativeHandle:J

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: const-class v0, Lai/onnxruntime/OrtProviderOptions;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/OrtProviderOptions;->logger:Ljava/util/logging/Logger;
    .line 12: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 15: return-void
    .line 16: move-exception v0
    .line 17: new-instance v1, Ljava/lang/RuntimeException;
    .line 19: const-string v2, "Failed to load onnx-runtime library"
    .line 21: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 24: throw v1
.end method

# direct methods
.method public constructor <init>(J)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-wide v1, v0, Lai/onnxruntime/OrtProviderOptions;->nativeHandle:J
    .line 5: const/4 v1, 0
    .line 6: iput-boolean v1, v0, Lai/onnxruntime/OrtProviderOptions;->closed:Z
    .line 8: return-void
.end method

# direct methods
.method public static getApiHandle()J
    .registers 2

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: return-wide v0
.end method

# direct methods
.method public static loadLibraryAndCreate(Lai/onnxruntime/OrtProvider;Lai/onnxruntime/OrtProviderOptions$OrtProviderSupplier;)J
    .registers 3

    .line 0: sget-object v0, Lai/onnxruntime/OrtProviderOptions$1;->$SwitchMap$ai$onnxruntime$OrtProvider:[I
    .line 2: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v1, v0, v1
    .line 8: const/4 v0, 1
    .line 9: if-eq v1, v0, :cond_92
    .line 11: const/4 v0, 2
    .line 12: if-eq v1, v0, :cond_75
    .line 14: const/4 v0, 3
    .line 15: if-eq v1, v0, :cond_58
    .line 17: const/4 v0, 4
    .line 18: if-eq v1, v0, :cond_41
    .line 20: const/4 v0, 5
    .line 21: if-eq v1, v0, :cond_24
    .line 23: goto :goto_98
    .line 24: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractTensorRT()Z
    .line 27: move-result v1
    .line 28: if-eqz v1, :cond_31
    .line 30: goto :goto_98
    .line 31: new-instance v1, Lai/onnxruntime/OrtException;
    .line 33: sget-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 35: const-string v0, "Failed to find TensorRT shared provider"
    .line 37: invoke-direct {v1, v2, v0}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 40: throw v1
    .line 41: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractROCM()Z
    .line 44: move-result v1
    .line 45: if-eqz v1, :cond_48
    .line 47: goto :goto_98
    .line 48: new-instance v1, Lai/onnxruntime/OrtException;
    .line 50: sget-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 52: const-string v0, "Failed to find ROCm shared provider"
    .line 54: invoke-direct {v1, v2, v0}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 57: throw v1
    .line 58: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractOpenVINO()Z
    .line 61: move-result v1
    .line 62: if-eqz v1, :cond_65
    .line 64: goto :goto_98
    .line 65: new-instance v1, Lai/onnxruntime/OrtException;
    .line 67: sget-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 69: const-string v0, "Failed to find OpenVINO shared provider"
    .line 71: invoke-direct {v1, v2, v0}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 74: throw v1
    .line 75: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractDNNL()Z
    .line 78: move-result v1
    .line 79: if-eqz v1, :cond_82
    .line 81: goto :goto_98
    .line 82: new-instance v1, Lai/onnxruntime/OrtException;
    .line 84: sget-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 86: const-string v0, "Failed to find DNNL shared provider"
    .line 88: invoke-direct {v1, v2, v0}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 91: throw v1
    .line 92: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->extractCUDA()Z
    .line 95: move-result v1
    .line 96: if-eqz v1, :cond_103
    .line 98: invoke-interface {v2}, Lai/onnxruntime/OrtProviderOptions$OrtProviderSupplier;->create()J
    .line 101: move-result-wide v1
    .line 102: return-wide v1
    .line 103: new-instance v1, Lai/onnxruntime/OrtException;
    .line 105: sget-object v2, Lai/onnxruntime/OrtException$OrtErrorCode;->ORT_EP_FAIL:Lai/onnxruntime/OrtException$OrtErrorCode;
    .line 107: const-string v0, "Failed to find CUDA shared provider"
    .line 109: invoke-direct {v1, v2, v0}, Lai/onnxruntime/OrtException;-><init>(Lai/onnxruntime/OrtException$OrtErrorCode;Ljava/lang/String;)V
    .line 112: throw v1
.end method

# virtual methods
.method public abstract applyToNative()V
.end method

# virtual methods
.method public checkClosed()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtProviderOptions;->closed:Z
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IllegalStateException;
    .line 7: const-string v1, "Trying to use a closed OrtProviderOptions"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtProviderOptions;->closed:Z
    .line 2: if-nez v0, :cond_15
    .line 4: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 6: iget-wide v2, v4, Lai/onnxruntime/OrtProviderOptions;->nativeHandle:J
    .line 8: invoke-virtual {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtProviderOptions;->close(JJ)V
    .line 11: const/4 v0, 1
    .line 12: iput-boolean v0, v4, Lai/onnxruntime/OrtProviderOptions;->closed:Z
    .line 14: goto :goto_22
    .line 15: sget-object v0, Lai/onnxruntime/OrtProviderOptions;->logger:Ljava/util/logging/Logger;
    .line 17: const-string v1, "Closing an already closed tensor."
    .line 19: invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V
    .line 22: return-void
.end method

# virtual methods
.method public abstract close(JJ)V
.end method

# virtual methods
.method public abstract getProvider()Lai/onnxruntime/OrtProvider;
.end method

# virtual methods
.method public declared-synchronized isClosed()Z
    .registers 2

    .line 0: monitor-enter v1
    .line 1: iget-boolean v0, v1, Lai/onnxruntime/OrtProviderOptions;->closed:Z
    .line 3: monitor-exit v1
    .line 4: return v0
    .line 5: move-exception v0
    .line 6: monitor-exit v1
    .line 7: throw v0
.end method

.class public abstract interface Lai/onnxruntime/OnnxValue;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

# direct methods
.method public static close(Ljava/lang/Iterable;)V
    .registers 2

    .line 0: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 3: move-result-object v1
    .line 4: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 7: move-result v0
    .line 8: if-eqz v0, :cond_20
    .line 10: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 13: move-result-object v0
    .line 14: check-cast v0, Lai/onnxruntime/OnnxValue;
    .line 16: invoke-interface {v0}, Lai/onnxruntime/OnnxValue;->close()V
    .line 19: goto :goto_4
    .line 20: return-void
.end method

# direct methods
.method public static close(Ljava/util/Map;)V
    .registers 2

    .line 0: invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 3: move-result-object v1
    .line 4: invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 7: move-result-object v1
    .line 8: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 11: move-result v0
    .line 12: if-eqz v0, :cond_24
    .line 14: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 17: move-result-object v0
    .line 18: check-cast v0, Lai/onnxruntime/OnnxValue;
    .line 20: invoke-interface {v0}, Lai/onnxruntime/OnnxValue;->close()V
    .line 23: goto :goto_8
    .line 24: return-void
.end method

# virtual methods
.method public abstract close()V
.end method

# virtual methods
.method public abstract getInfo()Lai/onnxruntime/ValueInfo;
.end method

# virtual methods
.method public abstract getType()Lai/onnxruntime/OnnxValue$OnnxValueType;
.end method

# virtual methods
.method public abstract getValue()Ljava/lang/Object;
.end method

# virtual methods
.method public abstract isClosed()Z
.end method

.class public final Lai/onnxruntime/OrtTrainingSession;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;

.field private final allocator:Lai/onnxruntime/OrtAllocator;
.field private final checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
.field private closed:Z
.field private final evalInputNames:Ljava/util/Set;
.field private final evalOutputNames:Ljava/util/Set;
.field private final evalPath:Ljava/lang/String;
.field private final nativeHandle:J
.field private final optimizerPath:Ljava/lang/String;
.field private final trainInputNames:Ljava/util/Set;
.field private final trainOutputNames:Ljava/util/Set;
.field private final trainPath:Ljava/lang/String;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->init()V
    .line 3: return-void
    .line 4: move-exception v0
    .line 5: new-instance v1, Ljava/lang/RuntimeException;
    .line 7: const-string v2, "Failed to load onnx-runtime library"
    .line 9: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 12: throw v1
.end method

# direct methods
.method private constructor <init>(JLai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 22

    .line 0: move-object v9, v14
    .line 1: move-object/from16 v10, v17
    .line 3: invoke-direct {v14}, Ljava/lang/Object;-><init>()V
    .line 6: const/4 v0, 0
    .line 7: iput-boolean v0, v9, Lai/onnxruntime/OrtTrainingSession;->closed:Z
    .line 9: move-wide v11, v15
    .line 10: iput-wide v11, v9, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 12: iput-object v10, v9, Lai/onnxruntime/OrtTrainingSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 14: move-object/from16 v0, v18
    .line 16: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 18: move-object/from16 v0, v19
    .line 20: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->trainPath:Ljava/lang/String;
    .line 22: move-object/from16 v0, v20
    .line 24: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->evalPath:Ljava/lang/String;
    .line 26: move-object/from16 v0, v21
    .line 28: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->optimizerPath:Ljava/lang/String;
    .line 30: new-instance v13, Ljava/util/LinkedHashSet;
    .line 32: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 34: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 36: iget-wide v7, v10, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 38: move-object v0, v14
    .line 39: move-wide v5, v15
    .line 40: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession;->getTrainInputNames(JJJJ)[Ljava/lang/String;
    .line 43: move-result-object v0
    .line 44: invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 47: move-result-object v0
    .line 48: invoke-direct {v13, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V
    .line 51: invoke-static {v13}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;
    .line 54: move-result-object v0
    .line 55: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 57: new-instance v13, Ljava/util/LinkedHashSet;
    .line 59: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 61: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 63: iget-wide v7, v10, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 65: move-object v0, v14
    .line 66: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession;->getTrainOutputNames(JJJJ)[Ljava/lang/String;
    .line 69: move-result-object v0
    .line 70: invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 73: move-result-object v0
    .line 74: invoke-direct {v13, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V
    .line 77: invoke-static {v13}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;
    .line 80: move-result-object v0
    .line 81: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 83: new-instance v13, Ljava/util/LinkedHashSet;
    .line 85: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 87: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 89: iget-wide v7, v10, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 91: move-object v0, v14
    .line 92: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession;->getEvalInputNames(JJJJ)[Ljava/lang/String;
    .line 95: move-result-object v0
    .line 96: invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 99: move-result-object v0
    .line 100: invoke-direct {v13, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V
    .line 103: invoke-static {v13}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;
    .line 106: move-result-object v0
    .line 107: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 109: new-instance v13, Ljava/util/LinkedHashSet;
    .line 111: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 113: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 115: iget-wide v7, v10, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 117: move-object v0, v14
    .line 118: invoke-direct/range {v0 .. v8}, Lai/onnxruntime/OrtTrainingSession;->getEvalOutputNames(JJJJ)[Ljava/lang/String;
    .line 121: move-result-object v0
    .line 122: invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 125: move-result-object v0
    .line 126: invoke-direct {v13, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V
    .line 129: invoke-static {v13}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;
    .line 132: move-result-object v0
    .line 133: iput-object v0, v9, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 135: return-void
.end method

# direct methods
.method public constructor <init>(Lai/onnxruntime/OrtEnvironment;Lai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtSession$SessionOptions;Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 24

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 4: invoke-virtual/range {v17 .. v17}, Lai/onnxruntime/OrtEnvironment;->getNativeHandle()J
    .line 7: move-result-wide v4
    .line 8: invoke-virtual/range {v19 .. v19}, Lai/onnxruntime/OrtSession$SessionOptions;->getNativeHandle()J
    .line 11: move-result-wide v6
    .line 12: move-object/from16 v13, v20
    .line 14: iget-wide v8, v13, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->nativeHandle:J
    .line 16: move-object/from16 v10, v21
    .line 18: move-object/from16 v11, v22
    .line 20: move-object/from16 v12, v23
    .line 22: invoke-static/range {v0 .. v12}, Lai/onnxruntime/OrtTrainingSession;->createTrainingSession(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)J
    .line 25: move-result-wide v9
    .line 26: move-object/from16 v8, v16
    .line 28: move-object/from16 v11, v18
    .line 30: move-object/from16 v12, v20
    .line 32: move-object/from16 v13, v21
    .line 34: move-object/from16 v14, v22
    .line 36: move-object/from16 v15, v23
    .line 38: invoke-direct/range {v8 .. v15}, Lai/onnxruntime/OrtTrainingSession;-><init>(JLai/onnxruntime/OrtAllocator;Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 41: return-void
.end method

# direct methods
.method private checkClosed()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtTrainingSession;->closed:Z
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IllegalStateException;
    .line 7: const-string v1, "Trying to use a closed OrtTrainingSession"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# direct methods
.method private native closeSession(JJ)V
.end method

# direct methods
.method private static native createTrainingSession(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)J
.end method

# direct methods
.method private native evalStep(JJJJ[Ljava/lang/String;[JJ[Ljava/lang/String;J[Lai/onnxruntime/OnnxValue;[JJ)[Z
.end method

# direct methods
.method private native exportModelForInference(JJJLjava/lang/String;J[Ljava/lang/String;)V
.end method

# direct methods
.method private native getEvalInputNames(JJJJ)[Ljava/lang/String;
.end method

# direct methods
.method private native getEvalOutputNames(JJJJ)[Ljava/lang/String;
.end method

# direct methods
.method private native getLearningRate(JJJ)F
.end method

# direct methods
.method private native getTrainInputNames(JJJJ)[Ljava/lang/String;
.end method

# direct methods
.method private native getTrainOutputNames(JJJJ)[Ljava/lang/String;
.end method

# direct methods
.method private native lazyResetGrad(JJJ)V
.end method

# direct methods
.method private native optimizerStep(JJJJ)V
.end method

# direct methods
.method private native registerLinearLRScheduler(JJJJJF)V
.end method

# direct methods
.method private native schedulerStep(JJJ)V
.end method

# direct methods
.method private native setLearningRate(JJJF)V
.end method

# direct methods
.method public static setSeed(J)V
    .registers 8

    .line 0: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 4: move-wide v4, v6
    .line 5: invoke-static/range {v0 .. v5}, Lai/onnxruntime/OrtTrainingSession;->setSeed(JJJ)V
    .line 8: return-void
.end method

# direct methods
.method private static native setSeed(JJJ)V
.end method

# direct methods
.method private native trainStep(JJJJ[Ljava/lang/String;[JJ[Ljava/lang/String;J[Lai/onnxruntime/OnnxValue;[JJ)[Z
.end method

# virtual methods
.method public addProperty(Ljava/lang/String;F)V
    .registers 4

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: invoke-virtual {v0, v2, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->addProperty(Ljava/lang/String;F)V
    .line 5: return-void
.end method

# virtual methods
.method public addProperty(Ljava/lang/String;I)V
    .registers 4

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: invoke-virtual {v0, v2, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->addProperty(Ljava/lang/String;I)V
    .line 5: return-void
.end method

# virtual methods
.method public addProperty(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: invoke-virtual {v0, v2, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->addProperty(Ljava/lang/String;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public close()V
    .registers 5

    .line 0: iget-boolean v0, v4, Lai/onnxruntime/OrtTrainingSession;->closed:Z
    .line 2: if-nez v0, :cond_20
    .line 4: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 6: iget-wide v2, v4, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 8: invoke-direct {v4, v0, v1, v2, v3}, Lai/onnxruntime/OrtTrainingSession;->closeSession(JJ)V
    .line 11: iget-object v0, v4, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 13: invoke-virtual {v0}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->close()V
    .line 16: const/4 v0, 1
    .line 17: iput-boolean v0, v4, Lai/onnxruntime/OrtTrainingSession;->closed:Z
    .line 19: return-void
    .line 20: new-instance v0, Ljava/lang/IllegalStateException;
    .line 22: const-string v1, "Trying to close an already closed OrtSession."
    .line 24: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 27: throw v0
.end method

# virtual methods
.method public evalStep(Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: iget-object v0, v3, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 2: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 5: move-result-object v1
    .line 6: const/4 v2, 0
    .line 7: invoke-virtual {v3, v4, v0, v1, v2}, Lai/onnxruntime/OrtTrainingSession;->evalStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 10: move-result-object v4
    .line 11: return-object v4
.end method

# virtual methods
.method public evalStep(Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: iget-object v0, v2, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 2: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v2, v3, v0, v1, v4}, Lai/onnxruntime/OrtTrainingSession;->evalStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 9: move-result-object v3
    .line 10: return-object v3
.end method

# virtual methods
.method public evalStep(Ljava/util/Map;Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: invoke-virtual {v2, v3, v0, v4, v1}, Lai/onnxruntime/OrtTrainingSession;->evalStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 8: move-result-object v3
    .line 9: return-object v3
.end method

# virtual methods
.method public evalStep(Ljava/util/Map;Ljava/util/Set;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: invoke-virtual {v2, v3, v4, v0, v1}, Lai/onnxruntime/OrtTrainingSession;->evalStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 8: move-result-object v3
    .line 9: return-object v3
.end method

# virtual methods
.method public evalStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 25

    .line 0: move-object/from16 v13, v20
    .line 2: invoke-direct/range {v20 .. v20}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 5: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->isEmpty()Z
    .line 8: move-result v0
    .line 9: const-string v1, ") found "
    .line 11: if-eqz v0, :cond_21
    .line 13: iget-object v0, v13, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 15: invoke-interface {v0}, Ljava/util/Set;->size()I
    .line 18: move-result v0
    .line 19: if-nez v0, :cond_438
    .line 21: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 24: move-result v0
    .line 25: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 27: invoke-interface {v2}, Ljava/util/Set;->size()I
    .line 30: move-result v2
    .line 31: if-gt v0, v2, :cond_438
    .line 33: iget-object v0, v13, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 35: invoke-interface {v0}, Ljava/util/Set;->size()I
    .line 38: move-result v0
    .line 39: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->size()I
    .line 42: move-result v2
    .line 43: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->size()I
    .line 46: move-result v3
    .line 47: add-int/2addr v3, v2
    .line 48: if-eqz v3, :cond_426
    .line 50: if-gt v3, v0, :cond_426
    .line 52: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 55: move-result v0
    .line 56: new-array v9, v0, [Ljava/lang/String;
    .line 58: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 61: move-result v1
    .line 62: new-array v10, v1, [J
    .line 64: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 67: move-result-object v1
    .line 68: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 71: move-result-object v1
    .line 72: const/4 v2, 0
    .line 73: move v3, v2
    .line 74: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 77: move-result v4
    .line 78: const-string v5, ", expected one of "
    .line 80: if-eqz v4, :cond_161
    .line 82: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 85: move-result-object v4
    .line 86: check-cast v4, Ljava/util/Map$Entry;
    .line 88: iget-object v6, v13, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 90: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 93: move-result-object v7
    .line 94: invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 97: move-result v6
    .line 98: if-eqz v6, :cond_123
    .line 100: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 103: move-result-object v5
    .line 104: check-cast v5, Ljava/lang/String;
    .line 106: aput-object v5, v9, v3
    .line 108: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 111: move-result-object v4
    .line 112: check-cast v4, Lai/onnxruntime/OnnxTensorLike;
    .line 114: invoke-virtual {v4}, Lai/onnxruntime/OnnxTensorLike;->getNativeHandle()J
    .line 117: move-result-wide v4
    .line 118: aput-wide v4, v10, v3
    .line 120: add-int/lit8 v3, v3, 1
    .line 122: goto :goto_74
    .line 123: new-instance v0, Lai/onnxruntime/OrtException;
    .line 125: new-instance v1, Ljava/lang/StringBuilder;
    .line 127: const-string v2, "Unknown input name "
    .line 129: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 132: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 135: move-result-object v2
    .line 136: check-cast v2, Ljava/lang/String;
    .line 138: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 141: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 144: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 146: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 149: move-result-object v2
    .line 150: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 153: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 156: move-result-object v1
    .line 157: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 160: throw v0
    .line 161: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->size()I
    .line 164: move-result v1
    .line 165: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->size()I
    .line 168: move-result v3
    .line 169: add-int v14, v3, v1
    .line 171: new-array v15, v14, [Ljava/lang/String;
    .line 173: new-array v11, v14, [Lai/onnxruntime/OnnxValue;
    .line 175: new-array v12, v14, [J
    .line 177: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 180: move-result-object v1
    .line 181: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 184: move-result-object v1
    .line 185: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 188: move-result v3
    .line 189: const-string v4, "Unknown output name "
    .line 191: if-eqz v3, :cond_278
    .line 193: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 196: move-result-object v3
    .line 197: check-cast v3, Ljava/util/Map$Entry;
    .line 199: iget-object v6, v13, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 201: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 204: move-result-object v7
    .line 205: invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 208: move-result v6
    .line 209: if-eqz v6, :cond_242
    .line 211: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 214: move-result-object v4
    .line 215: check-cast v4, Ljava/lang/String;
    .line 217: aput-object v4, v15, v2
    .line 219: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 222: move-result-object v4
    .line 223: check-cast v4, Lai/onnxruntime/OnnxValue;
    .line 225: aput-object v4, v11, v2
    .line 227: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 230: move-result-object v3
    .line 231: check-cast v3, Lai/onnxruntime/OnnxValue;
    .line 233: invoke-static {v3}, Lai/onnxruntime/OrtSession;->getHandle(Lai/onnxruntime/OnnxValue;)J
    .line 236: move-result-wide v3
    .line 237: aput-wide v3, v12, v2
    .line 239: add-int/lit8 v2, v2, 1
    .line 241: goto :goto_185
    .line 242: new-instance v0, Lai/onnxruntime/OrtException;
    .line 244: new-instance v1, Ljava/lang/StringBuilder;
    .line 246: invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 249: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 252: move-result-object v2
    .line 253: check-cast v2, Ljava/lang/String;
    .line 255: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 258: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 261: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 263: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 266: move-result-object v2
    .line 267: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 270: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 273: move-result-object v1
    .line 274: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 277: throw v0
    .line 278: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 281: move-result-object v1
    .line 282: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 285: move-result v3
    .line 286: if-eqz v3, :cond_370
    .line 288: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 291: move-result-object v3
    .line 292: check-cast v3, Ljava/lang/String;
    .line 294: iget-object v6, v13, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 296: invoke-interface {v6, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 299: move-result v6
    .line 300: if-eqz v6, :cond_340
    .line 302: move-object/from16 v6, v23
    .line 304: invoke-interface {v6, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 307: move-result v7
    .line 308: if-nez v7, :cond_315
    .line 310: aput-object v3, v15, v2
    .line 312: add-int/lit8 v2, v2, 1
    .line 314: goto :goto_282
    .line 315: new-instance v0, Lai/onnxruntime/OrtException;
    .line 317: new-instance v1, Ljava/lang/StringBuilder;
    .line 319: const-string v2, "Output '"
    .line 321: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 324: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 327: const-string v2, "' was found in both the requested outputs and the pinned outputs"
    .line 329: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 332: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 335: move-result-object v1
    .line 336: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 339: throw v0
    .line 340: new-instance v0, Lai/onnxruntime/OrtException;
    .line 342: new-instance v1, Ljava/lang/StringBuilder;
    .line 344: invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 347: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 350: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 353: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 355: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 358: move-result-object v2
    .line 359: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 362: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 365: move-result-object v1
    .line 366: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 369: throw v0
    .line 370: if-nez v24, :cond_377
    .line 372: const-wide/16 v1, 0
    .line 374: move-wide/from16 v18, v1
    .line 376: goto :goto_382
    .line 377: invoke-virtual/range {v24 .. v24}, Lai/onnxruntime/OrtSession$RunOptions;->getNativeHandle()J
    .line 380: move-result-wide v1
    .line 381: goto :goto_374
    .line 382: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 384: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 386: iget-wide v5, v13, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 388: iget-object v7, v13, Lai/onnxruntime/OrtTrainingSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 390: iget-wide v7, v7, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 392: move-object/from16 v16, v11
    .line 394: move-object/from16 v17, v12
    .line 396: int-to-long v11, v0
    .line 397: move-object/from16 v0, v16
    .line 399: int-to-long v13, v14
    .line 400: move-object/from16 v21, v15
    .line 402: move-wide v14, v13
    .line 403: move-object v13, v0
    .line 404: move-object/from16 v0, v20
    .line 406: move-object/from16 v22, v13
    .line 408: move-object/from16 v13, v21
    .line 410: move-object/from16 v16, v22
    .line 412: invoke-direct/range {v0 .. v19}, Lai/onnxruntime/OrtTrainingSession;->evalStep(JJJJ[Ljava/lang/String;[JJ[Ljava/lang/String;J[Lai/onnxruntime/OnnxValue;[JJ)[Z
    .line 415: move-result-object v0
    .line 416: new-instance v1, Lai/onnxruntime/OrtSession$Result;
    .line 418: move-object/from16 v2, v21
    .line 420: move-object/from16 v3, v22
    .line 422: invoke-direct {v1, v2, v3, v0}, Lai/onnxruntime/OrtSession$Result;-><init>([Ljava/lang/String;[Lai/onnxruntime/OnnxValue;[Z)V
    .line 425: return-object v1
    .line 426: new-instance v2, Lai/onnxruntime/OrtException;
    .line 428: const-string v4, "Unexpected number of requestedOutputs & pinnedOutputs, expected [1,"
    .line 430: invoke-static {v4, v0, v1, v3}, Lai/onnxruntime/b;->h(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;
    .line 433: move-result-object v0
    .line 434: invoke-direct {v2, v0}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 437: throw v2
    .line 438: new-instance v0, Lai/onnxruntime/OrtException;
    .line 440: new-instance v2, Ljava/lang/StringBuilder;
    .line 442: const-string v3, "Unexpected number of inputs, expected [1,"
    .line 444: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 447: move-object/from16 v3, v20
    .line 449: iget-object v4, v3, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 451: invoke-interface {v4}, Ljava/util/Set;->size()I
    .line 454: move-result v4
    .line 455: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 458: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 461: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 464: move-result v1
    .line 465: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 468: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 471: move-result-object v1
    .line 472: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 475: throw v0
.end method

# virtual methods
.method public exportModelForInference(Ljava/nio/file/Path;[Ljava/lang/String;)V
    .registers 15

    .line 0: invoke-direct {v12}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: array-length v0, v14
    .line 4: if-eqz v0, :cond_24
    .line 6: invoke-static {v13}, Lai/onnxruntime/a;->j(Ljava/nio/file/Path;)Ljava/lang/String;
    .line 9: move-result-object v8
    .line 10: sget-wide v2, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 12: sget-wide v4, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 14: iget-wide v6, v12, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 16: array-length v13, v14
    .line 17: int-to-long v9, v13
    .line 18: move-object v1, v12
    .line 19: move-object v11, v14
    .line 20: invoke-direct/range {v1 .. v11}, Lai/onnxruntime/OrtTrainingSession;->exportModelForInference(JJJLjava/lang/String;J[Ljava/lang/String;)V
    .line 23: return-void
    .line 24: new-instance v13, Ljava/lang/IllegalArgumentException;
    .line 26: const-string v14, "Requires at least one output name"
    .line 28: invoke-direct {v13, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 31: throw v13
.end method

# virtual methods
.method public getEvalInputNames()Ljava/util/Set;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 2: return-object v0
.end method

# virtual methods
.method public getEvalOutputNames()Ljava/util/Set;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->evalOutputNames:Ljava/util/Set;
    .line 2: return-object v0
.end method

# virtual methods
.method public getFloatProperty(Ljava/lang/String;)F
    .registers 4

    .line 0: iget-object v0, v2, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: iget-object v1, v2, Lai/onnxruntime/OrtTrainingSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 4: invoke-virtual {v0, v1, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->getFloatProperty(Lai/onnxruntime/OrtAllocator;Ljava/lang/String;)F
    .line 7: move-result v3
    .line 8: return v3
.end method

# virtual methods
.method public getIntProperty(Ljava/lang/String;)I
    .registers 4

    .line 0: iget-object v0, v2, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: iget-object v1, v2, Lai/onnxruntime/OrtTrainingSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 4: invoke-virtual {v0, v1, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->getIntProperty(Lai/onnxruntime/OrtAllocator;Ljava/lang/String;)I
    .line 7: move-result v3
    .line 8: return v3
.end method

# virtual methods
.method public getLearningRate()F
    .registers 8

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v7, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 9: move-object v0, v7
    .line 10: invoke-direct/range {v0 .. v6}, Lai/onnxruntime/OrtTrainingSession;->getLearningRate(JJJ)F
    .line 13: move-result v0
    .line 14: return v0
.end method

# virtual methods
.method public getStringProperty(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 0: iget-object v0, v2, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 2: iget-object v1, v2, Lai/onnxruntime/OrtTrainingSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 4: invoke-virtual {v0, v1, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->getStringProperty(Lai/onnxruntime/OrtAllocator;Ljava/lang/String;)Ljava/lang/String;
    .line 7: move-result-object v3
    .line 8: return-object v3
.end method

# virtual methods
.method public getTrainInputNames()Ljava/util/Set;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 2: return-object v0
.end method

# virtual methods
.method public getTrainOutputNames()Ljava/util/Set;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 2: return-object v0
.end method

# virtual methods
.method public lazyResetGrad()V
    .registers 8

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v7, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 9: move-object v0, v7
    .line 10: invoke-direct/range {v0 .. v6}, Lai/onnxruntime/OrtTrainingSession;->lazyResetGrad(JJJ)V
    .line 13: return-void
.end method

# virtual methods
.method public optimizerStep()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Lai/onnxruntime/OrtTrainingSession;->optimizerStep(Lai/onnxruntime/OrtSession$RunOptions;)V
    .line 4: return-void
.end method

# virtual methods
.method public optimizerStep(Lai/onnxruntime/OrtSession$RunOptions;)V
    .registers 13

    .line 0: invoke-direct {v11}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: if-nez v12, :cond_9
    .line 5: const-wide/16 v0, 0
    .line 7: move-wide v9, v0
    .line 8: goto :goto_14
    .line 9: invoke-virtual {v12}, Lai/onnxruntime/OrtSession$RunOptions;->getNativeHandle()J
    .line 12: move-result-wide v0
    .line 13: goto :goto_7
    .line 14: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 16: sget-wide v5, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 18: iget-wide v7, v11, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 20: move-object v2, v11
    .line 21: invoke-direct/range {v2 .. v10}, Lai/onnxruntime/OrtTrainingSession;->optimizerStep(JJJJ)V
    .line 24: return-void
.end method

# virtual methods
.method public registerLinearLRScheduler(JJF)V
    .registers 19

    .line 0: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 2: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 4: move-object v12, v13
    .line 5: iget-wide v5, v12, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 7: move-object v0, v13
    .line 8: move-wide v7, v14
    .line 9: move-wide/from16 v9, v16
    .line 11: move/from16 v11, v18
    .line 13: invoke-direct/range {v0 .. v11}, Lai/onnxruntime/OrtTrainingSession;->registerLinearLRScheduler(JJJJJF)V
    .line 16: return-void
.end method

# virtual methods
.method public saveCheckpoint(Ljava/nio/file/Path;Z)V
    .registers 4

    .line 0: invoke-direct {v1}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: iget-object v0, v1, Lai/onnxruntime/OrtTrainingSession;->checkpoint:Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;
    .line 5: invoke-virtual {v0, v2, v3}, Lai/onnxruntime/OrtTrainingSession$OrtCheckpointState;->saveCheckpoint(Ljava/nio/file/Path;Z)V
    .line 8: return-void
.end method

# virtual methods
.method public schedulerStep()V
    .registers 8

    .line 0: invoke-direct {v7}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v7, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 9: move-object v0, v7
    .line 10: invoke-direct/range {v0 .. v6}, Lai/onnxruntime/OrtTrainingSession;->schedulerStep(JJJ)V
    .line 13: return-void
.end method

# virtual methods
.method public setLearningRate(F)V
    .registers 10

    .line 0: invoke-direct {v8}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 3: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 5: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 7: iget-wide v5, v8, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 9: move-object v0, v8
    .line 10: move v7, v9
    .line 11: invoke-direct/range {v0 .. v7}, Lai/onnxruntime/OrtTrainingSession;->setLearningRate(JJJF)V
    .line 14: return-void
.end method

# virtual methods
.method public trainStep(Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: iget-object v0, v3, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 2: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 5: move-result-object v1
    .line 6: const/4 v2, 0
    .line 7: invoke-virtual {v3, v4, v0, v1, v2}, Lai/onnxruntime/OrtTrainingSession;->trainStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 10: move-result-object v4
    .line 11: return-object v4
.end method

# virtual methods
.method public trainStep(Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: iget-object v0, v2, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 2: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v2, v3, v0, v1, v4}, Lai/onnxruntime/OrtTrainingSession;->trainStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 9: move-result-object v3
    .line 10: return-object v3
.end method

# virtual methods
.method public trainStep(Ljava/util/Map;Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: invoke-virtual {v2, v3, v0, v4, v1}, Lai/onnxruntime/OrtTrainingSession;->trainStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 8: move-result-object v3
    .line 9: return-object v3
.end method

# virtual methods
.method public trainStep(Ljava/util/Map;Ljava/util/Set;)Lai/onnxruntime/OrtSession$Result;
    .registers 5

    .line 0: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: invoke-virtual {v2, v3, v4, v0, v1}, Lai/onnxruntime/OrtTrainingSession;->trainStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .line 8: move-result-object v3
    .line 9: return-object v3
.end method

# virtual methods
.method public trainStep(Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lai/onnxruntime/OrtSession$RunOptions;)Lai/onnxruntime/OrtSession$Result;
    .registers 25

    .line 0: move-object/from16 v13, v20
    .line 2: invoke-direct/range {v20 .. v20}, Lai/onnxruntime/OrtTrainingSession;->checkClosed()V
    .line 5: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->isEmpty()Z
    .line 8: move-result v0
    .line 9: const-string v1, ") found "
    .line 11: if-eqz v0, :cond_21
    .line 13: iget-object v0, v13, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 15: invoke-interface {v0}, Ljava/util/Set;->size()I
    .line 18: move-result v0
    .line 19: if-nez v0, :cond_434
    .line 21: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 24: move-result v0
    .line 25: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 27: invoke-interface {v2}, Ljava/util/Set;->size()I
    .line 30: move-result v2
    .line 31: if-gt v0, v2, :cond_434
    .line 33: iget-object v0, v13, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 35: invoke-interface {v0}, Ljava/util/Set;->size()I
    .line 38: move-result v0
    .line 39: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->size()I
    .line 42: move-result v2
    .line 43: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->size()I
    .line 46: move-result v3
    .line 47: add-int/2addr v3, v2
    .line 48: if-eqz v3, :cond_422
    .line 50: if-gt v3, v0, :cond_422
    .line 52: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 55: move-result v0
    .line 56: new-array v9, v0, [Ljava/lang/String;
    .line 58: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 61: move-result v1
    .line 62: new-array v10, v1, [J
    .line 64: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 67: move-result-object v1
    .line 68: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 71: move-result-object v1
    .line 72: const/4 v2, 0
    .line 73: move v3, v2
    .line 74: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 77: move-result v4
    .line 78: const-string v5, ", expected one of "
    .line 80: if-eqz v4, :cond_157
    .line 82: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 85: move-result-object v4
    .line 86: check-cast v4, Ljava/util/Map$Entry;
    .line 88: iget-object v6, v13, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 90: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 93: move-result-object v7
    .line 94: invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 97: move-result v6
    .line 98: if-eqz v6, :cond_123
    .line 100: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 103: move-result-object v5
    .line 104: check-cast v5, Ljava/lang/String;
    .line 106: aput-object v5, v9, v3
    .line 108: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 111: move-result-object v4
    .line 112: check-cast v4, Lai/onnxruntime/OnnxTensorLike;
    .line 114: invoke-virtual {v4}, Lai/onnxruntime/OnnxTensorLike;->getNativeHandle()J
    .line 117: move-result-wide v4
    .line 118: aput-wide v4, v10, v3
    .line 120: add-int/lit8 v3, v3, 1
    .line 122: goto :goto_74
    .line 123: new-instance v0, Lai/onnxruntime/OrtException;
    .line 125: new-instance v1, Ljava/lang/StringBuilder;
    .line 127: const-string v2, "Unknown input name "
    .line 129: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 132: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 135: move-result-object v2
    .line 136: check-cast v2, Ljava/lang/String;
    .line 138: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 141: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 144: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 146: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 149: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 152: move-result-object v1
    .line 153: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 156: throw v0
    .line 157: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->size()I
    .line 160: move-result v1
    .line 161: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->size()I
    .line 164: move-result v3
    .line 165: add-int v14, v3, v1
    .line 167: new-array v15, v14, [Ljava/lang/String;
    .line 169: new-array v11, v14, [Lai/onnxruntime/OnnxValue;
    .line 171: new-array v12, v14, [J
    .line 173: invoke-interface/range {v23 .. v23}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 176: move-result-object v1
    .line 177: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 180: move-result-object v1
    .line 181: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 184: move-result v3
    .line 185: const-string v4, "Unknown output name "
    .line 187: if-eqz v3, :cond_274
    .line 189: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 192: move-result-object v3
    .line 193: check-cast v3, Ljava/util/Map$Entry;
    .line 195: iget-object v6, v13, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 197: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 200: move-result-object v7
    .line 201: invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 204: move-result v6
    .line 205: if-eqz v6, :cond_238
    .line 207: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 210: move-result-object v4
    .line 211: check-cast v4, Ljava/lang/String;
    .line 213: aput-object v4, v15, v2
    .line 215: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 218: move-result-object v4
    .line 219: check-cast v4, Lai/onnxruntime/OnnxValue;
    .line 221: aput-object v4, v11, v2
    .line 223: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 226: move-result-object v3
    .line 227: check-cast v3, Lai/onnxruntime/OnnxValue;
    .line 229: invoke-static {v3}, Lai/onnxruntime/OrtSession;->getHandle(Lai/onnxruntime/OnnxValue;)J
    .line 232: move-result-wide v3
    .line 233: aput-wide v3, v12, v2
    .line 235: add-int/lit8 v2, v2, 1
    .line 237: goto :goto_181
    .line 238: new-instance v0, Lai/onnxruntime/OrtException;
    .line 240: new-instance v1, Ljava/lang/StringBuilder;
    .line 242: invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 245: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 248: move-result-object v2
    .line 249: check-cast v2, Ljava/lang/String;
    .line 251: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 254: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 257: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 259: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 262: move-result-object v2
    .line 263: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 266: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 269: move-result-object v1
    .line 270: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 273: throw v0
    .line 274: invoke-interface/range {v22 .. v22}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 277: move-result-object v1
    .line 278: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 281: move-result v3
    .line 282: if-eqz v3, :cond_366
    .line 284: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 287: move-result-object v3
    .line 288: check-cast v3, Ljava/lang/String;
    .line 290: iget-object v6, v13, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 292: invoke-interface {v6, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 295: move-result v6
    .line 296: if-eqz v6, :cond_336
    .line 298: move-object/from16 v6, v23
    .line 300: invoke-interface {v6, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 303: move-result v7
    .line 304: if-nez v7, :cond_311
    .line 306: aput-object v3, v15, v2
    .line 308: add-int/lit8 v2, v2, 1
    .line 310: goto :goto_278
    .line 311: new-instance v0, Lai/onnxruntime/OrtException;
    .line 313: new-instance v1, Ljava/lang/StringBuilder;
    .line 315: const-string v2, "Output '"
    .line 317: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 320: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 323: const-string v2, "' was found in both the requested outputs and the pinned outputs"
    .line 325: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 328: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 331: move-result-object v1
    .line 332: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 335: throw v0
    .line 336: new-instance v0, Lai/onnxruntime/OrtException;
    .line 338: new-instance v1, Ljava/lang/StringBuilder;
    .line 340: invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 343: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 346: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 349: iget-object v2, v13, Lai/onnxruntime/OrtTrainingSession;->trainOutputNames:Ljava/util/Set;
    .line 351: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 354: move-result-object v2
    .line 355: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 358: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 361: move-result-object v1
    .line 362: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 365: throw v0
    .line 366: if-nez v24, :cond_373
    .line 368: const-wide/16 v1, 0
    .line 370: move-wide/from16 v18, v1
    .line 372: goto :goto_378
    .line 373: invoke-virtual/range {v24 .. v24}, Lai/onnxruntime/OrtSession$RunOptions;->getNativeHandle()J
    .line 376: move-result-wide v1
    .line 377: goto :goto_370
    .line 378: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 380: sget-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 382: iget-wide v5, v13, Lai/onnxruntime/OrtTrainingSession;->nativeHandle:J
    .line 384: iget-object v7, v13, Lai/onnxruntime/OrtTrainingSession;->allocator:Lai/onnxruntime/OrtAllocator;
    .line 386: iget-wide v7, v7, Lai/onnxruntime/OrtAllocator;->handle:J
    .line 388: move-object/from16 v16, v11
    .line 390: move-object/from16 v17, v12
    .line 392: int-to-long v11, v0
    .line 393: move-object/from16 v0, v16
    .line 395: int-to-long v13, v14
    .line 396: move-object/from16 v21, v15
    .line 398: move-wide v14, v13
    .line 399: move-object v13, v0
    .line 400: move-object/from16 v0, v20
    .line 402: move-object/from16 v22, v13
    .line 404: move-object/from16 v13, v21
    .line 406: move-object/from16 v16, v22
    .line 408: invoke-direct/range {v0 .. v19}, Lai/onnxruntime/OrtTrainingSession;->trainStep(JJJJ[Ljava/lang/String;[JJ[Ljava/lang/String;J[Lai/onnxruntime/OnnxValue;[JJ)[Z
    .line 411: move-result-object v0
    .line 412: new-instance v1, Lai/onnxruntime/OrtSession$Result;
    .line 414: move-object/from16 v2, v21
    .line 416: move-object/from16 v3, v22
    .line 418: invoke-direct {v1, v2, v3, v0}, Lai/onnxruntime/OrtSession$Result;-><init>([Ljava/lang/String;[Lai/onnxruntime/OnnxValue;[Z)V
    .line 421: return-object v1
    .line 422: new-instance v2, Lai/onnxruntime/OrtException;
    .line 424: const-string v4, "Unexpected number of requestedOutputs & pinnedOutputs, expected [1,"
    .line 426: invoke-static {v4, v0, v1, v3}, Lai/onnxruntime/b;->h(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;
    .line 429: move-result-object v0
    .line 430: invoke-direct {v2, v0}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 433: throw v2
    .line 434: new-instance v0, Lai/onnxruntime/OrtException;
    .line 436: new-instance v2, Ljava/lang/StringBuilder;
    .line 438: const-string v3, "Unexpected number of inputs, expected [1,"
    .line 440: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 443: move-object/from16 v3, v20
    .line 445: iget-object v4, v3, Lai/onnxruntime/OrtTrainingSession;->trainInputNames:Ljava/util/Set;
    .line 447: invoke-interface {v4}, Ljava/util/Set;->size()I
    .line 450: move-result v4
    .line 451: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 454: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 457: invoke-interface/range {v21 .. v21}, Ljava/util/Map;->size()I
    .line 460: move-result v1
    .line 461: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 464: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 467: move-result-object v1
    .line 468: invoke-direct {v0, v1}, Lai/onnxruntime/OrtException;-><init>(Ljava/lang/String;)V
    .line 471: throw v0
.end method

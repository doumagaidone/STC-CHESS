.class synthetic Lai/onnxruntime/OnnxSparseTensor$1;
.super Ljava/lang/Object;
.source "SourceFile"

.field static final synthetic $SwitchMap$ai$onnxruntime$OnnxJavaType:[I
.field static final synthetic $SwitchMap$ai$onnxruntime$OnnxSparseTensor$SparseTensorType:[I

# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxJavaType;->values()[Lai/onnxruntime/OnnxJavaType;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 9: const/4 v1, 1
    .line 10: sget-object v2, Lai/onnxruntime/OnnxJavaType;->FLOAT:Lai/onnxruntime/OnnxJavaType;
    .line 12: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 15: move-result v2
    .line 16: aput v1, v0, v2
    .line 18: const/4 v0, 2
    .line 19: sget-object v2, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 21: sget-object v3, Lai/onnxruntime/OnnxJavaType;->FLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 23: invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I
    .line 26: move-result v3
    .line 27: aput v0, v2, v3
    .line 29: const/4 v2, 3
    .line 30: sget-object v3, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 32: sget-object v4, Lai/onnxruntime/OnnxJavaType;->BFLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 34: invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I
    .line 37: move-result v4
    .line 38: aput v2, v3, v4
    .line 40: const/4 v3, 4
    .line 41: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 43: sget-object v5, Lai/onnxruntime/OnnxJavaType;->DOUBLE:Lai/onnxruntime/OnnxJavaType;
    .line 45: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 48: move-result v5
    .line 49: aput v3, v4, v5
    .line 51: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 53: sget-object v5, Lai/onnxruntime/OnnxJavaType;->INT16:Lai/onnxruntime/OnnxJavaType;
    .line 55: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 58: move-result v5
    .line 59: const/4 v6, 5
    .line 60: aput v6, v4, v5
    .line 62: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 64: sget-object v5, Lai/onnxruntime/OnnxJavaType;->INT32:Lai/onnxruntime/OnnxJavaType;
    .line 66: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 69: move-result v5
    .line 70: const/4 v6, 6
    .line 71: aput v6, v4, v5
    .line 73: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 75: sget-object v5, Lai/onnxruntime/OnnxJavaType;->INT64:Lai/onnxruntime/OnnxJavaType;
    .line 77: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 80: move-result v5
    .line 81: const/4 v6, 7
    .line 82: aput v6, v4, v5
    .line 84: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 86: sget-object v5, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 88: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 91: move-result v5
    .line 92: const/16 v6, 8
    .line 94: aput v6, v4, v5
    .line 96: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 98: sget-object v5, Lai/onnxruntime/OnnxJavaType;->INT8:Lai/onnxruntime/OnnxJavaType;
    .line 100: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 103: move-result v5
    .line 104: const/16 v6, 9
    .line 106: aput v6, v4, v5
    .line 108: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 110: sget-object v5, Lai/onnxruntime/OnnxJavaType;->UINT8:Lai/onnxruntime/OnnxJavaType;
    .line 112: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 115: move-result v5
    .line 116: const/16 v6, 10
    .line 118: aput v6, v4, v5
    .line 120: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 122: sget-object v5, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 124: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 127: move-result v5
    .line 128: const/16 v6, 11
    .line 130: aput v6, v4, v5
    .line 132: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxJavaType:[I
    .line 134: sget-object v5, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 136: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 139: move-result v5
    .line 140: const/16 v6, 12
    .line 142: aput v6, v4, v5
    .line 144: invoke-static {}, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->values()[Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 147: move-result-object v4
    .line 148: array-length v4, v4
    .line 149: new-array v4, v4, [I
    .line 151: sput-object v4, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxSparseTensor$SparseTensorType:[I
    .line 153: sget-object v5, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->COO:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 155: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 158: move-result v5
    .line 159: aput v1, v4, v5
    .line 161: sget-object v1, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxSparseTensor$SparseTensorType:[I
    .line 163: sget-object v4, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->BLOCK_SPARSE:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 165: invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I
    .line 168: move-result v4
    .line 169: aput v0, v1, v4
    .line 171: sget-object v0, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxSparseTensor$SparseTensorType:[I
    .line 173: sget-object v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->CSRC:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 175: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 178: move-result v1
    .line 179: aput v2, v0, v1
    .line 181: sget-object v0, Lai/onnxruntime/OnnxSparseTensor$1;->$SwitchMap$ai$onnxruntime$OnnxSparseTensor$SparseTensorType:[I
    .line 183: sget-object v1, Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;->UNDEFINED:Lai/onnxruntime/OnnxSparseTensor$SparseTensorType;
    .line 185: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 188: move-result v1
    .line 189: aput v3, v0, v1
    .line 191: return-void
.end method

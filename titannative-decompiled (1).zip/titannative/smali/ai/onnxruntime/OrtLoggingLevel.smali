.class public final enum Lai/onnxruntime/OrtLoggingLevel;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OrtLoggingLevel;
.field public static final enum ORT_LOGGING_LEVEL_ERROR:Lai/onnxruntime/OrtLoggingLevel;
.field public static final enum ORT_LOGGING_LEVEL_FATAL:Lai/onnxruntime/OrtLoggingLevel;
.field public static final enum ORT_LOGGING_LEVEL_INFO:Lai/onnxruntime/OrtLoggingLevel;
.field public static final enum ORT_LOGGING_LEVEL_VERBOSE:Lai/onnxruntime/OrtLoggingLevel;
.field public static final enum ORT_LOGGING_LEVEL_WARNING:Lai/onnxruntime/OrtLoggingLevel;
.field private static final logger:Ljava/util/logging/Logger;
.field private static final values:[Lai/onnxruntime/OrtLoggingLevel;

.field private final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 8

    .line 0: new-instance v0, Lai/onnxruntime/OrtLoggingLevel;
    .line 2: const-string v1, "ORT_LOGGING_LEVEL_VERBOSE"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/OrtLoggingLevel;-><init>(Ljava/lang/String;II)V
    .line 8: sput-object v0, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_VERBOSE:Lai/onnxruntime/OrtLoggingLevel;
    .line 10: new-instance v1, Lai/onnxruntime/OrtLoggingLevel;
    .line 12: const-string v3, "ORT_LOGGING_LEVEL_INFO"
    .line 14: const/4 v4, 1
    .line 15: invoke-direct {v1, v3, v4, v4}, Lai/onnxruntime/OrtLoggingLevel;-><init>(Ljava/lang/String;II)V
    .line 18: sput-object v1, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_INFO:Lai/onnxruntime/OrtLoggingLevel;
    .line 20: new-instance v3, Lai/onnxruntime/OrtLoggingLevel;
    .line 22: const-string v4, "ORT_LOGGING_LEVEL_WARNING"
    .line 24: const/4 v5, 2
    .line 25: invoke-direct {v3, v4, v5, v5}, Lai/onnxruntime/OrtLoggingLevel;-><init>(Ljava/lang/String;II)V
    .line 28: sput-object v3, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_WARNING:Lai/onnxruntime/OrtLoggingLevel;
    .line 30: new-instance v4, Lai/onnxruntime/OrtLoggingLevel;
    .line 32: const-string v5, "ORT_LOGGING_LEVEL_ERROR"
    .line 34: const/4 v6, 3
    .line 35: invoke-direct {v4, v5, v6, v6}, Lai/onnxruntime/OrtLoggingLevel;-><init>(Ljava/lang/String;II)V
    .line 38: sput-object v4, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_ERROR:Lai/onnxruntime/OrtLoggingLevel;
    .line 40: new-instance v5, Lai/onnxruntime/OrtLoggingLevel;
    .line 42: const-string v6, "ORT_LOGGING_LEVEL_FATAL"
    .line 44: const/4 v7, 4
    .line 45: invoke-direct {v5, v6, v7, v7}, Lai/onnxruntime/OrtLoggingLevel;-><init>(Ljava/lang/String;II)V
    .line 48: sput-object v5, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_FATAL:Lai/onnxruntime/OrtLoggingLevel;
    .line 50: filled-new-array {v0, v1, v3, v4, v5}, [Lai/onnxruntime/OrtLoggingLevel;
    .line 53: move-result-object v0
    .line 54: sput-object v0, Lai/onnxruntime/OrtLoggingLevel;->$VALUES:[Lai/onnxruntime/OrtLoggingLevel;
    .line 56: const-class v0, Lai/onnxruntime/OrtLoggingLevel;
    .line 58: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 61: move-result-object v0
    .line 62: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 65: move-result-object v0
    .line 66: sput-object v0, Lai/onnxruntime/OrtLoggingLevel;->logger:Ljava/util/logging/Logger;
    .line 68: const/4 v0, 5
    .line 69: new-array v0, v0, [Lai/onnxruntime/OrtLoggingLevel;
    .line 71: sput-object v0, Lai/onnxruntime/OrtLoggingLevel;->values:[Lai/onnxruntime/OrtLoggingLevel;
    .line 73: invoke-static {}, Lai/onnxruntime/OrtLoggingLevel;->values()[Lai/onnxruntime/OrtLoggingLevel;
    .line 76: move-result-object v0
    .line 77: array-length v1, v0
    .line 78: if-ge v2, v1, :cond_91
    .line 80: aget-object v3, v0, v2
    .line 82: sget-object v4, Lai/onnxruntime/OrtLoggingLevel;->values:[Lai/onnxruntime/OrtLoggingLevel;
    .line 84: iget v5, v3, Lai/onnxruntime/OrtLoggingLevel;->value:I
    .line 86: aput-object v3, v4, v5
    .line 88: add-int/lit8 v2, v2, 1
    .line 90: goto :goto_78
    .line 91: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OrtLoggingLevel;->value:I
    .line 5: return-void
.end method

# direct methods
.method public static mapFromInt(I)Lai/onnxruntime/OrtLoggingLevel;
    .registers 4

    .line 0: if-lez v3, :cond_10
    .line 2: sget-object v0, Lai/onnxruntime/OrtLoggingLevel;->values:[Lai/onnxruntime/OrtLoggingLevel;
    .line 4: array-length v1, v0
    .line 5: if-ge v3, v1, :cond_10
    .line 7: aget-object v3, v0, v3
    .line 9: return-object v3
    .line 10: sget-object v0, Lai/onnxruntime/OrtLoggingLevel;->logger:Ljava/util/logging/Logger;
    .line 12: new-instance v1, Ljava/lang/StringBuilder;
    .line 14: const-string v2, "Unknown logging level "
    .line 16: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 19: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v3, " setting to ORT_LOGGING_LEVEL_VERBOSE"
    .line 24: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 30: move-result-object v3
    .line 31: invoke-virtual {v0, v3}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V
    .line 34: sget-object v3, Lai/onnxruntime/OrtLoggingLevel;->ORT_LOGGING_LEVEL_VERBOSE:Lai/onnxruntime/OrtLoggingLevel;
    .line 36: return-object v3
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OrtLoggingLevel;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OrtLoggingLevel;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OrtLoggingLevel;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OrtLoggingLevel;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OrtLoggingLevel;->$VALUES:[Lai/onnxruntime/OrtLoggingLevel;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OrtLoggingLevel;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OrtLoggingLevel;
    .line 8: return-object v0
.end method

# virtual methods
.method public getValue()I
    .registers 2

    .line 0: iget v0, v1, Lai/onnxruntime/OrtLoggingLevel;->value:I
    .line 2: return v0
.end method

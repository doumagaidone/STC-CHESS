.class public abstract interface Lai/onnxruntime/OrtProviderOptions$OrtProviderSupplier;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract create()J
.end method

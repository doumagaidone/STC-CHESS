.class public Lai/onnxruntime/OrtSession$Result;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/AutoCloseable;
.implements Ljava/lang/Iterable;

.field private static final logger:Ljava/util/logging/Logger;

.field private closed:Z
.field private final list:Ljava/util/List;
.field private final map:Ljava/util/Map;
.field private final ownedByResult:[Z

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-class v0, Lai/onnxruntime/OrtSession$Result;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/OrtSession$Result;->logger:Ljava/util/logging/Logger;
    .line 12: return-void
.end method

# direct methods
.method public constructor <init>([Ljava/lang/String;[Lai/onnxruntime/OnnxValue;[Z)V
    .registers 8

    .line 0: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 3: array-length v0, v5
    .line 4: array-length v1, v6
    .line 5: if-ne v0, v1, :cond_56
    .line 7: array-length v0, v5
    .line 8: array-length v1, v7
    .line 9: if-ne v0, v1, :cond_56
    .line 11: new-instance v0, Ljava/util/LinkedHashMap;
    .line 13: array-length v1, v5
    .line 14: invoke-static {v1}, Lai/onnxruntime/OrtUtil;->capacityFromSize(I)I
    .line 17: move-result v1
    .line 18: invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V
    .line 21: iput-object v0, v4, Lai/onnxruntime/OrtSession$Result;->map:Ljava/util/Map;
    .line 23: new-instance v0, Ljava/util/ArrayList;
    .line 25: invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 28: move-result-object v1
    .line 29: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 32: iput-object v0, v4, Lai/onnxruntime/OrtSession$Result;->list:Ljava/util/List;
    .line 34: iput-object v7, v4, Lai/onnxruntime/OrtSession$Result;->ownedByResult:[Z
    .line 36: const/4 v7, 0
    .line 37: move v0, v7
    .line 38: array-length v1, v5
    .line 39: if-ge v0, v1, :cond_53
    .line 41: iget-object v1, v4, Lai/onnxruntime/OrtSession$Result;->map:Ljava/util/Map;
    .line 43: aget-object v2, v5, v0
    .line 45: aget-object v3, v6, v0
    .line 47: invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 50: add-int/lit8 v0, v0, 1
    .line 52: goto :goto_38
    .line 53: iput-boolean v7, v4, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 55: return-void
    .line 56: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 58: new-instance v1, Ljava/lang/StringBuilder;
    .line 60: const-string v2, "Expected same number of names, values and ownedByResult, found names.length = "
    .line 62: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 65: array-length v5, v5
    .line 66: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 69: const-string v5, ", values.length = "
    .line 71: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 74: array-length v5, v6
    .line 75: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 78: const-string v5, ", ownedByResult.length = "
    .line 80: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 83: array-length v5, v7
    .line 84: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 87: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 90: move-result-object v5
    .line 91: invoke-direct {v0, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 94: throw v0
.end method

# virtual methods
.method public close()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 2: if-nez v0, :cond_36
    .line 4: const/4 v0, 1
    .line 5: iput-boolean v0, v2, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 7: const/4 v0, 0
    .line 8: iget-object v1, v2, Lai/onnxruntime/OrtSession$Result;->list:Ljava/util/List;
    .line 10: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 13: move-result v1
    .line 14: if-ge v0, v1, :cond_43
    .line 16: iget-object v1, v2, Lai/onnxruntime/OrtSession$Result;->ownedByResult:[Z
    .line 18: aget-boolean v1, v1, v0
    .line 20: if-eqz v1, :cond_33
    .line 22: iget-object v1, v2, Lai/onnxruntime/OrtSession$Result;->list:Ljava/util/List;
    .line 24: invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 27: move-result-object v1
    .line 28: check-cast v1, Lai/onnxruntime/OnnxValue;
    .line 30: invoke-interface {v1}, Lai/onnxruntime/OnnxValue;->close()V
    .line 33: add-int/lit8 v0, v0, 1
    .line 35: goto :goto_8
    .line 36: sget-object v0, Lai/onnxruntime/OrtSession$Result;->logger:Ljava/util/logging/Logger;
    .line 38: const-string v1, "Closing an already closed Result"
    .line 40: invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V
    .line 43: return-void
.end method

# virtual methods
.method public get(I)Lai/onnxruntime/OnnxValue;
    .registers 3

    .line 0: iget-boolean v0, v1, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 2: if-nez v0, :cond_13
    .line 4: iget-object v0, v1, Lai/onnxruntime/OrtSession$Result;->list:Ljava/util/List;
    .line 6: invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 9: move-result-object v2
    .line 10: check-cast v2, Lai/onnxruntime/OnnxValue;
    .line 12: return-object v2
    .line 13: new-instance v2, Ljava/lang/IllegalStateException;
    .line 15: const-string v0, "Result is closed"
    .line 17: invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 20: throw v2
.end method

# virtual methods
.method public get(Ljava/lang/String;)Ljava/util/Optional;
    .registers 3

    .line 0: iget-boolean v0, v1, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 2: if-nez v0, :cond_24
    .line 4: iget-object v0, v1, Lai/onnxruntime/OrtSession$Result;->map:Ljava/util/Map;
    .line 6: invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v2
    .line 10: check-cast v2, Lai/onnxruntime/OnnxValue;
    .line 12: if-eqz v2, :cond_19
    .line 14: invoke-static {v2}, Ljava/util/Optional;->of(Ljava/lang/Object;)Ljava/util/Optional;
    .line 17: move-result-object v2
    .line 18: return-object v2
    .line 19: invoke-static {}, Ljava/util/Optional;->empty()Ljava/util/Optional;
    .line 22: move-result-object v2
    .line 23: return-object v2
    .line 24: new-instance v2, Ljava/lang/IllegalStateException;
    .line 26: const-string v0, "Result is closed"
    .line 28: invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 31: throw v2
.end method

# virtual methods
.method public isResultOwner(I)Z
    .registers 3

    .line 0: iget-boolean v0, v1, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 2: if-nez v0, :cond_9
    .line 4: iget-object v0, v1, Lai/onnxruntime/OrtSession$Result;->ownedByResult:[Z
    .line 6: aget-boolean v2, v0, v2
    .line 8: return v2
    .line 9: new-instance v2, Ljava/lang/IllegalStateException;
    .line 11: const-string v0, "Result is closed"
    .line 13: invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 16: throw v2
.end method

# virtual methods
.method public iterator()Ljava/util/Iterator;
    .registers 3

    .line 0: iget-boolean v0, v2, Lai/onnxruntime/OrtSession$Result;->closed:Z
    .line 2: if-nez v0, :cond_15
    .line 4: iget-object v0, v2, Lai/onnxruntime/OrtSession$Result;->map:Ljava/util/Map;
    .line 6: invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 9: move-result-object v0
    .line 10: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 13: move-result-object v0
    .line 14: return-object v0
    .line 15: new-instance v0, Ljava/lang/IllegalStateException;
    .line 17: const-string v1, "Result is closed"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# virtual methods
.method public size()I
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtSession$Result;->map:Ljava/util/Map;
    .line 2: invoke-interface {v0}, Ljava/util/Map;->size()I
    .line 5: move-result v0
    .line 6: return v0
.end method

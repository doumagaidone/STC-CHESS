.class final Lai/onnxruntime/OnnxRuntime;
.super Ljava/lang/Object;
.source "SourceFile"

.field static final ONNXRUNTIME_JNI_LIBRARY_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_CUDA_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_DNNL_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_OPENVINO_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_ROCM_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_SHARED_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_LIBRARY_TENSORRT_NAME:Ljava/lang/String;
.field static final ONNXRUNTIME_NATIVE_PATH:Ljava/lang/String;
.field private static final ORT_API_VERSION_1:I
.field private static final ORT_API_VERSION_11:I
.field private static final ORT_API_VERSION_13:I
.field private static final ORT_API_VERSION_14:I
.field private static final ORT_API_VERSION_2:I
.field private static final ORT_API_VERSION_3:I
.field private static final ORT_API_VERSION_7:I
.field private static final ORT_API_VERSION_8:I
.field private static final ORT_TRAINING_API_VERSION_1:I
.field private static final OS_ARCH_STR:Ljava/lang/String;
.field private static final extractedSharedProviders:Ljava/util/Set;
.field private static libraryDirPathProperty:Ljava/lang/String;
.field private static loaded:Z
.field private static final logger:Ljava/util/logging/Logger;
.field static ortApiHandle:J
.field static ortTrainingApiHandle:J
.field static providers:Ljava/util/EnumSet;
.field private static tempDirectory:Ljava/nio/file/Path;
.field static trainingEnabled:Z
.field private static version:Ljava/lang/String;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-class v0, Lai/onnxruntime/OnnxRuntime;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 12: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->initOsArch()Ljava/lang/String;
    .line 15: move-result-object v0
    .line 16: sput-object v0, Lai/onnxruntime/OnnxRuntime;->OS_ARCH_STR:Ljava/lang/String;
    .line 18: const/4 v0, 0
    .line 19: sput-boolean v0, Lai/onnxruntime/OnnxRuntime;->loaded:Z
    .line 21: new-instance v0, Ljava/util/HashSet;
    .line 23: invoke-direct {v0}, Ljava/util/HashSet;-><init>()V
    .line 26: sput-object v0, Lai/onnxruntime/OnnxRuntime;->extractedSharedProviders:Ljava/util/Set;
    .line 28: return-void
.end method

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method private static cleanUp(Ljava/io/File;)V
    .registers 5

    .line 0: invoke-virtual {v4}, Ljava/io/File;->exists()Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-void
    .line 7: sget-object v0, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 9: sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 11: new-instance v2, Ljava/lang/StringBuilder;
    .line 13: const-string v3, "Deleting "
    .line 15: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 18: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 21: const-string v3, " on exit"
    .line 23: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 29: move-result-object v2
    .line 30: invoke-virtual {v0, v1, v2}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 33: invoke-virtual {v4}, Ljava/io/File;->deleteOnExit()V
    .line 36: return-void
.end method

# direct methods
.method public static extractCUDA()Z
    .registers 1

    .line 0: const-string v0, "onnxruntime_providers_cuda"
    .line 2: invoke-static {v0}, Lai/onnxruntime/OnnxRuntime;->extractProviderLibrary(Ljava/lang/String;)Z
    .line 5: move-result v0
    .line 6: return v0
.end method

# direct methods
.method public static extractDNNL()Z
    .registers 1

    .line 0: const-string v0, "onnxruntime_providers_dnnl"
    .line 2: invoke-static {v0}, Lai/onnxruntime/OnnxRuntime;->extractProviderLibrary(Ljava/lang/String;)Z
    .line 5: move-result v0
    .line 6: return v0
.end method

# direct methods
.method private static extractFromResources(Ljava/lang/String;)Ljava/util/Optional;
    .registers 8

    .line 0: const-string v0, "Attempting to load native library '"
    .line 2: invoke-static {v7}, Lai/onnxruntime/OnnxRuntime;->mapLibraryName(Ljava/lang/String;)Ljava/lang/String;
    .line 5: move-result-object v1
    .line 6: new-instance v2, Ljava/lang/StringBuilder;
    .line 8: const-string v3, "/ai/onnxruntime/native/"
    .line 10: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 13: sget-object v3, Lai/onnxruntime/OnnxRuntime;->OS_ARCH_STR:Ljava/lang/String;
    .line 15: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 18: const/16 v3, 47
    .line 20: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 23: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 29: move-result-object v2
    .line 30: sget-object v3, Lai/onnxruntime/OnnxRuntime;->tempDirectory:Ljava/nio/file/Path;
    .line 32: invoke-static {v3, v1}, Lai/onnxruntime/a;->m(Ljava/nio/file/Path;Ljava/lang/String;)Ljava/nio/file/Path;
    .line 35: move-result-object v1
    .line 36: invoke-static {v1}, Lai/onnxruntime/a;->g(Ljava/nio/file/Path;)Ljava/io/File;
    .line 39: move-result-object v1
    .line 40: const-class v3, Lai/onnxruntime/OnnxRuntime;
    .line 42: invoke-virtual {v3, v2}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;
    .line 45: move-result-object v3
    .line 46: if-nez v3, :cond_70
    .line 48: invoke-static {}, Ljava/util/Optional;->empty()Ljava/util/Optional;
    .line 51: move-result-object v0
    .line 52: if-eqz v3, :cond_64
    .line 54: invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    .line 57: goto :goto_64
    .line 58: move-exception v7
    .line 59: goto/16 :goto_228
    .line 61: move-exception v0
    .line 62: goto/16 :goto_191
    .line 64: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->cleanUp(Ljava/io/File;)V
    .line 67: return-object v0
    .line 68: move-exception v0
    .line 69: goto :goto_180
    .line 70: sget-object v4, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 72: sget-object v5, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 74: new-instance v6, Ljava/lang/StringBuilder;
    .line 76: invoke-direct {v6, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 79: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 82: const-string v0, "' from resource path "
    .line 84: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 87: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 90: const-string v0, " copying to "
    .line 92: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 95: invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 98: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 101: move-result-object v0
    .line 102: invoke-virtual {v4, v5, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 105: const/16 v0, 4096
    .line 107: new-array v0, v0, [B
    .line 109: new-instance v2, Ljava/io/FileOutputStream;
    .line 111: invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    .line 114: invoke-virtual {v3, v0}, Ljava/io/InputStream;->read([B)I
    .line 117: move-result v4
    .line 118: const/4 v5, -1
    .line 119: if-eq v4, v5, :cond_128
    .line 121: const/4 v5, 0
    .line 122: invoke-virtual {v2, v0, v5, v4}, Ljava/io/FileOutputStream;->write([BII)V
    .line 125: goto :goto_114
    .line 126: move-exception v0
    .line 127: goto :goto_171
    .line 128: invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    .line 131: sget-object v0, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 133: sget-object v2, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 135: new-instance v4, Ljava/lang/StringBuilder;
    .line 137: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    .line 140: const-string v5, "Extracted native library '"
    .line 142: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 145: invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 148: const-string v5, "' from resource path"
    .line 150: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 153: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 156: move-result-object v4
    .line 157: invoke-virtual {v0, v2, v4}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 160: invoke-static {v1}, Ljava/util/Optional;->of(Ljava/lang/Object;)Ljava/util/Optional;
    .line 163: move-result-object v0
    .line 164: invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    .line 167: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->cleanUp(Ljava/io/File;)V
    .line 170: return-object v0
    .line 171: invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    .line 174: goto :goto_179
    .line 175: move-exception v2
    .line 176: invoke-virtual {v0, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V
    .line 179: throw v0
    .line 180: if-eqz v3, :cond_190
    .line 182: invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    .line 185: goto :goto_190
    .line 186: move-exception v2
    .line 187: invoke-virtual {v0, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V
    .line 190: throw v0
    .line 191: sget-object v2, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 193: sget-object v3, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;
    .line 195: new-instance v4, Ljava/lang/StringBuilder;
    .line 197: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    .line 200: const-string v5, "Failed to extract library '"
    .line 202: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 205: invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 208: const-string v7, "' from the resources"
    .line 210: invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 213: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 216: move-result-object v7
    .line 217: invoke-virtual {v2, v3, v7, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 220: invoke-static {}, Ljava/util/Optional;->empty()Ljava/util/Optional;
    .line 223: move-result-object v7
    .line 224: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->cleanUp(Ljava/io/File;)V
    .line 227: return-object v7
    .line 228: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->cleanUp(Ljava/io/File;)V
    .line 231: throw v7
.end method

# direct methods
.method public static extractOpenVINO()Z
    .registers 1

    .line 0: const-string v0, "onnxruntime_providers_openvino"
    .line 2: invoke-static {v0}, Lai/onnxruntime/OnnxRuntime;->extractProviderLibrary(Ljava/lang/String;)Z
    .line 5: move-result v0
    .line 6: return v0
.end method

# direct methods
.method public static declared-synchronized extractProviderLibrary(Ljava/lang/String;)Z
    .registers 7

    .line 0: const-class v0, Lai/onnxruntime/OnnxRuntime;
    .line 2: monitor-enter v0
    .line 3: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->isAndroid()Z
    .line 6: move-result v1
    .line 7: const/4 v2, 0
    .line 8: if-eqz v1, :cond_12
    .line 10: monitor-exit v0
    .line 11: return v2
    .line 12: sget-object v1, Lai/onnxruntime/OnnxRuntime;->extractedSharedProviders:Ljava/util/Set;
    .line 14: invoke-interface {v1, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 17: move-result v3
    .line 18: const/4 v4, 1
    .line 19: if-eqz v3, :cond_23
    .line 21: monitor-exit v0
    .line 22: return v4
    .line 23: invoke-static {v6}, Lai/onnxruntime/OnnxRuntime;->extractFromResources(Ljava/lang/String;)Ljava/util/Optional;
    .line 26: move-result-object v3
    .line 27: invoke-virtual {v3}, Ljava/util/Optional;->isPresent()Z
    .line 30: move-result v3
    .line 31: if-eqz v3, :cond_40
    .line 33: invoke-interface {v1, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    .line 36: monitor-exit v0
    .line 37: return v4
    .line 38: move-exception v6
    .line 39: goto :goto_77
    .line 40: sget-object v3, Lai/onnxruntime/OnnxRuntime;->libraryDirPathProperty:Ljava/lang/String;
    .line 42: if-eqz v3, :cond_75
    .line 44: invoke-static {v6}, Lai/onnxruntime/OnnxRuntime;->mapLibraryName(Ljava/lang/String;)Ljava/lang/String;
    .line 47: move-result-object v3
    .line 48: sget-object v5, Lai/onnxruntime/OnnxRuntime;->libraryDirPathProperty:Ljava/lang/String;
    .line 50: filled-new-array {v3}, [Ljava/lang/String;
    .line 53: move-result-object v3
    .line 54: invoke-static {v5, v3}, Lai/onnxruntime/a;->l(Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;
    .line 57: move-result-object v3
    .line 58: invoke-static {v3}, Lai/onnxruntime/a;->g(Ljava/nio/file/Path;)Ljava/io/File;
    .line 61: move-result-object v3
    .line 62: invoke-virtual {v3}, Ljava/io/File;->exists()Z
    .line 65: move-result v3
    .line 66: if-eqz v3, :cond_73
    .line 68: invoke-interface {v1, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    .line 71: monitor-exit v0
    .line 72: return v4
    .line 73: monitor-exit v0
    .line 74: return v2
    .line 75: monitor-exit v0
    .line 76: return v2
    .line 77: monitor-exit v0
    .line 78: throw v6
.end method

# direct methods
.method public static extractROCM()Z
    .registers 1

    .line 0: const-string v0, "onnxruntime_providers_rocm"
    .line 2: invoke-static {v0}, Lai/onnxruntime/OnnxRuntime;->extractProviderLibrary(Ljava/lang/String;)Z
    .line 5: move-result v0
    .line 6: return v0
.end method

# direct methods
.method public static extractTensorRT()Z
    .registers 1

    .line 0: const-string v0, "onnxruntime_providers_tensorrt"
    .line 2: invoke-static {v0}, Lai/onnxruntime/OnnxRuntime;->extractProviderLibrary(Ljava/lang/String;)Z
    .line 5: move-result v0
    .line 6: return v0
.end method

# direct methods
.method private static native getAvailableProviders(J)[Ljava/lang/String;
.end method

# direct methods
.method public static declared-synchronized init()V
    .registers 8

    .line 0: const-class v0, Lai/onnxruntime/OnnxRuntime;
    .line 2: monitor-enter v0
    .line 3: sget-boolean v1, Lai/onnxruntime/OnnxRuntime;->loaded:Z
    .line 5: if-eqz v1, :cond_9
    .line 7: monitor-exit v0
    .line 8: return-void
    .line 9: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->isAndroid()Z
    .line 12: move-result v1
    .line 13: const/4 v2, 0
    .line 14: if-eqz v1, :cond_18
    .line 16: const/4 v1, 0
    .line 17: goto :goto_24
    .line 18: new-array v1, v2, [Ljava/nio/file/attribute/FileAttribute;
    .line 20: invoke-static {v1}, Lai/onnxruntime/a;->n([Ljava/nio/file/attribute/FileAttribute;)Ljava/nio/file/Path;
    .line 23: move-result-object v1
    .line 24: sput-object v1, Lai/onnxruntime/OnnxRuntime;->tempDirectory:Ljava/nio/file/Path;
    .line 26: const-string v1, "onnxruntime.native.path"
    .line 28: invoke-static {v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    .line 31: move-result-object v1
    .line 32: sput-object v1, Lai/onnxruntime/OnnxRuntime;->libraryDirPathProperty:Ljava/lang/String;
    .line 34: const-string v1, "onnxruntime_providers_shared"
    .line 36: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->extractProviderLibrary(Ljava/lang/String;)Z
    .line 39: const-string v1, "onnxruntime"
    .line 41: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->load(Ljava/lang/String;)V
    .line 44: const-string v1, "onnxruntime4j_jni"
    .line 46: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->load(Ljava/lang/String;)V
    .line 49: const/16 v1, 14
    .line 51: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->initialiseAPIBase(I)J
    .line 54: move-result-wide v3
    .line 55: sput-wide v3, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 57: const-wide/16 v5, 0
    .line 59: cmp-long v7, v3, v5
    .line 61: if-eqz v7, :cond_111
    .line 63: invoke-static {v3, v4, v1}, Lai/onnxruntime/OnnxRuntime;->initialiseTrainingAPIBase(JI)J
    .line 66: move-result-wide v3
    .line 67: sput-wide v3, Lai/onnxruntime/OnnxRuntime;->ortTrainingApiHandle:J
    .line 69: cmp-long v1, v3, v5
    .line 71: const/4 v3, 1
    .line 72: if-eqz v1, :cond_75
    .line 74: move v2, v3
    .line 75: sput-boolean v2, Lai/onnxruntime/OnnxRuntime;->trainingEnabled:Z
    .line 77: sget-wide v1, Lai/onnxruntime/OnnxRuntime;->ortApiHandle:J
    .line 79: invoke-static {v1, v2}, Lai/onnxruntime/OnnxRuntime;->initialiseProviders(J)Ljava/util/EnumSet;
    .line 82: move-result-object v1
    .line 83: sput-object v1, Lai/onnxruntime/OnnxRuntime;->providers:Ljava/util/EnumSet;
    .line 85: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->initialiseVersion()Ljava/lang/String;
    .line 88: move-result-object v1
    .line 89: sput-object v1, Lai/onnxruntime/OnnxRuntime;->version:Ljava/lang/String;
    .line 91: sput-boolean v3, Lai/onnxruntime/OnnxRuntime;->loaded:Z
    .line 93: sget-object v1, Lai/onnxruntime/OnnxRuntime;->tempDirectory:Ljava/nio/file/Path;
    .line 95: if-eqz v1, :cond_107
    .line 97: invoke-static {v1}, Lai/onnxruntime/a;->g(Ljava/nio/file/Path;)Ljava/io/File;
    .line 100: move-result-object v1
    .line 101: invoke-static {v1}, Lai/onnxruntime/OnnxRuntime;->cleanUp(Ljava/io/File;)V
    .line 104: goto :goto_107
    .line 105: move-exception v1
    .line 106: goto :goto_131
    .line 107: monitor-exit v0
    .line 108: return-void
    .line 109: move-exception v1
    .line 110: goto :goto_119
    .line 111: new-instance v1, Ljava/lang/IllegalStateException;
    .line 113: const-string v2, "There is a mismatch between the ORT class files and the ORT native library, and the native library could not be loaded"
    .line 115: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 118: throw v1
    .line 119: sget-object v2, Lai/onnxruntime/OnnxRuntime;->tempDirectory:Ljava/nio/file/Path;
    .line 121: if-eqz v2, :cond_130
    .line 123: invoke-static {v2}, Lai/onnxruntime/a;->g(Ljava/nio/file/Path;)Ljava/io/File;
    .line 126: move-result-object v2
    .line 127: invoke-static {v2}, Lai/onnxruntime/OnnxRuntime;->cleanUp(Ljava/io/File;)V
    .line 130: throw v1
    .line 131: monitor-exit v0
    .line 132: throw v1
.end method

# direct methods
.method private static initOsArch()Ljava/lang/String;
    .registers 5

    .line 0: const-string v0, "os.name"
    .line 2: const-string v1, "generic"
    .line 4: invoke-static {v0, v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 7: move-result-object v0
    .line 8: sget-object v2, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;
    .line 10: invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 13: move-result-object v0
    .line 14: const-string v3, "mac"
    .line 16: invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    .line 19: move-result v3
    .line 20: if-nez v3, :cond_72
    .line 22: const-string v3, "darwin"
    .line 24: invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    .line 27: move-result v3
    .line 28: if-eqz v3, :cond_31
    .line 30: goto :goto_72
    .line 31: const-string v3, "win"
    .line 33: invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    .line 36: move-result v4
    .line 37: if-eqz v4, :cond_40
    .line 39: goto :goto_74
    .line 40: const-string v3, "nux"
    .line 42: invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    .line 45: move-result v3
    .line 46: if-eqz v3, :cond_51
    .line 48: const-string v3, "linux"
    .line 50: goto :goto_74
    .line 51: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->isAndroid()Z
    .line 54: move-result v3
    .line 55: if-eqz v3, :cond_60
    .line 57: const-string v3, "android"
    .line 59: goto :goto_74
    .line 60: new-instance v1, Ljava/lang/IllegalStateException;
    .line 62: const-string v2, "Unsupported os:"
    .line 64: invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 67: move-result-object v0
    .line 68: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 71: throw v1
    .line 72: const-string v3, "osx"
    .line 74: const-string v0, "os.arch"
    .line 76: invoke-static {v0, v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 79: move-result-object v0
    .line 80: invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 83: move-result-object v0
    .line 84: const-string v1, "amd64"
    .line 86: invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 89: move-result v1
    .line 90: if-nez v1, :cond_148
    .line 92: const-string v1, "x86_64"
    .line 94: invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 97: move-result v1
    .line 98: if-eqz v1, :cond_101
    .line 100: goto :goto_148
    .line 101: const-string v1, "x86"
    .line 103: invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 106: move-result v2
    .line 107: if-eqz v2, :cond_111
    .line 109: move-object v0, v1
    .line 110: goto :goto_150
    .line 111: const-string v1, "aarch64"
    .line 113: invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 116: move-result v2
    .line 117: if-eqz v2, :cond_120
    .line 119: goto :goto_109
    .line 120: const-string v1, "ppc64"
    .line 122: invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 125: move-result v2
    .line 126: if-eqz v2, :cond_129
    .line 128: goto :goto_109
    .line 129: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->isAndroid()Z
    .line 132: move-result v1
    .line 133: if-eqz v1, :cond_136
    .line 135: goto :goto_150
    .line 136: new-instance v1, Ljava/lang/IllegalStateException;
    .line 138: const-string v2, "Unsupported arch:"
    .line 140: invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 143: move-result-object v0
    .line 144: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 147: throw v1
    .line 148: const-string v0, "x64"
    .line 150: new-instance v1, Ljava/lang/StringBuilder;
    .line 152: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 155: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 158: const/16 v2, 45
    .line 160: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 163: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 166: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 169: move-result-object v0
    .line 170: return-object v0
.end method

# direct methods
.method private static native initialiseAPIBase(I)J
.end method

# direct methods
.method private static initialiseProviders(J)Ljava/util/EnumSet;
    .registers 5

    .line 0: invoke-static {v3, v4}, Lai/onnxruntime/OnnxRuntime;->getAvailableProviders(J)[Ljava/lang/String;
    .line 3: move-result-object v3
    .line 4: const-class v4, Lai/onnxruntime/OrtProvider;
    .line 6: invoke-static {v4}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;
    .line 9: move-result-object v4
    .line 10: array-length v0, v3
    .line 11: const/4 v1, 0
    .line 12: if-ge v1, v0, :cond_26
    .line 14: aget-object v2, v3, v1
    .line 16: invoke-static {v2}, Lai/onnxruntime/OrtProvider;->mapFromName(Ljava/lang/String;)Lai/onnxruntime/OrtProvider;
    .line 19: move-result-object v2
    .line 20: invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z
    .line 23: add-int/lit8 v1, v1, 1
    .line 25: goto :goto_12
    .line 26: return-object v4
.end method

# direct methods
.method private static native initialiseTrainingAPIBase(JI)J
.end method

# direct methods
.method private static native initialiseVersion()Ljava/lang/String;
.end method

# direct methods
.method public static isAndroid()Z
    .registers 2

    .line 0: const-string v0, "java.vendor"
    .line 2: const-string v1, "generic"
    .line 4: invoke-static {v0, v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 7: move-result-object v0
    .line 8: const-string v1, "The Android Project"
    .line 10: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 13: move-result v0
    .line 14: return v0
.end method

# direct methods
.method private static load(Ljava/lang/String;)V
    .registers 11

    .line 0: invoke-static {}, Lai/onnxruntime/OnnxRuntime;->isAndroid()Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_12
    .line 6: const-string v10, "onnxruntime4j_jni"
    .line 8: invoke-static {v10}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    .line 11: return-void
    .line 12: new-instance v0, Ljava/lang/StringBuilder;
    .line 14: const-string v1, "onnxruntime.native."
    .line 16: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 19: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v2, ".skip"
    .line 24: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 30: move-result-object v0
    .line 31: invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    .line 34: move-result-object v0
    .line 35: sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 37: invoke-virtual {v2}, Ljava/lang/Boolean;->toString()Ljava/lang/String;
    .line 40: move-result-object v2
    .line 41: invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    .line 44: move-result v0
    .line 45: if-eqz v0, :cond_74
    .line 47: sget-object v0, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 49: sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 51: new-instance v2, Ljava/lang/StringBuilder;
    .line 53: const-string v3, "Skipping load of native library '"
    .line 55: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 58: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 61: const-string v10, "'"
    .line 63: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 66: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 69: move-result-object v10
    .line 70: invoke-virtual {v0, v1, v10}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 73: return-void
    .line 74: invoke-static {v10}, Lai/onnxruntime/OnnxRuntime;->mapLibraryName(Ljava/lang/String;)Ljava/lang/String;
    .line 77: move-result-object v0
    .line 78: sget-object v2, Lai/onnxruntime/OnnxRuntime;->libraryDirPathProperty:Ljava/lang/String;
    .line 80: const-string v3, "' from specified path"
    .line 82: const-string v4, "' not found at "
    .line 84: const-string v5, "Native library '"
    .line 86: const-string v6, "' from specified path: "
    .line 88: const-string v7, "Attempting to load native library '"
    .line 90: const-string v8, "Loaded native library '"
    .line 92: if-eqz v2, :cond_191
    .line 94: sget-object v1, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 96: sget-object v2, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 98: new-instance v9, Ljava/lang/StringBuilder;
    .line 100: invoke-direct {v9, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 103: invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 106: invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 109: sget-object v6, Lai/onnxruntime/OnnxRuntime;->libraryDirPathProperty:Ljava/lang/String;
    .line 111: invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 114: invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 117: move-result-object v6
    .line 118: invoke-virtual {v1, v2, v6}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 121: sget-object v6, Lai/onnxruntime/OnnxRuntime;->libraryDirPathProperty:Ljava/lang/String;
    .line 123: filled-new-array {v0}, [Ljava/lang/String;
    .line 126: move-result-object v0
    .line 127: invoke-static {v6, v0}, Lai/onnxruntime/a;->l(Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;
    .line 130: move-result-object v0
    .line 131: invoke-static {v0}, Lai/onnxruntime/a;->g(Ljava/nio/file/Path;)Ljava/io/File;
    .line 134: move-result-object v0
    .line 135: invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    .line 138: move-result-object v6
    .line 139: invoke-virtual {v0}, Ljava/io/File;->exists()Z
    .line 142: move-result v0
    .line 143: if-eqz v0, :cond_167
    .line 145: invoke-static {v6}, Ljava/lang/System;->load(Ljava/lang/String;)V
    .line 148: new-instance v0, Ljava/lang/StringBuilder;
    .line 150: invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 153: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 156: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 159: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 162: move-result-object v10
    .line 163: invoke-virtual {v1, v2, v10}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 166: return-void
    .line 167: new-instance v0, Ljava/io/IOException;
    .line 169: new-instance v1, Ljava/lang/StringBuilder;
    .line 171: invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 174: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 177: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 180: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 183: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 186: move-result-object v10
    .line 187: invoke-direct {v0, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 190: throw v0
    .line 191: new-instance v0, Ljava/lang/StringBuilder;
    .line 193: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 196: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 199: const-string v1, ".path"
    .line 201: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 204: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 207: move-result-object v0
    .line 208: invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    .line 211: move-result-object v0
    .line 212: if-eqz v0, :cond_300
    .line 214: sget-object v1, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 216: sget-object v2, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 218: new-instance v9, Ljava/lang/StringBuilder;
    .line 220: invoke-direct {v9, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 223: invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 226: invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 229: invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 232: invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 235: move-result-object v6
    .line 236: invoke-virtual {v1, v2, v6}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 239: new-instance v6, Ljava/io/File;
    .line 241: invoke-direct {v6, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    .line 244: invoke-virtual {v6}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    .line 247: move-result-object v0
    .line 248: invoke-virtual {v6}, Ljava/io/File;->exists()Z
    .line 251: move-result v6
    .line 252: if-eqz v6, :cond_276
    .line 254: invoke-static {v0}, Ljava/lang/System;->load(Ljava/lang/String;)V
    .line 257: new-instance v0, Ljava/lang/StringBuilder;
    .line 259: invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 262: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 265: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 268: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 271: move-result-object v10
    .line 272: invoke-virtual {v1, v2, v10}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 275: return-void
    .line 276: new-instance v1, Ljava/io/IOException;
    .line 278: new-instance v2, Ljava/lang/StringBuilder;
    .line 280: invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 283: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 286: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 289: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 292: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 295: move-result-object v10
    .line 296: invoke-direct {v1, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 299: throw v1
    .line 300: invoke-static {v10}, Lai/onnxruntime/OnnxRuntime;->extractFromResources(Ljava/lang/String;)Ljava/util/Optional;
    .line 303: move-result-object v0
    .line 304: invoke-virtual {v0}, Ljava/util/Optional;->isPresent()Z
    .line 307: move-result v1
    .line 308: if-eqz v1, :cond_348
    .line 310: invoke-virtual {v0}, Ljava/util/Optional;->get()Ljava/lang/Object;
    .line 313: move-result-object v0
    .line 314: check-cast v0, Ljava/io/File;
    .line 316: invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    .line 319: move-result-object v0
    .line 320: invoke-static {v0}, Ljava/lang/System;->load(Ljava/lang/String;)V
    .line 323: sget-object v0, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 325: sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 327: new-instance v2, Ljava/lang/StringBuilder;
    .line 329: invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 332: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 335: const-string v10, "' from resource path"
    .line 337: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 340: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 343: move-result-object v10
    .line 344: invoke-virtual {v0, v1, v10}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 347: goto :goto_393
    .line 348: sget-object v0, Lai/onnxruntime/OnnxRuntime;->logger:Ljava/util/logging/Logger;
    .line 350: sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;
    .line 352: new-instance v2, Ljava/lang/StringBuilder;
    .line 354: invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 357: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 360: const-string v3, "' from library path"
    .line 362: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 365: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 368: move-result-object v2
    .line 369: invoke-virtual {v0, v1, v2}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 372: invoke-static {v10}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    .line 375: new-instance v2, Ljava/lang/StringBuilder;
    .line 377: invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 380: invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 383: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 386: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 389: move-result-object v10
    .line 390: invoke-virtual {v0, v1, v10}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V
    .line 393: return-void
.end method

# direct methods
.method private static mapLibraryName(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 0: invoke-static {v2}, Ljava/lang/System;->mapLibraryName(Ljava/lang/String;)Ljava/lang/String;
    .line 3: move-result-object v2
    .line 4: const-string v0, "jnilib"
    .line 6: const-string v1, "dylib"
    .line 8: invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    .line 11: move-result-object v2
    .line 12: return-object v2
.end method

# direct methods
.method public static version()Ljava/lang/String;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OnnxRuntime;->version:Ljava/lang/String;
    .line 2: return-object v0
.end method

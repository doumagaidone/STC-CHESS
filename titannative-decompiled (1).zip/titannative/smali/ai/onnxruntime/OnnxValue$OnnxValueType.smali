.class public final enum Lai/onnxruntime/OnnxValue$OnnxValueType;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_MAP:Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_OPAQUE:Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_OPTIONAL:Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_SEQUENCE:Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_SPARSETENSOR:Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_TENSOR:Lai/onnxruntime/OnnxValue$OnnxValueType;
.field public static final enum ONNX_TYPE_UNKNOWN:Lai/onnxruntime/OnnxValue$OnnxValueType;

.field public final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 0: new-instance v0, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 2: const-string v1, "ONNX_TYPE_UNKNOWN"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2, v2}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 8: sput-object v0, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_UNKNOWN:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 10: new-instance v1, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 12: const-string v2, "ONNX_TYPE_TENSOR"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3, v3}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 18: sput-object v1, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_TENSOR:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 20: new-instance v2, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 22: const-string v3, "ONNX_TYPE_SEQUENCE"
    .line 24: const/4 v4, 2
    .line 25: invoke-direct {v2, v3, v4, v4}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 28: sput-object v2, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_SEQUENCE:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 30: new-instance v3, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 32: const-string v4, "ONNX_TYPE_MAP"
    .line 34: const/4 v5, 3
    .line 35: invoke-direct {v3, v4, v5, v5}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 38: sput-object v3, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_MAP:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 40: new-instance v4, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 42: const-string v5, "ONNX_TYPE_OPAQUE"
    .line 44: const/4 v6, 4
    .line 45: invoke-direct {v4, v5, v6, v6}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 48: sput-object v4, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_OPAQUE:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 50: new-instance v5, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 52: const-string v6, "ONNX_TYPE_SPARSETENSOR"
    .line 54: const/4 v7, 5
    .line 55: invoke-direct {v5, v6, v7, v7}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 58: sput-object v5, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_SPARSETENSOR:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 60: new-instance v6, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 62: const-string v7, "ONNX_TYPE_OPTIONAL"
    .line 64: const/4 v8, 6
    .line 65: invoke-direct {v6, v7, v8, v8}, Lai/onnxruntime/OnnxValue$OnnxValueType;-><init>(Ljava/lang/String;II)V
    .line 68: sput-object v6, Lai/onnxruntime/OnnxValue$OnnxValueType;->ONNX_TYPE_OPTIONAL:Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 70: filled-new-array/range {v0 .. v6}, [Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 73: move-result-object v0
    .line 74: sput-object v0, Lai/onnxruntime/OnnxValue$OnnxValueType;->$VALUES:[Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 76: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OnnxValue$OnnxValueType;->value:I
    .line 5: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OnnxValue$OnnxValueType;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OnnxValue$OnnxValueType;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OnnxValue$OnnxValueType;->$VALUES:[Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OnnxValue$OnnxValueType;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 8: return-object v0
.end method

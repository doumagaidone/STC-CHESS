.class public final enum Lai/onnxruntime/OrtProvider;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OrtProvider;
.field public static final enum ACL:Lai/onnxruntime/OrtProvider;
.field public static final enum ARM_NN:Lai/onnxruntime/OrtProvider;
.field public static final enum AZURE:Lai/onnxruntime/OrtProvider;
.field public static final enum CORE_ML:Lai/onnxruntime/OrtProvider;
.field public static final enum CPU:Lai/onnxruntime/OrtProvider;
.field public static final enum CUDA:Lai/onnxruntime/OrtProvider;
.field public static final enum DIRECT_ML:Lai/onnxruntime/OrtProvider;
.field public static final enum DNNL:Lai/onnxruntime/OrtProvider;
.field public static final enum MI_GRAPH_X:Lai/onnxruntime/OrtProvider;
.field public static final enum NNAPI:Lai/onnxruntime/OrtProvider;
.field public static final enum OPEN_VINO:Lai/onnxruntime/OrtProvider;
.field public static final enum RK_NPU:Lai/onnxruntime/OrtProvider;
.field public static final enum ROCM:Lai/onnxruntime/OrtProvider;
.field public static final enum TENSOR_RT:Lai/onnxruntime/OrtProvider;
.field public static final enum VITIS_AI:Lai/onnxruntime/OrtProvider;
.field public static final enum XNNPACK:Lai/onnxruntime/OrtProvider;
.field private static final valueMap:Ljava/util/Map;

.field private final name:Ljava/lang/String;

# direct methods
.method static constructor <clinit>()V
    .registers 20

    .line 0: new-instance v0, Lai/onnxruntime/OrtProvider;
    .line 2: const-string v1, "CPUExecutionProvider"
    .line 4: const-string v2, "CPU"
    .line 6: const/4 v15, 0
    .line 7: invoke-direct {v0, v2, v15, v1}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 10: sput-object v0, Lai/onnxruntime/OrtProvider;->CPU:Lai/onnxruntime/OrtProvider;
    .line 12: new-instance v1, Lai/onnxruntime/OrtProvider;
    .line 14: const/4 v2, 1
    .line 15: const-string v3, "CUDAExecutionProvider"
    .line 17: const-string v4, "CUDA"
    .line 19: invoke-direct {v1, v4, v2, v3}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 22: sput-object v1, Lai/onnxruntime/OrtProvider;->CUDA:Lai/onnxruntime/OrtProvider;
    .line 24: new-instance v2, Lai/onnxruntime/OrtProvider;
    .line 26: const/4 v3, 2
    .line 27: const-string v4, "DnnlExecutionProvider"
    .line 29: const-string v5, "DNNL"
    .line 31: invoke-direct {v2, v5, v3, v4}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 34: sput-object v2, Lai/onnxruntime/OrtProvider;->DNNL:Lai/onnxruntime/OrtProvider;
    .line 36: new-instance v3, Lai/onnxruntime/OrtProvider;
    .line 38: const/4 v4, 3
    .line 39: const-string v5, "OpenVINOExecutionProvider"
    .line 41: const-string v6, "OPEN_VINO"
    .line 43: invoke-direct {v3, v6, v4, v5}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 46: sput-object v3, Lai/onnxruntime/OrtProvider;->OPEN_VINO:Lai/onnxruntime/OrtProvider;
    .line 48: new-instance v4, Lai/onnxruntime/OrtProvider;
    .line 50: const/4 v5, 4
    .line 51: const-string v6, "VitisAIExecutionProvider"
    .line 53: const-string v7, "VITIS_AI"
    .line 55: invoke-direct {v4, v7, v5, v6}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 58: sput-object v4, Lai/onnxruntime/OrtProvider;->VITIS_AI:Lai/onnxruntime/OrtProvider;
    .line 60: new-instance v5, Lai/onnxruntime/OrtProvider;
    .line 62: const/4 v6, 5
    .line 63: const-string v7, "TensorrtExecutionProvider"
    .line 65: const-string v8, "TENSOR_RT"
    .line 67: invoke-direct {v5, v8, v6, v7}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 70: sput-object v5, Lai/onnxruntime/OrtProvider;->TENSOR_RT:Lai/onnxruntime/OrtProvider;
    .line 72: new-instance v6, Lai/onnxruntime/OrtProvider;
    .line 74: const/4 v7, 6
    .line 75: const-string v8, "NnapiExecutionProvider"
    .line 77: const-string v9, "NNAPI"
    .line 79: invoke-direct {v6, v9, v7, v8}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 82: sput-object v6, Lai/onnxruntime/OrtProvider;->NNAPI:Lai/onnxruntime/OrtProvider;
    .line 84: new-instance v7, Lai/onnxruntime/OrtProvider;
    .line 86: const/4 v8, 7
    .line 87: const-string v9, "RknpuExecutionProvider"
    .line 89: const-string v10, "RK_NPU"
    .line 91: invoke-direct {v7, v10, v8, v9}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 94: sput-object v7, Lai/onnxruntime/OrtProvider;->RK_NPU:Lai/onnxruntime/OrtProvider;
    .line 96: new-instance v8, Lai/onnxruntime/OrtProvider;
    .line 98: const/16 v9, 8
    .line 100: const-string v10, "DmlExecutionProvider"
    .line 102: const-string v11, "DIRECT_ML"
    .line 104: invoke-direct {v8, v11, v9, v10}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 107: sput-object v8, Lai/onnxruntime/OrtProvider;->DIRECT_ML:Lai/onnxruntime/OrtProvider;
    .line 109: new-instance v9, Lai/onnxruntime/OrtProvider;
    .line 111: const/16 v10, 9
    .line 113: const-string v11, "MIGraphXExecutionProvider"
    .line 115: const-string v12, "MI_GRAPH_X"
    .line 117: invoke-direct {v9, v12, v10, v11}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 120: sput-object v9, Lai/onnxruntime/OrtProvider;->MI_GRAPH_X:Lai/onnxruntime/OrtProvider;
    .line 122: new-instance v10, Lai/onnxruntime/OrtProvider;
    .line 124: const/16 v11, 10
    .line 126: const-string v12, "ACLExecutionProvider"
    .line 128: const-string v13, "ACL"
    .line 130: invoke-direct {v10, v13, v11, v12}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 133: sput-object v10, Lai/onnxruntime/OrtProvider;->ACL:Lai/onnxruntime/OrtProvider;
    .line 135: new-instance v11, Lai/onnxruntime/OrtProvider;
    .line 137: const/16 v12, 11
    .line 139: const-string v13, "ArmNNExecutionProvider"
    .line 141: const-string v14, "ARM_NN"
    .line 143: invoke-direct {v11, v14, v12, v13}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 146: sput-object v11, Lai/onnxruntime/OrtProvider;->ARM_NN:Lai/onnxruntime/OrtProvider;
    .line 148: new-instance v12, Lai/onnxruntime/OrtProvider;
    .line 150: const/16 v13, 12
    .line 152: const-string v14, "ROCMExecutionProvider"
    .line 154: const-string v15, "ROCM"
    .line 156: invoke-direct {v12, v15, v13, v14}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 159: sput-object v12, Lai/onnxruntime/OrtProvider;->ROCM:Lai/onnxruntime/OrtProvider;
    .line 161: new-instance v13, Lai/onnxruntime/OrtProvider;
    .line 163: const/16 v14, 13
    .line 165: const-string v15, "CoreMLExecutionProvider"
    .line 167: move-object/from16 v17, v12
    .line 169: const-string v12, "CORE_ML"
    .line 171: invoke-direct {v13, v12, v14, v15}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 174: sput-object v13, Lai/onnxruntime/OrtProvider;->CORE_ML:Lai/onnxruntime/OrtProvider;
    .line 176: new-instance v14, Lai/onnxruntime/OrtProvider;
    .line 178: const/16 v12, 14
    .line 180: const-string v15, "XnnpackExecutionProvider"
    .line 182: move-object/from16 v18, v13
    .line 184: const-string v13, "XNNPACK"
    .line 186: invoke-direct {v14, v13, v12, v15}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 189: sput-object v14, Lai/onnxruntime/OrtProvider;->XNNPACK:Lai/onnxruntime/OrtProvider;
    .line 191: new-instance v15, Lai/onnxruntime/OrtProvider;
    .line 193: const/16 v12, 15
    .line 195: const-string v13, "AzureExecutionProvider"
    .line 197: move-object/from16 v19, v14
    .line 199: const-string v14, "AZURE"
    .line 201: invoke-direct {v15, v14, v12, v13}, Lai/onnxruntime/OrtProvider;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 204: sput-object v15, Lai/onnxruntime/OrtProvider;->AZURE:Lai/onnxruntime/OrtProvider;
    .line 206: move-object/from16 v12, v17
    .line 208: move-object/from16 v13, v18
    .line 210: move-object/from16 v14, v19
    .line 212: const/16 v16, 0
    .line 214: filled-new-array/range {v0 .. v15}, [Lai/onnxruntime/OrtProvider;
    .line 217: move-result-object v0
    .line 218: sput-object v0, Lai/onnxruntime/OrtProvider;->$VALUES:[Lai/onnxruntime/OrtProvider;
    .line 220: new-instance v0, Ljava/util/HashMap;
    .line 222: invoke-static {}, Lai/onnxruntime/OrtProvider;->values()[Lai/onnxruntime/OrtProvider;
    .line 225: move-result-object v1
    .line 226: array-length v1, v1
    .line 227: invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V
    .line 230: sput-object v0, Lai/onnxruntime/OrtProvider;->valueMap:Ljava/util/Map;
    .line 232: invoke-static {}, Lai/onnxruntime/OrtProvider;->values()[Lai/onnxruntime/OrtProvider;
    .line 235: move-result-object v0
    .line 236: array-length v1, v0
    .line 237: move/from16 v15, v16
    .line 239: if-ge v15, v1, :cond_253
    .line 241: aget-object v2, v0, v15
    .line 243: sget-object v3, Lai/onnxruntime/OrtProvider;->valueMap:Ljava/util/Map;
    .line 245: iget-object v4, v2, Lai/onnxruntime/OrtProvider;->name:Ljava/lang/String;
    .line 247: invoke-interface {v3, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 250: add-int/lit8 v15, v15, 1
    .line 252: goto :goto_239
    .line 253: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput-object v3, v0, Lai/onnxruntime/OrtProvider;->name:Ljava/lang/String;
    .line 5: return-void
.end method

# direct methods
.method public static mapFromName(Ljava/lang/String;)Lai/onnxruntime/OrtProvider;
    .registers 4

    .line 0: sget-object v0, Lai/onnxruntime/OrtProvider;->valueMap:Ljava/util/Map;
    .line 2: invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lai/onnxruntime/OrtProvider;
    .line 8: if-eqz v0, :cond_11
    .line 10: return-object v0
    .line 11: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 13: new-instance v1, Ljava/lang/StringBuilder;
    .line 15: const-string v2, "Unknown execution provider - "
    .line 17: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 20: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 23: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 26: move-result-object v3
    .line 27: invoke-direct {v0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 30: throw v0
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OrtProvider;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OrtProvider;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OrtProvider;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OrtProvider;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OrtProvider;->$VALUES:[Lai/onnxruntime/OrtProvider;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OrtProvider;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OrtProvider;
    .line 8: return-object v0
.end method

# virtual methods
.method public getName()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lai/onnxruntime/OrtProvider;->name:Ljava/lang/String;
    .line 2: return-object v0
.end method

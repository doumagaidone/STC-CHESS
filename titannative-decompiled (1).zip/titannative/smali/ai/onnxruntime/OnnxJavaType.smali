.class public final enum Lai/onnxruntime/OnnxJavaType;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Lai/onnxruntime/OnnxJavaType;
.field public static final enum BFLOAT16:Lai/onnxruntime/OnnxJavaType;
.field public static final enum BOOL:Lai/onnxruntime/OnnxJavaType;
.field public static final enum DOUBLE:Lai/onnxruntime/OnnxJavaType;
.field public static final enum FLOAT:Lai/onnxruntime/OnnxJavaType;
.field public static final enum FLOAT16:Lai/onnxruntime/OnnxJavaType;
.field public static final enum INT16:Lai/onnxruntime/OnnxJavaType;
.field public static final enum INT32:Lai/onnxruntime/OnnxJavaType;
.field public static final enum INT64:Lai/onnxruntime/OnnxJavaType;
.field public static final enum INT8:Lai/onnxruntime/OnnxJavaType;
.field public static final enum STRING:Lai/onnxruntime/OnnxJavaType;
.field public static final enum UINT8:Lai/onnxruntime/OnnxJavaType;
.field public static final enum UNKNOWN:Lai/onnxruntime/OnnxJavaType;
.field private static final values:[Lai/onnxruntime/OnnxJavaType;

.field public final clazz:Ljava/lang/Class;
.field public final size:I
.field public final value:I

# direct methods
.method static constructor <clinit>()V
    .registers 32

    .line 0: new-instance v6, Lai/onnxruntime/OnnxJavaType;
    .line 2: const-string v1, "FLOAT"
    .line 4: const/4 v2, 0
    .line 5: const/4 v3, 1
    .line 6: sget-object v4, Ljava/lang/Float;->TYPE:Ljava/lang/Class;
    .line 8: const/4 v5, 4
    .line 9: move-object v0, v6
    .line 10: invoke-direct/range {v0 .. v5}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 13: sput-object v6, Lai/onnxruntime/OnnxJavaType;->FLOAT:Lai/onnxruntime/OnnxJavaType;
    .line 15: new-instance v1, Lai/onnxruntime/OnnxJavaType;
    .line 17: const-string v8, "DOUBLE"
    .line 19: const/4 v9, 1
    .line 20: const/4 v10, 2
    .line 21: sget-object v11, Ljava/lang/Double;->TYPE:Ljava/lang/Class;
    .line 23: const/16 v12, 8
    .line 25: move-object v7, v1
    .line 26: invoke-direct/range {v7 .. v12}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 29: sput-object v1, Lai/onnxruntime/OnnxJavaType;->DOUBLE:Lai/onnxruntime/OnnxJavaType;
    .line 31: new-instance v2, Lai/onnxruntime/OnnxJavaType;
    .line 33: const-string v14, "INT8"
    .line 35: const/4 v15, 2
    .line 36: const/16 v16, 3
    .line 38: sget-object v11, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;
    .line 40: const/16 v18, 1
    .line 42: move-object v13, v2
    .line 43: move-object/from16 v17, v11
    .line 45: invoke-direct/range {v13 .. v18}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 48: sput-object v2, Lai/onnxruntime/OnnxJavaType;->INT8:Lai/onnxruntime/OnnxJavaType;
    .line 50: new-instance v3, Lai/onnxruntime/OnnxJavaType;
    .line 52: const-string v20, "INT16"
    .line 54: const/16 v21, 3
    .line 56: const/16 v22, 4
    .line 58: sget-object v0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;
    .line 60: const/16 v24, 2
    .line 62: move-object/from16 v19, v3
    .line 64: move-object/from16 v23, v0
    .line 66: invoke-direct/range {v19 .. v24}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 69: sput-object v3, Lai/onnxruntime/OnnxJavaType;->INT16:Lai/onnxruntime/OnnxJavaType;
    .line 71: new-instance v4, Lai/onnxruntime/OnnxJavaType;
    .line 73: const-string v13, "INT32"
    .line 75: const/4 v14, 4
    .line 76: const/4 v15, 5
    .line 77: sget-object v16, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 79: const/16 v17, 4
    .line 81: move-object v12, v4
    .line 82: invoke-direct/range {v12 .. v17}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 85: sput-object v4, Lai/onnxruntime/OnnxJavaType;->INT32:Lai/onnxruntime/OnnxJavaType;
    .line 87: new-instance v5, Lai/onnxruntime/OnnxJavaType;
    .line 89: const-string v19, "INT64"
    .line 91: const/16 v20, 5
    .line 93: const/16 v21, 6
    .line 95: sget-object v22, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 97: const/16 v23, 8
    .line 99: move-object/from16 v18, v5
    .line 101: invoke-direct/range {v18 .. v23}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 104: sput-object v5, Lai/onnxruntime/OnnxJavaType;->INT64:Lai/onnxruntime/OnnxJavaType;
    .line 106: new-instance v18, Lai/onnxruntime/OnnxJavaType;
    .line 108: const-string v13, "BOOL"
    .line 110: const/4 v14, 6
    .line 111: const/4 v15, 7
    .line 112: sget-object v16, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 114: const/16 v17, 1
    .line 116: move-object/from16 v12, v18
    .line 118: invoke-direct/range {v12 .. v17}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 121: sput-object v18, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 123: new-instance v25, Lai/onnxruntime/OnnxJavaType;
    .line 125: const-string v20, "STRING"
    .line 127: const/16 v21, 7
    .line 129: const/16 v22, 8
    .line 131: const-class v23, Ljava/lang/String;
    .line 133: const/16 v24, 4
    .line 135: move-object/from16 v19, v25
    .line 137: invoke-direct/range {v19 .. v24}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 140: sput-object v25, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 142: new-instance v19, Lai/onnxruntime/OnnxJavaType;
    .line 144: const-string v8, "UINT8"
    .line 146: const/16 v9, 8
    .line 148: const/16 v10, 9
    .line 150: const/4 v12, 1
    .line 151: move-object/from16 v7, v19
    .line 153: invoke-direct/range {v7 .. v12}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 156: sput-object v19, Lai/onnxruntime/OnnxJavaType;->UINT8:Lai/onnxruntime/OnnxJavaType;
    .line 158: new-instance v9, Lai/onnxruntime/OnnxJavaType;
    .line 160: const-string v13, "FLOAT16"
    .line 162: const/16 v14, 9
    .line 164: const/16 v15, 10
    .line 166: const/16 v17, 2
    .line 168: move-object v12, v9
    .line 169: move-object/from16 v16, v0
    .line 171: invoke-direct/range {v12 .. v17}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 174: sput-object v9, Lai/onnxruntime/OnnxJavaType;->FLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 176: new-instance v10, Lai/onnxruntime/OnnxJavaType;
    .line 178: const-string v13, "BFLOAT16"
    .line 180: const/16 v14, 10
    .line 182: const/16 v15, 11
    .line 184: move-object v12, v10
    .line 185: invoke-direct/range {v12 .. v17}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 188: sput-object v10, Lai/onnxruntime/OnnxJavaType;->BFLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 190: new-instance v11, Lai/onnxruntime/OnnxJavaType;
    .line 192: const-string v27, "UNKNOWN"
    .line 194: const/16 v28, 11
    .line 196: const/16 v29, 0
    .line 198: const-class v30, Ljava/lang/Object;
    .line 200: const/16 v31, 0
    .line 202: move-object/from16 v26, v11
    .line 204: invoke-direct/range {v26 .. v31}, Lai/onnxruntime/OnnxJavaType;-><init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .line 207: sput-object v11, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 209: move-object v0, v6
    .line 210: move-object/from16 v6, v18
    .line 212: move-object/from16 v7, v25
    .line 214: move-object/from16 v8, v19
    .line 216: filled-new-array/range {v0 .. v11}, [Lai/onnxruntime/OnnxJavaType;
    .line 219: move-result-object v0
    .line 220: sput-object v0, Lai/onnxruntime/OnnxJavaType;->$VALUES:[Lai/onnxruntime/OnnxJavaType;
    .line 222: invoke-static {}, Lai/onnxruntime/OnnxJavaType;->values()[Lai/onnxruntime/OnnxJavaType;
    .line 225: move-result-object v0
    .line 226: array-length v1, v0
    .line 227: new-array v1, v1, [Lai/onnxruntime/OnnxJavaType;
    .line 229: sput-object v1, Lai/onnxruntime/OnnxJavaType;->values:[Lai/onnxruntime/OnnxJavaType;
    .line 231: array-length v1, v0
    .line 232: const/4 v2, 0
    .line 233: if-ge v2, v1, :cond_246
    .line 235: aget-object v3, v0, v2
    .line 237: sget-object v4, Lai/onnxruntime/OnnxJavaType;->values:[Lai/onnxruntime/OnnxJavaType;
    .line 239: iget v5, v3, Lai/onnxruntime/OnnxJavaType;->value:I
    .line 241: aput-object v3, v4, v5
    .line 243: add-int/lit8 v2, v2, 1
    .line 245: goto :goto_233
    .line 246: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;IILjava/lang/Class;I)V
    .registers 6

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput v3, v0, Lai/onnxruntime/OnnxJavaType;->value:I
    .line 5: iput-object v4, v0, Lai/onnxruntime/OnnxJavaType;->clazz:Ljava/lang/Class;
    .line 7: iput v5, v0, Lai/onnxruntime/OnnxJavaType;->size:I
    .line 9: return-void
.end method

# direct methods
.method public static mapFromClass(Ljava/lang/Class;)Lai/onnxruntime/OnnxJavaType;
    .registers 2

    .line 0: sget-object v0, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;
    .line 2: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 5: move-result v0
    .line 6: if-nez v0, :cond_153
    .line 8: const-class v0, Ljava/lang/Byte;
    .line 10: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_18
    .line 16: goto/16 :goto_153
    .line 18: sget-object v0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;
    .line 20: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 23: move-result v0
    .line 24: if-nez v0, :cond_150
    .line 26: const-class v0, Ljava/lang/Short;
    .line 28: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 31: move-result v0
    .line 32: if-eqz v0, :cond_36
    .line 34: goto/16 :goto_150
    .line 36: sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 38: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 41: move-result v0
    .line 42: if-nez v0, :cond_147
    .line 44: const-class v0, Ljava/lang/Integer;
    .line 46: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 49: move-result v0
    .line 50: if-eqz v0, :cond_53
    .line 52: goto :goto_147
    .line 53: sget-object v0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 55: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 58: move-result v0
    .line 59: if-nez v0, :cond_144
    .line 61: const-class v0, Ljava/lang/Long;
    .line 63: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 66: move-result v0
    .line 67: if-eqz v0, :cond_70
    .line 69: goto :goto_144
    .line 70: sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;
    .line 72: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 75: move-result v0
    .line 76: if-nez v0, :cond_141
    .line 78: const-class v0, Ljava/lang/Float;
    .line 80: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 83: move-result v0
    .line 84: if-eqz v0, :cond_87
    .line 86: goto :goto_141
    .line 87: sget-object v0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;
    .line 89: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 92: move-result v0
    .line 93: if-nez v0, :cond_138
    .line 95: const-class v0, Ljava/lang/Double;
    .line 97: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 100: move-result v0
    .line 101: if-eqz v0, :cond_104
    .line 103: goto :goto_138
    .line 104: sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 106: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 109: move-result v0
    .line 110: if-nez v0, :cond_135
    .line 112: const-class v0, Ljava/lang/Boolean;
    .line 114: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 117: move-result v0
    .line 118: if-eqz v0, :cond_121
    .line 120: goto :goto_135
    .line 121: const-class v0, Ljava/lang/String;
    .line 123: invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 126: move-result v1
    .line 127: if-eqz v1, :cond_132
    .line 129: sget-object v1, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 131: return-object v1
    .line 132: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 134: return-object v1
    .line 135: sget-object v1, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 137: return-object v1
    .line 138: sget-object v1, Lai/onnxruntime/OnnxJavaType;->DOUBLE:Lai/onnxruntime/OnnxJavaType;
    .line 140: return-object v1
    .line 141: sget-object v1, Lai/onnxruntime/OnnxJavaType;->FLOAT:Lai/onnxruntime/OnnxJavaType;
    .line 143: return-object v1
    .line 144: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT64:Lai/onnxruntime/OnnxJavaType;
    .line 146: return-object v1
    .line 147: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT32:Lai/onnxruntime/OnnxJavaType;
    .line 149: return-object v1
    .line 150: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT16:Lai/onnxruntime/OnnxJavaType;
    .line 152: return-object v1
    .line 153: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT8:Lai/onnxruntime/OnnxJavaType;
    .line 155: return-object v1
.end method

# direct methods
.method public static mapFromInt(I)Lai/onnxruntime/OnnxJavaType;
    .registers 3

    .line 0: if-lez v2, :cond_10
    .line 2: sget-object v0, Lai/onnxruntime/OnnxJavaType;->values:[Lai/onnxruntime/OnnxJavaType;
    .line 4: array-length v1, v0
    .line 5: if-ge v2, v1, :cond_10
    .line 7: aget-object v2, v0, v2
    .line 9: return-object v2
    .line 10: sget-object v2, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 12: return-object v2
.end method

# direct methods
.method public static mapFromOnnxTensorType(Lai/onnxruntime/TensorInfo$OnnxTensorType;)Lai/onnxruntime/OnnxJavaType;
    .registers 2

    .line 0: sget-object v0, Lai/onnxruntime/OnnxJavaType$1;->$SwitchMap$ai$onnxruntime$TensorInfo$OnnxTensorType:[I
    .line 2: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v1, v0, v1
    .line 8: packed-switch v1, :data_48
    .line 11: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UNKNOWN:Lai/onnxruntime/OnnxJavaType;
    .line 13: return-object v1
    .line 14: sget-object v1, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 16: return-object v1
    .line 17: sget-object v1, Lai/onnxruntime/OnnxJavaType;->STRING:Lai/onnxruntime/OnnxJavaType;
    .line 19: return-object v1
    .line 20: sget-object v1, Lai/onnxruntime/OnnxJavaType;->DOUBLE:Lai/onnxruntime/OnnxJavaType;
    .line 22: return-object v1
    .line 23: sget-object v1, Lai/onnxruntime/OnnxJavaType;->FLOAT:Lai/onnxruntime/OnnxJavaType;
    .line 25: return-object v1
    .line 26: sget-object v1, Lai/onnxruntime/OnnxJavaType;->BFLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 28: return-object v1
    .line 29: sget-object v1, Lai/onnxruntime/OnnxJavaType;->FLOAT16:Lai/onnxruntime/OnnxJavaType;
    .line 31: return-object v1
    .line 32: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT64:Lai/onnxruntime/OnnxJavaType;
    .line 34: return-object v1
    .line 35: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT32:Lai/onnxruntime/OnnxJavaType;
    .line 37: return-object v1
    .line 38: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT16:Lai/onnxruntime/OnnxJavaType;
    .line 40: return-object v1
    .line 41: sget-object v1, Lai/onnxruntime/OnnxJavaType;->INT8:Lai/onnxruntime/OnnxJavaType;
    .line 43: return-object v1
    .line 44: sget-object v1, Lai/onnxruntime/OnnxJavaType;->UINT8:Lai/onnxruntime/OnnxJavaType;
    .line 46: return-object v1
    .line 47: nop
    .line 48: nop
    .line 49: return-void
    .line 50: move v0, v0
    .line 51: nop
    .line 52: filled-new-array {}, B
    .line 55: nop
    .line 56: monitor-exit v0
    .line 57: nop
    .line 58: monitor-exit v0
    .line 59: nop
    .line 60: const-string/jumbo v0, "string@1769472"
    .line 63: nop
    .line 64: const-wide v0, 0x150180
    .line 69: nop
    .line 70: const/4 v0, 0
    .line 71: nop
    .line 72: return v0
    .line 73: nop
    .line 74: move-result-object v0
    .line 75: nop
    .line 76: move-object/16 v0, v6
    .line 79: nop
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lai/onnxruntime/OnnxJavaType;
    .registers 2

    .line 0: const-class v0, Lai/onnxruntime/OnnxJavaType;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lai/onnxruntime/OnnxJavaType;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lai/onnxruntime/OnnxJavaType;
    .registers 1

    .line 0: sget-object v0, Lai/onnxruntime/OnnxJavaType;->$VALUES:[Lai/onnxruntime/OnnxJavaType;
    .line 2: invoke-virtual {v0}, [Lai/onnxruntime/OnnxJavaType;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lai/onnxruntime/OnnxJavaType;
    .line 8: return-object v0
.end method

.class public final Lai/onnxruntime/platform/Fp16Conversions;
.super Ljava/lang/Object;
.source "SourceFile"

.field private static final logger:Ljava/util/logging/Logger;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-class v0, Lai/onnxruntime/platform/Fp16Conversions;
    .line 2: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lai/onnxruntime/platform/Fp16Conversions;->logger:Ljava/util/logging/Logger;
    .line 12: return-void
.end method

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static bf16ToFloat(S)F
    .registers 1

    .line 0: shl-int/lit8 v0, v0, 16
    .line 2: invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 5: move-result v0
    .line 6: return v0
.end method

# direct methods
.method public static convertBf16BufferToFloatBuffer(Ljava/nio/ShortBuffer;)Ljava/nio/FloatBuffer;
    .registers 6

    .line 0: invoke-virtual {v5}, Ljava/nio/Buffer;->position()I
    .line 3: move-result v0
    .line 4: invoke-virtual {v5}, Ljava/nio/Buffer;->remaining()I
    .line 7: move-result v1
    .line 8: mul-int/lit8 v2, v1, 4
    .line 10: invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;
    .line 13: move-result-object v2
    .line 14: invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;
    .line 17: move-result-object v3
    .line 18: invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    .line 21: move-result-object v2
    .line 22: invoke-virtual {v2}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;
    .line 25: move-result-object v2
    .line 26: const/4 v3, 0
    .line 27: if-ge v3, v1, :cond_45
    .line 29: add-int v4, v3, v0
    .line 31: invoke-virtual {v5, v4}, Ljava/nio/ShortBuffer;->get(I)S
    .line 34: move-result v4
    .line 35: invoke-static {v4}, Lai/onnxruntime/platform/Fp16Conversions;->bf16ToFloat(S)F
    .line 38: move-result v4
    .line 39: invoke-virtual {v2, v3, v4}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;
    .line 42: add-int/lit8 v3, v3, 1
    .line 44: goto :goto_27
    .line 45: return-object v2
.end method

# direct methods
.method public static convertFloatBufferToBf16Buffer(Ljava/nio/FloatBuffer;)Ljava/nio/ShortBuffer;
    .registers 6

    .line 0: invoke-virtual {v5}, Ljava/nio/Buffer;->position()I
    .line 3: move-result v0
    .line 4: invoke-virtual {v5}, Ljava/nio/Buffer;->remaining()I
    .line 7: move-result v1
    .line 8: mul-int/lit8 v2, v1, 2
    .line 10: invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;
    .line 13: move-result-object v2
    .line 14: invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;
    .line 17: move-result-object v3
    .line 18: invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    .line 21: move-result-object v2
    .line 22: invoke-virtual {v2}, Ljava/nio/ByteBuffer;->asShortBuffer()Ljava/nio/ShortBuffer;
    .line 25: move-result-object v2
    .line 26: const/4 v3, 0
    .line 27: if-ge v3, v1, :cond_45
    .line 29: add-int v4, v3, v0
    .line 31: invoke-virtual {v5, v4}, Ljava/nio/FloatBuffer;->get(I)F
    .line 34: move-result v4
    .line 35: invoke-static {v4}, Lai/onnxruntime/platform/Fp16Conversions;->floatToBf16(F)S
    .line 38: move-result v4
    .line 39: invoke-virtual {v2, v3, v4}, Ljava/nio/ShortBuffer;->put(IS)Ljava/nio/ShortBuffer;
    .line 42: add-int/lit8 v3, v3, 1
    .line 44: goto :goto_27
    .line 45: return-object v2
.end method

# direct methods
.method public static convertFloatBufferToFp16Buffer(Ljava/nio/FloatBuffer;)Ljava/nio/ShortBuffer;
    .registers 6

    .line 0: invoke-virtual {v5}, Ljava/nio/Buffer;->position()I
    .line 3: move-result v0
    .line 4: invoke-virtual {v5}, Ljava/nio/Buffer;->remaining()I
    .line 7: move-result v1
    .line 8: mul-int/lit8 v2, v1, 2
    .line 10: invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;
    .line 13: move-result-object v2
    .line 14: invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;
    .line 17: move-result-object v3
    .line 18: invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    .line 21: move-result-object v2
    .line 22: invoke-virtual {v2}, Ljava/nio/ByteBuffer;->asShortBuffer()Ljava/nio/ShortBuffer;
    .line 25: move-result-object v2
    .line 26: const/4 v3, 0
    .line 27: if-ge v3, v1, :cond_45
    .line 29: add-int v4, v3, v0
    .line 31: invoke-virtual {v5, v4}, Ljava/nio/FloatBuffer;->get(I)F
    .line 34: move-result v4
    .line 35: invoke-static {v4}, Lai/onnxruntime/platform/Fp16Conversions;->floatToFp16(F)S
    .line 38: move-result v4
    .line 39: invoke-virtual {v2, v3, v4}, Ljava/nio/ShortBuffer;->put(IS)Ljava/nio/ShortBuffer;
    .line 42: add-int/lit8 v3, v3, 1
    .line 44: goto :goto_27
    .line 45: return-object v2
.end method

# direct methods
.method public static convertFp16BufferToFloatBuffer(Ljava/nio/ShortBuffer;)Ljava/nio/FloatBuffer;
    .registers 6

    .line 0: invoke-virtual {v5}, Ljava/nio/Buffer;->position()I
    .line 3: move-result v0
    .line 4: invoke-virtual {v5}, Ljava/nio/Buffer;->remaining()I
    .line 7: move-result v1
    .line 8: mul-int/lit8 v2, v1, 4
    .line 10: invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;
    .line 13: move-result-object v2
    .line 14: invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;
    .line 17: move-result-object v3
    .line 18: invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    .line 21: move-result-object v2
    .line 22: invoke-virtual {v2}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;
    .line 25: move-result-object v2
    .line 26: const/4 v3, 0
    .line 27: if-ge v3, v1, :cond_45
    .line 29: add-int v4, v3, v0
    .line 31: invoke-virtual {v5, v4}, Ljava/nio/ShortBuffer;->get(I)S
    .line 34: move-result v4
    .line 35: invoke-static {v4}, Lai/onnxruntime/platform/Fp16Conversions;->fp16ToFloat(S)F
    .line 38: move-result v4
    .line 39: invoke-virtual {v2, v3, v4}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;
    .line 42: add-int/lit8 v3, v3, 1
    .line 44: goto :goto_27
    .line 45: return-object v2
.end method

# direct methods
.method public static floatToBf16(F)S
    .registers 2

    .line 0: invoke-static {v1}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v1
    .line 4: shr-int/lit8 v0, v1, 16
    .line 6: and-int/lit8 v0, v0, 1
    .line 8: add-int/lit16 v0, v0, 32767
    .line 10: add-int/2addr v0, v1
    .line 11: shr-int/lit8 v1, v0, 16
    .line 13: int-to-short v1, v1
    .line 14: return v1
.end method

# direct methods
.method public static floatToFp16(F)S
    .registers 1

    .line 0: invoke-static {v0}, Lai/onnxruntime/platform/Fp16Conversions;->mlasFloatToFp16(F)S
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static fp16ToFloat(S)F
    .registers 1

    .line 0: invoke-static {v0}, Lai/onnxruntime/platform/Fp16Conversions;->mlasFp16ToFloat(S)F
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static mlasFloatToFp16(F)S
    .registers 4

    .line 0: invoke-static {v3}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v3
    .line 4: const/high16 v0, 0x7f80
    .line 6: invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 9: move-result v0
    .line 10: const/high16 v1, 0x8000
    .line 12: and-int/2addr v1, v3
    .line 13: xor-int/2addr v3, v1
    .line 14: const/high16 v2, 0x4780
    .line 16: if-lt v3, v2, :cond_26
    .line 18: if-le v3, v0, :cond_23
    .line 20: const/16 v3, 32256
    .line 22: goto :goto_60
    .line 23: const/16 v3, 31744
    .line 25: goto :goto_60
    .line 26: const/high16 v0, 0x3880
    .line 28: if-ge v3, v0, :cond_48
    .line 30: invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 33: move-result v3
    .line 34: const/high16 v0, 0x3f00
    .line 36: invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 39: move-result v2
    .line 40: add-float/2addr v2, v3
    .line 41: invoke-static {v2}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 44: move-result v3
    .line 45: sub-int/2addr v3, v0
    .line 46: int-to-short v3, v3
    .line 47: goto :goto_60
    .line 48: shr-int/lit8 v0, v3, 13
    .line 50: and-int/lit8 v0, v0, 1
    .line 52: const v2, 0x37fff001
    .line 55: sub-int/2addr v3, v2
    .line 56: add-int/2addr v3, v0
    .line 57: shr-int/lit8 v3, v3, 13
    .line 59: goto :goto_46
    .line 60: shr-int/lit8 v0, v1, 16
    .line 62: int-to-short v0, v0
    .line 63: or-int/2addr v3, v0
    .line 64: int-to-short v3, v3
    .line 65: return v3
.end method

# direct methods
.method public static mlasFp16ToFloat(S)F
    .registers 5

    .line 0: and-int/lit16 v0, v4, 32767
    .line 2: shl-int/lit8 v0, v0, 13
    .line 4: const/high16 v1, 0xf80
    .line 6: and-int v2, v0, v1
    .line 8: const/high16 v3, 0x3800
    .line 10: add-int/2addr v3, v0
    .line 11: if-ne v2, v1, :cond_18
    .line 13: const/high16 v1, 0x7000
    .line 15: add-int v3, v0, v1
    .line 17: goto :goto_36
    .line 18: if-nez v2, :cond_36
    .line 20: const/high16 v1, 0x3880
    .line 22: add-int/2addr v0, v1
    .line 23: invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 26: move-result v0
    .line 27: invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 30: move-result v1
    .line 31: sub-float/2addr v0, v1
    .line 32: invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 35: move-result v3
    .line 36: const v0, 0x8000
    .line 39: and-int/2addr v4, v0
    .line 40: shl-int/lit8 v4, v4, 16
    .line 42: or-int/2addr v4, v3
    .line 43: invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 46: move-result v4
    .line 47: return v4
.end method

.class public Lf/k;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static l:[Ljava/lang/Object;
.field public static m:I
.field public static n:[Ljava/lang/Object;
.field public static o:I

.field public i:[I
.field public j:[Ljava/lang/Object;
.field public k:I

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: sget-object v0, Lf/d;->a:[I
    .line 5: iput-object v0, v1, Lf/k;->i:[I
    .line 7: sget-object v0, Lf/d;->b:[Ljava/lang/Object;
    .line 9: iput-object v0, v1, Lf/k;->j:[Ljava/lang/Object;
    .line 11: const/4 v0, 0
    .line 12: iput v0, v1, Lf/k;->k:I
    .line 14: return-void
.end method

# direct methods
.method public static c([I[Ljava/lang/Object;I)V
    .registers 10

    .line 0: array-length v0, v7
    .line 1: const/16 v1, 8
    .line 3: const/4 v2, 0
    .line 4: const/4 v3, 2
    .line 5: const/4 v4, 0
    .line 6: const/16 v5, 10
    .line 8: const/4 v6, 1
    .line 9: if-ne v0, v1, :cond_47
    .line 11: const-class v0, Lf/k;
    .line 13: monitor-enter v0
    .line 14: sget v1, Lf/k;->o:I
    .line 16: if-ge v1, v5, :cond_43
    .line 18: sget-object v1, Lf/k;->n:[Ljava/lang/Object;
    .line 20: aput-object v1, v8, v4
    .line 22: aput-object v7, v8, v6
    .line 24: shl-int/lit8 v7, v9, 1
    .line 26: sub-int/2addr v7, v6
    .line 27: if-lt v7, v3, :cond_36
    .line 29: aput-object v2, v8, v7
    .line 31: add-int/lit8 v7, v7, -1
    .line 33: goto :goto_27
    .line 34: move-exception v7
    .line 35: goto :goto_45
    .line 36: sput-object v8, Lf/k;->n:[Ljava/lang/Object;
    .line 38: sget v7, Lf/k;->o:I
    .line 40: add-int/2addr v7, v6
    .line 41: sput v7, Lf/k;->o:I
    .line 43: monitor-exit v0
    .line 44: goto :goto_87
    .line 45: monitor-exit v0
    .line 46: throw v7
    .line 47: array-length v0, v7
    .line 48: const/4 v1, 4
    .line 49: if-ne v0, v1, :cond_87
    .line 51: const-class v0, Lf/k;
    .line 53: monitor-enter v0
    .line 54: sget v1, Lf/k;->m:I
    .line 56: if-ge v1, v5, :cond_83
    .line 58: sget-object v1, Lf/k;->l:[Ljava/lang/Object;
    .line 60: aput-object v1, v8, v4
    .line 62: aput-object v7, v8, v6
    .line 64: shl-int/lit8 v7, v9, 1
    .line 66: sub-int/2addr v7, v6
    .line 67: if-lt v7, v3, :cond_76
    .line 69: aput-object v2, v8, v7
    .line 71: add-int/lit8 v7, v7, -1
    .line 73: goto :goto_67
    .line 74: move-exception v7
    .line 75: goto :goto_85
    .line 76: sput-object v8, Lf/k;->l:[Ljava/lang/Object;
    .line 78: sget v7, Lf/k;->m:I
    .line 80: add-int/2addr v7, v6
    .line 81: sput v7, Lf/k;->m:I
    .line 83: monitor-exit v0
    .line 84: goto :goto_87
    .line 85: monitor-exit v0
    .line 86: throw v7
    .line 87: return-void
.end method

# virtual methods
.method public final b(I)V
    .registers 7

    .line 0: const/16 v0, 8
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 0
    .line 4: const/4 v3, 1
    .line 5: if-ne v6, v0, :cond_45
    .line 7: const-class v0, Lf/k;
    .line 9: monitor-enter v0
    .line 10: sget-object v4, Lf/k;->n:[Ljava/lang/Object;
    .line 12: if-eqz v4, :cond_41
    .line 14: iput-object v4, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 16: aget-object v6, v4, v2
    .line 18: check-cast v6, [Ljava/lang/Object;
    .line 20: sput-object v6, Lf/k;->n:[Ljava/lang/Object;
    .line 22: aget-object v6, v4, v3
    .line 24: check-cast v6, [I
    .line 26: iput-object v6, v5, Lf/k;->i:[I
    .line 28: aput-object v1, v4, v3
    .line 30: aput-object v1, v4, v2
    .line 32: sget v6, Lf/k;->o:I
    .line 34: sub-int/2addr v6, v3
    .line 35: sput v6, Lf/k;->o:I
    .line 37: monitor-exit v0
    .line 38: return-void
    .line 39: move-exception v6
    .line 40: goto :goto_43
    .line 41: monitor-exit v0
    .line 42: goto :goto_86
    .line 43: monitor-exit v0
    .line 44: throw v6
    .line 45: const/4 v0, 4
    .line 46: if-ne v6, v0, :cond_86
    .line 48: const-class v0, Lf/k;
    .line 50: monitor-enter v0
    .line 51: sget-object v4, Lf/k;->l:[Ljava/lang/Object;
    .line 53: if-eqz v4, :cond_82
    .line 55: iput-object v4, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 57: aget-object v6, v4, v2
    .line 59: check-cast v6, [Ljava/lang/Object;
    .line 61: sput-object v6, Lf/k;->l:[Ljava/lang/Object;
    .line 63: aget-object v6, v4, v3
    .line 65: check-cast v6, [I
    .line 67: iput-object v6, v5, Lf/k;->i:[I
    .line 69: aput-object v1, v4, v3
    .line 71: aput-object v1, v4, v2
    .line 73: sget v6, Lf/k;->m:I
    .line 75: sub-int/2addr v6, v3
    .line 76: sput v6, Lf/k;->m:I
    .line 78: monitor-exit v0
    .line 79: return-void
    .line 80: move-exception v6
    .line 81: goto :goto_84
    .line 82: monitor-exit v0
    .line 83: goto :goto_86
    .line 84: monitor-exit v0
    .line 85: throw v6
    .line 86: new-array v0, v6, [I
    .line 88: iput-object v0, v5, Lf/k;->i:[I
    .line 90: shl-int/2addr v6, v3
    .line 91: new-array v6, v6, [Ljava/lang/Object;
    .line 93: iput-object v6, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 95: return-void
.end method

# virtual methods
.method public final clear()V
    .registers 5

    .line 0: iget v0, v4, Lf/k;->k:I
    .line 2: if-lez v0, :cond_22
    .line 4: iget-object v1, v4, Lf/k;->i:[I
    .line 6: iget-object v2, v4, Lf/k;->j:[Ljava/lang/Object;
    .line 8: sget-object v3, Lf/d;->a:[I
    .line 10: iput-object v3, v4, Lf/k;->i:[I
    .line 12: sget-object v3, Lf/d;->b:[Ljava/lang/Object;
    .line 14: iput-object v3, v4, Lf/k;->j:[Ljava/lang/Object;
    .line 16: const/4 v3, 0
    .line 17: iput v3, v4, Lf/k;->k:I
    .line 19: invoke-static {v1, v2, v0}, Lf/k;->c([I[Ljava/lang/Object;I)V
    .line 22: iget v0, v4, Lf/k;->k:I
    .line 24: if-gtz v0, :cond_27
    .line 26: return-void
    .line 27: new-instance v0, Ljava/util/ConcurrentModificationException;
    .line 29: invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 32: throw v0
.end method

# virtual methods
.method public final containsKey(Ljava/lang/Object;)Z
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Lf/k;->f(Ljava/lang/Object;)I
    .line 3: move-result v1
    .line 4: if-ltz v1, :cond_8
    .line 6: const/4 v1, 1
    .line 7: goto :goto_9
    .line 8: const/4 v1, 0
    .line 9: return v1
.end method

# virtual methods
.method public final containsValue(Ljava/lang/Object;)Z
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Lf/k;->h(Ljava/lang/Object;)I
    .line 3: move-result v1
    .line 4: if-ltz v1, :cond_8
    .line 6: const/4 v1, 1
    .line 7: goto :goto_9
    .line 8: const/4 v1, 0
    .line 9: return v1
.end method

# virtual methods
.method public final e(ILjava/lang/Object;)I
    .registers 8

    .line 0: iget v0, v5, Lf/k;->k:I
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v6, -1
    .line 5: return v6
    .line 6: iget-object v1, v5, Lf/k;->i:[I
    .line 8: invoke-static {v1, v0, v6}, Lf/d;->a([III)I
    .line 11: move-result v1
    .line 12: if-gez v1, :cond_15
    .line 14: return v1
    .line 15: iget-object v2, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 17: shl-int/lit8 v3, v1, 1
    .line 19: aget-object v2, v2, v3
    .line 21: invoke-virtual {v7, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 24: move-result v2
    .line 25: if-eqz v2, :cond_28
    .line 27: return v1
    .line 28: add-int/lit8 v2, v1, 1
    .line 30: if-ge v2, v0, :cond_54
    .line 32: iget-object v3, v5, Lf/k;->i:[I
    .line 34: aget v3, v3, v2
    .line 36: if-ne v3, v6, :cond_54
    .line 38: iget-object v3, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 40: shl-int/lit8 v4, v2, 1
    .line 42: aget-object v3, v3, v4
    .line 44: invoke-virtual {v7, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 47: move-result v3
    .line 48: if-eqz v3, :cond_51
    .line 50: return v2
    .line 51: add-int/lit8 v2, v2, 1
    .line 53: goto :goto_30
    .line 54: add-int/lit8 v1, v1, -1
    .line 56: if-ltz v1, :cond_80
    .line 58: iget-object v0, v5, Lf/k;->i:[I
    .line 60: aget v0, v0, v1
    .line 62: if-ne v0, v6, :cond_80
    .line 64: iget-object v0, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 66: shl-int/lit8 v3, v1, 1
    .line 68: aget-object v0, v0, v3
    .line 70: invoke-virtual {v7, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 73: move-result v0
    .line 74: if-eqz v0, :cond_77
    .line 76: return v1
    .line 77: add-int/lit8 v1, v1, -1
    .line 79: goto :goto_56
    .line 80: not-int v6, v2
    .line 81: return v6
    .line 82: new-instance v6, Ljava/util/ConcurrentModificationException;
    .line 84: invoke-direct {v6}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 87: throw v6
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    .line 0: const/4 v0, 1
    .line 1: if-ne v6, v7, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v7, Lf/k;
    .line 6: const/4 v2, 0
    .line 7: if-eqz v1, :cond_61
    .line 9: check-cast v7, Lf/k;
    .line 11: iget v1, v6, Lf/k;->k:I
    .line 13: iget v3, v7, Lf/k;->k:I
    .line 15: if-eq v1, v3, :cond_18
    .line 17: return v2
    .line 18: move v1, v2
    .line 19: iget v3, v6, Lf/k;->k:I
    .line 21: if-ge v1, v3, :cond_59
    .line 23: iget-object v3, v6, Lf/k;->j:[Ljava/lang/Object;
    .line 25: shl-int/lit8 v4, v1, 1
    .line 27: aget-object v5, v3, v4
    .line 29: add-int/lit8 v4, v4, 1
    .line 31: aget-object v3, v3, v4
    .line 33: const/4 v4, 0
    .line 34: invoke-virtual {v7, v5, v4}, Lf/k;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 37: move-result-object v4
    .line 38: if-nez v3, :cond_49
    .line 40: if-nez v4, :cond_48
    .line 42: invoke-virtual {v7, v5}, Lf/k;->containsKey(Ljava/lang/Object;)Z
    .line 45: move-result v3
    .line 46: if-nez v3, :cond_56
    .line 48: return v2
    .line 49: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 52: move-result v3
    .line 53: if-nez v3, :cond_56
    .line 55: return v2
    .line 56: add-int/lit8 v1, v1, 1
    .line 58: goto :goto_19
    .line 59: return v0
    .line 60: return v2
    .line 61: instance-of v1, v7, Ljava/util/Map;
    .line 63: if-eqz v1, :cond_117
    .line 65: check-cast v7, Ljava/util/Map;
    .line 67: iget v1, v6, Lf/k;->k:I
    .line 69: invoke-interface {v7}, Ljava/util/Map;->size()I
    .line 72: move-result v3
    .line 73: if-eq v1, v3, :cond_76
    .line 75: return v2
    .line 76: move v1, v2
    .line 77: iget v3, v6, Lf/k;->k:I
    .line 79: if-ge v1, v3, :cond_116
    .line 81: iget-object v3, v6, Lf/k;->j:[Ljava/lang/Object;
    .line 83: shl-int/lit8 v4, v1, 1
    .line 85: aget-object v5, v3, v4
    .line 87: add-int/lit8 v4, v4, 1
    .line 89: aget-object v3, v3, v4
    .line 91: invoke-interface {v7, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 94: move-result-object v4
    .line 95: if-nez v3, :cond_106
    .line 97: if-nez v4, :cond_105
    .line 99: invoke-interface {v7, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 102: move-result v3
    .line 103: if-nez v3, :cond_113
    .line 105: return v2
    .line 106: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 109: move-result v3
    .line 110: if-nez v3, :cond_113
    .line 112: return v2
    .line 113: add-int/lit8 v1, v1, 1
    .line 115: goto :goto_77
    .line 116: return v0
    .line 117: return v2
.end method

# virtual methods
.method public final f(Ljava/lang/Object;)I
    .registers 3

    .line 0: if-nez v2, :cond_7
    .line 2: invoke-virtual {v1}, Lf/k;->g()I
    .line 5: move-result v2
    .line 6: goto :goto_15
    .line 7: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 10: move-result v0
    .line 11: invoke-virtual {v1, v0, v2}, Lf/k;->e(ILjava/lang/Object;)I
    .line 14: move-result v2
    .line 15: return v2
.end method

# virtual methods
.method public final g()I
    .registers 6

    .line 0: iget v0, v5, Lf/k;->k:I
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, -1
    .line 5: return v0
    .line 6: iget-object v1, v5, Lf/k;->i:[I
    .line 8: const/4 v2, 0
    .line 9: invoke-static {v1, v0, v2}, Lf/d;->a([III)I
    .line 12: move-result v1
    .line 13: if-gez v1, :cond_16
    .line 15: return v1
    .line 16: iget-object v2, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 18: shl-int/lit8 v3, v1, 1
    .line 20: aget-object v2, v2, v3
    .line 22: if-nez v2, :cond_25
    .line 24: return v1
    .line 25: add-int/lit8 v2, v1, 1
    .line 27: if-ge v2, v0, :cond_47
    .line 29: iget-object v3, v5, Lf/k;->i:[I
    .line 31: aget v3, v3, v2
    .line 33: if-nez v3, :cond_47
    .line 35: iget-object v3, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 37: shl-int/lit8 v4, v2, 1
    .line 39: aget-object v3, v3, v4
    .line 41: if-nez v3, :cond_44
    .line 43: return v2
    .line 44: add-int/lit8 v2, v2, 1
    .line 46: goto :goto_27
    .line 47: add-int/lit8 v1, v1, -1
    .line 49: if-ltz v1, :cond_69
    .line 51: iget-object v0, v5, Lf/k;->i:[I
    .line 53: aget v0, v0, v1
    .line 55: if-nez v0, :cond_69
    .line 57: iget-object v0, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 59: shl-int/lit8 v3, v1, 1
    .line 61: aget-object v0, v0, v3
    .line 63: if-nez v0, :cond_66
    .line 65: return v1
    .line 66: add-int/lit8 v1, v1, -1
    .line 68: goto :goto_49
    .line 69: not-int v0, v2
    .line 70: return v0
    .line 71: new-instance v0, Ljava/util/ConcurrentModificationException;
    .line 73: invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 76: throw v0
.end method

# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v2, v0}, Lf/k;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 4: move-result-object v2
    .line 5: return-object v2
.end method

# virtual methods
.method public final getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0: invoke-virtual {v0, v1}, Lf/k;->f(Ljava/lang/Object;)I
    .line 3: move-result v1
    .line 4: if-ltz v1, :cond_14
    .line 6: iget-object v2, v0, Lf/k;->j:[Ljava/lang/Object;
    .line 8: shl-int/lit8 v1, v1, 1
    .line 10: add-int/lit8 v1, v1, 1
    .line 12: aget-object v2, v2, v1
    .line 14: return-object v2
.end method

# virtual methods
.method public final h(Ljava/lang/Object;)I
    .registers 7

    .line 0: iget v0, v5, Lf/k;->k:I
    .line 2: mul-int/lit8 v0, v0, 2
    .line 4: iget-object v1, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 6: const/4 v2, 1
    .line 7: if-nez v6, :cond_21
    .line 9: move v6, v2
    .line 10: if-ge v6, v0, :cond_38
    .line 12: aget-object v3, v1, v6
    .line 14: if-nez v3, :cond_18
    .line 16: shr-int/2addr v6, v2
    .line 17: return v6
    .line 18: add-int/lit8 v6, v6, 2
    .line 20: goto :goto_10
    .line 21: move v3, v2
    .line 22: if-ge v3, v0, :cond_38
    .line 24: aget-object v4, v1, v3
    .line 26: invoke-virtual {v6, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 29: move-result v4
    .line 30: if-eqz v4, :cond_35
    .line 32: shr-int/lit8 v6, v3, 1
    .line 34: return v6
    .line 35: add-int/lit8 v3, v3, 2
    .line 37: goto :goto_22
    .line 38: const/4 v6, -1
    .line 39: return v6
.end method

# virtual methods
.method public final hashCode()I
    .registers 10

    .line 0: iget-object v0, v9, Lf/k;->i:[I
    .line 2: iget-object v1, v9, Lf/k;->j:[Ljava/lang/Object;
    .line 4: iget v2, v9, Lf/k;->k:I
    .line 6: const/4 v3, 0
    .line 7: const/4 v4, 1
    .line 8: move v5, v3
    .line 9: move v6, v5
    .line 10: if-ge v5, v2, :cond_31
    .line 12: aget-object v7, v1, v4
    .line 14: aget v8, v0, v5
    .line 16: if-nez v7, :cond_20
    .line 18: move v7, v3
    .line 19: goto :goto_24
    .line 20: invoke-virtual {v7}, Ljava/lang/Object;->hashCode()I
    .line 23: move-result v7
    .line 24: xor-int/2addr v7, v8
    .line 25: add-int/2addr v6, v7
    .line 26: add-int/lit8 v5, v5, 1
    .line 28: add-int/lit8 v4, v4, 2
    .line 30: goto :goto_10
    .line 31: return v6
.end method

# virtual methods
.method public final i(I)Ljava/lang/Object;
    .registers 12

    .line 0: iget-object v0, v10, Lf/k;->j:[Ljava/lang/Object;
    .line 2: shl-int/lit8 v1, v11, 1
    .line 4: add-int/lit8 v2, v1, 1
    .line 6: aget-object v2, v0, v2
    .line 8: iget v3, v10, Lf/k;->k:I
    .line 10: const/4 v4, 0
    .line 11: const/4 v5, 1
    .line 12: if-gt v3, v5, :cond_28
    .line 14: iget-object v11, v10, Lf/k;->i:[I
    .line 16: invoke-static {v11, v0, v3}, Lf/k;->c([I[Ljava/lang/Object;I)V
    .line 19: sget-object v11, Lf/d;->a:[I
    .line 21: iput-object v11, v10, Lf/k;->i:[I
    .line 23: sget-object v11, Lf/d;->b:[Ljava/lang/Object;
    .line 25: iput-object v11, v10, Lf/k;->j:[Ljava/lang/Object;
    .line 27: goto :goto_121
    .line 28: add-int/lit8 v6, v3, -1
    .line 30: iget-object v7, v10, Lf/k;->i:[I
    .line 32: array-length v8, v7
    .line 33: const/16 v9, 8
    .line 35: if-le v8, v9, :cond_94
    .line 37: array-length v8, v7
    .line 38: div-int/lit8 v8, v8, 3
    .line 40: if-ge v3, v8, :cond_94
    .line 42: if-le v3, v9, :cond_48
    .line 44: shr-int/lit8 v8, v3, 1
    .line 46: add-int v9, v3, v8
    .line 48: invoke-virtual {v10, v9}, Lf/k;->b(I)V
    .line 51: iget v8, v10, Lf/k;->k:I
    .line 53: if-ne v3, v8, :cond_88
    .line 55: if-lez v11, :cond_67
    .line 57: iget-object v8, v10, Lf/k;->i:[I
    .line 59: invoke-static {v7, v4, v8, v4, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 62: iget-object v8, v10, Lf/k;->j:[Ljava/lang/Object;
    .line 64: invoke-static {v0, v4, v8, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 67: if-ge v11, v6, :cond_120
    .line 69: add-int/lit8 v4, v11, 1
    .line 71: iget-object v8, v10, Lf/k;->i:[I
    .line 73: sub-int v9, v6, v11
    .line 75: invoke-static {v7, v4, v8, v11, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 78: shl-int/lit8 v11, v4, 1
    .line 80: iget-object v4, v10, Lf/k;->j:[Ljava/lang/Object;
    .line 82: shl-int/lit8 v5, v9, 1
    .line 84: invoke-static {v0, v11, v4, v1, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 87: goto :goto_120
    .line 88: new-instance v11, Ljava/util/ConcurrentModificationException;
    .line 90: invoke-direct {v11}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 93: throw v11
    .line 94: if-ge v11, v6, :cond_110
    .line 96: add-int/lit8 v0, v11, 1
    .line 98: sub-int v4, v6, v11
    .line 100: invoke-static {v7, v0, v7, v11, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 103: iget-object v11, v10, Lf/k;->j:[Ljava/lang/Object;
    .line 105: shl-int/2addr v0, v5
    .line 106: shl-int/2addr v4, v5
    .line 107: invoke-static {v11, v0, v11, v1, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 110: iget-object v11, v10, Lf/k;->j:[Ljava/lang/Object;
    .line 112: shl-int/lit8 v0, v6, 1
    .line 114: const/4 v1, 0
    .line 115: aput-object v1, v11, v0
    .line 117: add-int/2addr v0, v5
    .line 118: aput-object v1, v11, v0
    .line 120: move v4, v6
    .line 121: iget v11, v10, Lf/k;->k:I
    .line 123: if-ne v3, v11, :cond_128
    .line 125: iput v4, v10, Lf/k;->k:I
    .line 127: return-object v2
    .line 128: new-instance v11, Ljava/util/ConcurrentModificationException;
    .line 130: invoke-direct {v11}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 133: throw v11
.end method

# virtual methods
.method public final isEmpty()Z
    .registers 2

    .line 0: iget v0, v1, Lf/k;->k:I
    .line 2: if-gtz v0, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_7
    .line 6: const/4 v0, 0
    .line 7: return v0
.end method

# virtual methods
.method public final put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 0: iget v0, v9, Lf/k;->k:I
    .line 2: const/4 v1, 0
    .line 3: if-nez v10, :cond_11
    .line 5: invoke-virtual {v9}, Lf/k;->g()I
    .line 8: move-result v2
    .line 9: move v3, v1
    .line 10: goto :goto_22
    .line 11: invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I
    .line 14: move-result v2
    .line 15: invoke-virtual {v9, v2, v10}, Lf/k;->e(ILjava/lang/Object;)I
    .line 18: move-result v3
    .line 19: move v8, v3
    .line 20: move v3, v2
    .line 21: move v2, v8
    .line 22: if-ltz v2, :cond_35
    .line 24: shl-int/lit8 v10, v2, 1
    .line 26: add-int/lit8 v10, v10, 1
    .line 28: iget-object v0, v9, Lf/k;->j:[Ljava/lang/Object;
    .line 30: aget-object v1, v0, v10
    .line 32: aput-object v11, v0, v10
    .line 34: return-object v1
    .line 35: not-int v2, v2
    .line 36: iget-object v4, v9, Lf/k;->i:[I
    .line 38: array-length v5, v4
    .line 39: if-lt v0, v5, :cond_88
    .line 41: const/16 v5, 8
    .line 43: if-lt v0, v5, :cond_49
    .line 45: shr-int/lit8 v5, v0, 1
    .line 47: add-int/2addr v5, v0
    .line 48: goto :goto_54
    .line 49: const/4 v6, 4
    .line 50: if-lt v0, v6, :cond_53
    .line 52: goto :goto_54
    .line 53: move v5, v6
    .line 54: iget-object v6, v9, Lf/k;->j:[Ljava/lang/Object;
    .line 56: invoke-virtual {v9, v5}, Lf/k;->b(I)V
    .line 59: iget v5, v9, Lf/k;->k:I
    .line 61: if-ne v0, v5, :cond_82
    .line 63: iget-object v5, v9, Lf/k;->i:[I
    .line 65: array-length v7, v5
    .line 66: if-lez v7, :cond_78
    .line 68: array-length v7, v4
    .line 69: invoke-static {v4, v1, v5, v1, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 72: iget-object v5, v9, Lf/k;->j:[Ljava/lang/Object;
    .line 74: array-length v7, v6
    .line 75: invoke-static {v6, v1, v5, v1, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 78: invoke-static {v4, v6, v0}, Lf/k;->c([I[Ljava/lang/Object;I)V
    .line 81: goto :goto_88
    .line 82: new-instance v10, Ljava/util/ConcurrentModificationException;
    .line 84: invoke-direct {v10}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 87: throw v10
    .line 88: if-ge v2, v0, :cond_113
    .line 90: iget-object v1, v9, Lf/k;->i:[I
    .line 92: add-int/lit8 v4, v2, 1
    .line 94: sub-int v5, v0, v2
    .line 96: invoke-static {v1, v2, v1, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 99: iget-object v1, v9, Lf/k;->j:[Ljava/lang/Object;
    .line 101: shl-int/lit8 v5, v2, 1
    .line 103: shl-int/lit8 v4, v4, 1
    .line 105: iget v6, v9, Lf/k;->k:I
    .line 107: sub-int/2addr v6, v2
    .line 108: shl-int/lit8 v6, v6, 1
    .line 110: invoke-static {v1, v5, v1, v4, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 113: iget v1, v9, Lf/k;->k:I
    .line 115: if-ne v0, v1, :cond_140
    .line 117: iget-object v0, v9, Lf/k;->i:[I
    .line 119: array-length v4, v0
    .line 120: if-ge v2, v4, :cond_140
    .line 122: aput v3, v0, v2
    .line 124: iget-object v0, v9, Lf/k;->j:[Ljava/lang/Object;
    .line 126: shl-int/lit8 v2, v2, 1
    .line 128: aput-object v10, v0, v2
    .line 130: add-int/lit8 v2, v2, 1
    .line 132: aput-object v11, v0, v2
    .line 134: add-int/lit8 v1, v1, 1
    .line 136: iput v1, v9, Lf/k;->k:I
    .line 138: const/4 v10, 0
    .line 139: return-object v10
    .line 140: new-instance v10, Ljava/util/ConcurrentModificationException;
    .line 142: invoke-direct {v10}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 145: throw v10
.end method

# virtual methods
.method public final putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v2, v0}, Lf/k;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 4: move-result-object v0
    .line 5: if-nez v0, :cond_11
    .line 7: invoke-virtual {v1, v2, v3}, Lf/k;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public final remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Lf/k;->f(Ljava/lang/Object;)I
    .line 3: move-result v1
    .line 4: if-ltz v1, :cond_11
    .line 6: invoke-virtual {v0, v1}, Lf/k;->i(I)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: return-object v1
    .line 11: const/4 v1, 0
    .line 12: return-object v1
.end method

# virtual methods
.method public final remove(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 6

    .line 0: invoke-virtual {v3, v4}, Lf/k;->f(Ljava/lang/Object;)I
    .line 3: move-result v4
    .line 4: if-ltz v4, :cond_28
    .line 6: iget-object v0, v3, Lf/k;->j:[Ljava/lang/Object;
    .line 8: shl-int/lit8 v1, v4, 1
    .line 10: const/4 v2, 1
    .line 11: add-int/2addr v1, v2
    .line 12: aget-object v0, v0, v1
    .line 14: if-eq v5, v0, :cond_24
    .line 16: if-eqz v5, :cond_28
    .line 18: invoke-virtual {v5, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 21: move-result v5
    .line 22: if-eqz v5, :cond_28
    .line 24: invoke-virtual {v3, v4}, Lf/k;->i(I)Ljava/lang/Object;
    .line 27: return v2
    .line 28: const/4 v4, 0
    .line 29: return v4
.end method

# virtual methods
.method public final replace(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0: invoke-virtual {v2, v3}, Lf/k;->f(Ljava/lang/Object;)I
    .line 3: move-result v3
    .line 4: if-ltz v3, :cond_17
    .line 6: shl-int/lit8 v3, v3, 1
    .line 8: add-int/lit8 v3, v3, 1
    .line 10: iget-object v0, v2, Lf/k;->j:[Ljava/lang/Object;
    .line 12: aget-object v1, v0, v3
    .line 14: aput-object v4, v0, v3
    .line 16: return-object v1
    .line 17: const/4 v3, 0
    .line 18: return-object v3
.end method

# virtual methods
.method public final replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 6

    .line 0: invoke-virtual {v2, v3}, Lf/k;->f(Ljava/lang/Object;)I
    .line 3: move-result v3
    .line 4: if-ltz v3, :cond_30
    .line 6: iget-object v0, v2, Lf/k;->j:[Ljava/lang/Object;
    .line 8: const/4 v1, 1
    .line 9: shl-int/2addr v3, v1
    .line 10: add-int/2addr v3, v1
    .line 11: aget-object v0, v0, v3
    .line 13: if-eq v0, v4, :cond_23
    .line 15: if-eqz v4, :cond_30
    .line 17: invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 20: move-result v4
    .line 21: if-eqz v4, :cond_30
    .line 23: iget-object v4, v2, Lf/k;->j:[Ljava/lang/Object;
    .line 25: aget-object v0, v4, v3
    .line 27: aput-object v5, v4, v3
    .line 29: return v1
    .line 30: const/4 v3, 0
    .line 31: return v3
.end method

# virtual methods
.method public final size()I
    .registers 2

    .line 0: iget v0, v1, Lf/k;->k:I
    .line 2: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 6

    .line 0: invoke-virtual {v5}, Lf/k;->isEmpty()Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_9
    .line 6: const-string v0, "{}"
    .line 8: return-object v0
    .line 9: new-instance v0, Ljava/lang/StringBuilder;
    .line 11: iget v1, v5, Lf/k;->k:I
    .line 13: mul-int/lit8 v1, v1, 28
    .line 15: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    .line 18: const/16 v1, 123
    .line 20: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 23: const/4 v1, 0
    .line 24: iget v2, v5, Lf/k;->k:I
    .line 26: if-ge v1, v2, :cond_75
    .line 28: if-lez v1, :cond_35
    .line 30: const-string v2, ", "
    .line 32: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 35: iget-object v2, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 37: shl-int/lit8 v3, v1, 1
    .line 39: aget-object v2, v2, v3
    .line 41: const-string v4, "(this Map)"
    .line 43: if-eq v2, v5, :cond_49
    .line 45: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 48: goto :goto_52
    .line 49: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 52: const/16 v2, 61
    .line 54: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 57: iget-object v2, v5, Lf/k;->j:[Ljava/lang/Object;
    .line 59: add-int/lit8 v3, v3, 1
    .line 61: aget-object v2, v2, v3
    .line 63: if-eq v2, v5, :cond_69
    .line 65: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 68: goto :goto_72
    .line 69: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 72: add-int/lit8 v1, v1, 1
    .line 74: goto :goto_24
    .line 75: const/16 v1, 125
    .line 77: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 80: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 83: move-result-object v0
    .line 84: return-object v0
.end method

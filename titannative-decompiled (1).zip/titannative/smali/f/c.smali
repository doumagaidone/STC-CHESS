.class public final Lf/c;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Collection;
.implements Ljava/util/Set;

.field public static final m:[I
.field public static final n:[Ljava/lang/Object;
.field public static o:[Ljava/lang/Object;
.field public static p:I
.field public static q:[Ljava/lang/Object;
.field public static r:I

.field public i:[I
.field public j:[Ljava/lang/Object;
.field public k:I
.field public l:Lf/a;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: new-array v1, v0, [I
    .line 3: sput-object v1, Lf/c;->m:[I
    .line 5: new-array v0, v0, [Ljava/lang/Object;
    .line 7: sput-object v0, Lf/c;->n:[Ljava/lang/Object;
    .line 9: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: sget-object v0, Lf/c;->m:[I
    .line 5: iput-object v0, v1, Lf/c;->i:[I
    .line 7: sget-object v0, Lf/c;->n:[Ljava/lang/Object;
    .line 9: iput-object v0, v1, Lf/c;->j:[Ljava/lang/Object;
    .line 11: const/4 v0, 0
    .line 12: iput v0, v1, Lf/c;->k:I
    .line 14: return-void
.end method

# direct methods
.method public static c([I[Ljava/lang/Object;I)V
    .registers 10

    .line 0: array-length v0, v7
    .line 1: const/16 v1, 8
    .line 3: const/4 v2, 0
    .line 4: const/4 v3, 2
    .line 5: const/4 v4, 0
    .line 6: const/16 v5, 10
    .line 8: const/4 v6, 1
    .line 9: if-ne v0, v1, :cond_45
    .line 11: const-class v0, Lf/c;
    .line 13: monitor-enter v0
    .line 14: sget v1, Lf/c;->r:I
    .line 16: if-ge v1, v5, :cond_41
    .line 18: sget-object v1, Lf/c;->q:[Ljava/lang/Object;
    .line 20: aput-object v1, v8, v4
    .line 22: aput-object v7, v8, v6
    .line 24: sub-int/2addr v9, v6
    .line 25: if-lt v9, v3, :cond_34
    .line 27: aput-object v2, v8, v9
    .line 29: add-int/lit8 v9, v9, -1
    .line 31: goto :goto_25
    .line 32: move-exception v7
    .line 33: goto :goto_43
    .line 34: sput-object v8, Lf/c;->q:[Ljava/lang/Object;
    .line 36: sget v7, Lf/c;->r:I
    .line 38: add-int/2addr v7, v6
    .line 39: sput v7, Lf/c;->r:I
    .line 41: monitor-exit v0
    .line 42: goto :goto_83
    .line 43: monitor-exit v0
    .line 44: throw v7
    .line 45: array-length v0, v7
    .line 46: const/4 v1, 4
    .line 47: if-ne v0, v1, :cond_83
    .line 49: const-class v0, Lf/c;
    .line 51: monitor-enter v0
    .line 52: sget v1, Lf/c;->p:I
    .line 54: if-ge v1, v5, :cond_79
    .line 56: sget-object v1, Lf/c;->o:[Ljava/lang/Object;
    .line 58: aput-object v1, v8, v4
    .line 60: aput-object v7, v8, v6
    .line 62: sub-int/2addr v9, v6
    .line 63: if-lt v9, v3, :cond_72
    .line 65: aput-object v2, v8, v9
    .line 67: add-int/lit8 v9, v9, -1
    .line 69: goto :goto_63
    .line 70: move-exception v7
    .line 71: goto :goto_81
    .line 72: sput-object v8, Lf/c;->o:[Ljava/lang/Object;
    .line 74: sget v7, Lf/c;->p:I
    .line 76: add-int/2addr v7, v6
    .line 77: sput v7, Lf/c;->p:I
    .line 79: monitor-exit v0
    .line 80: goto :goto_83
    .line 81: monitor-exit v0
    .line 82: throw v7
    .line 83: return-void
.end method

# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .registers 10

    .line 0: const/4 v0, 0
    .line 1: if-nez v9, :cond_9
    .line 3: invoke-virtual {v8}, Lf/c;->e()I
    .line 6: move-result v1
    .line 7: move v2, v0
    .line 8: goto :goto_20
    .line 9: invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I
    .line 12: move-result v1
    .line 13: invoke-virtual {v8, v1, v9}, Lf/c;->d(ILjava/lang/Object;)I
    .line 16: move-result v2
    .line 17: move v7, v2
    .line 18: move v2, v1
    .line 19: move v1, v7
    .line 20: if-ltz v1, :cond_23
    .line 22: return v0
    .line 23: not-int v1, v1
    .line 24: iget v3, v8, Lf/c;->k:I
    .line 26: iget-object v4, v8, Lf/c;->i:[I
    .line 28: array-length v5, v4
    .line 29: if-lt v3, v5, :cond_69
    .line 31: const/16 v5, 8
    .line 33: if-lt v3, v5, :cond_39
    .line 35: shr-int/lit8 v5, v3, 1
    .line 37: add-int/2addr v5, v3
    .line 38: goto :goto_44
    .line 39: const/4 v6, 4
    .line 40: if-lt v3, v6, :cond_43
    .line 42: goto :goto_44
    .line 43: move v5, v6
    .line 44: iget-object v3, v8, Lf/c;->j:[Ljava/lang/Object;
    .line 46: invoke-virtual {v8, v5}, Lf/c;->b(I)V
    .line 49: iget-object v5, v8, Lf/c;->i:[I
    .line 51: array-length v6, v5
    .line 52: if-lez v6, :cond_64
    .line 54: array-length v6, v4
    .line 55: invoke-static {v4, v0, v5, v0, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 58: iget-object v5, v8, Lf/c;->j:[Ljava/lang/Object;
    .line 60: array-length v6, v3
    .line 61: invoke-static {v3, v0, v5, v0, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 64: iget v0, v8, Lf/c;->k:I
    .line 66: invoke-static {v4, v3, v0}, Lf/c;->c([I[Ljava/lang/Object;I)V
    .line 69: iget v0, v8, Lf/c;->k:I
    .line 71: if-ge v1, v0, :cond_89
    .line 73: iget-object v3, v8, Lf/c;->i:[I
    .line 75: add-int/lit8 v4, v1, 1
    .line 77: sub-int/2addr v0, v1
    .line 78: invoke-static {v3, v1, v3, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 81: iget-object v0, v8, Lf/c;->j:[Ljava/lang/Object;
    .line 83: iget v3, v8, Lf/c;->k:I
    .line 85: sub-int/2addr v3, v1
    .line 86: invoke-static {v0, v1, v0, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 89: iget-object v0, v8, Lf/c;->i:[I
    .line 91: aput v2, v0, v1
    .line 93: iget-object v0, v8, Lf/c;->j:[Ljava/lang/Object;
    .line 95: aput-object v9, v0, v1
    .line 97: iget v9, v8, Lf/c;->k:I
    .line 99: const/4 v0, 1
    .line 100: add-int/2addr v9, v0
    .line 101: iput v9, v8, Lf/c;->k:I
    .line 103: return v0
.end method

# virtual methods
.method public final addAll(Ljava/util/Collection;)Z
    .registers 7

    .line 0: iget v0, v5, Lf/c;->k:I
    .line 2: invoke-interface {v6}, Ljava/util/Collection;->size()I
    .line 5: move-result v1
    .line 6: add-int/2addr v1, v0
    .line 7: iget-object v0, v5, Lf/c;->i:[I
    .line 9: array-length v2, v0
    .line 10: const/4 v3, 0
    .line 11: if-ge v2, v1, :cond_39
    .line 13: iget-object v2, v5, Lf/c;->j:[Ljava/lang/Object;
    .line 15: invoke-virtual {v5, v1}, Lf/c;->b(I)V
    .line 18: iget v1, v5, Lf/c;->k:I
    .line 20: if-lez v1, :cond_34
    .line 22: iget-object v4, v5, Lf/c;->i:[I
    .line 24: invoke-static {v0, v3, v4, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 27: iget-object v1, v5, Lf/c;->j:[Ljava/lang/Object;
    .line 29: iget v4, v5, Lf/c;->k:I
    .line 31: invoke-static {v2, v3, v1, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 34: iget v1, v5, Lf/c;->k:I
    .line 36: invoke-static {v0, v2, v1}, Lf/c;->c([I[Ljava/lang/Object;I)V
    .line 39: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 42: move-result-object v6
    .line 43: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 46: move-result v0
    .line 47: if-eqz v0, :cond_59
    .line 49: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 52: move-result-object v0
    .line 53: invoke-virtual {v5, v0}, Lf/c;->add(Ljava/lang/Object;)Z
    .line 56: move-result v0
    .line 57: or-int/2addr v3, v0
    .line 58: goto :goto_43
    .line 59: return v3
.end method

# virtual methods
.method public final b(I)V
    .registers 7

    .line 0: const/16 v0, 8
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 0
    .line 4: const/4 v3, 1
    .line 5: if-ne v6, v0, :cond_45
    .line 7: const-class v0, Lf/c;
    .line 9: monitor-enter v0
    .line 10: sget-object v4, Lf/c;->q:[Ljava/lang/Object;
    .line 12: if-eqz v4, :cond_41
    .line 14: iput-object v4, v5, Lf/c;->j:[Ljava/lang/Object;
    .line 16: aget-object v6, v4, v2
    .line 18: check-cast v6, [Ljava/lang/Object;
    .line 20: sput-object v6, Lf/c;->q:[Ljava/lang/Object;
    .line 22: aget-object v6, v4, v3
    .line 24: check-cast v6, [I
    .line 26: iput-object v6, v5, Lf/c;->i:[I
    .line 28: aput-object v1, v4, v3
    .line 30: aput-object v1, v4, v2
    .line 32: sget v6, Lf/c;->r:I
    .line 34: sub-int/2addr v6, v3
    .line 35: sput v6, Lf/c;->r:I
    .line 37: monitor-exit v0
    .line 38: return-void
    .line 39: move-exception v6
    .line 40: goto :goto_43
    .line 41: monitor-exit v0
    .line 42: goto :goto_86
    .line 43: monitor-exit v0
    .line 44: throw v6
    .line 45: const/4 v0, 4
    .line 46: if-ne v6, v0, :cond_86
    .line 48: const-class v0, Lf/c;
    .line 50: monitor-enter v0
    .line 51: sget-object v4, Lf/c;->o:[Ljava/lang/Object;
    .line 53: if-eqz v4, :cond_82
    .line 55: iput-object v4, v5, Lf/c;->j:[Ljava/lang/Object;
    .line 57: aget-object v6, v4, v2
    .line 59: check-cast v6, [Ljava/lang/Object;
    .line 61: sput-object v6, Lf/c;->o:[Ljava/lang/Object;
    .line 63: aget-object v6, v4, v3
    .line 65: check-cast v6, [I
    .line 67: iput-object v6, v5, Lf/c;->i:[I
    .line 69: aput-object v1, v4, v3
    .line 71: aput-object v1, v4, v2
    .line 73: sget v6, Lf/c;->p:I
    .line 75: sub-int/2addr v6, v3
    .line 76: sput v6, Lf/c;->p:I
    .line 78: monitor-exit v0
    .line 79: return-void
    .line 80: move-exception v6
    .line 81: goto :goto_84
    .line 82: monitor-exit v0
    .line 83: goto :goto_86
    .line 84: monitor-exit v0
    .line 85: throw v6
    .line 86: new-array v0, v6, [I
    .line 88: iput-object v0, v5, Lf/c;->i:[I
    .line 90: new-array v6, v6, [Ljava/lang/Object;
    .line 92: iput-object v6, v5, Lf/c;->j:[Ljava/lang/Object;
    .line 94: return-void
.end method

# virtual methods
.method public final clear()V
    .registers 4

    .line 0: iget v0, v3, Lf/c;->k:I
    .line 2: if-eqz v0, :cond_22
    .line 4: iget-object v1, v3, Lf/c;->i:[I
    .line 6: iget-object v2, v3, Lf/c;->j:[Ljava/lang/Object;
    .line 8: invoke-static {v1, v2, v0}, Lf/c;->c([I[Ljava/lang/Object;I)V
    .line 11: sget-object v0, Lf/c;->m:[I
    .line 13: iput-object v0, v3, Lf/c;->i:[I
    .line 15: sget-object v0, Lf/c;->n:[Ljava/lang/Object;
    .line 17: iput-object v0, v3, Lf/c;->j:[Ljava/lang/Object;
    .line 19: const/4 v0, 0
    .line 20: iput v0, v3, Lf/c;->k:I
    .line 22: return-void
.end method

# virtual methods
.method public final contains(Ljava/lang/Object;)Z
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 3: move-result v1
    .line 4: if-ltz v1, :cond_8
    .line 6: const/4 v1, 1
    .line 7: goto :goto_9
    .line 8: const/4 v1, 0
    .line 9: return v1
.end method

# virtual methods
.method public final containsAll(Ljava/util/Collection;)Z
    .registers 3

    .line 0: invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 3: move-result-object v2
    .line 4: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 7: move-result v0
    .line 8: if-eqz v0, :cond_22
    .line 10: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 13: move-result-object v0
    .line 14: invoke-virtual {v1, v0}, Lf/c;->contains(Ljava/lang/Object;)Z
    .line 17: move-result v0
    .line 18: if-nez v0, :cond_4
    .line 20: const/4 v2, 0
    .line 21: return v2
    .line 22: const/4 v2, 1
    .line 23: return v2
.end method

# virtual methods
.method public final d(ILjava/lang/Object;)I
    .registers 7

    .line 0: iget v0, v4, Lf/c;->k:I
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v5, -1
    .line 5: return v5
    .line 6: iget-object v1, v4, Lf/c;->i:[I
    .line 8: invoke-static {v1, v0, v5}, Lf/d;->a([III)I
    .line 11: move-result v1
    .line 12: if-gez v1, :cond_15
    .line 14: return v1
    .line 15: iget-object v2, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 17: aget-object v2, v2, v1
    .line 19: invoke-virtual {v6, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 22: move-result v2
    .line 23: if-eqz v2, :cond_26
    .line 25: return v1
    .line 26: add-int/lit8 v2, v1, 1
    .line 28: if-ge v2, v0, :cond_50
    .line 30: iget-object v3, v4, Lf/c;->i:[I
    .line 32: aget v3, v3, v2
    .line 34: if-ne v3, v5, :cond_50
    .line 36: iget-object v3, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 38: aget-object v3, v3, v2
    .line 40: invoke-virtual {v6, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 43: move-result v3
    .line 44: if-eqz v3, :cond_47
    .line 46: return v2
    .line 47: add-int/lit8 v2, v2, 1
    .line 49: goto :goto_28
    .line 50: add-int/lit8 v1, v1, -1
    .line 52: if-ltz v1, :cond_74
    .line 54: iget-object v0, v4, Lf/c;->i:[I
    .line 56: aget v0, v0, v1
    .line 58: if-ne v0, v5, :cond_74
    .line 60: iget-object v0, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 62: aget-object v0, v0, v1
    .line 64: invoke-virtual {v6, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 67: move-result v0
    .line 68: if-eqz v0, :cond_71
    .line 70: return v1
    .line 71: add-int/lit8 v1, v1, -1
    .line 73: goto :goto_52
    .line 74: not-int v5, v2
    .line 75: return v5
.end method

# virtual methods
.method public final e()I
    .registers 5

    .line 0: iget v0, v4, Lf/c;->k:I
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, -1
    .line 5: return v0
    .line 6: iget-object v1, v4, Lf/c;->i:[I
    .line 8: const/4 v2, 0
    .line 9: invoke-static {v1, v0, v2}, Lf/d;->a([III)I
    .line 12: move-result v1
    .line 13: if-gez v1, :cond_16
    .line 15: return v1
    .line 16: iget-object v2, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 18: aget-object v2, v2, v1
    .line 20: if-nez v2, :cond_23
    .line 22: return v1
    .line 23: add-int/lit8 v2, v1, 1
    .line 25: if-ge v2, v0, :cond_43
    .line 27: iget-object v3, v4, Lf/c;->i:[I
    .line 29: aget v3, v3, v2
    .line 31: if-nez v3, :cond_43
    .line 33: iget-object v3, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 35: aget-object v3, v3, v2
    .line 37: if-nez v3, :cond_40
    .line 39: return v2
    .line 40: add-int/lit8 v2, v2, 1
    .line 42: goto :goto_25
    .line 43: add-int/lit8 v1, v1, -1
    .line 45: if-ltz v1, :cond_63
    .line 47: iget-object v0, v4, Lf/c;->i:[I
    .line 49: aget v0, v0, v1
    .line 51: if-nez v0, :cond_63
    .line 53: iget-object v0, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 55: aget-object v0, v0, v1
    .line 57: if-nez v0, :cond_60
    .line 59: return v1
    .line 60: add-int/lit8 v1, v1, -1
    .line 62: goto :goto_45
    .line 63: not-int v0, v2
    .line 64: return v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Ljava/util/Set;
    .line 6: const/4 v2, 0
    .line 7: if-eqz v1, :cond_40
    .line 9: check-cast v5, Ljava/util/Set;
    .line 11: iget v1, v4, Lf/c;->k:I
    .line 13: invoke-interface {v5}, Ljava/util/Set;->size()I
    .line 16: move-result v3
    .line 17: if-eq v1, v3, :cond_20
    .line 19: return v2
    .line 20: move v1, v2
    .line 21: iget v3, v4, Lf/c;->k:I
    .line 23: if-ge v1, v3, :cond_39
    .line 25: iget-object v3, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 27: aget-object v3, v3, v1
    .line 29: invoke-interface {v5, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 32: move-result v3
    .line 33: if-nez v3, :cond_36
    .line 35: return v2
    .line 36: add-int/lit8 v1, v1, 1
    .line 38: goto :goto_21
    .line 39: return v0
    .line 40: return v2
.end method

# virtual methods
.method public final f(I)V
    .registers 9

    .line 0: iget-object v0, v7, Lf/c;->j:[Ljava/lang/Object;
    .line 2: aget-object v1, v0, v8
    .line 4: iget v1, v7, Lf/c;->k:I
    .line 6: const/4 v2, 0
    .line 7: const/4 v3, 1
    .line 8: if-gt v1, v3, :cond_26
    .line 10: iget-object v8, v7, Lf/c;->i:[I
    .line 12: invoke-static {v8, v0, v1}, Lf/c;->c([I[Ljava/lang/Object;I)V
    .line 15: sget-object v8, Lf/c;->m:[I
    .line 17: iput-object v8, v7, Lf/c;->i:[I
    .line 19: sget-object v8, Lf/c;->n:[Ljava/lang/Object;
    .line 21: iput-object v8, v7, Lf/c;->j:[Ljava/lang/Object;
    .line 23: iput v2, v7, Lf/c;->k:I
    .line 25: goto :goto_111
    .line 26: iget-object v4, v7, Lf/c;->i:[I
    .line 28: array-length v5, v4
    .line 29: const/16 v6, 8
    .line 31: if-le v5, v6, :cond_85
    .line 33: array-length v5, v4
    .line 34: div-int/lit8 v5, v5, 3
    .line 36: if-ge v1, v5, :cond_85
    .line 38: if-le v1, v6, :cond_44
    .line 40: shr-int/lit8 v5, v1, 1
    .line 42: add-int v6, v1, v5
    .line 44: invoke-virtual {v7, v6}, Lf/c;->b(I)V
    .line 47: iget v1, v7, Lf/c;->k:I
    .line 49: sub-int/2addr v1, v3
    .line 50: iput v1, v7, Lf/c;->k:I
    .line 52: if-lez v8, :cond_64
    .line 54: iget-object v1, v7, Lf/c;->i:[I
    .line 56: invoke-static {v4, v2, v1, v2, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 59: iget-object v1, v7, Lf/c;->j:[Ljava/lang/Object;
    .line 61: invoke-static {v0, v2, v1, v2, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 64: iget v1, v7, Lf/c;->k:I
    .line 66: if-ge v8, v1, :cond_111
    .line 68: add-int/lit8 v2, v8, 1
    .line 70: iget-object v3, v7, Lf/c;->i:[I
    .line 72: sub-int/2addr v1, v8
    .line 73: invoke-static {v4, v2, v3, v8, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 76: iget-object v1, v7, Lf/c;->j:[Ljava/lang/Object;
    .line 78: iget v3, v7, Lf/c;->k:I
    .line 80: sub-int/2addr v3, v8
    .line 81: invoke-static {v0, v2, v1, v8, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 84: goto :goto_111
    .line 85: sub-int/2addr v1, v3
    .line 86: iput v1, v7, Lf/c;->k:I
    .line 88: if-ge v8, v1, :cond_104
    .line 90: add-int/lit8 v0, v8, 1
    .line 92: sub-int/2addr v1, v8
    .line 93: invoke-static {v4, v0, v4, v8, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 96: iget-object v1, v7, Lf/c;->j:[Ljava/lang/Object;
    .line 98: iget v2, v7, Lf/c;->k:I
    .line 100: sub-int/2addr v2, v8
    .line 101: invoke-static {v1, v0, v1, v8, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 104: iget-object v8, v7, Lf/c;->j:[Ljava/lang/Object;
    .line 106: iget v0, v7, Lf/c;->k:I
    .line 108: const/4 v1, 0
    .line 109: aput-object v1, v8, v0
    .line 111: return-void
.end method

# virtual methods
.method public final hashCode()I
    .registers 6

    .line 0: iget-object v0, v5, Lf/c;->i:[I
    .line 2: iget v1, v5, Lf/c;->k:I
    .line 4: const/4 v2, 0
    .line 5: move v3, v2
    .line 6: if-ge v2, v1, :cond_14
    .line 8: aget v4, v0, v2
    .line 10: add-int/2addr v3, v4
    .line 11: add-int/lit8 v2, v2, 1
    .line 13: goto :goto_6
    .line 14: return v3
.end method

# virtual methods
.method public final indexOf(Ljava/lang/Object;)I
    .registers 3

    .line 0: if-nez v2, :cond_7
    .line 2: invoke-virtual {v1}, Lf/c;->e()I
    .line 5: move-result v2
    .line 6: goto :goto_15
    .line 7: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 10: move-result v0
    .line 11: invoke-virtual {v1, v0, v2}, Lf/c;->d(ILjava/lang/Object;)I
    .line 14: move-result v2
    .line 15: return v2
.end method

# virtual methods
.method public final isEmpty()Z
    .registers 2

    .line 0: iget v0, v1, Lf/c;->k:I
    .line 2: if-gtz v0, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_7
    .line 6: const/4 v0, 0
    .line 7: return v0
.end method

# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .registers 4

    .line 0: iget-object v0, v3, Lf/c;->l:Lf/a;
    .line 2: const/4 v1, 1
    .line 3: if-nez v0, :cond_12
    .line 5: new-instance v0, Lf/a;
    .line 7: invoke-direct {v0, v1, v3}, Lf/a;-><init>(ILjava/lang/Object;)V
    .line 10: iput-object v0, v3, Lf/c;->l:Lf/a;
    .line 12: iget-object v0, v3, Lf/c;->l:Lf/a;
    .line 14: iget-object v2, v0, Lf/j;->b:Lf/g;
    .line 16: if-nez v2, :cond_25
    .line 18: new-instance v2, Lf/g;
    .line 20: invoke-direct {v2, v0, v1}, Lf/g;-><init>(Lf/j;I)V
    .line 23: iput-object v2, v0, Lf/j;->b:Lf/g;
    .line 25: iget-object v0, v0, Lf/j;->b:Lf/g;
    .line 27: invoke-virtual {v0}, Lf/g;->iterator()Ljava/util/Iterator;
    .line 30: move-result-object v0
    .line 31: return-object v0
.end method

# virtual methods
.method public final remove(Ljava/lang/Object;)Z
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 3: move-result v1
    .line 4: if-ltz v1, :cond_11
    .line 6: invoke-virtual {v0, v1}, Lf/c;->f(I)V
    .line 9: const/4 v1, 1
    .line 10: return v1
    .line 11: const/4 v1, 0
    .line 12: return v1
.end method

# virtual methods
.method public final removeAll(Ljava/util/Collection;)Z
    .registers 4

    .line 0: invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 3: move-result-object v3
    .line 4: const/4 v0, 0
    .line 5: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 8: move-result v1
    .line 9: if-eqz v1, :cond_21
    .line 11: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 14: move-result-object v1
    .line 15: invoke-virtual {v2, v1}, Lf/c;->remove(Ljava/lang/Object;)Z
    .line 18: move-result v1
    .line 19: or-int/2addr v0, v1
    .line 20: goto :goto_5
    .line 21: return v0
.end method

# virtual methods
.method public final retainAll(Ljava/util/Collection;)Z
    .registers 6

    .line 0: iget v0, v4, Lf/c;->k:I
    .line 2: const/4 v1, 1
    .line 3: sub-int/2addr v0, v1
    .line 4: const/4 v2, 0
    .line 5: if-ltz v0, :cond_24
    .line 7: iget-object v3, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 9: aget-object v3, v3, v0
    .line 11: invoke-interface {v5, v3}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z
    .line 14: move-result v3
    .line 15: if-nez v3, :cond_21
    .line 17: invoke-virtual {v4, v0}, Lf/c;->f(I)V
    .line 20: move v2, v1
    .line 21: add-int/lit8 v0, v0, -1
    .line 23: goto :goto_5
    .line 24: return v2
.end method

# virtual methods
.method public final size()I
    .registers 2

    .line 0: iget v0, v1, Lf/c;->k:I
    .line 2: return v0
.end method

# virtual methods
.method public final toArray()[Ljava/lang/Object;
    .registers 5

    .line 0: iget v0, v4, Lf/c;->k:I
    .line 2: new-array v1, v0, [Ljava/lang/Object;
    .line 4: iget-object v2, v4, Lf/c;->j:[Ljava/lang/Object;
    .line 6: const/4 v3, 0
    .line 7: invoke-static {v2, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 10: return-object v1
.end method

# virtual methods
.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 5

    .line 0: array-length v0, v4
    .line 1: iget v1, v3, Lf/c;->k:I
    .line 3: if-ge v0, v1, :cond_21
    .line 5: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 8: move-result-object v4
    .line 9: invoke-virtual {v4}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    .line 12: move-result-object v4
    .line 13: iget v0, v3, Lf/c;->k:I
    .line 15: invoke-static {v4, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;
    .line 18: move-result-object v4
    .line 19: check-cast v4, [Ljava/lang/Object;
    .line 21: iget-object v0, v3, Lf/c;->j:[Ljava/lang/Object;
    .line 23: iget v1, v3, Lf/c;->k:I
    .line 25: const/4 v2, 0
    .line 26: invoke-static {v0, v2, v4, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 29: array-length v0, v4
    .line 30: iget v1, v3, Lf/c;->k:I
    .line 32: if-le v0, v1, :cond_37
    .line 34: const/4 v0, 0
    .line 35: aput-object v0, v4, v1
    .line 37: return-object v4
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: invoke-virtual {v3}, Lf/c;->isEmpty()Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_9
    .line 6: const-string v0, "{}"
    .line 8: return-object v0
    .line 9: new-instance v0, Ljava/lang/StringBuilder;
    .line 11: iget v1, v3, Lf/c;->k:I
    .line 13: mul-int/lit8 v1, v1, 14
    .line 15: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    .line 18: const/16 v1, 123
    .line 20: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 23: const/4 v1, 0
    .line 24: iget v2, v3, Lf/c;->k:I
    .line 26: if-ge v1, v2, :cond_53
    .line 28: if-lez v1, :cond_35
    .line 30: const-string v2, ", "
    .line 32: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 35: iget-object v2, v3, Lf/c;->j:[Ljava/lang/Object;
    .line 37: aget-object v2, v2, v1
    .line 39: if-eq v2, v3, :cond_45
    .line 41: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 44: goto :goto_50
    .line 45: const-string v2, "(this Set)"
    .line 47: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 50: add-int/lit8 v1, v1, 1
    .line 52: goto :goto_24
    .line 53: const/16 v1, 125
    .line 55: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 58: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 61: move-result-object v0
    .line 62: return-object v0
.end method

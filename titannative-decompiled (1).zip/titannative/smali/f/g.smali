.class public final Lf/g;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Set;

.field public final synthetic i:I
.field public final synthetic j:Lf/j;

# direct methods
.method public synthetic constructor <init>(Lf/j;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v2, v0, Lf/g;->i:I
    .line 5: iput-object v1, v0, Lf/g;->j:Lf/j;
    .line 7: return-void
.end method

# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .registers 3

    .line 0: iget v0, v1, Lf/g;->i:I
    .line 2: packed-switch v0, :data_20
    .line 5: new-instance v2, Ljava/lang/UnsupportedOperationException;
    .line 7: invoke-direct {v2}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 10: throw v2
    .line 11: check-cast v2, Ljava/util/Map$Entry;
    .line 13: new-instance v2, Ljava/lang/UnsupportedOperationException;
    .line 15: invoke-direct {v2}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 18: throw v2
    .line 19: nop
    .line 20: nop
    .line 21: move v0, v0
    .line 22: nop
    .line 23: nop
    .line 24: move-object/16 v0, v8
.end method

# virtual methods
.method public final addAll(Ljava/util/Collection;)Z
    .registers 8

    .line 0: iget v0, v6, Lf/g;->i:I
    .line 2: packed-switch v0, :data_74
    .line 5: new-instance v7, Ljava/lang/UnsupportedOperationException;
    .line 7: invoke-direct {v7}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 10: throw v7
    .line 11: iget-object v0, v6, Lf/g;->j:Lf/j;
    .line 13: invoke-virtual {v0}, Lf/j;->b()I
    .line 16: move-result v1
    .line 17: invoke-interface {v7}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 20: move-result-object v7
    .line 21: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 24: move-result v2
    .line 25: if-eqz v2, :cond_63
    .line 27: invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 30: move-result-object v2
    .line 31: check-cast v2, Ljava/util/Map$Entry;
    .line 33: invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 36: move-result-object v3
    .line 37: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 40: move-result-object v2
    .line 41: move-object v4, v0
    .line 42: check-cast v4, Lf/a;
    .line 44: iget v5, v4, Lf/a;->d:I
    .line 46: iget-object v4, v4, Lf/a;->e:Ljava/lang/Object;
    .line 48: packed-switch v5, :data_80
    .line 51: check-cast v4, Lf/c;
    .line 53: invoke-virtual {v4, v3}, Lf/c;->add(Ljava/lang/Object;)Z
    .line 56: goto :goto_21
    .line 57: check-cast v4, Lf/b;
    .line 59: invoke-virtual {v4, v3, v2}, Lf/k;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 62: goto :goto_21
    .line 63: invoke-virtual {v0}, Lf/j;->b()I
    .line 66: move-result v7
    .line 67: if-eq v1, v7, :cond_71
    .line 69: const/4 v7, 1
    .line 70: goto :goto_72
    .line 71: const/4 v7, 0
    .line 72: return v7
    .line 73: nop
    .line 74: nop
    .line 75: move v0, v0
    .line 76: nop
    .line 77: nop
    .line 78: move-object/16 v0, v256
    .line 81: move v0, v0
    .line 82: nop
    .line 83: nop
    .line 84: move-object/16 v0, v8
.end method

# virtual methods
.method public final clear()V
    .registers 3

    .line 0: iget v0, v2, Lf/g;->i:I
    .line 2: iget-object v1, v2, Lf/g;->j:Lf/j;
    .line 4: packed-switch v0, :data_50
    .line 7: check-cast v1, Lf/a;
    .line 9: iget v0, v1, Lf/a;->d:I
    .line 11: iget-object v1, v1, Lf/a;->e:Ljava/lang/Object;
    .line 13: packed-switch v0, :data_56
    .line 16: check-cast v1, Lf/c;
    .line 18: invoke-virtual {v1}, Lf/c;->clear()V
    .line 21: goto :goto_27
    .line 22: check-cast v1, Lf/b;
    .line 24: invoke-virtual {v1}, Lf/k;->clear()V
    .line 27: return-void
    .line 28: check-cast v1, Lf/a;
    .line 30: iget v0, v1, Lf/a;->d:I
    .line 32: iget-object v1, v1, Lf/a;->e:Ljava/lang/Object;
    .line 34: packed-switch v0, :data_62
    .line 37: check-cast v1, Lf/c;
    .line 39: invoke-virtual {v1}, Lf/c;->clear()V
    .line 42: goto :goto_48
    .line 43: check-cast v1, Lf/b;
    .line 45: invoke-virtual {v1}, Lf/k;->clear()V
    .line 48: return-void
    .line 49: nop
    .line 50: nop
    .line 51: move v0, v0
    .line 52: nop
    .line 53: nop
    .line 54: const-wide v0, 0x011000
    .line 59: nop
    .line 60: move-object/16 v0, v256
    .line 63: move v0, v0
    .line 64: nop
    .line 65: nop
    .line 66: move-object/16 v0, v6
.end method

# virtual methods
.method public final contains(Ljava/lang/Object;)Z
    .registers 8

    .line 0: iget v0, v6, Lf/g;->i:I
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 1
    .line 4: iget-object v3, v6, Lf/g;->j:Lf/j;
    .line 6: packed-switch v0, :data_92
    .line 9: check-cast v3, Lf/a;
    .line 11: iget v0, v3, Lf/a;->d:I
    .line 13: iget-object v3, v3, Lf/a;->e:Ljava/lang/Object;
    .line 15: packed-switch v0, :data_98
    .line 18: check-cast v3, Lf/c;
    .line 20: invoke-virtual {v3, v7}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 23: move-result v7
    .line 24: goto :goto_31
    .line 25: check-cast v3, Lf/b;
    .line 27: invoke-virtual {v3, v7}, Lf/k;->f(Ljava/lang/Object;)I
    .line 30: move-result v7
    .line 31: if-ltz v7, :cond_34
    .line 33: move v1, v2
    .line 34: return v1
    .line 35: instance-of v0, v7, Ljava/util/Map$Entry;
    .line 37: if-nez v0, :cond_40
    .line 39: goto :goto_91
    .line 40: check-cast v7, Ljava/util/Map$Entry;
    .line 42: invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 45: move-result-object v0
    .line 46: move-object v4, v3
    .line 47: check-cast v4, Lf/a;
    .line 49: iget v5, v4, Lf/a;->d:I
    .line 51: iget-object v4, v4, Lf/a;->e:Ljava/lang/Object;
    .line 53: packed-switch v5, :data_104
    .line 56: check-cast v4, Lf/c;
    .line 58: invoke-virtual {v4, v0}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 61: move-result v0
    .line 62: goto :goto_69
    .line 63: check-cast v4, Lf/b;
    .line 65: invoke-virtual {v4, v0}, Lf/k;->f(Ljava/lang/Object;)I
    .line 68: move-result v0
    .line 69: if-gez v0, :cond_72
    .line 71: goto :goto_91
    .line 72: invoke-virtual {v3, v0, v2}, Lf/j;->a(II)Ljava/lang/Object;
    .line 75: move-result-object v0
    .line 76: invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 79: move-result-object v7
    .line 80: if-eq v0, v7, :cond_90
    .line 82: if-eqz v0, :cond_91
    .line 84: invoke-virtual {v0, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 87: move-result v7
    .line 88: if-eqz v7, :cond_91
    .line 90: move v1, v2
    .line 91: return v1
    .line 92: nop
    .line 93: move v0, v0
    .line 94: nop
    .line 95: nop
    .line 96: monitor-enter v0
    .line 97: nop
    .line 98: nop
    .line 99: move v0, v0
    .line 100: nop
    .line 101: nop
    .line 102: move-result v0
    .line 103: nop
    .line 104: nop
    .line 105: move v0, v0
    .line 106: nop
    .line 107: nop
    .line 108: move-result v0
    .line 109: nop
.end method

# virtual methods
.method public final containsAll(Ljava/util/Collection;)Z
    .registers 6

    .line 0: iget v0, v4, Lf/g;->i:I
    .line 2: const/4 v1, 1
    .line 3: const/4 v2, 0
    .line 4: packed-switch v0, :data_72
    .line 7: iget-object v0, v4, Lf/g;->j:Lf/j;
    .line 9: check-cast v0, Lf/a;
    .line 11: iget v3, v0, Lf/a;->d:I
    .line 13: packed-switch v3, :data_78
    .line 16: new-instance v5, Ljava/lang/UnsupportedOperationException;
    .line 18: const-string v0, "not a map"
    .line 20: invoke-direct {v5, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 23: throw v5
    .line 24: iget-object v0, v0, Lf/a;->e:Ljava/lang/Object;
    .line 26: check-cast v0, Lf/b;
    .line 28: invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 31: move-result-object v5
    .line 32: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 35: move-result v3
    .line 36: if-eqz v3, :cond_49
    .line 38: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 41: move-result-object v3
    .line 42: invoke-virtual {v0, v3}, Lf/k;->containsKey(Ljava/lang/Object;)Z
    .line 45: move-result v3
    .line 46: if-nez v3, :cond_32
    .line 48: move v1, v2
    .line 49: return v1
    .line 50: invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 53: move-result-object v5
    .line 54: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 57: move-result v0
    .line 58: if-eqz v0, :cond_71
    .line 60: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 63: move-result-object v0
    .line 64: invoke-virtual {v4, v0}, Lf/g;->contains(Ljava/lang/Object;)Z
    .line 67: move-result v0
    .line 68: if-nez v0, :cond_54
    .line 70: move v1, v2
    .line 71: return v1
    .line 72: nop
    .line 73: move v0, v0
    .line 74: nop
    .line 75: nop
    .line 76: cmpg-float v0, v0, v0
    .line 78: nop
    .line 79: move v0, v0
    .line 80: nop
    .line 81: nop
    .line 82: move-result-wide v0
    .line 83: nop
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .line 0: iget v0, v1, Lf/g;->i:I
    .line 2: packed-switch v0, :data_16
    .line 5: invoke-static {v1, v2}, Lf/j;->d(Ljava/util/Set;Ljava/lang/Object;)Z
    .line 8: move-result v2
    .line 9: return v2
    .line 10: invoke-static {v1, v2}, Lf/j;->d(Ljava/util/Set;Ljava/lang/Object;)Z
    .line 13: move-result v2
    .line 14: return v2
    .line 15: nop
    .line 16: nop
    .line 17: move v0, v0
    .line 18: nop
    .line 19: nop
    .line 20: move-object/from16 v0, v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 8

    .line 0: iget v0, v7, Lf/g;->i:I
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 1
    .line 4: iget-object v3, v7, Lf/g;->j:Lf/j;
    .line 6: packed-switch v0, :data_72
    .line 9: invoke-virtual {v3}, Lf/j;->b()I
    .line 12: move-result v0
    .line 13: sub-int/2addr v0, v2
    .line 14: move v2, v1
    .line 15: if-ltz v0, :cond_33
    .line 17: invoke-virtual {v3, v0, v1}, Lf/j;->a(II)Ljava/lang/Object;
    .line 20: move-result-object v4
    .line 21: if-nez v4, :cond_25
    .line 23: move v4, v1
    .line 24: goto :goto_29
    .line 25: invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I
    .line 28: move-result v4
    .line 29: add-int/2addr v2, v4
    .line 30: add-int/lit8 v0, v0, -1
    .line 32: goto :goto_15
    .line 33: return v2
    .line 34: invoke-virtual {v3}, Lf/j;->b()I
    .line 37: move-result v0
    .line 38: sub-int/2addr v0, v2
    .line 39: move v4, v1
    .line 40: if-ltz v0, :cond_71
    .line 42: invoke-virtual {v3, v0, v1}, Lf/j;->a(II)Ljava/lang/Object;
    .line 45: move-result-object v5
    .line 46: invoke-virtual {v3, v0, v2}, Lf/j;->a(II)Ljava/lang/Object;
    .line 49: move-result-object v6
    .line 50: if-nez v5, :cond_54
    .line 52: move v5, v1
    .line 53: goto :goto_58
    .line 54: invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I
    .line 57: move-result v5
    .line 58: if-nez v6, :cond_62
    .line 60: move v6, v1
    .line 61: goto :goto_66
    .line 62: invoke-virtual {v6}, Ljava/lang/Object;->hashCode()I
    .line 65: move-result v6
    .line 66: xor-int/2addr v5, v6
    .line 67: add-int/2addr v4, v5
    .line 68: add-int/lit8 v0, v0, -1
    .line 70: goto :goto_40
    .line 71: return v4
    .line 72: nop
    .line 73: move v0, v0
    .line 74: nop
    .line 75: nop
    .line 76: const-class v0, B
.end method

# virtual methods
.method public final isEmpty()Z
    .registers 5

    .line 0: iget v0, v4, Lf/g;->i:I
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 1
    .line 4: iget-object v3, v4, Lf/g;->j:Lf/j;
    .line 6: packed-switch v0, :data_26
    .line 9: invoke-virtual {v3}, Lf/j;->b()I
    .line 12: move-result v0
    .line 13: if-nez v0, :cond_16
    .line 15: move v1, v2
    .line 16: return v1
    .line 17: invoke-virtual {v3}, Lf/j;->b()I
    .line 20: move-result v0
    .line 21: if-nez v0, :cond_24
    .line 23: move v1, v2
    .line 24: return v1
    .line 25: nop
    .line 26: nop
    .line 27: move v0, v0
    .line 28: nop
    .line 29: nop
    .line 30: move-result-wide v0
    .line 31: nop
.end method

# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .registers 4

    .line 0: iget v0, v3, Lf/g;->i:I
    .line 2: iget-object v1, v3, Lf/g;->j:Lf/j;
    .line 4: packed-switch v0, :data_20
    .line 7: new-instance v0, Lf/f;
    .line 9: const/4 v2, 0
    .line 10: invoke-direct {v0, v1, v2}, Lf/f;-><init>(Lf/j;I)V
    .line 13: return-object v0
    .line 14: new-instance v0, Lf/h;
    .line 16: invoke-direct {v0, v1}, Lf/h;-><init>(Lf/j;)V
    .line 19: return-object v0
    .line 20: nop
    .line 21: move v0, v0
    .line 22: nop
    .line 23: nop
    .line 24: move-result v0
    .line 25: nop
.end method

# virtual methods
.method public final remove(Ljava/lang/Object;)Z
    .registers 5

    .line 0: iget v0, v3, Lf/g;->i:I
    .line 2: packed-switch v0, :data_46
    .line 5: iget-object v0, v3, Lf/g;->j:Lf/j;
    .line 7: move-object v1, v0
    .line 8: check-cast v1, Lf/a;
    .line 10: iget v2, v1, Lf/a;->d:I
    .line 12: iget-object v1, v1, Lf/a;->e:Ljava/lang/Object;
    .line 14: packed-switch v2, :data_52
    .line 17: check-cast v1, Lf/c;
    .line 19: invoke-virtual {v1, v4}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 22: move-result v4
    .line 23: goto :goto_30
    .line 24: check-cast v1, Lf/b;
    .line 26: invoke-virtual {v1, v4}, Lf/k;->f(Ljava/lang/Object;)I
    .line 29: move-result v4
    .line 30: if-ltz v4, :cond_37
    .line 32: invoke-virtual {v0, v4}, Lf/j;->c(I)V
    .line 35: const/4 v4, 1
    .line 36: goto :goto_38
    .line 37: const/4 v4, 0
    .line 38: return v4
    .line 39: new-instance v4, Ljava/lang/UnsupportedOperationException;
    .line 41: invoke-direct {v4}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 44: throw v4
    .line 45: nop
    .line 46: nop
    .line 47: move v0, v0
    .line 48: nop
    .line 49: nop
    .line 50: filled-new-array/range {}, B
    .line 53: move v0, v0
    .line 54: nop
    .line 55: nop
    .line 56: move-result v0
    .line 57: nop
.end method

# virtual methods
.method public final removeAll(Ljava/util/Collection;)Z
    .registers 5

    .line 0: iget v0, v3, Lf/g;->i:I
    .line 2: packed-switch v0, :data_60
    .line 5: iget-object v0, v3, Lf/g;->j:Lf/j;
    .line 7: check-cast v0, Lf/a;
    .line 9: iget v1, v0, Lf/a;->d:I
    .line 11: packed-switch v1, :data_66
    .line 14: new-instance v4, Ljava/lang/UnsupportedOperationException;
    .line 16: const-string v0, "not a map"
    .line 18: invoke-direct {v4, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 21: throw v4
    .line 22: iget-object v0, v0, Lf/a;->e:Ljava/lang/Object;
    .line 24: check-cast v0, Lf/b;
    .line 26: iget v1, v0, Lf/k;->k:I
    .line 28: invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 31: move-result-object v4
    .line 32: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 35: move-result v2
    .line 36: if-eqz v2, :cond_46
    .line 38: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 41: move-result-object v2
    .line 42: invoke-virtual {v0, v2}, Lf/k;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 45: goto :goto_32
    .line 46: iget v4, v0, Lf/k;->k:I
    .line 48: if-eq v1, v4, :cond_52
    .line 50: const/4 v4, 1
    .line 51: goto :goto_53
    .line 52: const/4 v4, 0
    .line 53: return v4
    .line 54: new-instance v4, Ljava/lang/UnsupportedOperationException;
    .line 56: invoke-direct {v4}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 59: throw v4
    .line 60: nop
    .line 61: move v0, v0
    .line 62: nop
    .line 63: nop
    .line 64: if-lt v0, v0, :cond_64
    .line 66: nop
    .line 67: move v0, v0
    .line 68: nop
    .line 69: nop
    .line 70: move-result-wide v0
    .line 71: nop
.end method

# virtual methods
.method public final retainAll(Ljava/util/Collection;)Z
    .registers 6

    .line 0: iget v0, v4, Lf/g;->i:I
    .line 2: packed-switch v0, :data_72
    .line 5: iget-object v0, v4, Lf/g;->j:Lf/j;
    .line 7: check-cast v0, Lf/a;
    .line 9: iget v1, v0, Lf/a;->d:I
    .line 11: packed-switch v1, :data_78
    .line 14: new-instance v5, Ljava/lang/UnsupportedOperationException;
    .line 16: const-string v0, "not a map"
    .line 18: invoke-direct {v5, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 21: throw v5
    .line 22: iget-object v0, v0, Lf/a;->e:Ljava/lang/Object;
    .line 24: check-cast v0, Lf/b;
    .line 26: iget v1, v0, Lf/k;->k:I
    .line 28: invoke-virtual {v0}, Lf/b;->keySet()Ljava/util/Set;
    .line 31: move-result-object v2
    .line 32: check-cast v2, Lf/g;
    .line 34: invoke-virtual {v2}, Lf/g;->iterator()Ljava/util/Iterator;
    .line 37: move-result-object v2
    .line 38: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 41: move-result v3
    .line 42: if-eqz v3, :cond_58
    .line 44: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 47: move-result-object v3
    .line 48: invoke-interface {v5, v3}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z
    .line 51: move-result v3
    .line 52: if-nez v3, :cond_38
    .line 54: invoke-interface {v2}, Ljava/util/Iterator;->remove()V
    .line 57: goto :goto_38
    .line 58: iget v5, v0, Lf/k;->k:I
    .line 60: if-eq v1, v5, :cond_64
    .line 62: const/4 v5, 1
    .line 63: goto :goto_65
    .line 64: const/4 v5, 0
    .line 65: return v5
    .line 66: new-instance v5, Ljava/lang/UnsupportedOperationException;
    .line 68: invoke-direct {v5}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 71: throw v5
    .line 72: nop
    .line 73: move v0, v0
    .line 74: nop
    .line 75: nop
    .line 76: 0x40 ; unknown opcode
    .line 77: nop
    .line 78: nop
    .line 79: move v0, v0
    .line 80: nop
    .line 81: nop
    .line 82: move-result-wide v0
    .line 83: nop
.end method

# virtual methods
.method public final size()I
    .registers 3

    .line 0: iget v0, v2, Lf/g;->i:I
    .line 2: iget-object v1, v2, Lf/g;->j:Lf/j;
    .line 4: packed-switch v0, :data_18
    .line 7: invoke-virtual {v1}, Lf/j;->b()I
    .line 10: move-result v0
    .line 11: return v0
    .line 12: invoke-virtual {v1}, Lf/j;->b()I
    .line 15: move-result v0
    .line 16: return v0
    .line 17: nop
    .line 18: nop
    .line 19: move v0, v0
    .line 20: nop
    .line 21: nop
    .line 22: move-object/from16 v0, v0
.end method

# virtual methods
.method public final toArray()[Ljava/lang/Object;
    .registers 7

    .line 0: iget v0, v6, Lf/g;->i:I
    .line 2: packed-switch v0, :data_34
    .line 5: iget-object v0, v6, Lf/g;->j:Lf/j;
    .line 7: invoke-virtual {v0}, Lf/j;->b()I
    .line 10: move-result v1
    .line 11: new-array v2, v1, [Ljava/lang/Object;
    .line 13: const/4 v3, 0
    .line 14: move v4, v3
    .line 15: if-ge v4, v1, :cond_26
    .line 17: invoke-virtual {v0, v4, v3}, Lf/j;->a(II)Ljava/lang/Object;
    .line 20: move-result-object v5
    .line 21: aput-object v5, v2, v4
    .line 23: add-int/lit8 v4, v4, 1
    .line 25: goto :goto_15
    .line 26: return-object v2
    .line 27: new-instance v0, Ljava/lang/UnsupportedOperationException;
    .line 29: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 32: throw v0
    .line 33: nop
    .line 34: nop
    .line 35: move v0, v0
    .line 36: nop
    .line 37: nop
    .line 38: const-wide/high16 v0, 0x0
.end method

# virtual methods
.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 4

    .line 0: iget v0, v2, Lf/g;->i:I
    .line 2: packed-switch v0, :data_20
    .line 5: iget-object v0, v2, Lf/g;->j:Lf/j;
    .line 7: const/4 v1, 0
    .line 8: invoke-virtual {v0, v3, v1}, Lf/j;->e([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 11: move-result-object v3
    .line 12: return-object v3
    .line 13: new-instance v3, Ljava/lang/UnsupportedOperationException;
    .line 15: invoke-direct {v3}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 18: throw v3
    .line 19: nop
    .line 20: nop
    .line 21: move v0, v0
    .line 22: nop
    .line 23: nop
    .line 24: move-result-wide v0
    .line 25: nop
.end method

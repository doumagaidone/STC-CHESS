.class public final Lf/l;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Cloneable;

.field public static final l:Ljava/lang/Object;

.field public i:[I
.field public j:[Ljava/lang/Object;
.field public k:I

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/Object;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Lf/l;->l:Ljava/lang/Object;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 5

    .line 0: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 4
    .line 4: move v1, v0
    .line 5: const/16 v2, 32
    .line 7: const/16 v3, 40
    .line 9: if-ge v1, v2, :cond_22
    .line 11: const/4 v2, 1
    .line 12: shl-int/2addr v2, v1
    .line 13: add-int/lit8 v2, v2, -12
    .line 15: if-gt v3, v2, :cond_19
    .line 17: move v3, v2
    .line 18: goto :goto_22
    .line 19: add-int/lit8 v1, v1, 1
    .line 21: goto :goto_5
    .line 22: div-int/2addr v3, v0
    .line 23: new-array v0, v3, [I
    .line 25: iput-object v0, v4, Lf/l;->i:[I
    .line 27: new-array v0, v3, [Ljava/lang/Object;
    .line 29: iput-object v0, v4, Lf/l;->j:[Ljava/lang/Object;
    .line 31: return-void
.end method

# virtual methods
.method public final a(I)Ljava/lang/Object;
    .registers 4

    .line 0: iget-object v0, v2, Lf/l;->i:[I
    .line 2: iget v1, v2, Lf/l;->k:I
    .line 4: invoke-static {v0, v1, v3}, Lf/d;->a([III)I
    .line 7: move-result v3
    .line 8: if-ltz v3, :cond_18
    .line 10: iget-object v0, v2, Lf/l;->j:[Ljava/lang/Object;
    .line 12: aget-object v3, v0, v3
    .line 14: sget-object v0, Lf/l;->l:Ljava/lang/Object;
    .line 16: if-ne v3, v0, :cond_19
    .line 18: const/4 v3, 0
    .line 19: return-object v3
.end method

# virtual methods
.method public final b(ILjava/lang/Cloneable;)V
    .registers 10

    .line 0: iget-object v0, v7, Lf/l;->i:[I
    .line 2: iget v1, v7, Lf/l;->k:I
    .line 4: invoke-static {v0, v1, v8}, Lf/d;->a([III)I
    .line 7: move-result v0
    .line 8: if-ltz v0, :cond_15
    .line 10: iget-object v8, v7, Lf/l;->j:[Ljava/lang/Object;
    .line 12: aput-object v9, v8, v0
    .line 14: goto :goto_115
    .line 15: not-int v0, v0
    .line 16: iget v1, v7, Lf/l;->k:I
    .line 18: if-ge v0, v1, :cond_35
    .line 20: iget-object v2, v7, Lf/l;->j:[Ljava/lang/Object;
    .line 22: aget-object v3, v2, v0
    .line 24: sget-object v4, Lf/l;->l:Ljava/lang/Object;
    .line 26: if-ne v3, v4, :cond_35
    .line 28: iget-object v1, v7, Lf/l;->i:[I
    .line 30: aput v8, v1, v0
    .line 32: aput-object v9, v2, v0
    .line 34: return-void
    .line 35: iget-object v2, v7, Lf/l;->i:[I
    .line 37: array-length v2, v2
    .line 38: const/4 v3, 1
    .line 39: if-lt v1, v2, :cond_82
    .line 41: add-int/2addr v1, v3
    .line 42: const/4 v2, 4
    .line 43: mul-int/2addr v1, v2
    .line 44: move v4, v2
    .line 45: const/16 v5, 32
    .line 47: if-ge v4, v5, :cond_60
    .line 49: shl-int v5, v3, v4
    .line 51: add-int/lit8 v5, v5, -12
    .line 53: if-gt v1, v5, :cond_57
    .line 55: move v1, v5
    .line 56: goto :goto_60
    .line 57: add-int/lit8 v4, v4, 1
    .line 59: goto :goto_45
    .line 60: div-int/2addr v1, v2
    .line 61: new-array v2, v1, [I
    .line 63: new-array v1, v1, [Ljava/lang/Object;
    .line 65: iget-object v4, v7, Lf/l;->i:[I
    .line 67: array-length v5, v4
    .line 68: const/4 v6, 0
    .line 69: invoke-static {v4, v6, v2, v6, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 72: iget-object v4, v7, Lf/l;->j:[Ljava/lang/Object;
    .line 74: array-length v5, v4
    .line 75: invoke-static {v4, v6, v1, v6, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 78: iput-object v2, v7, Lf/l;->i:[I
    .line 80: iput-object v1, v7, Lf/l;->j:[Ljava/lang/Object;
    .line 82: iget v1, v7, Lf/l;->k:I
    .line 84: sub-int/2addr v1, v0
    .line 85: if-eqz v1, :cond_102
    .line 87: iget-object v2, v7, Lf/l;->i:[I
    .line 89: add-int/lit8 v4, v0, 1
    .line 91: invoke-static {v2, v0, v2, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 94: iget-object v1, v7, Lf/l;->j:[Ljava/lang/Object;
    .line 96: iget v2, v7, Lf/l;->k:I
    .line 98: sub-int/2addr v2, v0
    .line 99: invoke-static {v1, v0, v1, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 102: iget-object v1, v7, Lf/l;->i:[I
    .line 104: aput v8, v1, v0
    .line 106: iget-object v8, v7, Lf/l;->j:[Ljava/lang/Object;
    .line 108: aput-object v9, v8, v0
    .line 110: iget v8, v7, Lf/l;->k:I
    .line 112: add-int/2addr v8, v3
    .line 113: iput v8, v7, Lf/l;->k:I
    .line 115: return-void
.end method

# virtual methods
.method public final clone()Ljava/lang/Object;
    .registers 3

    .line 0: invoke-super {v2}, Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 3: move-result-object v0
    .line 4: check-cast v0, Lf/l;
    .line 6: iget-object v1, v2, Lf/l;->i:[I
    .line 8: invoke-virtual {v1}, [I->clone()Ljava/lang/Object;
    .line 11: move-result-object v1
    .line 12: check-cast v1, [I
    .line 14: iput-object v1, v0, Lf/l;->i:[I
    .line 16: iget-object v1, v2, Lf/l;->j:[Ljava/lang/Object;
    .line 18: invoke-virtual {v1}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 21: move-result-object v1
    .line 22: check-cast v1, [Ljava/lang/Object;
    .line 24: iput-object v1, v0, Lf/l;->j:[Ljava/lang/Object;
    .line 26: return-object v0
    .line 27: move-exception v0
    .line 28: new-instance v1, Ljava/lang/AssertionError;
    .line 30: invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V
    .line 33: throw v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: iget v0, v3, Lf/l;->k:I
    .line 2: if-gtz v0, :cond_7
    .line 4: const-string v0, "{}"
    .line 6: return-object v0
    .line 7: new-instance v1, Ljava/lang/StringBuilder;
    .line 9: mul-int/lit8 v0, v0, 28
    .line 11: invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V
    .line 14: const/16 v0, 123
    .line 16: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 19: const/4 v0, 0
    .line 20: iget v2, v3, Lf/l;->k:I
    .line 22: if-ge v0, v2, :cond_61
    .line 24: if-lez v0, :cond_31
    .line 26: const-string v2, ", "
    .line 28: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 31: iget-object v2, v3, Lf/l;->i:[I
    .line 33: aget v2, v2, v0
    .line 35: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 38: const/16 v2, 61
    .line 40: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 43: iget-object v2, v3, Lf/l;->j:[Ljava/lang/Object;
    .line 45: aget-object v2, v2, v0
    .line 47: if-eq v2, v3, :cond_53
    .line 49: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 52: goto :goto_58
    .line 53: const-string v2, "(this Map)"
    .line 55: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 58: add-int/lit8 v0, v0, 1
    .line 60: goto :goto_20
    .line 61: const/16 v0, 125
    .line 63: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 66: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 69: move-result-object v0
    .line 70: return-object v0
.end method

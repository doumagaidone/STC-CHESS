.class public final Lf/f;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Iterator;

.field public final i:I
.field public j:I
.field public k:I
.field public l:Z
.field public final synthetic m:Lf/j;

# direct methods
.method public constructor <init>(Lf/j;I)V
    .registers 4

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v2, v1, Lf/f;->m:Lf/j;
    .line 5: const/4 v0, 0
    .line 6: iput-boolean v0, v1, Lf/f;->l:Z
    .line 8: iput v3, v1, Lf/f;->i:I
    .line 10: invoke-virtual {v2}, Lf/j;->b()I
    .line 13: move-result v2
    .line 14: iput v2, v1, Lf/f;->j:I
    .line 16: return-void
.end method

# virtual methods
.method public final hasNext()Z
    .registers 3

    .line 0: iget v0, v2, Lf/f;->k:I
    .line 2: iget v1, v2, Lf/f;->j:I
    .line 4: if-ge v0, v1, :cond_8
    .line 6: const/4 v0, 1
    .line 7: goto :goto_9
    .line 8: const/4 v0, 0
    .line 9: return v0
.end method

# virtual methods
.method public final next()Ljava/lang/Object;
    .registers 4

    .line 0: invoke-virtual {v3}, Lf/f;->hasNext()Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_25
    .line 6: iget v0, v3, Lf/f;->k:I
    .line 8: iget v1, v3, Lf/f;->i:I
    .line 10: iget-object v2, v3, Lf/f;->m:Lf/j;
    .line 12: invoke-virtual {v2, v0, v1}, Lf/j;->a(II)Ljava/lang/Object;
    .line 15: move-result-object v0
    .line 16: iget v1, v3, Lf/f;->k:I
    .line 18: const/4 v2, 1
    .line 19: add-int/2addr v1, v2
    .line 20: iput v1, v3, Lf/f;->k:I
    .line 22: iput-boolean v2, v3, Lf/f;->l:Z
    .line 24: return-object v0
    .line 25: new-instance v0, Ljava/util/NoSuchElementException;
    .line 27: invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V
    .line 30: throw v0
.end method

# virtual methods
.method public final remove()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lf/f;->l:Z
    .line 2: if-eqz v0, :cond_25
    .line 4: iget v0, v2, Lf/f;->k:I
    .line 6: add-int/lit8 v0, v0, -1
    .line 8: iput v0, v2, Lf/f;->k:I
    .line 10: iget v1, v2, Lf/f;->j:I
    .line 12: add-int/lit8 v1, v1, -1
    .line 14: iput v1, v2, Lf/f;->j:I
    .line 16: const/4 v1, 0
    .line 17: iput-boolean v1, v2, Lf/f;->l:Z
    .line 19: iget-object v1, v2, Lf/f;->m:Lf/j;
    .line 21: invoke-virtual {v1, v0}, Lf/j;->c(I)V
    .line 24: return-void
    .line 25: new-instance v0, Ljava/lang/IllegalStateException;
    .line 27: invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V
    .line 30: throw v0
.end method

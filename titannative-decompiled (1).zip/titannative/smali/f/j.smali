.class public abstract Lf/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Lf/g;
.field public b:Lf/g;
.field public c:Lf/i;

# direct methods
.method public static d(Ljava/util/Set;Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Ljava/util/Set;
    .line 6: const/4 v2, 0
    .line 7: if-eqz v1, :cond_30
    .line 9: check-cast v5, Ljava/util/Set;
    .line 11: invoke-interface {v4}, Ljava/util/Set;->size()I
    .line 14: move-result v1
    .line 15: invoke-interface {v5}, Ljava/util/Set;->size()I
    .line 18: move-result v3
    .line 19: if-ne v1, v3, :cond_28
    .line 21: invoke-interface {v4, v5}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z
    .line 24: move-result v4
    .line 25: if-eqz v4, :cond_28
    .line 27: goto :goto_29
    .line 28: move v0, v2
    .line 29: return v0
    .line 30: return v2
.end method

# virtual methods
.method public abstract a(II)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract b()I
.end method

# virtual methods
.method public abstract c(I)V
.end method

# virtual methods
.method public final e([Ljava/lang/Object;I)[Ljava/lang/Object;
    .registers 6

    .line 0: invoke-virtual {v3}, Lf/j;->b()I
    .line 3: move-result v0
    .line 4: array-length v1, v4
    .line 5: if-ge v1, v0, :cond_21
    .line 7: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 10: move-result-object v4
    .line 11: invoke-virtual {v4}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    .line 14: move-result-object v4
    .line 15: invoke-static {v4, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;
    .line 18: move-result-object v4
    .line 19: check-cast v4, [Ljava/lang/Object;
    .line 21: const/4 v1, 0
    .line 22: if-ge v1, v0, :cond_33
    .line 24: invoke-virtual {v3, v1, v5}, Lf/j;->a(II)Ljava/lang/Object;
    .line 27: move-result-object v2
    .line 28: aput-object v2, v4, v1
    .line 30: add-int/lit8 v1, v1, 1
    .line 32: goto :goto_22
    .line 33: array-length v5, v4
    .line 34: if-le v5, v0, :cond_39
    .line 36: const/4 v5, 0
    .line 37: aput-object v5, v4, v0
    .line 39: return-object v4
.end method

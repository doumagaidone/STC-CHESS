.class public abstract Lf/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:[I
.field public static final b:[Ljava/lang/Object;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: new-array v1, v0, [I
    .line 3: sput-object v1, Lf/d;->a:[I
    .line 5: new-array v0, v0, [Ljava/lang/Object;
    .line 7: sput-object v0, Lf/d;->b:[Ljava/lang/Object;
    .line 9: return-void
.end method

# direct methods
.method public static a([III)I
    .registers 6

    .line 0: add-int/lit8 v4, v4, -1
    .line 2: const/4 v0, 0
    .line 3: if-gt v0, v4, :cond_24
    .line 5: add-int v1, v0, v4
    .line 7: ushr-int/lit8 v1, v1, 1
    .line 9: aget v2, v3, v1
    .line 11: if-ge v2, v5, :cond_17
    .line 13: add-int/lit8 v1, v1, 1
    .line 15: move v0, v1
    .line 16: goto :goto_3
    .line 17: if-le v2, v5, :cond_23
    .line 19: add-int/lit8 v1, v1, -1
    .line 21: move v4, v1
    .line 22: goto :goto_3
    .line 23: return v1
    .line 24: not-int v3, v0
    .line 25: return v3
.end method

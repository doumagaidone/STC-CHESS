.class public final Lf/e;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/LinkedHashMap;
.field public b:I
.field public c:I
.field public d:I

# direct methods
.method public constructor <init>()V
    .registers 5

    .line 0: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/LinkedHashMap;
    .line 5: const/4 v1, 1
    .line 6: const/4 v2, 0
    .line 7: const/high16 v3, 0x3f40
    .line 9: invoke-direct {v0, v2, v3, v1}, Ljava/util/LinkedHashMap;-><init>(IFZ)V
    .line 12: iput-object v0, v4, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 14: return-void
.end method

# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0: if-eqz v2, :cond_32
    .line 2: monitor-enter v1
    .line 3: iget-object v0, v1, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 5: invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 8: move-result-object v2
    .line 9: if-eqz v2, :cond_21
    .line 11: iget v0, v1, Lf/e;->c:I
    .line 13: add-int/lit8 v0, v0, 1
    .line 15: iput v0, v1, Lf/e;->c:I
    .line 17: monitor-exit v1
    .line 18: return-object v2
    .line 19: move-exception v2
    .line 20: goto :goto_30
    .line 21: iget v2, v1, Lf/e;->d:I
    .line 23: add-int/lit8 v2, v2, 1
    .line 25: iput v2, v1, Lf/e;->d:I
    .line 27: monitor-exit v1
    .line 28: const/4 v2, 0
    .line 29: return-object v2
    .line 30: monitor-exit v1
    .line 31: throw v2
    .line 32: new-instance v2, Ljava/lang/NullPointerException;
    .line 34: const-string v0, "key == null"
    .line 36: invoke-direct {v2, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 39: throw v2
.end method

# virtual methods
.method public final b(Ljava/lang/Object;Landroid/graphics/Typeface;)V
    .registers 4

    .line 0: if-eqz v2, :cond_133
    .line 2: monitor-enter v1
    .line 3: iget v0, v1, Lf/e;->b:I
    .line 5: add-int/lit8 v0, v0, 1
    .line 7: iput v0, v1, Lf/e;->b:I
    .line 9: iget-object v0, v1, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 11: invoke-virtual {v0, v2, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 14: move-result-object v2
    .line 15: if-eqz v2, :cond_26
    .line 17: iget v2, v1, Lf/e;->b:I
    .line 19: add-int/lit8 v2, v2, -1
    .line 21: iput v2, v1, Lf/e;->b:I
    .line 23: goto :goto_26
    .line 24: move-exception v2
    .line 25: goto :goto_131
    .line 26: monitor-exit v1
    .line 27: monitor-enter v1
    .line 28: iget v2, v1, Lf/e;->b:I
    .line 30: if-ltz v2, :cond_100
    .line 32: iget-object v2, v1, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 34: invoke-virtual {v2}, Ljava/util/AbstractMap;->isEmpty()Z
    .line 37: move-result v2
    .line 38: if-eqz v2, :cond_47
    .line 40: iget v2, v1, Lf/e;->b:I
    .line 42: if-nez v2, :cond_100
    .line 44: goto :goto_47
    .line 45: move-exception v2
    .line 46: goto :goto_129
    .line 47: iget v2, v1, Lf/e;->b:I
    .line 49: const/16 v3, 16
    .line 51: if-le v2, v3, :cond_98
    .line 53: iget-object v2, v1, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 55: invoke-virtual {v2}, Ljava/util/AbstractMap;->isEmpty()Z
    .line 58: move-result v2
    .line 59: if-eqz v2, :cond_62
    .line 61: goto :goto_98
    .line 62: iget-object v2, v1, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 64: invoke-virtual {v2}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;
    .line 67: move-result-object v2
    .line 68: invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 71: move-result-object v2
    .line 72: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 75: move-result-object v2
    .line 76: check-cast v2, Ljava/util/Map$Entry;
    .line 78: invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 81: move-result-object v3
    .line 82: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 85: iget-object v2, v1, Lf/e;->a:Ljava/util/LinkedHashMap;
    .line 87: invoke-virtual {v2, v3}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 90: iget v2, v1, Lf/e;->b:I
    .line 92: add-int/lit8 v2, v2, -1
    .line 94: iput v2, v1, Lf/e;->b:I
    .line 96: monitor-exit v1
    .line 97: goto :goto_27
    .line 98: monitor-exit v1
    .line 99: return-void
    .line 100: new-instance v2, Ljava/lang/IllegalStateException;
    .line 102: new-instance v3, Ljava/lang/StringBuilder;
    .line 104: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 107: const-class v0, Lf/e;
    .line 109: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 112: move-result-object v0
    .line 113: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 116: const-string v0, ".sizeOf() is reporting inconsistent results!"
    .line 118: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 121: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 124: move-result-object v3
    .line 125: invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 128: throw v2
    .line 129: monitor-exit v1
    .line 130: throw v2
    .line 131: monitor-exit v1
    .line 132: throw v2
    .line 133: new-instance v2, Ljava/lang/NullPointerException;
    .line 135: const-string v3, "key == null || value == null"
    .line 137: invoke-direct {v2, v3}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 140: throw v2
.end method

# virtual methods
.method public final declared-synchronized toString()Ljava/lang/String;
    .registers 7

    .line 0: monitor-enter v6
    .line 1: iget v0, v6, Lf/e;->c:I
    .line 3: iget v1, v6, Lf/e;->d:I
    .line 5: add-int/2addr v1, v0
    .line 6: const/4 v2, 0
    .line 7: if-eqz v1, :cond_15
    .line 9: mul-int/lit8 v0, v0, 100
    .line 11: div-int/2addr v0, v1
    .line 12: goto :goto_16
    .line 13: move-exception v0
    .line 14: goto :goto_62
    .line 15: move v0, v2
    .line 16: sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;
    .line 18: const-string v3, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]"
    .line 20: const/4 v4, 4
    .line 21: new-array v4, v4, [Ljava/lang/Object;
    .line 23: const/16 v5, 16
    .line 25: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 28: move-result-object v5
    .line 29: aput-object v5, v4, v2
    .line 31: iget v2, v6, Lf/e;->c:I
    .line 33: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 36: move-result-object v2
    .line 37: const/4 v5, 1
    .line 38: aput-object v2, v4, v5
    .line 40: iget v2, v6, Lf/e;->d:I
    .line 42: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 45: move-result-object v2
    .line 46: const/4 v5, 2
    .line 47: aput-object v2, v4, v5
    .line 49: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 52: move-result-object v0
    .line 53: const/4 v2, 3
    .line 54: aput-object v0, v4, v2
    .line 56: invoke-static {v1, v3, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 59: move-result-object v0
    .line 60: monitor-exit v6
    .line 61: return-object v0
    .line 62: monitor-exit v6
    .line 63: throw v0
.end method

.class public final Lf/i;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Collection;

.field public final synthetic i:Lf/j;

# direct methods
.method public constructor <init>(Lf/j;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lf/i;->i:Lf/j;
    .line 5: return-void
.end method

# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .registers 2

    .line 0: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 2: invoke-direct {v1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 5: throw v1
.end method

# virtual methods
.method public final addAll(Ljava/util/Collection;)Z
    .registers 2

    .line 0: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 2: invoke-direct {v1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 5: throw v1
.end method

# virtual methods
.method public final clear()V
    .registers 3

    .line 0: iget-object v0, v2, Lf/i;->i:Lf/j;
    .line 2: check-cast v0, Lf/a;
    .line 4: iget v1, v0, Lf/a;->d:I
    .line 6: iget-object v0, v0, Lf/a;->e:Ljava/lang/Object;
    .line 8: packed-switch v1, :data_24
    .line 11: check-cast v0, Lf/c;
    .line 13: invoke-virtual {v0}, Lf/c;->clear()V
    .line 16: goto :goto_22
    .line 17: check-cast v0, Lf/b;
    .line 19: invoke-virtual {v0}, Lf/k;->clear()V
    .line 22: return-void
    .line 23: nop
    .line 24: nop
    .line 25: move v0, v0
    .line 26: nop
    .line 27: nop
    .line 28: move-object/16 v0, v6
.end method

# virtual methods
.method public final contains(Ljava/lang/Object;)Z
    .registers 4

    .line 0: iget-object v0, v2, Lf/i;->i:Lf/j;
    .line 2: check-cast v0, Lf/a;
    .line 4: iget v1, v0, Lf/a;->d:I
    .line 6: iget-object v0, v0, Lf/a;->e:Ljava/lang/Object;
    .line 8: packed-switch v1, :data_30
    .line 11: check-cast v0, Lf/c;
    .line 13: invoke-virtual {v0, v3}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 16: move-result v3
    .line 17: goto :goto_24
    .line 18: check-cast v0, Lf/b;
    .line 20: invoke-virtual {v0, v3}, Lf/k;->h(Ljava/lang/Object;)I
    .line 23: move-result v3
    .line 24: if-ltz v3, :cond_28
    .line 26: const/4 v3, 1
    .line 27: goto :goto_29
    .line 28: const/4 v3, 0
    .line 29: return v3
    .line 30: nop
    .line 31: move v0, v0
    .line 32: nop
    .line 33: nop
    .line 34: move-result v0
    .line 35: nop
.end method

# virtual methods
.method public final containsAll(Ljava/util/Collection;)Z
    .registers 3

    .line 0: invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 3: move-result-object v2
    .line 4: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 7: move-result v0
    .line 8: if-eqz v0, :cond_22
    .line 10: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 13: move-result-object v0
    .line 14: invoke-virtual {v1, v0}, Lf/i;->contains(Ljava/lang/Object;)Z
    .line 17: move-result v0
    .line 18: if-nez v0, :cond_4
    .line 20: const/4 v2, 0
    .line 21: return v2
    .line 22: const/4 v2, 1
    .line 23: return v2
.end method

# virtual methods
.method public final isEmpty()Z
    .registers 2

    .line 0: iget-object v0, v1, Lf/i;->i:Lf/j;
    .line 2: invoke-virtual {v0}, Lf/j;->b()I
    .line 5: move-result v0
    .line 6: if-nez v0, :cond_10
    .line 8: const/4 v0, 1
    .line 9: goto :goto_11
    .line 10: const/4 v0, 0
    .line 11: return v0
.end method

# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .registers 4

    .line 0: new-instance v0, Lf/f;
    .line 2: iget-object v1, v3, Lf/i;->i:Lf/j;
    .line 4: const/4 v2, 1
    .line 5: invoke-direct {v0, v1, v2}, Lf/f;-><init>(Lf/j;I)V
    .line 8: return-object v0
.end method

# virtual methods
.method public final remove(Ljava/lang/Object;)Z
    .registers 5

    .line 0: iget-object v0, v3, Lf/i;->i:Lf/j;
    .line 2: move-object v1, v0
    .line 3: check-cast v1, Lf/a;
    .line 5: iget v2, v1, Lf/a;->d:I
    .line 7: iget-object v1, v1, Lf/a;->e:Ljava/lang/Object;
    .line 9: packed-switch v2, :data_34
    .line 12: check-cast v1, Lf/c;
    .line 14: invoke-virtual {v1, v4}, Lf/c;->indexOf(Ljava/lang/Object;)I
    .line 17: move-result v4
    .line 18: goto :goto_25
    .line 19: check-cast v1, Lf/b;
    .line 21: invoke-virtual {v1, v4}, Lf/k;->h(Ljava/lang/Object;)I
    .line 24: move-result v4
    .line 25: if-ltz v4, :cond_32
    .line 27: invoke-virtual {v0, v4}, Lf/j;->c(I)V
    .line 30: const/4 v4, 1
    .line 31: return v4
    .line 32: const/4 v4, 0
    .line 33: return v4
    .line 34: nop
    .line 35: move v0, v0
    .line 36: nop
    .line 37: nop
    .line 38: move-result v0
    .line 39: nop
.end method

# virtual methods
.method public final removeAll(Ljava/util/Collection;)Z
    .registers 8

    .line 0: iget-object v0, v6, Lf/i;->i:Lf/j;
    .line 2: invoke-virtual {v0}, Lf/j;->b()I
    .line 5: move-result v1
    .line 6: const/4 v2, 0
    .line 7: move v3, v2
    .line 8: if-ge v2, v1, :cond_31
    .line 10: const/4 v4, 1
    .line 11: invoke-virtual {v0, v2, v4}, Lf/j;->a(II)Ljava/lang/Object;
    .line 14: move-result-object v5
    .line 15: invoke-interface {v7, v5}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z
    .line 18: move-result v5
    .line 19: if-eqz v5, :cond_29
    .line 21: invoke-virtual {v0, v2}, Lf/j;->c(I)V
    .line 24: add-int/lit8 v2, v2, -1
    .line 26: add-int/lit8 v1, v1, -1
    .line 28: move v3, v4
    .line 29: add-int/2addr v2, v4
    .line 30: goto :goto_8
    .line 31: return v3
.end method

# virtual methods
.method public final retainAll(Ljava/util/Collection;)Z
    .registers 8

    .line 0: iget-object v0, v6, Lf/i;->i:Lf/j;
    .line 2: invoke-virtual {v0}, Lf/j;->b()I
    .line 5: move-result v1
    .line 6: const/4 v2, 0
    .line 7: move v3, v2
    .line 8: if-ge v2, v1, :cond_31
    .line 10: const/4 v4, 1
    .line 11: invoke-virtual {v0, v2, v4}, Lf/j;->a(II)Ljava/lang/Object;
    .line 14: move-result-object v5
    .line 15: invoke-interface {v7, v5}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z
    .line 18: move-result v5
    .line 19: if-nez v5, :cond_29
    .line 21: invoke-virtual {v0, v2}, Lf/j;->c(I)V
    .line 24: add-int/lit8 v2, v2, -1
    .line 26: add-int/lit8 v1, v1, -1
    .line 28: move v3, v4
    .line 29: add-int/2addr v2, v4
    .line 30: goto :goto_8
    .line 31: return v3
.end method

# virtual methods
.method public final size()I
    .registers 2

    .line 0: iget-object v0, v1, Lf/i;->i:Lf/j;
    .line 2: invoke-virtual {v0}, Lf/j;->b()I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final toArray()[Ljava/lang/Object;
    .registers 6

    .line 0: iget-object v0, v5, Lf/i;->i:Lf/j;
    .line 2: invoke-virtual {v0}, Lf/j;->b()I
    .line 5: move-result v1
    .line 6: new-array v2, v1, [Ljava/lang/Object;
    .line 8: const/4 v3, 0
    .line 9: if-ge v3, v1, :cond_21
    .line 11: const/4 v4, 1
    .line 12: invoke-virtual {v0, v3, v4}, Lf/j;->a(II)Ljava/lang/Object;
    .line 15: move-result-object v4
    .line 16: aput-object v4, v2, v3
    .line 18: add-int/lit8 v3, v3, 1
    .line 20: goto :goto_9
    .line 21: return-object v2
.end method

# virtual methods
.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 4

    .line 0: iget-object v0, v2, Lf/i;->i:Lf/j;
    .line 2: const/4 v1, 1
    .line 3: invoke-virtual {v0, v3, v1}, Lf/j;->e([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 6: move-result-object v3
    .line 7: return-object v3
.end method

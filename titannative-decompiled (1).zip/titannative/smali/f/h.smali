.class public final Lf/h;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Iterator;
.implements Ljava/util/Map$Entry;

.field public i:I
.field public j:I
.field public k:Z
.field public final synthetic l:Lf/j;

# direct methods
.method public constructor <init>(Lf/j;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v2, v1, Lf/h;->l:Lf/j;
    .line 5: const/4 v0, 0
    .line 6: iput-boolean v0, v1, Lf/h;->k:Z
    .line 8: invoke-virtual {v2}, Lf/j;->b()I
    .line 11: move-result v2
    .line 12: add-int/lit8 v2, v2, -1
    .line 14: iput v2, v1, Lf/h;->i:I
    .line 16: const/4 v2, -1
    .line 17: iput v2, v1, Lf/h;->j:I
    .line 19: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: iget-boolean v0, v4, Lf/h;->k:Z
    .line 2: if-eqz v0, :cond_57
    .line 4: instance-of v0, v5, Ljava/util/Map$Entry;
    .line 6: const/4 v1, 0
    .line 7: if-nez v0, :cond_10
    .line 9: return v1
    .line 10: check-cast v5, Ljava/util/Map$Entry;
    .line 12: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 15: move-result-object v0
    .line 16: iget v2, v4, Lf/h;->j:I
    .line 18: iget-object v3, v4, Lf/h;->l:Lf/j;
    .line 20: invoke-virtual {v3, v2, v1}, Lf/j;->a(II)Ljava/lang/Object;
    .line 23: move-result-object v2
    .line 24: if-eq v0, v2, :cond_34
    .line 26: if-eqz v0, :cond_56
    .line 28: invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 31: move-result v0
    .line 32: if-eqz v0, :cond_56
    .line 34: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 37: move-result-object v5
    .line 38: iget v0, v4, Lf/h;->j:I
    .line 40: const/4 v2, 1
    .line 41: invoke-virtual {v3, v0, v2}, Lf/j;->a(II)Ljava/lang/Object;
    .line 44: move-result-object v0
    .line 45: if-eq v5, v0, :cond_55
    .line 47: if-eqz v5, :cond_56
    .line 49: invoke-virtual {v5, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 52: move-result v5
    .line 53: if-eqz v5, :cond_56
    .line 55: move v1, v2
    .line 56: return v1
    .line 57: new-instance v5, Ljava/lang/IllegalStateException;
    .line 59: const-string v0, "This container does not support retaining Map.Entry objects"
    .line 61: invoke-direct {v5, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 64: throw v5
.end method

# virtual methods
.method public final getKey()Ljava/lang/Object;
    .registers 4

    .line 0: iget-boolean v0, v3, Lf/h;->k:Z
    .line 2: if-eqz v0, :cond_14
    .line 4: iget v0, v3, Lf/h;->j:I
    .line 6: const/4 v1, 0
    .line 7: iget-object v2, v3, Lf/h;->l:Lf/j;
    .line 9: invoke-virtual {v2, v0, v1}, Lf/j;->a(II)Ljava/lang/Object;
    .line 12: move-result-object v0
    .line 13: return-object v0
    .line 14: new-instance v0, Ljava/lang/IllegalStateException;
    .line 16: const-string v1, "This container does not support retaining Map.Entry objects"
    .line 18: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 21: throw v0
.end method

# virtual methods
.method public final getValue()Ljava/lang/Object;
    .registers 4

    .line 0: iget-boolean v0, v3, Lf/h;->k:Z
    .line 2: if-eqz v0, :cond_14
    .line 4: iget v0, v3, Lf/h;->j:I
    .line 6: const/4 v1, 1
    .line 7: iget-object v2, v3, Lf/h;->l:Lf/j;
    .line 9: invoke-virtual {v2, v0, v1}, Lf/j;->a(II)Ljava/lang/Object;
    .line 12: move-result-object v0
    .line 13: return-object v0
    .line 14: new-instance v0, Ljava/lang/IllegalStateException;
    .line 16: const-string v1, "This container does not support retaining Map.Entry objects"
    .line 18: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 21: throw v0
.end method

# virtual methods
.method public final hasNext()Z
    .registers 3

    .line 0: iget v0, v2, Lf/h;->j:I
    .line 2: iget v1, v2, Lf/h;->i:I
    .line 4: if-ge v0, v1, :cond_8
    .line 6: const/4 v0, 1
    .line 7: goto :goto_9
    .line 8: const/4 v0, 0
    .line 9: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 6

    .line 0: iget-boolean v0, v5, Lf/h;->k:Z
    .line 2: if-eqz v0, :cond_37
    .line 4: iget v0, v5, Lf/h;->j:I
    .line 6: iget-object v1, v5, Lf/h;->l:Lf/j;
    .line 8: const/4 v2, 0
    .line 9: invoke-virtual {v1, v0, v2}, Lf/j;->a(II)Ljava/lang/Object;
    .line 12: move-result-object v0
    .line 13: iget v3, v5, Lf/h;->j:I
    .line 15: const/4 v4, 1
    .line 16: invoke-virtual {v1, v3, v4}, Lf/j;->a(II)Ljava/lang/Object;
    .line 19: move-result-object v1
    .line 20: if-nez v0, :cond_24
    .line 22: move v0, v2
    .line 23: goto :goto_28
    .line 24: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 27: move-result v0
    .line 28: if-nez v1, :cond_31
    .line 30: goto :goto_35
    .line 31: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 34: move-result v2
    .line 35: xor-int/2addr v0, v2
    .line 36: return v0
    .line 37: new-instance v0, Ljava/lang/IllegalStateException;
    .line 39: const-string v1, "This container does not support retaining Map.Entry objects"
    .line 41: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 44: throw v0
.end method

# virtual methods
.method public final next()Ljava/lang/Object;
    .registers 3

    .line 0: invoke-virtual {v2}, Lf/h;->hasNext()Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_15
    .line 6: iget v0, v2, Lf/h;->j:I
    .line 8: const/4 v1, 1
    .line 9: add-int/2addr v0, v1
    .line 10: iput v0, v2, Lf/h;->j:I
    .line 12: iput-boolean v1, v2, Lf/h;->k:Z
    .line 14: return-object v2
    .line 15: new-instance v0, Ljava/util/NoSuchElementException;
    .line 17: invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V
    .line 20: throw v0
.end method

# virtual methods
.method public final remove()V
    .registers 3

    .line 0: iget-boolean v0, v2, Lf/h;->k:Z
    .line 2: if-eqz v0, :cond_27
    .line 4: iget-object v0, v2, Lf/h;->l:Lf/j;
    .line 6: iget v1, v2, Lf/h;->j:I
    .line 8: invoke-virtual {v0, v1}, Lf/j;->c(I)V
    .line 11: iget v0, v2, Lf/h;->j:I
    .line 13: add-int/lit8 v0, v0, -1
    .line 15: iput v0, v2, Lf/h;->j:I
    .line 17: iget v0, v2, Lf/h;->i:I
    .line 19: add-int/lit8 v0, v0, -1
    .line 21: iput v0, v2, Lf/h;->i:I
    .line 23: const/4 v0, 0
    .line 24: iput-boolean v0, v2, Lf/h;->k:Z
    .line 26: return-void
    .line 27: new-instance v0, Ljava/lang/IllegalStateException;
    .line 29: invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V
    .line 32: throw v0
.end method

# virtual methods
.method public final setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0: iget-boolean v0, v3, Lf/h;->k:Z
    .line 2: if-eqz v0, :cond_38
    .line 4: iget v0, v3, Lf/h;->j:I
    .line 6: iget-object v1, v3, Lf/h;->l:Lf/j;
    .line 8: check-cast v1, Lf/a;
    .line 10: iget v2, v1, Lf/a;->d:I
    .line 12: packed-switch v2, :data_46
    .line 15: new-instance v4, Ljava/lang/UnsupportedOperationException;
    .line 17: const-string v0, "not a map"
    .line 19: invoke-direct {v4, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 22: throw v4
    .line 23: iget-object v1, v1, Lf/a;->e:Ljava/lang/Object;
    .line 25: check-cast v1, Lf/b;
    .line 27: shl-int/lit8 v0, v0, 1
    .line 29: add-int/lit8 v0, v0, 1
    .line 31: iget-object v1, v1, Lf/k;->j:[Ljava/lang/Object;
    .line 33: aget-object v2, v1, v0
    .line 35: aput-object v4, v1, v0
    .line 37: return-object v2
    .line 38: new-instance v4, Ljava/lang/IllegalStateException;
    .line 40: const-string v0, "This container does not support retaining Map.Entry objects"
    .line 42: invoke-direct {v4, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 45: throw v4
    .line 46: nop
    .line 47: move v0, v0
    .line 48: nop
    .line 49: nop
    .line 50: move-result-wide v0
    .line 51: nop
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 5: invoke-virtual {v2}, Lf/h;->getKey()Ljava/lang/Object;
    .line 8: move-result-object v1
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, "="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: invoke-virtual {v2}, Lf/h;->getValue()Ljava/lang/Object;
    .line 20: move-result-object v1
    .line 21: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 24: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 27: move-result-object v0
    .line 28: return-object v0
.end method

.class public final La0/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:La0/b;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, La0/b;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, La0/b;->a:La0/b;
    .line 7: return-void
.end method

.class public final La0/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:I

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 0: const/4 v0, 1
    .line 1: if-ne v3, v4, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v4, La0/a;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v4, La0/a;
    .line 12: iget v1, v3, La0/a;->a:I
    .line 14: iget v4, v4, La0/a;->a:I
    .line 16: if-eq v1, v4, :cond_19
    .line 18: return v2
    .line 19: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 2

    .line 0: iget v0, v1, La0/a;->a:I
    .line 2: invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "DeltaCounter(count="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, La0/a;->a:I
    .line 9: const/16 v2, 41
    .line 11: invoke-static {v0, v1, v2}, Lai/onnxruntime/b;->j(Ljava/lang/StringBuilder;IC)Ljava/lang/String;
    .line 14: move-result-object v0
    .line 15: return-object v0
.end method

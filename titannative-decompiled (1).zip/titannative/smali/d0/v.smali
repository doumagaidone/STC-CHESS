.class public abstract Ld0/v;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/lang/Object;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/Object;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Ld0/v;->a:Ljava/lang/Object;
    .line 7: return-void
.end method

# direct methods
.method public static final a(II)V
    .registers 5

    .line 0: if-ltz v3, :cond_5
    .line 2: if-ge v3, v4, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    .line 7: new-instance v1, Ljava/lang/StringBuilder;
    .line 9: const-string v2, "index ("
    .line 11: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 14: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 17: const-string v3, ") is out of bound of [0, "
    .line 19: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 25: const/16 v3, 41
    .line 27: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 33: move-result-object v3
    .line 34: invoke-direct {v0, v3}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 37: throw v0
.end method

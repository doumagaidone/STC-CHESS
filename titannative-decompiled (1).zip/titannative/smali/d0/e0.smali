.class public abstract Ld0/e0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final i:Ld0/x;
.field public final j:Ljava/util/Iterator;
.field public k:I
.field public l:Ljava/util/Map$Entry;
.field public m:Ljava/util/Map$Entry;

# direct methods
.method public constructor <init>(Ld0/x;Ljava/util/Iterator;)V
    .registers 4

    .line 0: const-string v0, "map"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "iterator"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 13: iput-object v2, v1, Ld0/e0;->i:Ld0/x;
    .line 15: iput-object v3, v1, Ld0/e0;->j:Ljava/util/Iterator;
    .line 17: invoke-virtual {v2}, Ld0/x;->f()Ld0/w;
    .line 20: move-result-object v2
    .line 21: iget v2, v2, Ld0/w;->d:I
    .line 23: iput v2, v1, Ld0/e0;->k:I
    .line 25: invoke-virtual {v1}, Ld0/e0;->b()V
    .line 28: return-void
.end method

# virtual methods
.method public final b()V
    .registers 3

    .line 0: iget-object v0, v2, Ld0/e0;->m:Ljava/util/Map$Entry;
    .line 2: iput-object v0, v2, Ld0/e0;->l:Ljava/util/Map$Entry;
    .line 4: iget-object v0, v2, Ld0/e0;->j:Ljava/util/Iterator;
    .line 6: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_19
    .line 12: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 15: move-result-object v0
    .line 16: check-cast v0, Ljava/util/Map$Entry;
    .line 18: goto :goto_20
    .line 19: const/4 v0, 0
    .line 20: iput-object v0, v2, Ld0/e0;->m:Ljava/util/Map$Entry;
    .line 22: return-void
.end method

# virtual methods
.method public final hasNext()Z
    .registers 2

    .line 0: iget-object v0, v1, Ld0/e0;->m:Ljava/util/Map$Entry;
    .line 2: if-eqz v0, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_7
    .line 6: const/4 v0, 0
    .line 7: return v0
.end method

# virtual methods
.method public final remove()V
    .registers 4

    .line 0: iget-object v0, v3, Ld0/e0;->i:Ld0/x;
    .line 2: invoke-virtual {v0}, Ld0/x;->f()Ld0/w;
    .line 5: move-result-object v1
    .line 6: iget v1, v1, Ld0/w;->d:I
    .line 8: iget v2, v3, Ld0/e0;->k:I
    .line 10: if-ne v1, v2, :cond_41
    .line 12: iget-object v1, v3, Ld0/e0;->l:Ljava/util/Map$Entry;
    .line 14: if-eqz v1, :cond_35
    .line 16: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 19: move-result-object v1
    .line 20: invoke-virtual {v0, v1}, Ld0/x;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 23: const/4 v1, 0
    .line 24: iput-object v1, v3, Ld0/e0;->l:Ljava/util/Map$Entry;
    .line 26: invoke-virtual {v0}, Ld0/x;->f()Ld0/w;
    .line 29: move-result-object v0
    .line 30: iget v0, v0, Ld0/w;->d:I
    .line 32: iput v0, v3, Ld0/e0;->k:I
    .line 34: return-void
    .line 35: new-instance v0, Ljava/lang/IllegalStateException;
    .line 37: invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V
    .line 40: throw v0
    .line 41: new-instance v0, Ljava/util/ConcurrentModificationException;
    .line 43: invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V
    .line 46: throw v0
.end method

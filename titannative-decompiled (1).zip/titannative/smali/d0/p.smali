.class public abstract Ld0/p;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lo/g2;
.field public static final b:Ljava/lang/Object;
.field public static c:Ld0/n;
.field public static d:I
.field public static final e:Ld0/l;
.field public static final f:Lv/b;
.field public static final g:Ljava/util/ArrayList;
.field public static final h:Ljava/util/ArrayList;
.field public static final i:Ljava/util/concurrent/atomic/AtomicReference;
.field public static final j:Ld0/i;
.field public static final k:Lu/d;

# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 0: new-instance v0, Lo/g2;
    .line 2: const/4 v1, 2
    .line 3: invoke-direct {v0, v1}, Lo/g2;-><init>(I)V
    .line 6: sput-object v0, Ld0/p;->a:Lo/g2;
    .line 8: new-instance v0, Ljava/lang/Object;
    .line 10: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 13: sput-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 15: sget-object v0, Ld0/n;->m:Ld0/n;
    .line 17: sput-object v0, Ld0/p;->c:Ld0/n;
    .line 19: const/4 v1, 1
    .line 20: sput v1, Ld0/p;->d:I
    .line 22: new-instance v1, Ld0/l;
    .line 24: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 27: const/16 v2, 16
    .line 29: new-array v3, v2, [I
    .line 31: iput-object v3, v1, Ld0/l;->b:[I
    .line 33: new-array v3, v2, [I
    .line 35: iput-object v3, v1, Ld0/l;->c:[I
    .line 37: new-array v3, v2, [I
    .line 39: const/4 v4, 0
    .line 40: move v5, v4
    .line 41: if-ge v5, v2, :cond_49
    .line 43: add-int/lit8 v6, v5, 1
    .line 45: aput v6, v3, v5
    .line 47: move v5, v6
    .line 48: goto :goto_41
    .line 49: iput-object v3, v1, Ld0/l;->d:[I
    .line 51: sput-object v1, Ld0/p;->e:Ld0/l;
    .line 53: new-instance v1, Lv/b;
    .line 55: invoke-direct {v1}, Lv/b;-><init>()V
    .line 58: sput-object v1, Ld0/p;->f:Lv/b;
    .line 60: new-instance v1, Ljava/util/ArrayList;
    .line 62: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 65: sput-object v1, Ld0/p;->g:Ljava/util/ArrayList;
    .line 67: new-instance v1, Ljava/util/ArrayList;
    .line 69: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 72: sput-object v1, Ld0/p;->h:Ljava/util/ArrayList;
    .line 74: new-instance v1, Ld0/b;
    .line 76: sget v2, Ld0/p;->d:I
    .line 78: add-int/lit8 v3, v2, 1
    .line 80: sput v3, Ld0/p;->d:I
    .line 82: invoke-direct {v1, v2, v0}, Ld0/b;-><init>(ILd0/n;)V
    .line 85: sget-object v0, Ld0/p;->c:Ld0/n;
    .line 87: iget v2, v1, Ld0/i;->b:I
    .line 89: invoke-virtual {v0, v2}, Ld0/n;->i(I)Ld0/n;
    .line 92: move-result-object v0
    .line 93: sput-object v0, Ld0/p;->c:Ld0/n;
    .line 95: new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;
    .line 97: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V
    .line 100: sput-object v0, Ld0/p;->i:Ljava/util/concurrent/atomic/AtomicReference;
    .line 102: invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 105: move-result-object v0
    .line 106: const-string v1, "currentGlobalSnapshot.get()"
    .line 108: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 111: check-cast v0, Ld0/i;
    .line 113: sput-object v0, Ld0/p;->j:Ld0/i;
    .line 115: new-instance v0, Lu/d;
    .line 117: invoke-direct {v0, v4, v4}, Lu/d;-><init>(II)V
    .line 120: sput-object v0, Ld0/p;->k:Lu/d;
    .line 122: return-void
.end method

# direct methods
.method public static final a()V
    .registers 1

    .line 0: sget-object v0, Ld0/o;->k:Ld0/o;
    .line 2: invoke-static {v0}, Ld0/p;->f(Ld3/c;)Ljava/lang/Object;
    .line 5: return-void
.end method

# direct methods
.method public static final b(Ld3/c;Ld3/c;)Ld3/c;
    .registers 4

    .line 0: if-eqz v2, :cond_18
    .line 2: if-eqz v3, :cond_18
    .line 4: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 7: move-result v0
    .line 8: if-nez v0, :cond_18
    .line 10: new-instance v0, Ld0/a;
    .line 12: const/4 v1, 3
    .line 13: invoke-direct {v0, v2, v3, v1}, Ld0/a;-><init>(Ld3/c;Ld3/c;I)V
    .line 16: move-object v2, v0
    .line 17: goto :goto_21
    .line 18: if-nez v2, :cond_21
    .line 20: move-object v2, v3
    .line 21: return-object v2
.end method

# direct methods
.method public static final c(Ld0/c;Ld0/c;Ld0/n;)Ljava/util/HashMap;
    .registers 15

    .line 0: invoke-virtual {v13}, Ld0/c;->w()Lv/e;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v12}, Ld0/i;->d()I
    .line 7: move-result v12
    .line 8: const/4 v1, 0
    .line 9: if-nez v0, :cond_12
    .line 11: goto :goto_112
    .line 12: invoke-virtual {v13}, Ld0/i;->e()Ld0/n;
    .line 15: move-result-object v2
    .line 16: invoke-virtual {v13}, Ld0/i;->d()I
    .line 19: move-result v3
    .line 20: invoke-virtual {v2, v3}, Ld0/n;->i(I)Ld0/n;
    .line 23: move-result-object v2
    .line 24: iget-object v3, v13, Ld0/c;->j:Ld0/n;
    .line 26: invoke-virtual {v2, v3}, Ld0/n;->f(Ld0/n;)Ld0/n;
    .line 29: move-result-object v2
    .line 30: iget-object v3, v0, Lv/e;->j:[Ljava/lang/Object;
    .line 32: iget v0, v0, Lv/e;->i:I
    .line 34: const/4 v4, 0
    .line 35: move-object v5, v1
    .line 36: if-ge v4, v0, :cond_111
    .line 38: aget-object v6, v3, v4
    .line 40: const-string v7, "null cannot be cast to non-null type T of androidx.compose.runtime.collection.IdentityArraySet"
    .line 42: invoke-static {v6, v7}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 45: check-cast v6, Ld0/f0;
    .line 47: invoke-interface {v6}, Ld0/f0;->c()Ld0/g0;
    .line 50: move-result-object v7
    .line 51: invoke-static {v7, v12, v14}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 54: move-result-object v8
    .line 55: if-nez v8, :cond_58
    .line 57: goto :goto_108
    .line 58: invoke-static {v7, v12, v2}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 61: move-result-object v9
    .line 62: if-nez v9, :cond_65
    .line 64: goto :goto_108
    .line 65: invoke-static {v8, v9}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 68: move-result v10
    .line 69: if-nez v10, :cond_108
    .line 71: invoke-virtual {v13}, Ld0/i;->d()I
    .line 74: move-result v10
    .line 75: invoke-virtual {v13}, Ld0/i;->e()Ld0/n;
    .line 78: move-result-object v11
    .line 79: invoke-static {v7, v10, v11}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 82: move-result-object v7
    .line 83: if-eqz v7, :cond_104
    .line 85: invoke-interface {v6, v9, v8, v7}, Ld0/f0;->b(Ld0/g0;Ld0/g0;Ld0/g0;)Ld0/g0;
    .line 88: move-result-object v6
    .line 89: if-eqz v6, :cond_112
    .line 91: if-nez v5, :cond_98
    .line 93: new-instance v5, Ljava/util/HashMap;
    .line 95: invoke-direct {v5}, Ljava/util/HashMap;-><init>()V
    .line 98: move-object v7, v5
    .line 99: invoke-interface {v5, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 102: move-object v5, v7
    .line 103: goto :goto_108
    .line 104: invoke-static {}, Ld0/p;->r()V
    .line 107: throw v1
    .line 108: add-int/lit8 v4, v4, 1
    .line 110: goto :goto_36
    .line 111: move-object v1, v5
    .line 112: return-object v1
.end method

# direct methods
.method public static final d(Ld0/i;)V
    .registers 2

    .line 0: sget-object v0, Ld0/p;->c:Ld0/n;
    .line 2: invoke-virtual {v1}, Ld0/i;->d()I
    .line 5: move-result v1
    .line 6: invoke-virtual {v0, v1}, Ld0/n;->e(I)Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_13
    .line 12: return-void
    .line 13: new-instance v1, Ljava/lang/IllegalStateException;
    .line 15: const-string v0, "Snapshot is not open"
    .line 17: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 20: move-result-object v0
    .line 21: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 24: throw v1
.end method

# direct methods
.method public static final e(IILd0/n;)Ld0/n;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: if-ge v1, v2, :cond_14
    .line 7: invoke-virtual {v3, v1}, Ld0/n;->i(I)Ld0/n;
    .line 10: move-result-object v3
    .line 11: add-int/lit8 v1, v1, 1
    .line 13: goto :goto_5
    .line 14: return-object v3
.end method

# direct methods
.method public static final f(Ld3/c;)Ljava/lang/Object;
    .registers 9

    .line 0: sget-object v0, Ld0/p;->j:Ld0/i;
    .line 2: const-string v1, "null cannot be cast to non-null type androidx.compose.runtime.snapshots.GlobalSnapshot"
    .line 4: invoke-static {v0, v1}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: check-cast v0, Ld0/b;
    .line 9: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 11: monitor-enter v0
    .line 12: sget-object v1, Ld0/p;->i:Ljava/util/concurrent/atomic/AtomicReference;
    .line 14: invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 17: move-result-object v1
    .line 18: const-string v2, "currentGlobalSnapshot.get()"
    .line 20: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 23: move-object v2, v1
    .line 24: check-cast v2, Ld0/b;
    .line 26: iget-object v2, v2, Ld0/c;->h:Lv/e;
    .line 28: if-eqz v2, :cond_43
    .line 30: sget-object v3, Ld0/p;->k:Lu/d;
    .line 32: iget-object v3, v3, Lu/d;->b:Ljava/lang/Object;
    .line 34: check-cast v3, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 36: const/4 v4, 1
    .line 37: invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I
    .line 40: goto :goto_43
    .line 41: move-exception v8
    .line 42: goto :goto_142
    .line 43: move-object v3, v1
    .line 44: check-cast v3, Ld0/i;
    .line 46: invoke-static {v3, v8}, Ld0/p;->v(Ld0/i;Ld3/c;)Ljava/lang/Object;
    .line 49: move-result-object v8
    .line 50: monitor-exit v0
    .line 51: const/4 v3, 0
    .line 52: if-eqz v2, :cond_107
    .line 54: const/4 v4, -1
    .line 55: monitor-enter v0
    .line 56: sget-object v5, Ld0/p;->g:Ljava/util/ArrayList;
    .line 58: invoke-static {v5}, Lt2/p;->c2(Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 61: move-result-object v5
    .line 62: monitor-exit v0
    .line 63: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 66: move-result v0
    .line 67: move v6, v3
    .line 68: if-ge v6, v0, :cond_84
    .line 70: invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 73: move-result-object v7
    .line 74: check-cast v7, Ld3/e;
    .line 76: invoke-interface {v7, v2, v1}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 79: add-int/lit8 v6, v6, 1
    .line 81: goto :goto_68
    .line 82: move-exception v8
    .line 83: goto :goto_97
    .line 84: sget-object v0, Ld0/p;->k:Lu/d;
    .line 86: iget-object v0, v0, Lu/d;->b:Ljava/lang/Object;
    .line 88: check-cast v0, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 90: invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I
    .line 93: goto :goto_107
    .line 94: move-exception v8
    .line 95: monitor-exit v0
    .line 96: throw v8
    .line 97: sget-object v0, Ld0/p;->k:Lu/d;
    .line 99: iget-object v0, v0, Lu/d;->b:Ljava/lang/Object;
    .line 101: check-cast v0, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 103: invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I
    .line 106: throw v8
    .line 107: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 109: monitor-enter v0
    .line 110: invoke-static {}, Ld0/p;->g()V
    .line 113: if-eqz v2, :cond_138
    .line 115: iget-object v1, v2, Lv/e;->j:[Ljava/lang/Object;
    .line 117: iget v2, v2, Lv/e;->i:I
    .line 119: if-ge v3, v2, :cond_138
    .line 121: aget-object v4, v1, v3
    .line 123: const-string v5, "null cannot be cast to non-null type T of androidx.compose.runtime.collection.IdentityArraySet"
    .line 125: invoke-static {v4, v5}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 128: check-cast v4, Ld0/f0;
    .line 130: invoke-static {v4}, Ld0/p;->q(Ld0/f0;)V
    .line 133: add-int/lit8 v3, v3, 1
    .line 135: goto :goto_119
    .line 136: move-exception v8
    .line 137: goto :goto_140
    .line 138: monitor-exit v0
    .line 139: return-object v8
    .line 140: monitor-exit v0
    .line 141: throw v8
    .line 142: monitor-exit v0
    .line 143: throw v8
.end method

# direct methods
.method public static final g()V
    .registers 7

    .line 0: sget-object v0, Ld0/p;->f:Lv/b;
    .line 2: iget v1, v0, Lv/b;->b:I
    .line 4: const/4 v2, 0
    .line 5: move v3, v2
    .line 6: move v4, v3
    .line 7: const/4 v5, 0
    .line 8: if-ge v3, v1, :cond_58
    .line 10: iget-object v6, v0, Lv/b;->d:Ljava/lang/Object;
    .line 12: check-cast v6, [Lu/m3;
    .line 14: aget-object v6, v6, v3
    .line 16: if-eqz v6, :cond_22
    .line 18: invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 21: move-result-object v5
    .line 22: if-eqz v5, :cond_55
    .line 24: check-cast v5, Ld0/f0;
    .line 26: invoke-static {v5}, Ld0/p;->p(Ld0/f0;)Z
    .line 29: move-result v5
    .line 30: xor-int/lit8 v5, v5, 1
    .line 32: if-nez v5, :cond_55
    .line 34: if-eq v4, v3, :cond_53
    .line 36: iget-object v5, v0, Lv/b;->d:Ljava/lang/Object;
    .line 38: check-cast v5, [Lu/m3;
    .line 40: aput-object v6, v5, v4
    .line 42: iget-object v5, v0, Lv/b;->c:Ljava/lang/Object;
    .line 44: move-object v6, v5
    .line 45: check-cast v6, [I
    .line 47: check-cast v5, [I
    .line 49: aget v5, v5, v3
    .line 51: aput v5, v6, v4
    .line 53: add-int/lit8 v4, v4, 1
    .line 55: add-int/lit8 v3, v3, 1
    .line 57: goto :goto_7
    .line 58: move v3, v4
    .line 59: if-ge v3, v1, :cond_76
    .line 61: iget-object v6, v0, Lv/b;->d:Ljava/lang/Object;
    .line 63: check-cast v6, [Lu/m3;
    .line 65: aput-object v5, v6, v3
    .line 67: iget-object v6, v0, Lv/b;->c:Ljava/lang/Object;
    .line 69: check-cast v6, [I
    .line 71: aput v2, v6, v3
    .line 73: add-int/lit8 v3, v3, 1
    .line 75: goto :goto_59
    .line 76: if-eq v4, v1, :cond_80
    .line 78: iput v4, v0, Lv/b;->b:I
    .line 80: return-void
.end method

# direct methods
.method public static final h(Ld0/i;Ld3/c;Z)Ld0/i;
    .registers 11

    .line 0: instance-of v0, v8, Ld0/c;
    .line 2: if-nez v0, :cond_13
    .line 4: if-nez v8, :cond_7
    .line 6: goto :goto_13
    .line 7: new-instance v0, Ld0/k0;
    .line 9: invoke-direct {v0, v8, v9, v10}, Ld0/k0;-><init>(Ld0/i;Ld3/c;Z)V
    .line 12: goto :goto_32
    .line 13: new-instance v7, Ld0/j0;
    .line 15: if-eqz v0, :cond_21
    .line 17: check-cast v8, Ld0/c;
    .line 19: move-object v2, v8
    .line 20: goto :goto_23
    .line 21: const/4 v8, 0
    .line 22: goto :goto_19
    .line 23: const/4 v4, 0
    .line 24: const/4 v5, 0
    .line 25: move-object v1, v7
    .line 26: move-object v3, v9
    .line 27: move v6, v10
    .line 28: invoke-direct/range {v1 .. v6}, Ld0/j0;-><init>(Ld0/c;Ld3/c;Ld3/c;ZZ)V
    .line 31: move-object v0, v7
    .line 32: return-object v0
.end method

# direct methods
.method public static final i(Ld0/g0;)Ld0/g0;
    .registers 4

    .line 0: const-string v0, "r"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 8: move-result-object v0
    .line 9: invoke-virtual {v0}, Ld0/i;->d()I
    .line 12: move-result v1
    .line 13: invoke-virtual {v0}, Ld0/i;->e()Ld0/n;
    .line 16: move-result-object v0
    .line 17: invoke-static {v3, v1, v0}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 20: move-result-object v0
    .line 21: if-nez v0, :cond_55
    .line 23: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 25: monitor-enter v0
    .line 26: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 29: move-result-object v1
    .line 30: invoke-virtual {v1}, Ld0/i;->d()I
    .line 33: move-result v2
    .line 34: invoke-virtual {v1}, Ld0/i;->e()Ld0/n;
    .line 37: move-result-object v1
    .line 38: invoke-static {v3, v2, v1}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 41: move-result-object v3
    .line 42: monitor-exit v0
    .line 43: if-eqz v3, :cond_47
    .line 45: move-object v0, v3
    .line 46: goto :goto_55
    .line 47: invoke-static {}, Ld0/p;->r()V
    .line 50: const/4 v3, 0
    .line 51: throw v3
    .line 52: move-exception v3
    .line 53: monitor-exit v0
    .line 54: throw v3
    .line 55: return-object v0
.end method

# direct methods
.method public static final j()Ld0/i;
    .registers 2

    .line 0: sget-object v0, Ld0/p;->a:Lo/g2;
    .line 2: invoke-virtual {v0}, Lo/g2;->e()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ld0/i;
    .line 8: if-nez v0, :cond_23
    .line 10: sget-object v0, Ld0/p;->i:Ljava/util/concurrent/atomic/AtomicReference;
    .line 12: invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 15: move-result-object v0
    .line 16: const-string v1, "currentGlobalSnapshot.get()"
    .line 18: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 21: check-cast v0, Ld0/i;
    .line 23: return-object v0
.end method

# direct methods
.method public static final k(Ld3/c;Ld3/c;Z)Ld3/c;
    .registers 4

    .line 0: if-eqz v3, :cond_3
    .line 2: goto :goto_4
    .line 3: const/4 v2, 0
    .line 4: if-eqz v1, :cond_22
    .line 6: if-eqz v2, :cond_22
    .line 8: invoke-static {v1, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 11: move-result v3
    .line 12: if-nez v3, :cond_22
    .line 14: new-instance v3, Ld0/a;
    .line 16: const/4 v0, 2
    .line 17: invoke-direct {v3, v1, v2, v0}, Ld0/a;-><init>(Ld3/c;Ld3/c;I)V
    .line 20: move-object v1, v3
    .line 21: goto :goto_25
    .line 22: if-nez v1, :cond_25
    .line 24: move-object v1, v2
    .line 25: return-object v1
.end method

# direct methods
.method public static final l(Ld0/g0;Ld0/f0;)Ld0/g0;
    .registers 14

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "state"
    .line 7: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-interface {v13}, Ld0/f0;->c()Ld0/g0;
    .line 13: move-result-object v0
    .line 14: sget v1, Ld0/p;->d:I
    .line 16: sget-object v2, Ld0/p;->e:Ld0/l;
    .line 18: iget v3, v2, Ld0/l;->a:I
    .line 20: const/4 v4, 0
    .line 21: if-lez v3, :cond_27
    .line 23: iget-object v1, v2, Ld0/l;->b:[I
    .line 25: aget v1, v1, v4
    .line 27: const/4 v2, 1
    .line 28: sub-int/2addr v1, v2
    .line 29: const/4 v3, 0
    .line 30: move-object v5, v3
    .line 31: if-eqz v0, :cond_97
    .line 33: iget v6, v0, Ld0/g0;->a:I
    .line 35: if-nez v6, :cond_39
    .line 37: move-object v3, v0
    .line 38: goto :goto_97
    .line 39: if-eqz v6, :cond_94
    .line 41: if-gt v6, v1, :cond_94
    .line 43: add-int/lit8 v6, v6, 0
    .line 45: const-wide/16 v7, 0
    .line 47: const-wide/16 v9, 1
    .line 49: const/16 v11, 64
    .line 51: if-ltz v6, :cond_63
    .line 53: if-ge v6, v11, :cond_63
    .line 55: shl-long/2addr v9, v6
    .line 56: and-long/2addr v9, v7
    .line 57: cmp-long v6, v9, v7
    .line 59: if-eqz v6, :cond_78
    .line 61: move v6, v2
    .line 62: goto :goto_79
    .line 63: if-lt v6, v11, :cond_78
    .line 65: const/16 v11, 128
    .line 67: if-ge v6, v11, :cond_78
    .line 69: add-int/lit8 v6, v6, -64
    .line 71: shl-long/2addr v9, v6
    .line 72: and-long/2addr v9, v7
    .line 73: cmp-long v6, v9, v7
    .line 75: if-eqz v6, :cond_78
    .line 77: goto :goto_61
    .line 78: move v6, v4
    .line 79: if-nez v6, :cond_94
    .line 81: if-nez v5, :cond_85
    .line 83: move-object v5, v0
    .line 84: goto :goto_94
    .line 85: iget v1, v0, Ld0/g0;->a:I
    .line 87: iget v2, v5, Ld0/g0;->a:I
    .line 89: if-ge v1, v2, :cond_92
    .line 91: goto :goto_37
    .line 92: move-object v3, v5
    .line 93: goto :goto_97
    .line 94: iget-object v0, v0, Ld0/g0;->b:Ld0/g0;
    .line 96: goto :goto_31
    .line 97: const v0, 0x7fffffff
    .line 100: if-eqz v3, :cond_105
    .line 102: iput v0, v3, Ld0/g0;->a:I
    .line 104: goto :goto_120
    .line 105: invoke-virtual {v12}, Ld0/g0;->b()Ld0/g0;
    .line 108: move-result-object v3
    .line 109: iput v0, v3, Ld0/g0;->a:I
    .line 111: invoke-interface {v13}, Ld0/f0;->c()Ld0/g0;
    .line 114: move-result-object v12
    .line 115: iput-object v12, v3, Ld0/g0;->b:Ld0/g0;
    .line 117: invoke-interface {v13, v3}, Ld0/f0;->e(Ld0/g0;)V
    .line 120: return-object v3
.end method

# direct methods
.method public static final m(Ld0/g0;Ld0/f0;Ld0/i;)Ld0/g0;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "state"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 12: monitor-enter v0
    .line 13: invoke-static {v1, v2}, Ld0/p;->l(Ld0/g0;Ld0/f0;)Ld0/g0;
    .line 16: move-result-object v2
    .line 17: invoke-virtual {v2, v1}, Ld0/g0;->a(Ld0/g0;)V
    .line 20: invoke-virtual {v3}, Ld0/i;->d()I
    .line 23: move-result v1
    .line 24: iput v1, v2, Ld0/g0;->a:I
    .line 26: monitor-exit v0
    .line 27: return-object v2
    .line 28: move-exception v1
    .line 29: monitor-exit v0
    .line 30: throw v1
.end method

# direct methods
.method public static final n(Ld0/i;Ld0/f0;)V
    .registers 3

    .line 0: const-string v0, "state"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1}, Ld0/i;->h()I
    .line 8: move-result v0
    .line 9: add-int/lit8 v0, v0, 1
    .line 11: invoke-virtual {v1, v0}, Ld0/i;->s(I)V
    .line 14: invoke-virtual {v1}, Ld0/i;->i()Ld3/c;
    .line 17: move-result-object v1
    .line 18: if-eqz v1, :cond_23
    .line 20: invoke-interface {v1, v2}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 23: return-void
.end method

# direct methods
.method public static final o(Ld0/g0;Ld0/f0;Ld0/i;Ld0/g0;)Ld0/g0;
    .registers 6

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "state"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-virtual {v4}, Ld0/i;->g()Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_19
    .line 16: invoke-virtual {v4, v3}, Ld0/i;->n(Ld0/f0;)V
    .line 19: invoke-virtual {v4}, Ld0/i;->d()I
    .line 22: move-result v0
    .line 23: iget v1, v5, Ld0/g0;->a:I
    .line 25: if-ne v1, v0, :cond_28
    .line 27: return-object v5
    .line 28: sget-object v5, Ld0/p;->b:Ljava/lang/Object;
    .line 30: monitor-enter v5
    .line 31: invoke-static {v2, v3}, Ld0/p;->l(Ld0/g0;Ld0/f0;)Ld0/g0;
    .line 34: move-result-object v2
    .line 35: monitor-exit v5
    .line 36: iput v0, v2, Ld0/g0;->a:I
    .line 38: invoke-virtual {v4, v3}, Ld0/i;->n(Ld0/f0;)V
    .line 41: return-object v2
    .line 42: move-exception v2
    .line 43: monitor-exit v5
    .line 44: throw v2
.end method

# direct methods
.method public static final p(Ld0/f0;)Z
    .registers 11

    .line 0: invoke-interface {v10}, Ld0/f0;->c()Ld0/g0;
    .line 3: move-result-object v0
    .line 4: sget v1, Ld0/p;->d:I
    .line 6: sget-object v2, Ld0/p;->e:Ld0/l;
    .line 8: iget v3, v2, Ld0/l;->a:I
    .line 10: const/4 v4, 0
    .line 11: if-lez v3, :cond_17
    .line 13: iget-object v1, v2, Ld0/l;->b:[I
    .line 15: aget v1, v1, v4
    .line 17: const/4 v2, 0
    .line 18: move-object v3, v2
    .line 19: move v5, v4
    .line 20: if-eqz v0, :cond_77
    .line 22: iget v6, v0, Ld0/g0;->a:I
    .line 24: if-eqz v6, :cond_74
    .line 26: if-ge v6, v1, :cond_72
    .line 28: if-nez v2, :cond_34
    .line 30: add-int/lit8 v5, v5, 1
    .line 32: move-object v2, v0
    .line 33: goto :goto_74
    .line 34: iget v7, v2, Ld0/g0;->a:I
    .line 36: if-ge v6, v7, :cond_41
    .line 38: move-object v6, v2
    .line 39: move-object v2, v0
    .line 40: goto :goto_42
    .line 41: move-object v6, v0
    .line 42: if-nez v3, :cond_65
    .line 44: invoke-interface {v10}, Ld0/f0;->c()Ld0/g0;
    .line 47: move-result-object v3
    .line 48: move-object v7, v3
    .line 49: if-eqz v3, :cond_64
    .line 51: iget v8, v3, Ld0/g0;->a:I
    .line 53: if-lt v8, v1, :cond_56
    .line 55: goto :goto_65
    .line 56: iget v9, v7, Ld0/g0;->a:I
    .line 58: if-ge v9, v8, :cond_61
    .line 60: move-object v7, v3
    .line 61: iget-object v3, v3, Ld0/g0;->b:Ld0/g0;
    .line 63: goto :goto_49
    .line 64: move-object v3, v7
    .line 65: iput v4, v2, Ld0/g0;->a:I
    .line 67: invoke-virtual {v2, v3}, Ld0/g0;->a(Ld0/g0;)V
    .line 70: move-object v2, v6
    .line 71: goto :goto_74
    .line 72: add-int/lit8 v5, v5, 1
    .line 74: iget-object v0, v0, Ld0/g0;->b:Ld0/g0;
    .line 76: goto :goto_20
    .line 77: const/4 v10, 1
    .line 78: if-le v5, v10, :cond_81
    .line 80: move v4, v10
    .line 81: return v4
.end method

# direct methods
.method public static final q(Ld0/f0;)V
    .registers 15

    .line 0: invoke-static {v14}, Ld0/p;->p(Ld0/f0;)Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_164
    .line 6: sget-object v0, Ld0/p;->f:Lv/b;
    .line 8: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 11: iget v1, v0, Lv/b;->b:I
    .line 13: invoke-static {v14}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    .line 16: move-result v2
    .line 17: if-lez v1, :cond_74
    .line 19: iget v3, v0, Lv/b;->b:I
    .line 21: add-int/lit8 v3, v3, -1
    .line 23: const/4 v4, 0
    .line 24: if-gt v4, v3, :cond_68
    .line 26: add-int v5, v4, v3
    .line 28: ushr-int/lit8 v5, v5, 1
    .line 30: iget-object v6, v0, Lv/b;->c:Ljava/lang/Object;
    .line 32: check-cast v6, [I
    .line 34: aget v6, v6, v5
    .line 36: if-ge v6, v2, :cond_41
    .line 38: add-int/lit8 v4, v5, 1
    .line 40: goto :goto_24
    .line 41: if-le v6, v2, :cond_46
    .line 43: add-int/lit8 v3, v5, -1
    .line 45: goto :goto_24
    .line 46: iget-object v3, v0, Lv/b;->d:Ljava/lang/Object;
    .line 48: check-cast v3, [Lu/m3;
    .line 50: aget-object v3, v3, v5
    .line 52: if-eqz v3, :cond_59
    .line 54: invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 57: move-result-object v3
    .line 58: goto :goto_60
    .line 59: const/4 v3, 0
    .line 60: if-ne v14, v3, :cond_63
    .line 62: goto :goto_71
    .line 63: invoke-virtual {v0, v5, v2, v14}, Lv/b;->c(IILjava/lang/Object;)I
    .line 66: move-result v5
    .line 67: goto :goto_71
    .line 68: add-int/lit8 v4, v4, 1
    .line 70: neg-int v5, v4
    .line 71: if-ltz v5, :cond_75
    .line 73: goto :goto_164
    .line 74: const/4 v5, -1
    .line 75: add-int/lit8 v5, v5, 1
    .line 77: neg-int v3, v5
    .line 78: iget-object v4, v0, Lv/b;->d:Ljava/lang/Object;
    .line 80: check-cast v4, [Lu/m3;
    .line 82: array-length v5, v4
    .line 83: if-ne v1, v5, :cond_129
    .line 85: mul-int/lit8 v5, v5, 2
    .line 87: new-array v12, v5, [Lu/m3;
    .line 89: new-array v5, v5, [I
    .line 91: add-int/lit8 v13, v3, 1
    .line 93: invoke-static {v4, v12, v13, v3, v1}, Lt2/k;->N0([Ljava/lang/Object;[Ljava/lang/Object;III)V
    .line 96: iget-object v4, v0, Lv/b;->d:Ljava/lang/Object;
    .line 98: move-object v6, v4
    .line 99: check-cast v6, [Lu/m3;
    .line 101: const/4 v8, 0
    .line 102: const/4 v9, 0
    .line 103: const/4 v11, 6
    .line 104: move-object v7, v12
    .line 105: move v10, v3
    .line 106: invoke-static/range {v6 .. v11}, Lt2/k;->P0([Ljava/lang/Object;[Ljava/lang/Object;IIII)V
    .line 109: iget-object v4, v0, Lv/b;->c:Ljava/lang/Object;
    .line 111: check-cast v4, [I
    .line 113: invoke-static {v4, v5, v13, v3, v1}, Lt2/k;->M0([I[IIII)V
    .line 116: iget-object v1, v0, Lv/b;->c:Ljava/lang/Object;
    .line 118: check-cast v1, [I
    .line 120: const/4 v4, 6
    .line 121: invoke-static {v1, v5, v3, v4}, Lt2/k;->O0([I[III)V
    .line 124: iput-object v12, v0, Lv/b;->d:Ljava/lang/Object;
    .line 126: iput-object v5, v0, Lv/b;->c:Ljava/lang/Object;
    .line 128: goto :goto_141
    .line 129: add-int/lit8 v5, v3, 1
    .line 131: invoke-static {v4, v4, v5, v3, v1}, Lt2/k;->N0([Ljava/lang/Object;[Ljava/lang/Object;III)V
    .line 134: iget-object v4, v0, Lv/b;->c:Ljava/lang/Object;
    .line 136: check-cast v4, [I
    .line 138: invoke-static {v4, v4, v5, v3, v1}, Lt2/k;->M0([I[IIII)V
    .line 141: iget-object v1, v0, Lv/b;->d:Ljava/lang/Object;
    .line 143: check-cast v1, [Lu/m3;
    .line 145: new-instance v4, Lu/m3;
    .line 147: invoke-direct {v4, v14}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 150: aput-object v4, v1, v3
    .line 152: iget-object v14, v0, Lv/b;->c:Ljava/lang/Object;
    .line 154: check-cast v14, [I
    .line 156: aput v2, v14, v3
    .line 158: iget v14, v0, Lv/b;->b:I
    .line 160: add-int/lit8 v14, v14, 1
    .line 162: iput v14, v0, Lv/b;->b:I
    .line 164: return-void
.end method

# direct methods
.method public static final r()V
    .registers 2

    .line 0: new-instance v0, Ljava/lang/IllegalStateException;
    .line 2: const-string v1, "Reading a state that was created after the snapshot was taken or in a snapshot that has not yet been applied"
    .line 4: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 7: move-result-object v1
    .line 8: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 11: throw v0
.end method

# direct methods
.method public static final s(Ld0/g0;ILd0/n;)Ld0/g0;
    .registers 7

    .line 0: const/4 v0, 0
    .line 1: move-object v1, v0
    .line 2: if-eqz v4, :cond_29
    .line 4: iget v2, v4, Ld0/g0;->a:I
    .line 6: if-eqz v2, :cond_26
    .line 8: if-gt v2, v5, :cond_26
    .line 10: invoke-virtual {v6, v2}, Ld0/n;->e(I)Z
    .line 13: move-result v2
    .line 14: if-nez v2, :cond_26
    .line 16: if-nez v1, :cond_19
    .line 18: goto :goto_25
    .line 19: iget v2, v1, Ld0/g0;->a:I
    .line 21: iget v3, v4, Ld0/g0;->a:I
    .line 23: if-ge v2, v3, :cond_26
    .line 25: move-object v1, v4
    .line 26: iget-object v4, v4, Ld0/g0;->b:Ld0/g0;
    .line 28: goto :goto_2
    .line 29: if-eqz v1, :cond_32
    .line 31: return-object v1
    .line 32: return-object v0
.end method

# direct methods
.method public static final t(Ld0/g0;Ld0/f0;)Ld0/g0;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "state"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 13: move-result-object v0
    .line 14: invoke-virtual {v0}, Ld0/i;->f()Ld3/c;
    .line 17: move-result-object v1
    .line 18: if-eqz v1, :cond_23
    .line 20: invoke-interface {v1, v3}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 23: invoke-virtual {v0}, Ld0/i;->d()I
    .line 26: move-result v1
    .line 27: invoke-virtual {v0}, Ld0/i;->e()Ld0/n;
    .line 30: move-result-object v0
    .line 31: invoke-static {v2, v1, v0}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 34: move-result-object v2
    .line 35: if-nez v2, :cond_78
    .line 37: sget-object v2, Ld0/p;->b:Ljava/lang/Object;
    .line 39: monitor-enter v2
    .line 40: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 43: move-result-object v0
    .line 44: invoke-interface {v3}, Ld0/f0;->c()Ld0/g0;
    .line 47: move-result-object v3
    .line 48: const-string v1, "null cannot be cast to non-null type T of androidx.compose.runtime.snapshots.SnapshotKt.readable$lambda$9"
    .line 50: invoke-static {v3, v1}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 53: invoke-virtual {v0}, Ld0/i;->d()I
    .line 56: move-result v1
    .line 57: invoke-virtual {v0}, Ld0/i;->e()Ld0/n;
    .line 60: move-result-object v0
    .line 61: invoke-static {v3, v1, v0}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 64: move-result-object v3
    .line 65: if-eqz v3, :cond_70
    .line 67: monitor-exit v2
    .line 68: move-object v2, v3
    .line 69: goto :goto_78
    .line 70: invoke-static {}, Ld0/p;->r()V
    .line 73: const/4 v3, 0
    .line 74: throw v3
    .line 75: move-exception v3
    .line 76: monitor-exit v2
    .line 77: throw v3
    .line 78: return-object v2
.end method

# direct methods
.method public static final u(I)V
    .registers 9

    .line 0: sget-object v0, Ld0/p;->e:Ld0/l;
    .line 2: iget-object v1, v0, Ld0/l;->d:[I
    .line 4: aget v1, v1, v8
    .line 6: iget v2, v0, Ld0/l;->a:I
    .line 8: add-int/lit8 v2, v2, -1
    .line 10: invoke-virtual {v0, v1, v2}, Ld0/l;->b(II)V
    .line 13: iget v2, v0, Ld0/l;->a:I
    .line 15: add-int/lit8 v2, v2, -1
    .line 17: iput v2, v0, Ld0/l;->a:I
    .line 19: iget-object v2, v0, Ld0/l;->b:[I
    .line 21: aget v3, v2, v1
    .line 23: move v4, v1
    .line 24: if-lez v4, :cond_41
    .line 26: add-int/lit8 v5, v4, 1
    .line 28: shr-int/lit8 v5, v5, 1
    .line 30: add-int/lit8 v5, v5, -1
    .line 32: aget v6, v2, v5
    .line 34: if-le v6, v3, :cond_41
    .line 36: invoke-virtual {v0, v5, v4}, Ld0/l;->b(II)V
    .line 39: move v4, v5
    .line 40: goto :goto_24
    .line 41: iget-object v2, v0, Ld0/l;->b:[I
    .line 43: iget v3, v0, Ld0/l;->a:I
    .line 45: shr-int/lit8 v3, v3, 1
    .line 47: if-ge v1, v3, :cond_85
    .line 49: add-int/lit8 v4, v1, 1
    .line 51: shl-int/lit8 v4, v4, 1
    .line 53: add-int/lit8 v5, v4, -1
    .line 55: iget v6, v0, Ld0/l;->a:I
    .line 57: if-ge v4, v6, :cond_74
    .line 59: aget v6, v2, v4
    .line 61: aget v7, v2, v5
    .line 63: if-ge v6, v7, :cond_74
    .line 65: aget v5, v2, v1
    .line 67: if-ge v6, v5, :cond_85
    .line 69: invoke-virtual {v0, v4, v1}, Ld0/l;->b(II)V
    .line 72: move v1, v4
    .line 73: goto :goto_47
    .line 74: aget v4, v2, v5
    .line 76: aget v6, v2, v1
    .line 78: if-ge v4, v6, :cond_85
    .line 80: invoke-virtual {v0, v5, v1}, Ld0/l;->b(II)V
    .line 83: move v1, v5
    .line 84: goto :goto_47
    .line 85: iget-object v1, v0, Ld0/l;->d:[I
    .line 87: iget v2, v0, Ld0/l;->e:I
    .line 89: aput v2, v1, v8
    .line 91: iput v8, v0, Ld0/l;->e:I
    .line 93: return-void
.end method

# direct methods
.method public static final v(Ld0/i;Ld3/c;)Ljava/lang/Object;
    .registers 7

    .line 0: sget-object v0, Ld0/p;->c:Ld0/n;
    .line 2: invoke-virtual {v5}, Ld0/i;->d()I
    .line 5: move-result v1
    .line 6: invoke-virtual {v0, v1}, Ld0/n;->c(I)Ld0/n;
    .line 9: move-result-object v0
    .line 10: invoke-interface {v6, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 13: move-result-object v6
    .line 14: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 16: monitor-enter v0
    .line 17: sget v1, Ld0/p;->d:I
    .line 19: add-int/lit8 v2, v1, 1
    .line 21: sput v2, Ld0/p;->d:I
    .line 23: sget-object v2, Ld0/p;->c:Ld0/n;
    .line 25: invoke-virtual {v5}, Ld0/i;->d()I
    .line 28: move-result v3
    .line 29: invoke-virtual {v2, v3}, Ld0/n;->c(I)Ld0/n;
    .line 32: move-result-object v2
    .line 33: sput-object v2, Ld0/p;->c:Ld0/n;
    .line 35: sget-object v3, Ld0/p;->i:Ljava/util/concurrent/atomic/AtomicReference;
    .line 37: new-instance v4, Ld0/b;
    .line 39: invoke-direct {v4, v1, v2}, Ld0/b;-><init>(ILd0/n;)V
    .line 42: invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    .line 45: invoke-virtual {v5}, Ld0/i;->c()V
    .line 48: sget-object v5, Ld0/p;->c:Ld0/n;
    .line 50: invoke-virtual {v5, v1}, Ld0/n;->i(I)Ld0/n;
    .line 53: move-result-object v5
    .line 54: sput-object v5, Ld0/p;->c:Ld0/n;
    .line 56: monitor-exit v0
    .line 57: return-object v6
    .line 58: move-exception v5
    .line 59: monitor-exit v0
    .line 60: throw v5
.end method

# direct methods
.method public static final w(Ld0/g0;Ld0/f0;Ld0/i;)Ld0/g0;
    .registers 5

    .line 0: const-string v0, "state"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v4}, Ld0/i;->g()Z
    .line 8: move-result v0
    .line 9: if-eqz v0, :cond_14
    .line 11: invoke-virtual {v4, v3}, Ld0/i;->n(Ld0/f0;)V
    .line 14: invoke-virtual {v4}, Ld0/i;->d()I
    .line 17: move-result v0
    .line 18: invoke-virtual {v4}, Ld0/i;->e()Ld0/n;
    .line 21: move-result-object v1
    .line 22: invoke-static {v2, v0, v1}, Ld0/p;->s(Ld0/g0;ILd0/n;)Ld0/g0;
    .line 25: move-result-object v2
    .line 26: if-eqz v2, :cond_45
    .line 28: iget v0, v2, Ld0/g0;->a:I
    .line 30: invoke-virtual {v4}, Ld0/i;->d()I
    .line 33: move-result v1
    .line 34: if-ne v0, v1, :cond_37
    .line 36: return-object v2
    .line 37: invoke-static {v2, v3, v4}, Ld0/p;->m(Ld0/g0;Ld0/f0;Ld0/i;)Ld0/g0;
    .line 40: move-result-object v2
    .line 41: invoke-virtual {v4, v3}, Ld0/i;->n(Ld0/f0;)V
    .line 44: return-object v2
    .line 45: invoke-static {}, Ld0/p;->r()V
    .line 48: const/4 v2, 0
    .line 49: throw v2
.end method

.class public abstract Ld0/y;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/lang/Object;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/Object;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Ld0/y;->a:Ljava/lang/Object;
    .line 7: return-void
.end method

# direct methods
.method public static final a()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/UnsupportedOperationException;
    .line 2: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    .line 5: throw v0
.end method

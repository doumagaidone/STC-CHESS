.class public final Ld0/l;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:I
.field public b:[I
.field public c:[I
.field public d:[I
.field public e:I

# virtual methods
.method public final a(I)I
    .registers 9

    .line 0: iget v0, v7, Ld0/l;->a:I
    .line 2: add-int/lit8 v0, v0, 1
    .line 4: iget-object v1, v7, Ld0/l;->b:[I
    .line 6: array-length v2, v1
    .line 7: const/16 v3, 14
    .line 9: const/4 v4, 0
    .line 10: if-gt v0, v2, :cond_13
    .line 12: goto :goto_31
    .line 13: mul-int/lit8 v2, v2, 2
    .line 15: new-array v0, v2, [I
    .line 17: new-array v2, v2, [I
    .line 19: invoke-static {v1, v0, v4, v3}, Lt2/k;->O0([I[III)V
    .line 22: iget-object v1, v7, Ld0/l;->c:[I
    .line 24: invoke-static {v1, v2, v4, v3}, Lt2/k;->O0([I[III)V
    .line 27: iput-object v0, v7, Ld0/l;->b:[I
    .line 29: iput-object v2, v7, Ld0/l;->c:[I
    .line 31: iget v0, v7, Ld0/l;->a:I
    .line 33: add-int/lit8 v1, v0, 1
    .line 35: iput v1, v7, Ld0/l;->a:I
    .line 37: iget-object v1, v7, Ld0/l;->d:[I
    .line 39: array-length v1, v1
    .line 40: iget v2, v7, Ld0/l;->e:I
    .line 42: if-lt v2, v1, :cond_64
    .line 44: mul-int/lit8 v1, v1, 2
    .line 46: new-array v2, v1, [I
    .line 48: move v5, v4
    .line 49: if-ge v5, v1, :cond_57
    .line 51: add-int/lit8 v6, v5, 1
    .line 53: aput v6, v2, v5
    .line 55: move v5, v6
    .line 56: goto :goto_49
    .line 57: iget-object v1, v7, Ld0/l;->d:[I
    .line 59: invoke-static {v1, v2, v4, v3}, Lt2/k;->O0([I[III)V
    .line 62: iput-object v2, v7, Ld0/l;->d:[I
    .line 64: iget v1, v7, Ld0/l;->e:I
    .line 66: iget-object v2, v7, Ld0/l;->d:[I
    .line 68: aget v3, v2, v1
    .line 70: iput v3, v7, Ld0/l;->e:I
    .line 72: iget-object v3, v7, Ld0/l;->b:[I
    .line 74: aput v8, v3, v0
    .line 76: iget-object v8, v7, Ld0/l;->c:[I
    .line 78: aput v1, v8, v0
    .line 80: aput v0, v2, v1
    .line 82: aget v8, v3, v0
    .line 84: if-lez v0, :cond_101
    .line 86: add-int/lit8 v2, v0, 1
    .line 88: shr-int/lit8 v2, v2, 1
    .line 90: add-int/lit8 v2, v2, -1
    .line 92: aget v4, v3, v2
    .line 94: if-le v4, v8, :cond_101
    .line 96: invoke-virtual {v7, v2, v0}, Ld0/l;->b(II)V
    .line 99: move v0, v2
    .line 100: goto :goto_84
    .line 101: return v1
.end method

# virtual methods
.method public final b(II)V
    .registers 8

    .line 0: iget-object v0, v5, Ld0/l;->b:[I
    .line 2: iget-object v1, v5, Ld0/l;->c:[I
    .line 4: iget-object v2, v5, Ld0/l;->d:[I
    .line 6: aget v3, v0, v6
    .line 8: aget v4, v0, v7
    .line 10: aput v4, v0, v6
    .line 12: aput v3, v0, v7
    .line 14: aget v0, v1, v6
    .line 16: aget v3, v1, v7
    .line 18: aput v3, v1, v6
    .line 20: aput v0, v1, v7
    .line 22: aget v0, v1, v6
    .line 24: aput v6, v2, v0
    .line 26: aget v6, v1, v7
    .line 28: aput v7, v2, v6
    .line 30: return-void
.end method

.class public abstract interface Ld0/f0;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public b(Ld0/g0;Ld0/g0;Ld0/g0;)Ld0/g0;
    .registers 4

    .line 0: const/4 v1, 0
    .line 1: return-object v1
.end method

# virtual methods
.method public abstract c()Ld0/g0;
.end method

# virtual methods
.method public abstract e(Ld0/g0;)V
.end method

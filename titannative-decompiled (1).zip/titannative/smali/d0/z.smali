.class public final Ld0/z;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld3/c;
.field public b:Ljava/lang/Object;
.field public c:Lv/a;
.field public d:I
.field public final e:Lv/f;
.field public final f:Lv/b;
.field public final g:Lv/e;
.field public final h:Lv/j;
.field public final i:Lu/q;
.field public j:I
.field public final k:Lv/f;
.field public final l:Ljava/util/HashMap;

# direct methods
.method public constructor <init>(Ld3/c;)V
    .registers 3

    .line 0: const-string v0, "onChanged"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Ld0/z;->a:Ld3/c;
    .line 10: const/4 v2, -1
    .line 11: iput v2, v1, Ld0/z;->d:I
    .line 13: new-instance v2, Lv/f;
    .line 15: invoke-direct {v2}, Lv/f;-><init>()V
    .line 18: iput-object v2, v1, Ld0/z;->e:Lv/f;
    .line 20: new-instance v2, Lv/b;
    .line 22: const/4 v0, 0
    .line 23: invoke-direct {v2, v0}, Lv/b;-><init>(Ljava/lang/Object;)V
    .line 26: iput-object v2, v1, Ld0/z;->f:Lv/b;
    .line 28: new-instance v2, Lv/e;
    .line 30: invoke-direct {v2}, Lv/e;-><init>()V
    .line 33: iput-object v2, v1, Ld0/z;->g:Lv/e;
    .line 35: new-instance v2, Lv/j;
    .line 37: const/16 v0, 16
    .line 39: new-array v0, v0, [Lu/r0;
    .line 41: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 44: iput-object v0, v2, Lv/j;->i:[Ljava/lang/Object;
    .line 46: const/4 v0, 0
    .line 47: iput v0, v2, Lv/j;->k:I
    .line 49: iput-object v2, v1, Ld0/z;->h:Lv/j;
    .line 51: new-instance v2, Lu/q;
    .line 53: const/4 v0, 1
    .line 54: invoke-direct {v2, v0, v1}, Lu/q;-><init>(ILjava/lang/Object;)V
    .line 57: iput-object v2, v1, Ld0/z;->i:Lu/q;
    .line 59: new-instance v2, Lv/f;
    .line 61: invoke-direct {v2}, Lv/f;-><init>()V
    .line 64: iput-object v2, v1, Ld0/z;->k:Lv/f;
    .line 66: new-instance v2, Ljava/util/HashMap;
    .line 68: invoke-direct {v2}, Ljava/util/HashMap;-><init>()V
    .line 71: iput-object v2, v1, Ld0/z;->l:Ljava/util/HashMap;
    .line 73: return-void
.end method

# virtual methods
.method public final a(Ljava/lang/Object;Lg/n;Ld3/a;)V
    .registers 21

    .line 0: move-object/from16 v1, v17
    .line 2: move-object/from16 v0, v18
    .line 4: const-string v2, "scope"
    .line 6: invoke-static {v0, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: const-string v2, "readObserver"
    .line 11: move-object/from16 v3, v19
    .line 13: invoke-static {v3, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: iget-object v2, v1, Ld0/z;->b:Ljava/lang/Object;
    .line 18: iget-object v4, v1, Ld0/z;->c:Lv/a;
    .line 20: iget v5, v1, Ld0/z;->d:I
    .line 22: iput-object v0, v1, Ld0/z;->b:Ljava/lang/Object;
    .line 24: iget-object v6, v1, Ld0/z;->f:Lv/b;
    .line 26: invoke-virtual {v6, v0}, Lv/b;->d(Ljava/lang/Object;)Ljava/lang/Object;
    .line 29: move-result-object v0
    .line 30: check-cast v0, Lv/a;
    .line 32: iput-object v0, v1, Ld0/z;->c:Lv/a;
    .line 34: iget v0, v1, Ld0/z;->d:I
    .line 36: const/4 v6, -1
    .line 37: if-ne v0, v6, :cond_49
    .line 39: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 42: move-result-object v0
    .line 43: invoke-virtual {v0}, Ld0/i;->d()I
    .line 46: move-result v0
    .line 47: iput v0, v1, Ld0/z;->d:I
    .line 49: iget-object v0, v1, Ld0/z;->i:Lu/q;
    .line 51: invoke-static {}, Le3/g;->p()Lv/j;
    .line 54: move-result-object v6
    .line 55: const/4 v7, 1
    .line 56: invoke-virtual {v6, v0}, Lv/j;->b(Ljava/lang/Object;)V
    .line 59: invoke-static/range {v19 .. v20}, Lb0/e;->i(Ld3/c;Ld3/a;)Ljava/lang/Object;
    .line 62: iget v0, v6, Lv/j;->k:I
    .line 64: sub-int/2addr v0, v7
    .line 65: invoke-virtual {v6, v0}, Lv/j;->l(I)Ljava/lang/Object;
    .line 68: iget-object v0, v1, Ld0/z;->b:Ljava/lang/Object;
    .line 70: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 73: iget v3, v1, Ld0/z;->d:I
    .line 75: iget-object v6, v1, Ld0/z;->c:Lv/a;
    .line 77: if-eqz v6, :cond_157
    .line 79: iget-object v8, v6, Lv/a;->b:[Ljava/lang/Object;
    .line 81: iget-object v9, v6, Lv/a;->c:[I
    .line 83: iget v10, v6, Lv/a;->a:I
    .line 85: const/4 v12, 0
    .line 86: const/4 v13, 0
    .line 87: if-ge v12, v10, :cond_146
    .line 89: aget-object v14, v8, v12
    .line 91: const-string v15, "null cannot be cast to non-null type kotlin.Any"
    .line 93: invoke-static {v14, v15}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 96: aget v15, v9, v12
    .line 98: if-eq v15, v3, :cond_103
    .line 100: move/from16 v16, v7
    .line 102: goto :goto_105
    .line 103: const/16 v16, 0
    .line 105: if-eqz v16, :cond_132
    .line 107: iget-object v11, v1, Ld0/z;->e:Lv/f;
    .line 109: invoke-virtual {v11, v14, v0}, Lv/f;->e(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 112: instance-of v7, v14, Lu/r0;
    .line 114: if-eqz v7, :cond_132
    .line 116: invoke-virtual {v11, v14}, Lv/f;->c(Ljava/lang/Object;)Z
    .line 119: move-result v7
    .line 120: if-nez v7, :cond_132
    .line 122: iget-object v7, v1, Ld0/z;->k:Lv/f;
    .line 124: invoke-virtual {v7, v14}, Lv/f;->f(Ljava/lang/Object;)V
    .line 127: iget-object v7, v1, Ld0/z;->l:Ljava/util/HashMap;
    .line 129: invoke-virtual {v7, v14}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 132: if-nez v16, :cond_142
    .line 134: if-eq v13, v12, :cond_140
    .line 136: aput-object v14, v8, v13
    .line 138: aput v15, v9, v13
    .line 140: add-int/lit8 v13, v13, 1
    .line 142: add-int/lit8 v12, v12, 1
    .line 144: const/4 v7, 1
    .line 145: goto :goto_87
    .line 146: move v0, v13
    .line 147: if-ge v0, v10, :cond_155
    .line 149: const/4 v3, 0
    .line 150: aput-object v3, v8, v0
    .line 152: add-int/lit8 v0, v0, 1
    .line 154: goto :goto_147
    .line 155: iput v13, v6, Lv/a;->a:I
    .line 157: iput-object v2, v1, Ld0/z;->b:Ljava/lang/Object;
    .line 159: iput-object v4, v1, Ld0/z;->c:Lv/a;
    .line 161: iput v5, v1, Ld0/z;->d:I
    .line 163: return-void
    .line 164: move-exception v0
    .line 165: iget v2, v6, Lv/j;->k:I
    .line 167: const/4 v3, 1
    .line 168: sub-int/2addr v2, v3
    .line 169: invoke-virtual {v6, v2}, Lv/j;->l(I)Ljava/lang/Object;
    .line 172: throw v0
.end method

# virtual methods
.method public final b(Ljava/util/Set;)Z
    .registers 21

    .line 0: move-object/from16 v0, v19
    .line 2: move-object/from16 v1, v20
    .line 4: iget-object v2, v0, Ld0/z;->l:Ljava/util/HashMap;
    .line 6: instance-of v3, v1, Lv/e;
    .line 8: sget-object v4, Lu/l3;->a:Lu/l3;
    .line 10: iget-object v5, v0, Ld0/z;->h:Lv/j;
    .line 12: const-string v6, "null cannot be cast to non-null type T of androidx.compose.runtime.collection.IdentityArraySet"
    .line 14: iget-object v9, v0, Ld0/z;->k:Lv/f;
    .line 16: iget-object v10, v0, Ld0/z;->e:Lv/f;
    .line 18: iget-object v11, v0, Ld0/z;->g:Lv/e;
    .line 20: if-eqz v3, :cond_185
    .line 22: check-cast v1, Lv/e;
    .line 24: iget-object v3, v1, Lv/e;->j:[Ljava/lang/Object;
    .line 26: iget v1, v1, Lv/e;->i:I
    .line 28: const/4 v12, 0
    .line 29: const/4 v13, 0
    .line 30: if-ge v12, v1, :cond_330
    .line 32: aget-object v14, v3, v12
    .line 34: invoke-static {v14, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: invoke-virtual {v9, v14}, Lv/f;->c(Ljava/lang/Object;)Z
    .line 40: move-result v15
    .line 41: if-eqz v15, :cond_140
    .line 43: invoke-virtual {v9, v14}, Lv/f;->d(Ljava/lang/Object;)I
    .line 46: move-result v15
    .line 47: if-ltz v15, :cond_140
    .line 49: invoke-virtual {v9, v15}, Lv/f;->g(I)Lv/e;
    .line 52: move-result-object v15
    .line 53: iget-object v7, v15, Lv/e;->j:[Ljava/lang/Object;
    .line 55: iget v15, v15, Lv/e;->i:I
    .line 57: const/4 v8, 0
    .line 58: if-ge v8, v15, :cond_140
    .line 60: move/from16 v20, v1
    .line 62: aget-object v1, v7, v8
    .line 64: invoke-static {v1, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 67: check-cast v1, Lu/r0;
    .line 69: move-object/from16 v16, v3
    .line 71: invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 74: move-result-object v3
    .line 75: move-object/from16 v17, v4
    .line 77: iget-object v4, v1, Lu/r0;->j:Lu/f3;
    .line 79: move-object/from16 v18, v7
    .line 81: if-nez v4, :cond_85
    .line 83: move-object/from16 v4, v17
    .line 85: invoke-virtual {v1}, Lu/r0;->g()Lu/q0;
    .line 88: move-result-object v7
    .line 89: iget-object v7, v7, Lu/q0;->f:Ljava/lang/Object;
    .line 91: invoke-interface {v4, v7, v3}, Lu/f3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 94: move-result v3
    .line 95: if-nez v3, :cond_126
    .line 97: invoke-virtual {v10, v1}, Lv/f;->d(Ljava/lang/Object;)I
    .line 100: move-result v1
    .line 101: if-ltz v1, :cond_129
    .line 103: invoke-virtual {v10, v1}, Lv/f;->g(I)Lv/e;
    .line 106: move-result-object v1
    .line 107: iget-object v3, v1, Lv/e;->j:[Ljava/lang/Object;
    .line 109: iget v1, v1, Lv/e;->i:I
    .line 111: const/4 v4, 0
    .line 112: if-ge v4, v1, :cond_129
    .line 114: aget-object v7, v3, v4
    .line 116: invoke-static {v7, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 119: invoke-virtual {v11, v7}, Lv/e;->add(Ljava/lang/Object;)Z
    .line 122: add-int/lit8 v4, v4, 1
    .line 124: const/4 v13, 1
    .line 125: goto :goto_112
    .line 126: invoke-virtual {v5, v1}, Lv/j;->b(Ljava/lang/Object;)V
    .line 129: add-int/lit8 v8, v8, 1
    .line 131: move/from16 v1, v20
    .line 133: move-object/from16 v3, v16
    .line 135: move-object/from16 v4, v17
    .line 137: move-object/from16 v7, v18
    .line 139: goto :goto_58
    .line 140: move/from16 v20, v1
    .line 142: move-object/from16 v16, v3
    .line 144: move-object/from16 v17, v4
    .line 146: invoke-virtual {v10, v14}, Lv/f;->d(Ljava/lang/Object;)I
    .line 149: move-result v1
    .line 150: if-ltz v1, :cond_175
    .line 152: invoke-virtual {v10, v1}, Lv/f;->g(I)Lv/e;
    .line 155: move-result-object v1
    .line 156: iget-object v3, v1, Lv/e;->j:[Ljava/lang/Object;
    .line 158: iget v1, v1, Lv/e;->i:I
    .line 160: const/4 v4, 0
    .line 161: if-ge v4, v1, :cond_175
    .line 163: aget-object v7, v3, v4
    .line 165: invoke-static {v7, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 168: invoke-virtual {v11, v7}, Lv/e;->add(Ljava/lang/Object;)Z
    .line 171: add-int/lit8 v4, v4, 1
    .line 173: const/4 v13, 1
    .line 174: goto :goto_161
    .line 175: add-int/lit8 v12, v12, 1
    .line 177: move/from16 v1, v20
    .line 179: move-object/from16 v3, v16
    .line 181: move-object/from16 v4, v17
    .line 183: goto/16 :goto_30
    .line 185: move-object/from16 v17, v4
    .line 187: check-cast v1, Ljava/lang/Iterable;
    .line 189: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 192: move-result-object v1
    .line 193: const/4 v13, 0
    .line 194: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 197: move-result v3
    .line 198: if-eqz v3, :cond_330
    .line 200: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 203: move-result-object v3
    .line 204: invoke-virtual {v9, v3}, Lv/f;->c(Ljava/lang/Object;)Z
    .line 207: move-result v4
    .line 208: if-eqz v4, :cond_295
    .line 210: invoke-virtual {v9, v3}, Lv/f;->d(Ljava/lang/Object;)I
    .line 213: move-result v4
    .line 214: if-ltz v4, :cond_295
    .line 216: invoke-virtual {v9, v4}, Lv/f;->g(I)Lv/e;
    .line 219: move-result-object v4
    .line 220: iget-object v7, v4, Lv/e;->j:[Ljava/lang/Object;
    .line 222: iget v4, v4, Lv/e;->i:I
    .line 224: const/4 v8, 0
    .line 225: if-ge v8, v4, :cond_295
    .line 227: aget-object v12, v7, v8
    .line 229: invoke-static {v12, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 232: check-cast v12, Lu/r0;
    .line 234: invoke-virtual {v2, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 237: move-result-object v14
    .line 238: iget-object v15, v12, Lu/r0;->j:Lu/f3;
    .line 240: move-object/from16 v20, v1
    .line 242: if-nez v15, :cond_246
    .line 244: move-object/from16 v15, v17
    .line 246: invoke-virtual {v12}, Lu/r0;->g()Lu/q0;
    .line 249: move-result-object v1
    .line 250: iget-object v1, v1, Lu/q0;->f:Ljava/lang/Object;
    .line 252: invoke-interface {v15, v1, v14}, Lu/f3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 255: move-result v1
    .line 256: if-nez v1, :cond_287
    .line 258: invoke-virtual {v10, v12}, Lv/f;->d(Ljava/lang/Object;)I
    .line 261: move-result v1
    .line 262: if-ltz v1, :cond_290
    .line 264: invoke-virtual {v10, v1}, Lv/f;->g(I)Lv/e;
    .line 267: move-result-object v1
    .line 268: iget-object v12, v1, Lv/e;->j:[Ljava/lang/Object;
    .line 270: iget v1, v1, Lv/e;->i:I
    .line 272: const/4 v14, 0
    .line 273: if-ge v14, v1, :cond_290
    .line 275: aget-object v13, v12, v14
    .line 277: invoke-static {v13, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 280: invoke-virtual {v11, v13}, Lv/e;->add(Ljava/lang/Object;)Z
    .line 283: add-int/lit8 v14, v14, 1
    .line 285: const/4 v13, 1
    .line 286: goto :goto_273
    .line 287: invoke-virtual {v5, v12}, Lv/j;->b(Ljava/lang/Object;)V
    .line 290: add-int/lit8 v8, v8, 1
    .line 292: move-object/from16 v1, v20
    .line 294: goto :goto_225
    .line 295: move-object/from16 v20, v1
    .line 297: invoke-virtual {v10, v3}, Lv/f;->d(Ljava/lang/Object;)I
    .line 300: move-result v1
    .line 301: if-ltz v1, :cond_326
    .line 303: invoke-virtual {v10, v1}, Lv/f;->g(I)Lv/e;
    .line 306: move-result-object v1
    .line 307: iget-object v3, v1, Lv/e;->j:[Ljava/lang/Object;
    .line 309: iget v1, v1, Lv/e;->i:I
    .line 311: const/4 v4, 0
    .line 312: if-ge v4, v1, :cond_326
    .line 314: aget-object v7, v3, v4
    .line 316: invoke-static {v7, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 319: invoke-virtual {v11, v7}, Lv/e;->add(Ljava/lang/Object;)Z
    .line 322: add-int/lit8 v4, v4, 1
    .line 324: const/4 v13, 1
    .line 325: goto :goto_312
    .line 326: move-object/from16 v1, v20
    .line 328: goto/16 :goto_194
    .line 330: invoke-virtual {v5}, Lv/j;->j()Z
    .line 333: move-result v1
    .line 334: if-eqz v1, :cond_413
    .line 336: iget v1, v5, Lv/j;->k:I
    .line 338: if-lez v1, :cond_410
    .line 340: iget-object v2, v5, Lv/j;->i:[Ljava/lang/Object;
    .line 342: const/4 v3, 0
    .line 343: aget-object v4, v2, v3
    .line 345: check-cast v4, Lu/r0;
    .line 347: const-string v7, "derivedState"
    .line 349: invoke-static {v4, v7}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 352: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 355: move-result-object v7
    .line 356: invoke-virtual {v7}, Ld0/i;->d()I
    .line 359: move-result v7
    .line 360: invoke-virtual {v10, v4}, Lv/f;->d(Ljava/lang/Object;)I
    .line 363: move-result v8
    .line 364: if-ltz v8, :cond_406
    .line 366: invoke-virtual {v10, v8}, Lv/f;->g(I)Lv/e;
    .line 369: move-result-object v8
    .line 370: iget-object v9, v8, Lv/e;->j:[Ljava/lang/Object;
    .line 372: iget v8, v8, Lv/e;->i:I
    .line 374: const/4 v11, 0
    .line 375: if-ge v11, v8, :cond_406
    .line 377: aget-object v12, v9, v11
    .line 379: invoke-static {v12, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 382: iget-object v14, v0, Ld0/z;->f:Lv/b;
    .line 384: invoke-virtual {v14, v12}, Lv/b;->d(Ljava/lang/Object;)Ljava/lang/Object;
    .line 387: move-result-object v15
    .line 388: check-cast v15, Lv/a;
    .line 390: if-nez v15, :cond_400
    .line 392: new-instance v15, Lv/a;
    .line 394: invoke-direct {v15}, Lv/a;-><init>()V
    .line 397: invoke-virtual {v14, v12, v15}, Lv/b;->e(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 400: invoke-virtual {v0, v4, v7, v12, v15}, Ld0/z;->c(Ljava/lang/Object;ILjava/lang/Object;Lv/a;)V
    .line 403: add-int/lit8 v11, v11, 1
    .line 405: goto :goto_375
    .line 406: add-int/lit8 v3, v3, 1
    .line 408: if-lt v3, v1, :cond_343
    .line 410: invoke-virtual {v5}, Lv/j;->f()V
    .line 413: return v13
.end method

# virtual methods
.method public final c(Ljava/lang/Object;ILjava/lang/Object;Lv/a;)V
    .registers 9

    .line 0: iget v0, v4, Ld0/z;->j:I
    .line 2: if-lez v0, :cond_5
    .line 4: return-void
    .line 5: invoke-virtual {v8, v6, v5}, Lv/a;->a(ILjava/lang/Object;)I
    .line 8: move-result v8
    .line 9: instance-of v0, v5, Lu/r0;
    .line 11: if-eqz v0, :cond_60
    .line 13: if-eq v8, v6, :cond_60
    .line 15: move-object v6, v5
    .line 16: check-cast v6, Lu/r0;
    .line 18: invoke-virtual {v6}, Lu/r0;->g()Lu/q0;
    .line 21: move-result-object v6
    .line 22: iget-object v0, v4, Ld0/z;->l:Ljava/util/HashMap;
    .line 24: iget-object v1, v6, Lu/q0;->f:Ljava/lang/Object;
    .line 26: invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 29: iget-object v6, v6, Lu/q0;->e:Lv/b;
    .line 31: const/4 v0, 0
    .line 32: if-eqz v6, :cond_40
    .line 34: iget-object v6, v6, Lv/b;->c:Ljava/lang/Object;
    .line 36: check-cast v6, [Ljava/lang/Object;
    .line 38: if-nez v6, :cond_42
    .line 40: new-array v6, v0, [Ljava/lang/Object;
    .line 42: iget-object v1, v4, Ld0/z;->k:Lv/f;
    .line 44: invoke-virtual {v1, v5}, Lv/f;->f(Ljava/lang/Object;)V
    .line 47: array-length v2, v6
    .line 48: if-ge v0, v2, :cond_60
    .line 50: aget-object v3, v6, v0
    .line 52: if-eqz v3, :cond_60
    .line 54: invoke-virtual {v1, v3, v5}, Lv/f;->a(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 57: add-int/lit8 v0, v0, 1
    .line 59: goto :goto_48
    .line 60: const/4 v6, -1
    .line 61: if-ne v8, v6, :cond_68
    .line 63: iget-object v6, v4, Ld0/z;->e:Lv/f;
    .line 65: invoke-virtual {v6, v5, v7}, Lv/f;->a(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 68: return-void
.end method

# virtual methods
.method public final d()V
    .registers 16

    .line 0: sget-object v0, Lz0/g;->u:Lz0/g;
    .line 2: iget-object v1, v15, Ld0/z;->f:Lv/b;
    .line 4: iget v2, v1, Lv/b;->b:I
    .line 6: const/4 v3, 0
    .line 7: move v4, v3
    .line 8: move v5, v4
    .line 9: if-ge v4, v2, :cond_115
    .line 11: iget-object v6, v1, Lv/b;->c:Ljava/lang/Object;
    .line 13: check-cast v6, [Ljava/lang/Object;
    .line 15: aget-object v6, v6, v4
    .line 17: const-string v7, "null cannot be cast to non-null type Key of androidx.compose.runtime.collection.IdentityArrayMap"
    .line 19: invoke-static {v6, v7}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: iget-object v7, v1, Lv/b;->d:Ljava/lang/Object;
    .line 24: check-cast v7, [Ljava/lang/Object;
    .line 26: aget-object v7, v7, v4
    .line 28: check-cast v7, Lv/a;
    .line 30: invoke-virtual {v0, v6}, Lz0/g;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 33: move-result-object v8
    .line 34: check-cast v8, Ljava/lang/Boolean;
    .line 36: invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z
    .line 39: move-result v9
    .line 40: if-eqz v9, :cond_88
    .line 42: iget-object v9, v7, Lv/a;->b:[Ljava/lang/Object;
    .line 44: iget-object v10, v7, Lv/a;->c:[I
    .line 46: iget v7, v7, Lv/a;->a:I
    .line 48: move v11, v3
    .line 49: if-ge v11, v7, :cond_88
    .line 51: aget-object v12, v9, v11
    .line 53: const-string v13, "null cannot be cast to non-null type kotlin.Any"
    .line 55: invoke-static {v12, v13}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 58: aget v13, v10, v11
    .line 60: iget-object v13, v15, Ld0/z;->e:Lv/f;
    .line 62: invoke-virtual {v13, v12, v6}, Lv/f;->e(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 65: instance-of v14, v12, Lu/r0;
    .line 67: if-eqz v14, :cond_85
    .line 69: invoke-virtual {v13, v12}, Lv/f;->c(Ljava/lang/Object;)Z
    .line 72: move-result v13
    .line 73: if-nez v13, :cond_85
    .line 75: iget-object v13, v15, Ld0/z;->k:Lv/f;
    .line 77: invoke-virtual {v13, v12}, Lv/f;->f(Ljava/lang/Object;)V
    .line 80: iget-object v13, v15, Ld0/z;->l:Ljava/util/HashMap;
    .line 82: invoke-virtual {v13, v12}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 85: add-int/lit8 v11, v11, 1
    .line 87: goto :goto_49
    .line 88: invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z
    .line 91: move-result v7
    .line 92: if-nez v7, :cond_112
    .line 94: if-eq v5, v4, :cond_110
    .line 96: iget-object v7, v1, Lv/b;->c:Ljava/lang/Object;
    .line 98: check-cast v7, [Ljava/lang/Object;
    .line 100: aput-object v6, v7, v5
    .line 102: iget-object v6, v1, Lv/b;->d:Ljava/lang/Object;
    .line 104: check-cast v6, [Ljava/lang/Object;
    .line 106: aget-object v7, v6, v4
    .line 108: aput-object v7, v6, v5
    .line 110: add-int/lit8 v5, v5, 1
    .line 112: add-int/lit8 v4, v4, 1
    .line 114: goto :goto_9
    .line 115: iget v0, v1, Lv/b;->b:I
    .line 117: if-le v0, v5, :cond_140
    .line 119: move v2, v5
    .line 120: if-ge v2, v0, :cond_138
    .line 122: iget-object v3, v1, Lv/b;->c:Ljava/lang/Object;
    .line 124: check-cast v3, [Ljava/lang/Object;
    .line 126: const/4 v4, 0
    .line 127: aput-object v4, v3, v2
    .line 129: iget-object v3, v1, Lv/b;->d:Ljava/lang/Object;
    .line 131: check-cast v3, [Ljava/lang/Object;
    .line 133: aput-object v4, v3, v2
    .line 135: add-int/lit8 v2, v2, 1
    .line 137: goto :goto_120
    .line 138: iput v5, v1, Lv/b;->b:I
    .line 140: return-void
.end method

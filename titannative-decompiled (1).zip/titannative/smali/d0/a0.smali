.class public final Ld0/a0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld3/c;
.field public final b:Ljava/util/concurrent/atomic/AtomicReference;
.field public c:Z
.field public final d:Ll/v0;
.field public final e:Lg/n;
.field public final f:Lv/j;
.field public g:Ld0/h;
.field public h:Z
.field public i:Ld0/z;

# direct methods
.method public constructor <init>(Landroidx/compose/ui/platform/r;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v2, v1, Ld0/a0;->a:Ld3/c;
    .line 5: new-instance v2, Ljava/util/concurrent/atomic/AtomicReference;
    .line 7: const/4 v0, 0
    .line 8: invoke-direct {v2, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V
    .line 11: iput-object v2, v1, Ld0/a0;->b:Ljava/util/concurrent/atomic/AtomicReference;
    .line 13: new-instance v2, Ll/v0;
    .line 15: const/4 v0, 3
    .line 16: invoke-direct {v2, v0, v1}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 19: iput-object v2, v1, Ld0/a0;->d:Ll/v0;
    .line 21: new-instance v2, Lg/n;
    .line 23: const/16 v0, 18
    .line 25: invoke-direct {v2, v0, v1}, Lg/n;-><init>(ILjava/lang/Object;)V
    .line 28: iput-object v2, v1, Ld0/a0;->e:Lg/n;
    .line 30: new-instance v2, Lv/j;
    .line 32: const/16 v0, 16
    .line 34: new-array v0, v0, [Ld0/z;
    .line 36: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 39: iput-object v0, v2, Lv/j;->i:[Ljava/lang/Object;
    .line 41: const/4 v0, 0
    .line 42: iput v0, v2, Lv/j;->k:I
    .line 44: iput-object v2, v1, Ld0/a0;->f:Lv/j;
    .line 46: return-void
.end method

# direct methods
.method public static final a(Ld0/a0;)Z
    .registers 11

    .line 0: iget-object v0, v10, Ld0/a0;->f:Lv/j;
    .line 2: monitor-enter v0
    .line 3: iget-boolean v1, v10, Ld0/a0;->c:Z
    .line 5: monitor-exit v0
    .line 6: const/4 v0, 0
    .line 7: if-eqz v1, :cond_10
    .line 9: goto :goto_82
    .line 10: move v1, v0
    .line 11: iget-object v2, v10, Ld0/a0;->b:Ljava/util/concurrent/atomic/AtomicReference;
    .line 13: invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 16: move-result-object v3
    .line 17: const/4 v4, 0
    .line 18: const/4 v5, 1
    .line 19: if-nez v3, :cond_22
    .line 21: goto :goto_79
    .line 22: instance-of v6, v3, Ljava/util/Set;
    .line 24: if-eqz v6, :cond_32
    .line 26: move-object v6, v3
    .line 27: check-cast v6, Ljava/util/Set;
    .line 29: move-object v7, v6
    .line 30: move-object v6, v4
    .line 31: goto :goto_72
    .line 32: instance-of v6, v3, Ljava/util/List;
    .line 34: if-eqz v6, :cond_129
    .line 36: move-object v6, v3
    .line 37: check-cast v6, Ljava/util/List;
    .line 39: invoke-interface {v6, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 42: move-result-object v7
    .line 43: check-cast v7, Ljava/util/Set;
    .line 45: invoke-interface {v6}, Ljava/util/List;->size()I
    .line 48: move-result v8
    .line 49: const/4 v9, 2
    .line 50: if-ne v8, v9, :cond_57
    .line 52: invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 55: move-result-object v4
    .line 56: goto :goto_30
    .line 57: invoke-interface {v6}, Ljava/util/List;->size()I
    .line 60: move-result v8
    .line 61: if-le v8, v9, :cond_30
    .line 63: invoke-interface {v6}, Ljava/util/List;->size()I
    .line 66: move-result v4
    .line 67: invoke-interface {v6, v5, v4}, Ljava/util/List;->subList(II)Ljava/util/List;
    .line 70: move-result-object v4
    .line 71: goto :goto_30
    .line 72: invoke-virtual {v2, v3, v6}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 75: move-result v4
    .line 76: if-eqz v4, :cond_122
    .line 78: move-object v4, v7
    .line 79: if-nez v4, :cond_83
    .line 81: move v0, v1
    .line 82: return v0
    .line 83: iget-object v2, v10, Ld0/a0;->f:Lv/j;
    .line 85: monitor-enter v2
    .line 86: iget-object v3, v10, Ld0/a0;->f:Lv/j;
    .line 88: iget v6, v3, Lv/j;->k:I
    .line 90: if-lez v6, :cond_118
    .line 92: iget-object v3, v3, Lv/j;->i:[Ljava/lang/Object;
    .line 94: move v7, v0
    .line 95: aget-object v8, v3, v7
    .line 97: check-cast v8, Ld0/z;
    .line 99: invoke-virtual {v8, v4}, Ld0/z;->b(Ljava/util/Set;)Z
    .line 102: move-result v8
    .line 103: if-nez v8, :cond_110
    .line 105: if-eqz v1, :cond_108
    .line 107: goto :goto_110
    .line 108: move v1, v0
    .line 109: goto :goto_111
    .line 110: move v1, v5
    .line 111: add-int/lit8 v7, v7, 1
    .line 113: if-lt v7, v6, :cond_95
    .line 115: goto :goto_118
    .line 116: move-exception v10
    .line 117: goto :goto_120
    .line 118: monitor-exit v2
    .line 119: goto :goto_11
    .line 120: monitor-exit v2
    .line 121: throw v10
    .line 122: invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 125: move-result-object v4
    .line 126: if-eq v4, v3, :cond_72
    .line 128: goto :goto_11
    .line 129: const-string v10, "Unexpected notification"
    .line 131: invoke-static {v10}, Lu/c0;->e(Ljava/lang/String;)V
    .line 134: throw v4
    .line 135: move-exception v10
    .line 136: monitor-exit v0
    .line 137: throw v10
.end method

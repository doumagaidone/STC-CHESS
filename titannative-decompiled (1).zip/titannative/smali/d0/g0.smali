.class public abstract Ld0/g0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:I
.field public b:Ld0/g0;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: invoke-static {}, Ld0/p;->j()Ld0/i;
    .line 6: move-result-object v0
    .line 7: invoke-virtual {v0}, Ld0/i;->d()I
    .line 10: move-result v0
    .line 11: iput v0, v1, Ld0/g0;->a:I
    .line 13: return-void
.end method

# virtual methods
.method public abstract a(Ld0/g0;)V
.end method

# virtual methods
.method public abstract b()Ld0/g0;
.end method

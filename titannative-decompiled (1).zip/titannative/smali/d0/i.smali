.class public abstract Ld0/i;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Ld0/n;
.field public b:I
.field public c:Z
.field public d:I

# direct methods
.method public constructor <init>(ILd0/n;)V
    .registers 9

    .line 0: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v8, v6, Ld0/i;->a:Ld0/n;
    .line 5: iput v7, v6, Ld0/i;->b:I
    .line 7: if-eqz v7, :cond_71
    .line 9: invoke-virtual {v6}, Ld0/i;->e()Ld0/n;
    .line 12: move-result-object v8
    .line 13: sget-object v0, Ld0/p;->a:Lo/g2;
    .line 15: const-string v0, "invalid"
    .line 17: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: iget-object v0, v8, Ld0/n;->l:[I
    .line 22: if-eqz v0, :cond_28
    .line 24: const/4 v7, 0
    .line 25: aget v7, v0, v7
    .line 27: goto :goto_57
    .line 28: iget-wide v0, v8, Ld0/n;->j:J
    .line 30: const-wide/16 v2, 0
    .line 32: cmp-long v4, v0, v2
    .line 34: iget v5, v8, Ld0/n;->k:I
    .line 36: if-eqz v4, :cond_44
    .line 38: invoke-static {v0, v1}, Lo/g1;->h(J)I
    .line 41: move-result v7
    .line 42: add-int/2addr v7, v5
    .line 43: goto :goto_57
    .line 44: iget-wide v0, v8, Ld0/n;->i:J
    .line 46: cmp-long v8, v0, v2
    .line 48: if-eqz v8, :cond_57
    .line 50: add-int/lit8 v5, v5, 64
    .line 52: invoke-static {v0, v1}, Lo/g1;->h(J)I
    .line 55: move-result v7
    .line 56: goto :goto_42
    .line 57: sget-object v8, Ld0/p;->b:Ljava/lang/Object;
    .line 59: monitor-enter v8
    .line 60: sget-object v0, Ld0/p;->e:Ld0/l;
    .line 62: invoke-virtual {v0, v7}, Ld0/l;->a(I)I
    .line 65: move-result v7
    .line 66: monitor-exit v8
    .line 67: goto :goto_72
    .line 68: move-exception v7
    .line 69: monitor-exit v8
    .line 70: throw v7
    .line 71: const/4 v7, -1
    .line 72: iput v7, v6, Ld0/i;->d:I
    .line 74: return-void
.end method

# direct methods
.method public static p(Ld0/i;)V
    .registers 2

    .line 0: sget-object v0, Ld0/p;->a:Lo/g2;
    .line 2: invoke-virtual {v0, v1}, Lo/g2;->i(Ljava/lang/Object;)V
    .line 5: return-void
.end method

# virtual methods
.method public final a()V
    .registers 3

    .line 0: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 2: monitor-enter v0
    .line 3: invoke-virtual {v2}, Ld0/i;->b()V
    .line 6: invoke-virtual {v2}, Ld0/i;->o()V
    .line 9: monitor-exit v0
    .line 10: return-void
    .line 11: move-exception v1
    .line 12: monitor-exit v0
    .line 13: throw v1
.end method

# virtual methods
.method public b()V
    .registers 3

    .line 0: sget-object v0, Ld0/p;->c:Ld0/n;
    .line 2: invoke-virtual {v2}, Ld0/i;->d()I
    .line 5: move-result v1
    .line 6: invoke-virtual {v0, v1}, Ld0/n;->c(I)Ld0/n;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Ld0/p;->c:Ld0/n;
    .line 12: return-void
.end method

# virtual methods
.method public abstract c()V
.end method

# virtual methods
.method public d()I
    .registers 2

    .line 0: iget v0, v1, Ld0/i;->b:I
    .line 2: return v0
.end method

# virtual methods
.method public e()Ld0/n;
    .registers 2

    .line 0: iget-object v0, v1, Ld0/i;->a:Ld0/n;
    .line 2: return-object v0
.end method

# virtual methods
.method public abstract f()Ld3/c;
.end method

# virtual methods
.method public abstract g()Z
.end method

# virtual methods
.method public h()I
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

# virtual methods
.method public abstract i()Ld3/c;
.end method

# virtual methods
.method public final j()Ld0/i;
    .registers 3

    .line 0: sget-object v0, Ld0/p;->a:Lo/g2;
    .line 2: invoke-virtual {v0}, Lo/g2;->e()Ljava/lang/Object;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Ld0/i;
    .line 8: invoke-virtual {v0, v2}, Lo/g2;->i(Ljava/lang/Object;)V
    .line 11: return-object v1
.end method

# virtual methods
.method public abstract k(Ld0/i;)V
.end method

# virtual methods
.method public abstract l(Ld0/i;)V
.end method

# virtual methods
.method public abstract m()V
.end method

# virtual methods
.method public abstract n(Ld0/f0;)V
.end method

# virtual methods
.method public o()V
    .registers 2

    .line 0: iget v0, v1, Ld0/i;->d:I
    .line 2: if-ltz v0, :cond_10
    .line 4: invoke-static {v0}, Ld0/p;->u(I)V
    .line 7: const/4 v0, -1
    .line 8: iput v0, v1, Ld0/i;->d:I
    .line 10: return-void
.end method

# virtual methods
.method public q(I)V
    .registers 2

    .line 0: iput v1, v0, Ld0/i;->b:I
    .line 2: return-void
.end method

# virtual methods
.method public r(Ld0/n;)V
    .registers 3

    .line 0: const-string v0, "<set-?>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iput-object v2, v1, Ld0/i;->a:Ld0/n;
    .line 7: return-void
.end method

# virtual methods
.method public s(I)V
    .registers 3

    .line 0: new-instance v2, Ljava/lang/IllegalStateException;
    .line 2: const-string v0, "Updating write count is not supported for this snapshot"
    .line 4: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 7: move-result-object v0
    .line 8: invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 11: throw v2
.end method

# virtual methods
.method public abstract t(Ld3/c;)Ld0/i;
.end method

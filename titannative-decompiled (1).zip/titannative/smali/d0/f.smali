.class public abstract interface Ld0/f;
.super Ljava/lang/Object;
.source "SourceFile"

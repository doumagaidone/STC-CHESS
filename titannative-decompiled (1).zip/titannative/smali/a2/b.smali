.class public abstract La2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/Size;)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putSize(Ljava/lang/String;Landroid/util/Size;)V
    .line 3: return-void
.end method

# direct methods
.method public static final b(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/SizeF;)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putSizeF(Ljava/lang/String;Landroid/util/SizeF;)V
    .line 3: return-void
.end method

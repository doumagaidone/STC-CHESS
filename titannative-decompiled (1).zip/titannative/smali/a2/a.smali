.class public abstract La2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Landroid/os/Bundle;Ljava/lang/String;Landroid/os/IBinder;)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putBinder(Ljava/lang/String;Landroid/os/IBinder;)V
    .line 3: return-void
.end method

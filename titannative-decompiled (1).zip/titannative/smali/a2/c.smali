.class public abstract La2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Ljava/lang/String;)V
    .registers 1

    .line 0: invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    .line 3: return-void
.end method

# direct methods
.method public static b()V
    .registers 0

    .line 0: invoke-static {}, Landroid/os/Trace;->endSection()V
    .line 3: return-void
.end method

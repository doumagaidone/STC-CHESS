.class public abstract La2/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:I

# direct methods
.method static constructor <clinit>()V
    .registers 10

    .line 0: const-class v0, Ljava/lang/String;
    .line 2: const-class v1, Landroid/os/Trace;
    .line 4: sget v2, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 6: const/16 v3, 29
    .line 8: if-ge v2, v3, :cond_85
    .line 10: const-string v2, "TRACE_TAG_APP"
    .line 12: invoke-virtual {v1, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    .line 15: move-result-object v2
    .line 16: const/4 v3, 0
    .line 17: invoke-virtual {v2, v3}, Ljava/lang/reflect/Field;->getLong(Ljava/lang/Object;)J
    .line 20: const-string v2, "isTagEnabled"
    .line 22: const/4 v3, 1
    .line 23: new-array v4, v3, [Ljava/lang/Class;
    .line 25: sget-object v5, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 27: const/4 v6, 0
    .line 28: aput-object v5, v4, v6
    .line 30: invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 33: const-string v2, "asyncTraceBegin"
    .line 35: const/4 v4, 3
    .line 36: new-array v7, v4, [Ljava/lang/Class;
    .line 38: aput-object v5, v7, v6
    .line 40: aput-object v0, v7, v3
    .line 42: sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 44: const/4 v9, 2
    .line 45: aput-object v8, v7, v9
    .line 47: invoke-virtual {v1, v2, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 50: const-string v2, "asyncTraceEnd"
    .line 52: new-array v7, v4, [Ljava/lang/Class;
    .line 54: aput-object v5, v7, v6
    .line 56: aput-object v0, v7, v3
    .line 58: aput-object v8, v7, v9
    .line 60: invoke-virtual {v1, v2, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 63: const-string v2, "traceCounter"
    .line 65: new-array v4, v4, [Ljava/lang/Class;
    .line 67: aput-object v5, v4, v6
    .line 69: aput-object v0, v4, v3
    .line 71: aput-object v8, v4, v9
    .line 73: invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 76: goto :goto_85
    .line 77: move-exception v0
    .line 78: const-string v1, "TraceCompat"
    .line 80: const-string v2, "Unable to initialize via reflection."
    .line 82: invoke-static {v1, v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 85: return-void
.end method

.class public final Lc3/a;
.super Ljava/io/ByteArrayOutputStream;
.source "SourceFile"

# virtual methods
.method public final a()[B
    .registers 3

    .line 0: iget-object v0, v2, Ljava/io/ByteArrayOutputStream;->buf:[B
    .line 2: const-string v1, "buf"
    .line 4: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: return-object v0
.end method

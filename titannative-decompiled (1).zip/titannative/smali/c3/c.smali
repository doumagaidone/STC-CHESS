.class public Lc3/c;
.super Ljava/io/IOException;
.source "SourceFile"

# direct methods
.method public constructor <init>(Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V
    .registers 6

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-virtual {v3}, Ljava/io/File;->toString()Ljava/lang/String;
    .line 5: move-result-object v3
    .line 6: invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 9: if-eqz v4, :cond_28
    .line 11: new-instance v3, Ljava/lang/StringBuilder;
    .line 13: const-string v1, " -> "
    .line 15: invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 18: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 21: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 24: move-result-object v3
    .line 25: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 28: if-eqz v5, :cond_39
    .line 30: const-string v3, ": "
    .line 32: invoke-virtual {v3, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 35: move-result-object v3
    .line 36: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 42: move-result-object v3
    .line 43: const-string v4, "sb.toString()"
    .line 45: invoke-static {v3, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 48: invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 51: return-void
.end method

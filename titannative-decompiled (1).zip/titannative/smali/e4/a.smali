.class public abstract Le4/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:[B

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Le4/k;->l:Le4/k;
    .line 2: const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    .line 4: invoke-static {v0}, Lz3/b;->s(Ljava/lang/String;)Le4/k;
    .line 7: move-result-object v0
    .line 8: iget-object v0, v0, Le4/k;->i:[B
    .line 10: sput-object v0, Le4/a;->a:[B
    .line 12: const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    .line 14: invoke-static {v0}, Lz3/b;->s(Ljava/lang/String;)Le4/k;
    .line 17: return-void
.end method

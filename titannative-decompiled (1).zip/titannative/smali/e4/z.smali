.class public Le4/z;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final d:Le4/y;

.field public a:Z
.field public b:J
.field public c:J

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Le4/y;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Le4/z;->d:Le4/y;
    .line 7: return-void
.end method

# virtual methods
.method public a()Le4/z;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: iput-boolean v0, v1, Le4/z;->a:Z
    .line 3: return-object v1
.end method

# virtual methods
.method public b()Le4/z;
    .registers 3

    .line 0: const-wide/16 v0, 0
    .line 2: iput-wide v0, v2, Le4/z;->c:J
    .line 4: return-object v2
.end method

# virtual methods
.method public c()J
    .registers 3

    .line 0: iget-boolean v0, v2, Le4/z;->a:Z
    .line 2: if-eqz v0, :cond_7
    .line 4: iget-wide v0, v2, Le4/z;->b:J
    .line 6: return-wide v0
    .line 7: new-instance v0, Ljava/lang/IllegalStateException;
    .line 9: const-string v1, "No deadline"
    .line 11: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 14: move-result-object v1
    .line 15: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 18: throw v0
.end method

# virtual methods
.method public d(J)Le4/z;
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: iput-boolean v0, v1, Le4/z;->a:Z
    .line 3: iput-wide v2, v1, Le4/z;->b:J
    .line 5: return-object v1
.end method

# virtual methods
.method public e()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Le4/z;->a:Z
    .line 2: return v0
.end method

# virtual methods
.method public f()V
    .registers 5

    .line 0: invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z
    .line 7: move-result v0
    .line 8: if-nez v0, :cond_37
    .line 10: iget-boolean v0, v4, Le4/z;->a:Z
    .line 12: if-eqz v0, :cond_36
    .line 14: iget-wide v0, v4, Le4/z;->b:J
    .line 16: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 19: move-result-wide v2
    .line 20: sub-long/2addr v0, v2
    .line 21: const-wide/16 v2, 0
    .line 23: cmp-long v0, v0, v2
    .line 25: if-lez v0, :cond_28
    .line 27: goto :goto_36
    .line 28: new-instance v0, Ljava/io/InterruptedIOException;
    .line 30: const-string v1, "deadline reached"
    .line 32: invoke-direct {v0, v1}, Ljava/io/InterruptedIOException;-><init>(Ljava/lang/String;)V
    .line 35: throw v0
    .line 36: return-void
    .line 37: new-instance v0, Ljava/io/InterruptedIOException;
    .line 39: const-string v1, "interrupted"
    .line 41: invoke-direct {v0, v1}, Ljava/io/InterruptedIOException;-><init>(Ljava/lang/String;)V
    .line 44: throw v0
.end method

# virtual methods
.method public g(JLjava/util/concurrent/TimeUnit;)Le4/z;
    .registers 6

    .line 0: const-string v0, "unit"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-wide/16 v0, 0
    .line 7: cmp-long v0, v3, v0
    .line 9: if-ltz v0, :cond_18
    .line 11: invoke-virtual {v5, v3, v4}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J
    .line 14: move-result-wide v3
    .line 15: iput-wide v3, v2, Le4/z;->c:J
    .line 17: return-object v2
    .line 18: new-instance v5, Ljava/lang/StringBuilder;
    .line 20: const-string v0, "timeout < 0: "
    .line 22: invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 25: invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 28: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 31: move-result-object v3
    .line 32: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 34: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 37: move-result-object v3
    .line 38: invoke-direct {v4, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 41: throw v4
.end method

# virtual methods
.method public h()J
    .registers 3

    .line 0: iget-wide v0, v2, Le4/z;->c:J
    .line 2: return-wide v0
.end method

.class public abstract Le4/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Le4/g;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Le4/g;
    .line 2: invoke-direct {v0}, Le4/g;-><init>()V
    .line 5: sput-object v0, Le4/b;->a:Le4/g;
    .line 7: return-void
.end method

# direct methods
.method public static final a(III[B[B)Z
    .registers 9

    .line 0: const-string v0, "a"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "b"
    .line 7: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const/4 v0, 0
    .line 11: move v1, v0
    .line 12: if-ge v1, v6, :cond_28
    .line 14: add-int v2, v1, v4
    .line 16: aget-byte v2, v7, v2
    .line 18: add-int v3, v1, v5
    .line 20: aget-byte v3, v8, v3
    .line 22: if-eq v2, v3, :cond_25
    .line 24: return v0
    .line 25: add-int/lit8 v1, v1, 1
    .line 27: goto :goto_12
    .line 28: const/4 v4, 1
    .line 29: return v4
.end method

# direct methods
.method public static final b(JJJ)V
    .registers 10

    .line 0: or-long v0, v6, v8
    .line 2: const-wide/16 v2, 0
    .line 4: cmp-long v0, v0, v2
    .line 6: if-ltz v0, :cond_19
    .line 8: cmp-long v0, v6, v4
    .line 10: if-gtz v0, :cond_19
    .line 12: sub-long v0, v4, v6
    .line 14: cmp-long v0, v0, v8
    .line 16: if-ltz v0, :cond_19
    .line 18: return-void
    .line 19: new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;
    .line 21: new-instance v1, Ljava/lang/StringBuilder;
    .line 23: const-string v2, "size="
    .line 25: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 28: invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 31: const-string v4, " offset="
    .line 33: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 36: invoke-virtual {v1, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 39: const-string v4, " byteCount="
    .line 41: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 44: invoke-virtual {v1, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v4
    .line 51: invoke-direct {v0, v4}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 54: throw v0
.end method

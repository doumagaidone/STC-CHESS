.class public final Le4/s;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:[B
.field public b:I
.field public c:I
.field public d:Z
.field public final e:Z
.field public f:Le4/s;
.field public g:Le4/s;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/16 v0, 8192
    .line 5: new-array v0, v0, [B
    .line 7: iput-object v0, v1, Le4/s;->a:[B
    .line 9: const/4 v0, 1
    .line 10: iput-boolean v0, v1, Le4/s;->e:Z
    .line 12: const/4 v0, 0
    .line 13: iput-boolean v0, v1, Le4/s;->d:Z
    .line 15: return-void
.end method

# direct methods
.method public constructor <init>([BIIZZ)V
    .registers 7

    .line 0: const-string v0, "data"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Le4/s;->a:[B
    .line 10: iput v3, v1, Le4/s;->b:I
    .line 12: iput v4, v1, Le4/s;->c:I
    .line 14: iput-boolean v5, v1, Le4/s;->d:Z
    .line 16: iput-boolean v6, v1, Le4/s;->e:Z
    .line 18: return-void
.end method

# virtual methods
.method public final a()Le4/s;
    .registers 5

    .line 0: iget-object v0, v4, Le4/s;->f:Le4/s;
    .line 2: const/4 v1, 0
    .line 3: if-eq v0, v4, :cond_6
    .line 5: goto :goto_7
    .line 6: move-object v0, v1
    .line 7: iget-object v2, v4, Le4/s;->g:Le4/s;
    .line 9: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 12: iget-object v3, v4, Le4/s;->f:Le4/s;
    .line 14: iput-object v3, v2, Le4/s;->f:Le4/s;
    .line 16: iget-object v2, v4, Le4/s;->f:Le4/s;
    .line 18: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 21: iget-object v3, v4, Le4/s;->g:Le4/s;
    .line 23: iput-object v3, v2, Le4/s;->g:Le4/s;
    .line 25: iput-object v1, v4, Le4/s;->f:Le4/s;
    .line 27: iput-object v1, v4, Le4/s;->g:Le4/s;
    .line 29: return-object v0
.end method

# virtual methods
.method public final b(Le4/s;)V
    .registers 3

    .line 0: iput-object v1, v2, Le4/s;->g:Le4/s;
    .line 2: iget-object v0, v1, Le4/s;->f:Le4/s;
    .line 4: iput-object v0, v2, Le4/s;->f:Le4/s;
    .line 6: iget-object v0, v1, Le4/s;->f:Le4/s;
    .line 8: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 11: iput-object v2, v0, Le4/s;->g:Le4/s;
    .line 13: iput-object v2, v1, Le4/s;->f:Le4/s;
    .line 15: return-void
.end method

# virtual methods
.method public final c()Le4/s;
    .registers 8

    .line 0: const/4 v0, 1
    .line 1: iput-boolean v0, v7, Le4/s;->d:Z
    .line 3: new-instance v0, Le4/s;
    .line 5: iget-object v2, v7, Le4/s;->a:[B
    .line 7: iget v3, v7, Le4/s;->b:I
    .line 9: iget v4, v7, Le4/s;->c:I
    .line 11: const/4 v5, 1
    .line 12: const/4 v6, 0
    .line 13: move-object v1, v0
    .line 14: invoke-direct/range {v1 .. v6}, Le4/s;-><init>([BIIZZ)V
    .line 17: return-object v0
.end method

# virtual methods
.method public final d(Le4/s;I)V
    .registers 8

    .line 0: iget-boolean v0, v6, Le4/s;->e:Z
    .line 2: if-eqz v0, :cond_71
    .line 4: iget v0, v6, Le4/s;->c:I
    .line 6: add-int v1, v0, v7
    .line 8: iget-object v2, v6, Le4/s;->a:[B
    .line 10: const/16 v3, 8192
    .line 12: if-le v1, v3, :cond_49
    .line 14: iget-boolean v4, v6, Le4/s;->d:Z
    .line 16: if-nez v4, :cond_43
    .line 18: iget v4, v6, Le4/s;->b:I
    .line 20: sub-int/2addr v1, v4
    .line 21: if-gt v1, v3, :cond_37
    .line 23: const/4 v1, 0
    .line 24: invoke-static {v1, v4, v0, v2, v2}, Lt2/k;->K0(III[B[B)V
    .line 27: iget v0, v6, Le4/s;->c:I
    .line 29: iget v3, v6, Le4/s;->b:I
    .line 31: sub-int/2addr v0, v3
    .line 32: iput v0, v6, Le4/s;->c:I
    .line 34: iput v1, v6, Le4/s;->b:I
    .line 36: goto :goto_49
    .line 37: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 39: invoke-direct {v6}, Ljava/lang/IllegalArgumentException;-><init>()V
    .line 42: throw v6
    .line 43: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 45: invoke-direct {v6}, Ljava/lang/IllegalArgumentException;-><init>()V
    .line 48: throw v6
    .line 49: iget v0, v6, Le4/s;->c:I
    .line 51: iget v1, v5, Le4/s;->b:I
    .line 53: add-int v3, v1, v7
    .line 55: iget-object v4, v5, Le4/s;->a:[B
    .line 57: invoke-static {v0, v1, v3, v4, v2}, Lt2/k;->K0(III[B[B)V
    .line 60: iget v0, v6, Le4/s;->c:I
    .line 62: add-int/2addr v0, v7
    .line 63: iput v0, v6, Le4/s;->c:I
    .line 65: iget v6, v5, Le4/s;->b:I
    .line 67: add-int/2addr v6, v7
    .line 68: iput v6, v5, Le4/s;->b:I
    .line 70: return-void
    .line 71: new-instance v6, Ljava/lang/IllegalStateException;
    .line 73: const-string v7, "only owner can write"
    .line 75: invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 78: move-result-object v7
    .line 79: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 82: throw v6
.end method

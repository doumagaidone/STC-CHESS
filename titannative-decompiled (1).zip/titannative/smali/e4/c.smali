.class public final Le4/c;
.super Ljava/lang/Thread;
.source "SourceFile"

# virtual methods
.method public final run()V
    .registers 4

    .line 0: sget-object v0, Le4/f;->h:Ljava/util/concurrent/locks/ReentrantLock;
    .line 2: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V
    .line 5: invoke-static {}, Lz3/b;->g()Le4/f;
    .line 8: move-result-object v1
    .line 9: sget-object v2, Le4/f;->l:Le4/f;
    .line 11: if-ne v1, v2, :cond_20
    .line 13: const/4 v1, 0
    .line 14: sput-object v1, Le4/f;->l:Le4/f;
    .line 16: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    .line 19: return-void
    .line 20: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    .line 23: if-eqz v1, :cond_0
    .line 25: invoke-virtual {v1}, Le4/f;->l()V
    .line 28: goto :goto_0
    .line 29: move-exception v1
    .line 30: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    .line 33: throw v1
.end method

.class public abstract Le4/t;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Le4/s;
.field public static final b:I
.field public static final c:[Ljava/util/concurrent/atomic/AtomicReference;

# direct methods
.method static constructor <clinit>()V
    .registers 8

    .line 0: new-instance v6, Le4/s;
    .line 2: const/4 v7, 0
    .line 3: new-array v1, v7, [B
    .line 5: const/4 v2, 0
    .line 6: const/4 v3, 0
    .line 7: const/4 v4, 0
    .line 8: const/4 v5, 0
    .line 9: move-object v0, v6
    .line 10: invoke-direct/range {v0 .. v5}, Le4/s;-><init>([BIIZZ)V
    .line 13: sput-object v6, Le4/t;->a:Le4/s;
    .line 15: invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;
    .line 18: move-result-object v0
    .line 19: invoke-virtual {v0}, Ljava/lang/Runtime;->availableProcessors()I
    .line 22: move-result v0
    .line 23: mul-int/lit8 v0, v0, 2
    .line 25: add-int/lit8 v0, v0, -1
    .line 27: invoke-static {v0}, Ljava/lang/Integer;->highestOneBit(I)I
    .line 30: move-result v0
    .line 31: sput v0, Le4/t;->b:I
    .line 33: new-array v1, v0, [Ljava/util/concurrent/atomic/AtomicReference;
    .line 35: if-ge v7, v0, :cond_47
    .line 37: new-instance v2, Ljava/util/concurrent/atomic/AtomicReference;
    .line 39: invoke-direct {v2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V
    .line 42: aput-object v2, v1, v7
    .line 44: add-int/lit8 v7, v7, 1
    .line 46: goto :goto_35
    .line 47: sput-object v1, Le4/t;->c:[Ljava/util/concurrent/atomic/AtomicReference;
    .line 49: return-void
.end method

# direct methods
.method public static final a(Le4/s;)V
    .registers 7

    .line 0: iget-object v0, v6, Le4/s;->f:Le4/s;
    .line 2: if-nez v0, :cond_71
    .line 4: iget-object v0, v6, Le4/s;->g:Le4/s;
    .line 6: if-nez v0, :cond_71
    .line 8: iget-boolean v0, v6, Le4/s;->d:Z
    .line 10: if-eqz v0, :cond_13
    .line 12: return-void
    .line 13: invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;
    .line 16: move-result-object v0
    .line 17: invoke-virtual {v0}, Ljava/lang/Thread;->getId()J
    .line 20: move-result-wide v0
    .line 21: sget v2, Le4/t;->b:I
    .line 23: int-to-long v2, v2
    .line 24: const-wide/16 v4, 1
    .line 26: sub-long/2addr v2, v4
    .line 27: and-long/2addr v0, v2
    .line 28: long-to-int v0, v0
    .line 29: sget-object v1, Le4/t;->c:[Ljava/util/concurrent/atomic/AtomicReference;
    .line 31: aget-object v0, v1, v0
    .line 33: sget-object v1, Le4/t;->a:Le4/s;
    .line 35: invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;
    .line 38: move-result-object v2
    .line 39: check-cast v2, Le4/s;
    .line 41: if-ne v2, v1, :cond_44
    .line 43: return-void
    .line 44: const/4 v1, 0
    .line 45: if-eqz v2, :cond_50
    .line 47: iget v3, v2, Le4/s;->c:I
    .line 49: goto :goto_51
    .line 50: move v3, v1
    .line 51: const/high16 v4, 0x1
    .line 53: if-lt v3, v4, :cond_59
    .line 55: invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    .line 58: return-void
    .line 59: iput-object v2, v6, Le4/s;->f:Le4/s;
    .line 61: iput v1, v6, Le4/s;->b:I
    .line 63: add-int/lit16 v3, v3, 8192
    .line 65: iput v3, v6, Le4/s;->c:I
    .line 67: invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    .line 70: return-void
    .line 71: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 73: const-string v0, "Failed requirement."
    .line 75: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 78: move-result-object v0
    .line 79: invoke-direct {v6, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 82: throw v6
.end method

# direct methods
.method public static final b()Le4/s;
    .registers 6

    .line 0: invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v0}, Ljava/lang/Thread;->getId()J
    .line 7: move-result-wide v0
    .line 8: sget v2, Le4/t;->b:I
    .line 10: int-to-long v2, v2
    .line 11: const-wide/16 v4, 1
    .line 13: sub-long/2addr v2, v4
    .line 14: and-long/2addr v0, v2
    .line 15: long-to-int v0, v0
    .line 16: sget-object v1, Le4/t;->c:[Ljava/util/concurrent/atomic/AtomicReference;
    .line 18: aget-object v0, v1, v0
    .line 20: sget-object v1, Le4/t;->a:Le4/s;
    .line 22: invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;
    .line 25: move-result-object v2
    .line 26: check-cast v2, Le4/s;
    .line 28: if-ne v2, v1, :cond_36
    .line 30: new-instance v0, Le4/s;
    .line 32: invoke-direct {v0}, Le4/s;-><init>()V
    .line 35: return-object v0
    .line 36: const/4 v1, 0
    .line 37: if-nez v2, :cond_48
    .line 39: invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    .line 42: new-instance v0, Le4/s;
    .line 44: invoke-direct {v0}, Le4/s;-><init>()V
    .line 47: return-object v0
    .line 48: iget-object v3, v2, Le4/s;->f:Le4/s;
    .line 50: invoke-virtual {v0, v3}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    .line 53: iput-object v1, v2, Le4/s;->f:Le4/s;
    .line 55: const/4 v0, 0
    .line 56: iput v0, v2, Le4/s;->c:I
    .line 58: return-object v2
.end method

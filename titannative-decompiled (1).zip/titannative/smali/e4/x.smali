.class public abstract interface Le4/x;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Closeable;

# virtual methods
.method public abstract d()Le4/z;
.end method

# virtual methods
.method public abstract u(Le4/h;J)J
.end method

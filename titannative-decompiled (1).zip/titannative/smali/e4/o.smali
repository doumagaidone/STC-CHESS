.class public abstract synthetic Le4/o;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/logging/Logger;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-string v0, "okio.Okio"
    .line 2: invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    .line 5: move-result-object v0
    .line 6: sput-object v0, Le4/o;->a:Ljava/util/logging/Logger;
    .line 8: return-void
.end method

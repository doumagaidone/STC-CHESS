.class public Le4/k;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Serializable;
.implements Ljava/lang/Comparable;

.field public static final l:Le4/k;

.field public final i:[B
.field public transient j:I
.field public transient k:Ljava/lang/String;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: new-instance v1, Le4/k;
    .line 3: new-array v0, v0, [B
    .line 5: invoke-direct {v1, v0}, Le4/k;-><init>([B)V
    .line 8: sput-object v1, Le4/k;->l:Le4/k;
    .line 10: return-void
.end method

# direct methods
.method public constructor <init>([B)V
    .registers 3

    .line 0: const-string v0, "data"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Le4/k;->i:[B
    .line 10: return-void
.end method

# virtual methods
.method public a()Ljava/lang/String;
    .registers 14

    .line 0: sget-object v0, Le4/a;->a:[B
    .line 2: iget-object v1, v13, Le4/k;->i:[B
    .line 4: const-string v2, "<this>"
    .line 6: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: const-string v2, "map"
    .line 11: invoke-static {v0, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: array-length v2, v1
    .line 15: const/4 v3, 2
    .line 16: add-int/2addr v2, v3
    .line 17: div-int/lit8 v2, v2, 3
    .line 19: mul-int/lit8 v2, v2, 4
    .line 21: new-array v2, v2, [B
    .line 23: array-length v4, v1
    .line 24: array-length v5, v1
    .line 25: rem-int/lit8 v5, v5, 3
    .line 27: sub-int/2addr v4, v5
    .line 28: const/4 v5, 0
    .line 29: move v6, v5
    .line 30: if-ge v5, v4, :cond_91
    .line 32: add-int/lit8 v7, v5, 1
    .line 34: aget-byte v8, v1, v5
    .line 36: add-int/lit8 v9, v5, 2
    .line 38: aget-byte v7, v1, v7
    .line 40: add-int/lit8 v5, v5, 3
    .line 42: aget-byte v9, v1, v9
    .line 44: add-int/lit8 v10, v6, 1
    .line 46: and-int/lit16 v11, v8, 255
    .line 48: shr-int/2addr v11, v3
    .line 49: aget-byte v11, v0, v11
    .line 51: aput-byte v11, v2, v6
    .line 53: add-int/lit8 v11, v6, 2
    .line 55: and-int/lit8 v8, v8, 3
    .line 57: shl-int/lit8 v8, v8, 4
    .line 59: and-int/lit16 v12, v7, 255
    .line 61: shr-int/lit8 v12, v12, 4
    .line 63: or-int/2addr v8, v12
    .line 64: aget-byte v8, v0, v8
    .line 66: aput-byte v8, v2, v10
    .line 68: add-int/lit8 v8, v6, 3
    .line 70: and-int/lit8 v7, v7, 15
    .line 72: shl-int/2addr v7, v3
    .line 73: and-int/lit16 v10, v9, 255
    .line 75: shr-int/lit8 v10, v10, 6
    .line 77: or-int/2addr v7, v10
    .line 78: aget-byte v7, v0, v7
    .line 80: aput-byte v7, v2, v11
    .line 82: add-int/lit8 v6, v6, 4
    .line 84: and-int/lit8 v7, v9, 63
    .line 86: aget-byte v7, v0, v7
    .line 88: aput-byte v7, v2, v8
    .line 90: goto :goto_30
    .line 91: array-length v7, v1
    .line 92: sub-int/2addr v7, v4
    .line 93: const/4 v4, 1
    .line 94: const/16 v8, 61
    .line 96: if-eq v7, v4, :cond_143
    .line 98: if-eq v7, v3, :cond_101
    .line 100: goto :goto_171
    .line 101: add-int/lit8 v4, v5, 1
    .line 103: aget-byte v5, v1, v5
    .line 105: aget-byte v1, v1, v4
    .line 107: add-int/lit8 v4, v6, 1
    .line 109: and-int/lit16 v7, v5, 255
    .line 111: shr-int/2addr v7, v3
    .line 112: aget-byte v7, v0, v7
    .line 114: aput-byte v7, v2, v6
    .line 116: add-int/lit8 v7, v6, 2
    .line 118: and-int/lit8 v5, v5, 3
    .line 120: shl-int/lit8 v5, v5, 4
    .line 122: and-int/lit16 v9, v1, 255
    .line 124: shr-int/lit8 v9, v9, 4
    .line 126: or-int/2addr v5, v9
    .line 127: aget-byte v5, v0, v5
    .line 129: aput-byte v5, v2, v4
    .line 131: add-int/lit8 v6, v6, 3
    .line 133: and-int/lit8 v1, v1, 15
    .line 135: shl-int/2addr v1, v3
    .line 136: aget-byte v0, v0, v1
    .line 138: aput-byte v0, v2, v7
    .line 140: aput-byte v8, v2, v6
    .line 142: goto :goto_171
    .line 143: aget-byte v1, v1, v5
    .line 145: add-int/lit8 v4, v6, 1
    .line 147: and-int/lit16 v5, v1, 255
    .line 149: shr-int/lit8 v3, v5, 2
    .line 151: aget-byte v3, v0, v3
    .line 153: aput-byte v3, v2, v6
    .line 155: add-int/lit8 v3, v6, 2
    .line 157: and-int/lit8 v1, v1, 3
    .line 159: shl-int/lit8 v1, v1, 4
    .line 161: aget-byte v0, v0, v1
    .line 163: aput-byte v0, v2, v4
    .line 165: add-int/lit8 v6, v6, 3
    .line 167: aput-byte v8, v2, v3
    .line 169: aput-byte v8, v2, v6
    .line 171: new-instance v0, Ljava/lang/String;
    .line 173: sget-object v1, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 175: invoke-direct {v0, v2, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 178: return-object v0
.end method

# virtual methods
.method public b(Ljava/lang/String;)Le4/k;
    .registers 5

    .line 0: invoke-static {v4}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;
    .line 3: move-result-object v4
    .line 4: invoke-virtual {v3}, Le4/k;->c()I
    .line 7: move-result v0
    .line 8: iget-object v1, v3, Le4/k;->i:[B
    .line 10: const/4 v2, 0
    .line 11: invoke-virtual {v4, v1, v2, v0}, Ljava/security/MessageDigest;->update([BII)V
    .line 14: invoke-virtual {v4}, Ljava/security/MessageDigest;->digest()[B
    .line 17: move-result-object v4
    .line 18: new-instance v0, Le4/k;
    .line 20: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 23: invoke-direct {v0, v4}, Le4/k;-><init>([B)V
    .line 26: return-object v0
.end method

# virtual methods
.method public c()I
    .registers 2

    .line 0: iget-object v0, v1, Le4/k;->i:[B
    .line 2: array-length v0, v0
    .line 3: return v0
.end method

# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 11

    .line 0: check-cast v10, Le4/k;
    .line 2: const-string v0, "other"
    .line 4: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: invoke-virtual {v9}, Le4/k;->c()I
    .line 10: move-result v0
    .line 11: invoke-virtual {v10}, Le4/k;->c()I
    .line 14: move-result v1
    .line 15: invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I
    .line 18: move-result v2
    .line 19: const/4 v3, 0
    .line 20: move v4, v3
    .line 21: const/4 v5, 1
    .line 22: const/4 v6, -1
    .line 23: if-ge v4, v2, :cond_48
    .line 25: invoke-virtual {v9, v4}, Le4/k;->f(I)B
    .line 28: move-result v7
    .line 29: and-int/lit16 v7, v7, 255
    .line 31: invoke-virtual {v10, v4}, Le4/k;->f(I)B
    .line 34: move-result v8
    .line 35: and-int/lit16 v8, v8, 255
    .line 37: if-ne v7, v8, :cond_42
    .line 39: add-int/lit8 v4, v4, 1
    .line 41: goto :goto_21
    .line 42: if-ge v7, v8, :cond_46
    .line 44: move v3, v6
    .line 45: goto :goto_54
    .line 46: move v3, v5
    .line 47: goto :goto_54
    .line 48: if-ne v0, v1, :cond_51
    .line 50: goto :goto_54
    .line 51: if-ge v0, v1, :cond_46
    .line 53: goto :goto_44
    .line 54: return v3
.end method

# virtual methods
.method public d()Ljava/lang/String;
    .registers 10

    .line 0: iget-object v0, v9, Le4/k;->i:[B
    .line 2: array-length v1, v0
    .line 3: mul-int/lit8 v1, v1, 2
    .line 5: new-array v1, v1, [C
    .line 7: array-length v2, v0
    .line 8: const/4 v3, 0
    .line 9: move v4, v3
    .line 10: if-ge v3, v2, :cond_37
    .line 12: aget-byte v5, v0, v3
    .line 14: add-int/lit8 v6, v4, 1
    .line 16: sget-object v7, Lf4/b;->a:[C
    .line 18: shr-int/lit8 v8, v5, 4
    .line 20: and-int/lit8 v8, v8, 15
    .line 22: aget-char v8, v7, v8
    .line 24: aput-char v8, v1, v4
    .line 26: add-int/lit8 v4, v4, 2
    .line 28: and-int/lit8 v5, v5, 15
    .line 30: aget-char v5, v7, v5
    .line 32: aput-char v5, v1, v6
    .line 34: add-int/lit8 v3, v3, 1
    .line 36: goto :goto_10
    .line 37: new-instance v0, Ljava/lang/String;
    .line 39: invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V
    .line 42: return-object v0
.end method

# virtual methods
.method public e()[B
    .registers 2

    .line 0: iget-object v0, v1, Le4/k;->i:[B
    .line 2: return-object v0
.end method

# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7

    .line 0: const/4 v0, 1
    .line 1: if-ne v6, v5, :cond_4
    .line 3: goto :goto_29
    .line 4: instance-of v1, v6, Le4/k;
    .line 6: const/4 v2, 0
    .line 7: if-eqz v1, :cond_28
    .line 9: check-cast v6, Le4/k;
    .line 11: invoke-virtual {v6}, Le4/k;->c()I
    .line 14: move-result v1
    .line 15: iget-object v3, v5, Le4/k;->i:[B
    .line 17: array-length v4, v3
    .line 18: if-ne v1, v4, :cond_28
    .line 20: array-length v1, v3
    .line 21: invoke-virtual {v6, v2, v3, v2, v1}, Le4/k;->g(I[BII)Z
    .line 24: move-result v6
    .line 25: if-eqz v6, :cond_28
    .line 27: goto :goto_29
    .line 28: move v0, v2
    .line 29: return v0
.end method

# virtual methods
.method public f(I)B
    .registers 3

    .line 0: iget-object v0, v1, Le4/k;->i:[B
    .line 2: aget-byte v2, v0, v2
    .line 4: return v2
.end method

# virtual methods
.method public g(I[BII)Z
    .registers 7

    .line 0: const-string v0, "other"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: if-ltz v3, :cond_27
    .line 7: iget-object v0, v2, Le4/k;->i:[B
    .line 9: array-length v1, v0
    .line 10: sub-int/2addr v1, v6
    .line 11: if-gt v3, v1, :cond_27
    .line 13: if-ltz v5, :cond_27
    .line 15: array-length v1, v4
    .line 16: sub-int/2addr v1, v6
    .line 17: if-gt v5, v1, :cond_27
    .line 19: invoke-static {v3, v5, v6, v0, v4}, Le4/b;->a(III[B[B)Z
    .line 22: move-result v3
    .line 23: if-eqz v3, :cond_27
    .line 25: const/4 v3, 1
    .line 26: goto :goto_28
    .line 27: const/4 v3, 0
    .line 28: return v3
.end method

# virtual methods
.method public h(Le4/k;I)Z
    .registers 5

    .line 0: const-string v0, "other"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v2, Le4/k;->i:[B
    .line 7: const/4 v1, 0
    .line 8: invoke-virtual {v3, v1, v0, v1, v4}, Le4/k;->g(I[BII)Z
    .line 11: move-result v3
    .line 12: return v3
.end method

# virtual methods
.method public hashCode()I
    .registers 2

    .line 0: iget v0, v1, Le4/k;->j:I
    .line 2: if-eqz v0, :cond_5
    .line 4: goto :goto_13
    .line 5: iget-object v0, v1, Le4/k;->i:[B
    .line 7: invoke-static {v0}, Ljava/util/Arrays;->hashCode([B)I
    .line 10: move-result v0
    .line 11: iput v0, v1, Le4/k;->j:I
    .line 13: return v0
.end method

# virtual methods
.method public i()Le4/k;
    .registers 7

    .line 0: const/4 v0, 0
    .line 1: iget-object v1, v6, Le4/k;->i:[B
    .line 3: array-length v2, v1
    .line 4: if-ge v0, v2, :cond_61
    .line 6: aget-byte v2, v1, v0
    .line 8: const/16 v3, 65
    .line 10: if-lt v2, v3, :cond_58
    .line 12: const/16 v4, 90
    .line 14: if-le v2, v4, :cond_17
    .line 16: goto :goto_58
    .line 17: array-length v5, v1
    .line 18: invoke-static {v1, v5}, Ljava/util/Arrays;->copyOf([BI)[B
    .line 21: move-result-object v1
    .line 22: const-string v5, "copyOf(this, size)"
    .line 24: invoke-static {v1, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 27: add-int/lit8 v5, v0, 1
    .line 29: add-int/lit8 v2, v2, 32
    .line 31: int-to-byte v2, v2
    .line 32: aput-byte v2, v1, v0
    .line 34: array-length v0, v1
    .line 35: if-ge v5, v0, :cond_52
    .line 37: aget-byte v0, v1, v5
    .line 39: if-lt v0, v3, :cond_49
    .line 41: if-le v0, v4, :cond_44
    .line 43: goto :goto_49
    .line 44: add-int/lit8 v0, v0, 32
    .line 46: int-to-byte v0, v0
    .line 47: aput-byte v0, v1, v5
    .line 49: add-int/lit8 v5, v5, 1
    .line 51: goto :goto_34
    .line 52: new-instance v0, Le4/k;
    .line 54: invoke-direct {v0, v1}, Le4/k;-><init>([B)V
    .line 57: goto :goto_62
    .line 58: add-int/lit8 v0, v0, 1
    .line 60: goto :goto_1
    .line 61: move-object v0, v6
    .line 62: return-object v0
.end method

# virtual methods
.method public final j()Ljava/lang/String;
    .registers 4

    .line 0: iget-object v0, v3, Le4/k;->k:Ljava/lang/String;
    .line 2: if-nez v0, :cond_23
    .line 4: invoke-virtual {v3}, Le4/k;->e()[B
    .line 7: move-result-object v0
    .line 8: const-string v1, "<this>"
    .line 10: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: new-instance v1, Ljava/lang/String;
    .line 15: sget-object v2, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 17: invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 20: iput-object v1, v3, Le4/k;->k:Ljava/lang/String;
    .line 22: move-object v0, v1
    .line 23: return-object v0
.end method

# virtual methods
.method public k(Le4/h;I)V
    .registers 5

    .line 0: const-string v0, "buffer"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v2, Le4/k;->i:[B
    .line 7: const/4 v1, 0
    .line 8: invoke-virtual {v3, v0, v1, v4}, Le4/h;->M([BII)V
    .line 11: return-void
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 18

    .line 0: move-object/from16 v0, v17
    .line 2: iget-object v1, v0, Le4/k;->i:[B
    .line 4: array-length v2, v1
    .line 5: if-nez v2, :cond_11
    .line 7: const-string v1, "[size=0]"
    .line 9: goto/16 :goto_614
    .line 11: array-length v2, v1
    .line 12: const/4 v4, 0
    .line 13: const/4 v5, 0
    .line 14: const/4 v6, 0
    .line 15: const/16 v8, 64
    .line 17: if-ge v4, v2, :cond_422
    .line 19: aget-byte v9, v1, v4
    .line 21: const v12, 0xfffd
    .line 24: const/16 v13, 160
    .line 26: const/16 v14, 127
    .line 28: const/16 v15, 32
    .line 30: const/16 v10, 13
    .line 32: const/16 v11, 10
    .line 34: const/high16 v3, 0x1
    .line 36: if-ltz v9, :cond_111
    .line 38: add-int/lit8 v16, v6, 1
    .line 40: if-ne v6, v8, :cond_44
    .line 42: goto/16 :goto_422
    .line 44: if-eq v9, v11, :cond_58
    .line 46: if-eq v9, v10, :cond_58
    .line 48: if-ltz v9, :cond_53
    .line 50: if-ge v9, v15, :cond_53
    .line 52: goto :goto_60
    .line 53: if-gt v14, v9, :cond_58
    .line 55: if-ge v9, v13, :cond_58
    .line 57: goto :goto_60
    .line 58: if-ne v9, v12, :cond_63
    .line 60: const/4 v5, -1
    .line 61: goto/16 :goto_422
    .line 63: if-ge v9, v3, :cond_67
    .line 65: const/4 v6, 1
    .line 66: goto :goto_68
    .line 67: const/4 v6, 2
    .line 68: add-int/2addr v5, v6
    .line 69: add-int/lit8 v4, v4, 1
    .line 71: move/from16 v6, v16
    .line 73: if-ge v4, v2, :cond_15
    .line 75: aget-byte v9, v1, v4
    .line 77: if-ltz v9, :cond_15
    .line 79: add-int/lit8 v4, v4, 1
    .line 81: add-int/lit8 v16, v6, 1
    .line 83: if-ne v6, v8, :cond_87
    .line 85: goto/16 :goto_422
    .line 87: if-eq v9, v11, :cond_101
    .line 89: if-eq v9, v10, :cond_101
    .line 91: if-ltz v9, :cond_96
    .line 93: if-ge v9, v15, :cond_96
    .line 95: goto :goto_103
    .line 96: if-gt v14, v9, :cond_101
    .line 98: if-ge v9, v13, :cond_101
    .line 100: goto :goto_103
    .line 101: if-ne v9, v12, :cond_104
    .line 103: goto :goto_60
    .line 104: if-ge v9, v3, :cond_108
    .line 106: const/4 v6, 1
    .line 107: goto :goto_109
    .line 108: const/4 v6, 2
    .line 109: add-int/2addr v5, v6
    .line 110: goto :goto_71
    .line 111: shr-int/lit8 v7, v9, 5
    .line 113: const/4 v3, -2
    .line 114: const/16 v12, 128
    .line 116: if-ne v7, v3, :cond_186
    .line 118: add-int/lit8 v3, v4, 1
    .line 120: if-gt v2, v3, :cond_126
    .line 122: if-ne v6, v8, :cond_60
    .line 124: goto/16 :goto_422
    .line 126: aget-byte v3, v1, v3
    .line 128: and-int/lit16 v7, v3, 192
    .line 130: if-ne v7, v12, :cond_182
    .line 132: xor-int/lit16 v3, v3, 3968
    .line 134: shl-int/lit8 v7, v9, 6
    .line 136: xor-int/2addr v3, v7
    .line 137: if-ge v3, v12, :cond_143
    .line 139: if-ne v6, v8, :cond_60
    .line 141: goto/16 :goto_422
    .line 143: add-int/lit8 v7, v6, 1
    .line 145: if-ne v6, v8, :cond_149
    .line 147: goto/16 :goto_422
    .line 149: if-eq v3, v11, :cond_163
    .line 151: if-eq v3, v10, :cond_163
    .line 153: if-ltz v3, :cond_158
    .line 155: if-ge v3, v15, :cond_158
    .line 157: goto :goto_168
    .line 158: if-gt v14, v3, :cond_163
    .line 160: if-ge v3, v13, :cond_163
    .line 162: goto :goto_168
    .line 163: const v6, 0xfffd
    .line 166: if-ne v3, v6, :cond_169
    .line 168: goto :goto_60
    .line 169: const/high16 v6, 0x1
    .line 171: if-ge v3, v6, :cond_175
    .line 173: const/4 v10, 1
    .line 174: goto :goto_176
    .line 175: const/4 v10, 2
    .line 176: add-int/2addr v5, v10
    .line 177: add-int/lit8 v4, v4, 2
    .line 179: move v6, v7
    .line 180: goto/16 :goto_15
    .line 182: if-ne v6, v8, :cond_60
    .line 184: goto/16 :goto_422
    .line 186: shr-int/lit8 v7, v9, 4
    .line 188: const v13, 0xe000
    .line 191: const v14, 0xd800
    .line 194: if-ne v7, v3, :cond_296
    .line 196: add-int/lit8 v3, v4, 2
    .line 198: if-gt v2, v3, :cond_204
    .line 200: if-ne v6, v8, :cond_60
    .line 202: goto/16 :goto_422
    .line 204: add-int/lit8 v7, v4, 1
    .line 206: aget-byte v7, v1, v7
    .line 208: and-int/lit16 v15, v7, 192
    .line 210: if-ne v15, v12, :cond_292
    .line 212: aget-byte v3, v1, v3
    .line 214: and-int/lit16 v15, v3, 192
    .line 216: if-ne v15, v12, :cond_288
    .line 218: const v12, 0xfffe1f80
    .line 221: xor-int/2addr v3, v12
    .line 222: shl-int/lit8 v7, v7, 6
    .line 224: xor-int/2addr v3, v7
    .line 225: shl-int/lit8 v7, v9, 12
    .line 227: xor-int/2addr v3, v7
    .line 228: const/16 v7, 2048
    .line 230: if-ge v3, v7, :cond_236
    .line 232: if-ne v6, v8, :cond_60
    .line 234: goto/16 :goto_422
    .line 236: if-gt v14, v3, :cond_244
    .line 238: if-ge v3, v13, :cond_244
    .line 240: if-ne v6, v8, :cond_60
    .line 242: goto/16 :goto_422
    .line 244: add-int/lit8 v7, v6, 1
    .line 246: if-ne v6, v8, :cond_250
    .line 248: goto/16 :goto_422
    .line 250: if-eq v3, v11, :cond_270
    .line 252: if-eq v3, v10, :cond_270
    .line 254: if-ltz v3, :cond_261
    .line 256: const/16 v6, 32
    .line 258: if-ge v3, v6, :cond_261
    .line 260: goto :goto_275
    .line 261: const/16 v6, 127
    .line 263: if-gt v6, v3, :cond_270
    .line 265: const/16 v6, 160
    .line 267: if-ge v3, v6, :cond_270
    .line 269: goto :goto_275
    .line 270: const v6, 0xfffd
    .line 273: if-ne v3, v6, :cond_277
    .line 275: goto/16 :goto_60
    .line 277: const/high16 v6, 0x1
    .line 279: if-ge v3, v6, :cond_283
    .line 281: const/4 v10, 1
    .line 282: goto :goto_284
    .line 283: const/4 v10, 2
    .line 284: add-int/2addr v5, v10
    .line 285: add-int/lit8 v4, v4, 3
    .line 287: goto :goto_179
    .line 288: if-ne v6, v8, :cond_60
    .line 290: goto/16 :goto_422
    .line 292: if-ne v6, v8, :cond_60
    .line 294: goto/16 :goto_422
    .line 296: shr-int/lit8 v7, v9, 3
    .line 298: if-ne v7, v3, :cond_420
    .line 300: add-int/lit8 v3, v4, 3
    .line 302: if-gt v2, v3, :cond_308
    .line 304: if-ne v6, v8, :cond_60
    .line 306: goto/16 :goto_422
    .line 308: add-int/lit8 v7, v4, 1
    .line 310: aget-byte v7, v1, v7
    .line 312: and-int/lit16 v15, v7, 192
    .line 314: if-ne v15, v12, :cond_417
    .line 316: add-int/lit8 v15, v4, 2
    .line 318: aget-byte v15, v1, v15
    .line 320: and-int/lit16 v10, v15, 192
    .line 322: if-ne v10, v12, :cond_414
    .line 324: aget-byte v3, v1, v3
    .line 326: and-int/lit16 v10, v3, 192
    .line 328: if-ne v10, v12, :cond_411
    .line 330: const v10, 0x381f80
    .line 333: xor-int/2addr v3, v10
    .line 334: shl-int/lit8 v10, v15, 6
    .line 336: xor-int/2addr v3, v10
    .line 337: shl-int/lit8 v7, v7, 12
    .line 339: xor-int/2addr v3, v7
    .line 340: shl-int/lit8 v7, v9, 18
    .line 342: xor-int/2addr v3, v7
    .line 343: const v7, 0x10ffff
    .line 346: if-le v3, v7, :cond_351
    .line 348: if-ne v6, v8, :cond_60
    .line 350: goto :goto_422
    .line 351: if-gt v14, v3, :cond_358
    .line 353: if-ge v3, v13, :cond_358
    .line 355: if-ne v6, v8, :cond_60
    .line 357: goto :goto_422
    .line 358: const/high16 v7, 0x1
    .line 360: if-ge v3, v7, :cond_365
    .line 362: if-ne v6, v8, :cond_60
    .line 364: goto :goto_422
    .line 365: add-int/lit8 v7, v6, 1
    .line 367: if-ne v6, v8, :cond_370
    .line 369: goto :goto_422
    .line 370: if-eq v3, v11, :cond_392
    .line 372: const/16 v6, 13
    .line 374: if-eq v3, v6, :cond_392
    .line 376: if-ltz v3, :cond_383
    .line 378: const/16 v6, 32
    .line 380: if-ge v3, v6, :cond_383
    .line 382: goto :goto_397
    .line 383: const/16 v6, 127
    .line 385: if-gt v6, v3, :cond_392
    .line 387: const/16 v6, 160
    .line 389: if-ge v3, v6, :cond_392
    .line 391: goto :goto_397
    .line 392: const v6, 0xfffd
    .line 395: if-ne v3, v6, :cond_399
    .line 397: goto/16 :goto_60
    .line 399: const/high16 v6, 0x1
    .line 401: if-ge v3, v6, :cond_405
    .line 403: const/4 v10, 1
    .line 404: goto :goto_406
    .line 405: const/4 v10, 2
    .line 406: add-int/2addr v5, v10
    .line 407: add-int/lit8 v4, v4, 4
    .line 409: goto/16 :goto_179
    .line 411: if-ne v6, v8, :cond_60
    .line 413: goto :goto_422
    .line 414: if-ne v6, v8, :cond_60
    .line 416: goto :goto_422
    .line 417: if-ne v6, v8, :cond_60
    .line 419: goto :goto_422
    .line 420: if-ne v6, v8, :cond_60
    .line 422: const-string v2, "…]"
    .line 424: const-string v3, "[size="
    .line 426: const/16 v4, 93
    .line 428: const/4 v6, -1
    .line 429: if-ne v5, v6, :cond_528
    .line 431: array-length v5, v1
    .line 432: if-gt v5, v8, :cond_457
    .line 434: new-instance v1, Ljava/lang/StringBuilder;
    .line 436: const-string v2, "[hex="
    .line 438: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 441: invoke-virtual/range {v17 .. v17}, Le4/k;->d()Ljava/lang/String;
    .line 444: move-result-object v2
    .line 445: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 448: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 451: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 454: move-result-object v1
    .line 455: goto/16 :goto_614
    .line 457: new-instance v4, Ljava/lang/StringBuilder;
    .line 459: invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 462: array-length v3, v1
    .line 463: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 466: const-string v3, " hex="
    .line 468: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 471: array-length v3, v1
    .line 472: if-gt v8, v3, :cond_504
    .line 474: array-length v3, v1
    .line 475: if-ne v8, v3, :cond_479
    .line 477: move-object v3, v0
    .line 478: goto :goto_489
    .line 479: new-instance v3, Le4/k;
    .line 481: const/4 v5, 0
    .line 482: invoke-static {v1, v5, v8}, Lt2/k;->Q0([BII)[B
    .line 485: move-result-object v1
    .line 486: invoke-direct {v3, v1}, Le4/k;-><init>([B)V
    .line 489: invoke-virtual {v3}, Le4/k;->d()Ljava/lang/String;
    .line 492: move-result-object v1
    .line 493: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 496: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 499: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 502: move-result-object v1
    .line 503: goto :goto_614
    .line 504: new-instance v2, Ljava/lang/StringBuilder;
    .line 506: const-string v3, "endIndex > length("
    .line 508: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 511: array-length v1, v1
    .line 512: const/16 v3, 41
    .line 514: invoke-static {v2, v1, v3}, Lai/onnxruntime/b;->j(Ljava/lang/StringBuilder;IC)Ljava/lang/String;
    .line 517: move-result-object v1
    .line 518: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 520: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 523: move-result-object v1
    .line 524: invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 527: throw v2
    .line 528: invoke-virtual/range {v17 .. v17}, Le4/k;->j()Ljava/lang/String;
    .line 531: move-result-object v6
    .line 532: const/4 v7, 0
    .line 533: invoke-virtual {v6, v7, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 536: move-result-object v7
    .line 537: const-string v8, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 539: invoke-static {v7, v8}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 542: const-string v8, "\\"
    .line 544: const-string v9, "\\\\"
    .line 546: invoke-static {v7, v8, v9}, Lm3/j;->a2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 549: move-result-object v7
    .line 550: const-string v8, "\n"
    .line 552: const-string v9, "\\n"
    .line 554: invoke-static {v7, v8, v9}, Lm3/j;->a2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 557: move-result-object v7
    .line 558: const-string v8, "\r"
    .line 560: const-string v9, "\\r"
    .line 562: invoke-static {v7, v8, v9}, Lm3/j;->a2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 565: move-result-object v7
    .line 566: invoke-virtual {v6}, Ljava/lang/String;->length()I
    .line 569: move-result v6
    .line 570: if-ge v5, v6, :cond_597
    .line 572: new-instance v4, Ljava/lang/StringBuilder;
    .line 574: invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 577: array-length v1, v1
    .line 578: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 581: const-string v1, " text="
    .line 583: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 586: invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 589: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 592: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 595: move-result-object v1
    .line 596: goto :goto_614
    .line 597: new-instance v1, Ljava/lang/StringBuilder;
    .line 599: const-string v2, "[text="
    .line 601: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 604: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 607: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 610: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 613: move-result-object v1
    .line 614: return-object v1
.end method

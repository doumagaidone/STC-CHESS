.class public final Le4/g;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Closeable;

.field public i:Le4/h;
.field public j:Z
.field public k:Le4/s;
.field public l:J
.field public m:[B
.field public n:I
.field public o:I

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: const-wide/16 v0, -1
    .line 5: iput-wide v0, v2, Le4/g;->l:J
    .line 7: const/4 v0, -1
    .line 8: iput v0, v2, Le4/g;->n:I
    .line 10: iput v0, v2, Le4/g;->o:I
    .line 12: return-void
.end method

# virtual methods
.method public final a(J)V
    .registers 18

    .line 0: move-object v0, v15
    .line 1: move-wide/from16 v1, v16
    .line 3: iget-object v3, v0, Le4/g;->i:Le4/h;
    .line 5: if-eqz v3, :cond_168
    .line 7: iget-boolean v4, v0, Le4/g;->j:Z
    .line 9: if-eqz v4, :cond_156
    .line 11: iget-wide v4, v3, Le4/h;->j:J
    .line 13: cmp-long v6, v1, v4
    .line 15: const-wide/16 v7, 0
    .line 17: if-gtz v6, :cond_101
    .line 19: cmp-long v6, v1, v7
    .line 21: if-ltz v6, :cond_77
    .line 23: sub-long/2addr v4, v1
    .line 24: cmp-long v6, v4, v7
    .line 26: if-lez v6, :cond_64
    .line 28: iget-object v6, v3, Le4/h;->i:Le4/s;
    .line 30: invoke-static {v6}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 33: iget-object v6, v6, Le4/s;->g:Le4/s;
    .line 35: invoke-static {v6}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 38: iget v9, v6, Le4/s;->c:I
    .line 40: iget v10, v6, Le4/s;->b:I
    .line 42: sub-int v10, v9, v10
    .line 44: int-to-long v10, v10
    .line 45: cmp-long v12, v10, v4
    .line 47: if-gtz v12, :cond_60
    .line 49: invoke-virtual {v6}, Le4/s;->a()Le4/s;
    .line 52: move-result-object v9
    .line 53: iput-object v9, v3, Le4/h;->i:Le4/s;
    .line 55: invoke-static {v6}, Le4/t;->a(Le4/s;)V
    .line 58: sub-long/2addr v4, v10
    .line 59: goto :goto_24
    .line 60: long-to-int v4, v4
    .line 61: sub-int/2addr v9, v4
    .line 62: iput v9, v6, Le4/s;->c:I
    .line 64: const/4 v4, 0
    .line 65: iput-object v4, v0, Le4/g;->k:Le4/s;
    .line 67: iput-wide v1, v0, Le4/g;->l:J
    .line 69: iput-object v4, v0, Le4/g;->m:[B
    .line 71: const/4 v4, -1
    .line 72: iput v4, v0, Le4/g;->n:I
    .line 74: iput v4, v0, Le4/g;->o:I
    .line 76: goto :goto_153
    .line 77: new-instance v3, Ljava/lang/StringBuilder;
    .line 79: const-string v4, "newSize < 0: "
    .line 81: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 84: invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 87: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 90: move-result-object v1
    .line 91: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 93: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 96: move-result-object v1
    .line 97: invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 100: throw v2
    .line 101: if-lez v6, :cond_153
    .line 103: sub-long v9, v1, v4
    .line 105: const/4 v6, 1
    .line 106: move v11, v6
    .line 107: cmp-long v12, v9, v7
    .line 109: if-lez v12, :cond_153
    .line 111: invoke-virtual {v3, v6}, Le4/h;->t(I)Le4/s;
    .line 114: move-result-object v12
    .line 115: iget v13, v12, Le4/s;->c:I
    .line 117: rsub-int v13, v13, 8192
    .line 119: int-to-long v13, v13
    .line 120: invoke-static {v9, v10, v13, v14}, Ljava/lang/Math;->min(JJ)J
    .line 123: move-result-wide v13
    .line 124: long-to-int v13, v13
    .line 125: iget v14, v12, Le4/s;->c:I
    .line 127: add-int/2addr v14, v13
    .line 128: iput v14, v12, Le4/s;->c:I
    .line 130: int-to-long v6, v13
    .line 131: sub-long/2addr v9, v6
    .line 132: if-eqz v11, :cond_149
    .line 134: iput-object v12, v0, Le4/g;->k:Le4/s;
    .line 136: iput-wide v4, v0, Le4/g;->l:J
    .line 138: iget-object v6, v12, Le4/s;->a:[B
    .line 140: iput-object v6, v0, Le4/g;->m:[B
    .line 142: sub-int v6, v14, v13
    .line 144: iput v6, v0, Le4/g;->n:I
    .line 146: iput v14, v0, Le4/g;->o:I
    .line 148: const/4 v11, 0
    .line 149: const/4 v6, 1
    .line 150: const-wide/16 v7, 0
    .line 152: goto :goto_107
    .line 153: iput-wide v1, v3, Le4/h;->j:J
    .line 155: return-void
    .line 156: new-instance v1, Ljava/lang/IllegalStateException;
    .line 158: const-string v2, "resizeBuffer() only permitted for read/write buffers"
    .line 160: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 163: move-result-object v2
    .line 164: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 167: throw v1
    .line 168: new-instance v1, Ljava/lang/IllegalStateException;
    .line 170: const-string v2, "not attached to a buffer"
    .line 172: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 175: move-result-object v2
    .line 176: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 179: throw v1
.end method

# virtual methods
.method public final b(J)I
    .registers 20

    .line 0: move-object/from16 v0, v17
    .line 2: move-wide/from16 v1, v18
    .line 4: iget-object v3, v0, Le4/g;->i:Le4/h;
    .line 6: if-eqz v3, :cond_225
    .line 8: const-wide/16 v4, -1
    .line 10: cmp-long v4, v1, v4
    .line 12: if-ltz v4, :cond_195
    .line 14: iget-wide v5, v3, Le4/h;->j:J
    .line 16: cmp-long v7, v1, v5
    .line 18: if-gtz v7, :cond_195
    .line 20: if-eqz v4, :cond_182
    .line 22: if-nez v7, :cond_26
    .line 24: goto/16 :goto_182
    .line 26: iget-object v4, v3, Le4/h;->i:Le4/s;
    .line 28: iget-object v7, v0, Le4/g;->k:Le4/s;
    .line 30: const-wide/16 v8, 0
    .line 32: if-eqz v7, :cond_56
    .line 34: iget-wide v10, v0, Le4/g;->l:J
    .line 36: iget v12, v0, Le4/g;->n:I
    .line 38: iget v13, v7, Le4/s;->b:I
    .line 40: sub-int/2addr v12, v13
    .line 41: int-to-long v12, v12
    .line 42: sub-long/2addr v10, v12
    .line 43: cmp-long v12, v10, v1
    .line 45: if-lez v12, :cond_54
    .line 47: move-wide v5, v10
    .line 48: move-object/from16 v16, v7
    .line 50: move-object v7, v4
    .line 51: move-object/from16 v4, v16
    .line 53: goto :goto_57
    .line 54: move-wide v8, v10
    .line 55: goto :goto_57
    .line 56: move-object v7, v4
    .line 57: sub-long v10, v5, v1
    .line 59: sub-long v12, v1, v8
    .line 61: cmp-long v10, v10, v12
    .line 63: if-lez v10, :cond_83
    .line 65: invoke-static {v7}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 68: iget v4, v7, Le4/s;->c:I
    .line 70: iget v5, v7, Le4/s;->b:I
    .line 72: sub-int/2addr v4, v5
    .line 73: int-to-long v4, v4
    .line 74: add-long/2addr v4, v8
    .line 75: cmp-long v6, v1, v4
    .line 77: if-ltz v6, :cond_105
    .line 79: iget-object v7, v7, Le4/s;->f:Le4/s;
    .line 81: move-wide v8, v4
    .line 82: goto :goto_65
    .line 83: cmp-long v7, v5, v1
    .line 85: if-lez v7, :cond_103
    .line 87: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 90: iget-object v4, v4, Le4/s;->g:Le4/s;
    .line 92: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 95: iget v7, v4, Le4/s;->c:I
    .line 97: iget v8, v4, Le4/s;->b:I
    .line 99: sub-int/2addr v7, v8
    .line 100: int-to-long v7, v7
    .line 101: sub-long/2addr v5, v7
    .line 102: goto :goto_83
    .line 103: move-object v7, v4
    .line 104: move-wide v8, v5
    .line 105: iget-boolean v4, v0, Le4/g;->j:Z
    .line 107: if-eqz v4, :cond_158
    .line 109: invoke-static {v7}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 112: iget-boolean v4, v7, Le4/s;->d:Z
    .line 114: if-eqz v4, :cond_158
    .line 116: new-instance v4, Le4/s;
    .line 118: iget-object v5, v7, Le4/s;->a:[B
    .line 120: array-length v6, v5
    .line 121: invoke-static {v5, v6}, Ljava/util/Arrays;->copyOf([BI)[B
    .line 124: move-result-object v11
    .line 125: const-string v5, "copyOf(this, size)"
    .line 127: invoke-static {v11, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 130: iget v12, v7, Le4/s;->b:I
    .line 132: iget v13, v7, Le4/s;->c:I
    .line 134: const/4 v14, 0
    .line 135: const/4 v15, 1
    .line 136: move-object v10, v4
    .line 137: invoke-direct/range {v10 .. v15}, Le4/s;-><init>([BIIZZ)V
    .line 140: iget-object v5, v3, Le4/h;->i:Le4/s;
    .line 142: if-ne v5, v7, :cond_146
    .line 144: iput-object v4, v3, Le4/h;->i:Le4/s;
    .line 146: invoke-virtual {v7, v4}, Le4/s;->b(Le4/s;)V
    .line 149: iget-object v3, v4, Le4/s;->g:Le4/s;
    .line 151: invoke-static {v3}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 154: invoke-virtual {v3}, Le4/s;->a()Le4/s;
    .line 157: move-object v7, v4
    .line 158: iput-object v7, v0, Le4/g;->k:Le4/s;
    .line 160: iput-wide v1, v0, Le4/g;->l:J
    .line 162: invoke-static {v7}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 165: iget-object v3, v7, Le4/s;->a:[B
    .line 167: iput-object v3, v0, Le4/g;->m:[B
    .line 169: iget v3, v7, Le4/s;->b:I
    .line 171: sub-long/2addr v1, v8
    .line 172: long-to-int v1, v1
    .line 173: add-int/2addr v3, v1
    .line 174: iput v3, v0, Le4/g;->n:I
    .line 176: iget v1, v7, Le4/s;->c:I
    .line 178: iput v1, v0, Le4/g;->o:I
    .line 180: sub-int/2addr v1, v3
    .line 181: goto :goto_194
    .line 182: const/4 v3, 0
    .line 183: iput-object v3, v0, Le4/g;->k:Le4/s;
    .line 185: iput-wide v1, v0, Le4/g;->l:J
    .line 187: iput-object v3, v0, Le4/g;->m:[B
    .line 189: const/4 v1, -1
    .line 190: iput v1, v0, Le4/g;->n:I
    .line 192: iput v1, v0, Le4/g;->o:I
    .line 194: return v1
    .line 195: new-instance v4, Ljava/lang/ArrayIndexOutOfBoundsException;
    .line 197: new-instance v5, Ljava/lang/StringBuilder;
    .line 199: const-string v6, "offset="
    .line 201: invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 204: invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 207: const-string v1, " > size="
    .line 209: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 212: iget-wide v1, v3, Le4/h;->j:J
    .line 214: invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 217: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 220: move-result-object v1
    .line 221: invoke-direct {v4, v1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 224: throw v4
    .line 225: new-instance v1, Ljava/lang/IllegalStateException;
    .line 227: const-string v2, "not attached to a buffer"
    .line 229: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 232: move-result-object v2
    .line 233: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 236: throw v1
.end method

# virtual methods
.method public final close()V
    .registers 4

    .line 0: iget-object v0, v3, Le4/g;->i:Le4/h;
    .line 2: if-eqz v0, :cond_21
    .line 4: const/4 v0, 0
    .line 5: iput-object v0, v3, Le4/g;->i:Le4/h;
    .line 7: iput-object v0, v3, Le4/g;->k:Le4/s;
    .line 9: const-wide/16 v1, -1
    .line 11: iput-wide v1, v3, Le4/g;->l:J
    .line 13: iput-object v0, v3, Le4/g;->m:[B
    .line 15: const/4 v0, -1
    .line 16: iput v0, v3, Le4/g;->n:I
    .line 18: iput v0, v3, Le4/g;->o:I
    .line 20: return-void
    .line 21: new-instance v0, Ljava/lang/IllegalStateException;
    .line 23: const-string v1, "not attached to a buffer"
    .line 25: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 28: move-result-object v1
    .line 29: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 32: throw v0
.end method

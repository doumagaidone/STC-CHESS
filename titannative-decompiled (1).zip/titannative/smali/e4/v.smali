.class public abstract interface Le4/v;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;

# virtual methods
.method public abstract close()V
.end method

# virtual methods
.method public abstract d()Le4/z;
.end method

# virtual methods
.method public abstract flush()V
.end method

# virtual methods
.method public abstract y(Le4/h;J)V
.end method

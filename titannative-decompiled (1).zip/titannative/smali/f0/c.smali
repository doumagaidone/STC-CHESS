.class public abstract interface Lf0/c;
.super Ljava/lang/Object;
.source "SourceFile"

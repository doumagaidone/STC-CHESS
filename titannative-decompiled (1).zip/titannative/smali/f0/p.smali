.class public abstract interface Lf0/p;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:I

# virtual methods
.method public abstract a(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract d(Ld3/c;)Z
.end method

# virtual methods
.method public j(Lf0/p;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "other"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Lf0/m;->c:Lf0/m;
    .line 7: if-ne v2, v0, :cond_11
    .line 9: move-object v0, v1
    .line 10: goto :goto_16
    .line 11: new-instance v0, Lf0/i;
    .line 13: invoke-direct {v0, v1, v2}, Lf0/i;-><init>(Lf0/p;Lf0/p;)V
    .line 16: return-object v0
.end method

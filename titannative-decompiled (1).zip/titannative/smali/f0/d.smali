.class public abstract interface Lf0/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:I

.class public abstract interface Lf0/b;
.super Ljava/lang/Object;
.source "SourceFile"

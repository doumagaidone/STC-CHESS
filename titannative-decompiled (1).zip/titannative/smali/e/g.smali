.class public Le/g;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Iterable;

.field public i:Le/c;
.field public j:Le/c;
.field public final k:Ljava/util/WeakHashMap;
.field public l:I

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/WeakHashMap;
    .line 5: invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V
    .line 8: iput-object v0, v1, Le/g;->k:Ljava/util/WeakHashMap;
    .line 10: const/4 v0, 0
    .line 11: iput v0, v1, Le/g;->l:I
    .line 13: return-void
.end method

# virtual methods
.method public b(Ljava/lang/Object;)Le/c;
    .registers 4

    .line 0: iget-object v0, v2, Le/g;->i:Le/c;
    .line 2: if-eqz v0, :cond_16
    .line 4: iget-object v1, v0, Le/c;->i:Ljava/lang/Object;
    .line 6: invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_13
    .line 12: goto :goto_16
    .line 13: iget-object v0, v0, Le/c;->k:Le/c;
    .line 15: goto :goto_2
    .line 16: return-object v0
.end method

# virtual methods
.method public c(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0: invoke-virtual {v3, v4}, Le/g;->b(Ljava/lang/Object;)Le/c;
    .line 3: move-result-object v4
    .line 4: const/4 v0, 0
    .line 5: if-nez v4, :cond_8
    .line 7: return-object v0
    .line 8: iget v1, v3, Le/g;->l:I
    .line 10: add-int/lit8 v1, v1, -1
    .line 12: iput v1, v3, Le/g;->l:I
    .line 14: iget-object v1, v3, Le/g;->k:Ljava/util/WeakHashMap;
    .line 16: invoke-virtual {v1}, Ljava/util/WeakHashMap;->isEmpty()Z
    .line 19: move-result v2
    .line 20: if-nez v2, :cond_46
    .line 22: invoke-virtual {v1}, Ljava/util/WeakHashMap;->keySet()Ljava/util/Set;
    .line 25: move-result-object v1
    .line 26: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 29: move-result-object v1
    .line 30: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 33: move-result v2
    .line 34: if-eqz v2, :cond_46
    .line 36: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 39: move-result-object v2
    .line 40: check-cast v2, Le/f;
    .line 42: invoke-virtual {v2, v4}, Le/f;->a(Le/c;)V
    .line 45: goto :goto_30
    .line 46: iget-object v1, v4, Le/c;->l:Le/c;
    .line 48: if-eqz v1, :cond_55
    .line 50: iget-object v2, v4, Le/c;->k:Le/c;
    .line 52: iput-object v2, v1, Le/c;->k:Le/c;
    .line 54: goto :goto_59
    .line 55: iget-object v2, v4, Le/c;->k:Le/c;
    .line 57: iput-object v2, v3, Le/g;->i:Le/c;
    .line 59: iget-object v2, v4, Le/c;->k:Le/c;
    .line 61: if-eqz v2, :cond_66
    .line 63: iput-object v1, v2, Le/c;->l:Le/c;
    .line 65: goto :goto_68
    .line 66: iput-object v1, v3, Le/g;->j:Le/c;
    .line 68: iput-object v0, v4, Le/c;->k:Le/c;
    .line 70: iput-object v0, v4, Le/c;->l:Le/c;
    .line 72: iget-object v4, v4, Le/c;->j:Ljava/lang/Object;
    .line 74: return-object v4
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v6, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v7, Le/g;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v7, Le/g;
    .line 12: iget v1, v6, Le/g;->l:I
    .line 14: iget v3, v7, Le/g;->l:I
    .line 16: if-eq v1, v3, :cond_19
    .line 18: return v2
    .line 19: invoke-virtual {v6}, Le/g;->iterator()Ljava/util/Iterator;
    .line 22: move-result-object v1
    .line 23: invoke-virtual {v7}, Le/g;->iterator()Ljava/util/Iterator;
    .line 26: move-result-object v7
    .line 27: move-object v3, v1
    .line 28: check-cast v3, Le/e;
    .line 30: invoke-virtual {v3}, Le/e;->hasNext()Z
    .line 33: move-result v4
    .line 34: if-eqz v4, :cond_68
    .line 36: move-object v4, v7
    .line 37: check-cast v4, Le/e;
    .line 39: invoke-virtual {v4}, Le/e;->hasNext()Z
    .line 42: move-result v5
    .line 43: if-eqz v5, :cond_68
    .line 45: invoke-virtual {v3}, Le/e;->next()Ljava/lang/Object;
    .line 48: move-result-object v3
    .line 49: check-cast v3, Ljava/util/Map$Entry;
    .line 51: invoke-virtual {v4}, Le/e;->next()Ljava/lang/Object;
    .line 54: move-result-object v4
    .line 55: if-nez v3, :cond_59
    .line 57: if-nez v4, :cond_67
    .line 59: if-eqz v3, :cond_27
    .line 61: invoke-interface {v3, v4}, Ljava/util/Map$Entry;->equals(Ljava/lang/Object;)Z
    .line 64: move-result v3
    .line 65: if-nez v3, :cond_27
    .line 67: return v2
    .line 68: invoke-virtual {v3}, Le/e;->hasNext()Z
    .line 71: move-result v1
    .line 72: if-nez v1, :cond_83
    .line 74: check-cast v7, Le/e;
    .line 76: invoke-virtual {v7}, Le/e;->hasNext()Z
    .line 79: move-result v7
    .line 80: if-nez v7, :cond_83
    .line 82: goto :goto_84
    .line 83: move v0, v2
    .line 84: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 5

    .line 0: invoke-virtual {v4}, Le/g;->iterator()Ljava/util/Iterator;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: move-object v2, v0
    .line 6: check-cast v2, Le/e;
    .line 8: invoke-virtual {v2}, Le/e;->hasNext()Z
    .line 11: move-result v3
    .line 12: if-eqz v3, :cond_26
    .line 14: invoke-virtual {v2}, Le/e;->next()Ljava/lang/Object;
    .line 17: move-result-object v2
    .line 18: check-cast v2, Ljava/util/Map$Entry;
    .line 20: invoke-interface {v2}, Ljava/util/Map$Entry;->hashCode()I
    .line 23: move-result v2
    .line 24: add-int/2addr v1, v2
    .line 25: goto :goto_5
    .line 26: return v1
.end method

# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .registers 5

    .line 0: new-instance v0, Le/b;
    .line 2: iget-object v1, v4, Le/g;->i:Le/c;
    .line 4: iget-object v2, v4, Le/g;->j:Le/c;
    .line 6: const/4 v3, 0
    .line 7: invoke-direct {v0, v1, v2, v3}, Le/b;-><init>(Le/c;Le/c;I)V
    .line 10: iget-object v1, v4, Le/g;->k:Ljava/util/WeakHashMap;
    .line 12: sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 14: invoke-virtual {v1, v0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 17: return-object v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "["
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: invoke-virtual {v4}, Le/g;->iterator()Ljava/util/Iterator;
    .line 10: move-result-object v1
    .line 11: move-object v2, v1
    .line 12: check-cast v2, Le/e;
    .line 14: invoke-virtual {v2}, Le/e;->hasNext()Z
    .line 17: move-result v3
    .line 18: if-eqz v3, :cond_45
    .line 20: invoke-virtual {v2}, Le/e;->next()Ljava/lang/Object;
    .line 23: move-result-object v3
    .line 24: check-cast v3, Ljava/util/Map$Entry;
    .line 26: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 29: move-result-object v3
    .line 30: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 33: invoke-virtual {v2}, Le/e;->hasNext()Z
    .line 36: move-result v2
    .line 37: if-eqz v2, :cond_11
    .line 39: const-string v2, ", "
    .line 41: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 44: goto :goto_11
    .line 45: const-string v1, "]"
    .line 47: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 50: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 53: move-result-object v0
    .line 54: return-object v0
.end method

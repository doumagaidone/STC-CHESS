.class public final Le/c;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Map$Entry;

.field public final i:Ljava/lang/Object;
.field public final j:Ljava/lang/Object;
.field public k:Le/c;
.field public l:Le/c;

# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Le/c;->i:Ljava/lang/Object;
    .line 5: iput-object v2, v0, Le/c;->j:Ljava/lang/Object;
    .line 7: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v5, v4, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Le/c;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Le/c;
    .line 12: iget-object v1, v5, Le/c;->i:Ljava/lang/Object;
    .line 14: iget-object v3, v4, Le/c;->i:Ljava/lang/Object;
    .line 16: invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_33
    .line 22: iget-object v1, v4, Le/c;->j:Ljava/lang/Object;
    .line 24: iget-object v5, v5, Le/c;->j:Ljava/lang/Object;
    .line 26: invoke-virtual {v1, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 29: move-result v5
    .line 30: if-eqz v5, :cond_33
    .line 32: goto :goto_34
    .line 33: move v0, v2
    .line 34: return v0
.end method

# virtual methods
.method public final getKey()Ljava/lang/Object;
    .registers 2

    .line 0: iget-object v0, v1, Le/c;->i:Ljava/lang/Object;
    .line 2: return-object v0
.end method

# virtual methods
.method public final getValue()Ljava/lang/Object;
    .registers 2

    .line 0: iget-object v0, v1, Le/c;->j:Ljava/lang/Object;
    .line 2: return-object v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Le/c;->i:Ljava/lang/Object;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 5: move-result v0
    .line 6: iget-object v1, v2, Le/c;->j:Ljava/lang/Object;
    .line 8: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 11: move-result v1
    .line 12: xor-int/2addr v0, v1
    .line 13: return v0
.end method

# virtual methods
.method public final setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0: new-instance v2, Ljava/lang/UnsupportedOperationException;
    .line 2: const-string v0, "An entry modification is not supported"
    .line 4: invoke-direct {v2, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 7: throw v2
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 5: iget-object v1, v2, Le/c;->i:Ljava/lang/Object;
    .line 7: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 10: const-string v1, "="
    .line 12: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 15: iget-object v1, v2, Le/c;->j:Ljava/lang/Object;
    .line 17: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 20: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 23: move-result-object v0
    .line 24: return-object v0
.end method

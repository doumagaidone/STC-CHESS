.class public abstract Lf4/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:[C

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const/16 v0, 16
    .line 2: new-array v0, v0, [C
    .line 4: fill-array-data v0, :data_10
    .line 7: sput-object v0, Lf4/b;->a:[C
    .line 9: return-void
    .line 10: nop
    .line 11: move/from16 v0, v16
    .line 13: nop
    .line 14: cmpg-double v0, v49, v0
    .line 16: if-eq v0, v0, :cond_67
    .line 18: if-lt v0, v0, :cond_71
    .line 20: if-gt v0, v0, :cond_75
    .line 22: if-eqz v0, :cond_79
    .line 24: sget-wide v0, Lai/onnxruntime/OnnxRuntime;->ORT_API_VERSION_2:I
    .line 26: sget-boolean v0, Lai/onnxruntime/OnnxRuntime;->ORT_API_VERSION_7:I
    .line 28: sget-char v0, Lai/onnxruntime/OnnxRuntime;->ORT_TRAINING_API_VERSION_1:I
.end method

# direct methods
.method public static final a(C)I
    .registers 4

    .line 0: const/16 v0, 48
    .line 2: if-gt v0, v3, :cond_10
    .line 4: const/16 v1, 58
    .line 6: if-ge v3, v1, :cond_10
    .line 8: sub-int/2addr v3, v0
    .line 9: goto :goto_31
    .line 10: const/16 v0, 97
    .line 12: if-gt v0, v3, :cond_21
    .line 14: const/16 v0, 103
    .line 16: if-ge v3, v0, :cond_21
    .line 18: add-int/lit8 v3, v3, -87
    .line 20: goto :goto_31
    .line 21: const/16 v0, 65
    .line 23: if-gt v0, v3, :cond_32
    .line 25: const/16 v0, 71
    .line 27: if-ge v3, v0, :cond_32
    .line 29: add-int/lit8 v3, v3, -55
    .line 31: return v3
    .line 32: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 34: new-instance v1, Ljava/lang/StringBuilder;
    .line 36: const-string v2, "Unexpected hex digit: "
    .line 38: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 41: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 44: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 47: move-result-object v3
    .line 48: invoke-direct {v0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 51: throw v0
.end method

.class public abstract Lf4/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:[B

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 2: const-string v1, "0123456789abcdef"
    .line 4: invoke-virtual {v1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B
    .line 7: move-result-object v0
    .line 8: const-string v1, "this as java.lang.String).getBytes(charset)"
    .line 10: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: sput-object v0, Lf4/a;->a:[B
    .line 15: return-void
.end method

# direct methods
.method public static final a(Le4/h;J)Ljava/lang/String;
    .registers 9

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-wide/16 v0, 0
    .line 7: cmp-long v0, v7, v0
    .line 9: const-wide/16 v1, 1
    .line 11: if-lez v0, :cond_35
    .line 13: sub-long v3, v7, v1
    .line 15: invoke-virtual {v6, v3, v4}, Le4/h;->b(J)B
    .line 18: move-result v0
    .line 19: const/16 v5, 13
    .line 21: if-ne v0, v5, :cond_35
    .line 23: sget-object v7, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 25: invoke-virtual {v6, v3, v4, v7}, Le4/h;->k(JLjava/nio/charset/Charset;)Ljava/lang/String;
    .line 28: move-result-object v7
    .line 29: const-wide/16 v0, 2
    .line 31: invoke-virtual {v6, v0, v1}, Le4/h;->A(J)V
    .line 34: goto :goto_44
    .line 35: sget-object v0, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 37: invoke-virtual {v6, v7, v8, v0}, Le4/h;->k(JLjava/nio/charset/Charset;)Ljava/lang/String;
    .line 40: move-result-object v7
    .line 41: invoke-virtual {v6, v1, v2}, Le4/h;->A(J)V
    .line 44: return-object v7
.end method

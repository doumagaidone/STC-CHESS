.class public final Lb2/j;
.super Ljava/lang/Thread;
.source "SourceFile"

.field public final i:I

# direct methods
.method public constructor <init>(Ljava/lang/Runnable;Ljava/lang/String;I)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V
    .line 3: iput v3, v0, Lb2/j;->i:I
    .line 5: return-void
.end method

# virtual methods
.method public final run()V
    .registers 2

    .line 0: iget v0, v1, Lb2/j;->i:I
    .line 2: invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    .line 5: invoke-super {v1}, Ljava/lang/Thread;->run()V
    .line 8: return-void
.end method

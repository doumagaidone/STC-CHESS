.class public final Lb2/b;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final j:I
.field public final k:Ljava/lang/Object;
.field public final l:Ljava/lang/Object;

# direct methods
.method public constructor <init>(ILjava/util/ArrayList;)V
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: iput v0, v1, Lb2/b;->i:I
    .line 3: const/4 v0, 0
    .line 4: invoke-direct {v1, v3, v2, v0}, Lb2/b;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/util/List;ILjava/lang/Throwable;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v3, 1
    .line 4: iput v3, v0, Lb2/b;->i:I
    .line 6: if-eqz v1, :cond_18
    .line 8: new-instance v3, Ljava/util/ArrayList;
    .line 10: invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 13: iput-object v3, v0, Lb2/b;->k:Ljava/lang/Object;
    .line 15: iput v2, v0, Lb2/b;->j:I
    .line 17: return-void
    .line 18: new-instance v1, Ljava/lang/NullPointerException;
    .line 20: const-string v2, "initCallbacks cannot be null"
    .line 22: invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 25: throw v1
.end method

# direct methods
.method public constructor <init>(Ln1/e;I)V
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: iput v0, v1, Lb2/b;->i:I
    .line 3: filled-new-array {v2}, [Ln1/e;
    .line 6: move-result-object v2
    .line 7: invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    .line 10: move-result-object v2
    .line 11: const/4 v0, 0
    .line 12: invoke-direct {v1, v2, v3, v0}, Lb2/b;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V
    .line 15: return-void
.end method

# direct methods
.method public constructor <init>(Lo/g2;Lu/d;I)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v1, 0
    .line 4: iput v1, v0, Lb2/b;->i:I
    .line 6: iput-object v2, v0, Lb2/b;->k:Ljava/lang/Object;
    .line 8: iput v3, v0, Lb2/b;->j:I
    .line 10: return-void
.end method

# virtual methods
.method public final run()V
    .registers 8

    .line 0: iget v0, v7, Lb2/b;->i:I
    .line 2: iget-object v1, v7, Lb2/b;->k:Ljava/lang/Object;
    .line 4: packed-switch v0, :data_72
    .line 7: check-cast v1, Ljava/util/List;
    .line 9: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 12: move-result v0
    .line 13: const/4 v2, 1
    .line 14: iget v3, v7, Lb2/b;->j:I
    .line 16: const/4 v4, 0
    .line 17: if-eq v3, v2, :cond_36
    .line 19: if-ge v4, v0, :cond_63
    .line 21: invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 24: move-result-object v2
    .line 25: check-cast v2, Ln1/e;
    .line 27: sget-object v3, Ln1/h;->a:Ln1/i;
    .line 29: iget-object v2, v2, Ln1/e;->b:Ln1/f;
    .line 31: iput-object v3, v2, Ln1/f;->a:Lu/i3;
    .line 33: add-int/lit8 v4, v4, 1
    .line 35: goto :goto_19
    .line 36: if-ge v4, v0, :cond_63
    .line 38: invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 41: move-result-object v3
    .line 42: check-cast v3, Ln1/e;
    .line 44: iget-object v5, v3, Ln1/e;->a:Lu/l1;
    .line 46: sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 48: invoke-interface {v5, v6}, Lu/l1;->setValue(Ljava/lang/Object;)V
    .line 51: new-instance v5, Ln1/i;
    .line 53: invoke-direct {v5, v2}, Ln1/i;-><init>(Z)V
    .line 56: iget-object v3, v3, Ln1/e;->b:Ln1/f;
    .line 58: iput-object v5, v3, Ln1/f;->a:Lu/i3;
    .line 60: add-int/lit8 v4, v4, 1
    .line 62: goto :goto_36
    .line 63: return-void
    .line 64: check-cast v1, Lu/d;
    .line 66: iget-object v0, v1, Lu/d;->b:Ljava/lang/Object;
    .line 68: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 71: return-void
    .line 72: nop
    .line 73: move v0, v0
    .line 74: nop
    .line 75: nop
    .line 76: if-gtz v0, :cond_76
.end method

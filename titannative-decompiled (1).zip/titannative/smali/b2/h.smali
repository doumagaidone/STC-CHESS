.class public abstract Lb2/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lf/e;
.field public static final b:Ljava/lang/Object;

# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 0: new-instance v0, Lf/e;
    .line 2: invoke-direct {v0}, Lf/e;-><init>()V
    .line 5: sput-object v0, Lb2/h;->a:Lf/e;
    .line 7: new-instance v8, Lb2/k;
    .line 9: invoke-direct {v8}, Ljava/lang/Object;-><init>()V
    .line 12: const-string v0, "fonts-androidx"
    .line 14: iput-object v0, v8, Lb2/k;->a:Ljava/lang/String;
    .line 16: const/16 v0, 10
    .line 18: iput v0, v8, Lb2/k;->b:I
    .line 20: new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;
    .line 22: const/4 v2, 0
    .line 23: const/4 v3, 1
    .line 24: const/16 v1, 10000
    .line 26: int-to-long v4, v1
    .line 27: sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;
    .line 29: new-instance v7, Ljava/util/concurrent/LinkedBlockingDeque;
    .line 31: invoke-direct {v7}, Ljava/util/concurrent/LinkedBlockingDeque;-><init>()V
    .line 34: move-object v1, v0
    .line 35: invoke-direct/range {v1 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V
    .line 38: const/4 v1, 1
    .line 39: invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V
    .line 42: return-void
.end method

# direct methods
.method public static a(Ljava/lang/String;Landroid/content/Context;Lb2/e;I)Lb2/g;
    .registers 11

    .line 0: sget-object v0, Lb2/h;->a:Lf/e;
    .line 2: invoke-virtual {v0, v7}, Lf/e;->a(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Landroid/graphics/Typeface;
    .line 8: if-eqz v1, :cond_16
    .line 10: new-instance v7, Lb2/g;
    .line 12: invoke-direct {v7, v1}, Lb2/g;-><init>(Landroid/graphics/Typeface;)V
    .line 15: return-object v7
    .line 16: invoke-static {v8, v9}, Lb2/d;->a(Landroid/content/Context;Lb2/e;)Lh/t1;
    .line 19: move-result-object v9
    .line 20: iget v1, v9, Lh/t1;->a:I
    .line 22: const/4 v2, 1
    .line 23: const/4 v3, -3
    .line 24: if-eqz v1, :cond_32
    .line 26: if-eq v1, v2, :cond_30
    .line 28: move v2, v3
    .line 29: goto :goto_62
    .line 30: const/4 v2, -2
    .line 31: goto :goto_62
    .line 32: iget-object v1, v9, Lh/t1;->b:Ljava/lang/Object;
    .line 34: check-cast v1, [Lb2/i;
    .line 36: if-eqz v1, :cond_62
    .line 38: array-length v4, v1
    .line 39: if-nez v4, :cond_42
    .line 41: goto :goto_62
    .line 42: array-length v2, v1
    .line 43: const/4 v4, 0
    .line 44: move v5, v4
    .line 45: if-ge v5, v2, :cond_61
    .line 47: aget-object v6, v1, v5
    .line 49: iget v6, v6, Lb2/i;->e:I
    .line 51: if-eqz v6, :cond_58
    .line 53: if-gez v6, :cond_56
    .line 55: goto :goto_28
    .line 56: move v2, v6
    .line 57: goto :goto_62
    .line 58: add-int/lit8 v5, v5, 1
    .line 60: goto :goto_45
    .line 61: move v2, v4
    .line 62: if-eqz v2, :cond_70
    .line 64: new-instance v7, Lb2/g;
    .line 66: invoke-direct {v7, v2}, Lb2/g;-><init>(I)V
    .line 69: return-object v7
    .line 70: iget-object v9, v9, Lh/t1;->b:Ljava/lang/Object;
    .line 72: check-cast v9, [Lb2/i;
    .line 74: sget-object v1, Ly1/d;->a:Lu/d;
    .line 76: invoke-virtual {v1, v8, v9, v10}, Lu/d;->h(Landroid/content/Context;[Lb2/i;I)Landroid/graphics/Typeface;
    .line 79: move-result-object v8
    .line 80: if-eqz v8, :cond_91
    .line 82: invoke-virtual {v0, v7, v8}, Lf/e;->b(Ljava/lang/Object;Landroid/graphics/Typeface;)V
    .line 85: new-instance v7, Lb2/g;
    .line 87: invoke-direct {v7, v8}, Lb2/g;-><init>(Landroid/graphics/Typeface;)V
    .line 90: return-object v7
    .line 91: new-instance v7, Lb2/g;
    .line 93: invoke-direct {v7, v3}, Lb2/g;-><init>(I)V
    .line 96: return-object v7
    .line 97: new-instance v7, Lb2/g;
    .line 99: const/4 v8, -1
    .line 100: invoke-direct {v7, v8}, Lb2/g;-><init>(I)V
    .line 103: return-object v7
.end method

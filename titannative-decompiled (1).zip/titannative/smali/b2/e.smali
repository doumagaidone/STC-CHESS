.class public final Lb2/e;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/lang/String;
.field public final c:Ljava/lang/String;
.field public final d:Ljava/util/List;
.field public final e:Ljava/lang/String;

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .registers 5

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 6: iput-object v1, v0, Lb2/e;->a:Ljava/lang/String;
    .line 8: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 11: iput-object v2, v0, Lb2/e;->b:Ljava/lang/String;
    .line 13: iput-object v3, v0, Lb2/e;->c:Ljava/lang/String;
    .line 15: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 18: iput-object v4, v0, Lb2/e;->d:Ljava/util/List;
    .line 20: new-instance v4, Ljava/lang/StringBuilder;
    .line 22: invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 25: const-string v1, "-"
    .line 27: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 33: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 36: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 42: move-result-object v1
    .line 43: iput-object v1, v0, Lb2/e;->e:Ljava/lang/String;
    .line 45: return-void
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 7

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 5: new-instance v1, Ljava/lang/StringBuilder;
    .line 7: const-string v2, "FontRequest {mProviderAuthority: "
    .line 9: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 12: iget-object v2, v6, Lb2/e;->a:Ljava/lang/String;
    .line 14: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: const-string v2, ", mProviderPackage: "
    .line 19: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: iget-object v2, v6, Lb2/e;->b:Ljava/lang/String;
    .line 24: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: const-string v2, ", mQuery: "
    .line 29: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: iget-object v2, v6, Lb2/e;->c:Ljava/lang/String;
    .line 34: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: const-string v2, ", mCertificates:"
    .line 39: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 45: move-result-object v1
    .line 46: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 49: const/4 v1, 0
    .line 50: move v2, v1
    .line 51: iget-object v3, v6, Lb2/e;->d:Ljava/util/List;
    .line 53: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 56: move-result v4
    .line 57: if-ge v2, v4, :cond_111
    .line 59: const-string v4, " ["
    .line 61: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 64: invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 67: move-result-object v3
    .line 68: check-cast v3, Ljava/util/List;
    .line 70: move v4, v1
    .line 71: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 74: move-result v5
    .line 75: if-ge v4, v5, :cond_103
    .line 77: const-string v5, " \""
    .line 79: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 82: invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 85: move-result-object v5
    .line 86: check-cast v5, [B
    .line 88: invoke-static {v5, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;
    .line 91: move-result-object v5
    .line 92: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 95: const-string v5, "\""
    .line 97: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 100: add-int/lit8 v4, v4, 1
    .line 102: goto :goto_71
    .line 103: const-string v3, " ]"
    .line 105: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 108: add-int/lit8 v2, v2, 1
    .line 110: goto :goto_51
    .line 111: const-string v1, "}mCertificatesArray: 0"
    .line 113: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 116: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 119: move-result-object v0
    .line 120: return-object v0
.end method

.class public final Lb2/k;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/concurrent/ThreadFactory;

.field public a:Ljava/lang/String;
.field public b:I

# virtual methods
.method public final newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .registers 5

    .line 0: new-instance v0, Lb2/j;
    .line 2: iget-object v1, v3, Lb2/k;->a:Ljava/lang/String;
    .line 4: iget v2, v3, Lb2/k;->b:I
    .line 6: invoke-direct {v0, v4, v1, v2}, Lb2/j;-><init>(Ljava/lang/Runnable;Ljava/lang/String;I)V
    .line 9: return-object v0
.end method

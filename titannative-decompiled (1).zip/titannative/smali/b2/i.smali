.class public final Lb2/i;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroid/net/Uri;
.field public final b:I
.field public final c:I
.field public final d:Z
.field public final e:I

# direct methods
.method public constructor <init>(Landroid/net/Uri;IIZI)V
    .registers 6

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 6: iput-object v1, v0, Lb2/i;->a:Landroid/net/Uri;
    .line 8: iput v2, v0, Lb2/i;->b:I
    .line 10: iput v3, v0, Lb2/i;->c:I
    .line 12: iput-boolean v4, v0, Lb2/i;->d:Z
    .line 14: iput v5, v0, Lb2/i;->e:I
    .line 16: return-void
.end method

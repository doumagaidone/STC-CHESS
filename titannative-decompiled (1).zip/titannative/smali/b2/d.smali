.class public abstract Lb2/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lz0/c0;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Lz0/c0;
    .line 2: const/4 v1, 2
    .line 3: invoke-direct {v0, v1}, Lz0/c0;-><init>(I)V
    .line 6: sput-object v0, Lb2/d;->a:Lz0/c0;
    .line 8: return-void
.end method

# direct methods
.method public static a(Landroid/content/Context;Lb2/e;)Lh/t1;
    .registers 21

    .line 0: move-object/from16 v0, v20
    .line 2: const/4 v6, 0
    .line 3: invoke-virtual/range {v19 .. v19}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 6: move-result-object v1
    .line 7: invoke-virtual/range {v19 .. v19}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 10: move-result-object v2
    .line 11: iget-object v3, v0, Lb2/e;->a:Ljava/lang/String;
    .line 13: const/4 v7, 0
    .line 14: invoke-virtual {v1, v3, v7}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;
    .line 17: move-result-object v4
    .line 18: if-eqz v4, :cond_448
    .line 20: iget-object v5, v4, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;
    .line 22: iget-object v8, v0, Lb2/e;->b:Ljava/lang/String;
    .line 24: invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 27: move-result v5
    .line 28: if-eqz v5, :cond_420
    .line 30: iget-object v3, v4, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;
    .line 32: const/16 v5, 64
    .line 34: invoke-virtual {v1, v3, v5}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    .line 37: move-result-object v1
    .line 38: iget-object v1, v1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;
    .line 40: new-instance v3, Ljava/util/ArrayList;
    .line 42: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    .line 45: array-length v5, v1
    .line 46: move v8, v7
    .line 47: if-ge v8, v5, :cond_61
    .line 49: aget-object v9, v1, v8
    .line 51: invoke-virtual {v9}, Landroid/content/pm/Signature;->toByteArray()[B
    .line 54: move-result-object v9
    .line 55: invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 58: add-int/lit8 v8, v8, 1
    .line 60: goto :goto_47
    .line 61: sget-object v1, Lb2/d;->a:Lz0/c0;
    .line 63: invoke-static {v3, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V
    .line 66: iget-object v5, v0, Lb2/e;->d:Ljava/util/List;
    .line 68: if-eqz v5, :cond_71
    .line 70: goto :goto_75
    .line 71: invoke-static {v2, v7}, Ld2/c;->t0(Landroid/content/res/Resources;I)Ljava/util/List;
    .line 74: move-result-object v5
    .line 75: move v2, v7
    .line 76: invoke-interface {v5}, Ljava/util/List;->size()I
    .line 79: move-result v8
    .line 80: const/4 v9, 0
    .line 81: if-ge v2, v8, :cond_139
    .line 83: new-instance v8, Ljava/util/ArrayList;
    .line 85: invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 88: move-result-object v10
    .line 89: check-cast v10, Ljava/util/Collection;
    .line 91: invoke-direct {v8, v10}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 94: invoke-static {v8, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V
    .line 97: invoke-virtual {v3}, Ljava/util/ArrayList;->size()I
    .line 100: move-result v10
    .line 101: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 104: move-result v11
    .line 105: if-eq v10, v11, :cond_108
    .line 107: goto :goto_133
    .line 108: move v10, v7
    .line 109: invoke-virtual {v3}, Ljava/util/ArrayList;->size()I
    .line 112: move-result v11
    .line 113: if-ge v10, v11, :cond_140
    .line 115: invoke-virtual {v3, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 118: move-result-object v11
    .line 119: check-cast v11, [B
    .line 121: invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 124: move-result-object v12
    .line 125: check-cast v12, [B
    .line 127: invoke-static {v11, v12}, Ljava/util/Arrays;->equals([B[B)Z
    .line 130: move-result v11
    .line 131: if-nez v11, :cond_136
    .line 133: add-int/lit8 v2, v2, 1
    .line 135: goto :goto_76
    .line 136: add-int/lit8 v10, v10, 1
    .line 138: goto :goto_109
    .line 139: move-object v4, v9
    .line 140: const/4 v8, 1
    .line 141: if-nez v4, :cond_153
    .line 143: new-instance v0, Lh/t1;
    .line 145: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 148: iput v8, v0, Lh/t1;->a:I
    .line 150: iput-object v9, v0, Lh/t1;->b:Ljava/lang/Object;
    .line 152: return-object v0
    .line 153: iget-object v1, v4, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;
    .line 155: const-string v10, "result_code"
    .line 157: const-string v11, "font_italic"
    .line 159: const-string v12, "font_weight"
    .line 161: const-string v13, "font_ttc_index"
    .line 163: const-string v14, "file_id"
    .line 165: const-string v15, "_id"
    .line 167: new-instance v16, Ljava/util/ArrayList;
    .line 169: invoke-direct/range {v16 .. v16}, Ljava/util/ArrayList;-><init>()V
    .line 172: new-instance v2, Landroid/net/Uri$Builder;
    .line 174: invoke-direct {v2}, Landroid/net/Uri$Builder;-><init>()V
    .line 177: const-string v3, "content"
    .line 179: invoke-virtual {v2, v3}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 182: move-result-object v2
    .line 183: invoke-virtual {v2, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 186: move-result-object v2
    .line 187: invoke-virtual {v2}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
    .line 190: move-result-object v5
    .line 191: new-instance v2, Landroid/net/Uri$Builder;
    .line 193: invoke-direct {v2}, Landroid/net/Uri$Builder;-><init>()V
    .line 196: invoke-virtual {v2, v3}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 199: move-result-object v2
    .line 200: invoke-virtual {v2, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 203: move-result-object v1
    .line 204: const-string v2, "file"
    .line 206: invoke-virtual {v1, v2}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 209: move-result-object v1
    .line 210: invoke-virtual {v1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
    .line 213: move-result-object v4
    .line 214: const/4 v1, 7
    .line 215: new-array v2, v1, [Ljava/lang/String;
    .line 217: aput-object v15, v2, v7
    .line 219: aput-object v14, v2, v8
    .line 221: const/4 v1, 2
    .line 222: aput-object v13, v2, v1
    .line 224: const-string v1, "font_variation_settings"
    .line 226: const/4 v3, 3
    .line 227: aput-object v1, v2, v3
    .line 229: const/4 v1, 4
    .line 230: aput-object v12, v2, v1
    .line 232: const/4 v1, 5
    .line 233: aput-object v11, v2, v1
    .line 235: const/4 v1, 6
    .line 236: aput-object v10, v2, v1
    .line 238: invoke-virtual/range {v19 .. v19}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    .line 241: move-result-object v1
    .line 242: const-string v3, "query = ?"
    .line 244: new-array v9, v8, [Ljava/lang/String;
    .line 246: iget-object v0, v0, Lb2/e;->c:Ljava/lang/String;
    .line 248: aput-object v0, v9, v7
    .line 250: const/16 v18, 0
    .line 252: move-object v0, v1
    .line 253: move-object v1, v5
    .line 254: move-object v7, v4
    .line 255: move-object v4, v9
    .line 256: move-object v9, v5
    .line 257: move-object/from16 v5, v18
    .line 259: invoke-static/range {v0 .. v6}, Lb2/c;->a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;
    .line 262: move-result-object v1
    .line 263: if-eqz v1, :cond_386
    .line 265: invoke-interface {v1}, Landroid/database/Cursor;->getCount()I
    .line 268: move-result v0
    .line 269: if-lez v0, :cond_386
    .line 271: invoke-interface {v1, v10}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    .line 274: move-result v0
    .line 275: new-instance v2, Ljava/util/ArrayList;
    .line 277: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 280: invoke-interface {v1, v15}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    .line 283: move-result v3
    .line 284: invoke-interface {v1, v14}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    .line 287: move-result v4
    .line 288: invoke-interface {v1, v13}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    .line 291: move-result v5
    .line 292: invoke-interface {v1, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    .line 295: move-result v6
    .line 296: invoke-interface {v1, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    .line 299: move-result v10
    .line 300: invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z
    .line 303: move-result v11
    .line 304: if-eqz v11, :cond_388
    .line 306: const/4 v11, -1
    .line 307: if-eq v0, v11, :cond_319
    .line 309: invoke-interface {v1, v0}, Landroid/database/Cursor;->getInt(I)I
    .line 312: move-result v12
    .line 313: move/from16 v18, v12
    .line 315: goto :goto_321
    .line 316: move-exception v0
    .line 317: move-object v9, v1
    .line 318: goto :goto_414
    .line 319: const/16 v18, 0
    .line 321: if-eq v5, v11, :cond_329
    .line 323: invoke-interface {v1, v5}, Landroid/database/Cursor;->getInt(I)I
    .line 326: move-result v12
    .line 327: move v15, v12
    .line 328: goto :goto_330
    .line 329: const/4 v15, 0
    .line 330: if-ne v4, v11, :cond_342
    .line 332: invoke-interface {v1, v3}, Landroid/database/Cursor;->getLong(I)J
    .line 335: move-result-wide v12
    .line 336: invoke-static {v9, v12, v13}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;
    .line 339: move-result-object v12
    .line 340: move-object v14, v12
    .line 341: goto :goto_351
    .line 342: invoke-interface {v1, v4}, Landroid/database/Cursor;->getLong(I)J
    .line 345: move-result-wide v12
    .line 346: invoke-static {v7, v12, v13}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;
    .line 349: move-result-object v12
    .line 350: goto :goto_340
    .line 351: if-eq v6, v11, :cond_360
    .line 353: invoke-interface {v1, v6}, Landroid/database/Cursor;->getInt(I)I
    .line 356: move-result v12
    .line 357: move/from16 v16, v12
    .line 359: goto :goto_363
    .line 360: const/16 v12, 400
    .line 362: goto :goto_357
    .line 363: if-eq v10, v11, :cond_374
    .line 365: invoke-interface {v1, v10}, Landroid/database/Cursor;->getInt(I)I
    .line 368: move-result v11
    .line 369: if-ne v11, v8, :cond_374
    .line 371: move/from16 v17, v8
    .line 373: goto :goto_376
    .line 374: const/16 v17, 0
    .line 376: new-instance v11, Lb2/i;
    .line 378: move-object v13, v11
    .line 379: invoke-direct/range {v13 .. v18}, Lb2/i;-><init>(Landroid/net/Uri;IIZI)V
    .line 382: invoke-virtual {v2, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 385: goto :goto_300
    .line 386: move-object/from16 v2, v16
    .line 388: if-eqz v1, :cond_393
    .line 390: invoke-interface {v1}, Landroid/database/Cursor;->close()V
    .line 393: const/4 v0, 0
    .line 394: new-array v1, v0, [Lb2/i;
    .line 396: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 399: move-result-object v1
    .line 400: check-cast v1, [Lb2/i;
    .line 402: new-instance v2, Lh/t1;
    .line 404: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 407: iput v0, v2, Lh/t1;->a:I
    .line 409: iput-object v1, v2, Lh/t1;->b:Ljava/lang/Object;
    .line 411: return-object v2
    .line 412: move-exception v0
    .line 413: const/4 v9, 0
    .line 414: if-eqz v9, :cond_419
    .line 416: invoke-interface {v9}, Landroid/database/Cursor;->close()V
    .line 419: throw v0
    .line 420: new-instance v0, Landroid/content/pm/PackageManager$NameNotFoundException;
    .line 422: new-instance v1, Ljava/lang/StringBuilder;
    .line 424: const-string v2, "Found content provider "
    .line 426: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 429: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 432: const-string v2, ", but package was not "
    .line 434: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 437: invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 440: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 443: move-result-object v1
    .line 444: invoke-direct {v0, v1}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>(Ljava/lang/String;)V
    .line 447: throw v0
    .line 448: new-instance v0, Landroid/content/pm/PackageManager$NameNotFoundException;
    .line 450: new-instance v1, Ljava/lang/StringBuilder;
    .line 452: const-string v2, "No package found for authority: "
    .line 454: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 457: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 460: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 463: move-result-object v1
    .line 464: invoke-direct {v0, v1}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>(Ljava/lang/String;)V
    .line 467: throw v0
.end method

.class public final Lb2/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroid/graphics/Typeface;
.field public final b:I

# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-object v0, v1, Lb2/g;->a:Landroid/graphics/Typeface;
    .line 6: iput v2, v1, Lb2/g;->b:I
    .line 8: return-void
.end method

# direct methods
.method public constructor <init>(Landroid/graphics/Typeface;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lb2/g;->a:Landroid/graphics/Typeface;
    .line 5: const/4 v1, 0
    .line 6: iput v1, v0, Lb2/g;->b:I
    .line 8: return-void
.end method

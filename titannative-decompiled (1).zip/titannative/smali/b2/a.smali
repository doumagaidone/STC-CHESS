.class public final Lb2/a;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final j:Ljava/lang/Object;
.field public final k:Ljava/lang/Object;
.field public final l:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v4, v0, Lb2/a;->i:I
    .line 5: iput-object v1, v0, Lb2/a;->l:Ljava/lang/Object;
    .line 7: iput-object v2, v0, Lb2/a;->j:Ljava/lang/Object;
    .line 9: iput-object v3, v0, Lb2/a;->k:Ljava/lang/Object;
    .line 11: return-void
.end method

# virtual methods
.method public final run()V
    .registers 6

    .line 0: iget-object v0, v5, Lb2/a;->k:Ljava/lang/Object;
    .line 2: iget-object v1, v5, Lb2/a;->j:Ljava/lang/Object;
    .line 4: iget v2, v5, Lb2/a;->i:I
    .line 6: packed-switch v2, :data_50
    .line 9: check-cast v1, Ljava/util/concurrent/Callable;
    .line 11: invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;
    .line 14: move-result-object v1
    .line 15: goto :goto_17
    .line 16: const/4 v1, 0
    .line 17: check-cast v0, Ld2/a;
    .line 19: iget-object v2, v5, Lb2/a;->l:Ljava/lang/Object;
    .line 21: check-cast v2, Landroid/os/Handler;
    .line 23: new-instance v3, Lb2/a;
    .line 25: const/4 v4, 1
    .line 26: invoke-direct {v3, v5, v0, v1, v4}, Lb2/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .line 29: invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 32: return-void
    .line 33: check-cast v1, Ld2/a;
    .line 35: check-cast v1, Lb2/f;
    .line 37: invoke-virtual {v1, v0}, Lb2/f;->a(Ljava/lang/Object;)V
    .line 40: return-void
    .line 41: check-cast v1, Lu/d;
    .line 43: iget-object v0, v1, Lu/d;->b:Ljava/lang/Object;
    .line 45: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 48: return-void
    .line 49: nop
    .line 50: nop
    .line 51: move/from16 v0, v0
    .line 53: nop
    .line 54: new-array v0, v0, B
    .line 56: const-string/jumbo v0, "string@589824"
.end method

.class public abstract Lb2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;
    .registers 14

    .line 0: move-object v6, v13
    .line 1: check-cast v6, Landroid/os/CancellationSignal;
    .line 3: move-object v0, v7
    .line 4: move-object v1, v8
    .line 5: move-object v2, v9
    .line 6: move-object v3, v10
    .line 7: move-object v4, v11
    .line 8: move-object v5, v12
    .line 9: invoke-virtual/range {v0 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;
    .line 12: move-result-object v7
    .line 13: return-object v7
.end method

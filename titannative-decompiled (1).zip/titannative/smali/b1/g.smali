.class public abstract Lb1/g;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/View;)Landroid/view/contentcapture/ContentCaptureSession;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->getContentCaptureSession()Landroid/view/contentcapture/ContentCaptureSession;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

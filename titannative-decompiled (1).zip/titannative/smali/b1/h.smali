.class public abstract Lb1/h;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/View;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setImportantForContentCapture(I)V
    .line 3: return-void
.end method

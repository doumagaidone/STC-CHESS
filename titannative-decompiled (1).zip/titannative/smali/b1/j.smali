.class public final Lb1/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroid/view/ViewStructure;

# direct methods
.method public constructor <init>(Landroid/view/ViewStructure;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lb1/j;->a:Landroid/view/ViewStructure;
    .line 5: return-void
.end method

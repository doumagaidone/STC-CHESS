.class public abstract Lb1/i;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/ViewStructure;Ljava/lang/String;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setClassName(Ljava/lang/String;)V
    .line 3: return-void
.end method

# direct methods
.method public static b(Landroid/view/ViewStructure;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setContentDescription(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

# direct methods
.method public static c(Landroid/view/ViewStructure;IIIIII)V
    .registers 7

    .line 0: invoke-virtual/range {v0 .. v6}, Landroid/view/ViewStructure;->setDimens(IIIIII)V
    .line 3: return-void
.end method

# direct methods
.method public static d(Landroid/view/ViewStructure;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setText(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

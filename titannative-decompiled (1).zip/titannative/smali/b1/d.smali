.class public final synthetic Lb1/d;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/WindowInsetsController$OnControllableInsetsChangedListener;

.field public final synthetic a:Ljava/util/concurrent/atomic/AtomicBoolean;

# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lb1/d;->a:Ljava/util/concurrent/atomic/AtomicBoolean;
    .line 5: return-void
.end method

# virtual methods
.method public final onControllableInsetsChanged(Landroid/view/WindowInsetsController;I)V
    .registers 3

    .line 0: iget-object v1, v0, Lb1/d;->a:Ljava/util/concurrent/atomic/AtomicBoolean;
    .line 2: and-int/lit8 v2, v2, 8
    .line 4: if-eqz v2, :cond_8
    .line 6: const/4 v2, 1
    .line 7: goto :goto_9
    .line 8: const/4 v2, 0
    .line 9: invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    .line 12: return-void
.end method

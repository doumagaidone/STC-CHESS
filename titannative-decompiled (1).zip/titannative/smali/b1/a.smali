.class public final Lb1/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .registers 2

    .line 0: iput-object v1, v0, Lb1/a;->a:Ljava/lang/Object;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: return-void
.end method

.class public abstract annotation interface Landroidx/annotation/Keep;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/annotation/Annotation;

.class public final Landroidx/emoji2/text/s;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:I
.field public final b:Landroidx/emoji2/text/w;
.field public c:Landroidx/emoji2/text/w;
.field public d:Landroidx/emoji2/text/w;
.field public e:I
.field public f:I
.field public final g:Z
.field public final h:[I

# direct methods
.method public constructor <init>(Landroidx/emoji2/text/w;Z[I)V
    .registers 5

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 1
    .line 4: iput v0, v1, Landroidx/emoji2/text/s;->a:I
    .line 6: iput-object v2, v1, Landroidx/emoji2/text/s;->b:Landroidx/emoji2/text/w;
    .line 8: iput-object v2, v1, Landroidx/emoji2/text/s;->c:Landroidx/emoji2/text/w;
    .line 10: iput-boolean v3, v1, Landroidx/emoji2/text/s;->g:Z
    .line 12: iput-object v4, v1, Landroidx/emoji2/text/s;->h:[I
    .line 14: return-void
.end method

# virtual methods
.method public final a()V
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: iput v0, v1, Landroidx/emoji2/text/s;->a:I
    .line 3: iget-object v0, v1, Landroidx/emoji2/text/s;->b:Landroidx/emoji2/text/w;
    .line 5: iput-object v0, v1, Landroidx/emoji2/text/s;->c:Landroidx/emoji2/text/w;
    .line 7: const/4 v0, 0
    .line 8: iput v0, v1, Landroidx/emoji2/text/s;->f:I
    .line 10: return-void
.end method

# virtual methods
.method public final b()Z
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/emoji2/text/s;->c:Landroidx/emoji2/text/w;
    .line 2: iget-object v0, v0, Landroidx/emoji2/text/w;->b:Landroidx/emoji2/text/y;
    .line 4: invoke-virtual {v0}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 7: move-result-object v0
    .line 8: const/4 v1, 6
    .line 9: invoke-virtual {v0, v1}, Li2/c;->a(I)I
    .line 12: move-result v1
    .line 13: const/4 v2, 1
    .line 14: if-eqz v1, :cond_28
    .line 16: iget-object v3, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 18: iget v0, v0, Li2/c;->a:I
    .line 20: add-int/2addr v1, v0
    .line 21: invoke-virtual {v3, v1}, Ljava/nio/ByteBuffer;->get(I)B
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_28
    .line 27: return v2
    .line 28: iget v0, v4, Landroidx/emoji2/text/s;->e:I
    .line 30: const v1, 0xfe0f
    .line 33: if-ne v0, v1, :cond_36
    .line 35: return v2
    .line 36: iget-boolean v0, v4, Landroidx/emoji2/text/s;->g:Z
    .line 38: const/4 v1, 0
    .line 39: if-eqz v0, :cond_61
    .line 41: iget-object v0, v4, Landroidx/emoji2/text/s;->h:[I
    .line 43: if-nez v0, :cond_46
    .line 45: return v2
    .line 46: iget-object v3, v4, Landroidx/emoji2/text/s;->c:Landroidx/emoji2/text/w;
    .line 48: iget-object v3, v3, Landroidx/emoji2/text/w;->b:Landroidx/emoji2/text/y;
    .line 50: invoke-virtual {v3, v1}, Landroidx/emoji2/text/y;->a(I)I
    .line 53: move-result v3
    .line 54: invoke-static {v0, v3}, Ljava/util/Arrays;->binarySearch([II)I
    .line 57: move-result v0
    .line 58: if-gez v0, :cond_61
    .line 60: return v2
    .line 61: return v1
.end method

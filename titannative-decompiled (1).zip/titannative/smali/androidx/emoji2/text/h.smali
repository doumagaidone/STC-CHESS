.class public abstract Landroidx/emoji2/text/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroidx/emoji2/text/j;
.field public b:I
.field public final c:Landroidx/emoji2/text/e;

# direct methods
.method public constructor <init>(Landroidx/emoji2/text/j;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput v0, v1, Landroidx/emoji2/text/h;->b:I
    .line 6: new-instance v0, Landroidx/emoji2/text/e;
    .line 8: invoke-direct {v0}, Landroidx/emoji2/text/e;-><init>()V
    .line 11: iput-object v0, v1, Landroidx/emoji2/text/h;->c:Landroidx/emoji2/text/e;
    .line 13: iput-object v2, v1, Landroidx/emoji2/text/h;->a:Landroidx/emoji2/text/j;
    .line 15: return-void
.end method

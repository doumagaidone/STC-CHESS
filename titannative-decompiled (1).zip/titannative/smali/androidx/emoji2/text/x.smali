.class public final Landroidx/emoji2/text/x;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Li2/b;
.field public final b:[C
.field public final c:Landroidx/emoji2/text/w;
.field public final d:Landroid/graphics/Typeface;

# direct methods
.method public constructor <init>(Landroid/graphics/Typeface;Li2/b;)V
    .registers 8

    .line 0: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v6, v5, Landroidx/emoji2/text/x;->d:Landroid/graphics/Typeface;
    .line 5: iput-object v7, v5, Landroidx/emoji2/text/x;->a:Li2/b;
    .line 7: new-instance v6, Landroidx/emoji2/text/w;
    .line 9: const/16 v0, 1024
    .line 11: invoke-direct {v6, v0}, Landroidx/emoji2/text/w;-><init>(I)V
    .line 14: iput-object v6, v5, Landroidx/emoji2/text/x;->c:Landroidx/emoji2/text/w;
    .line 16: const/4 v6, 6
    .line 17: invoke-virtual {v7, v6}, Li2/c;->a(I)I
    .line 20: move-result v0
    .line 21: const/4 v1, 0
    .line 22: if-eqz v0, :cond_41
    .line 24: iget v2, v7, Li2/c;->a:I
    .line 26: add-int/2addr v0, v2
    .line 27: iget-object v2, v7, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 29: invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 32: move-result v2
    .line 33: add-int/2addr v2, v0
    .line 34: iget-object v0, v7, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 36: invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 39: move-result v0
    .line 40: goto :goto_42
    .line 41: move v0, v1
    .line 42: mul-int/lit8 v0, v0, 2
    .line 44: new-array v0, v0, [C
    .line 46: iput-object v0, v5, Landroidx/emoji2/text/x;->b:[C
    .line 48: invoke-virtual {v7, v6}, Li2/c;->a(I)I
    .line 51: move-result v6
    .line 52: if-eqz v6, :cond_71
    .line 54: iget v0, v7, Li2/c;->a:I
    .line 56: add-int/2addr v6, v0
    .line 57: iget-object v0, v7, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 59: invoke-virtual {v0, v6}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 62: move-result v0
    .line 63: add-int/2addr v0, v6
    .line 64: iget-object v6, v7, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 66: invoke-virtual {v6, v0}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 69: move-result v6
    .line 70: goto :goto_72
    .line 71: move v6, v1
    .line 72: move v7, v1
    .line 73: if-ge v7, v6, :cond_142
    .line 75: new-instance v0, Landroidx/emoji2/text/y;
    .line 77: invoke-direct {v0, v5, v7}, Landroidx/emoji2/text/y;-><init>(Landroidx/emoji2/text/x;I)V
    .line 80: invoke-virtual {v0}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 83: move-result-object v2
    .line 84: const/4 v3, 4
    .line 85: invoke-virtual {v2, v3}, Li2/c;->a(I)I
    .line 88: move-result v3
    .line 89: if-eqz v3, :cond_101
    .line 91: iget-object v4, v2, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 93: iget v2, v2, Li2/c;->a:I
    .line 95: add-int/2addr v3, v2
    .line 96: invoke-virtual {v4, v3}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 99: move-result v2
    .line 100: goto :goto_102
    .line 101: move v2, v1
    .line 102: mul-int/lit8 v3, v7, 2
    .line 104: iget-object v4, v5, Landroidx/emoji2/text/x;->b:[C
    .line 106: invoke-static {v2, v4, v3}, Ljava/lang/Character;->toChars(I[CI)I
    .line 109: invoke-virtual {v0}, Landroidx/emoji2/text/y;->b()I
    .line 112: move-result v2
    .line 113: const/4 v3, 1
    .line 114: if-lez v2, :cond_118
    .line 116: move v2, v3
    .line 117: goto :goto_119
    .line 118: move v2, v1
    .line 119: if-eqz v2, :cond_134
    .line 121: invoke-virtual {v0}, Landroidx/emoji2/text/y;->b()I
    .line 124: move-result v2
    .line 125: sub-int/2addr v2, v3
    .line 126: iget-object v3, v5, Landroidx/emoji2/text/x;->c:Landroidx/emoji2/text/w;
    .line 128: invoke-virtual {v3, v0, v1, v2}, Landroidx/emoji2/text/w;->a(Landroidx/emoji2/text/y;II)V
    .line 131: add-int/lit8 v7, v7, 1
    .line 133: goto :goto_73
    .line 134: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 136: const-string v7, "invalid metadata codepoint length"
    .line 138: invoke-direct {v6, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 141: throw v6
    .line 142: return-void
.end method

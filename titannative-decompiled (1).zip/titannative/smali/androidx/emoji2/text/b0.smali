.class public final Landroidx/emoji2/text/b0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/text/Spannable;

.field public a:Z
.field public b:Landroid/text/Spannable;

# direct methods
.method public constructor <init>(Landroid/text/Spannable;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput-boolean v0, v1, Landroidx/emoji2/text/b0;->a:Z
    .line 6: iput-object v2, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 8: return-void
.end method

# virtual methods
.method public final a()V
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: iget-boolean v1, v4, Landroidx/emoji2/text/b0;->a:Z
    .line 4: if-nez v1, :cond_38
    .line 6: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 8: const/16 v2, 28
    .line 10: const/16 v3, 20
    .line 12: if-ge v1, v2, :cond_20
    .line 14: new-instance v1, Lz3/b;
    .line 16: invoke-direct {v1, v3}, Lz3/b;-><init>(I)V
    .line 19: goto :goto_25
    .line 20: new-instance v1, Landroidx/emoji2/text/a0;
    .line 22: invoke-direct {v1, v3}, Lz3/b;-><init>(I)V
    .line 25: invoke-virtual {v1, v0}, Lz3/b;->w(Landroid/text/Spannable;)Z
    .line 28: move-result v1
    .line 29: if-eqz v1, :cond_38
    .line 31: new-instance v1, Landroid/text/SpannableString;
    .line 33: invoke-direct {v1, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V
    .line 36: iput-object v1, v4, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 38: const/4 v0, 1
    .line 39: iput-boolean v0, v4, Landroidx/emoji2/text/b0;->a:Z
    .line 41: return-void
.end method

# virtual methods
.method public final charAt(I)C
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2}, Ljava/lang/CharSequence;->charAt(I)C
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final chars()Ljava/util/stream/IntStream;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0}, Ljava/lang/CharSequence;->chars()Ljava/util/stream/IntStream;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public final codePoints()Ljava/util/stream/IntStream;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0}, Ljava/lang/CharSequence;->codePoints()Ljava/util/stream/IntStream;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public final getSpanEnd(Ljava/lang/Object;)I
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final getSpanFlags(Ljava/lang/Object;)I
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final getSpanStart(Ljava/lang/Object;)I
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .registers 5

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2, v3, v4}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# virtual methods
.method public final length()I
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0}, Ljava/lang/CharSequence;->length()I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final nextSpanTransition(IILjava/lang/Class;)I
    .registers 5

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2, v3, v4}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final removeSpan(Ljava/lang/Object;)V
    .registers 3

    .line 0: invoke-virtual {v1}, Landroidx/emoji2/text/b0;->a()V
    .line 3: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 5: invoke-interface {v0, v2}, Landroid/text/Spannable;->removeSpan(Ljava/lang/Object;)V
    .line 8: return-void
.end method

# virtual methods
.method public final setSpan(Ljava/lang/Object;III)V
    .registers 6

    .line 0: invoke-virtual {v1}, Landroidx/emoji2/text/b0;->a()V
    .line 3: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 5: invoke-interface {v0, v2, v3, v4, v5}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V
    .line 8: return-void
.end method

# virtual methods
.method public final subSequence(II)Ljava/lang/CharSequence;
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-interface {v0, v2, v3}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/emoji2/text/b0;->b:Landroid/text/Spannable;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

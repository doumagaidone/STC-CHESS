.class public abstract interface Landroidx/emoji2/text/j;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract b(Ld2/c;)V
.end method

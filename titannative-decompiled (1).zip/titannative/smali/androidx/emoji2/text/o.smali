.class public abstract Landroidx/emoji2/text/o;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a()Ljava/util/Set;
    .registers 1

    .line 0: invoke-static {}, Ld2/b;->o0()Ljava/util/Set;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

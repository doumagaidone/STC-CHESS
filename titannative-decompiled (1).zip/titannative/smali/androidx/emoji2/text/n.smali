.class public final Landroidx/emoji2/text/n;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

# virtual methods
.method public final run()V
    .registers 3

    .line 0: const-string v0, "EmojiCompat.EmojiCompatInitializer.run"
    .line 2: sget v1, La2/d;->a:I
    .line 4: invoke-static {v0}, La2/c;->a(Ljava/lang/String;)V
    .line 7: invoke-static {}, Landroidx/emoji2/text/k;->c()Z
    .line 10: move-result v0
    .line 11: if-eqz v0, :cond_23
    .line 13: invoke-static {}, Landroidx/emoji2/text/k;->a()Landroidx/emoji2/text/k;
    .line 16: move-result-object v0
    .line 17: invoke-virtual {v0}, Landroidx/emoji2/text/k;->d()V
    .line 20: goto :goto_23
    .line 21: move-exception v0
    .line 22: goto :goto_27
    .line 23: invoke-static {}, La2/c;->b()V
    .line 26: return-void
    .line 27: sget v1, La2/d;->a:I
    .line 29: invoke-static {}, La2/c;->b()V
    .line 32: throw v0
.end method

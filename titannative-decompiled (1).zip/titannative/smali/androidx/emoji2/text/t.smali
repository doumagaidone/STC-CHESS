.class public final synthetic Landroidx/emoji2/text/t;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final synthetic j:Landroidx/emoji2/text/u;

# direct methods
.method public synthetic constructor <init>(Landroidx/emoji2/text/u;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v2, v0, Landroidx/emoji2/text/t;->i:I
    .line 5: iput-object v1, v0, Landroidx/emoji2/text/t;->j:Landroidx/emoji2/text/u;
    .line 7: return-void
.end method

# virtual methods
.method public final run()V
    .registers 7

    .line 0: iget v0, v6, Landroidx/emoji2/text/t;->i:I
    .line 2: packed-switch v0, :data_196
    .line 5: iget-object v0, v6, Landroidx/emoji2/text/t;->j:Landroidx/emoji2/text/u;
    .line 7: invoke-virtual {v0}, Landroidx/emoji2/text/u;->c()V
    .line 10: return-void
    .line 11: iget-object v0, v6, Landroidx/emoji2/text/t;->j:Landroidx/emoji2/text/u;
    .line 13: const-string v1, "fetchFonts result is not OK. ("
    .line 15: iget-object v2, v0, Landroidx/emoji2/text/u;->d:Ljava/lang/Object;
    .line 17: monitor-enter v2
    .line 18: iget-object v3, v0, Landroidx/emoji2/text/u;->h:Ld2/c;
    .line 20: if-nez v3, :cond_28
    .line 22: monitor-exit v2
    .line 23: goto/16 :goto_190
    .line 25: move-exception v0
    .line 26: goto/16 :goto_193
    .line 28: monitor-exit v2
    .line 29: invoke-virtual {v0}, Landroidx/emoji2/text/u;->d()Lb2/i;
    .line 32: move-result-object v2
    .line 33: iget v3, v2, Lb2/i;->e:I
    .line 35: const/4 v4, 2
    .line 36: if-ne v3, v4, :cond_49
    .line 38: iget-object v4, v0, Landroidx/emoji2/text/u;->d:Ljava/lang/Object;
    .line 40: monitor-enter v4
    .line 41: monitor-exit v4
    .line 42: goto :goto_49
    .line 43: move-exception v1
    .line 44: monitor-exit v4
    .line 45: throw v1
    .line 46: move-exception v1
    .line 47: goto/16 :goto_173
    .line 49: if-nez v3, :cond_150
    .line 51: const-string v1, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"
    .line 53: sget v3, La2/d;->a:I
    .line 55: invoke-static {v1}, La2/c;->a(Ljava/lang/String;)V
    .line 58: iget-object v1, v0, Landroidx/emoji2/text/u;->c:Lz3/b;
    .line 60: iget-object v3, v0, Landroidx/emoji2/text/u;->a:Landroid/content/Context;
    .line 62: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 65: filled-new-array {v2}, [Lb2/i;
    .line 68: move-result-object v1
    .line 69: sget-object v4, Ly1/d;->a:Lu/d;
    .line 71: const/4 v5, 0
    .line 72: invoke-virtual {v4, v3, v1, v5}, Lu/d;->h(Landroid/content/Context;[Lb2/i;I)Landroid/graphics/Typeface;
    .line 75: move-result-object v1
    .line 76: iget-object v3, v0, Landroidx/emoji2/text/u;->a:Landroid/content/Context;
    .line 78: iget-object v2, v2, Lb2/i;->a:Landroid/net/Uri;
    .line 80: invoke-static {v3, v2}, Ld2/b;->K0(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;
    .line 83: move-result-object v2
    .line 84: if-eqz v2, :cond_135
    .line 86: if-eqz v1, :cond_135
    .line 88: const-string v3, "EmojiCompat.MetadataRepo.create"
    .line 90: invoke-static {v3}, La2/c;->a(Ljava/lang/String;)V
    .line 93: new-instance v3, Landroidx/emoji2/text/x;
    .line 95: invoke-static {v2}, Ld2/b;->Q0(Ljava/nio/MappedByteBuffer;)Li2/b;
    .line 98: move-result-object v2
    .line 99: invoke-direct {v3, v1, v2}, Landroidx/emoji2/text/x;-><init>(Landroid/graphics/Typeface;Li2/b;)V
    .line 102: invoke-static {}, La2/c;->b()V
    .line 105: invoke-static {}, La2/c;->b()V
    .line 108: iget-object v1, v0, Landroidx/emoji2/text/u;->d:Ljava/lang/Object;
    .line 110: monitor-enter v1
    .line 111: iget-object v2, v0, Landroidx/emoji2/text/u;->h:Ld2/c;
    .line 113: if-eqz v2, :cond_121
    .line 115: invoke-virtual {v2, v3}, Ld2/c;->l0(Landroidx/emoji2/text/x;)V
    .line 118: goto :goto_121
    .line 119: move-exception v2
    .line 120: goto :goto_126
    .line 121: monitor-exit v1
    .line 122: invoke-virtual {v0}, Landroidx/emoji2/text/u;->a()V
    .line 125: goto :goto_190
    .line 126: monitor-exit v1
    .line 127: throw v2
    .line 128: move-exception v1
    .line 129: sget v2, La2/d;->a:I
    .line 131: invoke-static {}, La2/c;->b()V
    .line 134: throw v1
    .line 135: new-instance v1, Ljava/lang/RuntimeException;
    .line 137: const-string v2, "Unable to open file."
    .line 139: invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 142: throw v1
    .line 143: move-exception v1
    .line 144: sget v2, La2/d;->a:I
    .line 146: invoke-static {}, La2/c;->b()V
    .line 149: throw v1
    .line 150: new-instance v2, Ljava/lang/RuntimeException;
    .line 152: new-instance v4, Ljava/lang/StringBuilder;
    .line 154: invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 157: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 160: const-string v1, ")"
    .line 162: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 165: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 168: move-result-object v1
    .line 169: invoke-direct {v2, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 172: throw v2
    .line 173: iget-object v3, v0, Landroidx/emoji2/text/u;->d:Ljava/lang/Object;
    .line 175: monitor-enter v3
    .line 176: iget-object v2, v0, Landroidx/emoji2/text/u;->h:Ld2/c;
    .line 178: if-eqz v2, :cond_186
    .line 180: invoke-virtual {v2, v1}, Ld2/c;->k0(Ljava/lang/Throwable;)V
    .line 183: goto :goto_186
    .line 184: move-exception v0
    .line 185: goto :goto_191
    .line 186: monitor-exit v3
    .line 187: invoke-virtual {v0}, Landroidx/emoji2/text/u;->a()V
    .line 190: return-void
    .line 191: monitor-exit v3
    .line 192: throw v0
    .line 193: monitor-exit v2
    .line 194: throw v0
    .line 195: nop
    .line 196: nop
    .line 197: move v0, v0
    .line 198: nop
    .line 199: nop
    .line 200: move-object/16 v0, v18
.end method

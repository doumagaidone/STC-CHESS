.class public final Landroidx/emoji2/text/k;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final j:Ljava/lang/Object;
.field public static volatile k:Landroidx/emoji2/text/k;

.field public final a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
.field public final b:Lf/c;
.field public volatile c:I
.field public final d:Landroid/os/Handler;
.field public final e:Landroidx/emoji2/text/g;
.field public final f:Landroidx/emoji2/text/j;
.field public final g:Lz3/b;
.field public final h:I
.field public final i:Landroidx/emoji2/text/e;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/Object;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/emoji2/text/k;->j:Ljava/lang/Object;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(Landroidx/emoji2/text/v;)V
    .registers 5

    .line 0: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 5: invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V
    .line 8: iput-object v0, v3, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 10: const/4 v1, 3
    .line 11: iput v1, v3, Landroidx/emoji2/text/k;->c:I
    .line 13: iget-object v1, v4, Landroidx/emoji2/text/h;->a:Landroidx/emoji2/text/j;
    .line 15: iput-object v1, v3, Landroidx/emoji2/text/k;->f:Landroidx/emoji2/text/j;
    .line 17: iget v1, v4, Landroidx/emoji2/text/h;->b:I
    .line 19: iput v1, v3, Landroidx/emoji2/text/k;->h:I
    .line 21: iget-object v4, v4, Landroidx/emoji2/text/h;->c:Landroidx/emoji2/text/e;
    .line 23: iput-object v4, v3, Landroidx/emoji2/text/k;->i:Landroidx/emoji2/text/e;
    .line 25: new-instance v4, Landroid/os/Handler;
    .line 27: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    .line 30: move-result-object v2
    .line 31: invoke-direct {v4, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    .line 34: iput-object v4, v3, Landroidx/emoji2/text/k;->d:Landroid/os/Handler;
    .line 36: new-instance v4, Lf/c;
    .line 38: invoke-direct {v4}, Lf/c;-><init>()V
    .line 41: iput-object v4, v3, Landroidx/emoji2/text/k;->b:Lf/c;
    .line 43: new-instance v4, Lz3/b;
    .line 45: const/16 v2, 18
    .line 47: invoke-direct {v4, v2}, Lz3/b;-><init>(I)V
    .line 50: iput-object v4, v3, Landroidx/emoji2/text/k;->g:Lz3/b;
    .line 52: new-instance v4, Landroidx/emoji2/text/g;
    .line 54: const/16 v2, 11
    .line 56: invoke-direct {v4, v2, v3}, Lu/d;-><init>(ILjava/lang/Object;)V
    .line 59: iput-object v4, v3, Landroidx/emoji2/text/k;->e:Landroidx/emoji2/text/g;
    .line 61: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 64: move-result-object v2
    .line 65: invoke-interface {v2}, Ljava/util/concurrent/locks/Lock;->lock()V
    .line 68: if-nez v1, :cond_85
    .line 70: const/4 v1, 0
    .line 71: iput v1, v3, Landroidx/emoji2/text/k;->c:I
    .line 73: goto :goto_85
    .line 74: move-exception v4
    .line 75: iget-object v0, v3, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 77: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 80: move-result-object v0
    .line 81: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 84: throw v4
    .line 85: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 88: move-result-object v0
    .line 89: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 92: invoke-virtual {v3}, Landroidx/emoji2/text/k;->b()I
    .line 95: move-result v0
    .line 96: if-nez v0, :cond_101
    .line 98: invoke-virtual {v4}, Landroidx/emoji2/text/g;->v()V
    .line 101: return-void
.end method

# direct methods
.method public static a()Landroidx/emoji2/text/k;
    .registers 4

    .line 0: sget-object v0, Landroidx/emoji2/text/k;->j:Ljava/lang/Object;
    .line 2: monitor-enter v0
    .line 3: sget-object v1, Landroidx/emoji2/text/k;->k:Landroidx/emoji2/text/k;
    .line 5: if-eqz v1, :cond_9
    .line 7: const/4 v2, 1
    .line 8: goto :goto_10
    .line 9: const/4 v2, 0
    .line 10: const-string v3, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message."
    .line 12: if-eqz v2, :cond_18
    .line 14: monitor-exit v0
    .line 15: return-object v1
    .line 16: move-exception v1
    .line 17: goto :goto_24
    .line 18: new-instance v1, Ljava/lang/IllegalStateException;
    .line 20: invoke-direct {v1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 23: throw v1
    .line 24: monitor-exit v0
    .line 25: throw v1
.end method

# direct methods
.method public static c()Z
    .registers 1

    .line 0: sget-object v0, Landroidx/emoji2/text/k;->k:Landroidx/emoji2/text/k;
    .line 2: if-eqz v0, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_7
    .line 6: const/4 v0, 0
    .line 7: return v0
.end method

# virtual methods
.method public final b()I
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 2: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;
    .line 5: move-result-object v0
    .line 6: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V
    .line 9: iget v0, v2, Landroidx/emoji2/text/k;->c:I
    .line 11: iget-object v1, v2, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 13: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;
    .line 16: move-result-object v1
    .line 17: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 20: return v0
    .line 21: move-exception v0
    .line 22: iget-object v1, v2, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 24: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;
    .line 27: move-result-object v1
    .line 28: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 31: throw v0
.end method

# virtual methods
.method public final d()V
    .registers 4

    .line 0: iget v0, v3, Landroidx/emoji2/text/k;->h:I
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 1
    .line 4: if-ne v0, v2, :cond_8
    .line 6: move v0, v2
    .line 7: goto :goto_9
    .line 8: move v0, v1
    .line 9: if-eqz v0, :cond_69
    .line 11: invoke-virtual {v3}, Landroidx/emoji2/text/k;->b()I
    .line 14: move-result v0
    .line 15: if-ne v0, v2, :cond_18
    .line 17: return-void
    .line 18: iget-object v0, v3, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 20: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 23: move-result-object v0
    .line 24: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V
    .line 27: iget v0, v3, Landroidx/emoji2/text/k;->c:I
    .line 29: if-nez v0, :cond_41
    .line 31: iget-object v0, v3, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 33: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 36: move-result-object v0
    .line 37: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 40: return-void
    .line 41: iput v1, v3, Landroidx/emoji2/text/k;->c:I
    .line 43: iget-object v0, v3, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 45: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 48: move-result-object v0
    .line 49: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 52: iget-object v0, v3, Landroidx/emoji2/text/k;->e:Landroidx/emoji2/text/g;
    .line 54: invoke-virtual {v0}, Landroidx/emoji2/text/g;->v()V
    .line 57: return-void
    .line 58: move-exception v0
    .line 59: iget-object v1, v3, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 61: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 64: move-result-object v1
    .line 65: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 68: throw v0
    .line 69: new-instance v0, Ljava/lang/IllegalStateException;
    .line 71: const-string v1, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading"
    .line 73: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 76: throw v0
.end method

# virtual methods
.method public final e(Ljava/lang/Throwable;)V
    .registers 6

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 5: iget-object v1, v4, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 7: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 10: move-result-object v1
    .line 11: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V
    .line 14: const/4 v1, 2
    .line 15: iput v1, v4, Landroidx/emoji2/text/k;->c:I
    .line 17: iget-object v1, v4, Landroidx/emoji2/text/k;->b:Lf/c;
    .line 19: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    .line 22: iget-object v1, v4, Landroidx/emoji2/text/k;->b:Lf/c;
    .line 24: invoke-virtual {v1}, Lf/c;->clear()V
    .line 27: iget-object v1, v4, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 29: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 32: move-result-object v1
    .line 33: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 36: iget-object v1, v4, Landroidx/emoji2/text/k;->d:Landroid/os/Handler;
    .line 38: new-instance v2, Lb2/b;
    .line 40: iget v3, v4, Landroidx/emoji2/text/k;->c:I
    .line 42: invoke-direct {v2, v0, v3, v5}, Lb2/b;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V
    .line 45: invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 48: return-void
    .line 49: move-exception v5
    .line 50: iget-object v0, v4, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 52: invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 55: move-result-object v0
    .line 56: invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 59: throw v5
.end method

# virtual methods
.method public final f()V
    .registers 5

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 5: iget-object v1, v4, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 7: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 10: move-result-object v1
    .line 11: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V
    .line 14: const/4 v1, 1
    .line 15: iput v1, v4, Landroidx/emoji2/text/k;->c:I
    .line 17: iget-object v1, v4, Landroidx/emoji2/text/k;->b:Lf/c;
    .line 19: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    .line 22: iget-object v1, v4, Landroidx/emoji2/text/k;->b:Lf/c;
    .line 24: invoke-virtual {v1}, Lf/c;->clear()V
    .line 27: iget-object v1, v4, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 29: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 32: move-result-object v1
    .line 33: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 36: iget-object v1, v4, Landroidx/emoji2/text/k;->d:Landroid/os/Handler;
    .line 38: new-instance v2, Lb2/b;
    .line 40: iget v3, v4, Landroidx/emoji2/text/k;->c:I
    .line 42: invoke-direct {v2, v3, v0}, Lb2/b;-><init>(ILjava/util/ArrayList;)V
    .line 45: invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 48: return-void
    .line 49: move-exception v0
    .line 50: iget-object v1, v4, Landroidx/emoji2/text/k;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .line 52: invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;
    .line 55: move-result-object v1
    .line 56: invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    .line 59: throw v0
.end method

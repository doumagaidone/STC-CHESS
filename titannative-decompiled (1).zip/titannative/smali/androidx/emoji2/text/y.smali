.class public final Landroidx/emoji2/text/y;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final d:Ljava/lang/ThreadLocal;

.field public final a:I
.field public final b:Landroidx/emoji2/text/x;
.field public volatile c:I

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/ThreadLocal;
    .line 2: invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V
    .line 5: sput-object v0, Landroidx/emoji2/text/y;->d:Ljava/lang/ThreadLocal;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(Landroidx/emoji2/text/x;I)V
    .registers 4

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput v0, v1, Landroidx/emoji2/text/y;->c:I
    .line 6: iput-object v2, v1, Landroidx/emoji2/text/y;->b:Landroidx/emoji2/text/x;
    .line 8: iput v3, v1, Landroidx/emoji2/text/y;->a:I
    .line 10: return-void
.end method

# virtual methods
.method public final a(I)I
    .registers 5

    .line 0: invoke-virtual {v3}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 3: move-result-object v0
    .line 4: const/16 v1, 16
    .line 6: invoke-virtual {v0, v1}, Li2/c;->a(I)I
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_32
    .line 12: iget-object v2, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 14: iget v0, v0, Li2/c;->a:I
    .line 16: add-int/2addr v1, v0
    .line 17: invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 20: move-result v0
    .line 21: add-int/2addr v0, v1
    .line 22: add-int/lit8 v0, v0, 4
    .line 24: mul-int/lit8 v4, v4, 4
    .line 26: add-int/2addr v4, v0
    .line 27: invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 30: move-result v4
    .line 31: goto :goto_33
    .line 32: const/4 v4, 0
    .line 33: return v4
.end method

# virtual methods
.method public final b()I
    .registers 4

    .line 0: invoke-virtual {v3}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 3: move-result-object v0
    .line 4: const/16 v1, 16
    .line 6: invoke-virtual {v0, v1}, Li2/c;->a(I)I
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_29
    .line 12: iget v2, v0, Li2/c;->a:I
    .line 14: add-int/2addr v1, v2
    .line 15: iget-object v2, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 17: invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 20: move-result v2
    .line 21: add-int/2addr v2, v1
    .line 22: iget-object v0, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 24: invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 27: move-result v0
    .line 28: goto :goto_30
    .line 29: const/4 v0, 0
    .line 30: return v0
.end method

# virtual methods
.method public final c()Li2/a;
    .registers 5

    .line 0: sget-object v0, Landroidx/emoji2/text/y;->d:Ljava/lang/ThreadLocal;
    .line 2: invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Li2/a;
    .line 8: if-nez v1, :cond_18
    .line 10: new-instance v1, Li2/a;
    .line 12: invoke-direct {v1}, Li2/c;-><init>()V
    .line 15: invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    .line 18: iget-object v0, v4, Landroidx/emoji2/text/y;->b:Landroidx/emoji2/text/x;
    .line 20: iget-object v0, v0, Landroidx/emoji2/text/x;->a:Li2/b;
    .line 22: const/4 v2, 6
    .line 23: invoke-virtual {v0, v2}, Li2/c;->a(I)I
    .line 26: move-result v2
    .line 27: if-eqz v2, :cond_84
    .line 29: iget v3, v0, Li2/c;->a:I
    .line 31: add-int/2addr v2, v3
    .line 32: iget-object v3, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 34: invoke-virtual {v3, v2}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 37: move-result v3
    .line 38: add-int/2addr v3, v2
    .line 39: add-int/lit8 v3, v3, 4
    .line 41: iget v2, v4, Landroidx/emoji2/text/y;->a:I
    .line 43: mul-int/lit8 v2, v2, 4
    .line 45: add-int/2addr v2, v3
    .line 46: iget-object v3, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 48: invoke-virtual {v3, v2}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 51: move-result v3
    .line 52: add-int/2addr v3, v2
    .line 53: iget-object v0, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 55: iput-object v0, v1, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 57: if-eqz v0, :cond_77
    .line 59: iput v3, v1, Li2/c;->a:I
    .line 61: invoke-virtual {v0, v3}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 64: move-result v0
    .line 65: sub-int/2addr v3, v0
    .line 66: iput v3, v1, Li2/c;->c:I
    .line 68: iget-object v0, v1, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 70: invoke-virtual {v0, v3}, Ljava/nio/ByteBuffer;->getShort(I)S
    .line 73: move-result v0
    .line 74: iput v0, v1, Li2/c;->d:I
    .line 76: goto :goto_84
    .line 77: const/4 v0, 0
    .line 78: iput v0, v1, Li2/c;->a:I
    .line 80: iput v0, v1, Li2/c;->c:I
    .line 82: iput v0, v1, Li2/c;->d:I
    .line 84: return-object v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 6

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 5: invoke-super {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 8: move-result-object v1
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", id:"
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: invoke-virtual {v5}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 20: move-result-object v1
    .line 21: const/4 v2, 4
    .line 22: invoke-virtual {v1, v2}, Li2/c;->a(I)I
    .line 25: move-result v2
    .line 26: const/4 v3, 0
    .line 27: if-eqz v2, :cond_39
    .line 29: iget-object v4, v1, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 31: iget v1, v1, Li2/c;->a:I
    .line 33: add-int/2addr v2, v1
    .line 34: invoke-virtual {v4, v2}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 37: move-result v1
    .line 38: goto :goto_40
    .line 39: move v1, v3
    .line 40: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    .line 43: move-result-object v1
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: const-string v1, ", codepoints:"
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 52: invoke-virtual {v5}, Landroidx/emoji2/text/y;->b()I
    .line 55: move-result v1
    .line 56: if-ge v3, v1, :cond_77
    .line 58: invoke-virtual {v5, v3}, Landroidx/emoji2/text/y;->a(I)I
    .line 61: move-result v2
    .line 62: invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    .line 65: move-result-object v2
    .line 66: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 69: const-string v2, " "
    .line 71: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 74: add-int/lit8 v3, v3, 1
    .line 76: goto :goto_56
    .line 77: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 80: move-result-object v0
    .line 81: return-object v0
.end method

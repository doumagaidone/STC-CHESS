.class public final Landroidx/emoji2/text/z;
.super Landroid/text/style/ReplacementSpan;
.source "SourceFile"

.field public final a:Landroid/graphics/Paint$FontMetricsInt;
.field public final b:Landroidx/emoji2/text/y;
.field public c:S
.field public d:F
.field public e:Landroid/text/TextPaint;

# direct methods
.method public constructor <init>(Landroidx/emoji2/text/y;)V
    .registers 3

    .line 0: invoke-direct {v1}, Landroid/text/style/ReplacementSpan;-><init>()V
    .line 3: new-instance v0, Landroid/graphics/Paint$FontMetricsInt;
    .line 5: invoke-direct {v0}, Landroid/graphics/Paint$FontMetricsInt;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/emoji2/text/z;->a:Landroid/graphics/Paint$FontMetricsInt;
    .line 10: const/4 v0, -1
    .line 11: iput-short v0, v1, Landroidx/emoji2/text/z;->c:S
    .line 13: const/high16 v0, 0x3f80
    .line 15: iput v0, v1, Landroidx/emoji2/text/z;->d:F
    .line 17: if-eqz v2, :cond_22
    .line 19: iput-object v2, v1, Landroidx/emoji2/text/z;->b:Landroidx/emoji2/text/y;
    .line 21: return-void
    .line 22: new-instance v2, Ljava/lang/NullPointerException;
    .line 24: const-string v0, "rasterizer cannot be null"
    .line 26: invoke-direct {v2, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 29: throw v2
.end method

# virtual methods
.method public final a(Landroid/graphics/Paint;Ljava/lang/CharSequence;IILandroid/graphics/Paint$FontMetricsInt;)I
    .registers 10

    .line 0: iget-object v6, v4, Landroidx/emoji2/text/z;->a:Landroid/graphics/Paint$FontMetricsInt;
    .line 2: invoke-virtual {v5, v6}, Landroid/graphics/Paint;->getFontMetricsInt(Landroid/graphics/Paint$FontMetricsInt;)I
    .line 5: iget v5, v6, Landroid/graphics/Paint$FontMetricsInt;->descent:I
    .line 7: iget v7, v6, Landroid/graphics/Paint$FontMetricsInt;->ascent:I
    .line 9: sub-int/2addr v5, v7
    .line 10: invoke-static {v5}, Ljava/lang/Math;->abs(I)I
    .line 13: move-result v5
    .line 14: int-to-float v5, v5
    .line 15: const/high16 v7, 0x3f80
    .line 17: mul-float/2addr v5, v7
    .line 18: iget-object v7, v4, Landroidx/emoji2/text/z;->b:Landroidx/emoji2/text/y;
    .line 20: invoke-virtual {v7}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 23: move-result-object v8
    .line 24: const/16 v0, 14
    .line 26: invoke-virtual {v8, v0}, Li2/c;->a(I)I
    .line 29: move-result v1
    .line 30: const/4 v2, 0
    .line 31: if-eqz v1, :cond_43
    .line 33: iget-object v3, v8, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 35: iget v8, v8, Li2/c;->a:I
    .line 37: add-int/2addr v1, v8
    .line 38: invoke-virtual {v3, v1}, Ljava/nio/ByteBuffer;->getShort(I)S
    .line 41: move-result v8
    .line 42: goto :goto_44
    .line 43: move v8, v2
    .line 44: int-to-float v8, v8
    .line 45: div-float/2addr v5, v8
    .line 46: iput v5, v4, Landroidx/emoji2/text/z;->d:F
    .line 48: invoke-virtual {v7}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 51: move-result-object v5
    .line 52: invoke-virtual {v5, v0}, Li2/c;->a(I)I
    .line 55: move-result v8
    .line 56: if-eqz v8, :cond_66
    .line 58: iget-object v0, v5, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 60: iget v5, v5, Li2/c;->a:I
    .line 62: add-int/2addr v8, v5
    .line 63: invoke-virtual {v0, v8}, Ljava/nio/ByteBuffer;->getShort(I)S
    .line 66: invoke-virtual {v7}, Landroidx/emoji2/text/y;->c()Li2/a;
    .line 69: move-result-object v5
    .line 70: const/16 v7, 12
    .line 72: invoke-virtual {v5, v7}, Li2/c;->a(I)I
    .line 75: move-result v7
    .line 76: if-eqz v7, :cond_87
    .line 78: iget-object v8, v5, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 80: iget v5, v5, Li2/c;->a:I
    .line 82: add-int/2addr v7, v5
    .line 83: invoke-virtual {v8, v7}, Ljava/nio/ByteBuffer;->getShort(I)S
    .line 86: move-result v2
    .line 87: int-to-float v5, v2
    .line 88: iget v7, v4, Landroidx/emoji2/text/z;->d:F
    .line 90: mul-float/2addr v5, v7
    .line 91: float-to-int v5, v5
    .line 92: int-to-short v5, v5
    .line 93: iput-short v5, v4, Landroidx/emoji2/text/z;->c:S
    .line 95: if-eqz v9, :cond_113
    .line 97: iget v7, v6, Landroid/graphics/Paint$FontMetricsInt;->ascent:I
    .line 99: iput v7, v9, Landroid/graphics/Paint$FontMetricsInt;->ascent:I
    .line 101: iget v7, v6, Landroid/graphics/Paint$FontMetricsInt;->descent:I
    .line 103: iput v7, v9, Landroid/graphics/Paint$FontMetricsInt;->descent:I
    .line 105: iget v7, v6, Landroid/graphics/Paint$FontMetricsInt;->top:I
    .line 107: iput v7, v9, Landroid/graphics/Paint$FontMetricsInt;->top:I
    .line 109: iget v6, v6, Landroid/graphics/Paint$FontMetricsInt;->bottom:I
    .line 111: iput v6, v9, Landroid/graphics/Paint$FontMetricsInt;->bottom:I
    .line 113: return v5
.end method

# virtual methods
.method public final draw(Landroid/graphics/Canvas;Ljava/lang/CharSequence;IIFIIILandroid/graphics/Paint;)V
    .registers 23

    .line 0: move-object v0, v13
    .line 1: move-object v1, v15
    .line 2: move-object/from16 v2, v22
    .line 4: instance-of v3, v1, Landroid/text/Spanned;
    .line 6: const/4 v4, 0
    .line 7: if-eqz v3, :cond_74
    .line 9: check-cast v1, Landroid/text/Spanned;
    .line 11: const-class v3, Landroid/text/style/CharacterStyle;
    .line 13: move/from16 v5, v16
    .line 15: move/from16 v6, v17
    .line 17: invoke-interface {v1, v5, v6, v3}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .line 20: move-result-object v1
    .line 21: check-cast v1, [Landroid/text/style/CharacterStyle;
    .line 23: array-length v3, v1
    .line 24: if-eqz v3, :cond_66
    .line 26: array-length v3, v1
    .line 27: const/4 v5, 1
    .line 28: const/4 v6, 0
    .line 29: if-ne v3, v5, :cond_36
    .line 31: aget-object v3, v1, v6
    .line 33: if-ne v3, v0, :cond_36
    .line 35: goto :goto_66
    .line 36: iget-object v3, v0, Landroidx/emoji2/text/z;->e:Landroid/text/TextPaint;
    .line 38: if-nez v3, :cond_47
    .line 40: new-instance v3, Landroid/text/TextPaint;
    .line 42: invoke-direct {v3}, Landroid/text/TextPaint;-><init>()V
    .line 45: iput-object v3, v0, Landroidx/emoji2/text/z;->e:Landroid/text/TextPaint;
    .line 47: move-object v4, v3
    .line 48: invoke-virtual {v4, v2}, Landroid/graphics/Paint;->set(Landroid/graphics/Paint;)V
    .line 51: array-length v3, v1
    .line 52: if-ge v6, v3, :cond_81
    .line 54: aget-object v3, v1, v6
    .line 56: instance-of v5, v3, Landroid/text/style/MetricAffectingSpan;
    .line 58: if-nez v5, :cond_63
    .line 60: invoke-virtual {v3, v4}, Landroid/text/style/CharacterStyle;->updateDrawState(Landroid/text/TextPaint;)V
    .line 63: add-int/lit8 v6, v6, 1
    .line 65: goto :goto_51
    .line 66: instance-of v1, v2, Landroid/text/TextPaint;
    .line 68: if-eqz v1, :cond_81
    .line 70: move-object v4, v2
    .line 71: check-cast v4, Landroid/text/TextPaint;
    .line 73: goto :goto_81
    .line 74: instance-of v1, v2, Landroid/text/TextPaint;
    .line 76: if-eqz v1, :cond_81
    .line 78: move-object v4, v2
    .line 79: check-cast v4, Landroid/text/TextPaint;
    .line 81: if-eqz v4, :cond_129
    .line 83: iget v1, v4, Landroid/text/TextPaint;->bgColor:I
    .line 85: if-eqz v1, :cond_129
    .line 87: iget-short v1, v0, Landroidx/emoji2/text/z;->c:S
    .line 89: int-to-float v1, v1
    .line 90: add-float v8, v18, v1
    .line 92: move/from16 v1, v19
    .line 94: int-to-float v7, v1
    .line 95: move/from16 v1, v21
    .line 97: int-to-float v9, v1
    .line 98: invoke-virtual {v4}, Landroid/graphics/Paint;->getColor()I
    .line 101: move-result v1
    .line 102: invoke-virtual {v4}, Landroid/graphics/Paint;->getStyle()Landroid/graphics/Paint$Style;
    .line 105: move-result-object v3
    .line 106: iget v5, v4, Landroid/text/TextPaint;->bgColor:I
    .line 108: invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V
    .line 111: sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;
    .line 113: invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V
    .line 116: move-object v5, v14
    .line 117: move/from16 v6, v18
    .line 119: move-object v10, v4
    .line 120: invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V
    .line 123: invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V
    .line 126: invoke-virtual {v4, v1}, Landroid/graphics/Paint;->setColor(I)V
    .line 129: invoke-static {}, Landroidx/emoji2/text/k;->a()Landroidx/emoji2/text/k;
    .line 132: move-result-object v1
    .line 133: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 136: move/from16 v1, v20
    .line 138: int-to-float v10, v1
    .line 139: if-eqz v4, :cond_142
    .line 141: move-object v2, v4
    .line 142: iget-object v1, v0, Landroidx/emoji2/text/z;->b:Landroidx/emoji2/text/y;
    .line 144: iget-object v3, v1, Landroidx/emoji2/text/y;->b:Landroidx/emoji2/text/x;
    .line 146: iget-object v4, v3, Landroidx/emoji2/text/x;->d:Landroid/graphics/Typeface;
    .line 148: invoke-virtual {v2}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;
    .line 151: move-result-object v12
    .line 152: invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 155: iget v1, v1, Landroidx/emoji2/text/y;->a:I
    .line 157: mul-int/lit8 v7, v1, 2
    .line 159: iget-object v6, v3, Landroidx/emoji2/text/x;->b:[C
    .line 161: const/4 v8, 2
    .line 162: move-object v5, v14
    .line 163: move/from16 v9, v18
    .line 165: move-object v11, v2
    .line 166: invoke-virtual/range {v5 .. v11}, Landroid/graphics/Canvas;->drawText([CIIFFLandroid/graphics/Paint;)V
    .line 169: invoke-virtual {v2, v12}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 172: return-void
.end method

# virtual methods
.method public final bridge synthetic getSize(Landroid/graphics/Paint;Ljava/lang/CharSequence;IILandroid/graphics/Paint$FontMetricsInt;)I
    .registers 6

    .line 0: invoke-virtual/range {v0 .. v5}, Landroidx/emoji2/text/z;->a(Landroid/graphics/Paint;Ljava/lang/CharSequence;IILandroid/graphics/Paint$FontMetricsInt;)I
    .line 3: move-result v1
    .line 4: return v1
.end method

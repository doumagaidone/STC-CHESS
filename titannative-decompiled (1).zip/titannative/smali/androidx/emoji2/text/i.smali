.class public abstract interface Landroidx/emoji2/text/i;
.super Ljava/lang/Object;
.source "SourceFile"

.class public abstract interface Landroidx/emoji2/text/q;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a(Ljava/lang/CharSequence;IILandroidx/emoji2/text/y;)Z
.end method

# virtual methods
.method public abstract c()Ljava/lang/Object;
.end method

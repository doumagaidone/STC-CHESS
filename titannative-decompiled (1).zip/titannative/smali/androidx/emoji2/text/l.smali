.class public final synthetic Landroidx/emoji2/text/l;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final synthetic j:Ljava/lang/Object;
.field public final synthetic k:Ljava/lang/Object;
.field public final synthetic l:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v4, v0, Landroidx/emoji2/text/l;->i:I
    .line 5: iput-object v1, v0, Landroidx/emoji2/text/l;->j:Ljava/lang/Object;
    .line 7: iput-object v2, v0, Landroidx/emoji2/text/l;->k:Ljava/lang/Object;
    .line 9: iput-object v3, v0, Landroidx/emoji2/text/l;->l:Ljava/lang/Object;
    .line 11: return-void
.end method

# virtual methods
.method public final run()V
    .registers 6

    .line 0: iget v0, v5, Landroidx/emoji2/text/l;->i:I
    .line 2: packed-switch v0, :data_110
    .line 5: iget-object v0, v5, Landroidx/emoji2/text/l;->j:Ljava/lang/Object;
    .line 7: check-cast v0, Le3/o;
    .line 9: iget-object v1, v5, Landroidx/emoji2/text/l;->k:Ljava/lang/Object;
    .line 11: check-cast v1, Le3/o;
    .line 13: iget-object v2, v5, Landroidx/emoji2/text/l;->l:Ljava/lang/Object;
    .line 15: check-cast v2, Ld3/a;
    .line 17: const-string v3, "$moved"
    .line 19: invoke-static {v0, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: const-string v3, "$longFired"
    .line 24: invoke-static {v1, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 27: const-string v3, "$onLongPress"
    .line 29: invoke-static {v2, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 32: iget-boolean v0, v0, Le3/o;->i:Z
    .line 34: if-nez v0, :cond_42
    .line 36: const/4 v0, 1
    .line 37: iput-boolean v0, v1, Le3/o;->i:Z
    .line 39: invoke-interface {v2}, Ld3/a;->s()Ljava/lang/Object;
    .line 42: return-void
    .line 43: iget-object v0, v5, Landroidx/emoji2/text/l;->j:Ljava/lang/Object;
    .line 45: check-cast v0, Lu/d;
    .line 47: iget-object v1, v5, Landroidx/emoji2/text/l;->k:Ljava/lang/Object;
    .line 49: check-cast v1, Ld2/c;
    .line 51: iget-object v2, v5, Landroidx/emoji2/text/l;->l:Ljava/lang/Object;
    .line 53: check-cast v2, Ljava/util/concurrent/ThreadPoolExecutor;
    .line 55: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 58: iget-object v0, v0, Lu/d;->b:Ljava/lang/Object;
    .line 60: check-cast v0, Landroid/content/Context;
    .line 62: invoke-static {v0}, Ld2/b;->R(Landroid/content/Context;)Landroidx/emoji2/text/v;
    .line 65: move-result-object v0
    .line 66: if-eqz v0, :cond_94
    .line 68: iget-object v3, v0, Landroidx/emoji2/text/h;->a:Landroidx/emoji2/text/j;
    .line 70: check-cast v3, Landroidx/emoji2/text/u;
    .line 72: iget-object v4, v3, Landroidx/emoji2/text/u;->d:Ljava/lang/Object;
    .line 74: monitor-enter v4
    .line 75: iput-object v2, v3, Landroidx/emoji2/text/u;->f:Ljava/util/concurrent/Executor;
    .line 77: monitor-exit v4
    .line 78: iget-object v0, v0, Landroidx/emoji2/text/h;->a:Landroidx/emoji2/text/j;
    .line 80: new-instance v3, Landroidx/emoji2/text/m;
    .line 82: invoke-direct {v3, v1, v2}, Landroidx/emoji2/text/m;-><init>(Ld2/c;Ljava/util/concurrent/ThreadPoolExecutor;)V
    .line 85: invoke-interface {v0, v3}, Landroidx/emoji2/text/j;->b(Ld2/c;)V
    .line 88: goto :goto_108
    .line 89: move-exception v0
    .line 90: goto :goto_102
    .line 91: move-exception v0
    .line 92: monitor-exit v4
    .line 93: throw v0
    .line 94: new-instance v0, Ljava/lang/RuntimeException;
    .line 96: const-string v3, "EmojiCompat font provider not available on this device."
    .line 98: invoke-direct {v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 101: throw v0
    .line 102: invoke-virtual {v1, v0}, Ld2/c;->k0(Ljava/lang/Throwable;)V
    .line 105: invoke-virtual {v2}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V
    .line 108: return-void
    .line 109: nop
    .line 110: nop
    .line 111: move v0, v0
    .line 112: nop
    .line 113: nop
    .line 114: goto/16 :goto_114
.end method

.class public abstract Landroidx/emoji2/text/b;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/os/Looper;)Landroid/os/Handler;
    .registers 1

    .line 0: invoke-static {v0}, Landroidx/compose/ui/platform/r2;->c(Landroid/os/Looper;)Landroid/os/Handler;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

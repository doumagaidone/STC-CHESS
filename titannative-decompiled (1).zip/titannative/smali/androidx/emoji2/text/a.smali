.class public final synthetic Landroidx/emoji2/text/a;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/concurrent/ThreadFactory;

.field public final synthetic a:Ljava/lang/String;

# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/emoji2/text/a;->a:Ljava/lang/String;
    .line 5: return-void
.end method

# virtual methods
.method public final newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/Thread;
    .line 2: iget-object v1, v2, Landroidx/emoji2/text/a;->a:Ljava/lang/String;
    .line 4: invoke-direct {v0, v3, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V
    .line 7: const/16 v3, 10
    .line 9: invoke-virtual {v0, v3}, Ljava/lang/Thread;->setPriority(I)V
    .line 12: return-object v0
.end method

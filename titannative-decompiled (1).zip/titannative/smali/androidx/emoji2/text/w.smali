.class public final Landroidx/emoji2/text/w;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroid/util/SparseArray;
.field public b:Landroidx/emoji2/text/y;

# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Landroid/util/SparseArray;
    .line 5: invoke-direct {v0, v2}, Landroid/util/SparseArray;-><init>(I)V
    .line 8: iput-object v0, v1, Landroidx/emoji2/text/w;->a:Landroid/util/SparseArray;
    .line 10: return-void
.end method

# virtual methods
.method public final a(Landroidx/emoji2/text/y;II)V
    .registers 8

    .line 0: invoke-virtual {v5, v6}, Landroidx/emoji2/text/y;->a(I)I
    .line 3: move-result v0
    .line 4: iget-object v1, v4, Landroidx/emoji2/text/w;->a:Landroid/util/SparseArray;
    .line 6: if-nez v1, :cond_10
    .line 8: const/4 v0, 0
    .line 9: goto :goto_16
    .line 10: invoke-virtual {v1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;
    .line 13: move-result-object v0
    .line 14: check-cast v0, Landroidx/emoji2/text/w;
    .line 16: const/4 v2, 1
    .line 17: if-nez v0, :cond_31
    .line 19: new-instance v0, Landroidx/emoji2/text/w;
    .line 21: invoke-direct {v0, v2}, Landroidx/emoji2/text/w;-><init>(I)V
    .line 24: invoke-virtual {v5, v6}, Landroidx/emoji2/text/y;->a(I)I
    .line 27: move-result v3
    .line 28: invoke-virtual {v1, v3, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    .line 31: if-le v7, v6, :cond_38
    .line 33: add-int/2addr v6, v2
    .line 34: invoke-virtual {v0, v5, v6, v7}, Landroidx/emoji2/text/w;->a(Landroidx/emoji2/text/y;II)V
    .line 37: goto :goto_40
    .line 38: iput-object v5, v0, Landroidx/emoji2/text/w;->b:Landroidx/emoji2/text/y;
    .line 40: return-void
.end method

.class public final Landroidx/activity/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/activity/a;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/activity/a;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/activity/a;->a:Landroidx/activity/a;
    .line 7: return-void
.end method

# virtual methods
.method public final a(FFFI)Landroid/window/BackEvent;
    .registers 6

    .line 0: new-instance v0, Landroid/window/BackEvent;
    .line 2: invoke-direct {v0, v2, v3, v4, v5}, Landroid/window/BackEvent;-><init>(FFFI)V
    .line 5: return-object v0
.end method

# virtual methods
.method public final b(Landroid/window/BackEvent;)F
    .registers 3

    .line 0: const-string v0, "backEvent"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/window/BackEvent;->getProgress()F
    .line 8: move-result v2
    .line 9: return v2
.end method

# virtual methods
.method public final c(Landroid/window/BackEvent;)I
    .registers 3

    .line 0: const-string v0, "backEvent"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/window/BackEvent;->getSwipeEdge()I
    .line 8: move-result v2
    .line 9: return v2
.end method

# virtual methods
.method public final d(Landroid/window/BackEvent;)F
    .registers 3

    .line 0: const-string v0, "backEvent"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/window/BackEvent;->getTouchX()F
    .line 8: move-result v2
    .line 9: return v2
.end method

# virtual methods
.method public final e(Landroid/window/BackEvent;)F
    .registers 3

    .line 0: const-string v0, "backEvent"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/window/BackEvent;->getTouchY()F
    .line 8: move-result v2
    .line 9: return v2
.end method

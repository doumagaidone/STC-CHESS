.class public final Landroidx/activity/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Landroidx/activity/b;->a:I
    .line 5: return-void
.end method

# direct methods
.method public synthetic constructor <init>(II)V
    .registers 3

    .line 0: iput v1, v0, Landroidx/activity/b;->a:I
    .line 2: packed-switch v1, :data_166
    .line 5: const/4 v1, 0
    .line 6: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 9: return-void
    .line 10: const/16 v1, 28
    .line 12: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 15: return-void
    .line 16: const/16 v1, 27
    .line 18: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 21: return-void
    .line 22: const/16 v1, 26
    .line 24: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 27: return-void
    .line 28: const/16 v1, 25
    .line 30: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 33: return-void
    .line 34: const/16 v1, 24
    .line 36: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 39: return-void
    .line 40: const/16 v1, 23
    .line 42: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 45: return-void
    .line 46: const/16 v1, 22
    .line 48: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 51: return-void
    .line 52: const/16 v1, 21
    .line 54: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 57: return-void
    .line 58: const/16 v1, 20
    .line 60: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 63: return-void
    .line 64: const/16 v1, 19
    .line 66: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 69: return-void
    .line 70: const/16 v1, 18
    .line 72: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 75: return-void
    .line 76: const/16 v1, 17
    .line 78: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 81: return-void
    .line 82: const/16 v1, 16
    .line 84: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 87: return-void
    .line 88: const/16 v1, 14
    .line 90: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 93: return-void
    .line 94: const/16 v1, 13
    .line 96: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 99: return-void
    .line 100: const/16 v1, 12
    .line 102: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 105: return-void
    .line 106: const/16 v1, 11
    .line 108: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 111: return-void
    .line 112: const/16 v1, 10
    .line 114: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 117: return-void
    .line 118: const/16 v1, 9
    .line 120: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 123: return-void
    .line 124: const/16 v1, 8
    .line 126: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 129: return-void
    .line 130: const/4 v1, 7
    .line 131: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 134: return-void
    .line 135: const/4 v1, 6
    .line 136: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 139: return-void
    .line 140: const/4 v1, 5
    .line 141: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 144: return-void
    .line 145: const/4 v1, 4
    .line 146: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 149: return-void
    .line 150: const/4 v1, 3
    .line 151: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 154: return-void
    .line 155: const/4 v1, 2
    .line 156: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 159: return-void
    .line 160: const/4 v1, 1
    .line 161: invoke-direct {v0, v1}, Landroidx/activity/b;-><init>(I)V
    .line 164: return-void
    .line 165: nop
    .line 166: nop
    .line 167: const-class v0, C
    .line 169: nop
    .line 170: div-long v0, v0, v0
    .line 172: shr-int v0, v0, v0
    .line 174: rem-int v0, v0, v0
    .line 176: int-to-short v0, v0
    .line 177: nop
    .line 178: double-to-int v0, v0
    .line 179: nop
    .line 180: long-to-float v0, v0
    .line 181: nop
    .line 182: neg-double v0, v0
    .line 183: nop
    .line 184: 0x7a ; unknown opcode
    .line 185: nop
    .line 186: invoke-virtual/range {}, La/a;-><clinit>()V
    .line 189: nop
    .line 190: sput-wide v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 192: sget-object v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 194: iput-boolean v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 196: iget-byte v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 198: move/16 v0, v80
    .line 201: nop
    .line 202: aget-short v0, v0, v0
    .line 204: aget v0, v0, v0
    .line 206: 0x3e ; unknown opcode
    .line 207: nop
    .line 208: if-eqz v0, :cond_208
    .line 210: if-eq v0, v0, :cond_210
    .line 212: sparse-switch v0, :data_2490580
    .line 215: nop
    .line 216: instance-of v0, v0, B
    .line 218: const-string v0, ""
    .line 220: const v0, 0xe0000
    .line 223: nop
    .line 224: move-object/from16 v0, v0
.end method

# direct methods
.method public static final a(Lu/d;)V
    .registers 10

    .line 0: sget-object v0, Lu/o2;->u:Lkotlinx/coroutines/flow/p0;
    .line 2: sget-object v0, Lu/o2;->u:Lkotlinx/coroutines/flow/p0;
    .line 4: invoke-virtual {v0}, Lkotlinx/coroutines/flow/p0;->getValue()Ljava/lang/Object;
    .line 7: move-result-object v1
    .line 8: check-cast v1, Lw/g;
    .line 10: move-object v2, v1
    .line 11: check-cast v2, Lz/b;
    .line 13: iget-object v3, v2, Lz/b;->k:Ly/c;
    .line 15: invoke-virtual {v3, v9}, Ly/c;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 18: move-result-object v4
    .line 19: check-cast v4, Lz/a;
    .line 21: if-nez v4, :cond_25
    .line 23: goto/16 :goto_131
    .line 25: const/4 v5, 0
    .line 26: if-eqz v9, :cond_33
    .line 28: invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I
    .line 31: move-result v6
    .line 32: goto :goto_34
    .line 33: move v6, v5
    .line 34: iget-object v7, v3, Ly/c;->i:Ly/n;
    .line 36: invoke-virtual {v7, v6, v5, v9}, Ly/n;->v(IILu/d;)Ly/n;
    .line 39: move-result-object v6
    .line 40: const/4 v8, 1
    .line 41: if-ne v7, v6, :cond_44
    .line 43: goto :goto_63
    .line 44: if-nez v6, :cond_54
    .line 46: sget-object v3, Ly/c;->k:Ly/c;
    .line 48: const-string v6, "null cannot be cast to non-null type androidx.compose.runtime.external.kotlinx.collections.immutable.implementations.immutableMap.PersistentHashMap<K of androidx.compose.runtime.external.kotlinx.collections.immutable.implementations.immutableMap.PersistentHashMap.Companion.emptyOf, V of androidx.compose.runtime.external.kotlinx.collections.immutable.implementations.immutableMap.PersistentHashMap.Companion.emptyOf>"
    .line 50: invoke-static {v3, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 53: goto :goto_63
    .line 54: new-instance v7, Ly/c;
    .line 56: iget v3, v3, Ly/c;->j:I
    .line 58: sub-int/2addr v3, v8
    .line 59: invoke-direct {v7, v6, v3}, Ly/c;-><init>(Ly/n;I)V
    .line 62: move-object v3, v7
    .line 63: sget-object v6, La0/b;->a:La0/b;
    .line 65: iget-object v7, v4, Lz/a;->a:Ljava/lang/Object;
    .line 67: if-eq v7, v6, :cond_70
    .line 69: move v5, v8
    .line 70: iget-object v4, v4, Lz/a;->b:Ljava/lang/Object;
    .line 72: if-eqz v5, :cond_94
    .line 74: invoke-interface {v3, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 77: move-result-object v5
    .line 78: invoke-static {v5}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 81: check-cast v5, Lz/a;
    .line 83: new-instance v8, Lz/a;
    .line 85: iget-object v5, v5, Lz/a;->a:Ljava/lang/Object;
    .line 87: invoke-direct {v8, v5, v4}, Lz/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 90: invoke-virtual {v3, v7, v8}, Ly/c;->c(Ljava/lang/Object;Lz/a;)Ly/c;
    .line 93: move-result-object v3
    .line 94: if-eq v4, v6, :cond_116
    .line 96: invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 99: move-result-object v5
    .line 100: invoke-static {v5}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 103: check-cast v5, Lz/a;
    .line 105: new-instance v8, Lz/a;
    .line 107: iget-object v5, v5, Lz/a;->b:Ljava/lang/Object;
    .line 109: invoke-direct {v8, v7, v5}, Lz/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 112: invoke-virtual {v3, v4, v8}, Ly/c;->c(Ljava/lang/Object;Lz/a;)Ly/c;
    .line 115: move-result-object v3
    .line 116: if-eq v7, v6, :cond_121
    .line 118: iget-object v5, v2, Lz/b;->i:Ljava/lang/Object;
    .line 120: goto :goto_122
    .line 121: move-object v5, v4
    .line 122: if-eq v4, v6, :cond_126
    .line 124: iget-object v7, v2, Lz/b;->j:Ljava/lang/Object;
    .line 126: new-instance v2, Lz/b;
    .line 128: invoke-direct {v2, v5, v7, v3}, Lz/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ly/c;)V
    .line 131: if-eq v1, v2, :cond_144
    .line 133: sget-object v3, Lq3/c;->b:Lkotlinx/coroutines/internal/u;
    .line 135: if-nez v1, :cond_138
    .line 137: move-object v1, v3
    .line 138: invoke-virtual {v0, v1, v2}, Lkotlinx/coroutines/flow/p0;->l(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 141: move-result v0
    .line 142: if-eqz v0, :cond_2
    .line 144: return-void
.end method

# direct methods
.method public static b(Lp/b;Lr1/j;Lf1/b0;Lr1/b;Lk1/r;)Lp/b;
    .registers 7

    .line 0: const-string v0, "paramStyle"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "fontFamilyResolver"
    .line 7: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: if-eqz v2, :cond_43
    .line 12: iget-object v0, v2, Lp/b;->a:Lr1/j;
    .line 14: if-ne v3, v0, :cond_43
    .line 16: iget-object v0, v2, Lp/b;->b:Lf1/b0;
    .line 18: invoke-static {v4, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 21: move-result v0
    .line 22: if-eqz v0, :cond_43
    .line 24: invoke-interface {v5}, Lr1/b;->getDensity()F
    .line 27: move-result v0
    .line 28: iget-object v1, v2, Lp/b;->c:Lr1/b;
    .line 30: invoke-interface {v1}, Lr1/b;->getDensity()F
    .line 33: move-result v1
    .line 34: cmpg-float v0, v0, v1
    .line 36: if-nez v0, :cond_43
    .line 38: iget-object v0, v2, Lp/b;->d:Lk1/r;
    .line 40: if-ne v6, v0, :cond_43
    .line 42: return-object v2
    .line 43: sget-object v2, Lp/b;->h:Lp/b;
    .line 45: if-eqz v2, :cond_78
    .line 47: iget-object v0, v2, Lp/b;->a:Lr1/j;
    .line 49: if-ne v3, v0, :cond_78
    .line 51: iget-object v0, v2, Lp/b;->b:Lf1/b0;
    .line 53: invoke-static {v4, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 56: move-result v0
    .line 57: if-eqz v0, :cond_78
    .line 59: invoke-interface {v5}, Lr1/b;->getDensity()F
    .line 62: move-result v0
    .line 63: iget-object v1, v2, Lp/b;->c:Lr1/b;
    .line 65: invoke-interface {v1}, Lr1/b;->getDensity()F
    .line 68: move-result v1
    .line 69: cmpg-float v0, v0, v1
    .line 71: if-nez v0, :cond_78
    .line 73: iget-object v0, v2, Lp/b;->d:Lk1/r;
    .line 75: if-ne v6, v0, :cond_78
    .line 77: return-object v2
    .line 78: new-instance v2, Lp/b;
    .line 80: invoke-static {v4, v3}, Ll0/j;->G(Lf1/b0;Lr1/j;)Lf1/b0;
    .line 83: move-result-object v4
    .line 84: invoke-direct {v2, v3, v4, v5, v6}, Lp/b;-><init>(Lr1/j;Lf1/b0;Lr1/b;Lk1/r;)V
    .line 87: sput-object v2, Lp/b;->h:Lp/b;
    .line 89: return-object v2
.end method

# direct methods
.method public static c(Lu/w2;ILu/w2;ZZZ)Ljava/util/List;
    .registers 28

    .line 0: move-object/from16 v0, v22
    .line 2: move/from16 v1, v23
    .line 4: move-object/from16 v2, v24
    .line 6: invoke-virtual/range {v22 .. v23}, Lu/w2;->q(I)I
    .line 9: move-result v3
    .line 10: add-int v4, v1, v3
    .line 12: iget-object v5, v0, Lu/w2;->b:[I
    .line 14: invoke-virtual/range {v22 .. v23}, Lu/w2;->p(I)I
    .line 17: move-result v6
    .line 18: invoke-virtual {v0, v6, v5}, Lu/w2;->g(I[I)I
    .line 21: move-result v5
    .line 22: iget-object v6, v0, Lu/w2;->b:[I
    .line 24: invoke-virtual {v0, v4}, Lu/w2;->p(I)I
    .line 27: move-result v7
    .line 28: invoke-virtual {v0, v7, v6}, Lu/w2;->g(I[I)I
    .line 31: move-result v6
    .line 32: sub-int v7, v6, v5
    .line 34: const/4 v8, 1
    .line 35: if-ltz v1, :cond_55
    .line 37: iget-object v10, v0, Lu/w2;->b:[I
    .line 39: invoke-virtual/range {v22 .. v23}, Lu/w2;->p(I)I
    .line 42: move-result v11
    .line 43: mul-int/lit8 v11, v11, 5
    .line 45: add-int/2addr v11, v8
    .line 46: aget v10, v10, v11
    .line 48: const/high16 v11, 0xc00
    .line 50: and-int/2addr v10, v11
    .line 51: if-eqz v10, :cond_55
    .line 53: move v10, v8
    .line 54: goto :goto_56
    .line 55: const/4 v10, 0
    .line 56: invoke-virtual {v2, v3}, Lu/w2;->s(I)V
    .line 59: iget v11, v2, Lu/w2;->r:I
    .line 61: invoke-virtual {v2, v7, v11}, Lu/w2;->t(II)V
    .line 64: iget v11, v0, Lu/w2;->e:I
    .line 66: if-ge v11, v4, :cond_71
    .line 68: invoke-virtual {v0, v4}, Lu/w2;->w(I)V
    .line 71: iget v11, v0, Lu/w2;->j:I
    .line 73: if-ge v11, v6, :cond_78
    .line 75: invoke-virtual {v0, v6, v4}, Lu/w2;->x(II)V
    .line 78: iget-object v11, v2, Lu/w2;->b:[I
    .line 80: iget v12, v2, Lu/w2;->r:I
    .line 82: iget-object v13, v0, Lu/w2;->b:[I
    .line 84: mul-int/lit8 v14, v12, 5
    .line 86: mul-int/lit8 v15, v1, 5
    .line 88: mul-int/lit8 v9, v4, 5
    .line 90: invoke-static {v13, v11, v14, v15, v9}, Lt2/k;->M0([I[IIII)V
    .line 93: iget-object v9, v2, Lu/w2;->c:[Ljava/lang/Object;
    .line 95: iget v13, v2, Lu/w2;->h:I
    .line 97: iget-object v15, v0, Lu/w2;->c:[Ljava/lang/Object;
    .line 99: invoke-static {v15, v9, v13, v5, v6}, Lt2/k;->N0([Ljava/lang/Object;[Ljava/lang/Object;III)V
    .line 102: iget v6, v2, Lu/w2;->s:I
    .line 104: add-int/lit8 v14, v14, 2
    .line 106: aput v6, v11, v14
    .line 108: sub-int v14, v12, v1
    .line 110: add-int v15, v12, v3
    .line 112: invoke-virtual {v2, v12, v11}, Lu/w2;->g(I[I)I
    .line 115: move-result v17
    .line 116: sub-int v17, v13, v17
    .line 118: iget v8, v2, Lu/w2;->l:I
    .line 120: move/from16 v18, v8
    .line 122: iget v8, v2, Lu/w2;->k:I
    .line 124: array-length v9, v9
    .line 125: move/from16 v19, v6
    .line 127: move/from16 v6, v18
    .line 129: move/from16 v18, v10
    .line 131: move v10, v12
    .line 132: if-ge v10, v15, :cond_185
    .line 134: if-eq v10, v12, :cond_146
    .line 136: mul-int/lit8 v20, v10, 5
    .line 138: add-int/lit8 v20, v20, 2
    .line 140: aget v21, v11, v20
    .line 142: add-int v21, v21, v14
    .line 144: aput v21, v11, v20
    .line 146: invoke-virtual {v2, v10, v11}, Lu/w2;->g(I[I)I
    .line 149: move-result v20
    .line 150: move/from16 v21, v13
    .line 152: add-int v13, v20, v17
    .line 154: if-ge v6, v10, :cond_160
    .line 156: move/from16 v20, v15
    .line 158: const/4 v15, 0
    .line 159: goto :goto_164
    .line 160: move/from16 v20, v15
    .line 162: iget v15, v2, Lu/w2;->j:I
    .line 164: invoke-static {v13, v15, v8, v9}, Lu/w2;->i(IIII)I
    .line 167: move-result v13
    .line 168: mul-int/lit8 v15, v10, 5
    .line 170: add-int/lit8 v15, v15, 4
    .line 172: aput v13, v11, v15
    .line 174: if-ne v10, v6, :cond_178
    .line 176: add-int/lit8 v6, v6, 1
    .line 178: add-int/lit8 v10, v10, 1
    .line 180: move/from16 v15, v20
    .line 182: move/from16 v13, v21
    .line 184: goto :goto_132
    .line 185: move/from16 v21, v13
    .line 187: move/from16 v20, v15
    .line 189: iput v6, v2, Lu/w2;->l:I
    .line 191: iget-object v6, v0, Lu/w2;->d:Ljava/util/ArrayList;
    .line 193: invoke-virtual/range {v22 .. v22}, Lu/w2;->o()I
    .line 196: move-result v8
    .line 197: invoke-static {v6, v1, v8}, Ln3/a0;->t(Ljava/util/ArrayList;II)I
    .line 200: move-result v6
    .line 201: iget-object v8, v0, Lu/w2;->d:Ljava/util/ArrayList;
    .line 203: invoke-virtual/range {v22 .. v22}, Lu/w2;->o()I
    .line 206: move-result v9
    .line 207: invoke-static {v8, v4, v9}, Ln3/a0;->t(Ljava/util/ArrayList;II)I
    .line 210: move-result v4
    .line 211: if-ge v6, v4, :cond_272
    .line 213: iget-object v8, v0, Lu/w2;->d:Ljava/util/ArrayList;
    .line 215: new-instance v9, Ljava/util/ArrayList;
    .line 217: sub-int v10, v4, v6
    .line 219: invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V
    .line 222: move v10, v6
    .line 223: if-ge v10, v4, :cond_247
    .line 225: invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 228: move-result-object v13
    .line 229: const-string v15, "sourceAnchors[anchorIndex]"
    .line 231: invoke-static {v13, v15}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 234: check-cast v13, Lu/b;
    .line 236: iget v15, v13, Lu/b;->a:I
    .line 238: add-int/2addr v15, v14
    .line 239: iput v15, v13, Lu/b;->a:I
    .line 241: invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 244: add-int/lit8 v10, v10, 1
    .line 246: goto :goto_223
    .line 247: iget-object v10, v2, Lu/w2;->d:Ljava/util/ArrayList;
    .line 249: iget v13, v2, Lu/w2;->r:I
    .line 251: invoke-virtual/range {v24 .. v24}, Lu/w2;->o()I
    .line 254: move-result v14
    .line 255: invoke-static {v10, v13, v14}, Ln3/a0;->t(Ljava/util/ArrayList;II)I
    .line 258: move-result v10
    .line 259: iget-object v13, v2, Lu/w2;->d:Ljava/util/ArrayList;
    .line 261: invoke-virtual {v13, v10, v9}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z
    .line 264: invoke-virtual {v8, v6, v4}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;
    .line 267: move-result-object v4
    .line 268: invoke-interface {v4}, Ljava/util/List;->clear()V
    .line 271: goto :goto_274
    .line 272: sget-object v9, Lt2/r;->i:Lt2/r;
    .line 274: iget-object v4, v0, Lu/w2;->b:[I
    .line 276: invoke-virtual {v0, v1, v4}, Lu/w2;->y(I[I)I
    .line 279: move-result v4
    .line 280: if-nez v27, :cond_286
    .line 282: const/4 v4, 1
    .line 283: const/16 v16, 0
    .line 285: goto :goto_348
    .line 286: if-eqz v25, :cond_337
    .line 288: if-ltz v4, :cond_293
    .line 290: const/16 v16, 1
    .line 292: goto :goto_295
    .line 293: const/16 v16, 0
    .line 295: if-eqz v16, :cond_309
    .line 297: invoke-virtual/range {v22 .. v22}, Lu/w2;->G()V
    .line 300: iget v3, v0, Lu/w2;->r:I
    .line 302: sub-int/2addr v4, v3
    .line 303: invoke-virtual {v0, v4}, Lu/w2;->a(I)V
    .line 306: invoke-virtual/range {v22 .. v22}, Lu/w2;->G()V
    .line 309: iget v3, v0, Lu/w2;->r:I
    .line 311: sub-int/2addr v1, v3
    .line 312: invoke-virtual {v0, v1}, Lu/w2;->a(I)V
    .line 315: invoke-virtual/range {v22 .. v22}, Lu/w2;->A()Z
    .line 318: move-result v1
    .line 319: if-eqz v16, :cond_333
    .line 321: invoke-virtual/range {v22 .. v22}, Lu/w2;->E()V
    .line 324: invoke-virtual/range {v22 .. v22}, Lu/w2;->j()V
    .line 327: invoke-virtual/range {v22 .. v22}, Lu/w2;->E()V
    .line 330: invoke-virtual/range {v22 .. v22}, Lu/w2;->j()V
    .line 333: move/from16 v16, v1
    .line 335: const/4 v4, 1
    .line 336: goto :goto_348
    .line 337: invoke-virtual {v0, v1, v3}, Lu/w2;->B(II)Z
    .line 340: move-result v3
    .line 341: const/4 v4, 1
    .line 342: sub-int/2addr v1, v4
    .line 343: invoke-virtual {v0, v5, v7, v1}, Lu/w2;->C(III)V
    .line 346: move/from16 v16, v3
    .line 348: xor-int/lit8 v0, v16, 1
    .line 350: if-eqz v0, :cond_387
    .line 352: iget v0, v2, Lu/w2;->n:I
    .line 354: invoke-static {v12, v11}, Ln3/a0;->s(I[I)Z
    .line 357: move-result v1
    .line 358: if-eqz v1, :cond_362
    .line 360: move v8, v4
    .line 361: goto :goto_366
    .line 362: invoke-static {v12, v11}, Ln3/a0;->u(I[I)I
    .line 365: move-result v8
    .line 366: add-int/2addr v0, v8
    .line 367: iput v0, v2, Lu/w2;->n:I
    .line 369: if-eqz v26, :cond_379
    .line 371: move/from16 v12, v20
    .line 373: iput v12, v2, Lu/w2;->r:I
    .line 375: add-int v13, v21, v7
    .line 377: iput v13, v2, Lu/w2;->h:I
    .line 379: if-eqz v18, :cond_386
    .line 381: move/from16 v0, v19
    .line 383: invoke-virtual {v2, v0}, Lu/w2;->K(I)V
    .line 386: return-object v9
    .line 387: const-string v0, "Unexpectedly removed anchors"
    .line 389: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 392: move-result-object v0
    .line 393: invoke-static {v0}, Lu/c0;->e(Ljava/lang/String;)V
    .line 396: const/4 v0, 0
    .line 397: throw v0
.end method

# direct methods
.method public static d(Ll1/e0;Lo/h1;Lf1/z;Lx0/q;Ll1/l0;ZLl1/p;)V
    .registers 9

    .line 0: const-string v0, "value"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "textDelegate"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "textLayoutResult"
    .line 12: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: const-string v0, "offsetMapping"
    .line 17: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: if-nez v7, :cond_23
    .line 22: return-void
    .line 23: iget-wide v0, v2, Ll1/e0;->b:J
    .line 25: invoke-static {v0, v1}, Lf1/a0;->c(J)I
    .line 28: move-result v2
    .line 29: invoke-interface {v8, v2}, Ll1/p;->a(I)I
    .line 32: move-result v2
    .line 33: iget-object v7, v4, Lf1/z;->a:Lf1/y;
    .line 35: iget-object v7, v7, Lf1/y;->a:Lf1/e;
    .line 37: iget-object v7, v7, Lf1/e;->a:Ljava/lang/String;
    .line 39: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 42: move-result v7
    .line 43: if-ge v2, v7, :cond_50
    .line 45: invoke-virtual {v4, v2}, Lf1/z;->b(I)Lj0/d;
    .line 48: move-result-object v2
    .line 49: goto :goto_86
    .line 50: if-eqz v2, :cond_59
    .line 52: add-int/lit8 v2, v2, -1
    .line 54: invoke-virtual {v4, v2}, Lf1/z;->b(I)Lj0/d;
    .line 57: move-result-object v2
    .line 58: goto :goto_86
    .line 59: iget-object v2, v3, Lo/h1;->b:Lf1/b0;
    .line 61: iget-object v4, v3, Lo/h1;->g:Lr1/b;
    .line 63: iget-object v3, v3, Lo/h1;->h:Lk1/r;
    .line 65: invoke-static {v2, v4, v3}, Lo/o1;->b(Lf1/b0;Lr1/b;Lk1/r;)J
    .line 68: move-result-wide v2
    .line 69: new-instance v4, Lj0/d;
    .line 71: const-wide v7, 0x00ffffffff
    .line 76: and-long/2addr v2, v7
    .line 77: long-to-int v2, v2
    .line 78: int-to-float v2, v2
    .line 79: const/4 v3, 0
    .line 80: const/high16 v7, 0x3f80
    .line 82: invoke-direct {v4, v3, v3, v7, v2}, Lj0/d;-><init>(FFFF)V
    .line 85: move-object v2, v4
    .line 86: iget v3, v2, Lj0/d;->a:F
    .line 88: iget v4, v2, Lj0/d;->b:F
    .line 90: invoke-static {v3, v4}, Ln3/a0;->g(FF)J
    .line 93: move-result-wide v3
    .line 94: invoke-interface {v5, v3, v4}, Lx0/q;->g(J)J
    .line 97: move-result-wide v3
    .line 98: invoke-static {v3, v4}, Lj0/c;->c(J)F
    .line 101: move-result v5
    .line 102: invoke-static {v3, v4}, Lj0/c;->d(J)F
    .line 105: move-result v3
    .line 106: invoke-static {v5, v3}, Ln3/a0;->g(FF)J
    .line 109: move-result-wide v3
    .line 110: invoke-virtual {v2}, Lj0/d;->c()F
    .line 113: move-result v5
    .line 114: invoke-virtual {v2}, Lj0/d;->b()F
    .line 117: move-result v2
    .line 118: invoke-static {v5, v2}, Ld2/c;->f(FF)J
    .line 121: move-result-wide v7
    .line 122: invoke-static {v3, v4, v7, v8}, Lo/g1;->b(JJ)Lj0/d;
    .line 125: move-result-object v2
    .line 126: invoke-virtual {v6}, Ll1/l0;->a()Z
    .line 129: move-result v3
    .line 130: if-eqz v3, :cond_192
    .line 132: iget-object v3, v6, Ll1/l0;->b:Ll1/x;
    .line 134: check-cast v3, Ll1/i0;
    .line 136: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 139: new-instance v4, Landroid/graphics/Rect;
    .line 141: iget v5, v2, Lj0/d;->a:F
    .line 143: invoke-static {v5}, Ld2/b;->a1(F)I
    .line 146: move-result v5
    .line 147: iget v6, v2, Lj0/d;->b:F
    .line 149: invoke-static {v6}, Ld2/b;->a1(F)I
    .line 152: move-result v6
    .line 153: iget v7, v2, Lj0/d;->c:F
    .line 155: invoke-static {v7}, Ld2/b;->a1(F)I
    .line 158: move-result v7
    .line 159: iget v2, v2, Lj0/d;->d:F
    .line 161: invoke-static {v2}, Ld2/b;->a1(F)I
    .line 164: move-result v2
    .line 165: invoke-direct {v4, v5, v6, v7, v2}, Landroid/graphics/Rect;-><init>(IIII)V
    .line 168: iput-object v4, v3, Ll1/i0;->k:Landroid/graphics/Rect;
    .line 170: iget-object v2, v3, Ll1/i0;->i:Ljava/util/ArrayList;
    .line 172: invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z
    .line 175: move-result v2
    .line 176: if-eqz v2, :cond_192
    .line 178: iget-object v2, v3, Ll1/i0;->k:Landroid/graphics/Rect;
    .line 180: if-eqz v2, :cond_192
    .line 182: new-instance v4, Landroid/graphics/Rect;
    .line 184: invoke-direct {v4, v2}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V
    .line 187: iget-object v2, v3, Ll1/i0;->a:Landroid/view/View;
    .line 189: invoke-virtual {v2, v4}, Landroid/view/View;->requestRectangleOnScreen(Landroid/graphics/Rect;)Z
    .line 192: return-void
.end method

# direct methods
.method public static e(Ljava/util/List;Ll1/h;Ld3/c;Ll1/l0;)V
    .registers 5

    .line 0: const-string v0, "ops"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "editProcessor"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "onValueChange"
    .line 12: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: invoke-virtual {v2, v1}, Ll1/h;->a(Ljava/util/List;)Ll1/e0;
    .line 18: move-result-object v1
    .line 19: if-eqz v4, :cond_25
    .line 21: const/4 v2, 0
    .line 22: invoke-virtual {v4, v2, v1}, Ll1/l0;->b(Ll1/e0;Ll1/e0;)V
    .line 25: invoke-interface {v3, v1}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 28: return-void
.end method

# direct methods
.method public static f(Ll1/f0;Ll1/e0;Ll1/h;Ll1/m;Lo/u;Lo/u;)Ll1/l0;
    .registers 10

    .line 0: const-string v0, "textInputService"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "value"
    .line 7: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "editProcessor"
    .line 12: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: const-string v0, "imeOptions"
    .line 17: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: const-string v0, "onValueChange"
    .line 22: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: const-string v0, "onImeActionPerformed"
    .line 27: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 30: new-instance v0, Le3/s;
    .line 32: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 35: new-instance v1, Lg/p;
    .line 37: const/4 v2, 4
    .line 38: invoke-direct {v1, v6, v8, v0, v2}, Lg/p;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .line 41: iget-object v6, v4, Ll1/f0;->a:Ll1/x;
    .line 43: move-object v8, v6
    .line 44: check-cast v8, Ll1/i0;
    .line 46: invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 49: iget-object v2, v8, Ll1/i0;->c:Ll1/u;
    .line 51: if-eqz v2, :cond_59
    .line 53: iget-object v3, v2, Ll1/u;->b:Ll1/w;
    .line 55: iget-object v2, v2, Ll1/u;->a:Ll1/s;
    .line 57: iput-object v2, v3, Ll1/w;->c:Ll1/s;
    .line 59: iput-object v5, v8, Ll1/i0;->g:Ll1/e0;
    .line 61: iput-object v7, v8, Ll1/i0;->h:Ll1/m;
    .line 63: iput-object v1, v8, Ll1/i0;->e:Ld3/c;
    .line 65: iput-object v9, v8, Ll1/i0;->f:Ld3/c;
    .line 67: sget-object v5, Ll1/g0;->i:Ll1/g0;
    .line 69: invoke-virtual {v8, v5}, Ll1/i0;->a(Ll1/g0;)V
    .line 72: new-instance v5, Ll1/l0;
    .line 74: invoke-direct {v5, v4, v6}, Ll1/l0;-><init>(Ll1/f0;Ll1/x;)V
    .line 77: iget-object v4, v4, Ll1/f0;->b:Ljava/util/concurrent/atomic/AtomicReference;
    .line 79: invoke-virtual {v4, v5}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    .line 82: iput-object v5, v0, Le3/s;->i:Ljava/lang/Object;
    .line 84: return-object v5
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget v0, v1, Landroidx/activity/b;->a:I
    .line 2: packed-switch v0, :data_14
    .line 5: invoke-super {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 8: move-result-object v0
    .line 9: return-object v0
    .line 10: const-string v0, "Empty"
    .line 12: return-object v0
    .line 13: nop
    .line 14: nop
    .line 15: move v0, v0
    .line 16: return v0
    .line 17: nop
    .line 18: move-object/from16 v0, v0
.end method

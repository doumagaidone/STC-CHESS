.class public final Landroidx/activity/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Ljava/lang/Object;
.field public b:Landroidx/lifecycle/t0;

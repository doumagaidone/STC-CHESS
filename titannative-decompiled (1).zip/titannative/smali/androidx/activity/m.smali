.class public final Landroidx/activity/m;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/Object;
.field public b:Z
.field public final c:Ljava/util/ArrayList;

# direct methods
.method public constructor <init>(Landroidx/activity/l;Landroidx/activity/e;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v1, Ljava/lang/Object;
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v1, v0, Landroidx/activity/m;->a:Ljava/lang/Object;
    .line 10: new-instance v1, Ljava/util/ArrayList;
    .line 12: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 15: iput-object v1, v0, Landroidx/activity/m;->c:Ljava/util/ArrayList;
    .line 17: return-void
.end method

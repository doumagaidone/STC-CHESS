.class public abstract Landroidx/activity/i;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/app/Activity;)Landroid/window/OnBackInvokedDispatcher;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/app/Activity;->getOnBackInvokedDispatcher()Landroid/window/OnBackInvokedDispatcher;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

.class public abstract Landroidx/activity/result/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/HashMap;
.field public final b:Ljava/util/HashMap;
.field public final c:Ljava/util/HashMap;
.field public d:Ljava/util/ArrayList;
.field public final transient e:Ljava/util/HashMap;
.field public final f:Ljava/util/HashMap;
.field public final g:Landroid/os/Bundle;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/activity/result/h;->a:Ljava/util/HashMap;
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: iput-object v0, v1, Landroidx/activity/result/h;->b:Ljava/util/HashMap;
    .line 17: new-instance v0, Ljava/util/HashMap;
    .line 19: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 22: iput-object v0, v1, Landroidx/activity/result/h;->c:Ljava/util/HashMap;
    .line 24: new-instance v0, Ljava/util/ArrayList;
    .line 26: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 29: iput-object v0, v1, Landroidx/activity/result/h;->d:Ljava/util/ArrayList;
    .line 31: new-instance v0, Ljava/util/HashMap;
    .line 33: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 36: iput-object v0, v1, Landroidx/activity/result/h;->e:Ljava/util/HashMap;
    .line 38: new-instance v0, Ljava/util/HashMap;
    .line 40: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 43: iput-object v0, v1, Landroidx/activity/result/h;->f:Ljava/util/HashMap;
    .line 45: new-instance v0, Landroid/os/Bundle;
    .line 47: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    .line 50: iput-object v0, v1, Landroidx/activity/result/h;->g:Landroid/os/Bundle;
    .line 52: return-void
.end method

# virtual methods
.method public final a(IILandroid/content/Intent;)Z
    .registers 5

    .line 0: iget-object v0, v1, Landroidx/activity/result/h;->a:Ljava/util/HashMap;
    .line 2: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 5: move-result-object v2
    .line 6: invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v2
    .line 10: check-cast v2, Ljava/lang/String;
    .line 12: if-nez v2, :cond_16
    .line 14: const/4 v2, 0
    .line 15: return v2
    .line 16: iget-object v0, v1, Landroidx/activity/result/h;->e:Ljava/util/HashMap;
    .line 18: invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 21: move-result-object v0
    .line 22: check-cast v0, Landroidx/activity/result/f;
    .line 24: iget-object v0, v1, Landroidx/activity/result/h;->f:Ljava/util/HashMap;
    .line 26: invoke-virtual {v0, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 29: new-instance v0, Landroidx/activity/result/b;
    .line 31: invoke-direct {v0, v4, v3}, Landroidx/activity/result/b;-><init>(Landroid/content/Intent;I)V
    .line 34: iget-object v3, v1, Landroidx/activity/result/h;->g:Landroid/os/Bundle;
    .line 36: invoke-virtual {v3, v2, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    .line 39: const/4 v2, 1
    .line 40: return v2
.end method

# virtual methods
.method public final b(Ljava/lang/String;Landroidx/lifecycle/t;)Landroidx/activity/result/e;
    .registers 9

    .line 0: invoke-interface {v8}, Landroidx/lifecycle/t;->getLifecycle()Landroidx/lifecycle/o;
    .line 3: move-result-object v0
    .line 4: move-object v1, v0
    .line 5: check-cast v1, Landroidx/lifecycle/v;
    .line 7: iget-object v2, v1, Landroidx/lifecycle/v;->c:Landroidx/lifecycle/n;
    .line 9: sget-object v3, Landroidx/lifecycle/n;->l:Landroidx/lifecycle/n;
    .line 11: invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I
    .line 14: move-result v2
    .line 15: if-gez v2, :cond_129
    .line 17: iget-object v8, v6, Landroidx/activity/result/h;->b:Ljava/util/HashMap;
    .line 19: invoke-virtual {v8, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 22: move-result-object v1
    .line 23: check-cast v1, Ljava/lang/Integer;
    .line 25: if-eqz v1, :cond_28
    .line 27: goto :goto_90
    .line 28: sget-object v1, Lh3/d;->i:Lh3/c;
    .line 30: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 33: sget-object v1, Lh3/d;->j:Lh3/a;
    .line 35: invoke-virtual {v1}, Lh3/a;->a()Ljava/util/Random;
    .line 38: move-result-object v1
    .line 39: const/high16 v2, 0x7fff
    .line 41: invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I
    .line 44: move-result v1
    .line 45: const/high16 v3, 0x1
    .line 47: add-int/2addr v1, v3
    .line 48: iget-object v4, v6, Landroidx/activity/result/h;->a:Ljava/util/HashMap;
    .line 50: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 53: move-result-object v5
    .line 54: invoke-virtual {v4, v5}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z
    .line 57: move-result v5
    .line 58: if-eqz v5, :cond_76
    .line 60: sget-object v1, Lh3/d;->i:Lh3/c;
    .line 62: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 65: sget-object v1, Lh3/d;->j:Lh3/a;
    .line 67: invoke-virtual {v1}, Lh3/a;->a()Ljava/util/Random;
    .line 70: move-result-object v1
    .line 71: invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I
    .line 74: move-result v1
    .line 75: goto :goto_47
    .line 76: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 79: move-result-object v2
    .line 80: invoke-virtual {v4, v2, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 83: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 86: move-result-object v1
    .line 87: invoke-virtual {v8, v7, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 90: iget-object v8, v6, Landroidx/activity/result/h;->c:Ljava/util/HashMap;
    .line 92: invoke-virtual {v8, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 95: move-result-object v1
    .line 96: check-cast v1, Landroidx/activity/result/g;
    .line 98: if-nez v1, :cond_105
    .line 100: new-instance v1, Landroidx/activity/result/g;
    .line 102: invoke-direct {v1, v0}, Landroidx/activity/result/g;-><init>(Landroidx/lifecycle/o;)V
    .line 105: new-instance v0, Landroidx/activity/result/ActivityResultRegistry$1;
    .line 107: invoke-direct {v0, v6, v7}, Landroidx/activity/result/ActivityResultRegistry$1;-><init>(Landroidx/activity/result/h;Ljava/lang/String;)V
    .line 110: iget-object v2, v1, Landroidx/activity/result/g;->a:Landroidx/lifecycle/o;
    .line 112: invoke-virtual {v2, v0}, Landroidx/lifecycle/o;->a(Landroidx/lifecycle/s;)V
    .line 115: iget-object v2, v1, Landroidx/activity/result/g;->b:Ljava/util/ArrayList;
    .line 117: invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 120: invoke-virtual {v8, v7, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 123: new-instance v7, Landroidx/activity/result/e;
    .line 125: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 128: return-object v7
    .line 129: new-instance v7, Ljava/lang/IllegalStateException;
    .line 131: new-instance v0, Ljava/lang/StringBuilder;
    .line 133: const-string v2, "LifecycleOwner "
    .line 135: invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 138: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 141: const-string v8, " is attempting to register while current state is "
    .line 143: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 146: iget-object v8, v1, Landroidx/lifecycle/v;->c:Landroidx/lifecycle/n;
    .line 148: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 151: const-string v8, ". LifecycleOwners must call register before they are STARTED."
    .line 153: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 156: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 159: move-result-object v8
    .line 160: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 163: throw v7
.end method

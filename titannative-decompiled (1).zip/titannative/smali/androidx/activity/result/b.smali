.class public final Landroidx/activity/result/b;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/os/Parcelable;

.field public static final CREATOR:Landroid/os/Parcelable$Creator;

.field public final i:I
.field public final j:Landroid/content/Intent;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Landroidx/activity/result/a;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v1}, Landroidx/activity/result/a;-><init>(I)V
    .line 6: sput-object v0, Landroidx/activity/result/b;->CREATOR:Landroid/os/Parcelable$Creator;
    .line 8: return-void
.end method

# direct methods
.method public constructor <init>(Landroid/content/Intent;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v2, v0, Landroidx/activity/result/b;->i:I
    .line 5: iput-object v1, v0, Landroidx/activity/result/b;->j:Landroid/content/Intent;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    .line 6: move-result v0
    .line 7: iput v0, v1, Landroidx/activity/result/b;->i:I
    .line 9: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    .line 12: move-result v0
    .line 13: if-nez v0, :cond_17
    .line 15: const/4 v2, 0
    .line 16: goto :goto_25
    .line 17: sget-object v0, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;
    .line 19: invoke-interface {v0, v2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .line 22: move-result-object v2
    .line 23: check-cast v2, Landroid/content/Intent;
    .line 25: iput-object v2, v1, Landroidx/activity/result/b;->j:Landroid/content/Intent;
    .line 27: return-void
.end method

# virtual methods
.method public final describeContents()I
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ActivityResult{resultCode="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: const/4 v1, -1
    .line 8: iget v2, v3, Landroidx/activity/result/b;->i:I
    .line 10: if-eq v2, v1, :cond_22
    .line 12: if-eqz v2, :cond_19
    .line 14: invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 17: move-result-object v1
    .line 18: goto :goto_24
    .line 19: const-string v1, "RESULT_CANCELED"
    .line 21: goto :goto_24
    .line 22: const-string v1, "RESULT_OK"
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: const-string v1, ", data="
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: iget-object v1, v3, Landroidx/activity/result/b;->j:Landroid/content/Intent;
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 37: const/16 v1, 125
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 42: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 45: move-result-object v0
    .line 46: return-object v0
.end method

# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 5

    .line 0: iget v0, v2, Landroidx/activity/result/b;->i:I
    .line 2: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    .line 5: iget-object v0, v2, Landroidx/activity/result/b;->j:Landroid/content/Intent;
    .line 7: if-nez v0, :cond_11
    .line 9: const/4 v1, 0
    .line 10: goto :goto_12
    .line 11: const/4 v1, 1
    .line 12: invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeInt(I)V
    .line 15: if-eqz v0, :cond_20
    .line 17: invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->writeToParcel(Landroid/os/Parcel;I)V
    .line 20: return-void
.end method

.class public final Landroidx/activity/result/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroidx/lifecycle/o;
.field public final b:Ljava/util/ArrayList;

# direct methods
.method public constructor <init>(Landroidx/lifecycle/o;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/activity/result/g;->a:Landroidx/lifecycle/o;
    .line 5: new-instance v1, Ljava/util/ArrayList;
    .line 7: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 10: iput-object v1, v0, Landroidx/activity/result/g;->b:Ljava/util/ArrayList;
    .line 12: return-void
.end method

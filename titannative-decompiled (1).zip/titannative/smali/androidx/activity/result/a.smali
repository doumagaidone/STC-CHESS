.class public final Landroidx/activity/result/a;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/os/Parcelable$Creator;

.field public final synthetic a:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Landroidx/activity/result/a;->a:I
    .line 5: return-void
.end method

# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 5

    .line 0: iget v0, v3, Landroidx/activity/result/a;->a:I
    .line 2: const-string v1, "parcel"
    .line 4: packed-switch v0, :data_58
    .line 7: new-instance v0, Landroidx/versionedparcelable/ParcelImpl;
    .line 9: invoke-direct {v0, v4}, Landroidx/versionedparcelable/ParcelImpl;-><init>(Landroid/os/Parcel;)V
    .line 12: return-object v0
    .line 13: invoke-static {v4, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: new-instance v0, Lu/q1;
    .line 18: invoke-virtual {v4}, Landroid/os/Parcel;->readLong()J
    .line 21: move-result-wide v1
    .line 22: invoke-direct {v0, v1, v2}, Lu/q1;-><init>(J)V
    .line 25: return-object v0
    .line 26: invoke-static {v4, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 29: new-instance v0, Lu/p1;
    .line 31: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    .line 34: move-result v4
    .line 35: invoke-direct {v0, v4}, Lu/p1;-><init>(I)V
    .line 38: return-object v0
    .line 39: invoke-static {v4, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 42: new-instance v0, Lu/o1;
    .line 44: invoke-virtual {v4}, Landroid/os/Parcel;->readFloat()F
    .line 47: move-result v4
    .line 48: invoke-direct {v0, v4}, Lu/o1;-><init>(F)V
    .line 51: return-object v0
    .line 52: new-instance v0, Landroidx/activity/result/b;
    .line 54: invoke-direct {v0, v4}, Landroidx/activity/result/b;-><init>(Landroid/os/Parcel;)V
    .line 57: return-object v0
    .line 58: nop
    .line 59: move-wide v0, v0
    .line 60: nop
    .line 61: nop
    .line 62: cmpg-double v0, v0, v0
    .line 64: new-array v0, v0, B
    .line 66: const-wide/16 v0, 0
    .line 68: move-object/16 v0, v3
.end method

# virtual methods
.method public final newArray(I)[Ljava/lang/Object;
    .registers 3

    .line 0: iget v0, v1, Landroidx/activity/result/a;->a:I
    .line 2: packed-switch v0, :data_20
    .line 5: new-array v2, v2, [Landroidx/versionedparcelable/ParcelImpl;
    .line 7: return-object v2
    .line 8: new-array v2, v2, [Lu/q1;
    .line 10: return-object v2
    .line 11: new-array v2, v2, [Lu/p1;
    .line 13: return-object v2
    .line 14: new-array v2, v2, [Lu/o1;
    .line 16: return-object v2
    .line 17: new-array v2, v2, [Landroidx/activity/result/b;
    .line 19: return-object v2
    .line 20: nop
    .line 21: move-wide v0, v0
    .line 22: nop
    .line 23: nop
    .line 24: return v0
    .line 25: nop
    .line 26: move-result-object v0
    .line 27: nop
    .line 28: move-object/16 v0, v6
    .line 31: nop
.end method

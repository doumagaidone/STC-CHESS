.class public final Landroidx/activity/h;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final synthetic j:Landroid/view/KeyEvent$Callback;

# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v2, v0, Landroidx/activity/h;->i:I
    .line 5: iput-object v1, v0, Landroidx/activity/h;->j:Landroid/view/KeyEvent$Callback;
    .line 7: return-void
.end method

# virtual methods
.method public final run()V
    .registers 9

    .line 0: iget v0, v8, Landroidx/activity/h;->i:I
    .line 2: iget-object v1, v8, Landroidx/activity/h;->j:Landroid/view/KeyEvent$Callback;
    .line 4: packed-switch v0, :data_96
    .line 7: move-object v2, v1
    .line 8: check-cast v2, Landroidx/compose/ui/platform/AndroidComposeView;
    .line 10: invoke-virtual {v2, v8}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z
    .line 13: iget-object v3, v2, Landroidx/compose/ui/platform/AndroidComposeView;->o0:Landroid/view/MotionEvent;
    .line 15: if-eqz v3, :cond_57
    .line 17: const/4 v0, 0
    .line 18: invoke-virtual {v3, v0}, Landroid/view/MotionEvent;->getToolType(I)I
    .line 21: move-result v1
    .line 22: const/4 v4, 3
    .line 23: const/4 v5, 1
    .line 24: if-ne v1, v4, :cond_27
    .line 26: move v0, v5
    .line 27: invoke-virtual {v3}, Landroid/view/MotionEvent;->getActionMasked()I
    .line 30: move-result v1
    .line 31: if-eqz v0, :cond_40
    .line 33: const/16 v0, 10
    .line 35: if-eq v1, v0, :cond_57
    .line 37: if-eq v1, v5, :cond_57
    .line 39: goto :goto_42
    .line 40: if-eq v1, v5, :cond_57
    .line 42: const/4 v0, 7
    .line 43: if-eq v1, v0, :cond_50
    .line 45: const/16 v4, 9
    .line 47: if-eq v1, v4, :cond_50
    .line 49: const/4 v0, 2
    .line 50: move v4, v0
    .line 51: iget-wide v5, v2, Landroidx/compose/ui/platform/AndroidComposeView;->p0:J
    .line 53: const/4 v7, 0
    .line 54: invoke-virtual/range {v2 .. v7}, Landroidx/compose/ui/platform/AndroidComposeView;->D(Landroid/view/MotionEvent;IJZ)V
    .line 57: return-void
    .line 58: check-cast v1, Landroidx/activity/ComponentActivity;
    .line 60: invoke-static {v1}, Landroidx/activity/ComponentActivity;->access$001(Landroidx/activity/ComponentActivity;)V
    .line 63: goto :goto_94
    .line 64: move-exception v0
    .line 65: goto :goto_68
    .line 66: move-exception v0
    .line 67: goto :goto_82
    .line 68: invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    .line 71: move-result-object v1
    .line 72: const-string v2, "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference"
    .line 74: invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    .line 77: move-result v1
    .line 78: if-eqz v1, :cond_81
    .line 80: goto :goto_94
    .line 81: throw v0
    .line 82: invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    .line 85: move-result-object v1
    .line 86: const-string v2, "Can not perform this action after onSaveInstanceState"
    .line 88: invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    .line 91: move-result v1
    .line 92: if-eqz v1, :cond_95
    .line 94: return-void
    .line 95: throw v0
    .line 96: nop
    .line 97: move v0, v0
    .line 98: nop
    .line 99: nop
    .line 100: if-gt v0, v0, :cond_100
.end method

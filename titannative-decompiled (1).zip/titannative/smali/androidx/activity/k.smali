.class public abstract interface Landroidx/activity/k;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/concurrent/Executor;

# virtual methods
.method public abstract n(Landroid/view/View;)V
.end method

.class public final Landroidx/activity/q;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/activity/q;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/activity/q;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/activity/q;->a:Landroidx/activity/q;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Ld3/a;)Landroid/window/OnBackInvokedCallback;
    .registers 3

    .line 0: const-string v0, "onBackInvoked"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/activity/p;
    .line 7: invoke-direct {v0, v2}, Landroidx/activity/p;-><init>(Ld3/a;)V
    .line 10: return-object v0
.end method

# virtual methods
.method public final b(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 5

    .line 0: const-string v0, "dispatcher"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "callback"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: check-cast v2, Landroid/window/OnBackInvokedDispatcher;
    .line 12: check-cast v4, Landroid/window/OnBackInvokedCallback;
    .line 14: invoke-interface {v2, v3, v4}, Landroid/window/OnBackInvokedDispatcher;->registerOnBackInvokedCallback(ILandroid/window/OnBackInvokedCallback;)V
    .line 17: return-void
.end method

# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 0: const-string v0, "dispatcher"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "callback"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: check-cast v2, Landroid/window/OnBackInvokedDispatcher;
    .line 12: check-cast v3, Landroid/window/OnBackInvokedCallback;
    .line 14: invoke-interface {v2, v3}, Landroid/window/OnBackInvokedDispatcher;->unregisterOnBackInvokedCallback(Landroid/window/OnBackInvokedCallback;)V
    .line 17: return-void
.end method

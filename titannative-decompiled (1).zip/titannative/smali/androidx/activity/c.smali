.class public final Landroidx/activity/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F
.field public final c:F
.field public final d:I

# direct methods
.method public constructor <init>(Landroid/window/BackEvent;)V
    .registers 6

    .line 0: const-string v0, "backEvent"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Landroidx/activity/a;->a:Landroidx/activity/a;
    .line 7: invoke-virtual {v0, v5}, Landroidx/activity/a;->d(Landroid/window/BackEvent;)F
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v5}, Landroidx/activity/a;->e(Landroid/window/BackEvent;)F
    .line 14: move-result v2
    .line 15: invoke-virtual {v0, v5}, Landroidx/activity/a;->b(Landroid/window/BackEvent;)F
    .line 18: move-result v3
    .line 19: invoke-virtual {v0, v5}, Landroidx/activity/a;->c(Landroid/window/BackEvent;)I
    .line 22: move-result v5
    .line 23: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 26: iput v1, v4, Landroidx/activity/c;->a:F
    .line 28: iput v2, v4, Landroidx/activity/c;->b:F
    .line 30: iput v3, v4, Landroidx/activity/c;->c:F
    .line 32: iput v5, v4, Landroidx/activity/c;->d:I
    .line 34: return-void
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "BackEventCompat{touchX="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Landroidx/activity/c;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", touchY="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v3, Landroidx/activity/c;->b:F
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", progress="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v3, Landroidx/activity/c;->c:F
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", swipeEdge="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v3, Landroidx/activity/c;->d:I
    .line 39: const/16 v2, 125
    .line 41: invoke-static {v0, v1, v2}, Lai/onnxruntime/b;->j(Ljava/lang/StringBuilder;IC)Ljava/lang/String;
    .line 44: move-result-object v0
    .line 45: return-object v0
.end method

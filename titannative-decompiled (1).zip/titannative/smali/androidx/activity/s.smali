.class public final Landroidx/activity/s;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/activity/s;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/activity/s;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/activity/s;->a:Landroidx/activity/s;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Ld3/c;Ld3/c;Ld3/a;Ld3/a;)Landroid/window/OnBackInvokedCallback;
    .registers 6

    .line 0: const-string v0, "onBackStarted"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "onBackProgressed"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "onBackInvoked"
    .line 12: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: const-string v0, "onBackCancelled"
    .line 17: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: new-instance v0, Landroidx/activity/r;
    .line 22: invoke-direct {v0, v2, v3, v4, v5}, Landroidx/activity/r;-><init>(Ld3/c;Ld3/c;Ld3/a;Ld3/a;)V
    .line 25: return-object v0
.end method

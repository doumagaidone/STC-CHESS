.class public final Landroidx/activity/t;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/Runnable;
.field public final b:Lt2/j;
.field public final c:Landroid/window/OnBackInvokedCallback;
.field public d:Landroid/window/OnBackInvokedDispatcher;
.field public e:Z

# direct methods
.method public constructor <init>(Landroidx/activity/h;)V
    .registers 7

    .line 0: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v6, v5, Landroidx/activity/t;->a:Ljava/lang/Runnable;
    .line 5: new-instance v6, Lt2/j;
    .line 7: invoke-direct {v6}, Lt2/j;-><init>()V
    .line 10: iput-object v6, v5, Landroidx/activity/t;->b:Lt2/j;
    .line 12: sget v6, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 14: const/16 v0, 33
    .line 16: if-lt v6, v0, :cond_65
    .line 18: const/16 v0, 34
    .line 20: if-lt v6, v0, :cond_51
    .line 22: sget-object v6, Landroidx/activity/s;->a:Landroidx/activity/s;
    .line 24: new-instance v0, Landroidx/activity/n;
    .line 26: const/4 v1, 0
    .line 27: invoke-direct {v0, v5, v1}, Landroidx/activity/n;-><init>(Landroidx/activity/t;I)V
    .line 30: new-instance v2, Landroidx/activity/n;
    .line 32: const/4 v3, 1
    .line 33: invoke-direct {v2, v5, v3}, Landroidx/activity/n;-><init>(Landroidx/activity/t;I)V
    .line 36: new-instance v4, Landroidx/activity/o;
    .line 38: invoke-direct {v4, v5, v1}, Landroidx/activity/o;-><init>(Landroidx/activity/t;I)V
    .line 41: new-instance v1, Landroidx/activity/o;
    .line 43: invoke-direct {v1, v5, v3}, Landroidx/activity/o;-><init>(Landroidx/activity/t;I)V
    .line 46: invoke-virtual {v6, v0, v2, v4, v1}, Landroidx/activity/s;->a(Ld3/c;Ld3/c;Ld3/a;Ld3/a;)Landroid/window/OnBackInvokedCallback;
    .line 49: move-result-object v6
    .line 50: goto :goto_63
    .line 51: sget-object v6, Landroidx/activity/q;->a:Landroidx/activity/q;
    .line 53: new-instance v0, Landroidx/activity/o;
    .line 55: const/4 v1, 2
    .line 56: invoke-direct {v0, v5, v1}, Landroidx/activity/o;-><init>(Landroidx/activity/t;I)V
    .line 59: invoke-virtual {v6, v0}, Landroidx/activity/q;->a(Ld3/a;)Landroid/window/OnBackInvokedCallback;
    .line 62: move-result-object v6
    .line 63: iput-object v6, v5, Landroidx/activity/t;->c:Landroid/window/OnBackInvokedCallback;
    .line 65: return-void
.end method

# virtual methods
.method public final a()V
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/activity/t;->b:Lt2/j;
    .line 2: invoke-virtual {v0}, Lt2/j;->b()I
    .line 5: move-result v1
    .line 6: invoke-virtual {v0, v1}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;
    .line 9: move-result-object v0
    .line 10: invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z
    .line 13: move-result v1
    .line 14: if-nez v1, :cond_24
    .line 16: iget-object v0, v2, Landroidx/activity/t;->a:Ljava/lang/Runnable;
    .line 18: if-eqz v0, :cond_23
    .line 20: invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    .line 23: return-void
    .line 24: invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;
    .line 27: move-result-object v0
    .line 28: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 31: const/4 v0, 0
    .line 32: throw v0
.end method

# virtual methods
.method public final b()V
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/activity/t;->d:Landroid/window/OnBackInvokedDispatcher;
    .line 2: if-eqz v0, :cond_20
    .line 4: iget-object v1, v4, Landroidx/activity/t;->c:Landroid/window/OnBackInvokedCallback;
    .line 6: if-eqz v1, :cond_20
    .line 8: sget-object v2, Landroidx/activity/q;->a:Landroidx/activity/q;
    .line 10: iget-boolean v3, v4, Landroidx/activity/t;->e:Z
    .line 12: if-eqz v3, :cond_20
    .line 14: invoke-virtual {v2, v0, v1}, Landroidx/activity/q;->c(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 17: const/4 v0, 0
    .line 18: iput-boolean v0, v4, Landroidx/activity/t;->e:Z
    .line 20: return-void
.end method

.class public Landroidx/startup/InitializationProvider;
.super Landroid/content/ContentProvider;
.source "SourceFile"

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Landroid/content/ContentProvider;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method public final delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 4

    .line 0: new-instance v1, Ljava/lang/IllegalStateException;
    .line 2: const-string v2, "Not allowed."
    .line 4: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 7: throw v1
.end method

# virtual methods
.method public final getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 3

    .line 0: new-instance v2, Ljava/lang/IllegalStateException;
    .line 2: const-string v0, "Not allowed."
    .line 4: invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 7: throw v2
.end method

# virtual methods
.method public final insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 3

    .line 0: new-instance v1, Ljava/lang/IllegalStateException;
    .line 2: const-string v2, "Not allowed."
    .line 4: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 7: throw v1
.end method

# virtual methods
.method public final onCreate()Z
    .registers 6

    .line 0: invoke-virtual {v5}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_72
    .line 6: invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    .line 9: move-result-object v1
    .line 10: if-eqz v1, :cond_70
    .line 12: invoke-static {v0}, Lm2/a;->c(Landroid/content/Context;)Lm2/a;
    .line 15: move-result-object v0
    .line 16: iget-object v1, v0, Lm2/a;->c:Landroid/content/Context;
    .line 18: const-string v2, "Startup"
    .line 20: invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    .line 23: new-instance v2, Landroid/content/ComponentName;
    .line 25: invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 28: move-result-object v3
    .line 29: const-class v4, Landroidx/startup/InitializationProvider;
    .line 31: invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 34: move-result-object v4
    .line 35: invoke-direct {v2, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    .line 38: invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 41: move-result-object v1
    .line 42: const/16 v3, 128
    .line 44: invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->getProviderInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ProviderInfo;
    .line 47: move-result-object v1
    .line 48: iget-object v1, v1, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;
    .line 50: invoke-virtual {v0, v1}, Lm2/a;->a(Landroid/os/Bundle;)V
    .line 53: invoke-static {}, Landroid/os/Trace;->endSection()V
    .line 56: goto :goto_70
    .line 57: move-exception v0
    .line 58: goto :goto_66
    .line 59: move-exception v0
    .line 60: new-instance v1, Lkotlinx/coroutines/internal/z;
    .line 62: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 65: throw v1
    .line 66: invoke-static {}, Landroid/os/Trace;->endSection()V
    .line 69: throw v0
    .line 70: const/4 v0, 1
    .line 71: return v0
    .line 72: new-instance v0, Lkotlinx/coroutines/internal/z;
    .line 74: const-string v1, "Context cannot be null"
    .line 76: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 79: throw v0
.end method

# virtual methods
.method public final query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 6

    .line 0: new-instance v1, Ljava/lang/IllegalStateException;
    .line 2: const-string v2, "Not allowed."
    .line 4: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 7: throw v1
.end method

# virtual methods
.method public final update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 5

    .line 0: new-instance v1, Ljava/lang/IllegalStateException;
    .line 2: const-string v2, "Not allowed."
    .line 4: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 7: throw v1
.end method

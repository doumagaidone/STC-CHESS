.class public abstract Landroidx/compose/foundation/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf0/p;Ld3/c;Lu/l;I)V
    .registers 7

    .line 0: const-string v0, "modifier"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "onDraw"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: check-cast v5, Lu/b0;
    .line 12: const v0, 0xc8660b92
    .line 15: invoke-virtual {v5, v0}, Lu/b0;->e0(I)Lu/b0;
    .line 18: and-int/lit8 v0, v6, 14
    .line 20: if-nez v0, :cond_33
    .line 22: invoke-virtual {v5, v3}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 25: move-result v0
    .line 26: if-eqz v0, :cond_30
    .line 28: const/4 v0, 4
    .line 29: goto :goto_31
    .line 30: const/4 v0, 2
    .line 31: or-int/2addr v0, v6
    .line 32: goto :goto_34
    .line 33: move v0, v6
    .line 34: and-int/lit8 v1, v6, 112
    .line 36: if-nez v1, :cond_50
    .line 38: invoke-virtual {v5, v4}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-eqz v1, :cond_47
    .line 44: const/16 v1, 32
    .line 46: goto :goto_49
    .line 47: const/16 v1, 16
    .line 49: or-int/2addr v0, v1
    .line 50: and-int/lit8 v0, v0, 91
    .line 52: const/16 v1, 18
    .line 54: const/4 v2, 0
    .line 55: if-ne v0, v1, :cond_68
    .line 57: invoke-virtual {v5}, Lu/b0;->F()Z
    .line 60: move-result v0
    .line 61: if-nez v0, :cond_64
    .line 63: goto :goto_68
    .line 64: invoke-virtual {v5}, Lu/b0;->Y()V
    .line 67: goto :goto_75
    .line 68: invoke-static {v3, v4}, Landroidx/compose/ui/draw/a;->d(Lf0/p;Ld3/c;)Lf0/p;
    .line 71: move-result-object v0
    .line 72: invoke-static {v0, v5, v2}, Landroidx/compose/foundation/layout/a;->a(Lf0/p;Lu/l;I)V
    .line 75: invoke-virtual {v5}, Lu/b0;->x()Lu/c2;
    .line 78: move-result-object v5
    .line 79: if-nez v5, :cond_82
    .line 81: goto :goto_89
    .line 82: new-instance v0, Li/x;
    .line 84: invoke-direct {v0, v6, v2, v3, v4}, Li/x;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .line 87: iput-object v0, v5, Lu/c2;->d:Ld3/e;
    .line 89: return-void
.end method

# direct methods
.method public static final b(Ln0/b;Ljava/lang/String;Lf0/p;Lf0/d;Lx0/h;FLk0/r;Lu/l;II)V
    .registers 27

    .line 0: move-object/from16 v2, v18
    .line 2: const-string v0, "painter"
    .line 4: move-object/from16 v1, v17
    .line 6: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: move-object/from16 v0, v24
    .line 11: check-cast v0, Lu/b0;
    .line 13: const v3, 0x441d0e20
    .line 16: invoke-virtual {v0, v3}, Lu/b0;->e0(I)Lu/b0;
    .line 19: and-int/lit8 v3, v26, 4
    .line 21: sget-object v4, Lf0/m;->c:Lf0/m;
    .line 23: if-eqz v3, :cond_27
    .line 25: move-object v10, v4
    .line 26: goto :goto_29
    .line 27: move-object/from16 v10, v19
    .line 29: and-int/lit8 v3, v26, 8
    .line 31: if-eqz v3, :cond_37
    .line 33: sget-object v3, Lf0/a;->j:Lf0/g;
    .line 35: move-object v11, v3
    .line 36: goto :goto_39
    .line 37: move-object/from16 v11, v20
    .line 39: and-int/lit8 v3, v26, 16
    .line 41: if-eqz v3, :cond_47
    .line 43: sget-object v3, Lx0/g;->a:Lz3/b;
    .line 45: move-object v12, v3
    .line 46: goto :goto_49
    .line 47: move-object/from16 v12, v21
    .line 49: and-int/lit8 v3, v26, 32
    .line 51: if-eqz v3, :cond_57
    .line 53: const/high16 v3, 0x3f80
    .line 55: move v13, v3
    .line 56: goto :goto_59
    .line 57: move/from16 v13, v22
    .line 59: and-int/lit8 v3, v26, 64
    .line 61: if-eqz v3, :cond_65
    .line 63: const/4 v15, 0
    .line 64: goto :goto_67
    .line 65: move-object/from16 v15, v23
    .line 67: const v3, 0xcf50b5f5
    .line 70: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 73: const/4 v9, 0
    .line 74: if-eqz v2, :cond_113
    .line 76: const v3, 0x44faf204
    .line 79: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 82: invoke-virtual {v0, v2}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 85: move-result v3
    .line 86: invoke-virtual {v0}, Lu/b0;->I()Ljava/lang/Object;
    .line 89: move-result-object v5
    .line 90: if-nez v3, :cond_96
    .line 92: sget-object v3, Lu/k;->i:Landroidx/activity/b;
    .line 94: if-ne v5, v3, :cond_104
    .line 96: new-instance v5, Li/f1;
    .line 98: invoke-direct {v5, v9, v2}, Li/f1;-><init>(ILjava/lang/String;)V
    .line 101: invoke-virtual {v0, v5}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 104: invoke-virtual {v0, v9}, Lu/b0;->t(Z)V
    .line 107: check-cast v5, Ld3/c;
    .line 109: invoke-static {v4, v9, v5}, Ld1/k;->a(Lf0/p;ZLd3/c;)Lf0/p;
    .line 112: move-result-object v4
    .line 113: invoke-virtual {v0, v9}, Lu/b0;->t(Z)V
    .line 116: invoke-interface {v10, v4}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 119: move-result-object v3
    .line 120: invoke-static {v3}, Landroidx/compose/ui/draw/a;->c(Lf0/p;)Lf0/p;
    .line 123: move-result-object v3
    .line 124: const/16 v16, 2
    .line 126: move-object/from16 v4, v17
    .line 128: move-object v5, v11
    .line 129: move-object v6, v12
    .line 130: move v7, v13
    .line 131: move-object v8, v15
    .line 132: move v14, v9
    .line 133: move/from16 v9, v16
    .line 135: invoke-static/range {v3 .. v9}, Landroidx/compose/ui/draw/a;->g(Lf0/p;Ln0/b;Lf0/d;Lx0/h;FLk0/r;I)Lf0/p;
    .line 138: move-result-object v3
    .line 139: sget-object v4, Li/d1;->a:Li/d1;
    .line 141: const v5, 0xb1164626
    .line 144: invoke-virtual {v0, v5}, Lu/b0;->d0(I)V
    .line 147: iget v5, v0, Lu/b0;->N:I
    .line 149: invoke-virtual {v0}, Lu/b0;->o()Lu/x1;
    .line 152: move-result-object v6
    .line 153: sget-object v7, Lz0/m;->g:Lz0/l;
    .line 155: invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 158: sget-object v7, Lz0/l;->b:Lz0/k;
    .line 160: invoke-static {v3}, Landroidx/compose/ui/layout/a;->j(Lf0/p;)Lb0/c;
    .line 163: move-result-object v3
    .line 164: iget-object v8, v0, Lu/b0;->a:Lu/c;
    .line 166: instance-of v8, v8, Lu/c;
    .line 168: if-eqz v8, :cond_268
    .line 170: invoke-virtual {v0}, Lu/b0;->f0()V
    .line 173: iget-boolean v8, v0, Lu/b0;->M:Z
    .line 175: if-eqz v8, :cond_181
    .line 177: invoke-virtual {v0, v7}, Lu/b0;->n(Ld3/a;)V
    .line 180: goto :goto_184
    .line 181: invoke-virtual {v0}, Lu/b0;->r0()V
    .line 184: sget-object v7, Lz0/l;->f:Lz0/j;
    .line 186: invoke-static {v0, v4, v7}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 189: sget-object v4, Lz0/l;->e:Lz0/j;
    .line 191: invoke-static {v0, v6, v4}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 194: sget-object v4, Lz0/l;->i:Lz0/j;
    .line 196: iget-boolean v6, v0, Lu/b0;->M:Z
    .line 198: if-nez v6, :cond_214
    .line 200: invoke-virtual {v0}, Lu/b0;->I()Ljava/lang/Object;
    .line 203: move-result-object v6
    .line 204: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 207: move-result-object v7
    .line 208: invoke-static {v6, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 211: move-result v6
    .line 212: if-nez v6, :cond_217
    .line 214: invoke-static {v5, v0, v5, v4}, Lai/onnxruntime/b;->r(ILu/b0;ILz0/j;)V
    .line 217: new-instance v4, Lu/r2;
    .line 219: invoke-direct {v4, v0}, Lu/r2;-><init>(Lu/l;)V
    .line 222: const v5, 0x7ab4aae9
    .line 225: invoke-static {v14, v3, v4, v0, v5}, Lai/onnxruntime/b;->o(ILb0/c;Lu/r2;Lu/b0;I)V
    .line 228: invoke-virtual {v0, v14}, Lu/b0;->t(Z)V
    .line 231: const/4 v3, 1
    .line 232: invoke-virtual {v0, v3}, Lu/b0;->t(Z)V
    .line 235: invoke-virtual {v0, v14}, Lu/b0;->t(Z)V
    .line 238: invoke-virtual {v0}, Lu/b0;->x()Lu/c2;
    .line 241: move-result-object v14
    .line 242: if-nez v14, :cond_245
    .line 244: goto :goto_267
    .line 245: new-instance v9, Li/e1;
    .line 247: move-object v0, v9
    .line 248: move-object/from16 v1, v17
    .line 250: move-object/from16 v2, v18
    .line 252: move-object v3, v10
    .line 253: move-object v4, v11
    .line 254: move-object v5, v12
    .line 255: move v6, v13
    .line 256: move-object v7, v15
    .line 257: move/from16 v8, v25
    .line 259: move-object v10, v9
    .line 260: move/from16 v9, v26
    .line 262: invoke-direct/range {v0 .. v9}, Li/e1;-><init>(Ln0/b;Ljava/lang/String;Lf0/p;Lf0/d;Lx0/h;FLk0/r;II)V
    .line 265: iput-object v10, v14, Lu/c2;->d:Ld3/e;
    .line 267: return-void
    .line 268: invoke-static {}, Lo/g1;->t()V
    .line 271: const/4 v0, 0
    .line 272: throw v0
.end method

# direct methods
.method public static c(Lf0/p;Lk0/j0;)Lf0/p;
    .registers 10

    .line 0: sget-object v5, Lk0/g0;->a:Lk0/f0;
    .line 2: const/high16 v4, 0x3f80
    .line 4: const-string v0, "<this>"
    .line 6: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: new-instance v7, Landroidx/compose/foundation/BackgroundElement;
    .line 11: const-wide/16 v1, 0
    .line 13: const/4 v6, 1
    .line 14: move-object v0, v7
    .line 15: move-object v3, v9
    .line 16: invoke-direct/range {v0 .. v6}, Landroidx/compose/foundation/BackgroundElement;-><init>(JLk0/j0;FLk0/l0;I)V
    .line 19: invoke-interface {v8, v7}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 22: move-result-object v8
    .line 23: return-object v8
.end method

# direct methods
.method public static final d(Lf0/p;JLk0/l0;)Lf0/p;
    .registers 12

    .line 0: const-string v0, "$this$background"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "shape"
    .line 7: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const/high16 v5, 0x3f80
    .line 12: new-instance v0, Landroidx/compose/foundation/BackgroundElement;
    .line 14: const/4 v4, 0
    .line 15: const/4 v7, 2
    .line 16: move-object v1, v0
    .line 17: move-wide v2, v9
    .line 18: move-object v6, v11
    .line 19: invoke-direct/range {v1 .. v7}, Landroidx/compose/foundation/BackgroundElement;-><init>(JLk0/j0;FLk0/l0;I)V
    .line 22: invoke-interface {v8, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 25: move-result-object v8
    .line 26: return-object v8
.end method

# direct methods
.method public static synthetic e(Lf0/p;J)Lf0/p;
    .registers 4

    .line 0: sget-object v0, Lk0/g0;->a:Lk0/f0;
    .line 2: invoke-static {v1, v2, v3, v0}, Landroidx/compose/foundation/a;->d(Lf0/p;JLk0/l0;)Lf0/p;
    .line 5: move-result-object v1
    .line 6: return-object v1
.end method

# direct methods
.method public static final f(Li/w;Lk0/l0;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "border"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "shape"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: iget-object v0, v2, Li/w;->b:Lk0/m;
    .line 12: const-string v1, "brush"
    .line 14: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 17: new-instance v1, Landroidx/compose/foundation/BorderModifierNodeElement;
    .line 19: iget v2, v2, Li/w;->a:F
    .line 21: invoke-direct {v1, v2, v0, v3}, Landroidx/compose/foundation/BorderModifierNodeElement;-><init>(FLk0/m;Lk0/l0;)V
    .line 24: return-object v1
.end method

# direct methods
.method public static final g(Lf0/p;Lk/m;Li/g1;ZLjava/lang/String;Ld1/f;Ld3/a;)Lf0/p;
    .registers 15

    .line 0: const-string v0, "$this$clickable"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "interactionSource"
    .line 7: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "onClick"
    .line 12: invoke-static {v14, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: sget-object v0, Landroidx/compose/ui/platform/s;->A:Landroidx/compose/ui/platform/s;
    .line 17: sget-object v1, Lf0/m;->c:Lf0/m;
    .line 19: sget-object v2, Li/j1;->a:Lu/j3;
    .line 21: new-instance v2, Li/i1;
    .line 23: const/4 v3, 0
    .line 24: invoke-direct {v2, v10, v3, v9}, Li/i1;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 27: invoke-static {v1, v0, v2}, Ld2/c;->y(Lf0/p;Ld3/c;Ld3/f;)Lf0/p;
    .line 30: move-result-object v10
    .line 31: invoke-static {v9, v10, v11}, Landroidx/compose/foundation/a;->j(Lk/m;Lf0/p;Z)Lf0/p;
    .line 34: move-result-object v10
    .line 35: sget-object v1, Landroidx/compose/foundation/b;->a:Landroidx/compose/ui/platform/t1;
    .line 37: const-string v1, "<this>"
    .line 39: invoke-static {v10, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 42: new-instance v1, Li/o0;
    .line 44: invoke-direct {v1, v3, v9, v11}, Li/o0;-><init>(ILjava/lang/Object;Z)V
    .line 47: sget-object v2, Landroidx/compose/foundation/b;->b:Landroidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1;
    .line 49: const-string v3, "other"
    .line 51: invoke-static {v2, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 54: invoke-static {v9, v2, v11}, Landroidx/compose/foundation/b;->a(Lk/m;Lf0/p;Z)Lf0/p;
    .line 57: move-result-object v2
    .line 58: invoke-static {v10, v1, v2}, Landroidx/compose/ui/platform/u1;->a(Lf0/p;Ld3/c;Lf0/p;)Lf0/p;
    .line 61: move-result-object v10
    .line 62: new-instance v7, Landroidx/compose/foundation/ClickableElement;
    .line 64: move-object v1, v7
    .line 65: move-object v2, v9
    .line 66: move v3, v11
    .line 67: move-object v4, v12
    .line 68: move-object v5, v13
    .line 69: move-object v6, v14
    .line 70: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/ClickableElement;-><init>(Lk/m;ZLjava/lang/String;Ld1/f;Ld3/a;)V
    .line 73: invoke-interface {v10, v7}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 76: move-result-object v9
    .line 77: invoke-static {v8, v0, v9}, Landroidx/compose/ui/platform/u1;->a(Lf0/p;Ld3/c;Lf0/p;)Lf0/p;
    .line 80: move-result-object v8
    .line 81: return-object v8
.end method

# direct methods
.method public static synthetic h(Lf0/p;Lk/m;Ls/e;ZLd1/f;Ld3/a;I)Lf0/p;
    .registers 14

    .line 0: and-int/lit8 v0, v13, 4
    .line 2: if-eqz v0, :cond_5
    .line 4: const/4 v10, 1
    .line 5: move v3, v10
    .line 6: const/4 v4, 0
    .line 7: and-int/lit8 v10, v13, 16
    .line 9: if-eqz v10, :cond_12
    .line 11: const/4 v11, 0
    .line 12: move-object v5, v11
    .line 13: move-object v0, v7
    .line 14: move-object v1, v8
    .line 15: move-object v2, v9
    .line 16: move-object v6, v12
    .line 17: invoke-static/range {v0 .. v6}, Landroidx/compose/foundation/a;->g(Lf0/p;Lk/m;Li/g1;ZLjava/lang/String;Ld1/f;Ld3/a;)Lf0/p;
    .line 20: move-result-object v7
    .line 21: return-object v7
.end method

# direct methods
.method public static i(Lf0/p;ZLd3/a;I)Lf0/p;
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: and-int/2addr v5, v0
    .line 2: if-eqz v5, :cond_5
    .line 4: move v3, v0
    .line 5: const-string v5, "$this$clickable"
    .line 7: invoke-static {v2, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v5, "onClick"
    .line 12: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: sget-object v5, Landroidx/compose/ui/platform/s;->A:Landroidx/compose/ui/platform/s;
    .line 17: new-instance v0, Li/y;
    .line 19: const/4 v1, 0
    .line 20: invoke-direct {v0, v3, v1, v1, v4}, Li/y;-><init>(ZLjava/lang/String;Ld1/f;Ld3/a;)V
    .line 23: invoke-static {v2, v5, v0}, Ld2/c;->y(Lf0/p;Ld3/c;Ld3/f;)Lf0/p;
    .line 26: move-result-object v2
    .line 27: return-object v2
.end method

# direct methods
.method public static final j(Lk/m;Lf0/p;Z)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "interactionSource"
    .line 7: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: if-eqz v3, :cond_18
    .line 12: new-instance v3, Landroidx/compose/foundation/HoverableElement;
    .line 14: invoke-direct {v3, v1}, Landroidx/compose/foundation/HoverableElement;-><init>(Lk/m;)V
    .line 17: goto :goto_20
    .line 18: sget-object v3, Lf0/m;->c:Lf0/m;
    .line 20: invoke-interface {v2, v3}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 23: move-result-object v1
    .line 24: return-object v1
.end method

# direct methods
.method public static final k(FJ)J
    .registers 5

    .line 0: invoke-static {v3, v4}, Lj0/a;->b(J)F
    .line 3: move-result v0
    .line 4: sub-float/2addr v0, v2
    .line 5: const/4 v1, 0
    .line 6: invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F
    .line 9: move-result v0
    .line 10: invoke-static {v3, v4}, Lj0/a;->c(J)F
    .line 13: move-result v3
    .line 14: sub-float/2addr v3, v2
    .line 15: invoke-static {v1, v3}, Ljava/lang/Math;->max(FF)F
    .line 18: move-result v2
    .line 19: invoke-static {v0, v2}, Ln3/a0;->c(FF)J
    .line 22: move-result-wide v2
    .line 23: return-wide v2
.end method

.class public abstract Landroidx/compose/foundation/layout/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf0/p;Lu/l;I)V
    .registers 8

    .line 0: const-string v0, "modifier"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: check-cast v6, Lu/b0;
    .line 7: const v0, 0xfba7e6dd
    .line 10: invoke-virtual {v6, v0}, Lu/b0;->d0(I)V
    .line 13: sget-object v0, Ll/t0;->a:Ll/t0;
    .line 15: shl-int/lit8 v7, v7, 3
    .line 17: and-int/lit8 v7, v7, 112
    .line 19: or-int/lit16 v7, v7, 384
    .line 21: const v1, 0xb1164626
    .line 24: invoke-virtual {v6, v1}, Lu/b0;->d0(I)V
    .line 27: iget v1, v6, Lu/b0;->N:I
    .line 29: invoke-virtual {v6}, Lu/b0;->o()Lu/x1;
    .line 32: move-result-object v2
    .line 33: sget-object v3, Lz0/m;->g:Lz0/l;
    .line 35: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 38: sget-object v3, Lz0/l;->b:Lz0/k;
    .line 40: invoke-static {v5}, Landroidx/compose/ui/layout/a;->j(Lf0/p;)Lb0/c;
    .line 43: move-result-object v5
    .line 44: shl-int/lit8 v7, v7, 9
    .line 46: and-int/lit16 v7, v7, 7168
    .line 48: or-int/lit8 v7, v7, 6
    .line 50: iget-object v4, v6, Lu/b0;->a:Lu/c;
    .line 52: instance-of v4, v4, Lu/c;
    .line 54: if-eqz v4, :cond_124
    .line 56: invoke-virtual {v6}, Lu/b0;->f0()V
    .line 59: iget-boolean v4, v6, Lu/b0;->M:Z
    .line 61: if-eqz v4, :cond_67
    .line 63: invoke-virtual {v6, v3}, Lu/b0;->n(Ld3/a;)V
    .line 66: goto :goto_70
    .line 67: invoke-virtual {v6}, Lu/b0;->r0()V
    .line 70: sget-object v3, Lz0/l;->f:Lz0/j;
    .line 72: invoke-static {v6, v0, v3}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 75: sget-object v0, Lz0/l;->e:Lz0/j;
    .line 77: invoke-static {v6, v2, v0}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 80: sget-object v0, Lz0/l;->i:Lz0/j;
    .line 82: iget-boolean v2, v6, Lu/b0;->M:Z
    .line 84: if-nez v2, :cond_100
    .line 86: invoke-virtual {v6}, Lu/b0;->I()Ljava/lang/Object;
    .line 89: move-result-object v2
    .line 90: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 93: move-result-object v3
    .line 94: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 97: move-result v2
    .line 98: if-nez v2, :cond_103
    .line 100: invoke-static {v1, v6, v1, v0}, Lai/onnxruntime/b;->r(ILu/b0;ILz0/j;)V
    .line 103: new-instance v0, Lu/r2;
    .line 105: invoke-direct {v0, v6}, Lu/r2;-><init>(Lu/l;)V
    .line 108: shr-int/lit8 v7, v7, 3
    .line 110: and-int/lit8 v7, v7, 112
    .line 112: const v1, 0x7ab4aae9
    .line 115: invoke-static {v7, v5, v0, v6, v1}, Lai/onnxruntime/b;->o(ILb0/c;Lu/r2;Lu/b0;I)V
    .line 118: const/4 v5, 0
    .line 119: const/4 v7, 1
    .line 120: invoke-static {v6, v5, v7, v5, v5}, Lai/onnxruntime/b;->v(Lu/b0;ZZZZ)V
    .line 123: return-void
    .line 124: invoke-static {}, Lo/g1;->t()V
    .line 127: const/4 v5, 0
    .line 128: throw v5
.end method

# direct methods
.method public static final b(Ljava/util/List;Ll/i;Ll/i;IIII)I
    .registers 15

    .line 0: const/4 v0, 0
    .line 1: const/4 v1, 0
    .line 2: if-ne v13, v14, :cond_82
    .line 4: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 7: move-result v10
    .line 8: move v2, v0
    .line 9: move v13, v1
    .line 10: move v14, v13
    .line 11: if-ge v1, v10, :cond_65
    .line 13: invoke-interface {v8, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 16: move-result-object v3
    .line 17: check-cast v3, Lx0/l;
    .line 19: invoke-static {v3}, Landroidx/compose/foundation/layout/a;->d(Lx0/l;)Ll/o0;
    .line 22: move-result-object v4
    .line 23: invoke-static {v4}, Landroidx/compose/foundation/layout/a;->e(Ll/o0;)F
    .line 26: move-result v4
    .line 27: invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 30: move-result-object v5
    .line 31: invoke-virtual {v9, v3, v5}, Ll/i;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 34: move-result-object v3
    .line 35: check-cast v3, Ljava/lang/Number;
    .line 37: invoke-virtual {v3}, Ljava/lang/Number;->intValue()I
    .line 40: move-result v3
    .line 41: cmpg-float v5, v4, v0
    .line 43: if-nez v5, :cond_47
    .line 45: add-int/2addr v14, v3
    .line 46: goto :goto_62
    .line 47: cmpl-float v5, v4, v0
    .line 49: if-lez v5, :cond_62
    .line 51: add-float/2addr v2, v4
    .line 52: int-to-float v3, v3
    .line 53: div-float/2addr v3, v4
    .line 54: invoke-static {v3}, Ld2/b;->a1(F)I
    .line 57: move-result v3
    .line 58: invoke-static {v13, v3}, Ljava/lang/Math;->max(II)I
    .line 61: move-result v13
    .line 62: add-int/lit8 v1, v1, 1
    .line 64: goto :goto_11
    .line 65: int-to-float v9, v13
    .line 66: mul-float/2addr v9, v2
    .line 67: invoke-static {v9}, Ld2/b;->a1(F)I
    .line 70: move-result v9
    .line 71: add-int/2addr v9, v14
    .line 72: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 75: move-result v8
    .line 76: add-int/lit8 v8, v8, -1
    .line 78: mul-int/2addr v8, v12
    .line 79: add-int/2addr v8, v9
    .line 80: goto/16 :goto_248
    .line 82: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 85: move-result v13
    .line 86: add-int/lit8 v13, v13, -1
    .line 88: mul-int/2addr v13, v12
    .line 89: invoke-static {v13, v11}, Ljava/lang/Math;->min(II)I
    .line 92: move-result v12
    .line 93: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 96: move-result v13
    .line 97: move v2, v0
    .line 98: move v14, v1
    .line 99: move v3, v14
    .line 100: const v4, 0x7fffffff
    .line 103: if-ge v14, v13, :cond_171
    .line 105: invoke-interface {v8, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 108: move-result-object v5
    .line 109: check-cast v5, Lx0/l;
    .line 111: invoke-static {v5}, Landroidx/compose/foundation/layout/a;->d(Lx0/l;)Ll/o0;
    .line 114: move-result-object v6
    .line 115: invoke-static {v6}, Landroidx/compose/foundation/layout/a;->e(Ll/o0;)F
    .line 118: move-result v6
    .line 119: cmpg-float v7, v6, v0
    .line 121: if-nez v7, :cond_163
    .line 123: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 126: move-result-object v4
    .line 127: invoke-virtual {v10, v5, v4}, Ll/i;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 130: move-result-object v4
    .line 131: check-cast v4, Ljava/lang/Number;
    .line 133: invoke-virtual {v4}, Ljava/lang/Number;->intValue()I
    .line 136: move-result v4
    .line 137: sub-int v6, v11, v12
    .line 139: invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I
    .line 142: move-result v4
    .line 143: add-int/2addr v12, v4
    .line 144: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 147: move-result-object v4
    .line 148: invoke-virtual {v9, v5, v4}, Ll/i;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 151: move-result-object v4
    .line 152: check-cast v4, Ljava/lang/Number;
    .line 154: invoke-virtual {v4}, Ljava/lang/Number;->intValue()I
    .line 157: move-result v4
    .line 158: invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I
    .line 161: move-result v3
    .line 162: goto :goto_168
    .line 163: cmpl-float v4, v6, v0
    .line 165: if-lez v4, :cond_168
    .line 167: add-float/2addr v2, v6
    .line 168: add-int/lit8 v14, v14, 1
    .line 170: goto :goto_100
    .line 171: cmpg-float v10, v2, v0
    .line 173: if-nez v10, :cond_177
    .line 175: move v10, v1
    .line 176: goto :goto_192
    .line 177: if-ne v11, v4, :cond_181
    .line 179: move v10, v4
    .line 180: goto :goto_192
    .line 181: sub-int/2addr v11, v12
    .line 182: invoke-static {v11, v1}, Ljava/lang/Math;->max(II)I
    .line 185: move-result v10
    .line 186: int-to-float v10, v10
    .line 187: div-float/2addr v10, v2
    .line 188: invoke-static {v10}, Ld2/b;->a1(F)I
    .line 191: move-result v10
    .line 192: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 195: move-result v11
    .line 196: if-ge v1, v11, :cond_247
    .line 198: invoke-interface {v8, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 201: move-result-object v12
    .line 202: check-cast v12, Lx0/l;
    .line 204: invoke-static {v12}, Landroidx/compose/foundation/layout/a;->d(Lx0/l;)Ll/o0;
    .line 207: move-result-object v13
    .line 208: invoke-static {v13}, Landroidx/compose/foundation/layout/a;->e(Ll/o0;)F
    .line 211: move-result v13
    .line 212: cmpl-float v14, v13, v0
    .line 214: if-lez v14, :cond_244
    .line 216: if-eq v10, v4, :cond_225
    .line 218: int-to-float v14, v10
    .line 219: mul-float/2addr v14, v13
    .line 220: invoke-static {v14}, Ld2/b;->a1(F)I
    .line 223: move-result v13
    .line 224: goto :goto_226
    .line 225: move v13, v4
    .line 226: invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 229: move-result-object v13
    .line 230: invoke-virtual {v9, v12, v13}, Ll/i;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 233: move-result-object v12
    .line 234: check-cast v12, Ljava/lang/Number;
    .line 236: invoke-virtual {v12}, Ljava/lang/Number;->intValue()I
    .line 239: move-result v12
    .line 240: invoke-static {v3, v12}, Ljava/lang/Math;->max(II)I
    .line 243: move-result v3
    .line 244: add-int/lit8 v1, v1, 1
    .line 246: goto :goto_196
    .line 247: move v8, v3
    .line 248: return v8
.end method

# direct methods
.method public static final c(Ll/i0;Lr1/j;)F
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "layoutDirection"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: sget-object v0, Lr1/j;->i:Lr1/j;
    .line 12: if-ne v2, v0, :cond_19
    .line 14: invoke-virtual {v1, v2}, Ll/i0;->a(Lr1/j;)F
    .line 17: move-result v1
    .line 18: goto :goto_23
    .line 19: invoke-virtual {v1, v2}, Ll/i0;->b(Lr1/j;)F
    .line 22: move-result v1
    .line 23: return v1
.end method

# direct methods
.method public static final d(Lx0/l;)Ll/o0;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v1}, Lx0/l;->J()Ljava/lang/Object;
    .line 8: move-result-object v1
    .line 9: instance-of v0, v1, Ll/o0;
    .line 11: if-eqz v0, :cond_16
    .line 13: check-cast v1, Ll/o0;
    .line 15: goto :goto_17
    .line 16: const/4 v1, 0
    .line 17: return-object v1
.end method

# direct methods
.method public static final e(Ll/o0;)F
    .registers 1

    .line 0: if-eqz v0, :cond_5
    .line 2: iget v0, v0, Ll/o0;->a:F
    .line 4: goto :goto_6
    .line 5: const/4 v0, 0
    .line 6: return v0
.end method

# direct methods
.method public static f(Lf0/c;Z)Landroidx/compose/foundation/layout/WrapContentElement;
    .registers 9

    .line 0: new-instance v6, Landroidx/compose/foundation/layout/WrapContentElement;
    .line 2: const/4 v1, 1
    .line 3: new-instance v3, Ll/v0;
    .line 5: const/4 v0, 0
    .line 6: invoke-direct {v3, v0, v7}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 9: const-string v5, "wrapContentHeight"
    .line 11: move-object v0, v6
    .line 12: move v2, v8
    .line 13: move-object v4, v7
    .line 14: invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/layout/WrapContentElement;-><init>(IZLl/v0;Ljava/lang/Object;Ljava/lang/String;)V
    .line 17: return-object v6
.end method

# direct methods
.method public static final g(Lf0/p;FF)Lf0/p;
    .registers 6

    .line 0: const-string v0, "$this$offset"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/OffsetElement;
    .line 7: new-instance v1, Ll/d0;
    .line 9: const/4 v2, 0
    .line 10: invoke-direct {v1, v4, v5, v2}, Ll/d0;-><init>(FFI)V
    .line 13: invoke-direct {v0, v4, v5, v1}, Landroidx/compose/foundation/layout/OffsetElement;-><init>(FFLl/d0;)V
    .line 16: invoke-interface {v3, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 19: move-result-object v3
    .line 20: return-object v3
.end method

# direct methods
.method public static final h(Lf0/p;Ll/i0;)Lf0/p;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "paddingValues"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/foundation/layout/PaddingValuesElement;
    .line 12: new-instance v1, Lg/n;
    .line 14: const/16 v2, 11
    .line 16: invoke-direct {v1, v2, v4}, Lg/n;-><init>(ILjava/lang/Object;)V
    .line 19: invoke-direct {v0, v4, v1}, Landroidx/compose/foundation/layout/PaddingValuesElement;-><init>(Ll/i0;Lg/n;)V
    .line 22: invoke-interface {v3, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 25: move-result-object v3
    .line 26: return-object v3
.end method

# direct methods
.method public static final i(Lf0/p;F)Lf0/p;
    .registers 9

    .line 0: const-string v0, "$this$padding"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/PaddingElement;
    .line 7: new-instance v6, Ll/g0;
    .line 9: const/4 v1, 1
    .line 10: invoke-direct {v6, v1}, Le3/h;-><init>(I)V
    .line 13: move-object v1, v0
    .line 14: move v2, v8
    .line 15: move v3, v8
    .line 16: move v4, v8
    .line 17: move v5, v8
    .line 18: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/PaddingElement;-><init>(FFFFLd3/c;)V
    .line 21: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 24: move-result-object v7
    .line 25: return-object v7
.end method

# direct methods
.method public static final j(Lf0/p;FF)Lf0/p;
    .registers 10

    .line 0: const-string v0, "$this$padding"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/PaddingElement;
    .line 7: new-instance v6, Ll/d0;
    .line 9: const/4 v1, 1
    .line 10: invoke-direct {v6, v8, v9, v1}, Ll/d0;-><init>(FFI)V
    .line 13: move-object v1, v0
    .line 14: move v2, v8
    .line 15: move v3, v9
    .line 16: move v4, v8
    .line 17: move v5, v9
    .line 18: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/PaddingElement;-><init>(FFFFLd3/c;)V
    .line 21: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 24: move-result-object v7
    .line 25: return-object v7
.end method

# direct methods
.method public static k(Lf0/p;FFI)Lf0/p;
    .registers 6

    .line 0: and-int/lit8 v0, v5, 1
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: int-to-float v3, v1
    .line 6: and-int/lit8 v5, v5, 2
    .line 8: if-eqz v5, :cond_11
    .line 10: int-to-float v4, v1
    .line 11: invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/a;->j(Lf0/p;FF)Lf0/p;
    .line 14: move-result-object v2
    .line 15: return-object v2
.end method

# direct methods
.method public static final l(Lf0/p;FFFF)Lf0/p;
    .registers 12

    .line 0: const-string v0, "$this$padding"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/PaddingElement;
    .line 7: new-instance v6, Ll/f0;
    .line 9: const/4 v1, 1
    .line 10: invoke-direct {v6, v1}, Le3/h;-><init>(I)V
    .line 13: move-object v1, v0
    .line 14: move v2, v8
    .line 15: move v3, v9
    .line 16: move v4, v10
    .line 17: move v5, v11
    .line 18: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/PaddingElement;-><init>(FFFFLd3/c;)V
    .line 21: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 24: move-result-object v7
    .line 25: return-object v7
.end method

# direct methods
.method public static m(Lf0/p;FFFFI)Lf0/p;
    .registers 8

    .line 0: and-int/lit8 v0, v7, 1
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: int-to-float v3, v1
    .line 6: and-int/lit8 v0, v7, 2
    .line 8: if-eqz v0, :cond_11
    .line 10: int-to-float v4, v1
    .line 11: and-int/lit8 v0, v7, 4
    .line 13: if-eqz v0, :cond_16
    .line 15: int-to-float v5, v1
    .line 16: and-int/lit8 v7, v7, 8
    .line 18: if-eqz v7, :cond_21
    .line 20: int-to-float v6, v1
    .line 21: invoke-static {v2, v3, v4, v5, v6}, Landroidx/compose/foundation/layout/a;->l(Lf0/p;FFFF)Lf0/p;
    .line 24: move-result-object v2
    .line 25: return-object v2
.end method

# direct methods
.method public static n(Lx0/k;FFI)Lf0/p;
    .registers 6

    .line 0: and-int/lit8 v0, v5, 2
    .line 2: const/high16 v1, 0x7fc0
    .line 4: if-eqz v0, :cond_7
    .line 6: move v3, v1
    .line 7: and-int/lit8 v5, v5, 4
    .line 9: if-eqz v5, :cond_12
    .line 11: move v4, v1
    .line 12: const-string v5, "alignmentLine"
    .line 14: invoke-static {v2, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 17: new-instance v5, Landroidx/compose/foundation/layout/AlignmentLineOffsetDpElement;
    .line 19: invoke-direct {v5, v2, v3, v4}, Landroidx/compose/foundation/layout/AlignmentLineOffsetDpElement;-><init>(Lx0/k;FF)V
    .line 22: return-object v5
.end method

# direct methods
.method public static final o(ILd3/h;FLl/x;)Ll/l0;
    .registers 6

    .line 0: const-string v0, "orientation"
    .line 2: invoke-static {v2, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 5: const-string v0, "crossAxisSize"
    .line 7: const/4 v1, 1
    .line 8: invoke-static {v1, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 11: new-instance v0, Ll/l0;
    .line 13: invoke-direct {v0, v2, v3, v4, v5}, Ll/l0;-><init>(ILd3/h;FLl/x;)V
    .line 16: return-object v0
.end method

# direct methods
.method public static final p(JI)J
    .registers 5

    .line 0: const-string v0, "orientation"
    .line 2: invoke-static {v4, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 5: const/4 v0, 1
    .line 6: if-ne v4, v0, :cond_29
    .line 8: invoke-static {v2, v3}, Lr1/a;->j(J)I
    .line 11: move-result v4
    .line 12: invoke-static {v2, v3}, Lr1/a;->h(J)I
    .line 15: move-result v0
    .line 16: invoke-static {v2, v3}, Lr1/a;->i(J)I
    .line 19: move-result v1
    .line 20: invoke-static {v2, v3}, Lr1/a;->g(J)I
    .line 23: move-result v2
    .line 24: invoke-static {v4, v0, v1, v2}, Ld2/c;->a(IIII)J
    .line 27: move-result-wide v2
    .line 28: goto :goto_49
    .line 29: invoke-static {v2, v3}, Lr1/a;->i(J)I
    .line 32: move-result v4
    .line 33: invoke-static {v2, v3}, Lr1/a;->g(J)I
    .line 36: move-result v0
    .line 37: invoke-static {v2, v3}, Lr1/a;->j(J)I
    .line 40: move-result v1
    .line 41: invoke-static {v2, v3}, Lr1/a;->h(J)I
    .line 44: move-result v2
    .line 45: invoke-static {v4, v0, v1, v2}, Ld2/c;->a(IIII)J
    .line 48: move-result-wide v2
    .line 49: return-wide v2
.end method

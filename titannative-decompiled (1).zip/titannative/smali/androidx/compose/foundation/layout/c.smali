.class public abstract Landroidx/compose/foundation/layout/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/foundation/layout/FillElement;
.field public static final b:Landroidx/compose/foundation/layout/FillElement;
.field public static final c:Landroidx/compose/foundation/layout/WrapContentElement;
.field public static final d:Landroidx/compose/foundation/layout/WrapContentElement;

# direct methods
.method static constructor <clinit>()V
    .registers 18

    .line 0: new-instance v0, Landroidx/compose/foundation/layout/FillElement;
    .line 2: const-string v1, "fillMaxWidth"
    .line 4: const/4 v2, 2
    .line 5: const/high16 v3, 0x3f80
    .line 7: invoke-direct {v0, v2, v3, v1}, Landroidx/compose/foundation/layout/FillElement;-><init>(IFLjava/lang/String;)V
    .line 10: sput-object v0, Landroidx/compose/foundation/layout/c;->a:Landroidx/compose/foundation/layout/FillElement;
    .line 12: new-instance v0, Landroidx/compose/foundation/layout/FillElement;
    .line 14: const-string v1, "fillMaxHeight"
    .line 16: const/4 v4, 1
    .line 17: invoke-direct {v0, v4, v3, v1}, Landroidx/compose/foundation/layout/FillElement;-><init>(IFLjava/lang/String;)V
    .line 20: new-instance v0, Landroidx/compose/foundation/layout/FillElement;
    .line 22: const/4 v1, 3
    .line 23: const-string v5, "fillMaxSize"
    .line 25: invoke-direct {v0, v1, v3, v5}, Landroidx/compose/foundation/layout/FillElement;-><init>(IFLjava/lang/String;)V
    .line 28: sput-object v0, Landroidx/compose/foundation/layout/c;->b:Landroidx/compose/foundation/layout/FillElement;
    .line 30: sget-object v10, Lf0/a;->p:Lf0/e;
    .line 32: const/4 v8, 0
    .line 33: new-instance v6, Landroidx/compose/foundation/layout/WrapContentElement;
    .line 35: const/4 v7, 2
    .line 36: new-instance v9, Ll/v0;
    .line 38: invoke-direct {v9, v2, v10}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 41: const-string v11, "wrapContentWidth"
    .line 43: invoke-direct/range {v6 .. v11}, Landroidx/compose/foundation/layout/WrapContentElement;-><init>(IZLl/v0;Ljava/lang/Object;Ljava/lang/String;)V
    .line 46: sget-object v0, Lf0/a;->o:Lf0/e;
    .line 48: const/4 v14, 0
    .line 49: new-instance v12, Landroidx/compose/foundation/layout/WrapContentElement;
    .line 51: const/4 v13, 2
    .line 52: new-instance v15, Ll/v0;
    .line 54: invoke-direct {v15, v2, v0}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 57: const-string v17, "wrapContentWidth"
    .line 59: move-object/from16 v16, v0
    .line 61: invoke-direct/range {v12 .. v17}, Landroidx/compose/foundation/layout/WrapContentElement;-><init>(IZLl/v0;Ljava/lang/Object;Ljava/lang/String;)V
    .line 64: sget-object v0, Lf0/a;->n:Lf0/f;
    .line 66: const/4 v1, 0
    .line 67: invoke-static {v0, v1}, Landroidx/compose/foundation/layout/a;->f(Lf0/c;Z)Landroidx/compose/foundation/layout/WrapContentElement;
    .line 70: move-result-object v0
    .line 71: sput-object v0, Landroidx/compose/foundation/layout/c;->c:Landroidx/compose/foundation/layout/WrapContentElement;
    .line 73: sget-object v0, Lf0/a;->m:Lf0/f;
    .line 75: invoke-static {v0, v1}, Landroidx/compose/foundation/layout/a;->f(Lf0/c;Z)Landroidx/compose/foundation/layout/WrapContentElement;
    .line 78: move-result-object v0
    .line 79: sput-object v0, Landroidx/compose/foundation/layout/c;->d:Landroidx/compose/foundation/layout/WrapContentElement;
    .line 81: sget-object v9, Lf0/a;->j:Lf0/g;
    .line 83: const/4 v7, 0
    .line 84: new-instance v5, Landroidx/compose/foundation/layout/WrapContentElement;
    .line 86: const/4 v6, 3
    .line 87: new-instance v8, Ll/v0;
    .line 89: invoke-direct {v8, v4, v9}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 92: const-string v10, "wrapContentSize"
    .line 94: invoke-direct/range {v5 .. v10}, Landroidx/compose/foundation/layout/WrapContentElement;-><init>(IZLl/v0;Ljava/lang/Object;Ljava/lang/String;)V
    .line 97: sget-object v15, Lf0/a;->i:Lf0/g;
    .line 99: const/4 v13, 0
    .line 100: new-instance v11, Landroidx/compose/foundation/layout/WrapContentElement;
    .line 102: const/4 v12, 3
    .line 103: new-instance v14, Ll/v0;
    .line 105: invoke-direct {v14, v4, v15}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 108: const-string v16, "wrapContentSize"
    .line 110: invoke-direct/range {v11 .. v16}, Landroidx/compose/foundation/layout/WrapContentElement;-><init>(IZLl/v0;Ljava/lang/Object;Ljava/lang/String;)V
    .line 113: return-void
.end method

# direct methods
.method public static final a(Lf0/p;FF)Lf0/p;
    .registers 4

    .line 0: const-string v0, "$this$defaultMinSize"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/UnspecifiedConstraintsElement;
    .line 7: invoke-direct {v0, v2, v3}, Landroidx/compose/foundation/layout/UnspecifiedConstraintsElement;-><init>(FF)V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

# direct methods
.method public static b()Lf0/p;
    .registers 2

    .line 0: const-string v0, "other"
    .line 2: sget-object v1, Landroidx/compose/foundation/layout/c;->b:Landroidx/compose/foundation/layout/FillElement;
    .line 4: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: return-object v1
.end method

# direct methods
.method public static final c(Lf0/p;F)Lf0/p;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const/high16 v0, 0x3f80
    .line 7: cmpg-float v0, v4, v0
    .line 9: if-nez v0, :cond_14
    .line 11: sget-object v4, Landroidx/compose/foundation/layout/c;->a:Landroidx/compose/foundation/layout/FillElement;
    .line 13: goto :goto_23
    .line 14: new-instance v0, Landroidx/compose/foundation/layout/FillElement;
    .line 16: const/4 v1, 2
    .line 17: const-string v2, "fillMaxWidth"
    .line 19: invoke-direct {v0, v1, v4, v2}, Landroidx/compose/foundation/layout/FillElement;-><init>(IFLjava/lang/String;)V
    .line 22: move-object v4, v0
    .line 23: invoke-interface {v3, v4}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 26: move-result-object v3
    .line 27: return-object v3
.end method

# direct methods
.method public static synthetic d(Lf0/p;)Lf0/p;
    .registers 2

    .line 0: const/high16 v0, 0x3f80
    .line 2: invoke-static {v1, v0}, Landroidx/compose/foundation/layout/c;->c(Lf0/p;F)Lf0/p;
    .line 5: move-result-object v1
    .line 6: return-object v1
.end method

# direct methods
.method public static final e(Lf0/p;F)Lf0/p;
    .registers 9

    .line 0: const-string v0, "$this$height"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/SizeElement;
    .line 7: const/4 v2, 0
    .line 8: const/4 v4, 0
    .line 9: const/4 v6, 5
    .line 10: move-object v1, v0
    .line 11: move v3, v8
    .line 12: move v5, v8
    .line 13: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/SizeElement;-><init>(FFFFI)V
    .line 16: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 19: move-result-object v7
    .line 20: return-object v7
.end method

# direct methods
.method public static final f(Lf0/p;FF)Lf0/p;
    .registers 10

    .line 0: const-string v0, "$this$heightIn"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/SizeElement;
    .line 7: const/4 v2, 0
    .line 8: const/4 v4, 0
    .line 9: const/4 v6, 5
    .line 10: move-object v1, v0
    .line 11: move v3, v8
    .line 12: move v5, v9
    .line 13: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/SizeElement;-><init>(FFFFI)V
    .line 16: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 19: move-result-object v7
    .line 20: return-object v7
.end method

# direct methods
.method public static g(Lf0/p;FFI)Lf0/p;
    .registers 6

    .line 0: and-int/lit8 v0, v5, 1
    .line 2: const/high16 v1, 0x7fc0
    .line 4: if-eqz v0, :cond_7
    .line 6: move v3, v1
    .line 7: and-int/lit8 v5, v5, 2
    .line 9: if-eqz v5, :cond_12
    .line 11: move v4, v1
    .line 12: invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/c;->f(Lf0/p;FF)Lf0/p;
    .line 15: move-result-object v2
    .line 16: return-object v2
.end method

# direct methods
.method public static h(Lf0/p;FF)Lf0/p;
    .registers 10

    .line 0: const/high16 v3, 0x7fc0
    .line 2: const/high16 v4, 0x7fc0
    .line 4: const-string v0, "$this$requiredSizeIn"
    .line 6: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: new-instance v6, Landroidx/compose/foundation/layout/SizeElement;
    .line 11: const/4 v5, 0
    .line 12: move-object v0, v6
    .line 13: move v1, v8
    .line 14: move v2, v9
    .line 15: invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/layout/SizeElement;-><init>(FFFFZ)V
    .line 18: invoke-interface {v7, v6}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 21: move-result-object v7
    .line 22: return-object v7
.end method

# direct methods
.method public static final i(Lf0/p;F)Lf0/p;
    .registers 9

    .line 0: const-string v0, "$this$size"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/SizeElement;
    .line 7: const/4 v6, 1
    .line 8: move-object v1, v0
    .line 9: move v2, v8
    .line 10: move v3, v8
    .line 11: move v4, v8
    .line 12: move v5, v8
    .line 13: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/SizeElement;-><init>(FFFFZ)V
    .line 16: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 19: move-result-object v7
    .line 20: return-object v7
.end method

# direct methods
.method public static final j(Lf0/p;FF)Lf0/p;
    .registers 10

    .line 0: const-string v0, "$this$size"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/SizeElement;
    .line 7: const/4 v6, 1
    .line 8: move-object v1, v0
    .line 9: move v2, v8
    .line 10: move v3, v9
    .line 11: move v4, v8
    .line 12: move v5, v9
    .line 13: invoke-direct/range {v1 .. v6}, Landroidx/compose/foundation/layout/SizeElement;-><init>(FFFFZ)V
    .line 16: invoke-interface {v7, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 19: move-result-object v7
    .line 20: return-object v7
.end method

# direct methods
.method public static k(FFI)Lf0/p;
    .registers 11

    .line 0: and-int/lit8 v0, v10, 1
    .line 2: const/high16 v1, 0x7fc0
    .line 4: if-eqz v0, :cond_8
    .line 6: move v3, v1
    .line 7: goto :goto_9
    .line 8: move v3, v8
    .line 9: and-int/lit8 v8, v10, 2
    .line 11: if-eqz v8, :cond_15
    .line 13: move v5, v1
    .line 14: goto :goto_16
    .line 15: move v5, v9
    .line 16: new-instance v8, Landroidx/compose/foundation/layout/SizeElement;
    .line 18: const/4 v4, 0
    .line 19: const/4 v6, 0
    .line 20: const/16 v7, 10
    .line 22: move-object v2, v8
    .line 23: invoke-direct/range {v2 .. v7}, Landroidx/compose/foundation/layout/SizeElement;-><init>(FFFFI)V
    .line 26: return-object v8
.end method

# direct methods
.method public static l(Lf0/p;)Lf0/p;
    .registers 3

    .line 0: sget-object v0, Lf0/a;->n:Lf0/f;
    .line 2: const-string v1, "<this>"
    .line 4: invoke-static {v2, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: invoke-static {v0, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 10: move-result v1
    .line 11: if-eqz v1, :cond_16
    .line 13: sget-object v0, Landroidx/compose/foundation/layout/c;->c:Landroidx/compose/foundation/layout/WrapContentElement;
    .line 15: goto :goto_32
    .line 16: sget-object v1, Lf0/a;->m:Lf0/f;
    .line 18: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 21: move-result v1
    .line 22: if-eqz v1, :cond_27
    .line 24: sget-object v0, Landroidx/compose/foundation/layout/c;->d:Landroidx/compose/foundation/layout/WrapContentElement;
    .line 26: goto :goto_32
    .line 27: const/4 v1, 0
    .line 28: invoke-static {v0, v1}, Landroidx/compose/foundation/layout/a;->f(Lf0/c;Z)Landroidx/compose/foundation/layout/WrapContentElement;
    .line 31: move-result-object v0
    .line 32: invoke-interface {v2, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 35: move-result-object v2
    .line 36: return-object v2
.end method

.class public final Landroidx/compose/foundation/layout/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/foundation/layout/b;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/foundation/layout/b;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/foundation/layout/b;->a:Landroidx/compose/foundation/layout/b;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Lf0/p;Lf0/g;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/layout/BoxChildDataElement;
    .line 7: invoke-direct {v0, v3}, Landroidx/compose/foundation/layout/BoxChildDataElement;-><init>(Lf0/g;)V
    .line 10: invoke-interface {v2, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v2
    .line 14: return-object v2
.end method

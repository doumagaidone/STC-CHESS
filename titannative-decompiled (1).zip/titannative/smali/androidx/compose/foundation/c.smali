.class public abstract Landroidx/compose/foundation/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ly0/i;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Li/u0;->k:Li/u0;
    .line 2: invoke-static {v0}, Ll0/j;->y(Ld3/a;)Ly0/i;
    .line 5: move-result-object v0
    .line 6: sput-object v0, Landroidx/compose/foundation/c;->a:Ly0/i;
    .line 8: return-void
.end method

# direct methods
.method public static final a(Lf0/p;Lg/n;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/foundation/FocusedBoundsObserverElement;
    .line 7: invoke-direct {v0, v2}, Landroidx/compose/foundation/FocusedBoundsObserverElement;-><init>(Lg/n;)V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

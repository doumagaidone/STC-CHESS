.class public abstract Landroidx/compose/foundation/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/t1;
.field public static final b:Landroidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Landroidx/compose/ui/platform/t1;
    .line 2: sget-object v1, Landroidx/compose/ui/platform/s;->A:Landroidx/compose/ui/platform/s;
    .line 4: invoke-direct {v0, v1}, Landroidx/compose/ui/platform/t1;-><init>(Ld3/c;)V
    .line 7: sput-object v0, Landroidx/compose/foundation/b;->a:Landroidx/compose/ui/platform/t1;
    .line 9: new-instance v0, Landroidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1;
    .line 11: invoke-direct {v0}, Landroidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1;-><init>()V
    .line 14: sput-object v0, Landroidx/compose/foundation/b;->b:Landroidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1;
    .line 16: return-void
.end method

# direct methods
.method public static final a(Lk/m;Lf0/p;Z)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: if-eqz v3, :cond_19
    .line 7: new-instance v3, Landroidx/compose/foundation/FocusableElement;
    .line 9: invoke-direct {v3, v1}, Landroidx/compose/foundation/FocusableElement;-><init>(Lk/m;)V
    .line 12: sget-object v1, Landroidx/compose/ui/focus/FocusTargetNode$FocusTargetElement;->c:Landroidx/compose/ui/focus/FocusTargetNode$FocusTargetElement;
    .line 14: invoke-interface {v3, v1}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 17: move-result-object v1
    .line 18: goto :goto_21
    .line 19: sget-object v1, Lf0/m;->c:Lf0/m;
    .line 21: invoke-interface {v2, v1}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 24: move-result-object v1
    .line 25: return-object v1
.end method

.class public abstract Landroidx/compose/foundation/relocation/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf0/p;Lm/f;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "bringIntoViewRequester"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;
    .line 12: invoke-direct {v0, v2}, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;-><init>(Lm/f;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

# direct methods
.method public static final b(Lf0/p;Lm/h;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "responder"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/foundation/relocation/BringIntoViewResponderElement;
    .line 12: invoke-direct {v0, v2}, Landroidx/compose/foundation/relocation/BringIntoViewResponderElement;-><init>(Lm/h;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

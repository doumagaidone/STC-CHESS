.class public final Landroidx/compose/material3/t0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:J
.field public final b:J
.field public final c:J
.field public final d:J
.field public final e:J
.field public final f:J
.field public final g:J
.field public final h:J
.field public final i:J
.field public final j:J

# direct methods
.method public constructor <init>(JJJJJJJJJJ)V
    .registers 24

    .line 0: move-object v0, v3
    .line 1: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 4: move-wide v1, v4
    .line 5: iput-wide v1, v0, Landroidx/compose/material3/t0;->a:J
    .line 7: move-wide v1, v6
    .line 8: iput-wide v1, v0, Landroidx/compose/material3/t0;->b:J
    .line 10: move-wide v1, v8
    .line 11: iput-wide v1, v0, Landroidx/compose/material3/t0;->c:J
    .line 13: move-wide v1, v10
    .line 14: iput-wide v1, v0, Landroidx/compose/material3/t0;->d:J
    .line 16: move-wide v1, v12
    .line 17: iput-wide v1, v0, Landroidx/compose/material3/t0;->e:J
    .line 19: move-wide v1, v14
    .line 20: iput-wide v1, v0, Landroidx/compose/material3/t0;->f:J
    .line 22: move-wide/from16 v1, v16
    .line 24: iput-wide v1, v0, Landroidx/compose/material3/t0;->g:J
    .line 26: move-wide/from16 v1, v18
    .line 28: iput-wide v1, v0, Landroidx/compose/material3/t0;->h:J
    .line 30: move-wide/from16 v1, v20
    .line 32: iput-wide v1, v0, Landroidx/compose/material3/t0;->i:J
    .line 34: move-wide/from16 v1, v22
    .line 36: iput-wide v1, v0, Landroidx/compose/material3/t0;->j:J
    .line 38: return-void
.end method

# virtual methods
.method public final a(ZZLu/l;)Lu/l1;
    .registers 5

    .line 0: check-cast v4, Lu/b0;
    .line 2: const v0, 0x14169eb2
    .line 5: invoke-virtual {v4, v0}, Lu/b0;->d0(I)V
    .line 8: if-eqz v2, :cond_18
    .line 10: if-eqz v3, :cond_15
    .line 12: iget-wide v2, v1, Landroidx/compose/material3/t0;->c:J
    .line 14: goto :goto_25
    .line 15: iget-wide v2, v1, Landroidx/compose/material3/t0;->e:J
    .line 17: goto :goto_25
    .line 18: if-eqz v3, :cond_23
    .line 20: iget-wide v2, v1, Landroidx/compose/material3/t0;->h:J
    .line 22: goto :goto_25
    .line 23: iget-wide v2, v1, Landroidx/compose/material3/t0;->j:J
    .line 25: new-instance v0, Lk0/q;
    .line 27: invoke-direct {v0, v2, v3}, Lk0/q;-><init>(J)V
    .line 30: invoke-static {v0, v4}, Le3/g;->z(Ljava/lang/Object;Lu/l;)Lu/l1;
    .line 33: move-result-object v2
    .line 34: const/4 v3, 0
    .line 35: invoke-virtual {v4, v3}, Lu/b0;->t(Z)V
    .line 38: return-object v2
.end method

# virtual methods
.method public final b(ZZLu/l;)Lu/l1;
    .registers 5

    .line 0: check-cast v4, Lu/b0;
    .line 2: const v0, 0x2d55fa04
    .line 5: invoke-virtual {v4, v0}, Lu/b0;->d0(I)V
    .line 8: if-eqz v2, :cond_18
    .line 10: if-eqz v3, :cond_15
    .line 12: iget-wide v2, v1, Landroidx/compose/material3/t0;->b:J
    .line 14: goto :goto_25
    .line 15: iget-wide v2, v1, Landroidx/compose/material3/t0;->d:J
    .line 17: goto :goto_25
    .line 18: if-eqz v3, :cond_23
    .line 20: iget-wide v2, v1, Landroidx/compose/material3/t0;->g:J
    .line 22: goto :goto_25
    .line 23: iget-wide v2, v1, Landroidx/compose/material3/t0;->i:J
    .line 25: new-instance v0, Lk0/q;
    .line 27: invoke-direct {v0, v2, v3}, Lk0/q;-><init>(J)V
    .line 30: invoke-static {v0, v4}, Le3/g;->z(Ljava/lang/Object;Lu/l;)Lu/l1;
    .line 33: move-result-object v2
    .line 34: const/4 v3, 0
    .line 35: invoke-virtual {v4, v3}, Lu/b0;->t(Z)V
    .line 38: return-object v2
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    .line 0: const/4 v0, 1
    .line 1: if-ne v6, v7, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-eqz v7, :cond_125
    .line 7: instance-of v2, v7, Landroidx/compose/material3/t0;
    .line 9: if-nez v2, :cond_12
    .line 11: goto :goto_125
    .line 12: check-cast v7, Landroidx/compose/material3/t0;
    .line 14: iget-wide v2, v7, Landroidx/compose/material3/t0;->a:J
    .line 16: iget-wide v4, v6, Landroidx/compose/material3/t0;->a:J
    .line 18: invoke-static {v4, v5, v2, v3}, Lk0/q;->d(JJ)Z
    .line 21: move-result v2
    .line 22: if-nez v2, :cond_25
    .line 24: return v1
    .line 25: iget-wide v2, v6, Landroidx/compose/material3/t0;->b:J
    .line 27: iget-wide v4, v7, Landroidx/compose/material3/t0;->b:J
    .line 29: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 32: move-result v2
    .line 33: if-nez v2, :cond_36
    .line 35: return v1
    .line 36: iget-wide v2, v6, Landroidx/compose/material3/t0;->c:J
    .line 38: iget-wide v4, v7, Landroidx/compose/material3/t0;->c:J
    .line 40: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 43: move-result v2
    .line 44: if-nez v2, :cond_47
    .line 46: return v1
    .line 47: iget-wide v2, v6, Landroidx/compose/material3/t0;->d:J
    .line 49: iget-wide v4, v7, Landroidx/compose/material3/t0;->d:J
    .line 51: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 54: move-result v2
    .line 55: if-nez v2, :cond_58
    .line 57: return v1
    .line 58: iget-wide v2, v6, Landroidx/compose/material3/t0;->e:J
    .line 60: iget-wide v4, v7, Landroidx/compose/material3/t0;->e:J
    .line 62: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 65: move-result v2
    .line 66: if-nez v2, :cond_69
    .line 68: return v1
    .line 69: iget-wide v2, v6, Landroidx/compose/material3/t0;->f:J
    .line 71: iget-wide v4, v7, Landroidx/compose/material3/t0;->f:J
    .line 73: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 76: move-result v2
    .line 77: if-nez v2, :cond_80
    .line 79: return v1
    .line 80: iget-wide v2, v6, Landroidx/compose/material3/t0;->g:J
    .line 82: iget-wide v4, v7, Landroidx/compose/material3/t0;->g:J
    .line 84: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 87: move-result v2
    .line 88: if-nez v2, :cond_91
    .line 90: return v1
    .line 91: iget-wide v2, v6, Landroidx/compose/material3/t0;->h:J
    .line 93: iget-wide v4, v7, Landroidx/compose/material3/t0;->h:J
    .line 95: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 98: move-result v2
    .line 99: if-nez v2, :cond_102
    .line 101: return v1
    .line 102: iget-wide v2, v6, Landroidx/compose/material3/t0;->i:J
    .line 104: iget-wide v4, v7, Landroidx/compose/material3/t0;->i:J
    .line 106: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 109: move-result v2
    .line 110: if-nez v2, :cond_113
    .line 112: return v1
    .line 113: iget-wide v2, v6, Landroidx/compose/material3/t0;->j:J
    .line 115: iget-wide v4, v7, Landroidx/compose/material3/t0;->j:J
    .line 117: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 120: move-result v7
    .line 121: if-nez v7, :cond_124
    .line 123: return v1
    .line 124: return v0
    .line 125: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 5

    .line 0: sget v0, Lk0/q;->h:I
    .line 2: iget-wide v0, v4, Landroidx/compose/material3/t0;->a:J
    .line 4: invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I
    .line 7: move-result v0
    .line 8: const/16 v1, 31
    .line 10: mul-int/2addr v0, v1
    .line 11: iget-wide v2, v4, Landroidx/compose/material3/t0;->b:J
    .line 13: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 16: move-result v0
    .line 17: iget-wide v2, v4, Landroidx/compose/material3/t0;->c:J
    .line 19: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 22: move-result v0
    .line 23: iget-wide v2, v4, Landroidx/compose/material3/t0;->d:J
    .line 25: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 28: move-result v0
    .line 29: iget-wide v2, v4, Landroidx/compose/material3/t0;->e:J
    .line 31: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 34: move-result v0
    .line 35: iget-wide v2, v4, Landroidx/compose/material3/t0;->f:J
    .line 37: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 40: move-result v0
    .line 41: iget-wide v2, v4, Landroidx/compose/material3/t0;->g:J
    .line 43: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 46: move-result v0
    .line 47: iget-wide v2, v4, Landroidx/compose/material3/t0;->h:J
    .line 49: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 52: move-result v0
    .line 53: iget-wide v2, v4, Landroidx/compose/material3/t0;->i:J
    .line 55: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 58: move-result v0
    .line 59: iget-wide v1, v4, Landroidx/compose/material3/t0;->j:J
    .line 61: invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I
    .line 64: move-result v1
    .line 65: add-int/2addr v1, v0
    .line 66: return v1
.end method

.class public abstract synthetic Landroidx/compose/material3/k3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:[I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Landroidx/compose/material3/z;->values()[Landroidx/compose/material3/z;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: const/4 v1, 1
    .line 8: const/4 v2, 0
    .line 9: aput v1, v0, v2
    .line 11: const/4 v2, 2
    .line 12: aput v2, v0, v1
    .line 14: const/4 v1, 3
    .line 15: aput v1, v0, v2
    .line 17: sput-object v0, Landroidx/compose/material3/k3;->a:[I
    .line 19: return-void
.end method

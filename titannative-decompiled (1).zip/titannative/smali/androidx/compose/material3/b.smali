.class public abstract Landroidx/compose/material3/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ll/i0;
.field public static final b:Ll/i0;
.field public static final c:F
.field public static final d:F

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: const/16 v0, 24
    .line 2: int-to-float v0, v0
    .line 3: const/16 v1, 8
    .line 5: int-to-float v1, v1
    .line 6: new-instance v2, Ll/i0;
    .line 8: invoke-direct {v2, v0, v1, v0, v1}, Ll/i0;-><init>(FFFF)V
    .line 11: sput-object v2, Landroidx/compose/material3/b;->a:Ll/i0;
    .line 13: const/16 v0, 12
    .line 15: int-to-float v0, v0
    .line 16: new-instance v2, Ll/i0;
    .line 18: invoke-direct {v2, v0, v1, v0, v1}, Ll/i0;-><init>(FFFF)V
    .line 21: sput-object v2, Landroidx/compose/material3/b;->b:Ll/i0;
    .line 23: const/16 v0, 58
    .line 25: int-to-float v0, v0
    .line 26: sput v0, Landroidx/compose/material3/b;->c:F
    .line 28: const/16 v0, 40
    .line 30: int-to-float v0, v0
    .line 31: sput v0, Landroidx/compose/material3/b;->d:F
    .line 33: sget v0, Lt/c;->a:F
    .line 35: return-void
.end method

# direct methods
.method public static a(JJLu/l;I)Landroidx/compose/material3/a;
    .registers 15

    .line 0: check-cast v13, Lu/b0;
    .line 2: const v0, 0xebc6ae55
    .line 5: invoke-virtual {v13, v0}, Lu/b0;->d0(I)V
    .line 8: and-int/lit8 v0, v14, 1
    .line 10: if-eqz v0, :cond_20
    .line 12: sget v9, Lt/c;->a:F
    .line 14: const/16 v9, 20
    .line 16: invoke-static {v9, v13}, Landroidx/compose/material3/m;->a(ILu/l;)J
    .line 19: move-result-wide v9
    .line 20: move-wide v1, v9
    .line 21: and-int/lit8 v9, v14, 2
    .line 23: if-eqz v9, :cond_31
    .line 25: sget v9, Lt/c;->h:I
    .line 27: invoke-static {v9, v13}, Landroidx/compose/material3/m;->a(ILu/l;)J
    .line 30: move-result-wide v11
    .line 31: move-wide v3, v11
    .line 32: and-int/lit8 v9, v14, 4
    .line 34: const-wide/16 v10, 0
    .line 36: if-eqz v9, :cond_52
    .line 38: sget v9, Lt/c;->c:I
    .line 40: invoke-static {v9, v13}, Landroidx/compose/material3/m;->a(ILu/l;)J
    .line 43: move-result-wide v5
    .line 44: const v9, 0x3df5c28f
    .line 47: invoke-static {v5, v6, v9}, Lk0/q;->c(JF)J
    .line 50: move-result-wide v5
    .line 51: goto :goto_53
    .line 52: move-wide v5, v10
    .line 53: and-int/lit8 v9, v14, 8
    .line 55: if-eqz v9, :cond_72
    .line 57: sget v9, Lt/c;->e:I
    .line 59: invoke-static {v9, v13}, Landroidx/compose/material3/m;->a(ILu/l;)J
    .line 62: move-result-wide v9
    .line 63: const v11, 0x3ec28f5c
    .line 66: invoke-static {v9, v10, v11}, Lk0/q;->c(JF)J
    .line 69: move-result-wide v9
    .line 70: move-wide v7, v9
    .line 71: goto :goto_73
    .line 72: move-wide v7, v10
    .line 73: new-instance v9, Landroidx/compose/material3/a;
    .line 75: move-object v0, v9
    .line 76: invoke-direct/range {v0 .. v8}, Landroidx/compose/material3/a;-><init>(JJJJ)V
    .line 79: const/4 v10, 0
    .line 80: invoke-virtual {v13, v10}, Lu/b0;->t(Z)V
    .line 83: return-object v9
.end method

# direct methods
.method public static b(JLu/l;I)Landroidx/compose/material3/a;
    .registers 19

    .line 0: move-object/from16 v0, v17
    .line 2: check-cast v0, Lu/b0;
    .line 4: const v1, 0xac6afc22
    .line 7: invoke-virtual {v0, v1}, Lu/b0;->d0(I)V
    .line 10: and-int/lit8 v1, v18, 1
    .line 12: const-wide/16 v2, 0
    .line 14: if-eqz v1, :cond_20
    .line 16: sget-wide v4, Lk0/q;->f:J
    .line 18: move-wide v7, v4
    .line 19: goto :goto_21
    .line 20: move-wide v7, v2
    .line 21: and-int/lit8 v1, v18, 2
    .line 23: if-eqz v1, :cond_33
    .line 25: sget v1, Ld2/b;->h:I
    .line 27: invoke-static {v1, v0}, Landroidx/compose/material3/m;->a(ILu/l;)J
    .line 30: move-result-wide v4
    .line 31: move-wide v9, v4
    .line 32: goto :goto_34
    .line 33: move-wide v9, v15
    .line 34: and-int/lit8 v1, v18, 4
    .line 36: if-eqz v1, :cond_42
    .line 38: sget-wide v4, Lk0/q;->f:J
    .line 40: move-wide v11, v4
    .line 41: goto :goto_43
    .line 42: move-wide v11, v2
    .line 43: and-int/lit8 v1, v18, 8
    .line 45: if-eqz v1, :cond_60
    .line 47: sget v1, Ld2/b;->g:I
    .line 49: invoke-static {v1, v0}, Landroidx/compose/material3/m;->a(ILu/l;)J
    .line 52: move-result-wide v1
    .line 53: const v3, 0x3ec28f5c
    .line 56: invoke-static {v1, v2, v3}, Lk0/q;->c(JF)J
    .line 59: move-result-wide v2
    .line 60: move-wide v13, v2
    .line 61: new-instance v1, Landroidx/compose/material3/a;
    .line 63: move-object v6, v1
    .line 64: invoke-direct/range {v6 .. v14}, Landroidx/compose/material3/a;-><init>(JJJJ)V
    .line 67: const/4 v2, 0
    .line 68: invoke-virtual {v0, v2}, Lu/b0;->t(Z)V
    .line 71: return-object v1
.end method

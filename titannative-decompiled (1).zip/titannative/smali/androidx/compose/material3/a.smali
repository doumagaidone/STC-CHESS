.class public final Landroidx/compose/material3/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:J
.field public final b:J
.field public final c:J
.field public final d:J

# direct methods
.method public constructor <init>(JJJJ)V
    .registers 9

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-wide v1, v0, Landroidx/compose/material3/a;->a:J
    .line 5: iput-wide v3, v0, Landroidx/compose/material3/a;->b:J
    .line 7: iput-wide v5, v0, Landroidx/compose/material3/a;->c:J
    .line 9: iput-wide v7, v0, Landroidx/compose/material3/a;->d:J
    .line 11: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    .line 0: const/4 v0, 1
    .line 1: if-ne v6, v7, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-eqz v7, :cond_59
    .line 7: instance-of v2, v7, Landroidx/compose/material3/a;
    .line 9: if-nez v2, :cond_12
    .line 11: goto :goto_59
    .line 12: check-cast v7, Landroidx/compose/material3/a;
    .line 14: iget-wide v2, v7, Landroidx/compose/material3/a;->a:J
    .line 16: iget-wide v4, v6, Landroidx/compose/material3/a;->a:J
    .line 18: invoke-static {v4, v5, v2, v3}, Lk0/q;->d(JJ)Z
    .line 21: move-result v2
    .line 22: if-nez v2, :cond_25
    .line 24: return v1
    .line 25: iget-wide v2, v6, Landroidx/compose/material3/a;->b:J
    .line 27: iget-wide v4, v7, Landroidx/compose/material3/a;->b:J
    .line 29: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 32: move-result v2
    .line 33: if-nez v2, :cond_36
    .line 35: return v1
    .line 36: iget-wide v2, v6, Landroidx/compose/material3/a;->c:J
    .line 38: iget-wide v4, v7, Landroidx/compose/material3/a;->c:J
    .line 40: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 43: move-result v2
    .line 44: if-nez v2, :cond_47
    .line 46: return v1
    .line 47: iget-wide v2, v6, Landroidx/compose/material3/a;->d:J
    .line 49: iget-wide v4, v7, Landroidx/compose/material3/a;->d:J
    .line 51: invoke-static {v2, v3, v4, v5}, Lk0/q;->d(JJ)Z
    .line 54: move-result v7
    .line 55: if-nez v7, :cond_58
    .line 57: return v1
    .line 58: return v0
    .line 59: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 5

    .line 0: sget v0, Lk0/q;->h:I
    .line 2: iget-wide v0, v4, Landroidx/compose/material3/a;->a:J
    .line 4: invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I
    .line 7: move-result v0
    .line 8: const/16 v1, 31
    .line 10: mul-int/2addr v0, v1
    .line 11: iget-wide v2, v4, Landroidx/compose/material3/a;->b:J
    .line 13: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 16: move-result v0
    .line 17: iget-wide v2, v4, Landroidx/compose/material3/a;->c:J
    .line 19: invoke-static {v2, v3, v0, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 22: move-result v0
    .line 23: iget-wide v1, v4, Landroidx/compose/material3/a;->d:J
    .line 25: invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I
    .line 28: move-result v1
    .line 29: add-int/2addr v1, v0
    .line 30: return v1
.end method

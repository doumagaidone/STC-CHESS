.class public abstract Landroidx/compose/material3/y;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lf0/p;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Lf0/m;->c:Lf0/m;
    .line 2: sget v1, Lt/d;->a:F
    .line 4: sget v1, Lt/d;->a:F
    .line 6: invoke-static {v0, v1}, Landroidx/compose/foundation/layout/c;->i(Lf0/p;F)Lf0/p;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Landroidx/compose/material3/y;->a:Lf0/p;
    .line 12: return-void
.end method

# direct methods
.method public static final a(Ln0/b;Ljava/lang/String;Lf0/p;JLu/l;II)V
    .registers 23

    .line 0: move-object/from16 v2, v16
    .line 2: const-string v0, "painter"
    .line 4: move-object v1, v15
    .line 5: invoke-static {v15, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 8: move-object/from16 v0, v20
    .line 10: check-cast v0, Lu/b0;
    .line 12: const v3, 0x80500507
    .line 15: invoke-virtual {v0, v3}, Lu/b0;->e0(I)Lu/b0;
    .line 18: and-int/lit8 v3, v22, 4
    .line 20: sget-object v4, Lf0/m;->c:Lf0/m;
    .line 22: if-eqz v3, :cond_26
    .line 24: move-object v10, v4
    .line 25: goto :goto_28
    .line 26: move-object/from16 v10, v17
    .line 28: and-int/lit8 v3, v22, 8
    .line 30: if-eqz v3, :cond_44
    .line 32: sget-object v3, Landroidx/compose/material3/r;->a:Lu/w0;
    .line 34: invoke-virtual {v0, v3}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 37: move-result-object v3
    .line 38: check-cast v3, Lk0/q;
    .line 40: iget-wide v5, v3, Lk0/q;->a:J
    .line 42: move-wide v11, v5
    .line 43: goto :goto_46
    .line 44: move-wide/from16 v11, v18
    .line 46: sget-wide v5, Lk0/q;->g:J
    .line 48: invoke-static {v11, v12, v5, v6}, Lk0/q;->d(JJ)Z
    .line 51: move-result v3
    .line 52: if-eqz v3, :cond_57
    .line 54: const/4 v3, 0
    .line 55: move-object v8, v3
    .line 56: goto :goto_90
    .line 57: sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 59: const/16 v5, 29
    .line 61: const/4 v6, 5
    .line 62: if-lt v3, v5, :cond_71
    .line 64: sget-object v3, Lk0/k;->a:Lk0/k;
    .line 66: invoke-virtual {v3, v11, v12, v6}, Lk0/k;->a(JI)Landroid/graphics/BlendModeColorFilter;
    .line 69: move-result-object v3
    .line 70: goto :goto_84
    .line 71: new-instance v3, Landroid/graphics/PorterDuffColorFilter;
    .line 73: invoke-static {v11, v12}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 76: move-result v5
    .line 77: invoke-static {v6}, Landroidx/compose/ui/graphics/a;->v(I)Landroid/graphics/PorterDuff$Mode;
    .line 80: move-result-object v6
    .line 81: invoke-direct {v3, v5, v6}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V
    .line 84: new-instance v5, Lk0/r;
    .line 86: invoke-direct {v5, v3}, Lk0/r;-><init>(Landroid/graphics/ColorFilter;)V
    .line 89: move-object v8, v5
    .line 90: const v3, 0x4224d11
    .line 93: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 96: const/4 v13, 0
    .line 97: if-eqz v2, :cond_139
    .line 99: const v3, 0x44faf204
    .line 102: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 105: invoke-virtual {v0, v2}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 108: move-result v3
    .line 109: invoke-virtual {v0}, Lu/b0;->I()Ljava/lang/Object;
    .line 112: move-result-object v5
    .line 113: if-nez v3, :cond_119
    .line 115: sget-object v3, Lu/k;->i:Landroidx/activity/b;
    .line 117: if-ne v5, v3, :cond_128
    .line 119: new-instance v5, Landroidx/compose/material3/u1;
    .line 121: const/4 v3, 2
    .line 122: invoke-direct {v5, v3, v2}, Landroidx/compose/material3/u1;-><init>(ILjava/lang/Object;)V
    .line 125: invoke-virtual {v0, v5}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 128: invoke-virtual {v0, v13}, Lu/b0;->t(Z)V
    .line 131: check-cast v5, Ld3/c;
    .line 133: invoke-static {v4, v13, v5}, Ld1/k;->a(Lf0/p;ZLd3/c;)Lf0/p;
    .line 136: move-result-object v3
    .line 137: move-object v14, v3
    .line 138: goto :goto_140
    .line 139: move-object v14, v4
    .line 140: invoke-virtual {v0, v13}, Lu/b0;->t(Z)V
    .line 143: const-string v3, "<this>"
    .line 145: invoke-static {v10, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 148: invoke-virtual {v15}, Ln0/b;->c()J
    .line 151: move-result-wide v5
    .line 152: move-object/from16 v18, v14
    .line 154: sget-wide v13, Lj0/f;->c:J
    .line 156: invoke-static {v5, v6, v13, v14}, Lj0/f;->a(JJ)Z
    .line 159: move-result v3
    .line 160: if-nez v3, :cond_186
    .line 162: invoke-virtual {v15}, Ln0/b;->c()J
    .line 165: move-result-wide v5
    .line 166: invoke-static {v5, v6}, Lj0/f;->d(J)F
    .line 169: move-result v3
    .line 170: invoke-static {v3}, Ljava/lang/Float;->isInfinite(F)Z
    .line 173: move-result v3
    .line 174: if-eqz v3, :cond_188
    .line 176: invoke-static {v5, v6}, Lj0/f;->b(J)F
    .line 179: move-result v3
    .line 180: invoke-static {v3}, Ljava/lang/Float;->isInfinite(F)Z
    .line 183: move-result v3
    .line 184: if-eqz v3, :cond_188
    .line 186: sget-object v4, Landroidx/compose/material3/y;->a:Lf0/p;
    .line 188: invoke-interface {v10, v4}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 191: move-result-object v3
    .line 192: sget-object v6, Lx0/g;->a:Lz3/b;
    .line 194: const/4 v5, 0
    .line 195: const/4 v7, 0
    .line 196: const/16 v9, 22
    .line 198: move-object v4, v15
    .line 199: invoke-static/range {v3 .. v9}, Landroidx/compose/ui/draw/a;->g(Lf0/p;Ln0/b;Lf0/d;Lx0/h;FLk0/r;I)Lf0/p;
    .line 202: move-result-object v3
    .line 203: move-object/from16 v4, v18
    .line 205: invoke-interface {v3, v4}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 208: move-result-object v3
    .line 209: const/4 v4, 0
    .line 210: invoke-static {v3, v0, v4}, Ll/r;->a(Lf0/p;Lu/l;I)V
    .line 213: invoke-virtual {v0}, Lu/b0;->x()Lu/c2;
    .line 216: move-result-object v9
    .line 217: if-nez v9, :cond_220
    .line 219: goto :goto_238
    .line 220: new-instance v13, Landroidx/compose/material3/x;
    .line 222: const/4 v8, 1
    .line 223: move-object v0, v13
    .line 224: move-object v1, v15
    .line 225: move-object/from16 v2, v16
    .line 227: move-object v3, v10
    .line 228: move-wide v4, v11
    .line 229: move/from16 v6, v21
    .line 231: move/from16 v7, v22
    .line 233: invoke-direct/range {v0 .. v8}, Landroidx/compose/material3/x;-><init>(Ljava/lang/Object;Ljava/lang/String;Lf0/p;JIII)V
    .line 236: iput-object v13, v9, Lu/c2;->d:Ld3/e;
    .line 238: return-void
.end method

# direct methods
.method public static final b(Lo0/f;Ljava/lang/String;Lf0/p;JLu/l;II)V
    .registers 25

    .line 0: move-object/from16 v1, v17
    .line 2: move/from16 v6, v23
    .line 4: const-string v0, "imageVector"
    .line 6: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: move-object/from16 v0, v22
    .line 11: check-cast v0, Lu/b0;
    .line 13: const v2, 0xf86fcc34
    .line 16: invoke-virtual {v0, v2}, Lu/b0;->e0(I)Lu/b0;
    .line 19: and-int/lit8 v2, v24, 1
    .line 21: if-eqz v2, :cond_26
    .line 23: or-int/lit8 v2, v6, 6
    .line 25: goto :goto_42
    .line 26: and-int/lit8 v2, v6, 14
    .line 28: if-nez v2, :cond_41
    .line 30: invoke-virtual {v0, v1}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 33: move-result v2
    .line 34: if-eqz v2, :cond_38
    .line 36: const/4 v2, 4
    .line 37: goto :goto_39
    .line 38: const/4 v2, 2
    .line 39: or-int/2addr v2, v6
    .line 40: goto :goto_42
    .line 41: move v2, v6
    .line 42: and-int/lit8 v3, v24, 2
    .line 44: if-eqz v3, :cond_51
    .line 46: or-int/lit8 v2, v2, 48
    .line 48: move-object/from16 v3, v18
    .line 50: goto :goto_69
    .line 51: and-int/lit8 v3, v6, 112
    .line 53: if-nez v3, :cond_48
    .line 55: move-object/from16 v3, v18
    .line 57: invoke-virtual {v0, v3}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 60: move-result v4
    .line 61: if-eqz v4, :cond_66
    .line 63: const/16 v4, 32
    .line 65: goto :goto_68
    .line 66: const/16 v4, 16
    .line 68: or-int/2addr v2, v4
    .line 69: and-int/lit8 v4, v24, 4
    .line 71: if-eqz v4, :cond_78
    .line 73: or-int/lit16 v2, v2, 384
    .line 75: move-object/from16 v5, v19
    .line 77: goto :goto_96
    .line 78: and-int/lit16 v5, v6, 896
    .line 80: if-nez v5, :cond_75
    .line 82: move-object/from16 v5, v19
    .line 84: invoke-virtual {v0, v5}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 87: move-result v7
    .line 88: if-eqz v7, :cond_93
    .line 90: const/16 v7, 256
    .line 92: goto :goto_95
    .line 93: const/16 v7, 128
    .line 95: or-int/2addr v2, v7
    .line 96: and-int/lit16 v7, v6, 7168
    .line 98: if-nez v7, :cond_121
    .line 100: and-int/lit8 v7, v24, 8
    .line 102: if-nez v7, :cond_115
    .line 104: move-wide/from16 v7, v20
    .line 106: invoke-virtual {v0, v7, v8}, Lu/b0;->e(J)Z
    .line 109: move-result v9
    .line 110: if-eqz v9, :cond_117
    .line 112: const/16 v9, 2048
    .line 114: goto :goto_119
    .line 115: move-wide/from16 v7, v20
    .line 117: const/16 v9, 1024
    .line 119: or-int/2addr v2, v9
    .line 120: goto :goto_123
    .line 121: move-wide/from16 v7, v20
    .line 123: and-int/lit16 v9, v2, 5851
    .line 125: const/16 v10, 1170
    .line 127: if-ne v9, v10, :cond_142
    .line 129: invoke-virtual {v0}, Lu/b0;->F()Z
    .line 132: move-result v9
    .line 133: if-nez v9, :cond_136
    .line 135: goto :goto_142
    .line 136: invoke-virtual {v0}, Lu/b0;->Y()V
    .line 139: move-object v4, v5
    .line 140: move-wide v15, v7
    .line 141: goto :goto_219
    .line 142: invoke-virtual {v0}, Lu/b0;->a0()V
    .line 145: and-int/lit8 v9, v6, 1
    .line 147: if-eqz v9, :cond_168
    .line 149: invoke-virtual {v0}, Lu/b0;->D()Z
    .line 152: move-result v9
    .line 153: if-eqz v9, :cond_156
    .line 155: goto :goto_168
    .line 156: invoke-virtual {v0}, Lu/b0;->Y()V
    .line 159: and-int/lit8 v4, v24, 8
    .line 161: if-eqz v4, :cond_165
    .line 163: and-int/lit16 v2, v2, -7169
    .line 165: move-object v4, v5
    .line 166: move-wide v15, v7
    .line 167: goto :goto_191
    .line 168: if-eqz v4, :cond_173
    .line 170: sget-object v4, Lf0/m;->c:Lf0/m;
    .line 172: goto :goto_174
    .line 173: move-object v4, v5
    .line 174: and-int/lit8 v5, v24, 8
    .line 176: if-eqz v5, :cond_166
    .line 178: sget-object v5, Landroidx/compose/material3/r;->a:Lu/w0;
    .line 180: invoke-virtual {v0, v5}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 183: move-result-object v5
    .line 184: check-cast v5, Lk0/q;
    .line 186: iget-wide v7, v5, Lk0/q;->a:J
    .line 188: and-int/lit16 v2, v2, -7169
    .line 190: goto :goto_166
    .line 191: invoke-virtual {v0}, Lu/b0;->u()V
    .line 194: invoke-static {v1, v0}, Ld2/b;->X0(Lo0/f;Lu/l;)Lo0/n0;
    .line 197: move-result-object v7
    .line 198: and-int/lit8 v5, v2, 112
    .line 200: const/16 v8, 8
    .line 202: or-int/2addr v5, v8
    .line 203: and-int/lit16 v8, v2, 896
    .line 205: or-int/2addr v5, v8
    .line 206: and-int/lit16 v2, v2, 7168
    .line 208: or-int v13, v5, v2
    .line 210: const/4 v14, 0
    .line 211: move-object/from16 v8, v18
    .line 213: move-object v9, v4
    .line 214: move-wide v10, v15
    .line 215: move-object v12, v0
    .line 216: invoke-static/range {v7 .. v14}, Landroidx/compose/material3/y;->a(Ln0/b;Ljava/lang/String;Lf0/p;JLu/l;II)V
    .line 219: invoke-virtual {v0}, Lu/b0;->x()Lu/c2;
    .line 222: move-result-object v9
    .line 223: if-nez v9, :cond_226
    .line 225: goto :goto_245
    .line 226: new-instance v10, Landroidx/compose/material3/x;
    .line 228: const/4 v8, 0
    .line 229: move-object v0, v10
    .line 230: move-object/from16 v1, v17
    .line 232: move-object/from16 v2, v18
    .line 234: move-object v3, v4
    .line 235: move-wide v4, v15
    .line 236: move/from16 v6, v23
    .line 238: move/from16 v7, v24
    .line 240: invoke-direct/range {v0 .. v8}, Landroidx/compose/material3/x;-><init>(Ljava/lang/Object;Ljava/lang/String;Lf0/p;JIII)V
    .line 243: iput-object v10, v9, Lu/c2;->d:Ld3/e;
    .line 245: return-void
.end method

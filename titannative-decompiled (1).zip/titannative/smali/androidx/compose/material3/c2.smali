.class public final Landroidx/compose/material3/c2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lkotlinx/coroutines/sync/g;
.field public final b:Lu/s1;

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: invoke-static {v0}, Lkotlinx/coroutines/sync/h;->a(Z)Lkotlinx/coroutines/sync/g;
    .line 7: move-result-object v0
    .line 8: iput-object v0, v2, Landroidx/compose/material3/c2;->a:Lkotlinx/coroutines/sync/g;
    .line 10: sget-object v0, Lu/l3;->a:Lu/l3;
    .line 12: const/4 v1, 0
    .line 13: invoke-static {v1, v0}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 16: move-result-object v0
    .line 17: iput-object v0, v2, Landroidx/compose/material3/c2;->b:Lu/s1;
    .line 19: return-void
.end method

# direct methods
.method public static b(Landroidx/compose/material3/c2;Ljava/lang/String;Lw2/e;)Ljava/lang/Object;
    .registers 7

    .line 0: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: new-instance v0, Landroidx/compose/material3/a2;
    .line 5: const/4 v1, 0
    .line 6: const/4 v2, 0
    .line 7: const/4 v3, 1
    .line 8: invoke-direct {v0, v5, v1, v2, v3}, Landroidx/compose/material3/a2;-><init>(Ljava/lang/String;Ljava/lang/String;ZI)V
    .line 11: invoke-virtual {v4, v0, v6}, Landroidx/compose/material3/c2;->a(Landroidx/compose/material3/a2;Lw2/e;)Ljava/lang/Object;
    .line 14: move-result-object v4
    .line 15: return-object v4
.end method

# virtual methods
.method public final a(Landroidx/compose/material3/a2;Lw2/e;)Ljava/lang/Object;
    .registers 11

    .line 0: instance-of v0, v10, Landroidx/compose/material3/b2;
    .line 2: if-eqz v0, :cond_19
    .line 4: move-object v0, v10
    .line 5: check-cast v0, Landroidx/compose/material3/b2;
    .line 7: iget v1, v0, Landroidx/compose/material3/b2;->q:I
    .line 9: const/high16 v2, 0x8000
    .line 11: and-int v3, v1, v2
    .line 13: if-eqz v3, :cond_19
    .line 15: sub-int/2addr v1, v2
    .line 16: iput v1, v0, Landroidx/compose/material3/b2;->q:I
    .line 18: goto :goto_24
    .line 19: new-instance v0, Landroidx/compose/material3/b2;
    .line 21: invoke-direct {v0, v8, v10}, Landroidx/compose/material3/b2;-><init>(Landroidx/compose/material3/c2;Lw2/e;)V
    .line 24: iget-object v10, v0, Landroidx/compose/material3/b2;->o:Ljava/lang/Object;
    .line 26: sget-object v1, Lx2/a;->i:Lx2/a;
    .line 28: iget v2, v0, Landroidx/compose/material3/b2;->q:I
    .line 30: const/4 v3, 2
    .line 31: const/4 v4, 1
    .line 32: const/4 v5, 0
    .line 33: if-eqz v2, :cond_70
    .line 35: if-eq v2, v4, :cond_58
    .line 37: if-ne v2, v3, :cond_50
    .line 39: iget-object v9, v0, Landroidx/compose/material3/b2;->n:Lkotlinx/coroutines/sync/b;
    .line 41: iget-object v0, v0, Landroidx/compose/material3/b2;->l:Landroidx/compose/material3/c2;
    .line 43: invoke-static {v10}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 46: goto :goto_135
    .line 47: move-exception v10
    .line 48: goto/16 :goto_151
    .line 50: new-instance v9, Ljava/lang/IllegalStateException;
    .line 52: const-string v10, "call to 'resume' before 'invoke' with coroutine"
    .line 54: invoke-direct {v9, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 57: throw v9
    .line 58: iget-object v9, v0, Landroidx/compose/material3/b2;->n:Lkotlinx/coroutines/sync/b;
    .line 60: iget-object v2, v0, Landroidx/compose/material3/b2;->m:Landroidx/compose/material3/a2;
    .line 62: iget-object v6, v0, Landroidx/compose/material3/b2;->l:Landroidx/compose/material3/c2;
    .line 64: invoke-static {v10}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 67: move-object v10, v9
    .line 68: move-object v9, v2
    .line 69: goto :goto_91
    .line 70: invoke-static {v10}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 73: iput-object v8, v0, Landroidx/compose/material3/b2;->l:Landroidx/compose/material3/c2;
    .line 75: iput-object v9, v0, Landroidx/compose/material3/b2;->m:Landroidx/compose/material3/a2;
    .line 77: iget-object v10, v8, Landroidx/compose/material3/c2;->a:Lkotlinx/coroutines/sync/g;
    .line 79: iput-object v10, v0, Landroidx/compose/material3/b2;->n:Lkotlinx/coroutines/sync/b;
    .line 81: iput v4, v0, Landroidx/compose/material3/b2;->q:I
    .line 83: invoke-virtual {v10, v5, v0}, Lkotlinx/coroutines/sync/g;->a(Ljava/lang/Object;Lw2/e;)Ljava/lang/Object;
    .line 86: move-result-object v2
    .line 87: if-ne v2, v1, :cond_90
    .line 89: return-object v1
    .line 90: move-object v6, v8
    .line 91: iput-object v6, v0, Landroidx/compose/material3/b2;->l:Landroidx/compose/material3/c2;
    .line 93: iput-object v9, v0, Landroidx/compose/material3/b2;->m:Landroidx/compose/material3/a2;
    .line 95: iput-object v10, v0, Landroidx/compose/material3/b2;->n:Lkotlinx/coroutines/sync/b;
    .line 97: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 100: iput v3, v0, Landroidx/compose/material3/b2;->q:I
    .line 102: new-instance v2, Ln3/h;
    .line 104: invoke-static {v0}, Ld2/b;->x0(Lw2/e;)Lw2/e;
    .line 107: move-result-object v0
    .line 108: invoke-direct {v2, v4, v0}, Ln3/h;-><init>(ILw2/e;)V
    .line 111: invoke-virtual {v2}, Ln3/h;->q()V
    .line 114: new-instance v0, Landroidx/compose/material3/z1;
    .line 116: invoke-direct {v0, v9, v2}, Landroidx/compose/material3/z1;-><init>(Landroidx/compose/material3/a2;Ln3/h;)V
    .line 119: iget-object v9, v6, Landroidx/compose/material3/c2;->b:Lu/s1;
    .line 121: invoke-virtual {v9, v0}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 124: invoke-virtual {v2}, Ln3/h;->p()Ljava/lang/Object;
    .line 127: move-result-object v9
    .line 128: if-ne v9, v1, :cond_131
    .line 130: return-object v1
    .line 131: move-object v0, v6
    .line 132: move-object v7, v10
    .line 133: move-object v10, v9
    .line 134: move-object v9, v7
    .line 135: iget-object v0, v0, Landroidx/compose/material3/c2;->b:Lu/s1;
    .line 137: invoke-virtual {v0, v5}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 140: check-cast v9, Lkotlinx/coroutines/sync/g;
    .line 142: invoke-virtual {v9, v5}, Lkotlinx/coroutines/sync/g;->b(Ljava/lang/Object;)V
    .line 145: return-object v10
    .line 146: move-exception v9
    .line 147: move-object v0, v6
    .line 148: move-object v7, v10
    .line 149: move-object v10, v9
    .line 150: move-object v9, v7
    .line 151: iget-object v0, v0, Landroidx/compose/material3/c2;->b:Lu/s1;
    .line 153: invoke-virtual {v0, v5}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 156: throw v10
    .line 157: move-exception v10
    .line 158: check-cast v9, Lkotlinx/coroutines/sync/g;
    .line 160: invoke-virtual {v9, v5}, Lkotlinx/coroutines/sync/g;->b(Ljava/lang/Object;)V
    .line 163: throw v10
.end method

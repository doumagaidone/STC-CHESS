.class public abstract Landroidx/compose/material3/s;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lf1/s;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: new-instance v0, Lf1/s;
    .line 2: new-instance v1, Lf1/q;
    .line 4: invoke-direct {v1}, Lf1/q;-><init>()V
    .line 7: const/4 v2, 0
    .line 8: invoke-direct {v0, v2, v1}, Lf1/s;-><init>(Lf1/r;Lf1/q;)V
    .line 11: sput-object v0, Landroidx/compose/material3/s;->a:Lf1/s;
    .line 13: return-void
.end method

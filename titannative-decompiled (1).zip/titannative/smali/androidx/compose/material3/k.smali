.class public final Landroidx/compose/material3/k;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final A:Lu/s1;
.field public final B:Lu/s1;
.field public final C:Lu/s1;
.field public final a:Lu/s1;
.field public final b:Lu/s1;
.field public final c:Lu/s1;
.field public final d:Lu/s1;
.field public final e:Lu/s1;
.field public final f:Lu/s1;
.field public final g:Lu/s1;
.field public final h:Lu/s1;
.field public final i:Lu/s1;
.field public final j:Lu/s1;
.field public final k:Lu/s1;
.field public final l:Lu/s1;
.field public final m:Lu/s1;
.field public final n:Lu/s1;
.field public final o:Lu/s1;
.field public final p:Lu/s1;
.field public final q:Lu/s1;
.field public final r:Lu/s1;
.field public final s:Lu/s1;
.field public final t:Lu/s1;
.field public final u:Lu/s1;
.field public final v:Lu/s1;
.field public final w:Lu/s1;
.field public final x:Lu/s1;
.field public final y:Lu/s1;
.field public final z:Lu/s1;

# direct methods
.method public constructor <init>(JJJJJJJJJJJJJJJJJJJJJJJJJJJJJ)V
    .registers 64

    .line 0: move-object v0, v5
    .line 1: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 4: new-instance v1, Lk0/q;
    .line 6: move-wide v2, v6
    .line 7: invoke-direct {v1, v6, v7}, Lk0/q;-><init>(J)V
    .line 10: sget-object v2, Lu/l3;->a:Lu/l3;
    .line 12: invoke-static {v1, v2}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 15: move-result-object v1
    .line 16: iput-object v1, v0, Landroidx/compose/material3/k;->a:Lu/s1;
    .line 18: move-wide v3, v8
    .line 19: invoke-static {v8, v9, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 22: move-result-object v1
    .line 23: iput-object v1, v0, Landroidx/compose/material3/k;->b:Lu/s1;
    .line 25: move-wide v3, v10
    .line 26: invoke-static {v10, v11, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 29: move-result-object v1
    .line 30: iput-object v1, v0, Landroidx/compose/material3/k;->c:Lu/s1;
    .line 32: move-wide v3, v12
    .line 33: invoke-static {v12, v13, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 36: move-result-object v1
    .line 37: iput-object v1, v0, Landroidx/compose/material3/k;->d:Lu/s1;
    .line 39: move-wide v3, v14
    .line 40: invoke-static {v14, v15, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 43: move-result-object v1
    .line 44: iput-object v1, v0, Landroidx/compose/material3/k;->e:Lu/s1;
    .line 46: move-wide/from16 v3, v16
    .line 48: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 51: move-result-object v1
    .line 52: iput-object v1, v0, Landroidx/compose/material3/k;->f:Lu/s1;
    .line 54: move-wide/from16 v3, v18
    .line 56: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 59: move-result-object v1
    .line 60: iput-object v1, v0, Landroidx/compose/material3/k;->g:Lu/s1;
    .line 62: move-wide/from16 v3, v20
    .line 64: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 67: move-result-object v1
    .line 68: iput-object v1, v0, Landroidx/compose/material3/k;->h:Lu/s1;
    .line 70: move-wide/from16 v3, v22
    .line 72: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 75: move-result-object v1
    .line 76: iput-object v1, v0, Landroidx/compose/material3/k;->i:Lu/s1;
    .line 78: move-wide/from16 v3, v24
    .line 80: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 83: move-result-object v1
    .line 84: iput-object v1, v0, Landroidx/compose/material3/k;->j:Lu/s1;
    .line 86: move-wide/from16 v3, v26
    .line 88: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 91: move-result-object v1
    .line 92: iput-object v1, v0, Landroidx/compose/material3/k;->k:Lu/s1;
    .line 94: move-wide/from16 v3, v28
    .line 96: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 99: move-result-object v1
    .line 100: iput-object v1, v0, Landroidx/compose/material3/k;->l:Lu/s1;
    .line 102: move-wide/from16 v3, v30
    .line 104: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 107: move-result-object v1
    .line 108: iput-object v1, v0, Landroidx/compose/material3/k;->m:Lu/s1;
    .line 110: move-wide/from16 v3, v32
    .line 112: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 115: move-result-object v1
    .line 116: iput-object v1, v0, Landroidx/compose/material3/k;->n:Lu/s1;
    .line 118: move-wide/from16 v3, v34
    .line 120: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 123: move-result-object v1
    .line 124: iput-object v1, v0, Landroidx/compose/material3/k;->o:Lu/s1;
    .line 126: move-wide/from16 v3, v36
    .line 128: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 131: move-result-object v1
    .line 132: iput-object v1, v0, Landroidx/compose/material3/k;->p:Lu/s1;
    .line 134: move-wide/from16 v3, v38
    .line 136: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 139: move-result-object v1
    .line 140: iput-object v1, v0, Landroidx/compose/material3/k;->q:Lu/s1;
    .line 142: new-instance v1, Lk0/q;
    .line 144: move-wide/from16 v3, v40
    .line 146: invoke-direct {v1, v3, v4}, Lk0/q;-><init>(J)V
    .line 149: invoke-static {v1, v2}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 152: move-result-object v1
    .line 153: iput-object v1, v0, Landroidx/compose/material3/k;->r:Lu/s1;
    .line 155: move-wide/from16 v3, v42
    .line 157: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 160: move-result-object v1
    .line 161: iput-object v1, v0, Landroidx/compose/material3/k;->s:Lu/s1;
    .line 163: move-wide/from16 v3, v44
    .line 165: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 168: move-result-object v1
    .line 169: iput-object v1, v0, Landroidx/compose/material3/k;->t:Lu/s1;
    .line 171: move-wide/from16 v3, v46
    .line 173: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 176: move-result-object v1
    .line 177: iput-object v1, v0, Landroidx/compose/material3/k;->u:Lu/s1;
    .line 179: move-wide/from16 v3, v48
    .line 181: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 184: move-result-object v1
    .line 185: iput-object v1, v0, Landroidx/compose/material3/k;->v:Lu/s1;
    .line 187: move-wide/from16 v3, v50
    .line 189: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 192: move-result-object v1
    .line 193: iput-object v1, v0, Landroidx/compose/material3/k;->w:Lu/s1;
    .line 195: move-wide/from16 v3, v52
    .line 197: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 200: move-result-object v1
    .line 201: iput-object v1, v0, Landroidx/compose/material3/k;->x:Lu/s1;
    .line 203: move-wide/from16 v3, v54
    .line 205: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 208: move-result-object v1
    .line 209: iput-object v1, v0, Landroidx/compose/material3/k;->y:Lu/s1;
    .line 211: move-wide/from16 v3, v56
    .line 213: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 216: move-result-object v1
    .line 217: iput-object v1, v0, Landroidx/compose/material3/k;->z:Lu/s1;
    .line 219: move-wide/from16 v3, v58
    .line 221: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 224: move-result-object v1
    .line 225: iput-object v1, v0, Landroidx/compose/material3/k;->A:Lu/s1;
    .line 227: move-wide/from16 v3, v60
    .line 229: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 232: move-result-object v1
    .line 233: iput-object v1, v0, Landroidx/compose/material3/k;->B:Lu/s1;
    .line 235: move-wide/from16 v3, v62
    .line 237: invoke-static {v3, v4, v2}, Lai/onnxruntime/b;->l(JLu/l3;)Lu/s1;
    .line 240: move-result-object v1
    .line 241: iput-object v1, v0, Landroidx/compose/material3/k;->C:Lu/s1;
    .line 243: return-void
.end method

# virtual methods
.method public final a()J
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/compose/material3/k;->p:Lu/s1;
    .line 2: invoke-virtual {v0}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lk0/q;
    .line 8: iget-wide v0, v0, Lk0/q;->a:J
    .line 10: return-wide v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ColorScheme(primary="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v4, Landroidx/compose/material3/k;->a:Lu/s1;
    .line 9: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 12: move-result-object v1
    .line 13: check-cast v1, Lk0/q;
    .line 15: iget-wide v1, v1, Lk0/q;->a:J
    .line 17: const-string v3, "onPrimary="
    .line 19: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 22: iget-object v1, v4, Landroidx/compose/material3/k;->b:Lu/s1;
    .line 24: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 27: move-result-object v1
    .line 28: check-cast v1, Lk0/q;
    .line 30: iget-wide v1, v1, Lk0/q;->a:J
    .line 32: const-string v3, "primaryContainer="
    .line 34: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 37: iget-object v1, v4, Landroidx/compose/material3/k;->c:Lu/s1;
    .line 39: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 42: move-result-object v1
    .line 43: check-cast v1, Lk0/q;
    .line 45: iget-wide v1, v1, Lk0/q;->a:J
    .line 47: const-string v3, "onPrimaryContainer="
    .line 49: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 52: iget-object v1, v4, Landroidx/compose/material3/k;->d:Lu/s1;
    .line 54: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 57: move-result-object v1
    .line 58: check-cast v1, Lk0/q;
    .line 60: iget-wide v1, v1, Lk0/q;->a:J
    .line 62: const-string v3, "inversePrimary="
    .line 64: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 67: iget-object v1, v4, Landroidx/compose/material3/k;->e:Lu/s1;
    .line 69: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 72: move-result-object v1
    .line 73: check-cast v1, Lk0/q;
    .line 75: iget-wide v1, v1, Lk0/q;->a:J
    .line 77: const-string v3, "secondary="
    .line 79: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 82: iget-object v1, v4, Landroidx/compose/material3/k;->f:Lu/s1;
    .line 84: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 87: move-result-object v1
    .line 88: check-cast v1, Lk0/q;
    .line 90: iget-wide v1, v1, Lk0/q;->a:J
    .line 92: const-string v3, "onSecondary="
    .line 94: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 97: iget-object v1, v4, Landroidx/compose/material3/k;->g:Lu/s1;
    .line 99: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 102: move-result-object v1
    .line 103: check-cast v1, Lk0/q;
    .line 105: iget-wide v1, v1, Lk0/q;->a:J
    .line 107: const-string v3, "secondaryContainer="
    .line 109: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 112: iget-object v1, v4, Landroidx/compose/material3/k;->h:Lu/s1;
    .line 114: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 117: move-result-object v1
    .line 118: check-cast v1, Lk0/q;
    .line 120: iget-wide v1, v1, Lk0/q;->a:J
    .line 122: const-string v3, "onSecondaryContainer="
    .line 124: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 127: iget-object v1, v4, Landroidx/compose/material3/k;->i:Lu/s1;
    .line 129: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 132: move-result-object v1
    .line 133: check-cast v1, Lk0/q;
    .line 135: iget-wide v1, v1, Lk0/q;->a:J
    .line 137: const-string v3, "tertiary="
    .line 139: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 142: iget-object v1, v4, Landroidx/compose/material3/k;->j:Lu/s1;
    .line 144: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 147: move-result-object v1
    .line 148: check-cast v1, Lk0/q;
    .line 150: iget-wide v1, v1, Lk0/q;->a:J
    .line 152: const-string v3, "onTertiary="
    .line 154: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 157: iget-object v1, v4, Landroidx/compose/material3/k;->k:Lu/s1;
    .line 159: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 162: move-result-object v1
    .line 163: check-cast v1, Lk0/q;
    .line 165: iget-wide v1, v1, Lk0/q;->a:J
    .line 167: const-string v3, "tertiaryContainer="
    .line 169: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 172: iget-object v1, v4, Landroidx/compose/material3/k;->l:Lu/s1;
    .line 174: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 177: move-result-object v1
    .line 178: check-cast v1, Lk0/q;
    .line 180: iget-wide v1, v1, Lk0/q;->a:J
    .line 182: const-string v3, "onTertiaryContainer="
    .line 184: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 187: iget-object v1, v4, Landroidx/compose/material3/k;->m:Lu/s1;
    .line 189: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 192: move-result-object v1
    .line 193: check-cast v1, Lk0/q;
    .line 195: iget-wide v1, v1, Lk0/q;->a:J
    .line 197: const-string v3, "background="
    .line 199: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 202: iget-object v1, v4, Landroidx/compose/material3/k;->n:Lu/s1;
    .line 204: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 207: move-result-object v1
    .line 208: check-cast v1, Lk0/q;
    .line 210: iget-wide v1, v1, Lk0/q;->a:J
    .line 212: const-string v3, "onBackground="
    .line 214: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 217: iget-object v1, v4, Landroidx/compose/material3/k;->o:Lu/s1;
    .line 219: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 222: move-result-object v1
    .line 223: check-cast v1, Lk0/q;
    .line 225: iget-wide v1, v1, Lk0/q;->a:J
    .line 227: invoke-static {v1, v2}, Lk0/q;->j(J)Ljava/lang/String;
    .line 230: move-result-object v1
    .line 231: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 234: const-string v1, "surface="
    .line 236: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 239: invoke-virtual {v4}, Landroidx/compose/material3/k;->a()J
    .line 242: move-result-wide v1
    .line 243: invoke-static {v1, v2}, Lk0/q;->j(J)Ljava/lang/String;
    .line 246: move-result-object v1
    .line 247: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 250: const-string v1, "onSurface="
    .line 252: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 255: iget-object v1, v4, Landroidx/compose/material3/k;->q:Lu/s1;
    .line 257: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 260: move-result-object v1
    .line 261: check-cast v1, Lk0/q;
    .line 263: iget-wide v1, v1, Lk0/q;->a:J
    .line 265: const-string v3, "surfaceVariant="
    .line 267: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 270: iget-object v1, v4, Landroidx/compose/material3/k;->r:Lu/s1;
    .line 272: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 275: move-result-object v1
    .line 276: check-cast v1, Lk0/q;
    .line 278: iget-wide v1, v1, Lk0/q;->a:J
    .line 280: const-string v3, "onSurfaceVariant="
    .line 282: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 285: iget-object v1, v4, Landroidx/compose/material3/k;->s:Lu/s1;
    .line 287: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 290: move-result-object v1
    .line 291: check-cast v1, Lk0/q;
    .line 293: iget-wide v1, v1, Lk0/q;->a:J
    .line 295: const-string v3, "surfaceTint="
    .line 297: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 300: iget-object v1, v4, Landroidx/compose/material3/k;->t:Lu/s1;
    .line 302: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 305: move-result-object v1
    .line 306: check-cast v1, Lk0/q;
    .line 308: iget-wide v1, v1, Lk0/q;->a:J
    .line 310: const-string v3, "inverseSurface="
    .line 312: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 315: iget-object v1, v4, Landroidx/compose/material3/k;->u:Lu/s1;
    .line 317: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 320: move-result-object v1
    .line 321: check-cast v1, Lk0/q;
    .line 323: iget-wide v1, v1, Lk0/q;->a:J
    .line 325: const-string v3, "inverseOnSurface="
    .line 327: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 330: iget-object v1, v4, Landroidx/compose/material3/k;->v:Lu/s1;
    .line 332: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 335: move-result-object v1
    .line 336: check-cast v1, Lk0/q;
    .line 338: iget-wide v1, v1, Lk0/q;->a:J
    .line 340: const-string v3, "error="
    .line 342: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 345: iget-object v1, v4, Landroidx/compose/material3/k;->w:Lu/s1;
    .line 347: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 350: move-result-object v1
    .line 351: check-cast v1, Lk0/q;
    .line 353: iget-wide v1, v1, Lk0/q;->a:J
    .line 355: const-string v3, "onError="
    .line 357: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 360: iget-object v1, v4, Landroidx/compose/material3/k;->x:Lu/s1;
    .line 362: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 365: move-result-object v1
    .line 366: check-cast v1, Lk0/q;
    .line 368: iget-wide v1, v1, Lk0/q;->a:J
    .line 370: const-string v3, "errorContainer="
    .line 372: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 375: iget-object v1, v4, Landroidx/compose/material3/k;->y:Lu/s1;
    .line 377: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 380: move-result-object v1
    .line 381: check-cast v1, Lk0/q;
    .line 383: iget-wide v1, v1, Lk0/q;->a:J
    .line 385: const-string v3, "onErrorContainer="
    .line 387: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 390: iget-object v1, v4, Landroidx/compose/material3/k;->z:Lu/s1;
    .line 392: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 395: move-result-object v1
    .line 396: check-cast v1, Lk0/q;
    .line 398: iget-wide v1, v1, Lk0/q;->a:J
    .line 400: const-string v3, "outline="
    .line 402: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 405: iget-object v1, v4, Landroidx/compose/material3/k;->A:Lu/s1;
    .line 407: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 410: move-result-object v1
    .line 411: check-cast v1, Lk0/q;
    .line 413: iget-wide v1, v1, Lk0/q;->a:J
    .line 415: const-string v3, "outlineVariant="
    .line 417: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 420: iget-object v1, v4, Landroidx/compose/material3/k;->B:Lu/s1;
    .line 422: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 425: move-result-object v1
    .line 426: check-cast v1, Lk0/q;
    .line 428: iget-wide v1, v1, Lk0/q;->a:J
    .line 430: const-string v3, "scrim="
    .line 432: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 435: iget-object v1, v4, Landroidx/compose/material3/k;->C:Lu/s1;
    .line 437: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 440: move-result-object v1
    .line 441: check-cast v1, Lk0/q;
    .line 443: iget-wide v1, v1, Lk0/q;->a:J
    .line 445: invoke-static {v1, v2}, Lk0/q;->j(J)Ljava/lang/String;
    .line 448: move-result-object v1
    .line 449: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 452: const/16 v1, 41
    .line 454: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 457: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 460: move-result-object v0
    .line 461: return-object v0
.end method

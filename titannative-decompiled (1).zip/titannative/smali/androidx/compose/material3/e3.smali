.class public abstract Landroidx/compose/material3/e3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:J
.field public static final b:F
.field public static final c:F
.field public static final d:F
.field public static final e:F
.field public static final f:F
.field public static final g:F
.field public static final h:F
.field public static final i:Lf0/p;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v0, v0, v0, v0}, Ld2/c;->a(IIII)J
    .line 4: move-result-wide v0
    .line 5: sput-wide v0, Landroidx/compose/material3/e3;->a:J
    .line 7: const/16 v0, 16
    .line 9: int-to-float v0, v0
    .line 10: sput v0, Landroidx/compose/material3/e3;->b:F
    .line 12: const/16 v1, 12
    .line 14: int-to-float v1, v1
    .line 15: sput v1, Landroidx/compose/material3/e3;->c:F
    .line 17: const/4 v1, 4
    .line 18: int-to-float v1, v1
    .line 19: sput v1, Landroidx/compose/material3/e3;->d:F
    .line 21: const/4 v1, 2
    .line 22: int-to-float v1, v1
    .line 23: sput v1, Landroidx/compose/material3/e3;->e:F
    .line 25: const/16 v1, 24
    .line 27: int-to-float v1, v1
    .line 28: sput v1, Landroidx/compose/material3/e3;->f:F
    .line 30: sput v0, Landroidx/compose/material3/e3;->g:F
    .line 32: sput v0, Landroidx/compose/material3/e3;->h:F
    .line 34: sget-object v0, Lf0/m;->c:Lf0/m;
    .line 36: const/16 v1, 48
    .line 38: int-to-float v1, v1
    .line 39: invoke-static {v0, v1, v1}, Landroidx/compose/foundation/layout/c;->a(Lf0/p;FF)Lf0/p;
    .line 42: move-result-object v0
    .line 43: sput-object v0, Landroidx/compose/material3/e3;->i:Lf0/p;
    .line 45: return-void
.end method

# direct methods
.method public static final a(Landroidx/compose/material3/l3;Ljava/lang/String;Ld3/e;Ll1/o0;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;ZZZLk/l;Ll/i0;Landroidx/compose/material3/u2;Ld3/e;Lu/l;III)V
    .registers 67

    .line 0: move-object/from16 v15, v45
    .line 2: move-object/from16 v14, v46
    .line 4: move-object/from16 v13, v47
    .line 6: move-object/from16 v12, v48
    .line 8: move-object/from16 v11, v49
    .line 10: move-object/from16 v10, v59
    .line 12: move-object/from16 v9, v60
    .line 14: move-object/from16 v8, v61
    .line 16: move-object/from16 v7, v62
    .line 18: move/from16 v6, v64
    .line 20: move/from16 v5, v65
    .line 22: move/from16 v4, v66
    .line 24: const-string v0, "type"
    .line 26: invoke-static {v15, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 29: const-string v0, "value"
    .line 31: invoke-static {v14, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 34: const-string v0, "innerTextField"
    .line 36: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 39: const-string v0, "visualTransformation"
    .line 41: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 44: const-string v0, "interactionSource"
    .line 46: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 49: const-string v0, "contentPadding"
    .line 51: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 54: const-string v0, "colors"
    .line 56: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 59: const-string v0, "container"
    .line 61: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 64: move-object/from16 v3, v63
    .line 66: check-cast v3, Lu/b0;
    .line 68: const v0, 0xc78d6294
    .line 71: invoke-virtual {v3, v0}, Lu/b0;->e0(I)Lu/b0;
    .line 74: and-int/lit8 v0, v4, 1
    .line 76: if-eqz v0, :cond_81
    .line 78: or-int/lit8 v0, v6, 6
    .line 80: goto :goto_97
    .line 81: and-int/lit8 v0, v6, 14
    .line 83: if-nez v0, :cond_96
    .line 85: invoke-virtual {v3, v15}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 88: move-result v0
    .line 89: if-eqz v0, :cond_93
    .line 91: const/4 v0, 4
    .line 92: goto :goto_94
    .line 93: const/4 v0, 2
    .line 94: or-int/2addr v0, v6
    .line 95: goto :goto_97
    .line 96: move v0, v6
    .line 97: and-int/lit8 v16, v4, 2
    .line 99: const/16 v17, 32
    .line 101: const/16 v18, 16
    .line 103: if-eqz v16, :cond_108
    .line 105: or-int/lit8 v0, v0, 48
    .line 107: goto :goto_125
    .line 108: and-int/lit8 v16, v6, 112
    .line 110: if-nez v16, :cond_125
    .line 112: invoke-virtual {v3, v14}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 115: move-result v16
    .line 116: if-eqz v16, :cond_121
    .line 118: move/from16 v16, v17
    .line 120: goto :goto_123
    .line 121: move/from16 v16, v18
    .line 123: or-int v0, v0, v16
    .line 125: and-int/lit8 v16, v4, 4
    .line 127: const/16 v19, 256
    .line 129: const/16 v20, 128
    .line 131: if-eqz v16, :cond_136
    .line 133: or-int/lit16 v0, v0, 384
    .line 135: goto :goto_152
    .line 136: and-int/lit16 v1, v6, 896
    .line 138: if-nez v1, :cond_152
    .line 140: invoke-virtual {v3, v13}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 143: move-result v1
    .line 144: if-eqz v1, :cond_149
    .line 146: move/from16 v1, v19
    .line 148: goto :goto_151
    .line 149: move/from16 v1, v20
    .line 151: or-int/2addr v0, v1
    .line 152: and-int/lit8 v1, v4, 8
    .line 154: const/16 v16, 2048
    .line 156: const/16 v21, 1024
    .line 158: if-eqz v1, :cond_163
    .line 160: or-int/lit16 v0, v0, 3072
    .line 162: goto :goto_179
    .line 163: and-int/lit16 v1, v6, 7168
    .line 165: if-nez v1, :cond_179
    .line 167: invoke-virtual {v3, v12}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 170: move-result v1
    .line 171: if-eqz v1, :cond_176
    .line 173: move/from16 v1, v16
    .line 175: goto :goto_178
    .line 176: move/from16 v1, v21
    .line 178: or-int/2addr v0, v1
    .line 179: and-int/lit8 v1, v4, 16
    .line 181: const v22, 0xe000
    .line 184: const/16 v23, 16384
    .line 186: const/16 v24, 8192
    .line 188: if-eqz v1, :cond_193
    .line 190: or-int/lit16 v0, v0, 24576
    .line 192: goto :goto_209
    .line 193: and-int v1, v6, v22
    .line 195: if-nez v1, :cond_209
    .line 197: invoke-virtual {v3, v11}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 200: move-result v1
    .line 201: if-eqz v1, :cond_206
    .line 203: move/from16 v1, v23
    .line 205: goto :goto_208
    .line 206: move/from16 v1, v24
    .line 208: or-int/2addr v0, v1
    .line 209: and-int/lit8 v1, v4, 32
    .line 211: const/high16 v25, 0x3
    .line 213: const/high16 v26, 0x1
    .line 215: const/high16 v27, 0x2
    .line 217: if-eqz v1, :cond_224
    .line 219: or-int v0, v0, v25
    .line 221: move-object/from16 v2, v50
    .line 223: goto :goto_245
    .line 224: const/high16 v28, 0x7
    .line 226: and-int v28, v6, v28
    .line 228: move-object/from16 v2, v50
    .line 230: if-nez v28, :cond_245
    .line 232: invoke-virtual {v3, v2}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 235: move-result v29
    .line 236: if-eqz v29, :cond_241
    .line 238: move/from16 v29, v27
    .line 240: goto :goto_243
    .line 241: move/from16 v29, v26
    .line 243: or-int v0, v0, v29
    .line 245: and-int/lit8 v29, v4, 64
    .line 247: if-eqz v29, :cond_256
    .line 249: const/high16 v30, 0x18
    .line 251: or-int v0, v0, v30
    .line 253: move-object/from16 v2, v51
    .line 255: goto :goto_277
    .line 256: const/high16 v30, 0x38
    .line 258: and-int v30, v6, v30
    .line 260: move-object/from16 v2, v51
    .line 262: if-nez v30, :cond_277
    .line 264: invoke-virtual {v3, v2}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 267: move-result v30
    .line 268: if-eqz v30, :cond_273
    .line 270: const/high16 v30, 0x10
    .line 272: goto :goto_275
    .line 273: const/high16 v30, 0x8
    .line 275: or-int v0, v0, v30
    .line 277: and-int/lit16 v2, v4, 128
    .line 279: if-eqz v2, :cond_288
    .line 281: const/high16 v30, 0xc0
    .line 283: or-int v0, v0, v30
    .line 285: move-object/from16 v13, v52
    .line 287: goto :goto_309
    .line 288: const/high16 v30, 0x1c0
    .line 290: and-int v30, v6, v30
    .line 292: move-object/from16 v13, v52
    .line 294: if-nez v30, :cond_309
    .line 296: invoke-virtual {v3, v13}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 299: move-result v30
    .line 300: if-eqz v30, :cond_305
    .line 302: const/high16 v30, 0x80
    .line 304: goto :goto_307
    .line 305: const/high16 v30, 0x40
    .line 307: or-int v0, v0, v30
    .line 309: and-int/lit16 v13, v4, 256
    .line 311: if-eqz v13, :cond_320
    .line 313: const/high16 v30, 0x600
    .line 315: or-int v0, v0, v30
    .line 317: move-object/from16 v15, v53
    .line 319: goto :goto_341
    .line 320: const/high16 v30, 0xe00
    .line 322: and-int v30, v6, v30
    .line 324: move-object/from16 v15, v53
    .line 326: if-nez v30, :cond_341
    .line 328: invoke-virtual {v3, v15}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 331: move-result v30
    .line 332: if-eqz v30, :cond_337
    .line 334: const/high16 v30, 0x400
    .line 336: goto :goto_339
    .line 337: const/high16 v30, 0x200
    .line 339: or-int v0, v0, v30
    .line 341: and-int/lit16 v15, v4, 512
    .line 343: if-eqz v15, :cond_354
    .line 345: const/high16 v30, 0x3000
    .line 347: or-int v0, v0, v30
    .line 349: move-object/from16 v6, v54
    .line 351: move/from16 v30, v0
    .line 353: goto :goto_376
    .line 354: const/high16 v30, 0x7000
    .line 356: and-int v30, v6, v30
    .line 358: move-object/from16 v6, v54
    .line 360: if-nez v30, :cond_351
    .line 362: invoke-virtual {v3, v6}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 365: move-result v30
    .line 366: if-eqz v30, :cond_371
    .line 368: const/high16 v30, 0x2000
    .line 370: goto :goto_373
    .line 371: const/high16 v30, 0x1000
    .line 373: or-int v0, v0, v30
    .line 375: goto :goto_351
    .line 376: and-int/lit16 v0, v4, 1024
    .line 378: if-eqz v0, :cond_385
    .line 380: or-int/lit8 v28, v5, 6
    .line 382: move-object/from16 v6, v55
    .line 384: goto :goto_407
    .line 385: and-int/lit8 v31, v5, 14
    .line 387: move-object/from16 v6, v55
    .line 389: if-nez v31, :cond_405
    .line 391: invoke-virtual {v3, v6}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 394: move-result v31
    .line 395: if-eqz v31, :cond_400
    .line 397: const/16 v28, 4
    .line 399: goto :goto_402
    .line 400: const/16 v28, 2
    .line 402: or-int v28, v5, v28
    .line 404: goto :goto_407
    .line 405: move/from16 v28, v5
    .line 407: and-int/lit16 v6, v4, 2048
    .line 409: if-eqz v6, :cond_416
    .line 411: or-int/lit8 v28, v28, 48
    .line 413: move/from16 v11, v28
    .line 415: goto :goto_434
    .line 416: and-int/lit8 v31, v5, 112
    .line 418: move/from16 v11, v56
    .line 420: if-nez v31, :cond_413
    .line 422: invoke-virtual {v3, v11}, Lu/b0;->g(Z)Z
    .line 425: move-result v31
    .line 426: if-eqz v31, :cond_429
    .line 428: goto :goto_431
    .line 429: move/from16 v17, v18
    .line 431: or-int v28, v28, v17
    .line 433: goto :goto_413
    .line 434: and-int/lit16 v12, v4, 4096
    .line 436: if-eqz v12, :cond_443
    .line 438: or-int/lit16 v11, v11, 384
    .line 440: move/from16 v14, v57
    .line 442: goto :goto_460
    .line 443: and-int/lit16 v14, v5, 896
    .line 445: if-nez v14, :cond_440
    .line 447: move/from16 v14, v57
    .line 449: invoke-virtual {v3, v14}, Lu/b0;->g(Z)Z
    .line 452: move-result v17
    .line 453: if-eqz v17, :cond_456
    .line 455: goto :goto_458
    .line 456: move/from16 v19, v20
    .line 458: or-int v11, v11, v19
    .line 460: and-int/lit16 v14, v4, 8192
    .line 462: if-eqz v14, :cond_471
    .line 464: or-int/lit16 v11, v11, 3072
    .line 466: move/from16 v17, v14
    .line 468: move/from16 v14, v58
    .line 470: goto :goto_490
    .line 471: move/from16 v17, v14
    .line 473: and-int/lit16 v14, v5, 7168
    .line 475: if-nez v14, :cond_468
    .line 477: move/from16 v14, v58
    .line 479: invoke-virtual {v3, v14}, Lu/b0;->g(Z)Z
    .line 482: move-result v18
    .line 483: if-eqz v18, :cond_486
    .line 485: goto :goto_488
    .line 486: move/from16 v16, v21
    .line 488: or-int v11, v11, v16
    .line 490: and-int/lit16 v14, v4, 16384
    .line 492: if-eqz v14, :cond_497
    .line 494: or-int/lit16 v11, v11, 24576
    .line 496: goto :goto_512
    .line 497: and-int v14, v5, v22
    .line 499: if-nez v14, :cond_512
    .line 501: invoke-virtual {v3, v10}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 504: move-result v14
    .line 505: if-eqz v14, :cond_508
    .line 507: goto :goto_510
    .line 508: move/from16 v23, v24
    .line 510: or-int v11, v11, v23
    .line 512: const v14, 0x8000
    .line 515: and-int/2addr v14, v4
    .line 516: if-eqz v14, :cond_521
    .line 518: or-int v11, v11, v25
    .line 520: goto :goto_538
    .line 521: const/high16 v14, 0x7
    .line 523: and-int/2addr v14, v5
    .line 524: if-nez v14, :cond_538
    .line 526: invoke-virtual {v3, v9}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 529: move-result v14
    .line 530: if-eqz v14, :cond_535
    .line 532: move/from16 v14, v27
    .line 534: goto :goto_537
    .line 535: move/from16 v14, v26
    .line 537: or-int/2addr v11, v14
    .line 538: and-int v14, v4, v26
    .line 540: if-eqz v14, :cond_546
    .line 542: const/high16 v14, 0x18
    .line 544: or-int/2addr v11, v14
    .line 545: goto :goto_563
    .line 546: const/high16 v14, 0x38
    .line 548: and-int/2addr v14, v5
    .line 549: if-nez v14, :cond_563
    .line 551: invoke-virtual {v3, v8}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 554: move-result v14
    .line 555: if-eqz v14, :cond_560
    .line 557: const/high16 v14, 0x10
    .line 559: goto :goto_544
    .line 560: const/high16 v14, 0x8
    .line 562: goto :goto_544
    .line 563: and-int v14, v4, v27
    .line 565: if-eqz v14, :cond_571
    .line 567: const/high16 v14, 0xc0
    .line 569: or-int/2addr v11, v14
    .line 570: goto :goto_588
    .line 571: const/high16 v14, 0x1c0
    .line 573: and-int/2addr v14, v5
    .line 574: if-nez v14, :cond_588
    .line 576: invoke-virtual {v3, v7}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 579: move-result v14
    .line 580: if-eqz v14, :cond_585
    .line 582: const/high16 v14, 0x80
    .line 584: goto :goto_569
    .line 585: const/high16 v14, 0x40
    .line 587: goto :goto_569
    .line 588: const v14, 0x5b6db6db
    .line 591: and-int v14, v30, v14
    .line 593: const v4, 0x12492492
    .line 596: if-ne v14, v4, :cond_638
    .line 598: const v4, 0x16db6db
    .line 601: and-int/2addr v4, v11
    .line 602: const v14, 0x492492
    .line 605: if-ne v4, v14, :cond_638
    .line 607: invoke-virtual {v3}, Lu/b0;->F()Z
    .line 610: move-result v4
    .line 611: if-nez v4, :cond_614
    .line 613: goto :goto_638
    .line 614: invoke-virtual {v3}, Lu/b0;->Y()V
    .line 617: move-object/from16 v6, v50
    .line 619: move-object/from16 v7, v51
    .line 621: move-object/from16 v8, v52
    .line 623: move-object/from16 v9, v53
    .line 625: move-object/from16 v10, v54
    .line 627: move-object/from16 v28, v55
    .line 629: move/from16 v12, v56
    .line 631: move/from16 v13, v57
    .line 633: move/from16 v14, v58
    .line 635: move-object v11, v3
    .line 636: goto/16 :goto_1089
    .line 638: const/4 v4, 0
    .line 639: if-eqz v1, :cond_644
    .line 641: move-object/from16 v23, v4
    .line 643: goto :goto_646
    .line 644: move-object/from16 v23, v50
    .line 646: if-eqz v29, :cond_651
    .line 648: move-object/from16 v24, v4
    .line 650: goto :goto_653
    .line 651: move-object/from16 v24, v51
    .line 653: if-eqz v2, :cond_658
    .line 655: move-object/from16 v25, v4
    .line 657: goto :goto_660
    .line 658: move-object/from16 v25, v52
    .line 660: if-eqz v13, :cond_665
    .line 662: move-object/from16 v26, v4
    .line 664: goto :goto_667
    .line 665: move-object/from16 v26, v53
    .line 667: if-eqz v15, :cond_672
    .line 669: move-object/from16 v27, v4
    .line 671: goto :goto_674
    .line 672: move-object/from16 v27, v54
    .line 674: if-eqz v0, :cond_679
    .line 676: move-object/from16 v28, v4
    .line 678: goto :goto_681
    .line 679: move-object/from16 v28, v55
    .line 681: const/4 v0, 0
    .line 682: if-eqz v6, :cond_687
    .line 684: move/from16 v29, v0
    .line 686: goto :goto_689
    .line 687: move/from16 v29, v56
    .line 689: if-eqz v12, :cond_694
    .line 691: const/16 v31, 1
    .line 693: goto :goto_696
    .line 694: move/from16 v31, v57
    .line 696: if-eqz v17, :cond_701
    .line 698: move/from16 v32, v0
    .line 700: goto :goto_703
    .line 701: move/from16 v32, v58
    .line 703: const v2, 0x1e7b2b64
    .line 706: invoke-virtual {v3, v2}, Lu/b0;->d0(I)V
    .line 709: move-object/from16 v14, v46
    .line 711: invoke-virtual {v3, v14}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 714: move-result v2
    .line 715: move-object/from16 v12, v48
    .line 717: invoke-virtual {v3, v12}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 720: move-result v4
    .line 721: or-int/2addr v2, v4
    .line 722: invoke-virtual {v3}, Lu/b0;->I()Ljava/lang/Object;
    .line 725: move-result-object v4
    .line 726: if-nez v2, :cond_732
    .line 728: sget-object v2, Lu/k;->i:Landroidx/activity/b;
    .line 730: if-ne v4, v2, :cond_749
    .line 732: new-instance v2, Lf1/e;
    .line 734: const/4 v4, 0
    .line 735: const/4 v6, 6
    .line 736: invoke-direct {v2, v14, v4, v6}, Lf1/e;-><init>(Ljava/lang/String;Ljava/util/ArrayList;I)V
    .line 739: new-instance v4, Ll1/m0;
    .line 741: sget-object v6, Ll1/o;->a:Ll1/n0;
    .line 743: invoke-direct {v4, v2, v6}, Ll1/m0;-><init>(Lf1/e;Ll1/p;)V
    .line 746: invoke-virtual {v3, v4}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 749: invoke-virtual {v3, v0}, Lu/b0;->t(Z)V
    .line 752: check-cast v4, Ll1/m0;
    .line 754: iget-object v2, v4, Ll1/m0;->a:Lf1/e;
    .line 756: iget-object v4, v2, Lf1/e;->a:Ljava/lang/String;
    .line 758: shr-int/lit8 v2, v11, 12
    .line 760: and-int/lit8 v2, v2, 14
    .line 762: invoke-static {v10, v3, v2}, Lo/g1;->n(Lk/l;Lu/l;I)Lu/l1;
    .line 765: move-result-object v2
    .line 766: invoke-interface {v2}, Lu/i3;->getValue()Ljava/lang/Object;
    .line 769: move-result-object v2
    .line 770: check-cast v2, Ljava/lang/Boolean;
    .line 772: invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z
    .line 775: move-result v2
    .line 776: if-eqz v2, :cond_782
    .line 778: sget-object v2, Landroidx/compose/material3/z;->i:Landroidx/compose/material3/z;
    .line 780: move-object v15, v2
    .line 781: goto :goto_794
    .line 782: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 785: move-result v2
    .line 786: if-nez v2, :cond_791
    .line 788: sget-object v2, Landroidx/compose/material3/z;->j:Landroidx/compose/material3/z;
    .line 790: goto :goto_780
    .line 791: sget-object v2, Landroidx/compose/material3/z;->k:Landroidx/compose/material3/z;
    .line 793: goto :goto_780
    .line 794: new-instance v13, Landroidx/compose/material3/b3;
    .line 796: move-object/from16 v50, v13
    .line 798: move-object/from16 v51, v61
    .line 800: move/from16 v52, v31
    .line 802: move/from16 v53, v32
    .line 804: move-object/from16 v54, v59
    .line 806: move/from16 v55, v11
    .line 808: invoke-direct/range {v50 .. v55}, Landroidx/compose/material3/b3;-><init>(Landroidx/compose/material3/u2;ZZLk/l;I)V
    .line 811: sget-object v2, Landroidx/compose/material3/q3;->a:Lu/j3;
    .line 813: invoke-virtual {v3, v2}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 816: move-result-object v6
    .line 817: check-cast v6, Landroidx/compose/material3/p3;
    .line 819: iget-object v0, v6, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 821: iget-object v6, v6, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 823: move-object/from16 v52, v2
    .line 825: invoke-virtual {v0}, Lf1/b0;->b()J
    .line 828: move-result-wide v1
    .line 829: sget-wide v7, Lk0/q;->g:J
    .line 831: invoke-static {v1, v2, v7, v8}, Lk0/q;->d(JJ)Z
    .line 834: move-result v1
    .line 835: if-eqz v1, :cond_847
    .line 837: invoke-virtual {v6}, Lf1/b0;->b()J
    .line 840: move-result-wide v1
    .line 841: invoke-static {v1, v2, v7, v8}, Lk0/q;->d(JJ)Z
    .line 844: move-result v1
    .line 845: if-eqz v1, :cond_867
    .line 847: invoke-virtual {v0}, Lf1/b0;->b()J
    .line 850: move-result-wide v1
    .line 851: invoke-static {v1, v2, v7, v8}, Lk0/q;->d(JJ)Z
    .line 854: move-result v1
    .line 855: if-nez v1, :cond_870
    .line 857: invoke-virtual {v6}, Lf1/b0;->b()J
    .line 860: move-result-wide v1
    .line 861: invoke-static {v1, v2, v7, v8}, Lk0/q;->d(JJ)Z
    .line 864: move-result v1
    .line 865: if-eqz v1, :cond_870
    .line 867: const/16 v19, 1
    .line 869: goto :goto_872
    .line 870: const/16 v19, 0
    .line 872: sget-object v33, Landroidx/compose/material3/y0;->b:Landroidx/compose/material3/y0;
    .line 874: const v1, 0xd978e5e3
    .line 877: invoke-virtual {v3, v1}, Lu/b0;->d0(I)V
    .line 880: move-object/from16 v1, v52
    .line 882: invoke-virtual {v3, v1}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 885: move-result-object v2
    .line 886: check-cast v2, Landroidx/compose/material3/p3;
    .line 888: iget-object v2, v2, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 890: invoke-virtual {v2}, Lf1/b0;->b()J
    .line 893: move-result-wide v16
    .line 894: if-eqz v19, :cond_930
    .line 896: cmp-long v2, v16, v7
    .line 898: if-eqz v2, :cond_905
    .line 900: move-object/from16 v18, v0
    .line 902: move-object/from16 v63, v3
    .line 904: goto :goto_924
    .line 905: move-object/from16 v18, v0
    .line 907: const/4 v2, 0
    .line 908: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 911: move-result-object v0
    .line 912: invoke-virtual {v13, v15, v3, v0}, Landroidx/compose/material3/b3;->K(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 915: move-result-object v0
    .line 916: check-cast v0, Lk0/q;
    .line 918: move-object/from16 v63, v3
    .line 920: iget-wide v2, v0, Lk0/q;->a:J
    .line 922: move-wide/from16 v16, v2
    .line 924: move-object/from16 v3, v63
    .line 926: move-wide/from16 v34, v16
    .line 928: const/4 v0, 0
    .line 929: goto :goto_933
    .line 930: move-object/from16 v18, v0
    .line 932: goto :goto_926
    .line 933: invoke-virtual {v3, v0}, Lu/b0;->t(Z)V
    .line 936: const v0, 0xd978e6a4
    .line 939: invoke-virtual {v3, v0}, Lu/b0;->d0(I)V
    .line 942: invoke-virtual {v3, v1}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 945: move-result-object v0
    .line 946: check-cast v0, Landroidx/compose/material3/p3;
    .line 948: iget-object v0, v0, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 950: invoke-virtual {v0}, Lf1/b0;->b()J
    .line 953: move-result-wide v0
    .line 954: if-eqz v19, :cond_977
    .line 956: cmp-long v2, v0, v7
    .line 958: if-eqz v2, :cond_961
    .line 960: goto :goto_977
    .line 961: const/4 v2, 0
    .line 962: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 965: move-result-object v0
    .line 966: invoke-virtual {v13, v15, v3, v0}, Landroidx/compose/material3/b3;->K(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 969: move-result-object v0
    .line 970: check-cast v0, Lk0/q;
    .line 972: iget-wide v0, v0, Lk0/q;->a:J
    .line 974: move-wide/from16 v36, v0
    .line 976: goto :goto_979
    .line 977: const/4 v2, 0
    .line 978: goto :goto_974
    .line 979: invoke-virtual {v3, v2}, Lu/b0;->t(Z)V
    .line 982: if-eqz v49, :cond_987
    .line 984: const/16 v38, 1
    .line 986: goto :goto_989
    .line 987: move/from16 v38, v2
    .line 989: new-instance v8, Landroidx/compose/material3/a3;
    .line 991: move-object/from16 v20, v18
    .line 993: move-object v0, v8
    .line 994: move-object/from16 v1, v49
    .line 996: move-object/from16 v2, v23
    .line 998: move-object v7, v3
    .line 999: move-object v3, v4
    .line 1000: move-object/from16 v4, v61
    .line 1002: move/from16 v5, v31
    .line 1004: move-object/from16 v21, v6
    .line 1006: move/from16 v6, v32
    .line 1008: move-object/from16 v39, v7
    .line 1010: move-object/from16 v7, v59
    .line 1012: move-object/from16 v40, v8
    .line 1014: move v8, v11
    .line 1015: move-object/from16 v9, v26
    .line 1017: move-object/from16 v10, v27
    .line 1019: move-object/from16 v11, v24
    .line 1021: move-object/from16 v12, v25
    .line 1023: move-object/from16 v41, v13
    .line 1025: move-object/from16 v13, v28
    .line 1027: move-object/from16 v14, v45
    .line 1029: move-object/from16 v42, v15
    .line 1031: move-object/from16 v15, v47
    .line 1033: move/from16 v16, v29
    .line 1035: move-object/from16 v17, v60
    .line 1037: move/from16 v18, v30
    .line 1039: move-object/from16 v22, v62
    .line 1041: invoke-direct/range {v0 .. v22}, Landroidx/compose/material3/a3;-><init>(Ld3/e;Ld3/e;Ljava/lang/String;Landroidx/compose/material3/u2;ZZLk/l;ILd3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Landroidx/compose/material3/l3;Ld3/e;ZLl/i0;IZLf1/b0;Lf1/b0;Ld3/e;)V
    .line 1044: const v0, 0x4cf0ddc7
    .line 1047: move-object/from16 v11, v39
    .line 1049: move-object/from16 v1, v40
    .line 1051: invoke-static {v11, v0, v1}, Ln3/a0;->A(Lu/l;ILe3/h;)Lb0/c;
    .line 1054: move-result-object v8
    .line 1055: const/high16 v10, 0x1b
    .line 1057: move-object/from16 v0, v33
    .line 1059: move-object/from16 v1, v42
    .line 1061: move-wide/from16 v2, v34
    .line 1063: move-wide/from16 v4, v36
    .line 1065: move-object/from16 v6, v41
    .line 1067: move/from16 v7, v38
    .line 1069: move-object v9, v11
    .line 1070: invoke-virtual/range {v0 .. v10}, Landroidx/compose/material3/y0;->c(Landroidx/compose/material3/z;JJLd3/f;ZLd3/i;Lu/l;I)V
    .line 1073: move-object/from16 v6, v23
    .line 1075: move-object/from16 v7, v24
    .line 1077: move-object/from16 v8, v25
    .line 1079: move-object/from16 v9, v26
    .line 1081: move-object/from16 v10, v27
    .line 1083: move/from16 v12, v29
    .line 1085: move/from16 v13, v31
    .line 1087: move/from16 v14, v32
    .line 1089: invoke-virtual {v11}, Lu/b0;->x()Lu/c2;
    .line 1092: move-result-object v15
    .line 1093: if-nez v15, :cond_1096
    .line 1095: goto :goto_1138
    .line 1096: new-instance v11, Landroidx/compose/material3/e0;
    .line 1098: move-object v0, v11
    .line 1099: move-object/from16 v1, v45
    .line 1101: move-object/from16 v2, v46
    .line 1103: move-object/from16 v3, v47
    .line 1105: move-object/from16 v4, v48
    .line 1107: move-object/from16 v5, v49
    .line 1109: move-object/from16 v43, v11
    .line 1111: move-object/from16 v11, v28
    .line 1113: move-object/from16 v44, v15
    .line 1115: move-object/from16 v15, v59
    .line 1117: move-object/from16 v16, v60
    .line 1119: move-object/from16 v17, v61
    .line 1121: move-object/from16 v18, v62
    .line 1123: move/from16 v19, v64
    .line 1125: move/from16 v20, v65
    .line 1127: move/from16 v21, v66
    .line 1129: invoke-direct/range {v0 .. v21}, Landroidx/compose/material3/e0;-><init>(Landroidx/compose/material3/l3;Ljava/lang/String;Ld3/e;Ll1/o0;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;Ld3/e;ZZZLk/l;Ll/i0;Landroidx/compose/material3/u2;Ld3/e;III)V
    .line 1132: move-object/from16 v1, v43
    .line 1134: move-object/from16 v0, v44
    .line 1136: iput-object v1, v0, Lu/c2;->d:Ld3/e;
    .line 1138: return-void
.end method

# direct methods
.method public static final b(JLf1/b0;Ld3/e;Lu/l;II)V
    .registers 17

    .line 0: move-wide v1, v10
    .line 1: move-object v4, v13
    .line 2: move v5, v15
    .line 3: const-string v0, "content"
    .line 5: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 8: move-object v0, v14
    .line 9: check-cast v0, Lu/b0;
    .line 11: const v3, 0xa565a0d7
    .line 14: invoke-virtual {v0, v3}, Lu/b0;->e0(I)Lu/b0;
    .line 17: and-int/lit8 v3, v16, 1
    .line 19: if-eqz v3, :cond_24
    .line 21: or-int/lit8 v3, v5, 6
    .line 23: goto :goto_40
    .line 24: and-int/lit8 v3, v5, 14
    .line 26: if-nez v3, :cond_39
    .line 28: invoke-virtual {v0, v10, v11}, Lu/b0;->e(J)Z
    .line 31: move-result v3
    .line 32: if-eqz v3, :cond_36
    .line 34: const/4 v3, 4
    .line 35: goto :goto_37
    .line 36: const/4 v3, 2
    .line 37: or-int/2addr v3, v5
    .line 38: goto :goto_40
    .line 39: move v3, v5
    .line 40: and-int/lit8 v6, v16, 2
    .line 42: if-eqz v6, :cond_48
    .line 44: or-int/lit8 v3, v3, 48
    .line 46: move-object v7, v12
    .line 47: goto :goto_65
    .line 48: and-int/lit8 v7, v5, 112
    .line 50: if-nez v7, :cond_46
    .line 52: move-object v7, v12
    .line 53: invoke-virtual {v0, v12}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 56: move-result v8
    .line 57: if-eqz v8, :cond_62
    .line 59: const/16 v8, 32
    .line 61: goto :goto_64
    .line 62: const/16 v8, 16
    .line 64: or-int/2addr v3, v8
    .line 65: and-int/lit8 v8, v16, 4
    .line 67: if-eqz v8, :cond_72
    .line 69: or-int/lit16 v3, v3, 384
    .line 71: goto :goto_88
    .line 72: and-int/lit16 v8, v5, 896
    .line 74: if-nez v8, :cond_88
    .line 76: invoke-virtual {v0, v13}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 79: move-result v8
    .line 80: if-eqz v8, :cond_85
    .line 82: const/16 v8, 256
    .line 84: goto :goto_87
    .line 85: const/16 v8, 128
    .line 87: or-int/2addr v3, v8
    .line 88: and-int/lit16 v8, v3, 731
    .line 90: const/16 v9, 146
    .line 92: if-ne v8, v9, :cond_106
    .line 94: invoke-virtual {v0}, Lu/b0;->F()Z
    .line 97: move-result v8
    .line 98: if-nez v8, :cond_101
    .line 100: goto :goto_106
    .line 101: invoke-virtual {v0}, Lu/b0;->Y()V
    .line 104: move-object v3, v7
    .line 105: goto :goto_161
    .line 106: if-eqz v6, :cond_110
    .line 108: const/4 v6, 0
    .line 109: goto :goto_111
    .line 110: move-object v6, v7
    .line 111: new-instance v7, Landroidx/compose/material3/d3;
    .line 113: invoke-direct {v7, v10, v11, v13, v3}, Landroidx/compose/material3/d3;-><init>(JLd3/e;I)V
    .line 116: const v8, 0x56639ed9
    .line 119: invoke-static {v0, v8, v7}, Ln3/a0;->A(Lu/l;ILe3/h;)Lb0/c;
    .line 122: move-result-object v7
    .line 123: const/4 v8, 0
    .line 124: if-eqz v6, :cond_145
    .line 126: const v9, 0x6d1ab9c0
    .line 129: invoke-virtual {v0, v9}, Lu/b0;->d0(I)V
    .line 132: shr-int/lit8 v3, v3, 3
    .line 134: and-int/lit8 v3, v3, 14
    .line 136: or-int/lit8 v3, v3, 48
    .line 138: invoke-static {v6, v7, v0, v3}, Landroidx/compose/material3/o3;->a(Lf1/b0;Ld3/e;Lu/l;I)V
    .line 141: invoke-virtual {v0, v8}, Lu/b0;->t(Z)V
    .line 144: goto :goto_160
    .line 145: const v3, 0x6d1ab9f4
    .line 148: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 151: const/4 v3, 6
    .line 152: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 155: move-result-object v3
    .line 156: invoke-virtual {v7, v0, v3}, Lb0/c;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 159: goto :goto_141
    .line 160: move-object v3, v6
    .line 161: invoke-virtual {v0}, Lu/b0;->x()Lu/c2;
    .line 164: move-result-object v7
    .line 165: if-nez v7, :cond_168
    .line 167: goto :goto_181
    .line 168: new-instance v8, Landroidx/compose/material3/c3;
    .line 170: move-object v0, v8
    .line 171: move-wide v1, v10
    .line 172: move-object v4, v13
    .line 173: move v5, v15
    .line 174: move/from16 v6, v16
    .line 176: invoke-direct/range {v0 .. v6}, Landroidx/compose/material3/c3;-><init>(JLf1/b0;Ld3/e;II)V
    .line 179: iput-object v8, v7, Lu/c2;->d:Ld3/e;
    .line 181: return-void
.end method

# direct methods
.method public static final c(Lx0/l;)Ljava/lang/Object;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v2}, Lx0/l;->J()Ljava/lang/Object;
    .line 8: move-result-object v2
    .line 9: instance-of v0, v2, Lx0/s;
    .line 11: const/4 v1, 0
    .line 12: if-eqz v0, :cond_17
    .line 14: check-cast v2, Lx0/s;
    .line 16: goto :goto_18
    .line 17: move-object v2, v1
    .line 18: if-eqz v2, :cond_24
    .line 20: check-cast v2, Lx0/r;
    .line 22: iget-object v1, v2, Lx0/r;->v:Ljava/lang/Object;
    .line 24: return-object v1
.end method

# direct methods
.method public static final d(Lx0/l0;)I
    .registers 1

    .line 0: if-eqz v0, :cond_5
    .line 2: iget v0, v0, Lx0/l0;->j:I
    .line 4: goto :goto_6
    .line 5: const/4 v0, 0
    .line 6: return v0
.end method

# direct methods
.method public static final e(Lx0/l0;)I
    .registers 1

    .line 0: if-eqz v0, :cond_5
    .line 2: iget v0, v0, Lx0/l0;->i:I
    .line 4: goto :goto_6
    .line 5: const/4 v0, 0
    .line 6: return v0
.end method

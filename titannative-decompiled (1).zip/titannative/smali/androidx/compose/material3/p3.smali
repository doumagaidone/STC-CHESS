.class public final Landroidx/compose/material3/p3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lf1/b0;
.field public final b:Lf1/b0;
.field public final c:Lf1/b0;
.field public final d:Lf1/b0;
.field public final e:Lf1/b0;
.field public final f:Lf1/b0;
.field public final g:Lf1/b0;
.field public final h:Lf1/b0;
.field public final i:Lf1/b0;
.field public final j:Lf1/b0;
.field public final k:Lf1/b0;
.field public final l:Lf1/b0;
.field public final m:Lf1/b0;
.field public final n:Lf1/b0;
.field public final o:Lf1/b0;

# direct methods
.method public constructor <init>()V
    .registers 17

    .line 0: move-object/from16 v0, v16
    .line 2: sget-object v1, Lt/k;->d:Lf1/b0;
    .line 4: sget-object v2, Lt/k;->e:Lf1/b0;
    .line 6: sget-object v3, Lt/k;->f:Lf1/b0;
    .line 8: sget-object v4, Lt/k;->g:Lf1/b0;
    .line 10: sget-object v5, Lt/k;->h:Lf1/b0;
    .line 12: sget-object v6, Lt/k;->i:Lf1/b0;
    .line 14: sget-object v7, Lt/k;->m:Lf1/b0;
    .line 16: sget-object v8, Lt/k;->n:Lf1/b0;
    .line 18: sget-object v9, Lt/k;->o:Lf1/b0;
    .line 20: sget-object v10, Lt/k;->a:Lf1/b0;
    .line 22: sget-object v11, Lt/k;->b:Lf1/b0;
    .line 24: sget-object v12, Lt/k;->c:Lf1/b0;
    .line 26: sget-object v13, Lt/k;->j:Lf1/b0;
    .line 28: sget-object v14, Lt/k;->k:Lf1/b0;
    .line 30: sget-object v15, Lt/k;->l:Lf1/b0;
    .line 32: const-string v0, "displayLarge"
    .line 34: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: const-string v0, "displayMedium"
    .line 39: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 42: const-string v0, "displaySmall"
    .line 44: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 47: const-string v0, "headlineLarge"
    .line 49: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 52: const-string v0, "headlineMedium"
    .line 54: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 57: const-string v0, "headlineSmall"
    .line 59: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 62: const-string v0, "titleLarge"
    .line 64: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 67: const-string v0, "titleMedium"
    .line 69: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 72: const-string v0, "titleSmall"
    .line 74: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 77: const-string v0, "bodyLarge"
    .line 79: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 82: const-string v0, "bodyMedium"
    .line 84: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 87: const-string v0, "bodySmall"
    .line 89: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 92: const-string v0, "labelLarge"
    .line 94: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 97: const-string v0, "labelMedium"
    .line 99: invoke-static {v14, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 102: const-string v0, "labelSmall"
    .line 104: invoke-static {v15, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 107: invoke-direct/range {v16 .. v16}, Ljava/lang/Object;-><init>()V
    .line 110: move-object/from16 v0, v16
    .line 112: iput-object v1, v0, Landroidx/compose/material3/p3;->a:Lf1/b0;
    .line 114: iput-object v2, v0, Landroidx/compose/material3/p3;->b:Lf1/b0;
    .line 116: iput-object v3, v0, Landroidx/compose/material3/p3;->c:Lf1/b0;
    .line 118: iput-object v4, v0, Landroidx/compose/material3/p3;->d:Lf1/b0;
    .line 120: iput-object v5, v0, Landroidx/compose/material3/p3;->e:Lf1/b0;
    .line 122: iput-object v6, v0, Landroidx/compose/material3/p3;->f:Lf1/b0;
    .line 124: iput-object v7, v0, Landroidx/compose/material3/p3;->g:Lf1/b0;
    .line 126: iput-object v8, v0, Landroidx/compose/material3/p3;->h:Lf1/b0;
    .line 128: iput-object v9, v0, Landroidx/compose/material3/p3;->i:Lf1/b0;
    .line 130: iput-object v10, v0, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 132: iput-object v11, v0, Landroidx/compose/material3/p3;->k:Lf1/b0;
    .line 134: iput-object v12, v0, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 136: iput-object v13, v0, Landroidx/compose/material3/p3;->m:Lf1/b0;
    .line 138: iput-object v14, v0, Landroidx/compose/material3/p3;->n:Lf1/b0;
    .line 140: iput-object v15, v0, Landroidx/compose/material3/p3;->o:Lf1/b0;
    .line 142: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Landroidx/compose/material3/p3;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Landroidx/compose/material3/p3;
    .line 12: iget-object v1, v5, Landroidx/compose/material3/p3;->a:Lf1/b0;
    .line 14: iget-object v3, v4, Landroidx/compose/material3/p3;->a:Lf1/b0;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Landroidx/compose/material3/p3;->b:Lf1/b0;
    .line 25: iget-object v3, v5, Landroidx/compose/material3/p3;->b:Lf1/b0;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Landroidx/compose/material3/p3;->c:Lf1/b0;
    .line 36: iget-object v3, v5, Landroidx/compose/material3/p3;->c:Lf1/b0;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget-object v1, v4, Landroidx/compose/material3/p3;->d:Lf1/b0;
    .line 47: iget-object v3, v5, Landroidx/compose/material3/p3;->d:Lf1/b0;
    .line 49: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v1
    .line 53: if-nez v1, :cond_56
    .line 55: return v2
    .line 56: iget-object v1, v4, Landroidx/compose/material3/p3;->e:Lf1/b0;
    .line 58: iget-object v3, v5, Landroidx/compose/material3/p3;->e:Lf1/b0;
    .line 60: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 63: move-result v1
    .line 64: if-nez v1, :cond_67
    .line 66: return v2
    .line 67: iget-object v1, v4, Landroidx/compose/material3/p3;->f:Lf1/b0;
    .line 69: iget-object v3, v5, Landroidx/compose/material3/p3;->f:Lf1/b0;
    .line 71: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 74: move-result v1
    .line 75: if-nez v1, :cond_78
    .line 77: return v2
    .line 78: iget-object v1, v4, Landroidx/compose/material3/p3;->g:Lf1/b0;
    .line 80: iget-object v3, v5, Landroidx/compose/material3/p3;->g:Lf1/b0;
    .line 82: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 85: move-result v1
    .line 86: if-nez v1, :cond_89
    .line 88: return v2
    .line 89: iget-object v1, v4, Landroidx/compose/material3/p3;->h:Lf1/b0;
    .line 91: iget-object v3, v5, Landroidx/compose/material3/p3;->h:Lf1/b0;
    .line 93: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 96: move-result v1
    .line 97: if-nez v1, :cond_100
    .line 99: return v2
    .line 100: iget-object v1, v4, Landroidx/compose/material3/p3;->i:Lf1/b0;
    .line 102: iget-object v3, v5, Landroidx/compose/material3/p3;->i:Lf1/b0;
    .line 104: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 107: move-result v1
    .line 108: if-nez v1, :cond_111
    .line 110: return v2
    .line 111: iget-object v1, v4, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 113: iget-object v3, v5, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 115: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 118: move-result v1
    .line 119: if-nez v1, :cond_122
    .line 121: return v2
    .line 122: iget-object v1, v4, Landroidx/compose/material3/p3;->k:Lf1/b0;
    .line 124: iget-object v3, v5, Landroidx/compose/material3/p3;->k:Lf1/b0;
    .line 126: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 129: move-result v1
    .line 130: if-nez v1, :cond_133
    .line 132: return v2
    .line 133: iget-object v1, v4, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 135: iget-object v3, v5, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 137: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 140: move-result v1
    .line 141: if-nez v1, :cond_144
    .line 143: return v2
    .line 144: iget-object v1, v4, Landroidx/compose/material3/p3;->m:Lf1/b0;
    .line 146: iget-object v3, v5, Landroidx/compose/material3/p3;->m:Lf1/b0;
    .line 148: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 151: move-result v1
    .line 152: if-nez v1, :cond_155
    .line 154: return v2
    .line 155: iget-object v1, v4, Landroidx/compose/material3/p3;->n:Lf1/b0;
    .line 157: iget-object v3, v5, Landroidx/compose/material3/p3;->n:Lf1/b0;
    .line 159: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 162: move-result v1
    .line 163: if-nez v1, :cond_166
    .line 165: return v2
    .line 166: iget-object v1, v4, Landroidx/compose/material3/p3;->o:Lf1/b0;
    .line 168: iget-object v5, v5, Landroidx/compose/material3/p3;->o:Lf1/b0;
    .line 170: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 173: move-result v5
    .line 174: if-nez v5, :cond_177
    .line 176: return v2
    .line 177: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/compose/material3/p3;->a:Lf1/b0;
    .line 2: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v2, Landroidx/compose/material3/p3;->b:Lf1/b0;
    .line 10: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget-object v0, v2, Landroidx/compose/material3/p3;->c:Lf1/b0;
    .line 19: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 22: move-result v0
    .line 23: add-int/2addr v0, v1
    .line 24: mul-int/lit8 v0, v0, 31
    .line 26: iget-object v1, v2, Landroidx/compose/material3/p3;->d:Lf1/b0;
    .line 28: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 31: move-result v1
    .line 32: add-int/2addr v1, v0
    .line 33: mul-int/lit8 v1, v1, 31
    .line 35: iget-object v0, v2, Landroidx/compose/material3/p3;->e:Lf1/b0;
    .line 37: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 40: move-result v0
    .line 41: add-int/2addr v0, v1
    .line 42: mul-int/lit8 v0, v0, 31
    .line 44: iget-object v1, v2, Landroidx/compose/material3/p3;->f:Lf1/b0;
    .line 46: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 49: move-result v1
    .line 50: add-int/2addr v1, v0
    .line 51: mul-int/lit8 v1, v1, 31
    .line 53: iget-object v0, v2, Landroidx/compose/material3/p3;->g:Lf1/b0;
    .line 55: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 58: move-result v0
    .line 59: add-int/2addr v0, v1
    .line 60: mul-int/lit8 v0, v0, 31
    .line 62: iget-object v1, v2, Landroidx/compose/material3/p3;->h:Lf1/b0;
    .line 64: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 67: move-result v1
    .line 68: add-int/2addr v1, v0
    .line 69: mul-int/lit8 v1, v1, 31
    .line 71: iget-object v0, v2, Landroidx/compose/material3/p3;->i:Lf1/b0;
    .line 73: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 76: move-result v0
    .line 77: add-int/2addr v0, v1
    .line 78: mul-int/lit8 v0, v0, 31
    .line 80: iget-object v1, v2, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 82: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 85: move-result v1
    .line 86: add-int/2addr v1, v0
    .line 87: mul-int/lit8 v1, v1, 31
    .line 89: iget-object v0, v2, Landroidx/compose/material3/p3;->k:Lf1/b0;
    .line 91: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 94: move-result v0
    .line 95: add-int/2addr v0, v1
    .line 96: mul-int/lit8 v0, v0, 31
    .line 98: iget-object v1, v2, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 100: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 103: move-result v1
    .line 104: add-int/2addr v1, v0
    .line 105: mul-int/lit8 v1, v1, 31
    .line 107: iget-object v0, v2, Landroidx/compose/material3/p3;->m:Lf1/b0;
    .line 109: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 112: move-result v0
    .line 113: add-int/2addr v0, v1
    .line 114: mul-int/lit8 v0, v0, 31
    .line 116: iget-object v1, v2, Landroidx/compose/material3/p3;->n:Lf1/b0;
    .line 118: invoke-virtual {v1}, Lf1/b0;->hashCode()I
    .line 121: move-result v1
    .line 122: add-int/2addr v1, v0
    .line 123: mul-int/lit8 v1, v1, 31
    .line 125: iget-object v0, v2, Landroidx/compose/material3/p3;->o:Lf1/b0;
    .line 127: invoke-virtual {v0}, Lf1/b0;->hashCode()I
    .line 130: move-result v0
    .line 131: add-int/2addr v0, v1
    .line 132: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Typography(displayLarge="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Landroidx/compose/material3/p3;->a:Lf1/b0;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", displayMedium="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Landroidx/compose/material3/p3;->b:Lf1/b0;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ",displaySmall="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Landroidx/compose/material3/p3;->c:Lf1/b0;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", headlineLarge="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v2, Landroidx/compose/material3/p3;->d:Lf1/b0;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", headlineMedium="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-object v1, v2, Landroidx/compose/material3/p3;->e:Lf1/b0;
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", headlineSmall="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget-object v1, v2, Landroidx/compose/material3/p3;->f:Lf1/b0;
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ", titleLarge="
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget-object v1, v2, Landroidx/compose/material3/p3;->g:Lf1/b0;
    .line 69: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 72: const-string v1, ", titleMedium="
    .line 74: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: iget-object v1, v2, Landroidx/compose/material3/p3;->h:Lf1/b0;
    .line 79: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 82: const-string v1, ", titleSmall="
    .line 84: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 87: iget-object v1, v2, Landroidx/compose/material3/p3;->i:Lf1/b0;
    .line 89: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 92: const-string v1, ", bodyLarge="
    .line 94: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 97: iget-object v1, v2, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 99: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 102: const-string v1, ", bodyMedium="
    .line 104: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 107: iget-object v1, v2, Landroidx/compose/material3/p3;->k:Lf1/b0;
    .line 109: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 112: const-string v1, ", bodySmall="
    .line 114: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 117: iget-object v1, v2, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 119: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 122: const-string v1, ", labelLarge="
    .line 124: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 127: iget-object v1, v2, Landroidx/compose/material3/p3;->m:Lf1/b0;
    .line 129: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 132: const-string v1, ", labelMedium="
    .line 134: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 137: iget-object v1, v2, Landroidx/compose/material3/p3;->n:Lf1/b0;
    .line 139: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 142: const-string v1, ", labelSmall="
    .line 144: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 147: iget-object v1, v2, Landroidx/compose/material3/p3;->o:Lf1/b0;
    .line 149: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 152: const/16 v1, 41
    .line 154: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 157: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 160: move-result-object v0
    .line 161: return-object v0
.end method

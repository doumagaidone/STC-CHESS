.class public abstract Landroidx/compose/material3/t2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/w0;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Landroidx/compose/material3/l;->o:Landroidx/compose/material3/l;
    .line 2: invoke-static {v0}, Le3/g;->o(Ld3/a;)Lu/w0;
    .line 5: move-result-object v0
    .line 6: sput-object v0, Landroidx/compose/material3/t2;->a:Lu/w0;
    .line 8: return-void
.end method

# direct methods
.method public static final a(Lf0/p;Lk0/l0;JLi/w;F)Lf0/p;
    .registers 6

    .line 0: invoke-static {v0, v5, v1}, Landroidx/compose/ui/draw/a;->h(Lf0/p;FLk0/l0;)Lf0/p;
    .line 3: move-result-object v0
    .line 4: if-eqz v4, :cond_11
    .line 6: invoke-static {v4, v1}, Landroidx/compose/foundation/a;->f(Li/w;Lk0/l0;)Lf0/p;
    .line 9: move-result-object v4
    .line 10: goto :goto_13
    .line 11: sget-object v4, Lf0/m;->c:Lf0/m;
    .line 13: invoke-interface {v0, v4}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 16: move-result-object v0
    .line 17: invoke-static {v0, v2, v3, v1}, Landroidx/compose/foundation/a;->d(Lf0/p;JLk0/l0;)Lf0/p;
    .line 20: move-result-object v0
    .line 21: invoke-static {v0, v1}, Landroidx/compose/ui/draw/a;->b(Lf0/p;Lk0/l0;)Lf0/p;
    .line 24: move-result-object v0
    .line 25: return-object v0
.end method

# direct methods
.method public static final b(JFLu/l;)J
    .registers 7

    .line 0: check-cast v6, Lu/b0;
    .line 2: const v0, 0x8406f7f6
    .line 5: invoke-virtual {v6, v0}, Lu/b0;->d0(I)V
    .line 8: sget-object v0, Landroidx/compose/material3/m;->a:Lu/j3;
    .line 10: invoke-virtual {v6, v0}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 13: move-result-object v1
    .line 14: check-cast v1, Landroidx/compose/material3/k;
    .line 16: invoke-virtual {v1}, Landroidx/compose/material3/k;->a()J
    .line 19: move-result-wide v1
    .line 20: invoke-static {v3, v4, v1, v2}, Lk0/q;->d(JJ)Z
    .line 23: move-result v1
    .line 24: const/4 v2, 0
    .line 25: if-eqz v1, :cond_90
    .line 27: invoke-virtual {v6, v0}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 30: move-result-object v3
    .line 31: check-cast v3, Landroidx/compose/material3/k;
    .line 33: const-string v4, "$this$surfaceColorAtElevation"
    .line 35: invoke-static {v3, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 38: int-to-float v4, v2
    .line 39: invoke-static {v5, v4}, Lr1/d;->a(FF)Z
    .line 42: move-result v4
    .line 43: if-eqz v4, :cond_50
    .line 45: invoke-virtual {v3}, Landroidx/compose/material3/k;->a()J
    .line 48: move-result-wide v3
    .line 49: goto :goto_90
    .line 50: const/4 v4, 1
    .line 51: int-to-float v4, v4
    .line 52: add-float/2addr v5, v4
    .line 53: float-to-double v4, v5
    .line 54: invoke-static {v4, v5}, Ljava/lang/Math;->log(D)D
    .line 57: move-result-wide v4
    .line 58: double-to-float v4, v4
    .line 59: const/high16 v5, 0x4090
    .line 61: mul-float/2addr v4, v5
    .line 62: const/high16 v5, 0x4000
    .line 64: add-float/2addr v4, v5
    .line 65: const/high16 v5, 0x42c8
    .line 67: div-float/2addr v4, v5
    .line 68: iget-object v5, v3, Landroidx/compose/material3/k;->t:Lu/s1;
    .line 70: invoke-virtual {v5}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 73: move-result-object v5
    .line 74: check-cast v5, Lk0/q;
    .line 76: iget-wide v0, v5, Lk0/q;->a:J
    .line 78: invoke-static {v0, v1, v4}, Lk0/q;->c(JF)J
    .line 81: move-result-wide v4
    .line 82: invoke-virtual {v3}, Landroidx/compose/material3/k;->a()J
    .line 85: move-result-wide v0
    .line 86: invoke-static {v4, v5, v0, v1}, Landroidx/compose/ui/graphics/a;->i(JJ)J
    .line 89: move-result-wide v3
    .line 90: invoke-virtual {v6, v2}, Lu/b0;->t(Z)V
    .line 93: return-wide v3
.end method

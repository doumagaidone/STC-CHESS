.class public final Landroidx/compose/material3/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F
.field public final c:F
.field public final d:F
.field public final e:F

# direct methods
.method public constructor <init>(FFFFF)V
    .registers 6

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Landroidx/compose/material3/g;->a:F
    .line 5: iput v2, v0, Landroidx/compose/material3/g;->b:F
    .line 7: iput v3, v0, Landroidx/compose/material3/g;->c:F
    .line 9: iput v4, v0, Landroidx/compose/material3/g;->d:F
    .line 11: iput v5, v0, Landroidx/compose/material3/g;->e:F
    .line 13: return-void
.end method

# virtual methods
.method public final a(ZLk/m;Lu/l;I)Lh/n;
    .registers 18

    .line 0: move-object v6, v13
    .line 1: move-object v0, v15
    .line 2: move-object/from16 v7, v16
    .line 4: check-cast v7, Lu/b0;
    .line 6: const v1, 0xb1c4ae02
    .line 9: invoke-virtual {v7, v1}, Lu/b0;->d0(I)V
    .line 12: const v1, 0xe2a708a4
    .line 15: invoke-virtual {v7, v1}, Lu/b0;->d0(I)V
    .line 18: invoke-virtual {v7}, Lu/b0;->I()Ljava/lang/Object;
    .line 21: move-result-object v2
    .line 22: sget-object v3, Lu/k;->i:Landroidx/activity/b;
    .line 24: if-ne v2, v3, :cond_33
    .line 26: invoke-static {}, Le3/g;->v()Ld0/u;
    .line 29: move-result-object v2
    .line 30: invoke-virtual {v7, v2}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 33: const/4 v8, 0
    .line 34: invoke-virtual {v7, v8}, Lu/b0;->t(Z)V
    .line 37: check-cast v2, Ld0/u;
    .line 39: const v4, 0x1e7b2b64
    .line 42: invoke-virtual {v7, v4}, Lu/b0;->d0(I)V
    .line 45: invoke-virtual {v7, v15}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 48: move-result v4
    .line 49: invoke-virtual {v7, v2}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 52: move-result v5
    .line 53: or-int/2addr v4, v5
    .line 54: invoke-virtual {v7}, Lu/b0;->I()Ljava/lang/Object;
    .line 57: move-result-object v5
    .line 58: const/4 v9, 0
    .line 59: if-nez v4, :cond_63
    .line 61: if-ne v5, v3, :cond_71
    .line 63: new-instance v5, Landroidx/compose/material3/d;
    .line 65: invoke-direct {v5, v15, v2, v9}, Landroidx/compose/material3/d;-><init>(Lk/l;Ld0/u;Lw2/e;)V
    .line 68: invoke-virtual {v7, v5}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 71: invoke-virtual {v7, v8}, Lu/b0;->t(Z)V
    .line 74: check-cast v5, Ld3/e;
    .line 76: invoke-static {v15, v5, v7}, Lu/c0;->b(Ljava/lang/Object;Ld3/e;Lu/l;)V
    .line 79: invoke-static {v2}, Lt2/p;->R1(Ljava/util/List;)Ljava/lang/Object;
    .line 82: move-result-object v0
    .line 83: move-object v4, v0
    .line 84: check-cast v4, Lk/k;
    .line 86: if-nez v14, :cond_92
    .line 88: iget v0, v6, Landroidx/compose/material3/g;->e:F
    .line 90: move v5, v0
    .line 91: goto :goto_116
    .line 92: instance-of v0, v4, Lk/o;
    .line 94: if-eqz v0, :cond_99
    .line 96: iget v0, v6, Landroidx/compose/material3/g;->b:F
    .line 98: goto :goto_90
    .line 99: instance-of v0, v4, Lk/h;
    .line 101: if-eqz v0, :cond_106
    .line 103: iget v0, v6, Landroidx/compose/material3/g;->d:F
    .line 105: goto :goto_90
    .line 106: instance-of v0, v4, Lk/d;
    .line 108: if-eqz v0, :cond_113
    .line 110: iget v0, v6, Landroidx/compose/material3/g;->c:F
    .line 112: goto :goto_90
    .line 113: iget v0, v6, Landroidx/compose/material3/g;->a:F
    .line 115: goto :goto_90
    .line 116: invoke-virtual {v7, v1}, Lu/b0;->d0(I)V
    .line 119: invoke-virtual {v7}, Lu/b0;->I()Ljava/lang/Object;
    .line 122: move-result-object v0
    .line 123: if-ne v0, v3, :cond_142
    .line 125: new-instance v0, Lh/d;
    .line 127: new-instance v1, Lr1/d;
    .line 129: invoke-direct {v1, v5}, Lr1/d;-><init>(F)V
    .line 132: sget-object v2, Lh/r1;->c:Lh/q1;
    .line 134: const/16 v3, 12
    .line 136: invoke-direct {v0, v1, v2, v9, v3}, Lh/d;-><init>(Ljava/lang/Object;Lh/q1;Ljava/lang/Object;I)V
    .line 139: invoke-virtual {v7, v0}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 142: invoke-virtual {v7, v8}, Lu/b0;->t(Z)V
    .line 145: move-object v10, v0
    .line 146: check-cast v10, Lh/d;
    .line 148: if-nez v14, :cond_173
    .line 150: const v0, 0xd516bd1d
    .line 153: invoke-virtual {v7, v0}, Lu/b0;->d0(I)V
    .line 156: new-instance v0, Lr1/d;
    .line 158: invoke-direct {v0, v5}, Lr1/d;-><init>(F)V
    .line 161: new-instance v1, Landroidx/compose/material3/e;
    .line 163: invoke-direct {v1, v10, v5, v9}, Landroidx/compose/material3/e;-><init>(Lh/d;FLw2/e;)V
    .line 166: invoke-static {v0, v1, v7}, Lu/c0;->b(Ljava/lang/Object;Ld3/e;Lu/l;)V
    .line 169: invoke-virtual {v7, v8}, Lu/b0;->t(Z)V
    .line 172: goto :goto_201
    .line 173: const v0, 0xd516bdac
    .line 176: invoke-virtual {v7, v0}, Lu/b0;->d0(I)V
    .line 179: new-instance v9, Lr1/d;
    .line 181: invoke-direct {v9, v5}, Lr1/d;-><init>(F)V
    .line 184: new-instance v11, Landroidx/compose/material3/f;
    .line 186: const/4 v12, 0
    .line 187: move-object v0, v11
    .line 188: move-object v1, v10
    .line 189: move-object v2, v13
    .line 190: move v3, v5
    .line 191: move-object v5, v12
    .line 192: invoke-direct/range {v0 .. v5}, Landroidx/compose/material3/f;-><init>(Lh/d;Landroidx/compose/material3/g;FLk/k;Lw2/e;)V
    .line 195: invoke-static {v9, v11, v7}, Lu/c0;->b(Ljava/lang/Object;Ld3/e;Lu/l;)V
    .line 198: invoke-virtual {v7, v8}, Lu/b0;->t(Z)V
    .line 201: iget-object v0, v10, Lh/d;->c:Lh/n;
    .line 203: invoke-virtual {v7, v8}, Lu/b0;->t(Z)V
    .line 206: return-object v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-eqz v5, :cond_70
    .line 7: instance-of v2, v5, Landroidx/compose/material3/g;
    .line 9: if-nez v2, :cond_12
    .line 11: goto :goto_70
    .line 12: check-cast v5, Landroidx/compose/material3/g;
    .line 14: iget v2, v5, Landroidx/compose/material3/g;->a:F
    .line 16: iget v3, v4, Landroidx/compose/material3/g;->a:F
    .line 18: invoke-static {v3, v2}, Lr1/d;->a(FF)Z
    .line 21: move-result v2
    .line 22: if-nez v2, :cond_25
    .line 24: return v1
    .line 25: iget v2, v4, Landroidx/compose/material3/g;->b:F
    .line 27: iget v3, v5, Landroidx/compose/material3/g;->b:F
    .line 29: invoke-static {v2, v3}, Lr1/d;->a(FF)Z
    .line 32: move-result v2
    .line 33: if-nez v2, :cond_36
    .line 35: return v1
    .line 36: iget v2, v4, Landroidx/compose/material3/g;->c:F
    .line 38: iget v3, v5, Landroidx/compose/material3/g;->c:F
    .line 40: invoke-static {v2, v3}, Lr1/d;->a(FF)Z
    .line 43: move-result v2
    .line 44: if-nez v2, :cond_47
    .line 46: return v1
    .line 47: iget v2, v4, Landroidx/compose/material3/g;->d:F
    .line 49: iget v3, v5, Landroidx/compose/material3/g;->d:F
    .line 51: invoke-static {v2, v3}, Lr1/d;->a(FF)Z
    .line 54: move-result v2
    .line 55: if-nez v2, :cond_58
    .line 57: return v1
    .line 58: iget v2, v4, Landroidx/compose/material3/g;->e:F
    .line 60: iget v5, v5, Landroidx/compose/material3/g;->e:F
    .line 62: invoke-static {v2, v5}, Lr1/d;->a(FF)Z
    .line 65: move-result v5
    .line 66: if-nez v5, :cond_69
    .line 68: return v1
    .line 69: return v0
    .line 70: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget v0, v3, Landroidx/compose/material3/g;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Landroidx/compose/material3/g;->b:F
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 14: move-result v0
    .line 15: iget v2, v3, Landroidx/compose/material3/g;->c:F
    .line 17: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 20: move-result v0
    .line 21: iget v2, v3, Landroidx/compose/material3/g;->d:F
    .line 23: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 26: move-result v0
    .line 27: iget v1, v3, Landroidx/compose/material3/g;->e:F
    .line 29: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 32: move-result v1
    .line 33: add-int/2addr v1, v0
    .line 34: return v1
.end method

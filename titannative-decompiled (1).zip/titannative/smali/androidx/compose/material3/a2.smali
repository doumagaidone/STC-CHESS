.class public final Landroidx/compose/material3/a2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/lang/String;
.field public final c:Z
.field public final d:I

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZI)V
    .registers 6

    .line 0: const-string v0, "duration"
    .line 2: invoke-static {v5, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Landroidx/compose/material3/a2;->a:Ljava/lang/String;
    .line 10: iput-object v3, v1, Landroidx/compose/material3/a2;->b:Ljava/lang/String;
    .line 12: iput-boolean v4, v1, Landroidx/compose/material3/a2;->c:Z
    .line 14: iput v5, v1, Landroidx/compose/material3/a2;->d:I
    .line 16: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-eqz v5, :cond_55
    .line 7: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 10: move-result-object v2
    .line 11: const-class v3, Landroidx/compose/material3/a2;
    .line 13: if-eq v3, v2, :cond_16
    .line 15: goto :goto_55
    .line 16: check-cast v5, Landroidx/compose/material3/a2;
    .line 18: iget-object v2, v4, Landroidx/compose/material3/a2;->a:Ljava/lang/String;
    .line 20: iget-object v3, v5, Landroidx/compose/material3/a2;->a:Ljava/lang/String;
    .line 22: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 25: move-result v2
    .line 26: if-nez v2, :cond_29
    .line 28: return v1
    .line 29: iget-object v2, v4, Landroidx/compose/material3/a2;->b:Ljava/lang/String;
    .line 31: iget-object v3, v5, Landroidx/compose/material3/a2;->b:Ljava/lang/String;
    .line 33: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 36: move-result v2
    .line 37: if-nez v2, :cond_40
    .line 39: return v1
    .line 40: iget-boolean v2, v4, Landroidx/compose/material3/a2;->c:Z
    .line 42: iget-boolean v3, v5, Landroidx/compose/material3/a2;->c:Z
    .line 44: if-eq v2, v3, :cond_47
    .line 46: return v1
    .line 47: iget v2, v4, Landroidx/compose/material3/a2;->d:I
    .line 49: iget v5, v5, Landroidx/compose/material3/a2;->d:I
    .line 51: if-eq v2, v5, :cond_54
    .line 53: return v1
    .line 54: return v0
    .line 55: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Landroidx/compose/material3/a2;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v3, Landroidx/compose/material3/a2;->b:Ljava/lang/String;
    .line 11: if-eqz v2, :cond_18
    .line 13: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 16: move-result v2
    .line 17: goto :goto_19
    .line 18: const/4 v2, 0
    .line 19: add-int/2addr v0, v2
    .line 20: mul-int/2addr v0, v1
    .line 21: iget-boolean v2, v3, Landroidx/compose/material3/a2;->c:Z
    .line 23: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->e(ZII)I
    .line 26: move-result v0
    .line 27: iget v1, v3, Landroidx/compose/material3/a2;->d:I
    .line 29: invoke-static {v1}, Lh/j;->d(I)I
    .line 32: move-result v1
    .line 33: add-int/2addr v1, v0
    .line 34: return v1
.end method

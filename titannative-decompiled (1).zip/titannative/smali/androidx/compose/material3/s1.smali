.class public final Landroidx/compose/material3/s1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lu/s1;
.field public final b:Lu/s1;

# direct methods
.method public constructor <init>(Lj3/a;[F)V
    .registers 4

    .line 0: const-string v0, "initialTickFractions"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: sget-object v0, Lu/l3;->a:Lu/l3;
    .line 10: invoke-static {v2, v0}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 13: move-result-object v2
    .line 14: iput-object v2, v1, Landroidx/compose/material3/s1;->a:Lu/s1;
    .line 16: invoke-static {v3, v0}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 19: move-result-object v2
    .line 20: iput-object v2, v1, Landroidx/compose/material3/s1;->b:Lu/s1;
    .line 22: return-void
.end method

# virtual methods
.method public final a()Lj3/a;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/compose/material3/s1;->a:Lu/s1;
    .line 2: invoke-virtual {v0}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lj3/a;
    .line 8: return-object v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Landroidx/compose/material3/s1;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: invoke-virtual {v4}, Landroidx/compose/material3/s1;->a()Lj3/a;
    .line 13: move-result-object v1
    .line 14: check-cast v5, Landroidx/compose/material3/s1;
    .line 16: invoke-virtual {v5}, Landroidx/compose/material3/s1;->a()Lj3/a;
    .line 19: move-result-object v3
    .line 20: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 23: move-result v1
    .line 24: if-nez v1, :cond_27
    .line 26: return v2
    .line 27: iget-object v1, v4, Landroidx/compose/material3/s1;->b:Lu/s1;
    .line 29: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 32: move-result-object v1
    .line 33: check-cast v1, [F
    .line 35: iget-object v5, v5, Landroidx/compose/material3/s1;->b:Lu/s1;
    .line 37: invoke-virtual {v5}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 40: move-result-object v5
    .line 41: check-cast v5, [F
    .line 43: invoke-static {v1, v5}, Ljava/util/Arrays;->equals([F[F)Z
    .line 46: move-result v5
    .line 47: if-nez v5, :cond_50
    .line 49: return v2
    .line 50: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: invoke-virtual {v2}, Landroidx/compose/material3/s1;->a()Lj3/a;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v0}, Lj3/a;->hashCode()I
    .line 7: move-result v0
    .line 8: mul-int/lit8 v0, v0, 31
    .line 10: iget-object v1, v2, Landroidx/compose/material3/s1;->b:Lu/s1;
    .line 12: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 15: move-result-object v1
    .line 16: check-cast v1, [F
    .line 18: invoke-static {v1}, Ljava/util/Arrays;->hashCode([F)I
    .line 21: move-result v1
    .line 22: add-int/2addr v1, v0
    .line 23: return v1
.end method

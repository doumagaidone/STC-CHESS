.class public abstract Landroidx/compose/material3/q3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/j3;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Landroidx/compose/material3/l;->q:Landroidx/compose/material3/l;
    .line 2: new-instance v1, Lu/j3;
    .line 4: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 7: sput-object v1, Landroidx/compose/material3/q3;->a:Lu/j3;
    .line 9: return-void
.end method

# direct methods
.method public static final a(Landroidx/compose/material3/p3;I)Lf1/b0;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "value"
    .line 7: invoke-static {v2, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 10: if-eqz v2, :cond_68
    .line 12: add-int/lit8 v2, v2, -1
    .line 14: packed-switch v2, :data_70
    .line 17: new-instance v1, Lkotlinx/coroutines/internal/z;
    .line 19: invoke-direct {v1}, Ljava/lang/RuntimeException;-><init>()V
    .line 22: throw v1
    .line 23: iget-object v1, v1, Landroidx/compose/material3/p3;->i:Lf1/b0;
    .line 25: goto :goto_67
    .line 26: iget-object v1, v1, Landroidx/compose/material3/p3;->h:Lf1/b0;
    .line 28: goto :goto_67
    .line 29: iget-object v1, v1, Landroidx/compose/material3/p3;->g:Lf1/b0;
    .line 31: goto :goto_67
    .line 32: iget-object v1, v1, Landroidx/compose/material3/p3;->o:Lf1/b0;
    .line 34: goto :goto_67
    .line 35: iget-object v1, v1, Landroidx/compose/material3/p3;->n:Lf1/b0;
    .line 37: goto :goto_67
    .line 38: iget-object v1, v1, Landroidx/compose/material3/p3;->m:Lf1/b0;
    .line 40: goto :goto_67
    .line 41: iget-object v1, v1, Landroidx/compose/material3/p3;->f:Lf1/b0;
    .line 43: goto :goto_67
    .line 44: iget-object v1, v1, Landroidx/compose/material3/p3;->e:Lf1/b0;
    .line 46: goto :goto_67
    .line 47: iget-object v1, v1, Landroidx/compose/material3/p3;->d:Lf1/b0;
    .line 49: goto :goto_67
    .line 50: iget-object v1, v1, Landroidx/compose/material3/p3;->c:Lf1/b0;
    .line 52: goto :goto_67
    .line 53: iget-object v1, v1, Landroidx/compose/material3/p3;->b:Lf1/b0;
    .line 55: goto :goto_67
    .line 56: iget-object v1, v1, Landroidx/compose/material3/p3;->a:Lf1/b0;
    .line 58: goto :goto_67
    .line 59: iget-object v1, v1, Landroidx/compose/material3/p3;->l:Lf1/b0;
    .line 61: goto :goto_67
    .line 62: iget-object v1, v1, Landroidx/compose/material3/p3;->k:Lf1/b0;
    .line 64: goto :goto_67
    .line 65: iget-object v1, v1, Landroidx/compose/material3/p3;->j:Lf1/b0;
    .line 67: return-object v1
    .line 68: const/4 v1, 0
    .line 69: throw v1
    .line 70: nop
    .line 71: return v0
    .line 72: nop
    .line 73: nop
    .line 74: if-ne v0, v0, :cond_74
    .line 76: cmpg-double v0, v0, v0
    .line 78: cmpl-float v0, v0, v0
    .line 80: goto/32 :goto_2555984
    .line 83: nop
    .line 84: filled-new-array {}, B
    .line 87: nop
    .line 88: monitor-exit v0
    .line 89: nop
    .line 90: const-string/jumbo v0, "string@1572864"
    .line 93: nop
    .line 94: const/high16 v0, 0x0
    .line 96: const/4 v0, 0
    .line 97: nop
    .line 98: return v0
    .line 99: nop
    .line 100: move-result-object v0
    .line 101: nop
    .line 102: move-object/16 v0, v2
.end method

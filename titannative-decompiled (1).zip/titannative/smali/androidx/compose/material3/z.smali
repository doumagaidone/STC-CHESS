.class public final enum Landroidx/compose/material3/z;
.super Ljava/lang/Enum;
.source "SourceFile"

.field public static final enum i:Landroidx/compose/material3/z;
.field public static final enum j:Landroidx/compose/material3/z;
.field public static final enum k:Landroidx/compose/material3/z;
.field public static final synthetic l:[Landroidx/compose/material3/z;

# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 0: new-instance v0, Landroidx/compose/material3/z;
    .line 2: const-string v1, "Focused"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Landroidx/compose/material3/z;->i:Landroidx/compose/material3/z;
    .line 10: new-instance v1, Landroidx/compose/material3/z;
    .line 12: const-string v2, "UnfocusedEmpty"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Landroidx/compose/material3/z;->j:Landroidx/compose/material3/z;
    .line 20: new-instance v2, Landroidx/compose/material3/z;
    .line 22: const-string v3, "UnfocusedNotEmpty"
    .line 24: const/4 v4, 2
    .line 25: invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 28: sput-object v2, Landroidx/compose/material3/z;->k:Landroidx/compose/material3/z;
    .line 30: filled-new-array {v0, v1, v2}, [Landroidx/compose/material3/z;
    .line 33: move-result-object v0
    .line 34: sput-object v0, Landroidx/compose/material3/z;->l:[Landroidx/compose/material3/z;
    .line 36: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Landroidx/compose/material3/z;
    .registers 2

    .line 0: const-class v0, Landroidx/compose/material3/z;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Landroidx/compose/material3/z;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Landroidx/compose/material3/z;
    .registers 1

    .line 0: sget-object v0, Landroidx/compose/material3/z;->l:[Landroidx/compose/material3/z;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Landroidx/compose/material3/z;
    .line 8: return-object v0
.end method

.class public abstract synthetic Landroidx/compose/material3/m0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:[I

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: invoke-static {}, Lr1/j;->values()[Lr1/j;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: const/4 v1, 1
    .line 8: aput v1, v0, v1
    .line 10: sput-object v0, Landroidx/compose/material3/m0;->a:[I
    .line 12: return-void
.end method

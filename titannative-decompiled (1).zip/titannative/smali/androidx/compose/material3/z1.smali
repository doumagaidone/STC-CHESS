.class public final Landroidx/compose/material3/z1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroidx/compose/material3/a2;
.field public final b:Ln3/g;

# direct methods
.method public constructor <init>(Landroidx/compose/material3/a2;Ln3/h;)V
    .registers 4

    .line 0: const-string v0, "visuals"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Landroidx/compose/material3/z1;->a:Landroidx/compose/material3/a2;
    .line 10: iput-object v3, v1, Landroidx/compose/material3/z1;->b:Ln3/g;
    .line 12: return-void
.end method

# virtual methods
.method public final a()V
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/compose/material3/z1;->b:Ln3/g;
    .line 2: move-object v1, v0
    .line 3: check-cast v1, Ln3/h;
    .line 5: invoke-virtual {v1}, Ln3/h;->t()Z
    .line 8: move-result v1
    .line 9: if-eqz v1, :cond_16
    .line 11: sget-object v1, Landroidx/compose/material3/n2;->i:Landroidx/compose/material3/n2;
    .line 13: invoke-interface {v0, v1}, Lw2/e;->c(Ljava/lang/Object;)V
    .line 16: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-eqz v5, :cond_41
    .line 7: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 10: move-result-object v2
    .line 11: const-class v3, Landroidx/compose/material3/z1;
    .line 13: if-eq v3, v2, :cond_16
    .line 15: goto :goto_41
    .line 16: check-cast v5, Landroidx/compose/material3/z1;
    .line 18: iget-object v2, v4, Landroidx/compose/material3/z1;->a:Landroidx/compose/material3/a2;
    .line 20: iget-object v3, v5, Landroidx/compose/material3/z1;->a:Landroidx/compose/material3/a2;
    .line 22: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 25: move-result v2
    .line 26: if-nez v2, :cond_29
    .line 28: return v1
    .line 29: iget-object v2, v4, Landroidx/compose/material3/z1;->b:Ln3/g;
    .line 31: iget-object v5, v5, Landroidx/compose/material3/z1;->b:Ln3/g;
    .line 33: invoke-static {v2, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 36: move-result v5
    .line 37: if-nez v5, :cond_40
    .line 39: return v1
    .line 40: return v0
    .line 41: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/compose/material3/z1;->a:Landroidx/compose/material3/a2;
    .line 2: invoke-virtual {v0}, Landroidx/compose/material3/a2;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v2, Landroidx/compose/material3/z1;->b:Ln3/g;
    .line 10: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: return v1
.end method

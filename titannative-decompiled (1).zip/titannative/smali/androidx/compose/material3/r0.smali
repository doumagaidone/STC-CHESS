.class public final Landroidx/compose/material3/r0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ln/a;
.field public final b:Ln/a;
.field public final c:Ln/a;
.field public final d:Ln/a;
.field public final e:Ln/a;

# direct methods
.method public constructor <init>()V
    .registers 7

    .line 0: sget-object v0, Landroidx/compose/material3/q0;->a:Ln/e;
    .line 2: sget-object v1, Landroidx/compose/material3/q0;->b:Ln/e;
    .line 4: sget-object v2, Landroidx/compose/material3/q0;->c:Ln/e;
    .line 6: sget-object v3, Landroidx/compose/material3/q0;->d:Ln/e;
    .line 8: sget-object v4, Landroidx/compose/material3/q0;->e:Ln/e;
    .line 10: const-string v5, "extraSmall"
    .line 12: invoke-static {v0, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: const-string v5, "small"
    .line 17: invoke-static {v1, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: const-string v5, "medium"
    .line 22: invoke-static {v2, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: const-string v5, "large"
    .line 27: invoke-static {v3, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 30: const-string v5, "extraLarge"
    .line 32: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 35: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 38: iput-object v0, v6, Landroidx/compose/material3/r0;->a:Ln/a;
    .line 40: iput-object v1, v6, Landroidx/compose/material3/r0;->b:Ln/a;
    .line 42: iput-object v2, v6, Landroidx/compose/material3/r0;->c:Ln/a;
    .line 44: iput-object v3, v6, Landroidx/compose/material3/r0;->d:Ln/a;
    .line 46: iput-object v4, v6, Landroidx/compose/material3/r0;->e:Ln/a;
    .line 48: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Landroidx/compose/material3/r0;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Landroidx/compose/material3/r0;
    .line 12: iget-object v1, v5, Landroidx/compose/material3/r0;->a:Ln/a;
    .line 14: iget-object v3, v4, Landroidx/compose/material3/r0;->a:Ln/a;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Landroidx/compose/material3/r0;->b:Ln/a;
    .line 25: iget-object v3, v5, Landroidx/compose/material3/r0;->b:Ln/a;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Landroidx/compose/material3/r0;->c:Ln/a;
    .line 36: iget-object v3, v5, Landroidx/compose/material3/r0;->c:Ln/a;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget-object v1, v4, Landroidx/compose/material3/r0;->d:Ln/a;
    .line 47: iget-object v3, v5, Landroidx/compose/material3/r0;->d:Ln/a;
    .line 49: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v1
    .line 53: if-nez v1, :cond_56
    .line 55: return v2
    .line 56: iget-object v1, v4, Landroidx/compose/material3/r0;->e:Ln/a;
    .line 58: iget-object v5, v5, Landroidx/compose/material3/r0;->e:Ln/a;
    .line 60: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 63: move-result v5
    .line 64: if-nez v5, :cond_67
    .line 66: return v2
    .line 67: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/compose/material3/r0;->a:Ln/a;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v2, Landroidx/compose/material3/r0;->b:Ln/a;
    .line 10: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget-object v0, v2, Landroidx/compose/material3/r0;->c:Ln/a;
    .line 19: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 22: move-result v0
    .line 23: add-int/2addr v0, v1
    .line 24: mul-int/lit8 v0, v0, 31
    .line 26: iget-object v1, v2, Landroidx/compose/material3/r0;->d:Ln/a;
    .line 28: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 31: move-result v1
    .line 32: add-int/2addr v1, v0
    .line 33: mul-int/lit8 v1, v1, 31
    .line 35: iget-object v0, v2, Landroidx/compose/material3/r0;->e:Ln/a;
    .line 37: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 40: move-result v0
    .line 41: add-int/2addr v0, v1
    .line 42: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Shapes(extraSmall="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Landroidx/compose/material3/r0;->a:Ln/a;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", small="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Landroidx/compose/material3/r0;->b:Ln/a;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", medium="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Landroidx/compose/material3/r0;->c:Ln/a;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", large="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v2, Landroidx/compose/material3/r0;->d:Ln/a;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", extraLarge="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-object v1, v2, Landroidx/compose/material3/r0;->e:Ln/a;
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 52: const/16 v1, 41
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 60: move-result-object v0
    .line 61: return-object v0
.end method

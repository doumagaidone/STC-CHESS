.class public abstract Landroidx/compose/material3/s0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/j3;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Landroidx/compose/material3/l;->n:Landroidx/compose/material3/l;
    .line 2: new-instance v1, Lu/j3;
    .line 4: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 7: sput-object v1, Landroidx/compose/material3/s0;->a:Lu/j3;
    .line 9: return-void
.end method

# direct methods
.method public static final a(ILu/l;)Lk0/l0;
    .registers 7

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v5, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 5: check-cast v6, Lu/b0;
    .line 7: sget-object v1, Landroidx/compose/material3/s0;->a:Lu/j3;
    .line 9: invoke-virtual {v6, v1}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 12: move-result-object v6
    .line 13: check-cast v6, Landroidx/compose/material3/r0;
    .line 15: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 18: const/4 v1, 0
    .line 19: if-eqz v5, :cond_91
    .line 21: add-int/lit8 v5, v5, -1
    .line 23: iget-object v2, v6, Landroidx/compose/material3/r0;->e:Ln/a;
    .line 25: iget-object v3, v6, Landroidx/compose/material3/r0;->a:Ln/a;
    .line 27: iget-object v4, v6, Landroidx/compose/material3/r0;->d:Ln/a;
    .line 29: packed-switch v5, :data_92
    .line 32: new-instance v5, Lkotlinx/coroutines/internal/z;
    .line 34: invoke-direct {v5}, Ljava/lang/RuntimeException;-><init>()V
    .line 37: throw v5
    .line 38: iget-object v2, v6, Landroidx/compose/material3/r0;->b:Ln/a;
    .line 40: goto :goto_90
    .line 41: sget-object v2, Lk0/g0;->a:Lk0/f0;
    .line 43: goto :goto_90
    .line 44: iget-object v2, v6, Landroidx/compose/material3/r0;->c:Ln/a;
    .line 46: goto :goto_90
    .line 47: invoke-static {v4}, Landroidx/compose/material3/s0;->b(Ln/a;)Ln/e;
    .line 50: move-result-object v2
    .line 51: goto :goto_90
    .line 52: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 55: const-wide/16 v5, 0
    .line 57: double-to-float v5, v5
    .line 58: new-instance v6, Ln/c;
    .line 60: invoke-direct {v6, v5}, Ln/c;-><init>(F)V
    .line 63: new-instance v0, Ln/c;
    .line 65: invoke-direct {v0, v5}, Ln/c;-><init>(F)V
    .line 68: const/4 v5, 6
    .line 69: invoke-static {v4, v6, v1, v0, v5}, Ln/a;->b(Ln/a;Ln/c;Ln/c;Ln/c;I)Ln/e;
    .line 72: move-result-object v2
    .line 73: goto :goto_90
    .line 74: move-object v2, v4
    .line 75: goto :goto_90
    .line 76: sget-object v2, Ln/f;->a:Ln/e;
    .line 78: goto :goto_90
    .line 79: invoke-static {v3}, Landroidx/compose/material3/s0;->b(Ln/a;)Ln/e;
    .line 82: move-result-object v2
    .line 83: goto :goto_90
    .line 84: move-object v2, v3
    .line 85: goto :goto_90
    .line 86: invoke-static {v2}, Landroidx/compose/material3/s0;->b(Ln/a;)Ln/e;
    .line 89: move-result-object v2
    .line 90: return-object v2
    .line 91: throw v1
    .line 92: nop
    .line 93: move-result-wide v0
    .line 94: nop
    .line 95: nop
    .line 96: if-lez v0, :cond_96
    .line 98: if-nez v0, :cond_98
    .line 100: if-le v0, v0, :cond_100
    .line 102: if-eq v0, v0, :cond_102
    .line 104: cmpl-double v0, v0, v0
    .line 106: cmpl-float v0, v0, v0
    .line 108: const-wide/32 v0, 0x120000
    .line 111: nop
    .line 112: return v0
    .line 113: nop
    .line 114: move-result-object v0
    .line 115: nop
    .line 116: move-object/16 v0, v5
.end method

# direct methods
.method public static final b(Ln/a;)Ln/e;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-wide/16 v0, 0
    .line 7: double-to-float v0, v0
    .line 8: new-instance v1, Ln/c;
    .line 10: invoke-direct {v1, v0}, Ln/c;-><init>(F)V
    .line 13: new-instance v2, Ln/c;
    .line 15: invoke-direct {v2, v0}, Ln/c;-><init>(F)V
    .line 18: const/4 v0, 0
    .line 19: const/4 v3, 3
    .line 20: invoke-static {v4, v0, v2, v1, v3}, Ln/a;->b(Ln/a;Ln/c;Ln/c;Ln/c;I)Ln/e;
    .line 23: move-result-object v4
    .line 24: return-object v4
.end method

.class public abstract Landroidx/compose/material3/r;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/w0;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Landroidx/compose/material3/l;->l:Landroidx/compose/material3/l;
    .line 2: invoke-static {v0}, Le3/g;->o(Ld3/a;)Lu/w0;
    .line 5: move-result-object v0
    .line 6: sput-object v0, Landroidx/compose/material3/r;->a:Lu/w0;
    .line 8: return-void
.end method

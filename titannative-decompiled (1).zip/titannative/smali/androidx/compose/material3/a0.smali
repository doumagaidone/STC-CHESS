.class public abstract Landroidx/compose/material3/a0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/j3;
.field public static final b:J

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Landroidx/compose/material3/l;->m:Landroidx/compose/material3/l;
    .line 2: new-instance v1, Lu/j3;
    .line 4: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 7: sput-object v1, Landroidx/compose/material3/a0;->a:Lu/j3;
    .line 9: const/16 v0, 48
    .line 11: int-to-float v0, v0
    .line 12: invoke-static {v0, v0}, Ld2/b;->f(FF)J
    .line 15: move-result-wide v0
    .line 16: sput-wide v0, Landroidx/compose/material3/a0;->b:J
    .line 18: return-void
.end method

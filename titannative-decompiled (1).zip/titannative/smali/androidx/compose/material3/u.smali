.class public final Landroidx/compose/material3/u;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/Object;
.field public final b:Ld3/f;

# direct methods
.method public constructor <init>(Landroidx/compose/material3/z1;Lb0/c;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/material3/u;->a:Ljava/lang/Object;
    .line 5: iput-object v2, v0, Landroidx/compose/material3/u;->b:Ld3/f;
    .line 7: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Landroidx/compose/material3/u;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Landroidx/compose/material3/u;
    .line 12: iget-object v1, v5, Landroidx/compose/material3/u;->a:Ljava/lang/Object;
    .line 14: iget-object v3, v4, Landroidx/compose/material3/u;->a:Ljava/lang/Object;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Landroidx/compose/material3/u;->b:Ld3/f;
    .line 25: iget-object v5, v5, Landroidx/compose/material3/u;->b:Ld3/f;
    .line 27: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v5
    .line 31: if-nez v5, :cond_34
    .line 33: return v2
    .line 34: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/compose/material3/u;->a:Ljava/lang/Object;
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, 0
    .line 5: goto :goto_10
    .line 6: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 9: move-result v0
    .line 10: mul-int/lit8 v0, v0, 31
    .line 12: iget-object v1, v2, Landroidx/compose/material3/u;->b:Ld3/f;
    .line 14: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 17: move-result v1
    .line 18: add-int/2addr v1, v0
    .line 19: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "FadeInFadeOutAnimationItem(key="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Landroidx/compose/material3/u;->a:Ljava/lang/Object;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", transition="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Landroidx/compose/material3/u;->b:Ld3/f;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const/16 v1, 41
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 30: move-result-object v0
    .line 31: return-object v0
.end method

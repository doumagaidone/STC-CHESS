.class public abstract Landroidx/compose/material3/t;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lh/p1;
.field public static final b:Lh/p1;
.field public static final c:Lh/p1;

# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 0: new-instance v0, Lh/u;
    .line 2: const v1, 0x3f19999a
    .line 5: invoke-direct {v0, v1}, Lh/u;-><init>(F)V
    .line 8: new-instance v1, Lh/p1;
    .line 10: sget-object v2, Lh/a0;->a:Lh/u;
    .line 12: const/16 v3, 120
    .line 14: const/4 v4, 0
    .line 15: invoke-direct {v1, v3, v4, v2}, Lh/p1;-><init>(IILh/y;)V
    .line 18: sput-object v1, Landroidx/compose/material3/t;->a:Lh/p1;
    .line 20: new-instance v1, Lh/p1;
    .line 22: const/16 v2, 150
    .line 24: invoke-direct {v1, v2, v4, v0}, Lh/p1;-><init>(IILh/y;)V
    .line 27: sput-object v1, Landroidx/compose/material3/t;->b:Lh/p1;
    .line 29: new-instance v1, Lh/p1;
    .line 31: invoke-direct {v1, v3, v4, v0}, Lh/p1;-><init>(IILh/y;)V
    .line 34: sput-object v1, Landroidx/compose/material3/t;->c:Lh/p1;
    .line 36: return-void
.end method

.class public final enum Landroidx/compose/material3/n2;
.super Ljava/lang/Enum;
.source "SourceFile"

.field public static final enum i:Landroidx/compose/material3/n2;
.field public static final enum j:Landroidx/compose/material3/n2;
.field public static final synthetic k:[Landroidx/compose/material3/n2;

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: new-instance v0, Landroidx/compose/material3/n2;
    .line 2: const-string v1, "Dismissed"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Landroidx/compose/material3/n2;->i:Landroidx/compose/material3/n2;
    .line 10: new-instance v1, Landroidx/compose/material3/n2;
    .line 12: const-string v2, "ActionPerformed"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Landroidx/compose/material3/n2;->j:Landroidx/compose/material3/n2;
    .line 20: filled-new-array {v0, v1}, [Landroidx/compose/material3/n2;
    .line 23: move-result-object v0
    .line 24: sput-object v0, Landroidx/compose/material3/n2;->k:[Landroidx/compose/material3/n2;
    .line 26: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Landroidx/compose/material3/n2;
    .registers 2

    .line 0: const-class v0, Landroidx/compose/material3/n2;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Landroidx/compose/material3/n2;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Landroidx/compose/material3/n2;
    .registers 1

    .line 0: sget-object v0, Landroidx/compose/material3/n2;->k:[Landroidx/compose/material3/n2;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Landroidx/compose/material3/n2;
    .line 8: return-object v0
.end method

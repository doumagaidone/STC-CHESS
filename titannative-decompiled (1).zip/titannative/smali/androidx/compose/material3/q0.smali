.class public abstract Landroidx/compose/material3/q0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ln/e;
.field public static final b:Ln/e;
.field public static final c:Ln/e;
.field public static final d:Ln/e;
.field public static final e:Ln/e;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Lt/f;->b:Ln/e;
    .line 2: sput-object v0, Landroidx/compose/material3/q0;->a:Ln/e;
    .line 4: sget-object v0, Lt/f;->e:Ln/e;
    .line 6: sput-object v0, Landroidx/compose/material3/q0;->b:Ln/e;
    .line 8: sget-object v0, Lt/f;->d:Ln/e;
    .line 10: sput-object v0, Landroidx/compose/material3/q0;->c:Ln/e;
    .line 12: sget-object v0, Lt/f;->c:Ln/e;
    .line 14: sput-object v0, Landroidx/compose/material3/q0;->d:Ln/e;
    .line 16: sget-object v0, Lt/f;->a:Ln/e;
    .line 18: sput-object v0, Landroidx/compose/material3/q0;->e:Ln/e;
    .line 20: return-void
.end method

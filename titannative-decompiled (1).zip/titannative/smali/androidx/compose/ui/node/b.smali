.class public abstract Landroidx/compose/ui/node/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lz0/w0;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Lz0/w0;
    .line 2: invoke-direct {v0}, Lf0/o;-><init>()V
    .line 5: const/4 v1, -1
    .line 6: iput v1, v0, Lf0/o;->l:I
    .line 8: sput-object v0, Landroidx/compose/ui/node/b;->a:Lz0/w0;
    .line 10: return-void
.end method

# direct methods
.method public static final a(Lf0/n;Lf0/n;)I
    .registers 4

    .line 0: const-string v0, "prev"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "next"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_18
    .line 16: const/4 v2, 2
    .line 17: goto :goto_55
    .line 18: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 21: move-result-object v0
    .line 22: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 25: move-result-object v1
    .line 26: if-ne v0, v1, :cond_29
    .line 28: goto :goto_52
    .line 29: instance-of v0, v2, Landroidx/compose/ui/node/ForceUpdateElement;
    .line 31: if-eqz v0, :cond_54
    .line 33: check-cast v2, Landroidx/compose/ui/node/ForceUpdateElement;
    .line 35: const-string v0, "a"
    .line 37: iget-object v2, v2, Landroidx/compose/ui/node/ForceUpdateElement;->c:Lz0/t0;
    .line 39: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 42: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 45: move-result-object v2
    .line 46: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 49: move-result-object v3
    .line 50: if-ne v2, v3, :cond_54
    .line 52: const/4 v2, 1
    .line 53: goto :goto_55
    .line 54: const/4 v2, 0
    .line 55: return v2
.end method

.class public abstract Landroidx/compose/ui/draw/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf0/p;F)Lf0/p;
    .registers 10

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const/high16 v0, 0x3f80
    .line 7: cmpg-float v0, v9, v0
    .line 9: if-nez v0, :cond_12
    .line 11: goto :goto_25
    .line 12: const/4 v2, 0
    .line 13: const/4 v3, 0
    .line 14: const/4 v5, 0
    .line 15: const/4 v6, 1
    .line 16: const v7, 0x1effb
    .line 19: move-object v1, v8
    .line 20: move v4, v9
    .line 21: invoke-static/range {v1 .. v7}, Landroidx/compose/ui/graphics/a;->l(Lf0/p;FFFLk0/l0;ZI)Lf0/p;
    .line 24: move-result-object v8
    .line 25: return-object v8
.end method

# direct methods
.method public static final b(Lf0/p;Lk0/l0;)Lf0/p;
    .registers 10

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "shape"
    .line 7: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const/4 v2, 0
    .line 11: const/4 v3, 0
    .line 12: const/4 v4, 0
    .line 13: const/4 v6, 1
    .line 14: const v7, 0x1e7ff
    .line 17: move-object v1, v8
    .line 18: move-object v5, v9
    .line 19: invoke-static/range {v1 .. v7}, Landroidx/compose/ui/graphics/a;->l(Lf0/p;FFFLk0/l0;ZI)Lf0/p;
    .line 22: move-result-object v8
    .line 23: return-object v8
.end method

# direct methods
.method public static final c(Lf0/p;)Lf0/p;
    .registers 9

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const/4 v2, 0
    .line 6: const/4 v3, 0
    .line 7: const/4 v4, 0
    .line 8: const/4 v5, 0
    .line 9: const/4 v6, 1
    .line 10: const v7, 0x1efff
    .line 13: move-object v1, v8
    .line 14: invoke-static/range {v1 .. v7}, Landroidx/compose/ui/graphics/a;->l(Lf0/p;FFFLk0/l0;ZI)Lf0/p;
    .line 17: move-result-object v8
    .line 18: return-object v8
.end method

# direct methods
.method public static final d(Lf0/p;Ld3/c;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "onDraw"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/ui/draw/DrawBehindElement;
    .line 12: invoke-direct {v0, v2}, Landroidx/compose/ui/draw/DrawBehindElement;-><init>(Ld3/c;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

# direct methods
.method public static final e(Ld3/c;)Lf0/p;
    .registers 2

    .line 0: const-string v0, "onBuildDrawCache"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/draw/DrawWithCacheElement;
    .line 7: invoke-direct {v0, v1}, Landroidx/compose/ui/draw/DrawWithCacheElement;-><init>(Ld3/c;)V
    .line 10: return-object v0
.end method

# direct methods
.method public static final f(Lf0/p;Ld3/c;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/draw/DrawWithContentElement;
    .line 7: invoke-direct {v0, v2}, Landroidx/compose/ui/draw/DrawWithContentElement;-><init>(Ld3/c;)V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

# direct methods
.method public static g(Lf0/p;Ln0/b;Lf0/d;Lx0/h;FLk0/r;I)Lf0/p;
    .registers 15

    .line 0: and-int/lit8 v0, v14, 2
    .line 2: if-eqz v0, :cond_7
    .line 4: const/4 v0, 1
    .line 5: move v3, v0
    .line 6: goto :goto_9
    .line 7: const/4 v0, 0
    .line 8: goto :goto_5
    .line 9: and-int/lit8 v0, v14, 4
    .line 11: if-eqz v0, :cond_15
    .line 13: sget-object v10, Lf0/a;->j:Lf0/g;
    .line 15: move-object v4, v10
    .line 16: and-int/lit8 v10, v14, 8
    .line 18: if-eqz v10, :cond_22
    .line 20: sget-object v11, Lx0/g;->b:Lz3/b;
    .line 22: move-object v5, v11
    .line 23: and-int/lit8 v10, v14, 16
    .line 25: if-eqz v10, :cond_29
    .line 27: const/high16 v12, 0x3f80
    .line 29: move v6, v12
    .line 30: and-int/lit8 v10, v14, 32
    .line 32: if-eqz v10, :cond_35
    .line 34: const/4 v13, 0
    .line 35: move-object v7, v13
    .line 36: const-string v10, "<this>"
    .line 38: invoke-static {v8, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 41: const-string v10, "painter"
    .line 43: invoke-static {v9, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 46: const-string v10, "alignment"
    .line 48: invoke-static {v4, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 51: const-string v10, "contentScale"
    .line 53: invoke-static {v5, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 56: new-instance v10, Landroidx/compose/ui/draw/PainterElement;
    .line 58: move-object v1, v10
    .line 59: move-object v2, v9
    .line 60: invoke-direct/range {v1 .. v7}, Landroidx/compose/ui/draw/PainterElement;-><init>(Ln0/b;ZLf0/d;Lx0/h;FLk0/r;)V
    .line 63: invoke-interface {v8, v10}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 66: move-result-object v8
    .line 67: return-object v8
.end method

# direct methods
.method public static h(Lf0/p;FLk0/l0;)Lf0/p;
    .registers 14

    .line 0: const/4 v3, 0
    .line 1: sget-wide v6, Lk0/x;->a:J
    .line 3: const-string v0, "$this$shadow"
    .line 5: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 8: const-string v0, "shape"
    .line 10: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: const/4 v0, 0
    .line 14: int-to-float v0, v0
    .line 15: invoke-static {v12, v0}, Ljava/lang/Float;->compare(FF)I
    .line 18: move-result v0
    .line 19: if-gtz v0, :cond_22
    .line 21: goto :goto_43
    .line 22: sget-object v8, Landroidx/compose/ui/platform/s;->A:Landroidx/compose/ui/platform/s;
    .line 24: sget-object v9, Lf0/m;->c:Lf0/m;
    .line 26: new-instance v10, Lh0/k;
    .line 28: move-object v0, v10
    .line 29: move v1, v12
    .line 30: move-object v2, v13
    .line 31: move-wide v4, v6
    .line 32: invoke-direct/range {v0 .. v7}, Lh0/k;-><init>(FLk0/l0;ZJJ)V
    .line 35: invoke-static {v9, v10}, Landroidx/compose/ui/graphics/a;->k(Lf0/p;Ld3/c;)Lf0/p;
    .line 38: move-result-object v12
    .line 39: invoke-static {v11, v8, v12}, Landroidx/compose/ui/platform/u1;->a(Lf0/p;Ld3/c;Lf0/p;)Lf0/p;
    .line 42: move-result-object v11
    .line 43: return-object v11
.end method

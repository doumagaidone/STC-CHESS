.class public abstract Landroidx/compose/ui/input/key/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(I)J
    .registers 7

    .line 0: int-to-long v0, v6
    .line 1: const/16 v6, 32
    .line 3: shl-long/2addr v0, v6
    .line 4: const/4 v6, 0
    .line 5: int-to-long v2, v6
    .line 6: const-wide v4, 0x00ffffffff
    .line 11: and-long/2addr v2, v4
    .line 12: or-long/2addr v0, v2
    .line 13: sget v6, Ls0/a;->l:I
    .line 15: return-wide v0
.end method

# direct methods
.method public static final b(Landroid/view/KeyEvent;)J
    .registers 3

    .line 0: const-string v0, "$this$key"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/view/KeyEvent;->getKeyCode()I
    .line 8: move-result v2
    .line 9: invoke-static {v2}, Landroidx/compose/ui/input/key/a;->a(I)J
    .line 12: move-result-wide v0
    .line 13: return-wide v0
.end method

# direct methods
.method public static final c(Landroid/view/KeyEvent;)I
    .registers 2

    .line 0: const-string v0, "$this$type"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1}, Landroid/view/KeyEvent;->getAction()I
    .line 8: move-result v1
    .line 9: if-eqz v1, :cond_16
    .line 11: const/4 v0, 1
    .line 12: if-eq v1, v0, :cond_17
    .line 14: const/4 v0, 0
    .line 15: goto :goto_17
    .line 16: const/4 v0, 2
    .line 17: return v0
.end method

# direct methods
.method public static final d(Ld3/c;)Lf0/p;
    .registers 3

    .line 0: new-instance v0, Landroidx/compose/ui/input/key/KeyInputElement;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v2, v1}, Landroidx/compose/ui/input/key/KeyInputElement;-><init>(Ld3/c;Li/t;)V
    .line 6: return-object v0
.end method

# direct methods
.method public static final e(Lf0/p;Li/t;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/input/key/KeyInputElement;
    .line 7: const/4 v1, 0
    .line 8: invoke-direct {v0, v1, v3}, Landroidx/compose/ui/input/key/KeyInputElement;-><init>(Ld3/c;Li/t;)V
    .line 11: invoke-interface {v2, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 14: move-result-object v2
    .line 15: return-object v2
.end method

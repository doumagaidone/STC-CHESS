.class public abstract Landroidx/compose/ui/input/nestedscroll/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf0/p;Lt0/a;Lt0/d;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "connection"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;
    .line 12: invoke-direct {v0, v2, v3}, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;-><init>(Lt0/a;Lt0/d;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

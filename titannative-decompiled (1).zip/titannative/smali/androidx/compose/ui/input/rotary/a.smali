.class public abstract Landroidx/compose/ui/input/rotary/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a()Lf0/p;
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/input/rotary/RotaryInputElement;
    .line 2: invoke-direct {v0}, Landroidx/compose/ui/input/rotary/RotaryInputElement;-><init>()V
    .line 5: return-object v0
.end method

.class public abstract Landroidx/compose/ui/focus/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final A(Li0/q;Ld3/c;)Z
    .registers 13

    .line 0: const/16 v0, 16
    .line 2: new-array v1, v0, [Li0/q;
    .line 4: iget-object v11, v11, Lf0/o;->i:Lf0/o;
    .line 6: iget-boolean v2, v11, Lf0/o;->u:Z
    .line 8: if-eqz v2, :cond_205
    .line 10: new-instance v2, Lv/j;
    .line 12: new-array v3, v0, [Lf0/o;
    .line 14: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 17: iput-object v3, v2, Lv/j;->i:[Ljava/lang/Object;
    .line 19: const/4 v3, 0
    .line 20: iput v3, v2, Lv/j;->k:I
    .line 22: iget-object v4, v11, Lf0/o;->n:Lf0/o;
    .line 24: if-nez v4, :cond_31
    .line 26: invoke-static {v2, v11}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 29: move v11, v3
    .line 30: goto :goto_35
    .line 31: invoke-virtual {v2, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 34: goto :goto_29
    .line 35: invoke-virtual {v2}, Lv/j;->j()Z
    .line 38: move-result v4
    .line 39: const/4 v5, 1
    .line 40: if-eqz v4, :cond_170
    .line 42: iget v4, v2, Lv/j;->k:I
    .line 44: sub-int/2addr v4, v5
    .line 45: invoke-virtual {v2, v4}, Lv/j;->l(I)Ljava/lang/Object;
    .line 48: move-result-object v4
    .line 49: check-cast v4, Lf0/o;
    .line 51: iget v6, v4, Lf0/o;->l:I
    .line 53: and-int/lit16 v6, v6, 1024
    .line 55: if-nez v6, :cond_61
    .line 57: invoke-static {v2, v4}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 60: goto :goto_35
    .line 61: if-eqz v4, :cond_35
    .line 63: iget v6, v4, Lf0/o;->k:I
    .line 65: and-int/lit16 v6, v6, 1024
    .line 67: if-eqz v6, :cond_167
    .line 69: const/4 v6, 0
    .line 70: move-object v7, v6
    .line 71: if-eqz v4, :cond_35
    .line 73: instance-of v8, v4, Li0/q;
    .line 75: if-eqz v8, :cond_104
    .line 77: check-cast v4, Li0/q;
    .line 79: add-int/lit8 v8, v11, 1
    .line 81: array-length v9, v1
    .line 82: if-ge v9, v8, :cond_100
    .line 84: array-length v9, v1
    .line 85: mul-int/lit8 v9, v9, 2
    .line 87: invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I
    .line 90: move-result v9
    .line 91: invoke-static {v1, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 94: move-result-object v1
    .line 95: const-string v9, "copyOf(this, newSize)"
    .line 97: invoke-static {v1, v9}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 100: aput-object v4, v1, v11
    .line 102: move v11, v8
    .line 103: goto :goto_162
    .line 104: iget v8, v4, Lf0/o;->k:I
    .line 106: and-int/lit16 v8, v8, 1024
    .line 108: if-eqz v8, :cond_162
    .line 110: instance-of v8, v4, Lz0/p;
    .line 112: if-eqz v8, :cond_162
    .line 114: move-object v8, v4
    .line 115: check-cast v8, Lz0/p;
    .line 117: iget-object v8, v8, Lz0/p;->w:Lf0/o;
    .line 119: move v9, v3
    .line 120: if-eqz v8, :cond_159
    .line 122: iget v10, v8, Lf0/o;->k:I
    .line 124: and-int/lit16 v10, v10, 1024
    .line 126: if-eqz v10, :cond_156
    .line 128: add-int/lit8 v9, v9, 1
    .line 130: if-ne v9, v5, :cond_134
    .line 132: move-object v4, v8
    .line 133: goto :goto_156
    .line 134: if-nez v7, :cond_147
    .line 136: new-instance v7, Lv/j;
    .line 138: new-array v10, v0, [Lf0/o;
    .line 140: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 143: iput-object v10, v7, Lv/j;->i:[Ljava/lang/Object;
    .line 145: iput v3, v7, Lv/j;->k:I
    .line 147: if-eqz v4, :cond_153
    .line 149: invoke-virtual {v7, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 152: move-object v4, v6
    .line 153: invoke-virtual {v7, v8}, Lv/j;->b(Ljava/lang/Object;)V
    .line 156: iget-object v8, v8, Lf0/o;->n:Lf0/o;
    .line 158: goto :goto_120
    .line 159: if-ne v9, v5, :cond_162
    .line 161: goto :goto_71
    .line 162: invoke-static {v7}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 165: move-result-object v4
    .line 166: goto :goto_71
    .line 167: iget-object v4, v4, Lf0/o;->n:Lf0/o;
    .line 169: goto :goto_61
    .line 170: sget-object v0, Li0/r;->a:Li0/r;
    .line 172: const-string v2, "<this>"
    .line 174: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 177: invoke-static {v1, v3, v11, v0}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V
    .line 180: if-lez v11, :cond_204
    .line 182: sub-int/2addr v11, v5
    .line 183: aget-object v0, v1, v11
    .line 185: check-cast v0, Li0/q;
    .line 187: invoke-static {v0}, Landroidx/compose/ui/focus/a;->u(Li0/q;)Z
    .line 190: move-result v2
    .line 191: if-eqz v2, :cond_200
    .line 193: invoke-static {v0, v12}, Landroidx/compose/ui/focus/a;->a(Li0/q;Ld3/c;)Z
    .line 196: move-result v0
    .line 197: if-eqz v0, :cond_200
    .line 199: return v5
    .line 200: add-int/lit8 v11, v11, -1
    .line 202: if-gez v11, :cond_183
    .line 204: return v3
    .line 205: new-instance v11, Ljava/lang/IllegalStateException;
    .line 207: const-string v12, "visitChildren called on an unattached node"
    .line 209: invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 212: move-result-object v12
    .line 213: invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 216: throw v11
.end method

# direct methods
.method public static final B(Li0/q;Ld3/c;)Z
    .registers 13

    .line 0: const/16 v0, 16
    .line 2: new-array v1, v0, [Li0/q;
    .line 4: iget-object v11, v11, Lf0/o;->i:Lf0/o;
    .line 6: iget-boolean v2, v11, Lf0/o;->u:Z
    .line 8: if-eqz v2, :cond_206
    .line 10: new-instance v2, Lv/j;
    .line 12: new-array v3, v0, [Lf0/o;
    .line 14: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 17: iput-object v3, v2, Lv/j;->i:[Ljava/lang/Object;
    .line 19: const/4 v3, 0
    .line 20: iput v3, v2, Lv/j;->k:I
    .line 22: iget-object v4, v11, Lf0/o;->n:Lf0/o;
    .line 24: if-nez v4, :cond_31
    .line 26: invoke-static {v2, v11}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 29: move v11, v3
    .line 30: goto :goto_35
    .line 31: invoke-virtual {v2, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 34: goto :goto_29
    .line 35: invoke-virtual {v2}, Lv/j;->j()Z
    .line 38: move-result v4
    .line 39: const/4 v5, 1
    .line 40: if-eqz v4, :cond_170
    .line 42: iget v4, v2, Lv/j;->k:I
    .line 44: sub-int/2addr v4, v5
    .line 45: invoke-virtual {v2, v4}, Lv/j;->l(I)Ljava/lang/Object;
    .line 48: move-result-object v4
    .line 49: check-cast v4, Lf0/o;
    .line 51: iget v6, v4, Lf0/o;->l:I
    .line 53: and-int/lit16 v6, v6, 1024
    .line 55: if-nez v6, :cond_61
    .line 57: invoke-static {v2, v4}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 60: goto :goto_35
    .line 61: if-eqz v4, :cond_35
    .line 63: iget v6, v4, Lf0/o;->k:I
    .line 65: and-int/lit16 v6, v6, 1024
    .line 67: if-eqz v6, :cond_167
    .line 69: const/4 v6, 0
    .line 70: move-object v7, v6
    .line 71: if-eqz v4, :cond_35
    .line 73: instance-of v8, v4, Li0/q;
    .line 75: if-eqz v8, :cond_104
    .line 77: check-cast v4, Li0/q;
    .line 79: add-int/lit8 v8, v11, 1
    .line 81: array-length v9, v1
    .line 82: if-ge v9, v8, :cond_100
    .line 84: array-length v9, v1
    .line 85: mul-int/lit8 v9, v9, 2
    .line 87: invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I
    .line 90: move-result v9
    .line 91: invoke-static {v1, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 94: move-result-object v1
    .line 95: const-string v9, "copyOf(this, newSize)"
    .line 97: invoke-static {v1, v9}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 100: aput-object v4, v1, v11
    .line 102: move v11, v8
    .line 103: goto :goto_162
    .line 104: iget v8, v4, Lf0/o;->k:I
    .line 106: and-int/lit16 v8, v8, 1024
    .line 108: if-eqz v8, :cond_162
    .line 110: instance-of v8, v4, Lz0/p;
    .line 112: if-eqz v8, :cond_162
    .line 114: move-object v8, v4
    .line 115: check-cast v8, Lz0/p;
    .line 117: iget-object v8, v8, Lz0/p;->w:Lf0/o;
    .line 119: move v9, v3
    .line 120: if-eqz v8, :cond_159
    .line 122: iget v10, v8, Lf0/o;->k:I
    .line 124: and-int/lit16 v10, v10, 1024
    .line 126: if-eqz v10, :cond_156
    .line 128: add-int/lit8 v9, v9, 1
    .line 130: if-ne v9, v5, :cond_134
    .line 132: move-object v4, v8
    .line 133: goto :goto_156
    .line 134: if-nez v7, :cond_147
    .line 136: new-instance v7, Lv/j;
    .line 138: new-array v10, v0, [Lf0/o;
    .line 140: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 143: iput-object v10, v7, Lv/j;->i:[Ljava/lang/Object;
    .line 145: iput v3, v7, Lv/j;->k:I
    .line 147: if-eqz v4, :cond_153
    .line 149: invoke-virtual {v7, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 152: move-object v4, v6
    .line 153: invoke-virtual {v7, v8}, Lv/j;->b(Ljava/lang/Object;)V
    .line 156: iget-object v8, v8, Lf0/o;->n:Lf0/o;
    .line 158: goto :goto_120
    .line 159: if-ne v9, v5, :cond_162
    .line 161: goto :goto_71
    .line 162: invoke-static {v7}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 165: move-result-object v4
    .line 166: goto :goto_71
    .line 167: iget-object v4, v4, Lf0/o;->n:Lf0/o;
    .line 169: goto :goto_61
    .line 170: sget-object v0, Li0/r;->a:Li0/r;
    .line 172: const-string v2, "<this>"
    .line 174: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 177: invoke-static {v1, v3, v11, v0}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V
    .line 180: if-lez v11, :cond_205
    .line 182: move v0, v3
    .line 183: aget-object v2, v1, v0
    .line 185: check-cast v2, Li0/q;
    .line 187: invoke-static {v2}, Landroidx/compose/ui/focus/a;->u(Li0/q;)Z
    .line 190: move-result v4
    .line 191: if-eqz v4, :cond_201
    .line 193: invoke-static {v2, v12}, Landroidx/compose/ui/focus/a;->l(Li0/q;Ld3/c;)Z
    .line 196: move-result v2
    .line 197: if-eqz v2, :cond_201
    .line 199: move v3, v5
    .line 200: goto :goto_205
    .line 201: add-int/lit8 v0, v0, 1
    .line 203: if-lt v0, v11, :cond_183
    .line 205: return v3
    .line 206: new-instance v11, Ljava/lang/IllegalStateException;
    .line 208: const-string v12, "visitChildren called on an unattached node"
    .line 210: invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 213: move-result-object v12
    .line 214: invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 217: throw v11
.end method

# direct methods
.method public static final C(Li0/q;)V
    .registers 11

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v10, Lf0/o;->i:Lf0/o;
    .line 7: iget-boolean v1, v0, Lf0/o;->u:Z
    .line 9: if-eqz v1, :cond_155
    .line 11: invoke-static {v10}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 14: move-result-object v10
    .line 15: move-object v1, v0
    .line 16: if-eqz v10, :cond_154
    .line 18: iget-object v2, v10, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 20: iget-object v2, v2, Lz0/v0;->e:Lf0/o;
    .line 22: iget v2, v2, Lf0/o;->l:I
    .line 24: and-int/lit16 v2, v2, 5120
    .line 26: const/4 v3, 0
    .line 27: if-eqz v2, :cond_137
    .line 29: if-eqz v1, :cond_137
    .line 31: iget v2, v1, Lf0/o;->k:I
    .line 33: and-int/lit16 v4, v2, 5120
    .line 35: if-eqz v4, :cond_134
    .line 37: if-eq v1, v0, :cond_45
    .line 39: and-int/lit16 v4, v2, 1024
    .line 41: if-eqz v4, :cond_45
    .line 43: goto/16 :goto_154
    .line 45: and-int/lit16 v2, v2, 4096
    .line 47: if-eqz v2, :cond_134
    .line 49: move-object v2, v1
    .line 50: move-object v4, v3
    .line 51: if-eqz v2, :cond_134
    .line 53: instance-of v5, v2, Li0/c;
    .line 55: if-eqz v5, :cond_67
    .line 57: check-cast v2, Li0/c;
    .line 59: invoke-static {v2}, Landroidx/compose/ui/focus/a;->p(Li0/c;)Li0/p;
    .line 62: move-result-object v5
    .line 63: invoke-interface {v2, v5}, Li0/c;->j0(Li0/p;)V
    .line 66: goto :goto_129
    .line 67: iget v5, v2, Lf0/o;->k:I
    .line 69: and-int/lit16 v5, v5, 4096
    .line 71: if-eqz v5, :cond_129
    .line 73: instance-of v5, v2, Lz0/p;
    .line 75: if-eqz v5, :cond_129
    .line 77: move-object v5, v2
    .line 78: check-cast v5, Lz0/p;
    .line 80: iget-object v5, v5, Lz0/p;->w:Lf0/o;
    .line 82: const/4 v6, 0
    .line 83: move v7, v6
    .line 84: const/4 v8, 1
    .line 85: if-eqz v5, :cond_126
    .line 87: iget v9, v5, Lf0/o;->k:I
    .line 89: and-int/lit16 v9, v9, 4096
    .line 91: if-eqz v9, :cond_123
    .line 93: add-int/lit8 v7, v7, 1
    .line 95: if-ne v7, v8, :cond_99
    .line 97: move-object v2, v5
    .line 98: goto :goto_123
    .line 99: if-nez v4, :cond_114
    .line 101: new-instance v4, Lv/j;
    .line 103: const/16 v8, 16
    .line 105: new-array v8, v8, [Lf0/o;
    .line 107: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 110: iput-object v8, v4, Lv/j;->i:[Ljava/lang/Object;
    .line 112: iput v6, v4, Lv/j;->k:I
    .line 114: if-eqz v2, :cond_120
    .line 116: invoke-virtual {v4, v2}, Lv/j;->b(Ljava/lang/Object;)V
    .line 119: move-object v2, v3
    .line 120: invoke-virtual {v4, v5}, Lv/j;->b(Ljava/lang/Object;)V
    .line 123: iget-object v5, v5, Lf0/o;->n:Lf0/o;
    .line 125: goto :goto_84
    .line 126: if-ne v7, v8, :cond_129
    .line 128: goto :goto_51
    .line 129: invoke-static {v4}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 132: move-result-object v2
    .line 133: goto :goto_51
    .line 134: iget-object v1, v1, Lf0/o;->m:Lf0/o;
    .line 136: goto :goto_29
    .line 137: invoke-virtual {v10}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 140: move-result-object v10
    .line 141: if-eqz v10, :cond_151
    .line 143: iget-object v1, v10, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 145: if-eqz v1, :cond_151
    .line 147: iget-object v1, v1, Lz0/v0;->d:Lz0/q1;
    .line 149: goto/16 :goto_16
    .line 151: move-object v1, v3
    .line 152: goto/16 :goto_16
    .line 154: return-void
    .line 155: new-instance v10, Ljava/lang/IllegalStateException;
    .line 157: const-string v0, "visitAncestors called on an unattached node"
    .line 159: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 162: move-result-object v0
    .line 163: invoke-direct {v10, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 166: throw v10
.end method

# direct methods
.method public static final D(Li0/q;)Z
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const/4 v0, 7
    .line 6: invoke-static {v2, v0}, Landroidx/compose/ui/focus/a;->y(Li0/q;I)I
    .line 9: move-result v0
    .line 10: invoke-static {v0}, Lh/j;->d(I)I
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_34
    .line 16: const/4 v2, 1
    .line 17: if-eq v0, v2, :cond_32
    .line 19: const/4 v1, 2
    .line 20: if-eq v0, v1, :cond_38
    .line 22: const/4 v2, 3
    .line 23: if-ne v0, v2, :cond_26
    .line 25: goto :goto_32
    .line 26: new-instance v2, Lkotlinx/coroutines/internal/z;
    .line 28: invoke-direct {v2}, Ljava/lang/RuntimeException;-><init>()V
    .line 31: throw v2
    .line 32: const/4 v2, 0
    .line 33: goto :goto_38
    .line 34: invoke-static {v2}, Landroidx/compose/ui/focus/a;->z(Li0/q;)Z
    .line 37: move-result v2
    .line 38: return v2
.end method

# direct methods
.method public static final E(Li0/q;Li0/q;)Z
    .registers 14

    .line 0: iget-object v0, v13, Lf0/o;->i:Lf0/o;
    .line 2: iget-boolean v1, v0, Lf0/o;->u:Z
    .line 4: const-string v2, "visitAncestors called on an unattached node"
    .line 6: if-eqz v1, :cond_433
    .line 8: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 10: invoke-static {v13}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 13: move-result-object v1
    .line 14: const/4 v3, 0
    .line 15: const/4 v4, 1
    .line 16: const/16 v5, 16
    .line 18: const/4 v6, 0
    .line 19: if-eqz v1, :cond_129
    .line 21: iget-object v7, v1, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 23: iget-object v7, v7, Lz0/v0;->e:Lf0/o;
    .line 25: iget v7, v7, Lf0/o;->l:I
    .line 27: and-int/lit16 v7, v7, 1024
    .line 29: if-eqz v7, :cond_114
    .line 31: if-eqz v0, :cond_114
    .line 33: iget v7, v0, Lf0/o;->k:I
    .line 35: and-int/lit16 v7, v7, 1024
    .line 37: if-eqz v7, :cond_111
    .line 39: move-object v7, v0
    .line 40: move-object v8, v6
    .line 41: if-eqz v7, :cond_111
    .line 43: instance-of v9, v7, Li0/q;
    .line 45: if-eqz v9, :cond_48
    .line 47: goto :goto_130
    .line 48: iget v9, v7, Lf0/o;->k:I
    .line 50: and-int/lit16 v9, v9, 1024
    .line 52: if-eqz v9, :cond_106
    .line 54: instance-of v9, v7, Lz0/p;
    .line 56: if-eqz v9, :cond_106
    .line 58: move-object v9, v7
    .line 59: check-cast v9, Lz0/p;
    .line 61: iget-object v9, v9, Lz0/p;->w:Lf0/o;
    .line 63: move v10, v3
    .line 64: if-eqz v9, :cond_103
    .line 66: iget v11, v9, Lf0/o;->k:I
    .line 68: and-int/lit16 v11, v11, 1024
    .line 70: if-eqz v11, :cond_100
    .line 72: add-int/lit8 v10, v10, 1
    .line 74: if-ne v10, v4, :cond_78
    .line 76: move-object v7, v9
    .line 77: goto :goto_100
    .line 78: if-nez v8, :cond_91
    .line 80: new-instance v8, Lv/j;
    .line 82: new-array v11, v5, [Lf0/o;
    .line 84: invoke-direct {v8}, Ljava/lang/Object;-><init>()V
    .line 87: iput-object v11, v8, Lv/j;->i:[Ljava/lang/Object;
    .line 89: iput v3, v8, Lv/j;->k:I
    .line 91: if-eqz v7, :cond_97
    .line 93: invoke-virtual {v8, v7}, Lv/j;->b(Ljava/lang/Object;)V
    .line 96: move-object v7, v6
    .line 97: invoke-virtual {v8, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 100: iget-object v9, v9, Lf0/o;->n:Lf0/o;
    .line 102: goto :goto_64
    .line 103: if-ne v10, v4, :cond_106
    .line 105: goto :goto_41
    .line 106: invoke-static {v8}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 109: move-result-object v7
    .line 110: goto :goto_41
    .line 111: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 113: goto :goto_31
    .line 114: invoke-virtual {v1}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 117: move-result-object v1
    .line 118: if-eqz v1, :cond_127
    .line 120: iget-object v0, v1, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 122: if-eqz v0, :cond_127
    .line 124: iget-object v0, v0, Lz0/v0;->d:Lz0/q1;
    .line 126: goto :goto_14
    .line 127: move-object v0, v6
    .line 128: goto :goto_14
    .line 129: move-object v7, v6
    .line 130: invoke-static {v7, v12}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 133: move-result v0
    .line 134: if-eqz v0, :cond_421
    .line 136: iget-object v0, v12, Li0/q;->x:Li0/p;
    .line 138: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 141: move-result v0
    .line 142: sget-object v1, Li0/p;->j:Li0/p;
    .line 144: if-eqz v0, :cond_408
    .line 146: if-eq v0, v4, :cond_368
    .line 148: const/4 v7, 2
    .line 149: if-eq v0, v7, :cond_420
    .line 151: const/4 v7, 3
    .line 152: if-ne v0, v7, :cond_362
    .line 154: iget-object v0, v12, Lf0/o;->i:Lf0/o;
    .line 156: iget-boolean v7, v0, Lf0/o;->u:Z
    .line 158: if-eqz v7, :cond_352
    .line 160: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 162: invoke-static {v12}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 165: move-result-object v2
    .line 166: if-eqz v2, :cond_277
    .line 168: iget-object v7, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 170: iget-object v7, v7, Lz0/v0;->e:Lf0/o;
    .line 172: iget v7, v7, Lf0/o;->l:I
    .line 174: and-int/lit16 v7, v7, 1024
    .line 176: if-eqz v7, :cond_262
    .line 178: if-eqz v0, :cond_262
    .line 180: iget v7, v0, Lf0/o;->k:I
    .line 182: and-int/lit16 v7, v7, 1024
    .line 184: if-eqz v7, :cond_259
    .line 186: move-object v7, v0
    .line 187: move-object v8, v6
    .line 188: if-eqz v7, :cond_259
    .line 190: instance-of v9, v7, Li0/q;
    .line 192: if-eqz v9, :cond_196
    .line 194: move-object v6, v7
    .line 195: goto :goto_277
    .line 196: iget v9, v7, Lf0/o;->k:I
    .line 198: and-int/lit16 v9, v9, 1024
    .line 200: if-eqz v9, :cond_254
    .line 202: instance-of v9, v7, Lz0/p;
    .line 204: if-eqz v9, :cond_254
    .line 206: move-object v9, v7
    .line 207: check-cast v9, Lz0/p;
    .line 209: iget-object v9, v9, Lz0/p;->w:Lf0/o;
    .line 211: move v10, v3
    .line 212: if-eqz v9, :cond_251
    .line 214: iget v11, v9, Lf0/o;->k:I
    .line 216: and-int/lit16 v11, v11, 1024
    .line 218: if-eqz v11, :cond_248
    .line 220: add-int/lit8 v10, v10, 1
    .line 222: if-ne v10, v4, :cond_226
    .line 224: move-object v7, v9
    .line 225: goto :goto_248
    .line 226: if-nez v8, :cond_239
    .line 228: new-instance v8, Lv/j;
    .line 230: new-array v11, v5, [Lf0/o;
    .line 232: invoke-direct {v8}, Ljava/lang/Object;-><init>()V
    .line 235: iput-object v11, v8, Lv/j;->i:[Ljava/lang/Object;
    .line 237: iput v3, v8, Lv/j;->k:I
    .line 239: if-eqz v7, :cond_245
    .line 241: invoke-virtual {v8, v7}, Lv/j;->b(Ljava/lang/Object;)V
    .line 244: move-object v7, v6
    .line 245: invoke-virtual {v8, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 248: iget-object v9, v9, Lf0/o;->n:Lf0/o;
    .line 250: goto :goto_212
    .line 251: if-ne v10, v4, :cond_254
    .line 253: goto :goto_188
    .line 254: invoke-static {v8}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 257: move-result-object v7
    .line 258: goto :goto_188
    .line 259: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 261: goto :goto_178
    .line 262: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 265: move-result-object v2
    .line 266: if-eqz v2, :cond_275
    .line 268: iget-object v0, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 270: if-eqz v0, :cond_275
    .line 272: iget-object v0, v0, Lz0/v0;->d:Lz0/q1;
    .line 274: goto :goto_166
    .line 275: move-object v0, v6
    .line 276: goto :goto_166
    .line 277: check-cast v6, Li0/q;
    .line 279: if-nez v6, :cond_323
    .line 281: iget-object v0, v12, Lf0/o;->p:Lz0/a1;
    .line 283: if-eqz v0, :cond_311
    .line 285: iget-object v0, v0, Lz0/a1;->p:Landroidx/compose/ui/node/a;
    .line 287: if-eqz v0, :cond_311
    .line 289: iget-object v0, v0, Landroidx/compose/ui/node/a;->q:Lz0/j1;
    .line 291: if-eqz v0, :cond_311
    .line 293: invoke-interface {v0}, Lz0/j1;->requestFocus()Z
    .line 296: move-result v0
    .line 297: if-eqz v0, :cond_323
    .line 299: sget-object v0, Li0/p;->i:Li0/p;
    .line 301: iput-object v0, v12, Li0/q;->x:Li0/p;
    .line 303: invoke-static {v12}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 306: invoke-static {v12, v13}, Landroidx/compose/ui/focus/a;->E(Li0/q;Li0/q;)Z
    .line 309: move-result v3
    .line 310: goto :goto_420
    .line 311: new-instance v12, Ljava/lang/IllegalStateException;
    .line 313: const-string v13, "Owner not initialized."
    .line 315: invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 318: move-result-object v13
    .line 319: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 322: throw v12
    .line 323: if-eqz v6, :cond_420
    .line 325: invoke-static {v6, v12}, Landroidx/compose/ui/focus/a;->E(Li0/q;Li0/q;)Z
    .line 328: move-result v0
    .line 329: if-eqz v0, :cond_420
    .line 331: invoke-static {v12, v13}, Landroidx/compose/ui/focus/a;->E(Li0/q;Li0/q;)Z
    .line 334: move-result v3
    .line 335: iget-object v12, v12, Li0/q;->x:Li0/p;
    .line 337: if-ne v12, v1, :cond_340
    .line 339: goto :goto_420
    .line 340: new-instance v12, Ljava/lang/IllegalStateException;
    .line 342: const-string v13, "Check failed."
    .line 344: invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 347: move-result-object v13
    .line 348: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 351: throw v12
    .line 352: new-instance v12, Ljava/lang/IllegalStateException;
    .line 354: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 357: move-result-object v13
    .line 358: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 361: throw v12
    .line 362: new-instance v12, Lkotlinx/coroutines/internal/z;
    .line 364: invoke-direct {v12}, Ljava/lang/RuntimeException;-><init>()V
    .line 367: throw v12
    .line 368: invoke-static {v12}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 371: move-result-object v0
    .line 372: if-eqz v0, :cond_396
    .line 374: invoke-static {v12}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 377: move-result-object v12
    .line 378: if-eqz v12, :cond_386
    .line 380: invoke-static {v12, v3, v4}, Landroidx/compose/ui/focus/a;->d(Li0/q;ZZ)Z
    .line 383: move-result v12
    .line 384: if-eqz v12, :cond_390
    .line 386: invoke-static {v13}, Landroidx/compose/ui/focus/a;->q(Li0/q;)V
    .line 389: move v3, v4
    .line 390: if-eqz v3, :cond_420
    .line 392: invoke-static {v13}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 395: goto :goto_420
    .line 396: new-instance v12, Ljava/lang/IllegalStateException;
    .line 398: const-string v13, "Required value was null."
    .line 400: invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 403: move-result-object v13
    .line 404: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 407: throw v12
    .line 408: invoke-static {v13}, Landroidx/compose/ui/focus/a;->q(Li0/q;)V
    .line 411: iput-object v1, v12, Li0/q;->x:Li0/p;
    .line 413: invoke-static {v13}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 416: invoke-static {v12}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 419: move v3, v4
    .line 420: return v3
    .line 421: new-instance v12, Ljava/lang/IllegalStateException;
    .line 423: const-string v13, "Non child node cannot request focus."
    .line 425: invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 428: move-result-object v13
    .line 429: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 432: throw v12
    .line 433: new-instance v12, Ljava/lang/IllegalStateException;
    .line 435: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 438: move-result-object v13
    .line 439: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 442: throw v12
.end method

# direct methods
.method public static final F(Li0/q;Li0/s;)V
    .registers 11

    .line 0: iget-object v10, v9, Lf0/o;->i:Lf0/o;
    .line 2: iget-boolean v0, v10, Lf0/o;->u:Z
    .line 4: if-eqz v0, :cond_165
    .line 6: iget-object v10, v10, Lf0/o;->m:Lf0/o;
    .line 8: invoke-static {v9}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 11: move-result-object v0
    .line 12: const/4 v1, 0
    .line 13: if-eqz v0, :cond_127
    .line 15: iget-object v2, v0, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 17: iget-object v2, v2, Lz0/v0;->e:Lf0/o;
    .line 19: iget v2, v2, Lf0/o;->l:I
    .line 21: and-int/lit16 v2, v2, 1024
    .line 23: if-eqz v2, :cond_112
    .line 25: if-eqz v10, :cond_112
    .line 27: iget v2, v10, Lf0/o;->k:I
    .line 29: and-int/lit16 v2, v2, 1024
    .line 31: if-eqz v2, :cond_109
    .line 33: move-object v2, v10
    .line 34: move-object v3, v1
    .line 35: if-eqz v2, :cond_109
    .line 37: instance-of v4, v2, Li0/q;
    .line 39: if-eqz v4, :cond_42
    .line 41: goto :goto_128
    .line 42: iget v4, v2, Lf0/o;->k:I
    .line 44: and-int/lit16 v4, v4, 1024
    .line 46: if-eqz v4, :cond_104
    .line 48: instance-of v4, v2, Lz0/p;
    .line 50: if-eqz v4, :cond_104
    .line 52: move-object v4, v2
    .line 53: check-cast v4, Lz0/p;
    .line 55: iget-object v4, v4, Lz0/p;->w:Lf0/o;
    .line 57: const/4 v5, 0
    .line 58: move v6, v5
    .line 59: const/4 v7, 1
    .line 60: if-eqz v4, :cond_101
    .line 62: iget v8, v4, Lf0/o;->k:I
    .line 64: and-int/lit16 v8, v8, 1024
    .line 66: if-eqz v8, :cond_98
    .line 68: add-int/lit8 v6, v6, 1
    .line 70: if-ne v6, v7, :cond_74
    .line 72: move-object v2, v4
    .line 73: goto :goto_98
    .line 74: if-nez v3, :cond_89
    .line 76: new-instance v3, Lv/j;
    .line 78: const/16 v7, 16
    .line 80: new-array v7, v7, [Lf0/o;
    .line 82: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 85: iput-object v7, v3, Lv/j;->i:[Ljava/lang/Object;
    .line 87: iput v5, v3, Lv/j;->k:I
    .line 89: if-eqz v2, :cond_95
    .line 91: invoke-virtual {v3, v2}, Lv/j;->b(Ljava/lang/Object;)V
    .line 94: move-object v2, v1
    .line 95: invoke-virtual {v3, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 98: iget-object v4, v4, Lf0/o;->n:Lf0/o;
    .line 100: goto :goto_59
    .line 101: if-ne v6, v7, :cond_104
    .line 103: goto :goto_35
    .line 104: invoke-static {v3}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 107: move-result-object v2
    .line 108: goto :goto_35
    .line 109: iget-object v10, v10, Lf0/o;->m:Lf0/o;
    .line 111: goto :goto_25
    .line 112: invoke-virtual {v0}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 115: move-result-object v0
    .line 116: if-eqz v0, :cond_125
    .line 118: iget-object v10, v0, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 120: if-eqz v10, :cond_125
    .line 122: iget-object v10, v10, Lz0/v0;->d:Lz0/q1;
    .line 124: goto :goto_12
    .line 125: move-object v10, v1
    .line 126: goto :goto_12
    .line 127: move-object v2, v1
    .line 128: check-cast v2, Li0/q;
    .line 130: if-eqz v2, :cond_155
    .line 132: sget-object v10, Lx0/f;->a:Ly0/i;
    .line 134: invoke-interface {v2, v10}, Ly0/f;->a(Ly0/i;)Ljava/lang/Object;
    .line 137: move-result-object v0
    .line 138: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 141: invoke-interface {v9, v10}, Ly0/f;->a(Ly0/i;)Ljava/lang/Object;
    .line 144: move-result-object v10
    .line 145: invoke-static {v10}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 148: invoke-static {v1, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 151: move-result v10
    .line 152: if-eqz v10, :cond_155
    .line 154: return-void
    .line 155: sget-object v10, Lx0/f;->a:Ly0/i;
    .line 157: invoke-interface {v9, v10}, Ly0/f;->a(Ly0/i;)Ljava/lang/Object;
    .line 160: move-result-object v9
    .line 161: invoke-static {v9}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 164: return-void
    .line 165: new-instance v9, Ljava/lang/IllegalStateException;
    .line 167: const-string v10, "visitAncestors called on an unattached node"
    .line 169: invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 172: move-result-object v10
    .line 173: invoke-direct {v9, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 176: throw v9
.end method

# direct methods
.method public static final G(Li0/q;Li0/q;ILd3/c;)Z
    .registers 20

    .line 0: move-object/from16 v0, v16
    .line 2: move-object/from16 v1, v17
    .line 4: move/from16 v2, v18
    .line 6: move-object/from16 v3, v19
    .line 8: iget-object v4, v0, Li0/q;->x:Li0/p;
    .line 10: sget-object v5, Li0/p;->j:Li0/p;
    .line 12: if-ne v4, v5, :cond_483
    .line 14: const/16 v4, 16
    .line 16: new-array v5, v4, [Li0/q;
    .line 18: iget-object v6, v0, Lf0/o;->i:Lf0/o;
    .line 20: iget-boolean v7, v6, Lf0/o;->u:Z
    .line 22: if-eqz v7, :cond_471
    .line 24: new-instance v7, Lv/j;
    .line 26: new-array v8, v4, [Lf0/o;
    .line 28: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 31: iput-object v8, v7, Lv/j;->i:[Ljava/lang/Object;
    .line 33: const/4 v8, 0
    .line 34: iput v8, v7, Lv/j;->k:I
    .line 36: iget-object v9, v6, Lf0/o;->n:Lf0/o;
    .line 38: if-nez v9, :cond_45
    .line 40: invoke-static {v7, v6}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 43: move v6, v8
    .line 44: goto :goto_49
    .line 45: invoke-virtual {v7, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 48: goto :goto_43
    .line 49: invoke-virtual {v7}, Lv/j;->j()Z
    .line 52: move-result v9
    .line 53: const/4 v10, 1
    .line 54: const/4 v11, 2
    .line 55: if-eqz v9, :cond_183
    .line 57: iget v9, v7, Lv/j;->k:I
    .line 59: sub-int/2addr v9, v10
    .line 60: invoke-virtual {v7, v9}, Lv/j;->l(I)Ljava/lang/Object;
    .line 63: move-result-object v9
    .line 64: check-cast v9, Lf0/o;
    .line 66: iget v13, v9, Lf0/o;->l:I
    .line 68: and-int/lit16 v13, v13, 1024
    .line 70: if-nez v13, :cond_76
    .line 72: invoke-static {v7, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 75: goto :goto_49
    .line 76: if-eqz v9, :cond_49
    .line 78: iget v13, v9, Lf0/o;->k:I
    .line 80: and-int/lit16 v13, v13, 1024
    .line 82: if-eqz v13, :cond_180
    .line 84: const/4 v13, 0
    .line 85: if-eqz v9, :cond_49
    .line 87: instance-of v14, v9, Li0/q;
    .line 89: if-eqz v14, :cond_117
    .line 91: check-cast v9, Li0/q;
    .line 93: add-int/lit8 v14, v6, 1
    .line 95: array-length v15, v5
    .line 96: if-ge v15, v14, :cond_113
    .line 98: array-length v15, v5
    .line 99: mul-int/2addr v15, v11
    .line 100: invoke-static {v14, v15}, Ljava/lang/Math;->max(II)I
    .line 103: move-result v15
    .line 104: invoke-static {v5, v15}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 107: move-result-object v5
    .line 108: const-string v15, "copyOf(this, newSize)"
    .line 110: invoke-static {v5, v15}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 113: aput-object v9, v5, v6
    .line 115: move v6, v14
    .line 116: goto :goto_175
    .line 117: iget v14, v9, Lf0/o;->k:I
    .line 119: and-int/lit16 v14, v14, 1024
    .line 121: if-eqz v14, :cond_175
    .line 123: instance-of v14, v9, Lz0/p;
    .line 125: if-eqz v14, :cond_175
    .line 127: move-object v14, v9
    .line 128: check-cast v14, Lz0/p;
    .line 130: iget-object v14, v14, Lz0/p;->w:Lf0/o;
    .line 132: move v15, v8
    .line 133: if-eqz v14, :cond_172
    .line 135: iget v12, v14, Lf0/o;->k:I
    .line 137: and-int/lit16 v12, v12, 1024
    .line 139: if-eqz v12, :cond_169
    .line 141: add-int/lit8 v15, v15, 1
    .line 143: if-ne v15, v10, :cond_147
    .line 145: move-object v9, v14
    .line 146: goto :goto_169
    .line 147: if-nez v13, :cond_160
    .line 149: new-instance v13, Lv/j;
    .line 151: new-array v12, v4, [Lf0/o;
    .line 153: invoke-direct {v13}, Ljava/lang/Object;-><init>()V
    .line 156: iput-object v12, v13, Lv/j;->i:[Ljava/lang/Object;
    .line 158: iput v8, v13, Lv/j;->k:I
    .line 160: if-eqz v9, :cond_166
    .line 162: invoke-virtual {v13, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 165: const/4 v9, 0
    .line 166: invoke-virtual {v13, v14}, Lv/j;->b(Ljava/lang/Object;)V
    .line 169: iget-object v14, v14, Lf0/o;->n:Lf0/o;
    .line 171: goto :goto_133
    .line 172: if-ne v15, v10, :cond_175
    .line 174: goto :goto_85
    .line 175: invoke-static {v13}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 178: move-result-object v9
    .line 179: goto :goto_85
    .line 180: iget-object v9, v9, Lf0/o;->n:Lf0/o;
    .line 182: goto :goto_76
    .line 183: sget-object v7, Li0/r;->a:Li0/r;
    .line 185: const-string v9, "<this>"
    .line 187: invoke-static {v5, v9}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 190: invoke-static {v5, v8, v6, v7}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V
    .line 193: invoke-static {v2, v10}, Li0/b;->a(II)Z
    .line 196: move-result v7
    .line 197: if-eqz v7, :cond_244
    .line 199: new-instance v7, Lj3/d;
    .line 201: sub-int/2addr v6, v10
    .line 202: invoke-direct {v7, v8, v6, v10}, Lj3/b;-><init>(III)V
    .line 205: iget v6, v7, Lj3/b;->j:I
    .line 207: if-ltz v6, :cond_294
    .line 209: move v7, v8
    .line 210: move v9, v7
    .line 211: if-eqz v7, :cond_230
    .line 213: aget-object v11, v5, v9
    .line 215: check-cast v11, Li0/q;
    .line 217: invoke-static {v11}, Landroidx/compose/ui/focus/a;->u(Li0/q;)Z
    .line 220: move-result v12
    .line 221: if-eqz v12, :cond_230
    .line 223: invoke-static {v11, v3}, Landroidx/compose/ui/focus/a;->l(Li0/q;Ld3/c;)Z
    .line 226: move-result v11
    .line 227: if-eqz v11, :cond_230
    .line 229: return v10
    .line 230: aget-object v11, v5, v9
    .line 232: invoke-static {v11, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 235: move-result v11
    .line 236: if-eqz v11, :cond_239
    .line 238: move v7, v10
    .line 239: if-eq v9, v6, :cond_294
    .line 241: add-int/lit8 v9, v9, 1
    .line 243: goto :goto_211
    .line 244: invoke-static {v2, v11}, Li0/b;->a(II)Z
    .line 247: move-result v7
    .line 248: if-eqz v7, :cond_459
    .line 250: new-instance v7, Lj3/d;
    .line 252: sub-int/2addr v6, v10
    .line 253: invoke-direct {v7, v8, v6, v10}, Lj3/b;-><init>(III)V
    .line 256: iget v6, v7, Lj3/b;->j:I
    .line 258: if-ltz v6, :cond_294
    .line 260: move v7, v8
    .line 261: if-eqz v7, :cond_280
    .line 263: aget-object v9, v5, v6
    .line 265: check-cast v9, Li0/q;
    .line 267: invoke-static {v9}, Landroidx/compose/ui/focus/a;->u(Li0/q;)Z
    .line 270: move-result v11
    .line 271: if-eqz v11, :cond_280
    .line 273: invoke-static {v9, v3}, Landroidx/compose/ui/focus/a;->a(Li0/q;Ld3/c;)Z
    .line 276: move-result v9
    .line 277: if-eqz v9, :cond_280
    .line 279: return v10
    .line 280: aget-object v9, v5, v6
    .line 282: invoke-static {v9, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 285: move-result v9
    .line 286: if-eqz v9, :cond_289
    .line 288: move v7, v10
    .line 289: if-eqz v6, :cond_294
    .line 291: add-int/lit8 v6, v6, -1
    .line 293: goto :goto_261
    .line 294: invoke-static {v2, v10}, Li0/b;->a(II)Z
    .line 297: move-result v1
    .line 298: if-nez v1, :cond_458
    .line 300: invoke-virtual/range {v16 .. v16}, Li0/q;->D0()Li0/i;
    .line 303: move-result-object v1
    .line 304: iget-boolean v1, v1, Li0/i;->a:Z
    .line 306: if-eqz v1, :cond_458
    .line 308: iget-object v1, v0, Lf0/o;->i:Lf0/o;
    .line 310: iget-boolean v2, v1, Lf0/o;->u:Z
    .line 312: if-eqz v2, :cond_446
    .line 314: iget-object v1, v1, Lf0/o;->m:Lf0/o;
    .line 316: invoke-static/range {v16 .. v16}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 319: move-result-object v2
    .line 320: if-eqz v2, :cond_431
    .line 322: iget-object v5, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 324: iget-object v5, v5, Lz0/v0;->e:Lf0/o;
    .line 326: iget v5, v5, Lf0/o;->l:I
    .line 328: and-int/lit16 v5, v5, 1024
    .line 330: if-eqz v5, :cond_416
    .line 332: if-eqz v1, :cond_416
    .line 334: iget v5, v1, Lf0/o;->k:I
    .line 336: and-int/lit16 v5, v5, 1024
    .line 338: if-eqz v5, :cond_413
    .line 340: move-object v5, v1
    .line 341: const/4 v6, 0
    .line 342: if-eqz v5, :cond_413
    .line 344: instance-of v7, v5, Li0/q;
    .line 346: if-eqz v7, :cond_350
    .line 348: move-object v12, v5
    .line 349: goto :goto_432
    .line 350: iget v7, v5, Lf0/o;->k:I
    .line 352: and-int/lit16 v7, v7, 1024
    .line 354: if-eqz v7, :cond_408
    .line 356: instance-of v7, v5, Lz0/p;
    .line 358: if-eqz v7, :cond_408
    .line 360: move-object v7, v5
    .line 361: check-cast v7, Lz0/p;
    .line 363: iget-object v7, v7, Lz0/p;->w:Lf0/o;
    .line 365: move v9, v8
    .line 366: if-eqz v7, :cond_405
    .line 368: iget v11, v7, Lf0/o;->k:I
    .line 370: and-int/lit16 v11, v11, 1024
    .line 372: if-eqz v11, :cond_402
    .line 374: add-int/lit8 v9, v9, 1
    .line 376: if-ne v9, v10, :cond_380
    .line 378: move-object v5, v7
    .line 379: goto :goto_402
    .line 380: if-nez v6, :cond_393
    .line 382: new-instance v6, Lv/j;
    .line 384: new-array v11, v4, [Lf0/o;
    .line 386: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 389: iput-object v11, v6, Lv/j;->i:[Ljava/lang/Object;
    .line 391: iput v8, v6, Lv/j;->k:I
    .line 393: if-eqz v5, :cond_399
    .line 395: invoke-virtual {v6, v5}, Lv/j;->b(Ljava/lang/Object;)V
    .line 398: const/4 v5, 0
    .line 399: invoke-virtual {v6, v7}, Lv/j;->b(Ljava/lang/Object;)V
    .line 402: iget-object v7, v7, Lf0/o;->n:Lf0/o;
    .line 404: goto :goto_366
    .line 405: if-ne v9, v10, :cond_408
    .line 407: goto :goto_342
    .line 408: invoke-static {v6}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 411: move-result-object v5
    .line 412: goto :goto_342
    .line 413: iget-object v1, v1, Lf0/o;->m:Lf0/o;
    .line 415: goto :goto_332
    .line 416: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 419: move-result-object v2
    .line 420: if-eqz v2, :cond_429
    .line 422: iget-object v1, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 424: if-eqz v1, :cond_429
    .line 426: iget-object v1, v1, Lz0/v0;->d:Lz0/q1;
    .line 428: goto :goto_320
    .line 429: const/4 v1, 0
    .line 430: goto :goto_320
    .line 431: const/4 v12, 0
    .line 432: if-nez v12, :cond_435
    .line 434: goto :goto_458
    .line 435: invoke-interface {v3, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 438: move-result-object v0
    .line 439: check-cast v0, Ljava/lang/Boolean;
    .line 441: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 444: move-result v0
    .line 445: return v0
    .line 446: new-instance v0, Ljava/lang/IllegalStateException;
    .line 448: const-string v1, "visitAncestors called on an unattached node"
    .line 450: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 453: move-result-object v1
    .line 454: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 457: throw v0
    .line 458: return v8
    .line 459: new-instance v0, Ljava/lang/IllegalStateException;
    .line 461: const-string v1, "This function should only be used for 1-D focus search"
    .line 463: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 466: move-result-object v1
    .line 467: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 470: throw v0
    .line 471: new-instance v0, Ljava/lang/IllegalStateException;
    .line 473: const-string v1, "visitChildren called on an unattached node"
    .line 475: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 478: move-result-object v1
    .line 479: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 482: throw v0
    .line 483: new-instance v0, Ljava/lang/IllegalStateException;
    .line 485: const-string v1, "This function should only be used within a parent that has focus."
    .line 487: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 490: move-result-object v1
    .line 491: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 494: throw v0
.end method

# direct methods
.method public static final H(Li0/q;Li0/q;ILd3/c;)Z
    .registers 14

    .line 0: new-instance v0, Lv/j;
    .line 2: const/16 v1, 16
    .line 4: new-array v2, v1, [Li0/q;
    .line 6: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 9: iput-object v2, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 11: const/4 v2, 0
    .line 12: iput v2, v0, Lv/j;->k:I
    .line 14: iget-object v10, v10, Lf0/o;->i:Lf0/o;
    .line 16: iget-boolean v3, v10, Lf0/o;->u:Z
    .line 18: if-eqz v3, :cond_204
    .line 20: new-instance v3, Lv/j;
    .line 22: new-array v4, v1, [Lf0/o;
    .line 24: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 27: iput-object v4, v3, Lv/j;->i:[Ljava/lang/Object;
    .line 29: iput v2, v3, Lv/j;->k:I
    .line 31: iget-object v4, v10, Lf0/o;->n:Lf0/o;
    .line 33: if-nez v4, :cond_39
    .line 35: invoke-static {v3, v10}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 38: goto :goto_42
    .line 39: invoke-virtual {v3, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 42: invoke-virtual {v3}, Lv/j;->j()Z
    .line 45: move-result v10
    .line 46: const/4 v4, 1
    .line 47: if-eqz v10, :cond_156
    .line 49: iget v10, v3, Lv/j;->k:I
    .line 51: sub-int/2addr v10, v4
    .line 52: invoke-virtual {v3, v10}, Lv/j;->l(I)Ljava/lang/Object;
    .line 55: move-result-object v10
    .line 56: check-cast v10, Lf0/o;
    .line 58: iget v5, v10, Lf0/o;->l:I
    .line 60: and-int/lit16 v5, v5, 1024
    .line 62: if-nez v5, :cond_68
    .line 64: invoke-static {v3, v10}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 67: goto :goto_42
    .line 68: if-eqz v10, :cond_42
    .line 70: iget v5, v10, Lf0/o;->k:I
    .line 72: and-int/lit16 v5, v5, 1024
    .line 74: if-eqz v5, :cond_153
    .line 76: const/4 v5, 0
    .line 77: move-object v6, v5
    .line 78: if-eqz v10, :cond_42
    .line 80: instance-of v7, v10, Li0/q;
    .line 82: if-eqz v7, :cond_90
    .line 84: check-cast v10, Li0/q;
    .line 86: invoke-virtual {v0, v10}, Lv/j;->b(Ljava/lang/Object;)V
    .line 89: goto :goto_148
    .line 90: iget v7, v10, Lf0/o;->k:I
    .line 92: and-int/lit16 v7, v7, 1024
    .line 94: if-eqz v7, :cond_148
    .line 96: instance-of v7, v10, Lz0/p;
    .line 98: if-eqz v7, :cond_148
    .line 100: move-object v7, v10
    .line 101: check-cast v7, Lz0/p;
    .line 103: iget-object v7, v7, Lz0/p;->w:Lf0/o;
    .line 105: move v8, v2
    .line 106: if-eqz v7, :cond_145
    .line 108: iget v9, v7, Lf0/o;->k:I
    .line 110: and-int/lit16 v9, v9, 1024
    .line 112: if-eqz v9, :cond_142
    .line 114: add-int/lit8 v8, v8, 1
    .line 116: if-ne v8, v4, :cond_120
    .line 118: move-object v10, v7
    .line 119: goto :goto_142
    .line 120: if-nez v6, :cond_133
    .line 122: new-instance v6, Lv/j;
    .line 124: new-array v9, v1, [Lf0/o;
    .line 126: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 129: iput-object v9, v6, Lv/j;->i:[Ljava/lang/Object;
    .line 131: iput v2, v6, Lv/j;->k:I
    .line 133: if-eqz v10, :cond_139
    .line 135: invoke-virtual {v6, v10}, Lv/j;->b(Ljava/lang/Object;)V
    .line 138: move-object v10, v5
    .line 139: invoke-virtual {v6, v7}, Lv/j;->b(Ljava/lang/Object;)V
    .line 142: iget-object v7, v7, Lf0/o;->n:Lf0/o;
    .line 144: goto :goto_106
    .line 145: if-ne v8, v4, :cond_148
    .line 147: goto :goto_78
    .line 148: invoke-static {v6}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 151: move-result-object v10
    .line 152: goto :goto_78
    .line 153: iget-object v10, v10, Lf0/o;->n:Lf0/o;
    .line 155: goto :goto_68
    .line 156: invoke-virtual {v0}, Lv/j;->j()Z
    .line 159: move-result v10
    .line 160: if-eqz v10, :cond_203
    .line 162: invoke-static {v11}, Landroidx/compose/ui/focus/a;->j(Li0/q;)Lj0/d;
    .line 165: move-result-object v10
    .line 166: invoke-static {v0, v10, v12}, Landroidx/compose/ui/focus/a;->g(Lv/j;Lj0/d;I)Li0/q;
    .line 169: move-result-object v10
    .line 170: if-nez v10, :cond_173
    .line 172: return v2
    .line 173: invoke-virtual {v10}, Li0/q;->D0()Li0/i;
    .line 176: move-result-object v1
    .line 177: iget-boolean v1, v1, Li0/i;->a:Z
    .line 179: if-eqz v1, :cond_192
    .line 181: invoke-interface {v13, v10}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 184: move-result-object v10
    .line 185: check-cast v10, Ljava/lang/Boolean;
    .line 187: invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z
    .line 190: move-result v10
    .line 191: return v10
    .line 192: invoke-static {v10, v11, v12, v13}, Landroidx/compose/ui/focus/a;->n(Li0/q;Li0/q;ILd3/c;)Z
    .line 195: move-result v1
    .line 196: if-eqz v1, :cond_199
    .line 198: return v4
    .line 199: invoke-virtual {v0, v10}, Lv/j;->k(Ljava/lang/Object;)Z
    .line 202: goto :goto_156
    .line 203: return v2
    .line 204: new-instance v10, Ljava/lang/IllegalStateException;
    .line 206: const-string v11, "visitChildren called on an unattached node"
    .line 208: invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 211: move-result-object v11
    .line 212: invoke-direct {v10, v11}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 215: throw v10
.end method

# direct methods
.method public static final I(Li0/q;ILi/r2;)Ljava/lang/Boolean;
    .registers 9

    .line 0: iget-object v0, v6, Li0/q;->x:Li0/p;
    .line 2: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_154
    .line 8: const/4 v1, 3
    .line 9: const/4 v2, 2
    .line 10: const/4 v3, 1
    .line 11: if-eq v0, v3, :cond_41
    .line 13: if-eq v0, v2, :cond_154
    .line 15: if-ne v0, v1, :cond_35
    .line 17: invoke-virtual {v6}, Li0/q;->D0()Li0/i;
    .line 20: move-result-object v7
    .line 21: iget-boolean v7, v7, Li0/i;->a:Z
    .line 23: if-eqz v7, :cond_32
    .line 25: invoke-virtual {v8, v6}, Li/r2;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 28: move-result-object v6
    .line 29: check-cast v6, Ljava/lang/Boolean;
    .line 31: goto :goto_34
    .line 32: sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 34: return-object v6
    .line 35: new-instance v6, Lkotlinx/coroutines/internal/z;
    .line 37: invoke-direct {v6}, Ljava/lang/RuntimeException;-><init>()V
    .line 40: throw v6
    .line 41: invoke-static {v6}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 44: move-result-object v0
    .line 45: const-string v4, "ActiveParent must have a focusedChild"
    .line 47: if-eqz v0, :cond_144
    .line 49: iget-object v5, v0, Li0/q;->x:Li0/p;
    .line 51: invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I
    .line 54: move-result v5
    .line 55: if-eqz v5, :cond_135
    .line 57: if-eq v5, v3, :cond_79
    .line 59: if-eq v5, v2, :cond_135
    .line 61: if-eq v5, v1, :cond_69
    .line 63: new-instance v6, Lkotlinx/coroutines/internal/z;
    .line 65: invoke-direct {v6}, Ljava/lang/RuntimeException;-><init>()V
    .line 68: throw v6
    .line 69: new-instance v6, Ljava/lang/IllegalStateException;
    .line 71: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 74: move-result-object v7
    .line 75: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 78: throw v6
    .line 79: invoke-static {v0, v7, v8}, Landroidx/compose/ui/focus/a;->I(Li0/q;ILi/r2;)Ljava/lang/Boolean;
    .line 82: move-result-object v1
    .line 83: sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 85: invoke-static {v1, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 88: move-result v2
    .line 89: if-nez v2, :cond_92
    .line 91: return-object v1
    .line 92: iget-object v1, v0, Li0/q;->x:Li0/p;
    .line 94: sget-object v2, Li0/p;->j:Li0/p;
    .line 96: if-ne v1, v2, :cond_123
    .line 98: invoke-static {v0}, Landroidx/compose/ui/focus/a;->f(Li0/q;)Li0/q;
    .line 101: move-result-object v0
    .line 102: if-eqz v0, :cond_113
    .line 104: invoke-static {v6, v0, v7, v8}, Landroidx/compose/ui/focus/a;->n(Li0/q;Li0/q;ILd3/c;)Z
    .line 107: move-result v6
    .line 108: invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 111: move-result-object v6
    .line 112: return-object v6
    .line 113: new-instance v6, Ljava/lang/IllegalStateException;
    .line 115: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 118: move-result-object v7
    .line 119: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 122: throw v6
    .line 123: new-instance v6, Ljava/lang/IllegalStateException;
    .line 125: const-string v7, "Check failed."
    .line 127: invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 130: move-result-object v7
    .line 131: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 134: throw v6
    .line 135: invoke-static {v6, v0, v7, v8}, Landroidx/compose/ui/focus/a;->n(Li0/q;Li0/q;ILd3/c;)Z
    .line 138: move-result v6
    .line 139: invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 142: move-result-object v6
    .line 143: return-object v6
    .line 144: new-instance v6, Ljava/lang/IllegalStateException;
    .line 146: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 149: move-result-object v7
    .line 150: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 153: throw v6
    .line 154: invoke-static {v6, v7, v8}, Landroidx/compose/ui/focus/a;->h(Li0/q;ILd3/c;)Z
    .line 157: move-result v6
    .line 158: invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 161: move-result-object v6
    .line 162: return-object v6
.end method

# direct methods
.method public static final a(Li0/q;Ld3/c;)Z
    .registers 9

    .line 0: iget-object v0, v7, Li0/q;->x:Li0/p;
    .line 2: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_138
    .line 8: const/4 v1, 0
    .line 9: const/4 v2, 3
    .line 10: const/4 v3, 2
    .line 11: const/4 v4, 1
    .line 12: if-eq v0, v4, :cond_52
    .line 14: if-eq v0, v3, :cond_138
    .line 16: if-ne v0, v2, :cond_46
    .line 18: invoke-static {v7, v8}, Landroidx/compose/ui/focus/a;->A(Li0/q;Ld3/c;)Z
    .line 21: move-result v0
    .line 22: if-nez v0, :cond_44
    .line 24: invoke-virtual {v7}, Li0/q;->D0()Li0/i;
    .line 27: move-result-object v0
    .line 28: iget-boolean v0, v0, Li0/i;->a:Z
    .line 30: if-eqz v0, :cond_142
    .line 32: invoke-interface {v8, v7}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 35: move-result-object v7
    .line 36: check-cast v7, Ljava/lang/Boolean;
    .line 38: invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z
    .line 41: move-result v7
    .line 42: if-eqz v7, :cond_142
    .line 44: move v1, v4
    .line 45: goto :goto_142
    .line 46: new-instance v7, Lkotlinx/coroutines/internal/z;
    .line 48: invoke-direct {v7}, Ljava/lang/RuntimeException;-><init>()V
    .line 51: throw v7
    .line 52: invoke-static {v7}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 55: move-result-object v0
    .line 56: const-string v5, "ActiveParent must have a focusedChild"
    .line 58: if-eqz v0, :cond_128
    .line 60: iget-object v6, v0, Li0/q;->x:Li0/p;
    .line 62: invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I
    .line 65: move-result v6
    .line 66: if-eqz v6, :cond_123
    .line 68: if-eq v6, v4, :cond_90
    .line 70: if-eq v6, v3, :cond_123
    .line 72: if-eq v6, v2, :cond_80
    .line 74: new-instance v7, Lkotlinx/coroutines/internal/z;
    .line 76: invoke-direct {v7}, Ljava/lang/RuntimeException;-><init>()V
    .line 79: throw v7
    .line 80: new-instance v7, Ljava/lang/IllegalStateException;
    .line 82: invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 85: move-result-object v8
    .line 86: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 89: throw v7
    .line 90: invoke-static {v0, v8}, Landroidx/compose/ui/focus/a;->a(Li0/q;Ld3/c;)Z
    .line 93: move-result v2
    .line 94: if-nez v2, :cond_44
    .line 96: invoke-static {v7, v0, v3, v8}, Landroidx/compose/ui/focus/a;->m(Li0/q;Li0/q;ILd3/c;)Z
    .line 99: move-result v7
    .line 100: if-nez v7, :cond_44
    .line 102: invoke-virtual {v0}, Li0/q;->D0()Li0/i;
    .line 105: move-result-object v7
    .line 106: iget-boolean v7, v7, Li0/i;->a:Z
    .line 108: if-eqz v7, :cond_142
    .line 110: invoke-interface {v8, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 113: move-result-object v7
    .line 114: check-cast v7, Ljava/lang/Boolean;
    .line 116: invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z
    .line 119: move-result v7
    .line 120: if-eqz v7, :cond_142
    .line 122: goto :goto_44
    .line 123: invoke-static {v7, v0, v3, v8}, Landroidx/compose/ui/focus/a;->m(Li0/q;Li0/q;ILd3/c;)Z
    .line 126: move-result v1
    .line 127: goto :goto_142
    .line 128: new-instance v7, Ljava/lang/IllegalStateException;
    .line 130: invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 133: move-result-object v8
    .line 134: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 137: throw v7
    .line 138: invoke-static {v7, v8}, Landroidx/compose/ui/focus/a;->A(Li0/q;Ld3/c;)Z
    .line 141: move-result v1
    .line 142: return v1
.end method

# direct methods
.method public static final b(Lj0/d;Lj0/d;Lj0/d;I)Z
    .registers 20

    .line 0: move-object/from16 v0, v16
    .line 2: move-object/from16 v1, v17
    .line 4: move-object/from16 v2, v18
    .line 6: move/from16 v3, v19
    .line 8: invoke-static {v3, v2, v0}, Landroidx/compose/ui/focus/a;->c(ILj0/d;Lj0/d;)Z
    .line 11: move-result v4
    .line 12: if-nez v4, :cond_192
    .line 14: invoke-static {v3, v1, v0}, Landroidx/compose/ui/focus/a;->c(ILj0/d;Lj0/d;)Z
    .line 17: move-result v4
    .line 18: if-nez v4, :cond_22
    .line 20: goto/16 :goto_192
    .line 22: const/4 v4, 3
    .line 23: invoke-static {v3, v4}, Li0/b;->a(II)Z
    .line 26: move-result v6
    .line 27: const-string v8, "This function should only be used for 2-D focus search"
    .line 29: const/4 v9, 6
    .line 30: const/4 v10, 5
    .line 31: const/4 v11, 4
    .line 32: iget v12, v2, Lj0/d;->b:F
    .line 34: iget v13, v2, Lj0/d;->d:F
    .line 36: iget v14, v2, Lj0/d;->a:F
    .line 38: iget v2, v2, Lj0/d;->c:F
    .line 40: iget v15, v0, Lj0/d;->d:F
    .line 42: iget v5, v0, Lj0/d;->b:F
    .line 44: iget v7, v0, Lj0/d;->c:F
    .line 46: iget v0, v0, Lj0/d;->a:F
    .line 48: if-eqz v6, :cond_55
    .line 50: cmpl-float v6, v0, v2
    .line 52: if-ltz v6, :cond_190
    .line 54: goto :goto_87
    .line 55: invoke-static {v3, v11}, Li0/b;->a(II)Z
    .line 58: move-result v6
    .line 59: if-eqz v6, :cond_66
    .line 61: cmpg-float v6, v7, v14
    .line 63: if-gtz v6, :cond_190
    .line 65: goto :goto_87
    .line 66: invoke-static {v3, v10}, Li0/b;->a(II)Z
    .line 69: move-result v6
    .line 70: if-eqz v6, :cond_77
    .line 72: cmpl-float v6, v5, v13
    .line 74: if-ltz v6, :cond_190
    .line 76: goto :goto_87
    .line 77: invoke-static {v3, v9}, Li0/b;->a(II)Z
    .line 80: move-result v6
    .line 81: if-eqz v6, :cond_214
    .line 83: cmpg-float v6, v15, v12
    .line 85: if-gtz v6, :cond_190
    .line 87: invoke-static {v3, v4}, Li0/b;->a(II)Z
    .line 90: move-result v6
    .line 91: if-nez v6, :cond_190
    .line 93: invoke-static {v3, v11}, Li0/b;->a(II)Z
    .line 96: move-result v6
    .line 97: if-eqz v6, :cond_100
    .line 99: goto :goto_190
    .line 100: invoke-static {v3, v4}, Li0/b;->a(II)Z
    .line 103: move-result v6
    .line 104: if-eqz v6, :cond_111
    .line 106: iget v1, v1, Lj0/d;->c:F
    .line 108: sub-float v1, v0, v1
    .line 110: goto :goto_141
    .line 111: invoke-static {v3, v11}, Li0/b;->a(II)Z
    .line 114: move-result v6
    .line 115: if-eqz v6, :cond_121
    .line 117: iget v1, v1, Lj0/d;->a:F
    .line 119: sub-float/2addr v1, v7
    .line 120: goto :goto_141
    .line 121: invoke-static {v3, v10}, Li0/b;->a(II)Z
    .line 124: move-result v6
    .line 125: if-eqz v6, :cond_132
    .line 127: iget v1, v1, Lj0/d;->d:F
    .line 129: sub-float v1, v5, v1
    .line 131: goto :goto_141
    .line 132: invoke-static {v3, v9}, Li0/b;->a(II)Z
    .line 135: move-result v6
    .line 136: if-eqz v6, :cond_204
    .line 138: iget v1, v1, Lj0/d;->b:F
    .line 140: sub-float/2addr v1, v15
    .line 141: const/4 v6, 0
    .line 142: invoke-static {v6, v1}, Ljava/lang/Math;->max(FF)F
    .line 145: move-result v1
    .line 146: invoke-static {v3, v4}, Li0/b;->a(II)Z
    .line 149: move-result v4
    .line 150: if-eqz v4, :cond_154
    .line 152: sub-float/2addr v0, v14
    .line 153: goto :goto_180
    .line 154: invoke-static {v3, v11}, Li0/b;->a(II)Z
    .line 157: move-result v0
    .line 158: if-eqz v0, :cond_163
    .line 160: sub-float v0, v2, v7
    .line 162: goto :goto_180
    .line 163: invoke-static {v3, v10}, Li0/b;->a(II)Z
    .line 166: move-result v0
    .line 167: if-eqz v0, :cond_172
    .line 169: sub-float v0, v5, v12
    .line 171: goto :goto_180
    .line 172: invoke-static {v3, v9}, Li0/b;->a(II)Z
    .line 175: move-result v0
    .line 176: if-eqz v0, :cond_194
    .line 178: sub-float v0, v13, v15
    .line 180: const/high16 v2, 0x3f80
    .line 182: invoke-static {v2, v0}, Ljava/lang/Math;->max(FF)F
    .line 185: move-result v0
    .line 186: cmpg-float v0, v1, v0
    .line 188: if-gez v0, :cond_192
    .line 190: const/4 v5, 1
    .line 191: goto :goto_224
    .line 192: const/4 v5, 0
    .line 193: goto :goto_224
    .line 194: new-instance v0, Ljava/lang/IllegalStateException;
    .line 196: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 199: move-result-object v1
    .line 200: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 203: throw v0
    .line 204: new-instance v0, Ljava/lang/IllegalStateException;
    .line 206: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 209: move-result-object v1
    .line 210: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 213: throw v0
    .line 214: new-instance v0, Ljava/lang/IllegalStateException;
    .line 216: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 219: move-result-object v1
    .line 220: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 223: throw v0
    .line 224: return v5
.end method

# direct methods
.method public static final c(ILj0/d;Lj0/d;)Z
    .registers 6

    .line 0: const/4 v0, 3
    .line 1: invoke-static {v3, v0}, Li0/b;->a(II)Z
    .line 4: move-result v0
    .line 5: const/4 v1, 0
    .line 6: const/4 v2, 1
    .line 7: if-eqz v0, :cond_10
    .line 9: goto :goto_17
    .line 10: const/4 v0, 4
    .line 11: invoke-static {v3, v0}, Li0/b;->a(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_35
    .line 17: iget v3, v4, Lj0/d;->d:F
    .line 19: iget v0, v5, Lj0/d;->b:F
    .line 21: cmpl-float v3, v3, v0
    .line 23: if-lez v3, :cond_67
    .line 25: iget v3, v4, Lj0/d;->b:F
    .line 27: iget v4, v5, Lj0/d;->d:F
    .line 29: cmpg-float v3, v3, v4
    .line 31: if-gez v3, :cond_67
    .line 33: move v1, v2
    .line 34: goto :goto_67
    .line 35: const/4 v0, 5
    .line 36: invoke-static {v3, v0}, Li0/b;->a(II)Z
    .line 39: move-result v0
    .line 40: if-eqz v0, :cond_43
    .line 42: goto :goto_50
    .line 43: const/4 v0, 6
    .line 44: invoke-static {v3, v0}, Li0/b;->a(II)Z
    .line 47: move-result v3
    .line 48: if-eqz v3, :cond_68
    .line 50: iget v3, v4, Lj0/d;->c:F
    .line 52: iget v0, v5, Lj0/d;->a:F
    .line 54: cmpl-float v3, v3, v0
    .line 56: if-lez v3, :cond_67
    .line 58: iget v3, v4, Lj0/d;->a:F
    .line 60: iget v4, v5, Lj0/d;->c:F
    .line 62: cmpg-float v3, v3, v4
    .line 64: if-gez v3, :cond_67
    .line 66: goto :goto_33
    .line 67: return v1
    .line 68: new-instance v3, Ljava/lang/IllegalStateException;
    .line 70: const-string v4, "This function should only be used for 2-D focus search"
    .line 72: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 75: move-result-object v4
    .line 76: invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 79: throw v3
.end method

# direct methods
.method public static final d(Li0/q;ZZ)Z
    .registers 7

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v4, Li0/q;->x:Li0/p;
    .line 7: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 10: move-result v0
    .line 11: sget-object v1, Li0/p;->k:Li0/p;
    .line 13: const/4 v2, 1
    .line 14: if-eqz v0, :cond_65
    .line 16: if-eq v0, v2, :cond_42
    .line 18: const/4 v3, 2
    .line 19: if-eq v0, v3, :cond_32
    .line 21: const/4 v4, 3
    .line 22: if-ne v0, v4, :cond_26
    .line 24: move v5, v2
    .line 25: goto :goto_73
    .line 26: new-instance v4, Lkotlinx/coroutines/internal/z;
    .line 28: invoke-direct {v4}, Ljava/lang/RuntimeException;-><init>()V
    .line 31: throw v4
    .line 32: if-eqz v5, :cond_73
    .line 34: iput-object v1, v4, Li0/q;->x:Li0/p;
    .line 36: if-eqz v6, :cond_73
    .line 38: invoke-static {v4}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 41: goto :goto_73
    .line 42: invoke-static {v4}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 45: move-result-object v0
    .line 46: if-eqz v0, :cond_57
    .line 48: invoke-static {v0, v5, v6}, Landroidx/compose/ui/focus/a;->d(Li0/q;ZZ)Z
    .line 51: move-result v5
    .line 52: if-eqz v5, :cond_55
    .line 54: goto :goto_57
    .line 55: const/4 v5, 0
    .line 56: goto :goto_73
    .line 57: iput-object v1, v4, Li0/q;->x:Li0/p;
    .line 59: if-eqz v6, :cond_24
    .line 61: invoke-static {v4}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 64: goto :goto_24
    .line 65: iput-object v1, v4, Li0/q;->x:Li0/p;
    .line 67: if-eqz v6, :cond_24
    .line 69: invoke-static {v4}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 72: goto :goto_24
    .line 73: return v5
.end method

# direct methods
.method public static final e(Lz0/o;Lv/j;)V
    .registers 11

    .line 0: check-cast v9, Lf0/o;
    .line 2: iget-object v9, v9, Lf0/o;->i:Lf0/o;
    .line 4: iget-boolean v0, v9, Lf0/o;->u:Z
    .line 6: if-eqz v0, :cond_164
    .line 8: new-instance v0, Lv/j;
    .line 10: const/16 v1, 16
    .line 12: new-array v2, v1, [Lf0/o;
    .line 14: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 17: iput-object v2, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 19: const/4 v2, 0
    .line 20: iput v2, v0, Lv/j;->k:I
    .line 22: iget-object v3, v9, Lf0/o;->n:Lf0/o;
    .line 24: if-nez v3, :cond_30
    .line 26: invoke-static {v0, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 29: goto :goto_33
    .line 30: invoke-virtual {v0, v3}, Lv/j;->b(Ljava/lang/Object;)V
    .line 33: invoke-virtual {v0}, Lv/j;->j()Z
    .line 36: move-result v9
    .line 37: if-eqz v9, :cond_163
    .line 39: iget v9, v0, Lv/j;->k:I
    .line 41: const/4 v3, 1
    .line 42: sub-int/2addr v9, v3
    .line 43: invoke-virtual {v0, v9}, Lv/j;->l(I)Ljava/lang/Object;
    .line 46: move-result-object v9
    .line 47: check-cast v9, Lf0/o;
    .line 49: iget v4, v9, Lf0/o;->l:I
    .line 51: and-int/lit16 v4, v4, 1024
    .line 53: if-nez v4, :cond_59
    .line 55: invoke-static {v0, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 58: goto :goto_33
    .line 59: if-eqz v9, :cond_33
    .line 61: iget v4, v9, Lf0/o;->k:I
    .line 63: and-int/lit16 v4, v4, 1024
    .line 65: if-eqz v4, :cond_160
    .line 67: const/4 v4, 0
    .line 68: move-object v5, v4
    .line 69: if-eqz v9, :cond_33
    .line 71: instance-of v6, v9, Li0/q;
    .line 73: if-eqz v6, :cond_97
    .line 75: check-cast v9, Li0/q;
    .line 77: iget-boolean v6, v9, Lf0/o;->u:Z
    .line 79: if-eqz v6, :cond_155
    .line 81: invoke-virtual {v9}, Li0/q;->D0()Li0/i;
    .line 84: move-result-object v6
    .line 85: iget-boolean v6, v6, Li0/i;->a:Z
    .line 87: if-eqz v6, :cond_93
    .line 89: invoke-virtual {v10, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 92: goto :goto_155
    .line 93: invoke-static {v9, v10}, Landroidx/compose/ui/focus/a;->e(Lz0/o;Lv/j;)V
    .line 96: goto :goto_155
    .line 97: iget v6, v9, Lf0/o;->k:I
    .line 99: and-int/lit16 v6, v6, 1024
    .line 101: if-eqz v6, :cond_155
    .line 103: instance-of v6, v9, Lz0/p;
    .line 105: if-eqz v6, :cond_155
    .line 107: move-object v6, v9
    .line 108: check-cast v6, Lz0/p;
    .line 110: iget-object v6, v6, Lz0/p;->w:Lf0/o;
    .line 112: move v7, v2
    .line 113: if-eqz v6, :cond_152
    .line 115: iget v8, v6, Lf0/o;->k:I
    .line 117: and-int/lit16 v8, v8, 1024
    .line 119: if-eqz v8, :cond_149
    .line 121: add-int/lit8 v7, v7, 1
    .line 123: if-ne v7, v3, :cond_127
    .line 125: move-object v9, v6
    .line 126: goto :goto_149
    .line 127: if-nez v5, :cond_140
    .line 129: new-instance v5, Lv/j;
    .line 131: new-array v8, v1, [Lf0/o;
    .line 133: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 136: iput-object v8, v5, Lv/j;->i:[Ljava/lang/Object;
    .line 138: iput v2, v5, Lv/j;->k:I
    .line 140: if-eqz v9, :cond_146
    .line 142: invoke-virtual {v5, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 145: move-object v9, v4
    .line 146: invoke-virtual {v5, v6}, Lv/j;->b(Ljava/lang/Object;)V
    .line 149: iget-object v6, v6, Lf0/o;->n:Lf0/o;
    .line 151: goto :goto_113
    .line 152: if-ne v7, v3, :cond_155
    .line 154: goto :goto_69
    .line 155: invoke-static {v5}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 158: move-result-object v9
    .line 159: goto :goto_69
    .line 160: iget-object v9, v9, Lf0/o;->n:Lf0/o;
    .line 162: goto :goto_59
    .line 163: return-void
    .line 164: new-instance v9, Ljava/lang/IllegalStateException;
    .line 166: const-string v10, "visitChildren called on an unattached node"
    .line 168: invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 171: move-result-object v10
    .line 172: invoke-direct {v9, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 175: throw v9
.end method

# direct methods
.method public static final f(Li0/q;)Li0/q;
    .registers 10

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v9, Li0/q;->x:Li0/p;
    .line 7: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 10: move-result v0
    .line 11: if-eqz v0, :cond_189
    .line 13: const/4 v1, 1
    .line 14: const/4 v2, 0
    .line 15: if-eq v0, v1, :cond_30
    .line 17: const/4 v1, 2
    .line 18: if-eq v0, v1, :cond_189
    .line 20: const/4 v9, 3
    .line 21: if-ne v0, v9, :cond_24
    .line 23: return-object v2
    .line 24: new-instance v9, Lkotlinx/coroutines/internal/z;
    .line 26: invoke-direct {v9}, Ljava/lang/RuntimeException;-><init>()V
    .line 29: throw v9
    .line 30: iget-object v9, v9, Lf0/o;->i:Lf0/o;
    .line 32: iget-boolean v0, v9, Lf0/o;->u:Z
    .line 34: if-eqz v0, :cond_177
    .line 36: new-instance v0, Lv/j;
    .line 38: const/16 v3, 16
    .line 40: new-array v4, v3, [Lf0/o;
    .line 42: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 45: iput-object v4, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 47: const/4 v4, 0
    .line 48: iput v4, v0, Lv/j;->k:I
    .line 50: iget-object v5, v9, Lf0/o;->n:Lf0/o;
    .line 52: if-nez v5, :cond_58
    .line 54: invoke-static {v0, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 57: goto :goto_61
    .line 58: invoke-virtual {v0, v5}, Lv/j;->b(Ljava/lang/Object;)V
    .line 61: invoke-virtual {v0}, Lv/j;->j()Z
    .line 64: move-result v9
    .line 65: if-eqz v9, :cond_176
    .line 67: iget v9, v0, Lv/j;->k:I
    .line 69: sub-int/2addr v9, v1
    .line 70: invoke-virtual {v0, v9}, Lv/j;->l(I)Ljava/lang/Object;
    .line 73: move-result-object v9
    .line 74: check-cast v9, Lf0/o;
    .line 76: iget v5, v9, Lf0/o;->l:I
    .line 78: and-int/lit16 v5, v5, 1024
    .line 80: if-nez v5, :cond_86
    .line 82: invoke-static {v0, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 85: goto :goto_61
    .line 86: if-eqz v9, :cond_61
    .line 88: iget v5, v9, Lf0/o;->k:I
    .line 90: and-int/lit16 v5, v5, 1024
    .line 92: if-eqz v5, :cond_173
    .line 94: move-object v5, v2
    .line 95: if-eqz v9, :cond_61
    .line 97: instance-of v6, v9, Li0/q;
    .line 99: if-eqz v6, :cond_110
    .line 101: check-cast v9, Li0/q;
    .line 103: invoke-static {v9}, Landroidx/compose/ui/focus/a;->f(Li0/q;)Li0/q;
    .line 106: move-result-object v9
    .line 107: if-eqz v9, :cond_168
    .line 109: return-object v9
    .line 110: iget v6, v9, Lf0/o;->k:I
    .line 112: and-int/lit16 v6, v6, 1024
    .line 114: if-eqz v6, :cond_168
    .line 116: instance-of v6, v9, Lz0/p;
    .line 118: if-eqz v6, :cond_168
    .line 120: move-object v6, v9
    .line 121: check-cast v6, Lz0/p;
    .line 123: iget-object v6, v6, Lz0/p;->w:Lf0/o;
    .line 125: move v7, v4
    .line 126: if-eqz v6, :cond_165
    .line 128: iget v8, v6, Lf0/o;->k:I
    .line 130: and-int/lit16 v8, v8, 1024
    .line 132: if-eqz v8, :cond_162
    .line 134: add-int/lit8 v7, v7, 1
    .line 136: if-ne v7, v1, :cond_140
    .line 138: move-object v9, v6
    .line 139: goto :goto_162
    .line 140: if-nez v5, :cond_153
    .line 142: new-instance v5, Lv/j;
    .line 144: new-array v8, v3, [Lf0/o;
    .line 146: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 149: iput-object v8, v5, Lv/j;->i:[Ljava/lang/Object;
    .line 151: iput v4, v5, Lv/j;->k:I
    .line 153: if-eqz v9, :cond_159
    .line 155: invoke-virtual {v5, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 158: move-object v9, v2
    .line 159: invoke-virtual {v5, v6}, Lv/j;->b(Ljava/lang/Object;)V
    .line 162: iget-object v6, v6, Lf0/o;->n:Lf0/o;
    .line 164: goto :goto_126
    .line 165: if-ne v7, v1, :cond_168
    .line 167: goto :goto_95
    .line 168: invoke-static {v5}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 171: move-result-object v9
    .line 172: goto :goto_95
    .line 173: iget-object v9, v9, Lf0/o;->n:Lf0/o;
    .line 175: goto :goto_86
    .line 176: return-object v2
    .line 177: new-instance v9, Ljava/lang/IllegalStateException;
    .line 179: const-string v0, "visitChildren called on an unattached node"
    .line 181: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 184: move-result-object v0
    .line 185: invoke-direct {v9, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 188: throw v9
    .line 189: return-object v9
.end method

# direct methods
.method public static final g(Lv/j;Lj0/d;I)Li0/q;
    .registers 13

    .line 0: const/4 v0, 3
    .line 1: invoke-static {v12, v0}, Li0/b;->a(II)Z
    .line 4: move-result v0
    .line 5: const/4 v1, 0
    .line 6: const/4 v2, 1
    .line 7: if-eqz v0, :cond_20
    .line 9: invoke-virtual {v11}, Lj0/d;->c()F
    .line 12: move-result v0
    .line 13: int-to-float v2, v2
    .line 14: add-float/2addr v0, v2
    .line 15: invoke-virtual {v11, v0, v1}, Lj0/d;->e(FF)Lj0/d;
    .line 18: move-result-object v0
    .line 19: goto :goto_75
    .line 20: const/4 v0, 4
    .line 21: invoke-static {v12, v0}, Li0/b;->a(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_39
    .line 27: invoke-virtual {v11}, Lj0/d;->c()F
    .line 30: move-result v0
    .line 31: int-to-float v2, v2
    .line 32: add-float/2addr v0, v2
    .line 33: neg-float v0, v0
    .line 34: invoke-virtual {v11, v0, v1}, Lj0/d;->e(FF)Lj0/d;
    .line 37: move-result-object v0
    .line 38: goto :goto_75
    .line 39: const/4 v0, 5
    .line 40: invoke-static {v12, v0}, Li0/b;->a(II)Z
    .line 43: move-result v0
    .line 44: if-eqz v0, :cond_57
    .line 46: invoke-virtual {v11}, Lj0/d;->b()F
    .line 49: move-result v0
    .line 50: int-to-float v2, v2
    .line 51: add-float/2addr v0, v2
    .line 52: invoke-virtual {v11, v1, v0}, Lj0/d;->e(FF)Lj0/d;
    .line 55: move-result-object v0
    .line 56: goto :goto_75
    .line 57: const/4 v0, 6
    .line 58: invoke-static {v12, v0}, Li0/b;->a(II)Z
    .line 61: move-result v0
    .line 62: if-eqz v0, :cond_144
    .line 64: invoke-virtual {v11}, Lj0/d;->b()F
    .line 67: move-result v0
    .line 68: int-to-float v2, v2
    .line 69: add-float/2addr v0, v2
    .line 70: neg-float v0, v0
    .line 71: invoke-virtual {v11, v1, v0}, Lj0/d;->e(FF)Lj0/d;
    .line 74: move-result-object v0
    .line 75: iget v1, v10, Lv/j;->k:I
    .line 77: const/4 v2, 0
    .line 78: if-lez v1, :cond_143
    .line 80: iget-object v10, v10, Lv/j;->i:[Ljava/lang/Object;
    .line 82: const/4 v3, 0
    .line 83: aget-object v4, v10, v3
    .line 85: check-cast v4, Li0/q;
    .line 87: invoke-static {v4}, Landroidx/compose/ui/focus/a;->u(Li0/q;)Z
    .line 90: move-result v5
    .line 91: if-eqz v5, :cond_139
    .line 93: invoke-static {v4}, Landroidx/compose/ui/focus/a;->j(Li0/q;)Lj0/d;
    .line 96: move-result-object v5
    .line 97: invoke-static {v12, v5, v11}, Landroidx/compose/ui/focus/a;->s(ILj0/d;Lj0/d;)Z
    .line 100: move-result v6
    .line 101: if-nez v6, :cond_104
    .line 103: goto :goto_139
    .line 104: invoke-static {v12, v0, v11}, Landroidx/compose/ui/focus/a;->s(ILj0/d;Lj0/d;)Z
    .line 107: move-result v6
    .line 108: if-nez v6, :cond_111
    .line 110: goto :goto_137
    .line 111: invoke-static {v11, v5, v0, v12}, Landroidx/compose/ui/focus/a;->b(Lj0/d;Lj0/d;Lj0/d;I)Z
    .line 114: move-result v6
    .line 115: if-eqz v6, :cond_118
    .line 117: goto :goto_137
    .line 118: invoke-static {v11, v0, v5, v12}, Landroidx/compose/ui/focus/a;->b(Lj0/d;Lj0/d;Lj0/d;I)Z
    .line 121: move-result v6
    .line 122: if-eqz v6, :cond_125
    .line 124: goto :goto_139
    .line 125: invoke-static {v12, v11, v5}, Landroidx/compose/ui/focus/a;->t(ILj0/d;Lj0/d;)J
    .line 128: move-result-wide v6
    .line 129: invoke-static {v12, v11, v0}, Landroidx/compose/ui/focus/a;->t(ILj0/d;Lj0/d;)J
    .line 132: move-result-wide v8
    .line 133: cmp-long v6, v6, v8
    .line 135: if-gez v6, :cond_139
    .line 137: move-object v2, v4
    .line 138: move-object v0, v5
    .line 139: add-int/lit8 v3, v3, 1
    .line 141: if-lt v3, v1, :cond_83
    .line 143: return-object v2
    .line 144: new-instance v10, Ljava/lang/IllegalStateException;
    .line 146: const-string v11, "This function should only be used for 2-D focus search"
    .line 148: invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 151: move-result-object v11
    .line 152: invoke-direct {v10, v11}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 155: throw v10
.end method

# direct methods
.method public static final h(Li0/q;ILd3/c;)Z
    .registers 7

    .line 0: new-instance v0, Lv/j;
    .line 2: const/16 v1, 16
    .line 4: new-array v1, v1, [Li0/q;
    .line 6: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 9: iput-object v1, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 11: const/4 v1, 0
    .line 12: iput v1, v0, Lv/j;->k:I
    .line 14: invoke-static {v4, v0}, Landroidx/compose/ui/focus/a;->e(Lz0/o;Lv/j;)V
    .line 17: iget v2, v0, Lv/j;->k:I
    .line 19: const/4 v3, 1
    .line 20: if-gt v2, v3, :cond_49
    .line 22: invoke-virtual {v0}, Lv/j;->i()Z
    .line 25: move-result v4
    .line 26: if-eqz v4, :cond_30
    .line 28: const/4 v4, 0
    .line 29: goto :goto_34
    .line 30: iget-object v4, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 32: aget-object v4, v4, v1
    .line 34: check-cast v4, Li0/q;
    .line 36: if-eqz v4, :cond_48
    .line 38: invoke-interface {v6, v4}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 41: move-result-object v4
    .line 42: check-cast v4, Ljava/lang/Boolean;
    .line 44: invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z
    .line 47: move-result v1
    .line 48: return v1
    .line 49: const/4 v2, 7
    .line 50: invoke-static {v5, v2}, Li0/b;->a(II)Z
    .line 53: move-result v2
    .line 54: const/4 v3, 4
    .line 55: if-eqz v2, :cond_58
    .line 57: move v5, v3
    .line 58: invoke-static {v5, v3}, Li0/b;->a(II)Z
    .line 61: move-result v2
    .line 62: if-eqz v2, :cond_65
    .line 64: goto :goto_72
    .line 65: const/4 v2, 6
    .line 66: invoke-static {v5, v2}, Li0/b;->a(II)Z
    .line 69: move-result v2
    .line 70: if-eqz v2, :cond_86
    .line 72: invoke-static {v4}, Landroidx/compose/ui/focus/a;->j(Li0/q;)Lj0/d;
    .line 75: move-result-object v4
    .line 76: new-instance v2, Lj0/d;
    .line 78: iget v3, v4, Lj0/d;->b:F
    .line 80: iget v4, v4, Lj0/d;->a:F
    .line 82: invoke-direct {v2, v4, v3, v4, v3}, Lj0/d;-><init>(FFFF)V
    .line 85: goto :goto_114
    .line 86: const/4 v2, 3
    .line 87: invoke-static {v5, v2}, Li0/b;->a(II)Z
    .line 90: move-result v2
    .line 91: if-eqz v2, :cond_94
    .line 93: goto :goto_101
    .line 94: const/4 v2, 5
    .line 95: invoke-static {v5, v2}, Li0/b;->a(II)Z
    .line 98: move-result v2
    .line 99: if-eqz v2, :cond_131
    .line 101: invoke-static {v4}, Landroidx/compose/ui/focus/a;->j(Li0/q;)Lj0/d;
    .line 104: move-result-object v4
    .line 105: new-instance v2, Lj0/d;
    .line 107: iget v3, v4, Lj0/d;->d:F
    .line 109: iget v4, v4, Lj0/d;->c:F
    .line 111: invoke-direct {v2, v4, v3, v4, v3}, Lj0/d;-><init>(FFFF)V
    .line 114: invoke-static {v0, v2, v5}, Landroidx/compose/ui/focus/a;->g(Lv/j;Lj0/d;I)Li0/q;
    .line 117: move-result-object v4
    .line 118: if-eqz v4, :cond_130
    .line 120: invoke-interface {v6, v4}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 123: move-result-object v4
    .line 124: check-cast v4, Ljava/lang/Boolean;
    .line 126: invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z
    .line 129: move-result v1
    .line 130: return v1
    .line 131: new-instance v4, Ljava/lang/IllegalStateException;
    .line 133: const-string v5, "This function should only be used for 2-D focus search"
    .line 135: invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 138: move-result-object v5
    .line 139: invoke-direct {v4, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 142: throw v4
.end method

# direct methods
.method public static final i(Lf0/p;)Lf0/p;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/focus/FocusPropertiesElement;
    .line 7: invoke-direct {v0}, Landroidx/compose/ui/focus/FocusPropertiesElement;-><init>()V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

# direct methods
.method public static final j(Li0/q;)Lj0/d;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v2, v2, Lf0/o;->p:Lz0/a1;
    .line 7: if-eqz v2, :cond_20
    .line 9: invoke-static {v2}, Landroidx/compose/ui/layout/a;->d(Lx0/q;)Lx0/q;
    .line 12: move-result-object v0
    .line 13: const/4 v1, 0
    .line 14: invoke-interface {v0, v2, v1}, Lx0/q;->D(Lx0/q;Z)Lj0/d;
    .line 17: move-result-object v2
    .line 18: if-nez v2, :cond_22
    .line 20: sget-object v2, Lj0/d;->e:Lj0/d;
    .line 22: return-object v2
.end method

# direct methods
.method public static final k(Li0/l;)Lf0/p;
    .registers 2

    .line 0: new-instance v0, Landroidx/compose/ui/focus/FocusRequesterElement;
    .line 2: invoke-direct {v0, v1}, Landroidx/compose/ui/focus/FocusRequesterElement;-><init>(Li0/l;)V
    .line 5: return-object v0
.end method

# direct methods
.method public static final l(Li0/q;Ld3/c;)Z
    .registers 5

    .line 0: iget-object v0, v3, Li0/q;->x:Li0/p;
    .line 2: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_80
    .line 8: const/4 v1, 1
    .line 9: if-eq v0, v1, :cond_47
    .line 11: const/4 v1, 2
    .line 12: if-eq v0, v1, :cond_80
    .line 14: const/4 v1, 3
    .line 15: if-ne v0, v1, :cond_41
    .line 17: invoke-virtual {v3}, Li0/q;->D0()Li0/i;
    .line 20: move-result-object v0
    .line 21: iget-boolean v0, v0, Li0/i;->a:Z
    .line 23: if-eqz v0, :cond_36
    .line 25: invoke-interface {v4, v3}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 28: move-result-object v3
    .line 29: check-cast v3, Ljava/lang/Boolean;
    .line 31: invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z
    .line 34: move-result v1
    .line 35: goto :goto_84
    .line 36: invoke-static {v3, v4}, Landroidx/compose/ui/focus/a;->B(Li0/q;Ld3/c;)Z
    .line 39: move-result v1
    .line 40: goto :goto_84
    .line 41: new-instance v3, Lkotlinx/coroutines/internal/z;
    .line 43: invoke-direct {v3}, Ljava/lang/RuntimeException;-><init>()V
    .line 46: throw v3
    .line 47: invoke-static {v3}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 50: move-result-object v0
    .line 51: if-eqz v0, :cond_68
    .line 53: invoke-static {v0, v4}, Landroidx/compose/ui/focus/a;->l(Li0/q;Ld3/c;)Z
    .line 56: move-result v2
    .line 57: if-nez v2, :cond_84
    .line 59: invoke-static {v3, v0, v1, v4}, Landroidx/compose/ui/focus/a;->m(Li0/q;Li0/q;ILd3/c;)Z
    .line 62: move-result v3
    .line 63: if-eqz v3, :cond_66
    .line 65: goto :goto_84
    .line 66: const/4 v1, 0
    .line 67: goto :goto_84
    .line 68: new-instance v3, Ljava/lang/IllegalStateException;
    .line 70: const-string v4, "ActiveParent must have a focusedChild"
    .line 72: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 75: move-result-object v4
    .line 76: invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 79: throw v3
    .line 80: invoke-static {v3, v4}, Landroidx/compose/ui/focus/a;->B(Li0/q;Ld3/c;)Z
    .line 83: move-result v1
    .line 84: return v1
.end method

# direct methods
.method public static final m(Li0/q;Li0/q;ILd3/c;)Z
    .registers 11

    .line 0: invoke-static {v7, v8, v9, v10}, Landroidx/compose/ui/focus/a;->G(Li0/q;Li0/q;ILd3/c;)Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_8
    .line 6: const/4 v7, 1
    .line 7: return v7
    .line 8: new-instance v6, Li0/s;
    .line 10: const/4 v5, 0
    .line 11: move-object v0, v6
    .line 12: move-object v1, v7
    .line 13: move-object v2, v8
    .line 14: move v3, v9
    .line 15: move-object v4, v10
    .line 16: invoke-direct/range {v0 .. v5}, Li0/s;-><init>(Li0/q;Li0/q;ILd3/c;I)V
    .line 19: invoke-static {v7, v6}, Landroidx/compose/ui/focus/a;->F(Li0/q;Li0/s;)V
    .line 22: const/4 v7, 0
    .line 23: return v7
.end method

# direct methods
.method public static final n(Li0/q;Li0/q;ILd3/c;)Z
    .registers 11

    .line 0: invoke-static {v7, v8, v9, v10}, Landroidx/compose/ui/focus/a;->H(Li0/q;Li0/q;ILd3/c;)Z
    .line 3: move-result v0
    .line 4: if-eqz v0, :cond_8
    .line 6: const/4 v7, 1
    .line 7: return v7
    .line 8: new-instance v6, Li0/s;
    .line 10: const/4 v5, 1
    .line 11: move-object v0, v6
    .line 12: move-object v1, v7
    .line 13: move-object v2, v8
    .line 14: move v3, v9
    .line 15: move-object v4, v10
    .line 16: invoke-direct/range {v0 .. v5}, Li0/s;-><init>(Li0/q;Li0/q;ILd3/c;I)V
    .line 19: invoke-static {v7, v6}, Landroidx/compose/ui/focus/a;->F(Li0/q;Li0/s;)V
    .line 22: const/4 v7, 0
    .line 23: return v7
.end method

# direct methods
.method public static final o(Li0/q;)Li0/q;
    .registers 10

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v9, v9, Lf0/o;->i:Lf0/o;
    .line 7: iget-boolean v0, v9, Lf0/o;->u:Z
    .line 9: const/4 v1, 0
    .line 10: if-nez v0, :cond_13
    .line 12: return-object v1
    .line 13: if-eqz v0, :cond_165
    .line 15: new-instance v0, Lv/j;
    .line 17: const/16 v2, 16
    .line 19: new-array v3, v2, [Lf0/o;
    .line 21: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 24: iput-object v3, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 26: const/4 v3, 0
    .line 27: iput v3, v0, Lv/j;->k:I
    .line 29: iget-object v4, v9, Lf0/o;->n:Lf0/o;
    .line 31: if-nez v4, :cond_37
    .line 33: invoke-static {v0, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 36: goto :goto_40
    .line 37: invoke-virtual {v0, v4}, Lv/j;->b(Ljava/lang/Object;)V
    .line 40: invoke-virtual {v0}, Lv/j;->j()Z
    .line 43: move-result v9
    .line 44: if-eqz v9, :cond_164
    .line 46: iget v9, v0, Lv/j;->k:I
    .line 48: const/4 v4, 1
    .line 49: sub-int/2addr v9, v4
    .line 50: invoke-virtual {v0, v9}, Lv/j;->l(I)Ljava/lang/Object;
    .line 53: move-result-object v9
    .line 54: check-cast v9, Lf0/o;
    .line 56: iget v5, v9, Lf0/o;->l:I
    .line 58: and-int/lit16 v5, v5, 1024
    .line 60: if-nez v5, :cond_66
    .line 62: invoke-static {v0, v9}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 65: goto :goto_40
    .line 66: if-eqz v9, :cond_40
    .line 68: iget v5, v9, Lf0/o;->k:I
    .line 70: and-int/lit16 v5, v5, 1024
    .line 72: if-eqz v5, :cond_161
    .line 74: move-object v5, v1
    .line 75: if-eqz v9, :cond_40
    .line 77: instance-of v6, v9, Li0/q;
    .line 79: if-eqz v6, :cond_98
    .line 81: check-cast v9, Li0/q;
    .line 83: iget-object v6, v9, Li0/q;->x:Li0/p;
    .line 85: invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I
    .line 88: move-result v6
    .line 89: if-eqz v6, :cond_97
    .line 91: if-eq v6, v4, :cond_97
    .line 93: const/4 v7, 2
    .line 94: if-eq v6, v7, :cond_97
    .line 96: goto :goto_156
    .line 97: return-object v9
    .line 98: iget v6, v9, Lf0/o;->k:I
    .line 100: and-int/lit16 v6, v6, 1024
    .line 102: if-eqz v6, :cond_156
    .line 104: instance-of v6, v9, Lz0/p;
    .line 106: if-eqz v6, :cond_156
    .line 108: move-object v6, v9
    .line 109: check-cast v6, Lz0/p;
    .line 111: iget-object v6, v6, Lz0/p;->w:Lf0/o;
    .line 113: move v7, v3
    .line 114: if-eqz v6, :cond_153
    .line 116: iget v8, v6, Lf0/o;->k:I
    .line 118: and-int/lit16 v8, v8, 1024
    .line 120: if-eqz v8, :cond_150
    .line 122: add-int/lit8 v7, v7, 1
    .line 124: if-ne v7, v4, :cond_128
    .line 126: move-object v9, v6
    .line 127: goto :goto_150
    .line 128: if-nez v5, :cond_141
    .line 130: new-instance v5, Lv/j;
    .line 132: new-array v8, v2, [Lf0/o;
    .line 134: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 137: iput-object v8, v5, Lv/j;->i:[Ljava/lang/Object;
    .line 139: iput v3, v5, Lv/j;->k:I
    .line 141: if-eqz v9, :cond_147
    .line 143: invoke-virtual {v5, v9}, Lv/j;->b(Ljava/lang/Object;)V
    .line 146: move-object v9, v1
    .line 147: invoke-virtual {v5, v6}, Lv/j;->b(Ljava/lang/Object;)V
    .line 150: iget-object v6, v6, Lf0/o;->n:Lf0/o;
    .line 152: goto :goto_114
    .line 153: if-ne v7, v4, :cond_156
    .line 155: goto :goto_75
    .line 156: invoke-static {v5}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 159: move-result-object v9
    .line 160: goto :goto_75
    .line 161: iget-object v9, v9, Lf0/o;->n:Lf0/o;
    .line 163: goto :goto_66
    .line 164: return-object v1
    .line 165: new-instance v9, Ljava/lang/IllegalStateException;
    .line 167: const-string v0, "visitChildren called on an unattached node"
    .line 169: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 172: move-result-object v0
    .line 173: invoke-direct {v9, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 176: throw v9
.end method

# direct methods
.method public static final p(Li0/c;)Li0/p;
    .registers 11

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: check-cast v10, Lf0/o;
    .line 7: iget-object v0, v10, Lf0/o;->i:Lf0/o;
    .line 9: const/4 v1, 0
    .line 10: move-object v2, v1
    .line 11: const/4 v3, 1
    .line 12: const/4 v4, 0
    .line 13: const/4 v5, 2
    .line 14: const/16 v6, 16
    .line 16: if-eqz v0, :cond_101
    .line 18: instance-of v7, v0, Li0/q;
    .line 20: if-eqz v7, :cond_38
    .line 22: check-cast v0, Li0/q;
    .line 24: iget-object v0, v0, Li0/q;->x:Li0/p;
    .line 26: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 29: move-result v4
    .line 30: if-eqz v4, :cond_37
    .line 32: if-eq v4, v3, :cond_37
    .line 34: if-eq v4, v5, :cond_37
    .line 36: goto :goto_96
    .line 37: return-object v0
    .line 38: iget v5, v0, Lf0/o;->k:I
    .line 40: and-int/lit16 v5, v5, 1024
    .line 42: if-eqz v5, :cond_96
    .line 44: instance-of v5, v0, Lz0/p;
    .line 46: if-eqz v5, :cond_96
    .line 48: move-object v5, v0
    .line 49: check-cast v5, Lz0/p;
    .line 51: iget-object v5, v5, Lz0/p;->w:Lf0/o;
    .line 53: move v7, v4
    .line 54: if-eqz v5, :cond_93
    .line 56: iget v8, v5, Lf0/o;->k:I
    .line 58: and-int/lit16 v8, v8, 1024
    .line 60: if-eqz v8, :cond_90
    .line 62: add-int/lit8 v7, v7, 1
    .line 64: if-ne v7, v3, :cond_68
    .line 66: move-object v0, v5
    .line 67: goto :goto_90
    .line 68: if-nez v2, :cond_81
    .line 70: new-instance v2, Lv/j;
    .line 72: new-array v8, v6, [Lf0/o;
    .line 74: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 77: iput-object v8, v2, Lv/j;->i:[Ljava/lang/Object;
    .line 79: iput v4, v2, Lv/j;->k:I
    .line 81: if-eqz v0, :cond_87
    .line 83: invoke-virtual {v2, v0}, Lv/j;->b(Ljava/lang/Object;)V
    .line 86: move-object v0, v1
    .line 87: invoke-virtual {v2, v5}, Lv/j;->b(Ljava/lang/Object;)V
    .line 90: iget-object v5, v5, Lf0/o;->n:Lf0/o;
    .line 92: goto :goto_54
    .line 93: if-ne v7, v3, :cond_96
    .line 95: goto :goto_11
    .line 96: invoke-static {v2}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 99: move-result-object v0
    .line 100: goto :goto_11
    .line 101: iget-object v10, v10, Lf0/o;->i:Lf0/o;
    .line 103: iget-boolean v0, v10, Lf0/o;->u:Z
    .line 105: if-eqz v0, :cond_254
    .line 107: new-instance v0, Lv/j;
    .line 109: new-array v2, v6, [Lf0/o;
    .line 111: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 114: iput-object v2, v0, Lv/j;->i:[Ljava/lang/Object;
    .line 116: iput v4, v0, Lv/j;->k:I
    .line 118: iget-object v2, v10, Lf0/o;->n:Lf0/o;
    .line 120: if-nez v2, :cond_126
    .line 122: invoke-static {v0, v10}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 125: goto :goto_129
    .line 126: invoke-virtual {v0, v2}, Lv/j;->b(Ljava/lang/Object;)V
    .line 129: invoke-virtual {v0}, Lv/j;->j()Z
    .line 132: move-result v10
    .line 133: if-eqz v10, :cond_251
    .line 135: iget v10, v0, Lv/j;->k:I
    .line 137: sub-int/2addr v10, v3
    .line 138: invoke-virtual {v0, v10}, Lv/j;->l(I)Ljava/lang/Object;
    .line 141: move-result-object v10
    .line 142: check-cast v10, Lf0/o;
    .line 144: iget v2, v10, Lf0/o;->l:I
    .line 146: and-int/lit16 v2, v2, 1024
    .line 148: if-nez v2, :cond_154
    .line 150: invoke-static {v0, v10}, Lz0/h;->b(Lv/j;Lf0/o;)V
    .line 153: goto :goto_129
    .line 154: if-eqz v10, :cond_129
    .line 156: iget v2, v10, Lf0/o;->k:I
    .line 158: and-int/lit16 v2, v2, 1024
    .line 160: if-eqz v2, :cond_248
    .line 162: move-object v2, v1
    .line 163: if-eqz v10, :cond_129
    .line 165: instance-of v7, v10, Li0/q;
    .line 167: if-eqz v7, :cond_185
    .line 169: check-cast v10, Li0/q;
    .line 171: iget-object v10, v10, Li0/q;->x:Li0/p;
    .line 173: invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I
    .line 176: move-result v7
    .line 177: if-eqz v7, :cond_184
    .line 179: if-eq v7, v3, :cond_184
    .line 181: if-eq v7, v5, :cond_184
    .line 183: goto :goto_243
    .line 184: return-object v10
    .line 185: iget v7, v10, Lf0/o;->k:I
    .line 187: and-int/lit16 v7, v7, 1024
    .line 189: if-eqz v7, :cond_243
    .line 191: instance-of v7, v10, Lz0/p;
    .line 193: if-eqz v7, :cond_243
    .line 195: move-object v7, v10
    .line 196: check-cast v7, Lz0/p;
    .line 198: iget-object v7, v7, Lz0/p;->w:Lf0/o;
    .line 200: move v8, v4
    .line 201: if-eqz v7, :cond_240
    .line 203: iget v9, v7, Lf0/o;->k:I
    .line 205: and-int/lit16 v9, v9, 1024
    .line 207: if-eqz v9, :cond_237
    .line 209: add-int/lit8 v8, v8, 1
    .line 211: if-ne v8, v3, :cond_215
    .line 213: move-object v10, v7
    .line 214: goto :goto_237
    .line 215: if-nez v2, :cond_228
    .line 217: new-instance v2, Lv/j;
    .line 219: new-array v9, v6, [Lf0/o;
    .line 221: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 224: iput-object v9, v2, Lv/j;->i:[Ljava/lang/Object;
    .line 226: iput v4, v2, Lv/j;->k:I
    .line 228: if-eqz v10, :cond_234
    .line 230: invoke-virtual {v2, v10}, Lv/j;->b(Ljava/lang/Object;)V
    .line 233: move-object v10, v1
    .line 234: invoke-virtual {v2, v7}, Lv/j;->b(Ljava/lang/Object;)V
    .line 237: iget-object v7, v7, Lf0/o;->n:Lf0/o;
    .line 239: goto :goto_201
    .line 240: if-ne v8, v3, :cond_243
    .line 242: goto :goto_163
    .line 243: invoke-static {v2}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 246: move-result-object v10
    .line 247: goto :goto_163
    .line 248: iget-object v10, v10, Lf0/o;->n:Lf0/o;
    .line 250: goto :goto_154
    .line 251: sget-object v10, Li0/p;->k:Li0/p;
    .line 253: return-object v10
    .line 254: new-instance v10, Ljava/lang/IllegalStateException;
    .line 256: const-string v0, "visitChildren called on an unattached node"
    .line 258: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 261: move-result-object v0
    .line 262: invoke-direct {v10, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 265: throw v10
.end method

# direct methods
.method public static final q(Li0/q;)V
    .registers 3

    .line 0: new-instance v0, Lh/i0;
    .line 2: const/16 v1, 10
    .line 4: invoke-direct {v0, v1, v2}, Lh/i0;-><init>(ILjava/lang/Object;)V
    .line 7: invoke-static {v2, v0}, Lz0/h;->v(Lf0/o;Ld3/a;)V
    .line 10: iget-object v0, v2, Li0/q;->x:Li0/p;
    .line 12: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 15: move-result v0
    .line 16: const/4 v1, 1
    .line 17: if-eq v0, v1, :cond_23
    .line 19: const/4 v1, 3
    .line 20: if-eq v0, v1, :cond_23
    .line 22: goto :goto_27
    .line 23: sget-object v0, Li0/p;->i:Li0/p;
    .line 25: iput-object v0, v2, Li0/q;->x:Li0/p;
    .line 27: return-void
.end method

# direct methods
.method public static final r(Li0/c;)V
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v2}, Lz0/h;->z(Lz0/o;)Lz0/j1;
    .line 8: move-result-object v0
    .line 9: invoke-interface {v0}, Lz0/j1;->getFocusOwner()Li0/e;
    .line 12: move-result-object v0
    .line 13: check-cast v0, Li0/f;
    .line 15: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 18: iget-object v0, v0, Li0/f;->b:Li0/d;
    .line 20: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 23: iget-object v1, v0, Li0/d;->c:Ljava/util/LinkedHashSet;
    .line 25: invoke-virtual {v0, v1, v2}, Li0/d;->a(Ljava/util/LinkedHashSet;Ljava/lang/Object;)V
    .line 28: return-void
.end method

# direct methods
.method public static final s(ILj0/d;Lj0/d;)Z
    .registers 10

    .line 0: const/4 v0, 3
    .line 1: invoke-static {v7, v0}, Li0/b;->a(II)Z
    .line 4: move-result v0
    .line 5: iget v1, v8, Lj0/d;->a:F
    .line 7: iget v2, v8, Lj0/d;->c:F
    .line 9: iget v3, v9, Lj0/d;->a:F
    .line 11: iget v4, v9, Lj0/d;->c:F
    .line 13: const/4 v5, 0
    .line 14: const/4 v6, 1
    .line 15: if-eqz v0, :cond_31
    .line 17: cmpl-float v7, v4, v2
    .line 19: if-gtz v7, :cond_25
    .line 21: cmpl-float v7, v3, v2
    .line 23: if-ltz v7, :cond_99
    .line 25: cmpl-float v7, v3, v1
    .line 27: if-lez v7, :cond_99
    .line 29: move v5, v6
    .line 30: goto :goto_99
    .line 31: const/4 v0, 4
    .line 32: invoke-static {v7, v0}, Li0/b;->a(II)Z
    .line 35: move-result v0
    .line 36: if-eqz v0, :cond_51
    .line 38: cmpg-float v7, v3, v1
    .line 40: if-ltz v7, :cond_46
    .line 42: cmpg-float v7, v4, v1
    .line 44: if-gtz v7, :cond_99
    .line 46: cmpg-float v7, v4, v2
    .line 48: if-gez v7, :cond_99
    .line 50: goto :goto_29
    .line 51: const/4 v0, 5
    .line 52: invoke-static {v7, v0}, Li0/b;->a(II)Z
    .line 55: move-result v0
    .line 56: iget v1, v8, Lj0/d;->b:F
    .line 58: iget v8, v8, Lj0/d;->d:F
    .line 60: iget v2, v9, Lj0/d;->b:F
    .line 62: iget v9, v9, Lj0/d;->d:F
    .line 64: if-eqz v0, :cond_79
    .line 66: cmpl-float v7, v9, v8
    .line 68: if-gtz v7, :cond_74
    .line 70: cmpl-float v7, v2, v8
    .line 72: if-ltz v7, :cond_99
    .line 74: cmpl-float v7, v2, v1
    .line 76: if-lez v7, :cond_99
    .line 78: goto :goto_29
    .line 79: const/4 v0, 6
    .line 80: invoke-static {v7, v0}, Li0/b;->a(II)Z
    .line 83: move-result v7
    .line 84: if-eqz v7, :cond_100
    .line 86: cmpg-float v7, v2, v1
    .line 88: if-ltz v7, :cond_94
    .line 90: cmpg-float v7, v9, v1
    .line 92: if-gtz v7, :cond_99
    .line 94: cmpg-float v7, v9, v8
    .line 96: if-gez v7, :cond_99
    .line 98: goto :goto_29
    .line 99: return v5
    .line 100: new-instance v7, Ljava/lang/IllegalStateException;
    .line 102: const-string v8, "This function should only be used for 2-D focus search"
    .line 104: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 107: move-result-object v8
    .line 108: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 111: throw v7
.end method

# direct methods
.method public static final t(ILj0/d;Lj0/d;)J
    .registers 15

    .line 0: const/4 v0, 3
    .line 1: invoke-static {v12, v0}, Li0/b;->a(II)Z
    .line 4: move-result v1
    .line 5: iget v2, v13, Lj0/d;->b:F
    .line 7: iget v3, v13, Lj0/d;->a:F
    .line 9: iget v4, v14, Lj0/d;->b:F
    .line 11: iget v5, v14, Lj0/d;->a:F
    .line 13: const-string v6, "This function should only be used for 2-D focus search"
    .line 15: const/4 v7, 6
    .line 16: const/4 v8, 5
    .line 17: const/4 v9, 4
    .line 18: if-eqz v1, :cond_25
    .line 20: iget v1, v14, Lj0/d;->c:F
    .line 22: sub-float v1, v3, v1
    .line 24: goto :goto_57
    .line 25: invoke-static {v12, v9}, Li0/b;->a(II)Z
    .line 28: move-result v1
    .line 29: if-eqz v1, :cond_36
    .line 31: iget v1, v13, Lj0/d;->c:F
    .line 33: sub-float v1, v5, v1
    .line 35: goto :goto_57
    .line 36: invoke-static {v12, v8}, Li0/b;->a(II)Z
    .line 39: move-result v1
    .line 40: if-eqz v1, :cond_47
    .line 42: iget v1, v14, Lj0/d;->d:F
    .line 44: sub-float v1, v2, v1
    .line 46: goto :goto_57
    .line 47: invoke-static {v12, v7}, Li0/b;->a(II)Z
    .line 50: move-result v1
    .line 51: if-eqz v1, :cond_146
    .line 53: iget v1, v13, Lj0/d;->d:F
    .line 55: sub-float v1, v4, v1
    .line 57: const/4 v10, 0
    .line 58: invoke-static {v10, v1}, Ljava/lang/Math;->max(FF)F
    .line 61: move-result v1
    .line 62: invoke-static {v1}, Ljava/lang/Math;->abs(F)F
    .line 65: move-result v1
    .line 66: float-to-long v10, v1
    .line 67: invoke-static {v12, v0}, Li0/b;->a(II)Z
    .line 70: move-result v0
    .line 71: const/4 v1, 2
    .line 72: if-eqz v0, :cond_75
    .line 74: goto :goto_81
    .line 75: invoke-static {v12, v9}, Li0/b;->a(II)Z
    .line 78: move-result v0
    .line 79: if-eqz v0, :cond_96
    .line 81: invoke-virtual {v13}, Lj0/d;->b()F
    .line 84: move-result v12
    .line 85: int-to-float v13, v1
    .line 86: div-float/2addr v12, v13
    .line 87: add-float/2addr v12, v2
    .line 88: invoke-virtual {v14}, Lj0/d;->b()F
    .line 91: move-result v14
    .line 92: div-float/2addr v14, v13
    .line 93: add-float/2addr v14, v4
    .line 94: sub-float/2addr v12, v14
    .line 95: goto :goto_123
    .line 96: invoke-static {v12, v8}, Li0/b;->a(II)Z
    .line 99: move-result v0
    .line 100: if-eqz v0, :cond_103
    .line 102: goto :goto_109
    .line 103: invoke-static {v12, v7}, Li0/b;->a(II)Z
    .line 106: move-result v12
    .line 107: if-eqz v12, :cond_136
    .line 109: invoke-virtual {v13}, Lj0/d;->c()F
    .line 112: move-result v12
    .line 113: int-to-float v13, v1
    .line 114: div-float/2addr v12, v13
    .line 115: add-float/2addr v12, v3
    .line 116: invoke-virtual {v14}, Lj0/d;->c()F
    .line 119: move-result v14
    .line 120: div-float/2addr v14, v13
    .line 121: add-float/2addr v14, v5
    .line 122: goto :goto_94
    .line 123: invoke-static {v12}, Ljava/lang/Math;->abs(F)F
    .line 126: move-result v12
    .line 127: float-to-long v12, v12
    .line 128: const/16 v14, 13
    .line 130: int-to-long v0, v14
    .line 131: mul-long/2addr v0, v10
    .line 132: mul-long/2addr v0, v10
    .line 133: mul-long/2addr v12, v12
    .line 134: add-long/2addr v12, v0
    .line 135: return-wide v12
    .line 136: new-instance v12, Ljava/lang/IllegalStateException;
    .line 138: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 141: move-result-object v13
    .line 142: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 145: throw v12
    .line 146: new-instance v12, Ljava/lang/IllegalStateException;
    .line 148: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 151: move-result-object v13
    .line 152: invoke-direct {v12, v13}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 155: throw v12
.end method

# direct methods
.method public static final u(Li0/q;)Z
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v2, Lf0/o;->p:Lz0/a1;
    .line 7: if-eqz v0, :cond_35
    .line 9: iget-object v0, v0, Lz0/a1;->p:Landroidx/compose/ui/node/a;
    .line 11: if-eqz v0, :cond_35
    .line 13: invoke-virtual {v0}, Landroidx/compose/ui/node/a;->y()Z
    .line 16: move-result v0
    .line 17: const/4 v1, 1
    .line 18: if-ne v0, v1, :cond_35
    .line 20: iget-object v2, v2, Lf0/o;->p:Lz0/a1;
    .line 22: if-eqz v2, :cond_35
    .line 24: iget-object v2, v2, Lz0/a1;->p:Landroidx/compose/ui/node/a;
    .line 26: if-eqz v2, :cond_35
    .line 28: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->x()Z
    .line 31: move-result v2
    .line 32: if-ne v2, v1, :cond_35
    .line 34: goto :goto_36
    .line 35: const/4 v1, 0
    .line 36: return v1
.end method

# direct methods
.method public static final v(Lf0/p;Lo/w;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/focus/FocusChangedElement;
    .line 7: invoke-direct {v0, v2}, Landroidx/compose/ui/focus/FocusChangedElement;-><init>(Lo/w;)V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

# direct methods
.method public static final w(Li0/q;I)I
    .registers 8

    .line 0: const-string v0, "$this$performCustomClearFocus"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v6, Li0/q;->x:Li0/p;
    .line 7: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 10: move-result v0
    .line 11: const/4 v1, 1
    .line 12: if-eqz v0, :cond_112
    .line 14: const/4 v2, 3
    .line 15: const/4 v3, 2
    .line 16: if-eq v0, v1, :cond_31
    .line 18: if-eq v0, v3, :cond_29
    .line 20: if-ne v0, v2, :cond_23
    .line 22: goto :goto_112
    .line 23: new-instance v6, Lkotlinx/coroutines/internal/z;
    .line 25: invoke-direct {v6}, Ljava/lang/RuntimeException;-><init>()V
    .line 28: throw v6
    .line 29: move v1, v3
    .line 30: goto :goto_112
    .line 31: invoke-static {v6}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 34: move-result-object v0
    .line 35: if-eqz v0, :cond_100
    .line 37: invoke-static {v0, v7}, Landroidx/compose/ui/focus/a;->w(Li0/q;I)I
    .line 40: move-result v0
    .line 41: const/4 v4, 0
    .line 42: if-ne v0, v1, :cond_45
    .line 44: move v0, v4
    .line 45: if-nez v0, :cond_98
    .line 47: iget-boolean v0, v6, Li0/q;->v:Z
    .line 49: if-nez v0, :cond_112
    .line 51: iput-boolean v1, v6, Li0/q;->v:Z
    .line 53: invoke-virtual {v6}, Li0/q;->D0()Li0/i;
    .line 56: move-result-object v0
    .line 57: iget-object v0, v0, Li0/i;->k:Li0/g;
    .line 59: new-instance v5, Li0/b;
    .line 61: invoke-direct {v5, v7}, Li0/b;-><init>(I)V
    .line 64: invoke-virtual {v0, v5}, Li0/g;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 67: move-result-object v7
    .line 68: check-cast v7, Li0/l;
    .line 70: sget-object v0, Li0/l;->b:Li0/l;
    .line 72: if-eq v7, v0, :cond_91
    .line 74: sget-object v0, Li0/l;->c:Li0/l;
    .line 76: if-ne v7, v0, :cond_81
    .line 78: iput-boolean v4, v6, Li0/q;->v:Z
    .line 80: goto :goto_29
    .line 81: invoke-virtual {v7}, Li0/l;->a()Z
    .line 84: move-result v7
    .line 85: if-eqz v7, :cond_89
    .line 87: move v1, v2
    .line 88: goto :goto_91
    .line 89: const/4 v7, 4
    .line 90: move v1, v7
    .line 91: iput-boolean v4, v6, Li0/q;->v:Z
    .line 93: goto :goto_112
    .line 94: move-exception v7
    .line 95: iput-boolean v4, v6, Li0/q;->v:Z
    .line 97: throw v7
    .line 98: move v1, v0
    .line 99: goto :goto_112
    .line 100: new-instance v6, Ljava/lang/IllegalStateException;
    .line 102: const-string v7, "Required value was null."
    .line 104: invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 107: move-result-object v7
    .line 108: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 111: throw v6
    .line 112: return v1
.end method

# direct methods
.method public static final x(Li0/q;I)I
    .registers 6

    .line 0: iget-boolean v0, v4, Li0/q;->w:Z
    .line 2: const/4 v1, 1
    .line 3: if-nez v0, :cond_57
    .line 5: iput-boolean v1, v4, Li0/q;->w:Z
    .line 7: const/4 v0, 0
    .line 8: invoke-virtual {v4}, Li0/q;->D0()Li0/i;
    .line 11: move-result-object v2
    .line 12: iget-object v2, v2, Li0/i;->j:Li0/g;
    .line 14: new-instance v3, Li0/b;
    .line 16: invoke-direct {v3, v5}, Li0/b;-><init>(I)V
    .line 19: invoke-virtual {v2, v3}, Li0/g;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 22: move-result-object v5
    .line 23: check-cast v5, Li0/l;
    .line 25: sget-object v2, Li0/l;->b:Li0/l;
    .line 27: if-eq v5, v2, :cond_51
    .line 29: sget-object v1, Li0/l;->c:Li0/l;
    .line 31: if-ne v5, v1, :cond_37
    .line 33: iput-boolean v0, v4, Li0/q;->w:Z
    .line 35: const/4 v4, 2
    .line 36: return v4
    .line 37: invoke-virtual {v5}, Li0/l;->a()Z
    .line 40: move-result v5
    .line 41: if-eqz v5, :cond_45
    .line 43: const/4 v5, 3
    .line 44: goto :goto_46
    .line 45: const/4 v5, 4
    .line 46: iput-boolean v0, v4, Li0/q;->w:Z
    .line 48: return v5
    .line 49: move-exception v5
    .line 50: goto :goto_54
    .line 51: iput-boolean v0, v4, Li0/q;->w:Z
    .line 53: goto :goto_57
    .line 54: iput-boolean v0, v4, Li0/q;->w:Z
    .line 56: throw v5
    .line 57: return v1
.end method

# direct methods
.method public static final y(Li0/q;I)I
    .registers 13

    .line 0: const-string v0, "$this$performCustomRequestFocus"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v11, Li0/q;->x:Li0/p;
    .line 7: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 10: move-result v0
    .line 11: const/4 v1, 1
    .line 12: if-eqz v0, :cond_241
    .line 14: if-eq v0, v1, :cond_218
    .line 16: const/4 v2, 2
    .line 17: if-eq v0, v2, :cond_241
    .line 19: const/4 v3, 3
    .line 20: if-ne v0, v3, :cond_212
    .line 22: iget-object v0, v11, Lf0/o;->i:Lf0/o;
    .line 24: iget-boolean v4, v0, Lf0/o;->u:Z
    .line 26: if-eqz v4, :cond_200
    .line 28: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 30: invoke-static {v11}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 33: move-result-object v11
    .line 34: const/4 v4, 0
    .line 35: const/4 v5, 0
    .line 36: if-eqz v11, :cond_149
    .line 38: iget-object v6, v11, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 40: iget-object v6, v6, Lz0/v0;->e:Lf0/o;
    .line 42: iget v6, v6, Lf0/o;->l:I
    .line 44: and-int/lit16 v6, v6, 1024
    .line 46: if-eqz v6, :cond_134
    .line 48: if-eqz v0, :cond_134
    .line 50: iget v6, v0, Lf0/o;->k:I
    .line 52: and-int/lit16 v6, v6, 1024
    .line 54: if-eqz v6, :cond_131
    .line 56: move-object v6, v0
    .line 57: move-object v7, v5
    .line 58: if-eqz v6, :cond_131
    .line 60: instance-of v8, v6, Li0/q;
    .line 62: if-eqz v8, :cond_66
    .line 64: move-object v5, v6
    .line 65: goto :goto_149
    .line 66: iget v8, v6, Lf0/o;->k:I
    .line 68: and-int/lit16 v8, v8, 1024
    .line 70: if-eqz v8, :cond_126
    .line 72: instance-of v8, v6, Lz0/p;
    .line 74: if-eqz v8, :cond_126
    .line 76: move-object v8, v6
    .line 77: check-cast v8, Lz0/p;
    .line 79: iget-object v8, v8, Lz0/p;->w:Lf0/o;
    .line 81: move v9, v4
    .line 82: if-eqz v8, :cond_123
    .line 84: iget v10, v8, Lf0/o;->k:I
    .line 86: and-int/lit16 v10, v10, 1024
    .line 88: if-eqz v10, :cond_120
    .line 90: add-int/lit8 v9, v9, 1
    .line 92: if-ne v9, v1, :cond_96
    .line 94: move-object v6, v8
    .line 95: goto :goto_120
    .line 96: if-nez v7, :cond_111
    .line 98: new-instance v7, Lv/j;
    .line 100: const/16 v10, 16
    .line 102: new-array v10, v10, [Lf0/o;
    .line 104: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 107: iput-object v10, v7, Lv/j;->i:[Ljava/lang/Object;
    .line 109: iput v4, v7, Lv/j;->k:I
    .line 111: if-eqz v6, :cond_117
    .line 113: invoke-virtual {v7, v6}, Lv/j;->b(Ljava/lang/Object;)V
    .line 116: move-object v6, v5
    .line 117: invoke-virtual {v7, v8}, Lv/j;->b(Ljava/lang/Object;)V
    .line 120: iget-object v8, v8, Lf0/o;->n:Lf0/o;
    .line 122: goto :goto_82
    .line 123: if-ne v9, v1, :cond_126
    .line 125: goto :goto_58
    .line 126: invoke-static {v7}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 129: move-result-object v6
    .line 130: goto :goto_58
    .line 131: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 133: goto :goto_48
    .line 134: invoke-virtual {v11}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 137: move-result-object v11
    .line 138: if-eqz v11, :cond_147
    .line 140: iget-object v0, v11, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 142: if-eqz v0, :cond_147
    .line 144: iget-object v0, v0, Lz0/v0;->d:Lz0/q1;
    .line 146: goto :goto_34
    .line 147: move-object v0, v5
    .line 148: goto :goto_34
    .line 149: check-cast v5, Li0/q;
    .line 151: if-nez v5, :cond_154
    .line 153: return v1
    .line 154: iget-object v11, v5, Li0/q;->x:Li0/p;
    .line 156: invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I
    .line 159: move-result v11
    .line 160: if-eqz v11, :cond_195
    .line 162: if-eq v11, v1, :cond_190
    .line 164: if-eq v11, v2, :cond_199
    .line 166: if-ne v11, v3, :cond_184
    .line 168: invoke-static {v5, v12}, Landroidx/compose/ui/focus/a;->y(Li0/q;I)I
    .line 171: move-result v11
    .line 172: if-ne v11, v1, :cond_176
    .line 174: move v2, v4
    .line 175: goto :goto_177
    .line 176: move v2, v11
    .line 177: if-nez v2, :cond_199
    .line 179: invoke-static {v5, v12}, Landroidx/compose/ui/focus/a;->x(Li0/q;I)I
    .line 182: move-result v2
    .line 183: goto :goto_199
    .line 184: new-instance v11, Lkotlinx/coroutines/internal/z;
    .line 186: invoke-direct {v11}, Ljava/lang/RuntimeException;-><init>()V
    .line 189: throw v11
    .line 190: invoke-static {v5, v12}, Landroidx/compose/ui/focus/a;->y(Li0/q;I)I
    .line 193: move-result v2
    .line 194: goto :goto_199
    .line 195: invoke-static {v5, v12}, Landroidx/compose/ui/focus/a;->x(Li0/q;I)I
    .line 198: move-result v2
    .line 199: return v2
    .line 200: new-instance v11, Ljava/lang/IllegalStateException;
    .line 202: const-string v12, "visitAncestors called on an unattached node"
    .line 204: invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 207: move-result-object v12
    .line 208: invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 211: throw v11
    .line 212: new-instance v11, Lkotlinx/coroutines/internal/z;
    .line 214: invoke-direct {v11}, Ljava/lang/RuntimeException;-><init>()V
    .line 217: throw v11
    .line 218: invoke-static {v11}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 221: move-result-object v11
    .line 222: if-eqz v11, :cond_229
    .line 224: invoke-static {v11, v12}, Landroidx/compose/ui/focus/a;->w(Li0/q;I)I
    .line 227: move-result v11
    .line 228: return v11
    .line 229: new-instance v11, Ljava/lang/IllegalStateException;
    .line 231: const-string v12, "Required value was null."
    .line 233: invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 236: move-result-object v12
    .line 237: invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 240: throw v11
    .line 241: return v1
.end method

# direct methods
.method public static final z(Li0/q;)Z
    .registers 11

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v10, Li0/q;->x:Li0/p;
    .line 7: invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I
    .line 10: move-result v0
    .line 11: const/4 v1, 1
    .line 12: if-eqz v0, :cond_241
    .line 14: const/4 v2, 0
    .line 15: if-eq v0, v1, :cond_217
    .line 17: const/4 v3, 2
    .line 18: if-eq v0, v3, :cond_241
    .line 20: const/4 v3, 3
    .line 21: if-ne v0, v3, :cond_211
    .line 23: iget-object v0, v10, Lf0/o;->i:Lf0/o;
    .line 25: iget-boolean v3, v0, Lf0/o;->u:Z
    .line 27: if-eqz v3, :cond_199
    .line 29: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 31: invoke-static {v10}, Lz0/h;->x(Lz0/o;)Landroidx/compose/ui/node/a;
    .line 34: move-result-object v3
    .line 35: const/4 v4, 0
    .line 36: if-eqz v3, :cond_149
    .line 38: iget-object v5, v3, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 40: iget-object v5, v5, Lz0/v0;->e:Lf0/o;
    .line 42: iget v5, v5, Lf0/o;->l:I
    .line 44: and-int/lit16 v5, v5, 1024
    .line 46: if-eqz v5, :cond_134
    .line 48: if-eqz v0, :cond_134
    .line 50: iget v5, v0, Lf0/o;->k:I
    .line 52: and-int/lit16 v5, v5, 1024
    .line 54: if-eqz v5, :cond_131
    .line 56: move-object v5, v0
    .line 57: move-object v6, v4
    .line 58: if-eqz v5, :cond_131
    .line 60: instance-of v7, v5, Li0/q;
    .line 62: if-eqz v7, :cond_66
    .line 64: move-object v4, v5
    .line 65: goto :goto_149
    .line 66: iget v7, v5, Lf0/o;->k:I
    .line 68: and-int/lit16 v7, v7, 1024
    .line 70: if-eqz v7, :cond_126
    .line 72: instance-of v7, v5, Lz0/p;
    .line 74: if-eqz v7, :cond_126
    .line 76: move-object v7, v5
    .line 77: check-cast v7, Lz0/p;
    .line 79: iget-object v7, v7, Lz0/p;->w:Lf0/o;
    .line 81: move v8, v2
    .line 82: if-eqz v7, :cond_123
    .line 84: iget v9, v7, Lf0/o;->k:I
    .line 86: and-int/lit16 v9, v9, 1024
    .line 88: if-eqz v9, :cond_120
    .line 90: add-int/lit8 v8, v8, 1
    .line 92: if-ne v8, v1, :cond_96
    .line 94: move-object v5, v7
    .line 95: goto :goto_120
    .line 96: if-nez v6, :cond_111
    .line 98: new-instance v6, Lv/j;
    .line 100: const/16 v9, 16
    .line 102: new-array v9, v9, [Lf0/o;
    .line 104: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 107: iput-object v9, v6, Lv/j;->i:[Ljava/lang/Object;
    .line 109: iput v2, v6, Lv/j;->k:I
    .line 111: if-eqz v5, :cond_117
    .line 113: invoke-virtual {v6, v5}, Lv/j;->b(Ljava/lang/Object;)V
    .line 116: move-object v5, v4
    .line 117: invoke-virtual {v6, v7}, Lv/j;->b(Ljava/lang/Object;)V
    .line 120: iget-object v7, v7, Lf0/o;->n:Lf0/o;
    .line 122: goto :goto_82
    .line 123: if-ne v8, v1, :cond_126
    .line 125: goto :goto_58
    .line 126: invoke-static {v6}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 129: move-result-object v5
    .line 130: goto :goto_58
    .line 131: iget-object v0, v0, Lf0/o;->m:Lf0/o;
    .line 133: goto :goto_48
    .line 134: invoke-virtual {v3}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 137: move-result-object v3
    .line 138: if-eqz v3, :cond_147
    .line 140: iget-object v0, v3, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 142: if-eqz v0, :cond_147
    .line 144: iget-object v0, v0, Lz0/v0;->d:Lz0/q1;
    .line 146: goto :goto_35
    .line 147: move-object v0, v4
    .line 148: goto :goto_35
    .line 149: check-cast v4, Li0/q;
    .line 151: if-eqz v4, :cond_158
    .line 153: invoke-static {v4, v10}, Landroidx/compose/ui/focus/a;->E(Li0/q;Li0/q;)Z
    .line 156: move-result v1
    .line 157: goto :goto_244
    .line 158: iget-object v0, v10, Lf0/o;->p:Lz0/a1;
    .line 160: if-eqz v0, :cond_187
    .line 162: iget-object v0, v0, Lz0/a1;->p:Landroidx/compose/ui/node/a;
    .line 164: if-eqz v0, :cond_187
    .line 166: iget-object v0, v0, Landroidx/compose/ui/node/a;->q:Lz0/j1;
    .line 168: if-eqz v0, :cond_187
    .line 170: invoke-interface {v0}, Lz0/j1;->requestFocus()Z
    .line 173: move-result v0
    .line 174: if-eqz v0, :cond_180
    .line 176: invoke-static {v10}, Landroidx/compose/ui/focus/a;->q(Li0/q;)V
    .line 179: goto :goto_181
    .line 180: move v1, v2
    .line 181: if-eqz v1, :cond_244
    .line 183: invoke-static {v10}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 186: goto :goto_244
    .line 187: new-instance v10, Ljava/lang/IllegalStateException;
    .line 189: const-string v0, "Owner not initialized."
    .line 191: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 194: move-result-object v0
    .line 195: invoke-direct {v10, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 198: throw v10
    .line 199: new-instance v10, Ljava/lang/IllegalStateException;
    .line 201: const-string v0, "visitAncestors called on an unattached node"
    .line 203: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 206: move-result-object v0
    .line 207: invoke-direct {v10, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 210: throw v10
    .line 211: new-instance v10, Lkotlinx/coroutines/internal/z;
    .line 213: invoke-direct {v10}, Ljava/lang/RuntimeException;-><init>()V
    .line 216: throw v10
    .line 217: invoke-static {v10}, Landroidx/compose/ui/focus/a;->o(Li0/q;)Li0/q;
    .line 220: move-result-object v0
    .line 221: if-eqz v0, :cond_232
    .line 223: invoke-static {v0, v2, v1}, Landroidx/compose/ui/focus/a;->d(Li0/q;ZZ)Z
    .line 226: move-result v0
    .line 227: if-eqz v0, :cond_230
    .line 229: goto :goto_232
    .line 230: move v1, v2
    .line 231: goto :goto_235
    .line 232: invoke-static {v10}, Landroidx/compose/ui/focus/a;->q(Li0/q;)V
    .line 235: if-eqz v1, :cond_244
    .line 237: invoke-static {v10}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 240: goto :goto_244
    .line 241: invoke-static {v10}, Landroidx/compose/ui/focus/a;->C(Li0/q;)V
    .line 244: return v1
.end method

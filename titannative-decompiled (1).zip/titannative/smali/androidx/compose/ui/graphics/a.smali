.class public abstract Landroidx/compose/ui/graphics/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(FFFFLl0/d;)J
    .registers 13

    .line 0: const-string v0, "colorSpace"
    .line 2: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const/4 v0, 0
    .line 6: invoke-virtual {v12, v0}, Ll0/d;->b(I)F
    .line 9: move-result v1
    .line 10: invoke-virtual {v12, v0}, Ll0/d;->a(I)F
    .line 13: move-result v0
    .line 14: cmpg-float v0, v8, v0
    .line 16: if-gtz v0, :cond_207
    .line 18: cmpg-float v0, v1, v8
    .line 20: if-gtz v0, :cond_207
    .line 22: const/4 v0, 1
    .line 23: invoke-virtual {v12, v0}, Ll0/d;->b(I)F
    .line 26: move-result v1
    .line 27: invoke-virtual {v12, v0}, Ll0/d;->a(I)F
    .line 30: move-result v0
    .line 31: cmpg-float v0, v9, v0
    .line 33: if-gtz v0, :cond_207
    .line 35: cmpg-float v0, v1, v9
    .line 37: if-gtz v0, :cond_207
    .line 39: const/4 v0, 2
    .line 40: invoke-virtual {v12, v0}, Ll0/d;->b(I)F
    .line 43: move-result v1
    .line 44: invoke-virtual {v12, v0}, Ll0/d;->a(I)F
    .line 47: move-result v0
    .line 48: cmpg-float v0, v10, v0
    .line 50: if-gtz v0, :cond_207
    .line 52: cmpg-float v0, v1, v10
    .line 54: if-gtz v0, :cond_207
    .line 56: const/4 v0, 0
    .line 57: cmpg-float v1, v0, v11
    .line 59: if-gtz v1, :cond_207
    .line 61: const/high16 v1, 0x3f80
    .line 63: cmpg-float v2, v11, v1
    .line 65: if-gtz v2, :cond_207
    .line 67: invoke-virtual {v12}, Ll0/d;->c()Z
    .line 70: move-result v2
    .line 71: const/16 v3, 16
    .line 73: const/16 v4, 32
    .line 75: const/high16 v5, 0x3f00
    .line 77: if-eqz v2, :cond_112
    .line 79: const/high16 v12, 0x437f
    .line 81: mul-float/2addr v11, v12
    .line 82: add-float/2addr v11, v5
    .line 83: float-to-int v11, v11
    .line 84: shl-int/lit8 v11, v11, 24
    .line 86: mul-float/2addr v8, v12
    .line 87: add-float/2addr v8, v5
    .line 88: float-to-int v8, v8
    .line 89: shl-int/2addr v8, v3
    .line 90: or-int/2addr v8, v11
    .line 91: mul-float/2addr v9, v12
    .line 92: add-float/2addr v9, v5
    .line 93: float-to-int v9, v9
    .line 94: shl-int/lit8 v9, v9, 8
    .line 96: or-int/2addr v8, v9
    .line 97: mul-float/2addr v10, v12
    .line 98: add-float/2addr v10, v5
    .line 99: float-to-int v9, v10
    .line 100: or-int/2addr v8, v9
    .line 101: int-to-long v8, v8
    .line 102: const-wide v10, 0x00ffffffff
    .line 107: and-long/2addr v8, v10
    .line 108: shl-long/2addr v8, v4
    .line 109: sget v10, Lk0/q;->h:I
    .line 111: return-wide v8
    .line 112: sget v2, Ll0/c;->e:I
    .line 114: iget-wide v6, v12, Ll0/d;->b:J
    .line 116: shr-long/2addr v6, v4
    .line 117: long-to-int v2, v6
    .line 118: const/4 v6, 3
    .line 119: if-ne v2, v6, :cond_195
    .line 121: const/4 v2, -1
    .line 122: iget v12, v12, Ll0/d;->c:I
    .line 124: if-eq v12, v2, :cond_183
    .line 126: invoke-static {v8}, Lk0/w;->a(F)S
    .line 129: move-result v8
    .line 130: invoke-static {v9}, Lk0/w;->a(F)S
    .line 133: move-result v9
    .line 134: invoke-static {v10}, Lk0/w;->a(F)S
    .line 137: move-result v10
    .line 138: invoke-static {v11, v1}, Ljava/lang/Math;->min(FF)F
    .line 141: move-result v11
    .line 142: invoke-static {v0, v11}, Ljava/lang/Math;->max(FF)F
    .line 145: move-result v11
    .line 146: const v0, 0x447fc000
    .line 149: mul-float/2addr v11, v0
    .line 150: add-float/2addr v11, v5
    .line 151: float-to-int v11, v11
    .line 152: int-to-long v0, v8
    .line 153: const-wide/32 v5, 0xffff
    .line 156: and-long/2addr v0, v5
    .line 157: const/16 v8, 48
    .line 159: shl-long/2addr v0, v8
    .line 160: int-to-long v8, v9
    .line 161: and-long/2addr v8, v5
    .line 162: shl-long/2addr v8, v4
    .line 163: or-long/2addr v8, v0
    .line 164: int-to-long v0, v10
    .line 165: and-long/2addr v0, v5
    .line 166: shl-long/2addr v0, v3
    .line 167: or-long/2addr v8, v0
    .line 168: int-to-long v10, v11
    .line 169: const-wide/16 v0, 1023
    .line 171: and-long/2addr v10, v0
    .line 172: const/4 v0, 6
    .line 173: shl-long/2addr v10, v0
    .line 174: or-long/2addr v8, v10
    .line 175: int-to-long v10, v12
    .line 176: const-wide/16 v0, 63
    .line 178: and-long/2addr v10, v0
    .line 179: or-long/2addr v8, v10
    .line 180: sget v10, Lk0/q;->h:I
    .line 182: return-wide v8
    .line 183: new-instance v8, Ljava/lang/IllegalArgumentException;
    .line 185: const-string v9, "Unknown color space, please use a color space in ColorSpaces"
    .line 187: invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 190: move-result-object v9
    .line 191: invoke-direct {v8, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 194: throw v8
    .line 195: new-instance v8, Ljava/lang/IllegalArgumentException;
    .line 197: const-string v9, "Color only works with ColorSpaces with 3 components"
    .line 199: invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 202: move-result-object v9
    .line 203: invoke-direct {v8, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 206: throw v8
    .line 207: new-instance v0, Ljava/lang/StringBuilder;
    .line 209: const-string v1, "red = "
    .line 211: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 214: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 217: const-string v8, ", green = "
    .line 219: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 222: invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 225: const-string v8, ", blue = "
    .line 227: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 230: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 233: const-string v8, ", alpha = "
    .line 235: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 238: invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 241: const-string v8, " outside the range for "
    .line 243: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 246: invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 249: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 252: move-result-object v8
    .line 253: new-instance v9, Ljava/lang/IllegalArgumentException;
    .line 255: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 258: move-result-object v8
    .line 259: invoke-direct {v9, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 262: throw v9
.end method

# direct methods
.method public static final b(I)J
    .registers 3

    .line 0: int-to-long v0, v2
    .line 1: const/16 v2, 32
    .line 3: shl-long/2addr v0, v2
    .line 4: sget v2, Lk0/q;->h:I
    .line 6: return-wide v0
.end method

# direct methods
.method public static final c(J)J
    .registers 4

    .line 0: const-wide v0, 0x00ffffffff
    .line 5: and-long/2addr v2, v0
    .line 6: const/16 v0, 32
    .line 8: shl-long/2addr v2, v0
    .line 9: sget v0, Lk0/q;->h:I
    .line 11: return-wide v2
.end method

# direct methods
.method public static d(III)J
    .registers 4

    .line 0: and-int/lit16 v1, v1, 255
    .line 2: shl-int/lit8 v1, v1, 16
    .line 4: const/high16 v0, 0xff00
    .line 6: or-int/2addr v1, v0
    .line 7: and-int/lit16 v2, v2, 255
    .line 9: shl-int/lit8 v2, v2, 8
    .line 11: or-int/2addr v1, v2
    .line 12: and-int/lit16 v2, v3, 255
    .line 14: or-int/2addr v1, v2
    .line 15: invoke-static {v1}, Landroidx/compose/ui/graphics/a;->b(I)J
    .line 18: move-result-wide v1
    .line 19: return-wide v1
.end method

# direct methods
.method public static e(IIII)Lk0/c;
    .registers 9

    .line 0: and-int/lit8 v0, v8, 4
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: move v7, v1
    .line 6: and-int/lit8 v0, v8, 8
    .line 8: if-eqz v0, :cond_11
    .line 10: const/4 v1, 1
    .line 11: and-int/lit8 v8, v8, 16
    .line 13: const/4 v0, 0
    .line 14: if-eqz v8, :cond_19
    .line 16: sget-object v8, Ll0/e;->c:Ll0/q;
    .line 18: goto :goto_20
    .line 19: move-object v8, v0
    .line 20: const-string v2, "colorSpace"
    .line 22: invoke-static {v8, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: invoke-static {v7}, Landroidx/compose/ui/graphics/a;->u(I)Landroid/graphics/Bitmap$Config;
    .line 28: move-result-object v2
    .line 29: sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 31: const/16 v4, 26
    .line 33: if-lt v3, v4, :cond_40
    .line 35: invoke-static {v5, v6, v7, v1, v8}, Lk0/h;->b(IIIZLl0/d;)Landroid/graphics/Bitmap;
    .line 38: move-result-object v5
    .line 39: goto :goto_52
    .line 40: invoke-static {v0, v5, v6, v2}, Landroid/graphics/Bitmap;->createBitmap(Landroid/util/DisplayMetrics;IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    .line 43: move-result-object v5
    .line 44: const-string v6, "createBitmap(\n          …   bitmapConfig\n        )"
    .line 46: invoke-static {v5, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 49: invoke-virtual {v5, v1}, Landroid/graphics/Bitmap;->setHasAlpha(Z)V
    .line 52: new-instance v6, Lk0/c;
    .line 54: invoke-direct {v6, v5}, Lk0/c;-><init>(Landroid/graphics/Bitmap;)V
    .line 57: return-object v6
.end method

# direct methods
.method public static final f()Lk0/d;
    .registers 3

    .line 0: new-instance v0, Lk0/d;
    .line 2: new-instance v1, Landroid/graphics/Paint;
    .line 4: const/4 v2, 7
    .line 5: invoke-direct {v1, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 8: invoke-direct {v0, v1}, Lk0/d;-><init>(Landroid/graphics/Paint;)V
    .line 11: return-object v0
.end method

# direct methods
.method public static final g()Lk0/f;
    .registers 2

    .line 0: new-instance v0, Lk0/f;
    .line 2: new-instance v1, Landroid/graphics/Path;
    .line 4: invoke-direct {v1}, Landroid/graphics/Path;-><init>()V
    .line 7: invoke-direct {v0, v1}, Lk0/f;-><init>(Landroid/graphics/Path;)V
    .line 10: return-object v0
.end method

# direct methods
.method public static final h(Lk0/y;)Landroid/graphics/Bitmap;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: instance-of v0, v1, Lk0/c;
    .line 7: if-eqz v0, :cond_14
    .line 9: check-cast v1, Lk0/c;
    .line 11: iget-object v1, v1, Lk0/c;->a:Landroid/graphics/Bitmap;
    .line 13: return-object v1
    .line 14: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 16: const-string v0, "Unable to obtain android.graphics.Bitmap"
    .line 18: invoke-direct {v1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 21: throw v1
.end method

# direct methods
.method public static final i(JJ)J
    .registers 13

    .line 0: invoke-static {v11, v12}, Lk0/q;->g(J)Ll0/d;
    .line 3: move-result-object v0
    .line 4: invoke-static {v9, v10, v0}, Lk0/q;->b(JLl0/d;)J
    .line 7: move-result-wide v9
    .line 8: invoke-static {v11, v12}, Lk0/q;->e(J)F
    .line 11: move-result v0
    .line 12: invoke-static {v9, v10}, Lk0/q;->e(J)F
    .line 15: move-result v1
    .line 16: const/high16 v2, 0x3f80
    .line 18: sub-float/2addr v2, v1
    .line 19: mul-float v3, v0, v2
    .line 21: add-float/2addr v3, v1
    .line 22: invoke-static {v9, v10}, Lk0/q;->i(J)F
    .line 25: move-result v4
    .line 26: invoke-static {v11, v12}, Lk0/q;->i(J)F
    .line 29: move-result v5
    .line 30: const/4 v6, 0
    .line 31: cmpg-float v7, v3, v6
    .line 33: if-nez v7, :cond_37
    .line 35: move v5, v6
    .line 36: goto :goto_42
    .line 37: mul-float/2addr v4, v1
    .line 38: mul-float/2addr v5, v0
    .line 39: mul-float/2addr v5, v2
    .line 40: add-float/2addr v5, v4
    .line 41: div-float/2addr v5, v3
    .line 42: invoke-static {v9, v10}, Lk0/q;->h(J)F
    .line 45: move-result v4
    .line 46: invoke-static {v11, v12}, Lk0/q;->h(J)F
    .line 49: move-result v8
    .line 50: if-nez v7, :cond_54
    .line 52: move v8, v6
    .line 53: goto :goto_59
    .line 54: mul-float/2addr v4, v1
    .line 55: mul-float/2addr v8, v0
    .line 56: mul-float/2addr v8, v2
    .line 57: add-float/2addr v8, v4
    .line 58: div-float/2addr v8, v3
    .line 59: invoke-static {v9, v10}, Lk0/q;->f(J)F
    .line 62: move-result v9
    .line 63: invoke-static {v11, v12}, Lk0/q;->f(J)F
    .line 66: move-result v10
    .line 67: if-nez v7, :cond_70
    .line 69: goto :goto_76
    .line 70: mul-float/2addr v9, v1
    .line 71: mul-float/2addr v10, v0
    .line 72: mul-float/2addr v10, v2
    .line 73: add-float/2addr v10, v9
    .line 74: div-float v6, v10, v3
    .line 76: invoke-static {v11, v12}, Lk0/q;->g(J)Ll0/d;
    .line 79: move-result-object v9
    .line 80: invoke-static {v5, v8, v6, v3, v9}, Landroidx/compose/ui/graphics/a;->a(FFFFLl0/d;)J
    .line 83: move-result-wide v9
    .line 84: return-wide v9
.end method

# direct methods
.method public static final j(Ljava/util/List;)I
    .registers 6

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 26
    .line 4: const/4 v2, 0
    .line 5: if-lt v0, v1, :cond_8
    .line 7: return v2
    .line 8: invoke-static {v5}, Ld2/b;->r0(Ljava/util/List;)I
    .line 11: move-result v0
    .line 12: const/4 v1, 1
    .line 13: if-ge v1, v0, :cond_37
    .line 15: invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 18: move-result-object v3
    .line 19: check-cast v3, Lk0/q;
    .line 21: iget-wide v3, v3, Lk0/q;->a:J
    .line 23: invoke-static {v3, v4}, Lk0/q;->e(J)F
    .line 26: move-result v3
    .line 27: const/4 v4, 0
    .line 28: cmpg-float v3, v3, v4
    .line 30: if-nez v3, :cond_34
    .line 32: add-int/lit8 v2, v2, 1
    .line 34: add-int/lit8 v1, v1, 1
    .line 36: goto :goto_13
    .line 37: return v2
.end method

# direct methods
.method public static final k(Lf0/p;Ld3/c;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "block"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/ui/graphics/BlockGraphicsLayerElement;
    .line 12: invoke-direct {v0, v2}, Landroidx/compose/ui/graphics/BlockGraphicsLayerElement;-><init>(Ld3/c;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

# direct methods
.method public static l(Lf0/p;FFFLk0/l0;ZI)Lf0/p;
    .registers 31

    .line 0: move-object/from16 v0, v24
    .line 2: move/from16 v1, v30
    .line 4: and-int/lit8 v2, v1, 1
    .line 6: const/high16 v3, 0x3f80
    .line 8: if-eqz v2, :cond_12
    .line 10: move v5, v3
    .line 11: goto :goto_14
    .line 12: move/from16 v5, v25
    .line 14: and-int/lit8 v2, v1, 2
    .line 16: if-eqz v2, :cond_20
    .line 18: move v6, v3
    .line 19: goto :goto_22
    .line 20: move/from16 v6, v26
    .line 22: and-int/lit8 v2, v1, 4
    .line 24: if-eqz v2, :cond_28
    .line 26: move v7, v3
    .line 27: goto :goto_30
    .line 28: move/from16 v7, v27
    .line 30: const/4 v8, 0
    .line 31: const/4 v9, 0
    .line 32: const/4 v10, 0
    .line 33: const/4 v11, 0
    .line 34: const/4 v12, 0
    .line 35: const/4 v13, 0
    .line 36: and-int/lit16 v2, v1, 512
    .line 38: if-eqz v2, :cond_44
    .line 40: const/high16 v2, 0x4100
    .line 42: move v14, v2
    .line 43: goto :goto_46
    .line 44: const/4 v2, 0
    .line 45: goto :goto_42
    .line 46: and-int/lit16 v2, v1, 1024
    .line 48: if-eqz v2, :cond_53
    .line 50: sget-wide v15, Lk0/s0;->b:J
    .line 52: goto :goto_55
    .line 53: const-wide/16 v15, 0
    .line 55: and-int/lit16 v2, v1, 2048
    .line 57: if-eqz v2, :cond_62
    .line 59: sget-object v2, Lk0/g0;->a:Lk0/f0;
    .line 61: goto :goto_64
    .line 62: move-object/from16 v2, v28
    .line 64: and-int/lit16 v3, v1, 4096
    .line 66: if-eqz v3, :cond_72
    .line 68: const/4 v3, 0
    .line 69: move/from16 v18, v3
    .line 71: goto :goto_74
    .line 72: move/from16 v18, v29
    .line 74: and-int/lit16 v3, v1, 16384
    .line 76: if-eqz v3, :cond_83
    .line 78: sget-wide v3, Lk0/x;->a:J
    .line 80: move-wide/from16 v19, v3
    .line 82: goto :goto_85
    .line 83: const-wide/16 v19, 0
    .line 85: const v3, 0x8000
    .line 88: and-int/2addr v1, v3
    .line 89: if-eqz v1, :cond_96
    .line 91: sget-wide v3, Lk0/x;->a:J
    .line 93: move-wide/from16 v21, v3
    .line 95: goto :goto_98
    .line 96: const-wide/16 v21, 0
    .line 98: const/16 v23, 0
    .line 100: const-string v1, "$this$graphicsLayer"
    .line 102: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 105: const-string v1, "shape"
    .line 107: invoke-static {v2, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 110: new-instance v1, Landroidx/compose/ui/graphics/GraphicsLayerElement;
    .line 112: move-object v4, v1
    .line 113: move-object/from16 v17, v2
    .line 115: invoke-direct/range {v4 .. v23}, Landroidx/compose/ui/graphics/GraphicsLayerElement;-><init>(FFFFFFFFFFJLk0/l0;ZJJI)V
    .line 118: invoke-interface {v0, v1}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 121: move-result-object v0
    .line 122: return-object v0
.end method

# direct methods
.method public static final m(JJF)J
    .registers 13

    .line 0: sget-object v0, Ll0/e;->t:Ll0/l;
    .line 2: invoke-static {v8, v9, v0}, Lk0/q;->b(JLl0/d;)J
    .line 5: move-result-wide v8
    .line 6: invoke-static {v10, v11, v0}, Lk0/q;->b(JLl0/d;)J
    .line 9: move-result-wide v1
    .line 10: invoke-static {v8, v9}, Lk0/q;->e(J)F
    .line 13: move-result v3
    .line 14: invoke-static {v8, v9}, Lk0/q;->i(J)F
    .line 17: move-result v4
    .line 18: invoke-static {v8, v9}, Lk0/q;->h(J)F
    .line 21: move-result v5
    .line 22: invoke-static {v8, v9}, Lk0/q;->f(J)F
    .line 25: move-result v8
    .line 26: invoke-static {v1, v2}, Lk0/q;->e(J)F
    .line 29: move-result v9
    .line 30: invoke-static {v1, v2}, Lk0/q;->i(J)F
    .line 33: move-result v6
    .line 34: invoke-static {v1, v2}, Lk0/q;->h(J)F
    .line 37: move-result v7
    .line 38: invoke-static {v1, v2}, Lk0/q;->f(J)F
    .line 41: move-result v1
    .line 42: invoke-static {v3, v9, v12}, Ld2/b;->G0(FFF)F
    .line 45: move-result v9
    .line 46: invoke-static {v4, v6, v12}, Ld2/b;->G0(FFF)F
    .line 49: move-result v2
    .line 50: invoke-static {v5, v7, v12}, Ld2/b;->G0(FFF)F
    .line 53: move-result v3
    .line 54: invoke-static {v8, v1, v12}, Ld2/b;->G0(FFF)F
    .line 57: move-result v8
    .line 58: invoke-static {v2, v3, v8, v9, v0}, Landroidx/compose/ui/graphics/a;->a(FFFFLl0/d;)J
    .line 61: move-result-wide v8
    .line 62: invoke-static {v10, v11}, Lk0/q;->g(J)Ll0/d;
    .line 65: move-result-object v10
    .line 66: invoke-static {v8, v9, v10}, Lk0/q;->b(JLl0/d;)J
    .line 69: move-result-wide v8
    .line 70: return-wide v8
.end method

# direct methods
.method public static final n(J)F
    .registers 9

    .line 0: invoke-static {v7, v8}, Lk0/q;->g(J)Ll0/d;
    .line 3: move-result-object v0
    .line 4: iget-wide v1, v0, Ll0/d;->b:J
    .line 6: sget-wide v3, Ll0/c;->a:J
    .line 8: invoke-static {v1, v2, v3, v4}, Ll0/c;->a(JJ)Z
    .line 11: move-result v1
    .line 12: if-eqz v1, :cond_81
    .line 14: check-cast v0, Ll0/q;
    .line 16: invoke-static {v7, v8}, Lk0/q;->i(J)F
    .line 19: move-result v1
    .line 20: float-to-double v1, v1
    .line 21: iget-object v0, v0, Ll0/q;->p:Ll0/m;
    .line 23: invoke-virtual {v0, v1, v2}, Ll0/m;->a(D)D
    .line 26: move-result-wide v1
    .line 27: invoke-static {v7, v8}, Lk0/q;->h(J)F
    .line 30: move-result v3
    .line 31: float-to-double v3, v3
    .line 32: invoke-virtual {v0, v3, v4}, Ll0/m;->a(D)D
    .line 35: move-result-wide v3
    .line 36: invoke-static {v7, v8}, Lk0/q;->f(J)F
    .line 39: move-result v7
    .line 40: float-to-double v7, v7
    .line 41: invoke-virtual {v0, v7, v8}, Ll0/m;->a(D)D
    .line 44: move-result-wide v7
    .line 45: const-wide v5, 0x3fcb367af9096bc
    .line 50: mul-double/2addr v1, v5
    .line 51: const-wide v5, 0x3fe6e2eb1c432ca5
    .line 56: mul-double/2addr v3, v5
    .line 57: add-double/2addr v3, v1
    .line 58: const-wide v0, 0x3fb27bb2fec56d5d
    .line 63: mul-double/2addr v7, v0
    .line 64: add-double/2addr v7, v3
    .line 65: double-to-float v7, v7
    .line 66: const/4 v8, 0
    .line 67: cmpg-float v0, v7, v8
    .line 69: if-gtz v0, :cond_73
    .line 71: move v7, v8
    .line 72: goto :goto_80
    .line 73: const/high16 v8, 0x3f80
    .line 75: cmpl-float v0, v7, v8
    .line 77: if-ltz v0, :cond_80
    .line 79: goto :goto_71
    .line 80: return v7
    .line 81: new-instance v7, Ljava/lang/StringBuilder;
    .line 83: const-string v8, "The specified color must be encoded in an RGB color space. The supplied color space is "
    .line 85: invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 88: iget-wide v0, v0, Ll0/d;->b:J
    .line 90: invoke-static {v0, v1}, Ll0/c;->b(J)Ljava/lang/String;
    .line 93: move-result-object v8
    .line 94: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 97: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 100: move-result-object v7
    .line 101: new-instance v8, Ljava/lang/IllegalArgumentException;
    .line 103: invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 106: move-result-object v7
    .line 107: invoke-direct {v8, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 110: throw v8
.end method

# direct methods
.method public static final o(ILjava/util/List;)[I
    .registers 10

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 26
    .line 4: const/4 v2, 0
    .line 5: if-lt v0, v1, :cond_33
    .line 7: invoke-interface {v9}, Ljava/util/List;->size()I
    .line 10: move-result v8
    .line 11: new-array v0, v8, [I
    .line 13: if-ge v2, v8, :cond_32
    .line 15: invoke-interface {v9, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 18: move-result-object v1
    .line 19: check-cast v1, Lk0/q;
    .line 21: iget-wide v3, v1, Lk0/q;->a:J
    .line 23: invoke-static {v3, v4}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 26: move-result v1
    .line 27: aput v1, v0, v2
    .line 29: add-int/lit8 v2, v2, 1
    .line 31: goto :goto_13
    .line 32: return-object v0
    .line 33: invoke-interface {v9}, Ljava/util/List;->size()I
    .line 36: move-result v0
    .line 37: add-int/2addr v0, v8
    .line 38: new-array v8, v0, [I
    .line 40: invoke-static {v9}, Ld2/b;->r0(Ljava/util/List;)I
    .line 43: move-result v0
    .line 44: invoke-interface {v9}, Ljava/util/List;->size()I
    .line 47: move-result v1
    .line 48: move v3, v2
    .line 49: if-ge v2, v1, :cond_175
    .line 51: invoke-interface {v9, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 54: move-result-object v4
    .line 55: check-cast v4, Lk0/q;
    .line 57: iget-wide v4, v4, Lk0/q;->a:J
    .line 59: invoke-static {v4, v5}, Lk0/q;->e(J)F
    .line 62: move-result v6
    .line 63: const/4 v7, 0
    .line 64: cmpg-float v6, v6, v7
    .line 66: if-nez v6, :cond_163
    .line 68: if-nez v2, :cond_93
    .line 70: add-int/lit8 v4, v3, 1
    .line 72: const/4 v5, 1
    .line 73: invoke-interface {v9, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 76: move-result-object v5
    .line 77: check-cast v5, Lk0/q;
    .line 79: iget-wide v5, v5, Lk0/q;->a:J
    .line 81: invoke-static {v5, v6, v7}, Lk0/q;->c(JF)J
    .line 84: move-result-wide v5
    .line 85: invoke-static {v5, v6}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 88: move-result v5
    .line 89: aput v5, v8, v3
    .line 91: move v3, v4
    .line 92: goto :goto_172
    .line 93: if-ne v2, v0, :cond_118
    .line 95: add-int/lit8 v4, v3, 1
    .line 97: add-int/lit8 v5, v2, -1
    .line 99: invoke-interface {v9, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 102: move-result-object v5
    .line 103: check-cast v5, Lk0/q;
    .line 105: iget-wide v5, v5, Lk0/q;->a:J
    .line 107: invoke-static {v5, v6, v7}, Lk0/q;->c(JF)J
    .line 110: move-result-wide v5
    .line 111: invoke-static {v5, v6}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 114: move-result v5
    .line 115: aput v5, v8, v3
    .line 117: goto :goto_91
    .line 118: add-int/lit8 v4, v2, -1
    .line 120: invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 123: move-result-object v4
    .line 124: check-cast v4, Lk0/q;
    .line 126: iget-wide v4, v4, Lk0/q;->a:J
    .line 128: add-int/lit8 v6, v3, 1
    .line 130: invoke-static {v4, v5, v7}, Lk0/q;->c(JF)J
    .line 133: move-result-wide v4
    .line 134: invoke-static {v4, v5}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 137: move-result v4
    .line 138: aput v4, v8, v3
    .line 140: add-int/lit8 v4, v2, 1
    .line 142: invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 145: move-result-object v4
    .line 146: check-cast v4, Lk0/q;
    .line 148: iget-wide v4, v4, Lk0/q;->a:J
    .line 150: add-int/lit8 v3, v3, 2
    .line 152: invoke-static {v4, v5, v7}, Lk0/q;->c(JF)J
    .line 155: move-result-wide v4
    .line 156: invoke-static {v4, v5}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 159: move-result v4
    .line 160: aput v4, v8, v6
    .line 162: goto :goto_172
    .line 163: add-int/lit8 v6, v3, 1
    .line 165: invoke-static {v4, v5}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 168: move-result v4
    .line 169: aput v4, v8, v3
    .line 171: move v3, v6
    .line 172: add-int/lit8 v2, v2, 1
    .line 174: goto :goto_49
    .line 175: return-object v8
.end method

# direct methods
.method public static final p(Ljava/util/List;Ljava/util/List;I)[F
    .registers 11

    .line 0: const/4 v0, 0
    .line 1: if-nez v10, :cond_39
    .line 3: if-eqz v8, :cond_37
    .line 5: invoke-interface {v8}, Ljava/util/Collection;->size()I
    .line 8: move-result v9
    .line 9: new-array v9, v9, [F
    .line 11: invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 14: move-result-object v8
    .line 15: invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z
    .line 18: move-result v10
    .line 19: if-eqz v10, :cond_38
    .line 21: invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 24: move-result-object v10
    .line 25: check-cast v10, Ljava/lang/Number;
    .line 27: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 30: move-result v10
    .line 31: add-int/lit8 v1, v0, 1
    .line 33: aput v10, v9, v0
    .line 35: move v0, v1
    .line 36: goto :goto_15
    .line 37: const/4 v9, 0
    .line 38: return-object v9
    .line 39: invoke-interface {v9}, Ljava/util/List;->size()I
    .line 42: move-result v1
    .line 43: add-int/2addr v1, v10
    .line 44: new-array v10, v1, [F
    .line 46: const/4 v1, 0
    .line 47: if-eqz v8, :cond_60
    .line 49: invoke-interface {v8, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 52: move-result-object v2
    .line 53: check-cast v2, Ljava/lang/Number;
    .line 55: invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F
    .line 58: move-result v2
    .line 59: goto :goto_61
    .line 60: move v2, v1
    .line 61: aput v2, v10, v0
    .line 63: invoke-static {v9}, Ld2/b;->r0(Ljava/util/List;)I
    .line 66: move-result v0
    .line 67: const/4 v2, 1
    .line 68: move v3, v2
    .line 69: if-ge v2, v0, :cond_120
    .line 71: invoke-interface {v9, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 74: move-result-object v4
    .line 75: check-cast v4, Lk0/q;
    .line 77: iget-wide v4, v4, Lk0/q;->a:J
    .line 79: if-eqz v8, :cond_92
    .line 81: invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 84: move-result-object v6
    .line 85: check-cast v6, Ljava/lang/Number;
    .line 87: invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F
    .line 90: move-result v6
    .line 91: goto :goto_99
    .line 92: int-to-float v6, v2
    .line 93: invoke-static {v9}, Ld2/b;->r0(Ljava/util/List;)I
    .line 96: move-result v7
    .line 97: int-to-float v7, v7
    .line 98: div-float/2addr v6, v7
    .line 99: add-int/lit8 v7, v3, 1
    .line 101: aput v6, v10, v3
    .line 103: invoke-static {v4, v5}, Lk0/q;->e(J)F
    .line 106: move-result v4
    .line 107: cmpg-float v4, v4, v1
    .line 109: if-nez v4, :cond_116
    .line 111: add-int/lit8 v3, v3, 2
    .line 113: aput v6, v10, v7
    .line 115: goto :goto_117
    .line 116: move v3, v7
    .line 117: add-int/lit8 v2, v2, 1
    .line 119: goto :goto_69
    .line 120: if-eqz v8, :cond_137
    .line 122: invoke-static {v9}, Ld2/b;->r0(Ljava/util/List;)I
    .line 125: move-result v9
    .line 126: invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 129: move-result-object v8
    .line 130: check-cast v8, Ljava/lang/Number;
    .line 132: invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F
    .line 135: move-result v8
    .line 136: goto :goto_139
    .line 137: const/high16 v8, 0x3f80
    .line 139: aput v8, v10, v3
    .line 141: return-object v10
.end method

# direct methods
.method public static final q(Landroid/graphics/Matrix;[F)V
    .registers 21

    .line 0: move-object/from16 v0, v20
    .line 2: const-string v1, "$this$setFrom"
    .line 4: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: const-string v1, "matrix"
    .line 9: move-object/from16 v2, v19
    .line 11: invoke-static {v2, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: invoke-virtual/range {v19 .. v20}, Landroid/graphics/Matrix;->getValues([F)V
    .line 17: const/4 v1, 0
    .line 18: aget v2, v0, v1
    .line 20: const/4 v3, 1
    .line 21: aget v4, v0, v3
    .line 23: const/4 v5, 2
    .line 24: aget v6, v0, v5
    .line 26: const/4 v7, 3
    .line 27: aget v8, v0, v7
    .line 29: const/4 v9, 4
    .line 30: aget v10, v0, v9
    .line 32: const/4 v11, 5
    .line 33: aget v12, v0, v11
    .line 35: const/4 v13, 6
    .line 36: aget v14, v0, v13
    .line 38: const/4 v15, 7
    .line 39: aget v16, v0, v15
    .line 41: const/16 v17, 8
    .line 43: aget v18, v0, v17
    .line 45: aput v2, v0, v1
    .line 47: aput v8, v0, v3
    .line 49: const/4 v1, 0
    .line 50: aput v1, v0, v5
    .line 52: aput v14, v0, v7
    .line 54: aput v4, v0, v9
    .line 56: aput v10, v0, v11
    .line 58: aput v1, v0, v13
    .line 60: aput v16, v0, v15
    .line 62: aput v1, v0, v17
    .line 64: const/16 v2, 9
    .line 66: aput v1, v0, v2
    .line 68: const/16 v2, 10
    .line 70: const/high16 v3, 0x3f80
    .line 72: aput v3, v0, v2
    .line 74: const/16 v2, 11
    .line 76: aput v1, v0, v2
    .line 78: const/16 v2, 12
    .line 80: aput v6, v0, v2
    .line 82: const/16 v2, 13
    .line 84: aput v12, v0, v2
    .line 86: const/16 v2, 14
    .line 88: aput v1, v0, v2
    .line 90: const/16 v1, 15
    .line 92: aput v18, v0, v1
    .line 94: return-void
.end method

# direct methods
.method public static final r(I)Landroid/graphics/BlendMode;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_13
    .line 7: invoke-static {}, Lg1/q;->a()Landroid/graphics/BlendMode;
    .line 10: move-result-object v1
    .line 11: goto/16 :goto_394
    .line 13: const/4 v0, 1
    .line 14: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 17: move-result v0
    .line 18: if-eqz v0, :cond_26
    .line 20: invoke-static {}, Lg1/q;->n()Landroid/graphics/BlendMode;
    .line 23: move-result-object v1
    .line 24: goto/16 :goto_394
    .line 26: const/4 v0, 2
    .line 27: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 30: move-result v0
    .line 31: if-eqz v0, :cond_39
    .line 33: invoke-static {}, Lg1/q;->h()Landroid/graphics/BlendMode;
    .line 36: move-result-object v1
    .line 37: goto/16 :goto_394
    .line 39: const/4 v0, 3
    .line 40: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 43: move-result v0
    .line 44: if-eqz v0, :cond_52
    .line 46: invoke-static {}, Lg1/q;->g()Landroid/graphics/BlendMode;
    .line 49: move-result-object v1
    .line 50: goto/16 :goto_394
    .line 52: const/4 v0, 4
    .line 53: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 56: move-result v0
    .line 57: if-eqz v0, :cond_65
    .line 59: invoke-static {}, Lg1/q;->i()Landroid/graphics/BlendMode;
    .line 62: move-result-object v1
    .line 63: goto/16 :goto_394
    .line 65: const/4 v0, 5
    .line 66: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 69: move-result v0
    .line 70: if-eqz v0, :cond_78
    .line 72: invoke-static {}, Lg1/q;->j()Landroid/graphics/BlendMode;
    .line 75: move-result-object v1
    .line 76: goto/16 :goto_394
    .line 78: const/4 v0, 6
    .line 79: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 82: move-result v0
    .line 83: if-eqz v0, :cond_91
    .line 85: invoke-static {}, Lg1/q;->k()Landroid/graphics/BlendMode;
    .line 88: move-result-object v1
    .line 89: goto/16 :goto_394
    .line 91: const/4 v0, 7
    .line 92: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 95: move-result v0
    .line 96: if-eqz v0, :cond_104
    .line 98: invoke-static {}, Lg1/q;->l()Landroid/graphics/BlendMode;
    .line 101: move-result-object v1
    .line 102: goto/16 :goto_394
    .line 104: const/16 v0, 8
    .line 106: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 109: move-result v0
    .line 110: if-eqz v0, :cond_118
    .line 112: invoke-static {}, Lg1/q;->m()Landroid/graphics/BlendMode;
    .line 115: move-result-object v1
    .line 116: goto/16 :goto_394
    .line 118: const/16 v0, 9
    .line 120: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 123: move-result v0
    .line 124: if-eqz v0, :cond_132
    .line 126: invoke-static {}, Lg1/q;->o()Landroid/graphics/BlendMode;
    .line 129: move-result-object v1
    .line 130: goto/16 :goto_394
    .line 132: const/16 v0, 10
    .line 134: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 137: move-result v0
    .line 138: if-eqz v0, :cond_146
    .line 140: invoke-static {}, Lg1/q;->e()Landroid/graphics/BlendMode;
    .line 143: move-result-object v1
    .line 144: goto/16 :goto_394
    .line 146: const/16 v0, 11
    .line 148: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 151: move-result v0
    .line 152: if-eqz v0, :cond_160
    .line 154: invoke-static {}, Lg1/q;->p()Landroid/graphics/BlendMode;
    .line 157: move-result-object v1
    .line 158: goto/16 :goto_394
    .line 160: const/16 v0, 12
    .line 162: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 165: move-result v0
    .line 166: if-eqz v0, :cond_174
    .line 168: invoke-static {}, Lg1/q;->q()Landroid/graphics/BlendMode;
    .line 171: move-result-object v1
    .line 172: goto/16 :goto_394
    .line 174: const/16 v0, 13
    .line 176: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 179: move-result v0
    .line 180: if-eqz v0, :cond_188
    .line 182: invoke-static {}, Lg1/q;->r()Landroid/graphics/BlendMode;
    .line 185: move-result-object v1
    .line 186: goto/16 :goto_394
    .line 188: const/16 v0, 14
    .line 190: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 193: move-result v0
    .line 194: if-eqz v0, :cond_202
    .line 196: invoke-static {}, Lg1/q;->s()Landroid/graphics/BlendMode;
    .line 199: move-result-object v1
    .line 200: goto/16 :goto_394
    .line 202: const/16 v0, 15
    .line 204: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 207: move-result v0
    .line 208: if-eqz v0, :cond_216
    .line 210: invoke-static {}, Lg1/q;->t()Landroid/graphics/BlendMode;
    .line 213: move-result-object v1
    .line 214: goto/16 :goto_394
    .line 216: const/16 v0, 16
    .line 218: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 221: move-result v0
    .line 222: if-eqz v0, :cond_230
    .line 224: invoke-static {}, Lg1/q;->u()Landroid/graphics/BlendMode;
    .line 227: move-result-object v1
    .line 228: goto/16 :goto_394
    .line 230: const/16 v0, 17
    .line 232: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 235: move-result v0
    .line 236: if-eqz v0, :cond_244
    .line 238: invoke-static {}, Lg1/q;->v()Landroid/graphics/BlendMode;
    .line 241: move-result-object v1
    .line 242: goto/16 :goto_394
    .line 244: const/16 v0, 18
    .line 246: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 249: move-result v0
    .line 250: if-eqz v0, :cond_258
    .line 252: invoke-static {}, Lg1/q;->w()Landroid/graphics/BlendMode;
    .line 255: move-result-object v1
    .line 256: goto/16 :goto_394
    .line 258: const/16 v0, 19
    .line 260: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 263: move-result v0
    .line 264: if-eqz v0, :cond_272
    .line 266: invoke-static {}, Lg1/q;->c()Landroid/graphics/BlendMode;
    .line 269: move-result-object v1
    .line 270: goto/16 :goto_394
    .line 272: const/16 v0, 20
    .line 274: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 277: move-result v0
    .line 278: if-eqz v0, :cond_286
    .line 280: invoke-static {}, Lg1/q;->x()Landroid/graphics/BlendMode;
    .line 283: move-result-object v1
    .line 284: goto/16 :goto_394
    .line 286: const/16 v0, 21
    .line 288: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 291: move-result v0
    .line 292: if-eqz v0, :cond_299
    .line 294: invoke-static {}, Lg1/q;->y()Landroid/graphics/BlendMode;
    .line 297: move-result-object v1
    .line 298: goto :goto_394
    .line 299: const/16 v0, 22
    .line 301: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 304: move-result v0
    .line 305: if-eqz v0, :cond_312
    .line 307: invoke-static {}, Lg1/q;->z()Landroid/graphics/BlendMode;
    .line 310: move-result-object v1
    .line 311: goto :goto_394
    .line 312: const/16 v0, 23
    .line 314: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 317: move-result v0
    .line 318: if-eqz v0, :cond_325
    .line 320: invoke-static {}, Lg1/q;->A()Landroid/graphics/BlendMode;
    .line 323: move-result-object v1
    .line 324: goto :goto_394
    .line 325: const/16 v0, 24
    .line 327: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 330: move-result v0
    .line 331: if-eqz v0, :cond_338
    .line 333: invoke-static {}, Lg1/q;->B()Landroid/graphics/BlendMode;
    .line 336: move-result-object v1
    .line 337: goto :goto_394
    .line 338: const/16 v0, 25
    .line 340: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 343: move-result v0
    .line 344: if-eqz v0, :cond_351
    .line 346: invoke-static {}, Lg1/q;->C()Landroid/graphics/BlendMode;
    .line 349: move-result-object v1
    .line 350: goto :goto_394
    .line 351: const/16 v0, 26
    .line 353: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 356: move-result v0
    .line 357: if-eqz v0, :cond_364
    .line 359: invoke-static {}, Lg1/q;->D()Landroid/graphics/BlendMode;
    .line 362: move-result-object v1
    .line 363: goto :goto_394
    .line 364: const/16 v0, 27
    .line 366: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 369: move-result v0
    .line 370: if-eqz v0, :cond_377
    .line 372: invoke-static {}, Lg1/q;->d()Landroid/graphics/BlendMode;
    .line 375: move-result-object v1
    .line 376: goto :goto_394
    .line 377: const/16 v0, 28
    .line 379: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 382: move-result v1
    .line 383: if-eqz v1, :cond_390
    .line 385: invoke-static {}, Lg1/q;->f()Landroid/graphics/BlendMode;
    .line 388: move-result-object v1
    .line 389: goto :goto_394
    .line 390: invoke-static {}, Lg1/q;->g()Landroid/graphics/BlendMode;
    .line 393: move-result-object v1
    .line 394: return-object v1
.end method

# direct methods
.method public static final s(I)Landroid/graphics/Shader$TileMode;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v1, v0}, Lk0/g0;->e(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: sget-object v1, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;
    .line 9: goto :goto_55
    .line 10: const/4 v0, 1
    .line 11: invoke-static {v1, v0}, Lk0/g0;->e(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: sget-object v1, Landroid/graphics/Shader$TileMode;->REPEAT:Landroid/graphics/Shader$TileMode;
    .line 19: goto :goto_55
    .line 20: const/4 v0, 2
    .line 21: invoke-static {v1, v0}, Lk0/g0;->e(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_30
    .line 27: sget-object v1, Landroid/graphics/Shader$TileMode;->MIRROR:Landroid/graphics/Shader$TileMode;
    .line 29: goto :goto_55
    .line 30: const/4 v0, 3
    .line 31: invoke-static {v1, v0}, Lk0/g0;->e(II)Z
    .line 34: move-result v1
    .line 35: if-eqz v1, :cond_53
    .line 37: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 39: const/16 v0, 31
    .line 41: if-lt v1, v0, :cond_50
    .line 43: sget-object v1, Lk0/r0;->a:Lk0/r0;
    .line 45: invoke-virtual {v1}, Lk0/r0;->b()Landroid/graphics/Shader$TileMode;
    .line 48: move-result-object v1
    .line 49: goto :goto_55
    .line 50: sget-object v1, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;
    .line 52: goto :goto_55
    .line 53: sget-object v1, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;
    .line 55: return-object v1
.end method

# direct methods
.method public static final t(J)I
    .registers 3

    .line 0: sget-object v0, Ll0/e;->a:[F
    .line 2: sget-object v0, Ll0/e;->c:Ll0/q;
    .line 4: invoke-static {v1, v2, v0}, Lk0/q;->b(JLl0/d;)J
    .line 7: move-result-wide v1
    .line 8: const/16 v0, 32
    .line 10: ushr-long/2addr v1, v0
    .line 11: long-to-int v1, v1
    .line 12: return v1
.end method

# direct methods
.method public static final u(I)Landroid/graphics/Bitmap$Config;
    .registers 4

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v3, v0}, Lk0/g0;->d(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;
    .line 9: goto :goto_64
    .line 10: const/4 v0, 1
    .line 11: invoke-static {v3, v0}, Lk0/g0;->d(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: sget-object v3, Landroid/graphics/Bitmap$Config;->ALPHA_8:Landroid/graphics/Bitmap$Config;
    .line 19: goto :goto_64
    .line 20: const/4 v0, 2
    .line 21: invoke-static {v3, v0}, Lk0/g0;->d(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_30
    .line 27: sget-object v3, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;
    .line 29: goto :goto_64
    .line 30: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 32: const/16 v1, 26
    .line 34: if-lt v0, v1, :cond_48
    .line 36: const/4 v2, 3
    .line 37: invoke-static {v3, v2}, Lk0/g0;->d(II)Z
    .line 40: move-result v2
    .line 41: if-eqz v2, :cond_48
    .line 43: invoke-static {}, Lg0/e;->d()Landroid/graphics/Bitmap$Config;
    .line 46: move-result-object v3
    .line 47: goto :goto_64
    .line 48: if-lt v0, v1, :cond_62
    .line 50: const/4 v0, 4
    .line 51: invoke-static {v3, v0}, Lk0/g0;->d(II)Z
    .line 54: move-result v3
    .line 55: if-eqz v3, :cond_62
    .line 57: invoke-static {}, Lg0/e;->u()Landroid/graphics/Bitmap$Config;
    .line 60: move-result-object v3
    .line 61: goto :goto_64
    .line 62: sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;
    .line 64: return-object v3
.end method

# direct methods
.method public static final v(I)Landroid/graphics/PorterDuff$Mode;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_11
    .line 7: sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;
    .line 9: goto/16 :goto_201
    .line 11: const/4 v0, 1
    .line 12: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 15: move-result v0
    .line 16: if-eqz v0, :cond_22
    .line 18: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC:Landroid/graphics/PorterDuff$Mode;
    .line 20: goto/16 :goto_201
    .line 22: const/4 v0, 2
    .line 23: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 26: move-result v0
    .line 27: if-eqz v0, :cond_33
    .line 29: sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST:Landroid/graphics/PorterDuff$Mode;
    .line 31: goto/16 :goto_201
    .line 33: const/4 v0, 3
    .line 34: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 37: move-result v0
    .line 38: if-eqz v0, :cond_44
    .line 40: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_OVER:Landroid/graphics/PorterDuff$Mode;
    .line 42: goto/16 :goto_201
    .line 44: const/4 v0, 4
    .line 45: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 48: move-result v0
    .line 49: if-eqz v0, :cond_55
    .line 51: sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST_OVER:Landroid/graphics/PorterDuff$Mode;
    .line 53: goto/16 :goto_201
    .line 55: const/4 v0, 5
    .line 56: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 59: move-result v0
    .line 60: if-eqz v0, :cond_66
    .line 62: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;
    .line 64: goto/16 :goto_201
    .line 66: const/4 v0, 6
    .line 67: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 70: move-result v0
    .line 71: if-eqz v0, :cond_77
    .line 73: sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST_IN:Landroid/graphics/PorterDuff$Mode;
    .line 75: goto/16 :goto_201
    .line 77: const/4 v0, 7
    .line 78: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 81: move-result v0
    .line 82: if-eqz v0, :cond_88
    .line 84: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_OUT:Landroid/graphics/PorterDuff$Mode;
    .line 86: goto/16 :goto_201
    .line 88: const/16 v0, 8
    .line 90: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 93: move-result v0
    .line 94: if-eqz v0, :cond_100
    .line 96: sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST_OUT:Landroid/graphics/PorterDuff$Mode;
    .line 98: goto/16 :goto_201
    .line 100: const/16 v0, 9
    .line 102: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 105: move-result v0
    .line 106: if-eqz v0, :cond_111
    .line 108: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;
    .line 110: goto :goto_201
    .line 111: const/16 v0, 10
    .line 113: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 116: move-result v0
    .line 117: if-eqz v0, :cond_122
    .line 119: sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST_ATOP:Landroid/graphics/PorterDuff$Mode;
    .line 121: goto :goto_201
    .line 122: const/16 v0, 11
    .line 124: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 127: move-result v0
    .line 128: if-eqz v0, :cond_133
    .line 130: sget-object v1, Landroid/graphics/PorterDuff$Mode;->XOR:Landroid/graphics/PorterDuff$Mode;
    .line 132: goto :goto_201
    .line 133: const/16 v0, 12
    .line 135: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 138: move-result v0
    .line 139: if-eqz v0, :cond_144
    .line 141: sget-object v1, Landroid/graphics/PorterDuff$Mode;->ADD:Landroid/graphics/PorterDuff$Mode;
    .line 143: goto :goto_201
    .line 144: const/16 v0, 14
    .line 146: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 149: move-result v0
    .line 150: if-eqz v0, :cond_155
    .line 152: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SCREEN:Landroid/graphics/PorterDuff$Mode;
    .line 154: goto :goto_201
    .line 155: const/16 v0, 15
    .line 157: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 160: move-result v0
    .line 161: if-eqz v0, :cond_166
    .line 163: sget-object v1, Landroid/graphics/PorterDuff$Mode;->OVERLAY:Landroid/graphics/PorterDuff$Mode;
    .line 165: goto :goto_201
    .line 166: const/16 v0, 16
    .line 168: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 171: move-result v0
    .line 172: if-eqz v0, :cond_177
    .line 174: sget-object v1, Landroid/graphics/PorterDuff$Mode;->DARKEN:Landroid/graphics/PorterDuff$Mode;
    .line 176: goto :goto_201
    .line 177: const/16 v0, 17
    .line 179: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 182: move-result v0
    .line 183: if-eqz v0, :cond_188
    .line 185: sget-object v1, Landroid/graphics/PorterDuff$Mode;->LIGHTEN:Landroid/graphics/PorterDuff$Mode;
    .line 187: goto :goto_201
    .line 188: const/16 v0, 13
    .line 190: invoke-static {v1, v0}, Lk0/i;->a(II)Z
    .line 193: move-result v1
    .line 194: if-eqz v1, :cond_199
    .line 196: sget-object v1, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;
    .line 198: goto :goto_201
    .line 199: sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_OVER:Landroid/graphics/PorterDuff$Mode;
    .line 201: return-object v1
.end method

# direct methods
.method public static final w(Ljava/util/List;Ljava/util/List;)V
    .registers 2

    .line 0: if-nez v1, :cond_18
    .line 2: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 5: move-result v0
    .line 6: const/4 v1, 2
    .line 7: if-lt v0, v1, :cond_10
    .line 9: goto :goto_28
    .line 10: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 12: const-string v1, "colors must have length of at least 2 if colorStops is omitted."
    .line 14: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 17: throw v0
    .line 18: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 21: move-result v0
    .line 22: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 25: move-result v1
    .line 26: if-ne v0, v1, :cond_29
    .line 28: return-void
    .line 29: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 31: const-string v1, "colors and colorStops arguments must have equal length."
    .line 33: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 36: throw v0
.end method

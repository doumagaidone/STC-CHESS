.class public abstract Landroidx/compose/ui/layout/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(FF)J
    .registers 6

    .line 0: invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v4
    .line 4: int-to-long v0, v4
    .line 5: invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 8: move-result v4
    .line 9: int-to-long v4, v4
    .line 10: const/16 v2, 32
    .line 12: shl-long/2addr v0, v2
    .line 13: const-wide v2, 0x00ffffffff
    .line 18: and-long/2addr v4, v2
    .line 19: or-long/2addr v4, v0
    .line 20: sget v0, Lx0/p0;->b:I
    .line 22: return-wide v4
.end method

# direct methods
.method public static final b(Lz0/w;)Lj0/d;
    .registers 6

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v5}, Lz0/a1;->T()Lx0/q;
    .line 8: move-result-object v0
    .line 9: if-eqz v0, :cond_19
    .line 11: const/4 v1, 1
    .line 12: check-cast v0, Lz0/a1;
    .line 14: invoke-virtual {v0, v5, v1}, Lz0/a1;->D(Lx0/q;Z)Lj0/d;
    .line 17: move-result-object v5
    .line 18: goto :goto_42
    .line 19: new-instance v0, Lj0/d;
    .line 21: iget-wide v1, v5, Lx0/l0;->k:J
    .line 23: const/16 v5, 32
    .line 25: shr-long v3, v1, v5
    .line 27: long-to-int v5, v3
    .line 28: int-to-float v5, v5
    .line 29: const-wide v3, 0x00ffffffff
    .line 34: and-long/2addr v1, v3
    .line 35: long-to-int v1, v1
    .line 36: int-to-float v1, v1
    .line 37: const/4 v2, 0
    .line 38: invoke-direct {v0, v2, v2, v5, v1}, Lj0/d;-><init>(FFFF)V
    .line 41: move-object v5, v0
    .line 42: return-object v5
.end method

# direct methods
.method public static final c(Lx0/q;)Lj0/d;
    .registers 18

    .line 0: invoke-static/range {v17 .. v17}, Landroidx/compose/ui/layout/a;->d(Lx0/q;)Lx0/q;
    .line 3: move-result-object v0
    .line 4: invoke-static/range {v17 .. v17}, Landroidx/compose/ui/layout/a;->d(Lx0/q;)Lx0/q;
    .line 7: move-result-object v1
    .line 8: const/4 v2, 1
    .line 9: move-object/from16 v3, v17
    .line 11: invoke-interface {v1, v3, v2}, Lx0/q;->D(Lx0/q;Z)Lj0/d;
    .line 14: move-result-object v1
    .line 15: invoke-interface {v0}, Lx0/q;->f()J
    .line 18: move-result-wide v3
    .line 19: const/16 v5, 32
    .line 21: shr-long/2addr v3, v5
    .line 22: long-to-int v3, v3
    .line 23: int-to-float v3, v3
    .line 24: invoke-interface {v0}, Lx0/q;->f()J
    .line 27: move-result-wide v4
    .line 28: const-wide v6, 0x00ffffffff
    .line 33: and-long/2addr v4, v6
    .line 34: long-to-int v4, v4
    .line 35: int-to-float v4, v4
    .line 36: iget v5, v1, Lj0/d;->a:F
    .line 38: const/4 v6, 0
    .line 39: invoke-static {v5, v6, v3}, Ld2/b;->F(FFF)F
    .line 42: move-result v5
    .line 43: iget v7, v1, Lj0/d;->b:F
    .line 45: invoke-static {v7, v6, v4}, Ld2/b;->F(FFF)F
    .line 48: move-result v7
    .line 49: iget v8, v1, Lj0/d;->c:F
    .line 51: invoke-static {v8, v6, v3}, Ld2/b;->F(FFF)F
    .line 54: move-result v3
    .line 55: iget v1, v1, Lj0/d;->d:F
    .line 57: invoke-static {v1, v6, v4}, Ld2/b;->F(FFF)F
    .line 60: move-result v1
    .line 61: cmpg-float v4, v5, v3
    .line 63: if-nez v4, :cond_66
    .line 65: goto :goto_70
    .line 66: cmpg-float v4, v7, v1
    .line 68: if-nez v4, :cond_73
    .line 70: sget-object v0, Lj0/d;->e:Lj0/d;
    .line 72: return-object v0
    .line 73: invoke-static {v5, v7}, Ln3/a0;->g(FF)J
    .line 76: move-result-wide v8
    .line 77: invoke-interface {v0, v8, v9}, Lx0/q;->x(J)J
    .line 80: move-result-wide v8
    .line 81: invoke-static {v3, v7}, Ln3/a0;->g(FF)J
    .line 84: move-result-wide v6
    .line 85: invoke-interface {v0, v6, v7}, Lx0/q;->x(J)J
    .line 88: move-result-wide v6
    .line 89: invoke-static {v3, v1}, Ln3/a0;->g(FF)J
    .line 92: move-result-wide v3
    .line 93: invoke-interface {v0, v3, v4}, Lx0/q;->x(J)J
    .line 96: move-result-wide v3
    .line 97: invoke-static {v5, v1}, Ln3/a0;->g(FF)J
    .line 100: move-result-wide v10
    .line 101: invoke-interface {v0, v10, v11}, Lx0/q;->x(J)J
    .line 104: move-result-wide v0
    .line 105: invoke-static {v8, v9}, Lj0/c;->c(J)F
    .line 108: move-result v5
    .line 109: const/4 v10, 3
    .line 110: new-array v11, v10, [F
    .line 112: invoke-static {v6, v7}, Lj0/c;->c(J)F
    .line 115: move-result v12
    .line 116: const/4 v13, 0
    .line 117: aput v12, v11, v13
    .line 119: invoke-static {v0, v1}, Lj0/c;->c(J)F
    .line 122: move-result v12
    .line 123: aput v12, v11, v2
    .line 125: invoke-static {v3, v4}, Lj0/c;->c(J)F
    .line 128: move-result v12
    .line 129: const/4 v14, 2
    .line 130: aput v12, v11, v14
    .line 132: move v12, v13
    .line 133: if-ge v12, v10, :cond_144
    .line 135: aget v15, v11, v12
    .line 137: invoke-static {v5, v15}, Ljava/lang/Math;->min(FF)F
    .line 140: move-result v5
    .line 141: add-int/lit8 v12, v12, 1
    .line 143: goto :goto_133
    .line 144: invoke-static {v8, v9}, Lj0/c;->d(J)F
    .line 147: move-result v11
    .line 148: new-array v12, v10, [F
    .line 150: invoke-static {v6, v7}, Lj0/c;->d(J)F
    .line 153: move-result v15
    .line 154: aput v15, v12, v13
    .line 156: invoke-static {v0, v1}, Lj0/c;->d(J)F
    .line 159: move-result v15
    .line 160: aput v15, v12, v2
    .line 162: invoke-static {v3, v4}, Lj0/c;->d(J)F
    .line 165: move-result v15
    .line 166: aput v15, v12, v14
    .line 168: move v15, v13
    .line 169: if-ge v15, v10, :cond_181
    .line 171: aget v14, v12, v15
    .line 173: invoke-static {v11, v14}, Ljava/lang/Math;->min(FF)F
    .line 176: move-result v11
    .line 177: add-int/lit8 v15, v15, 1
    .line 179: const/4 v14, 2
    .line 180: goto :goto_169
    .line 181: invoke-static {v8, v9}, Lj0/c;->c(J)F
    .line 184: move-result v12
    .line 185: new-array v14, v10, [F
    .line 187: invoke-static {v6, v7}, Lj0/c;->c(J)F
    .line 190: move-result v15
    .line 191: aput v15, v14, v13
    .line 193: invoke-static {v0, v1}, Lj0/c;->c(J)F
    .line 196: move-result v15
    .line 197: aput v15, v14, v2
    .line 199: invoke-static {v3, v4}, Lj0/c;->c(J)F
    .line 202: move-result v15
    .line 203: const/16 v16, 2
    .line 205: aput v15, v14, v16
    .line 207: move v15, v13
    .line 208: if-ge v15, v10, :cond_220
    .line 210: aget v2, v14, v15
    .line 212: invoke-static {v12, v2}, Ljava/lang/Math;->max(FF)F
    .line 215: move-result v12
    .line 216: add-int/lit8 v15, v15, 1
    .line 218: const/4 v2, 1
    .line 219: goto :goto_208
    .line 220: invoke-static {v8, v9}, Lj0/c;->d(J)F
    .line 223: move-result v2
    .line 224: new-array v8, v10, [F
    .line 226: invoke-static {v6, v7}, Lj0/c;->d(J)F
    .line 229: move-result v6
    .line 230: aput v6, v8, v13
    .line 232: invoke-static {v0, v1}, Lj0/c;->d(J)F
    .line 235: move-result v0
    .line 236: const/4 v1, 1
    .line 237: aput v0, v8, v1
    .line 239: invoke-static {v3, v4}, Lj0/c;->d(J)F
    .line 242: move-result v0
    .line 243: const/4 v1, 2
    .line 244: aput v0, v8, v1
    .line 246: if-ge v13, v10, :cond_257
    .line 248: aget v0, v8, v13
    .line 250: invoke-static {v2, v0}, Ljava/lang/Math;->max(FF)F
    .line 253: move-result v2
    .line 254: add-int/lit8 v13, v13, 1
    .line 256: goto :goto_246
    .line 257: new-instance v0, Lj0/d;
    .line 259: invoke-direct {v0, v5, v11, v12, v2}, Lj0/d;-><init>(FFFF)V
    .line 262: return-object v0
.end method

# direct methods
.method public static final d(Lx0/q;)Lx0/q;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v2}, Lx0/q;->T()Lx0/q;
    .line 8: move-result-object v0
    .line 9: move-object v1, v0
    .line 10: move-object v0, v2
    .line 11: move-object v2, v1
    .line 12: if-eqz v2, :cond_19
    .line 14: invoke-interface {v2}, Lx0/q;->T()Lx0/q;
    .line 17: move-result-object v0
    .line 18: goto :goto_9
    .line 19: instance-of v2, v0, Lz0/a1;
    .line 21: if-eqz v2, :cond_27
    .line 23: move-object v2, v0
    .line 24: check-cast v2, Lz0/a1;
    .line 26: goto :goto_28
    .line 27: const/4 v2, 0
    .line 28: if-nez v2, :cond_31
    .line 30: return-object v0
    .line 31: iget-object v0, v2, Lz0/a1;->r:Lz0/a1;
    .line 33: move-object v1, v0
    .line 34: move-object v0, v2
    .line 35: move-object v2, v1
    .line 36: if-eqz v2, :cond_41
    .line 38: iget-object v0, v2, Lz0/a1;->r:Lz0/a1;
    .line 40: goto :goto_33
    .line 41: return-object v0
.end method

# direct methods
.method public static final e(Lx0/x;)Ljava/lang/Object;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v2}, Lx0/l;->J()Ljava/lang/Object;
    .line 8: move-result-object v2
    .line 9: instance-of v0, v2, Lx0/s;
    .line 11: const/4 v1, 0
    .line 12: if-eqz v0, :cond_17
    .line 14: check-cast v2, Lx0/s;
    .line 16: goto :goto_18
    .line 17: move-object v2, v1
    .line 18: if-eqz v2, :cond_24
    .line 20: check-cast v2, Lx0/r;
    .line 22: iget-object v1, v2, Lx0/r;->v:Ljava/lang/Object;
    .line 24: return-object v1
.end method

# direct methods
.method public static final f(Lz0/p0;)Lz0/p0;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v2, v2, Lz0/p0;->p:Lz0/a1;
    .line 7: iget-object v2, v2, Lz0/a1;->p:Landroidx/compose/ui/node/a;
    .line 9: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 12: move-result-object v0
    .line 13: const/4 v1, 0
    .line 14: if-eqz v0, :cond_19
    .line 16: iget-object v0, v0, Landroidx/compose/ui/node/a;->k:Landroidx/compose/ui/node/a;
    .line 18: goto :goto_20
    .line 19: move-object v0, v1
    .line 20: if-eqz v0, :cond_46
    .line 22: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 25: move-result-object v0
    .line 26: if-eqz v0, :cond_30
    .line 28: iget-object v1, v0, Landroidx/compose/ui/node/a;->k:Landroidx/compose/ui/node/a;
    .line 30: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 33: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 36: move-result-object v2
    .line 37: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 40: iget-object v2, v2, Landroidx/compose/ui/node/a;->k:Landroidx/compose/ui/node/a;
    .line 42: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 45: goto :goto_9
    .line 46: iget-object v2, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 48: iget-object v2, v2, Lz0/v0;->c:Lz0/a1;
    .line 50: invoke-virtual {v2}, Lz0/a1;->I0()Lz0/p0;
    .line 53: move-result-object v2
    .line 54: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 57: return-object v2
.end method

# direct methods
.method public static final g(Lf0/p;Ld3/f;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/layout/LayoutElement;
    .line 7: invoke-direct {v0, v2}, Landroidx/compose/ui/layout/LayoutElement;-><init>(Ld3/f;)V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

# direct methods
.method public static final h(Lf0/p;Ljava/lang/Object;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroidx/compose/ui/layout/LayoutIdElement;
    .line 7: invoke-direct {v0, v2}, Landroidx/compose/ui/layout/LayoutIdElement;-><init>(Ljava/lang/Object;)V
    .line 10: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 13: move-result-object v1
    .line 14: return-object v1
.end method

# direct methods
.method public static final i(Lf0/p;)Lb0/c;
    .registers 3

    .line 0: const-string v0, "modifier"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Lx0/t;
    .line 7: const/4 v1, 1
    .line 8: invoke-direct {v0, v2, v1}, Lx0/t;-><init>(Lf0/p;I)V
    .line 11: const v2, 0xfcad6ab2
    .line 14: invoke-static {v2, v0, v1}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 17: move-result-object v2
    .line 18: return-object v2
.end method

# direct methods
.method public static final j(Lf0/p;)Lb0/c;
    .registers 3

    .line 0: const-string v0, "modifier"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Lx0/t;
    .line 7: const/4 v1, 0
    .line 8: invoke-direct {v0, v2, v1}, Lx0/t;-><init>(Lf0/p;I)V
    .line 11: const v2, 0xa173a20c
    .line 14: const/4 v1, 1
    .line 15: invoke-static {v2, v0, v1}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 18: move-result-object v2
    .line 19: return-object v2
.end method

# direct methods
.method public static final k(Lf0/p;Ld3/c;)Lf0/p;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "onGloballyPositioned"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/ui/layout/OnGloballyPositionedElement;
    .line 12: invoke-direct {v0, v2}, Landroidx/compose/ui/layout/OnGloballyPositionedElement;-><init>(Ld3/c;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

# direct methods
.method public static final l(Lx0/q;)J
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Lj0/c;->e:I
    .line 7: sget-wide v0, Lj0/c;->b:J
    .line 9: invoke-interface {v2, v0, v1}, Lx0/q;->g(J)J
    .line 12: move-result-wide v0
    .line 13: return-wide v0
.end method

# direct methods
.method public static final m(JJ)J
    .registers 11

    .line 0: invoke-static {v7, v8}, Lj0/f;->d(J)F
    .line 3: move-result v0
    .line 4: sget-wide v1, Lx0/p0;->a:J
    .line 6: cmp-long v3, v9, v1
    .line 8: const-string v4, "ScaleFactor is unspecified"
    .line 10: if-eqz v3, :cond_58
    .line 12: const/16 v3, 32
    .line 14: shr-long v5, v9, v3
    .line 16: long-to-int v3, v5
    .line 17: invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 20: move-result v3
    .line 21: mul-float/2addr v3, v0
    .line 22: invoke-static {v7, v8}, Lj0/f;->b(J)F
    .line 25: move-result v7
    .line 26: cmp-long v8, v9, v1
    .line 28: if-eqz v8, :cond_48
    .line 30: const-wide v0, 0x00ffffffff
    .line 35: and-long v8, v9, v0
    .line 37: long-to-int v8, v8
    .line 38: invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F
    .line 41: move-result v8
    .line 42: mul-float/2addr v8, v7
    .line 43: invoke-static {v3, v8}, Ld2/c;->f(FF)J
    .line 46: move-result-wide v7
    .line 47: return-wide v7
    .line 48: new-instance v7, Ljava/lang/IllegalStateException;
    .line 50: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 53: move-result-object v8
    .line 54: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 57: throw v7
    .line 58: new-instance v7, Ljava/lang/IllegalStateException;
    .line 60: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 63: move-result-object v8
    .line 64: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 67: throw v7
.end method

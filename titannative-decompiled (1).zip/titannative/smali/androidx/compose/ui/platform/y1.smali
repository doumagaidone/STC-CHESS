.class public final Landroidx/compose/ui/platform/y1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Lr1/b;
.field public b:Z
.field public final c:Landroid/graphics/Outline;
.field public d:J
.field public e:Lk0/l0;
.field public f:Lk0/f;
.field public g:Lk0/c0;
.field public h:Z
.field public i:Z
.field public j:Lk0/c0;
.field public k:Lj0/e;
.field public l:F
.field public m:J
.field public n:J
.field public o:Z
.field public p:Lr1/j;
.field public q:Lk0/g0;

# direct methods
.method public constructor <init>(Lr1/b;)V
    .registers 6

    .line 0: const-string v0, "density"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v5, v4, Landroidx/compose/ui/platform/y1;->a:Lr1/b;
    .line 10: const/4 v5, 1
    .line 11: iput-boolean v5, v4, Landroidx/compose/ui/platform/y1;->b:Z
    .line 13: new-instance v5, Landroid/graphics/Outline;
    .line 15: invoke-direct {v5}, Landroid/graphics/Outline;-><init>()V
    .line 18: const/high16 v0, 0x3f80
    .line 20: invoke-virtual {v5, v0}, Landroid/graphics/Outline;->setAlpha(F)V
    .line 23: iput-object v5, v4, Landroidx/compose/ui/platform/y1;->c:Landroid/graphics/Outline;
    .line 25: sget-wide v0, Lj0/f;->b:J
    .line 27: iput-wide v0, v4, Landroidx/compose/ui/platform/y1;->d:J
    .line 29: sget-object v5, Lk0/g0;->a:Lk0/f0;
    .line 31: iput-object v5, v4, Landroidx/compose/ui/platform/y1;->e:Lk0/l0;
    .line 33: sget-wide v2, Lj0/c;->b:J
    .line 35: iput-wide v2, v4, Landroidx/compose/ui/platform/y1;->m:J
    .line 37: iput-wide v0, v4, Landroidx/compose/ui/platform/y1;->n:J
    .line 39: sget-object v5, Lr1/j;->i:Lr1/j;
    .line 41: iput-object v5, v4, Landroidx/compose/ui/platform/y1;->p:Lr1/j;
    .line 43: return-void
.end method

# virtual methods
.method public final a(Lk0/o;)V
    .registers 22

    .line 0: move-object/from16 v0, v20
    .line 2: move-object/from16 v1, v21
    .line 4: const-string v2, "canvas"
    .line 6: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/platform/y1;->e()V
    .line 12: iget-object v2, v0, Landroidx/compose/ui/platform/y1;->g:Lk0/c0;
    .line 14: const/4 v3, 1
    .line 15: if-eqz v2, :cond_22
    .line 17: invoke-interface {v1, v2, v3}, Lk0/o;->n(Lk0/c0;I)V
    .line 20: goto/16 :goto_252
    .line 22: iget v2, v0, Landroidx/compose/ui/platform/y1;->l:F
    .line 24: const/4 v4, 0
    .line 25: cmpl-float v4, v2, v4
    .line 27: if-lez v4, :cond_208
    .line 29: iget-object v4, v0, Landroidx/compose/ui/platform/y1;->j:Lk0/c0;
    .line 31: iget-object v5, v0, Landroidx/compose/ui/platform/y1;->k:Lj0/e;
    .line 33: if-eqz v4, :cond_109
    .line 35: iget-wide v6, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 37: iget-wide v8, v0, Landroidx/compose/ui/platform/y1;->n:J
    .line 39: if-eqz v5, :cond_109
    .line 41: invoke-static {v5}, Ld2/b;->D0(Lj0/e;)Z
    .line 44: move-result v10
    .line 45: if-nez v10, :cond_48
    .line 47: goto :goto_109
    .line 48: invoke-static {v6, v7}, Lj0/c;->c(J)F
    .line 51: move-result v10
    .line 52: iget v11, v5, Lj0/e;->a:F
    .line 54: cmpg-float v10, v11, v10
    .line 56: if-nez v10, :cond_109
    .line 58: invoke-static {v6, v7}, Lj0/c;->d(J)F
    .line 61: move-result v10
    .line 62: iget v11, v5, Lj0/e;->b:F
    .line 64: cmpg-float v10, v11, v10
    .line 66: if-nez v10, :cond_109
    .line 68: invoke-static {v6, v7}, Lj0/c;->c(J)F
    .line 71: move-result v10
    .line 72: invoke-static {v8, v9}, Lj0/f;->d(J)F
    .line 75: move-result v11
    .line 76: add-float/2addr v11, v10
    .line 77: iget v10, v5, Lj0/e;->c:F
    .line 79: cmpg-float v10, v10, v11
    .line 81: if-nez v10, :cond_109
    .line 83: invoke-static {v6, v7}, Lj0/c;->d(J)F
    .line 86: move-result v6
    .line 87: invoke-static {v8, v9}, Lj0/f;->b(J)F
    .line 90: move-result v7
    .line 91: add-float/2addr v7, v6
    .line 92: iget v6, v5, Lj0/e;->d:F
    .line 94: cmpg-float v6, v6, v7
    .line 96: if-nez v6, :cond_109
    .line 98: iget-wide v5, v5, Lj0/e;->e:J
    .line 100: invoke-static {v5, v6}, Lj0/a;->b(J)F
    .line 103: move-result v5
    .line 104: cmpg-float v2, v5, v2
    .line 106: if-nez v2, :cond_109
    .line 108: goto :goto_204
    .line 109: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 111: invoke-static {v5, v6}, Lj0/c;->c(J)F
    .line 114: move-result v8
    .line 115: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 117: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 120: move-result v9
    .line 121: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 123: invoke-static {v5, v6}, Lj0/c;->c(J)F
    .line 126: move-result v2
    .line 127: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->n:J
    .line 129: invoke-static {v5, v6}, Lj0/f;->d(J)F
    .line 132: move-result v5
    .line 133: add-float v10, v5, v2
    .line 135: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 137: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 140: move-result v2
    .line 141: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->n:J
    .line 143: invoke-static {v5, v6}, Lj0/f;->b(J)F
    .line 146: move-result v5
    .line 147: add-float v11, v5, v2
    .line 149: iget v2, v0, Landroidx/compose/ui/platform/y1;->l:F
    .line 151: invoke-static {v2, v2}, Ln3/a0;->c(FF)J
    .line 154: move-result-wide v5
    .line 155: invoke-static {v5, v6}, Lj0/a;->b(J)F
    .line 158: move-result v2
    .line 159: invoke-static {v5, v6}, Lj0/a;->c(J)F
    .line 162: move-result v5
    .line 163: invoke-static {v2, v5}, Ln3/a0;->c(FF)J
    .line 166: move-result-wide v18
    .line 167: new-instance v2, Lj0/e;
    .line 169: move-object v7, v2
    .line 170: move-wide/from16 v12, v18
    .line 172: move-wide/from16 v14, v18
    .line 174: move-wide/from16 v16, v18
    .line 176: invoke-direct/range {v7 .. v19}, Lj0/e;-><init>(FFFFJJJJ)V
    .line 179: if-nez v4, :cond_186
    .line 181: invoke-static {}, Landroidx/compose/ui/graphics/a;->g()Lk0/f;
    .line 184: move-result-object v4
    .line 185: goto :goto_194
    .line 186: move-object v5, v4
    .line 187: check-cast v5, Lk0/f;
    .line 189: iget-object v5, v5, Lk0/f;->a:Landroid/graphics/Path;
    .line 191: invoke-virtual {v5}, Landroid/graphics/Path;->reset()V
    .line 194: move-object v5, v4
    .line 195: check-cast v5, Lk0/f;
    .line 197: invoke-virtual {v5, v2}, Lk0/f;->a(Lj0/e;)V
    .line 200: iput-object v2, v0, Landroidx/compose/ui/platform/y1;->k:Lj0/e;
    .line 202: iput-object v4, v0, Landroidx/compose/ui/platform/y1;->j:Lk0/c0;
    .line 204: invoke-interface {v1, v4, v3}, Lk0/o;->n(Lk0/c0;I)V
    .line 207: goto :goto_252
    .line 208: iget-wide v2, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 210: invoke-static {v2, v3}, Lj0/c;->c(J)F
    .line 213: move-result v2
    .line 214: iget-wide v3, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 216: invoke-static {v3, v4}, Lj0/c;->d(J)F
    .line 219: move-result v3
    .line 220: iget-wide v4, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 222: invoke-static {v4, v5}, Lj0/c;->c(J)F
    .line 225: move-result v4
    .line 226: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->n:J
    .line 228: invoke-static {v5, v6}, Lj0/f;->d(J)F
    .line 231: move-result v5
    .line 232: add-float/2addr v4, v5
    .line 233: iget-wide v5, v0, Landroidx/compose/ui/platform/y1;->m:J
    .line 235: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 238: move-result v5
    .line 239: iget-wide v6, v0, Landroidx/compose/ui/platform/y1;->n:J
    .line 241: invoke-static {v6, v7}, Lj0/f;->b(J)F
    .line 244: move-result v6
    .line 245: add-float/2addr v5, v6
    .line 246: const/4 v6, 1
    .line 247: move-object/from16 v1, v21
    .line 249: invoke-interface/range {v1 .. v6}, Lk0/o;->q(FFFFI)V
    .line 252: return-void
.end method

# virtual methods
.method public final b()Landroid/graphics/Outline;
    .registers 2

    .line 0: invoke-virtual {v1}, Landroidx/compose/ui/platform/y1;->e()V
    .line 3: iget-boolean v0, v1, Landroidx/compose/ui/platform/y1;->o:Z
    .line 5: if-eqz v0, :cond_15
    .line 7: iget-boolean v0, v1, Landroidx/compose/ui/platform/y1;->b:Z
    .line 9: if-nez v0, :cond_12
    .line 11: goto :goto_15
    .line 12: iget-object v0, v1, Landroidx/compose/ui/platform/y1;->c:Landroid/graphics/Outline;
    .line 14: goto :goto_16
    .line 15: const/4 v0, 0
    .line 16: return-object v0
.end method

# virtual methods
.method public final c(J)Z
    .registers 20

    .line 0: move-object/from16 v0, v17
    .line 2: iget-boolean v1, v0, Landroidx/compose/ui/platform/y1;->o:Z
    .line 4: const/4 v2, 1
    .line 5: if-nez v1, :cond_8
    .line 7: return v2
    .line 8: iget-object v1, v0, Landroidx/compose/ui/platform/y1;->q:Lk0/g0;
    .line 10: if-nez v1, :cond_13
    .line 12: return v2
    .line 13: invoke-static/range {v18 .. v19}, Lj0/c;->c(J)F
    .line 16: move-result v3
    .line 17: invoke-static/range {v18 .. v19}, Lj0/c;->d(J)F
    .line 20: move-result v4
    .line 21: instance-of v5, v1, Lk0/a0;
    .line 23: const/4 v6, 0
    .line 24: if-eqz v5, :cond_56
    .line 26: check-cast v1, Lk0/a0;
    .line 28: iget-object v1, v1, Lk0/a0;->e:Lj0/d;
    .line 30: iget v5, v1, Lj0/d;->a:F
    .line 32: cmpg-float v5, v5, v3
    .line 34: if-gtz v5, :cond_424
    .line 36: iget v5, v1, Lj0/d;->c:F
    .line 38: cmpg-float v3, v3, v5
    .line 40: if-gez v3, :cond_424
    .line 42: iget v3, v1, Lj0/d;->b:F
    .line 44: cmpg-float v3, v3, v4
    .line 46: if-gtz v3, :cond_424
    .line 48: iget v1, v1, Lj0/d;->d:F
    .line 50: cmpg-float v1, v4, v1
    .line 52: if-gez v1, :cond_424
    .line 54: goto/16 :goto_425
    .line 56: instance-of v5, v1, Lk0/b0;
    .line 58: if-eqz v5, :cond_426
    .line 60: check-cast v1, Lk0/b0;
    .line 62: iget-object v1, v1, Lk0/b0;->e:Lj0/e;
    .line 64: iget v5, v1, Lj0/e;->a:F
    .line 66: cmpg-float v5, v3, v5
    .line 68: if-ltz v5, :cond_424
    .line 70: iget v5, v1, Lj0/e;->c:F
    .line 72: cmpl-float v7, v3, v5
    .line 74: if-gez v7, :cond_424
    .line 76: iget v7, v1, Lj0/e;->b:F
    .line 78: cmpg-float v8, v4, v7
    .line 80: if-ltz v8, :cond_424
    .line 82: iget v8, v1, Lj0/e;->d:F
    .line 84: cmpl-float v9, v4, v8
    .line 86: if-ltz v9, :cond_90
    .line 88: goto/16 :goto_424
    .line 90: iget-wide v9, v1, Lj0/e;->e:J
    .line 92: invoke-static {v9, v10}, Lj0/a;->b(J)F
    .line 95: move-result v6
    .line 96: iget-wide v11, v1, Lj0/e;->f:J
    .line 98: invoke-static {v11, v12}, Lj0/a;->b(J)F
    .line 101: move-result v13
    .line 102: add-float/2addr v13, v6
    .line 103: invoke-virtual {v1}, Lj0/e;->b()F
    .line 106: move-result v6
    .line 107: cmpg-float v6, v13, v6
    .line 109: if-gtz v6, :cond_291
    .line 111: iget-wide v13, v1, Lj0/e;->h:J
    .line 113: invoke-static {v13, v14}, Lj0/a;->b(J)F
    .line 116: move-result v6
    .line 117: move v15, v3
    .line 118: iget-wide v2, v1, Lj0/e;->g:J
    .line 120: invoke-static {v2, v3}, Lj0/a;->b(J)F
    .line 123: move-result v16
    .line 124: add-float v16, v16, v6
    .line 126: invoke-virtual {v1}, Lj0/e;->b()F
    .line 129: move-result v6
    .line 130: cmpg-float v6, v16, v6
    .line 132: if-gtz v6, :cond_292
    .line 134: invoke-static {v9, v10}, Lj0/a;->c(J)F
    .line 137: move-result v6
    .line 138: invoke-static {v13, v14}, Lj0/a;->c(J)F
    .line 141: move-result v16
    .line 142: add-float v16, v16, v6
    .line 144: invoke-virtual {v1}, Lj0/e;->a()F
    .line 147: move-result v6
    .line 148: cmpg-float v6, v16, v6
    .line 150: if-gtz v6, :cond_292
    .line 152: invoke-static {v11, v12}, Lj0/a;->c(J)F
    .line 155: move-result v6
    .line 156: invoke-static {v2, v3}, Lj0/a;->c(J)F
    .line 159: move-result v16
    .line 160: add-float v16, v16, v6
    .line 162: invoke-virtual {v1}, Lj0/e;->a()F
    .line 165: move-result v6
    .line 166: cmpg-float v6, v16, v6
    .line 168: if-gtz v6, :cond_292
    .line 170: invoke-static {v9, v10}, Lj0/a;->b(J)F
    .line 173: move-result v6
    .line 174: iget v0, v1, Lj0/e;->a:F
    .line 176: add-float/2addr v6, v0
    .line 177: invoke-static {v9, v10}, Lj0/a;->c(J)F
    .line 180: move-result v9
    .line 181: add-float/2addr v9, v7
    .line 182: invoke-static {v11, v12}, Lj0/a;->b(J)F
    .line 185: move-result v10
    .line 186: sub-float v10, v5, v10
    .line 188: invoke-static {v11, v12}, Lj0/a;->c(J)F
    .line 191: move-result v11
    .line 192: add-float/2addr v7, v11
    .line 193: invoke-static {v2, v3}, Lj0/a;->b(J)F
    .line 196: move-result v11
    .line 197: sub-float/2addr v5, v11
    .line 198: invoke-static {v2, v3}, Lj0/a;->c(J)F
    .line 201: move-result v2
    .line 202: sub-float v2, v8, v2
    .line 204: invoke-static {v13, v14}, Lj0/a;->c(J)F
    .line 207: move-result v3
    .line 208: sub-float/2addr v8, v3
    .line 209: invoke-static {v13, v14}, Lj0/a;->b(J)F
    .line 212: move-result v3
    .line 213: add-float/2addr v0, v3
    .line 214: cmpg-float v3, v15, v6
    .line 216: if-gez v3, :cond_232
    .line 218: cmpg-float v3, v4, v9
    .line 220: if-gez v3, :cond_232
    .line 222: iget-wide v7, v1, Lj0/e;->e:J
    .line 224: move v3, v15
    .line 225: move v5, v6
    .line 226: move v6, v9
    .line 227: invoke-static/range {v3 .. v8}, Landroidx/compose/ui/platform/n1;->u(FFFFJ)Z
    .line 230: move-result v2
    .line 231: goto :goto_288
    .line 232: cmpg-float v3, v15, v0
    .line 234: if-gez v3, :cond_251
    .line 236: cmpl-float v3, v4, v8
    .line 238: if-lez v3, :cond_251
    .line 240: iget-wide v1, v1, Lj0/e;->h:J
    .line 242: move v3, v15
    .line 243: move v5, v0
    .line 244: move v6, v8
    .line 245: move-wide v7, v1
    .line 246: invoke-static/range {v3 .. v8}, Landroidx/compose/ui/platform/n1;->u(FFFFJ)Z
    .line 249: move-result v2
    .line 250: goto :goto_288
    .line 251: cmpl-float v0, v15, v10
    .line 253: if-lez v0, :cond_270
    .line 255: cmpg-float v0, v4, v7
    .line 257: if-gez v0, :cond_270
    .line 259: iget-wide v0, v1, Lj0/e;->f:J
    .line 261: move v3, v15
    .line 262: move v5, v10
    .line 263: move v6, v7
    .line 264: move-wide v7, v0
    .line 265: invoke-static/range {v3 .. v8}, Landroidx/compose/ui/platform/n1;->u(FFFFJ)Z
    .line 268: move-result v2
    .line 269: goto :goto_288
    .line 270: cmpl-float v0, v15, v5
    .line 272: if-lez v0, :cond_287
    .line 274: cmpl-float v0, v4, v2
    .line 276: if-lez v0, :cond_287
    .line 278: iget-wide v7, v1, Lj0/e;->g:J
    .line 280: move v3, v15
    .line 281: move v6, v2
    .line 282: invoke-static/range {v3 .. v8}, Landroidx/compose/ui/platform/n1;->u(FFFFJ)Z
    .line 285: move-result v2
    .line 286: goto :goto_288
    .line 287: const/4 v2, 1
    .line 288: move v6, v2
    .line 289: goto/16 :goto_424
    .line 291: move v15, v3
    .line 292: invoke-static {}, Landroidx/compose/ui/graphics/a;->g()Lk0/f;
    .line 295: move-result-object v0
    .line 296: invoke-virtual {v0, v1}, Lk0/f;->a(Lj0/e;)V
    .line 299: const v1, 0x3ba3d70a
    .line 302: sub-float v3, v15, v1
    .line 304: sub-float v2, v4, v1
    .line 306: add-float v5, v15, v1
    .line 308: add-float/2addr v4, v1
    .line 309: invoke-static {}, Landroidx/compose/ui/graphics/a;->g()Lk0/f;
    .line 312: move-result-object v1
    .line 313: invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z
    .line 316: move-result v6
    .line 317: const/4 v7, 1
    .line 318: xor-int/2addr v6, v7
    .line 319: if-eqz v6, :cond_412
    .line 321: invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z
    .line 324: move-result v6
    .line 325: xor-int/2addr v6, v7
    .line 326: if-eqz v6, :cond_400
    .line 328: invoke-static {v5}, Ljava/lang/Float;->isNaN(F)Z
    .line 331: move-result v6
    .line 332: xor-int/2addr v6, v7
    .line 333: if-eqz v6, :cond_388
    .line 335: invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z
    .line 338: move-result v6
    .line 339: xor-int/2addr v6, v7
    .line 340: if-eqz v6, :cond_376
    .line 342: iget-object v6, v1, Lk0/f;->b:Landroid/graphics/RectF;
    .line 344: invoke-virtual {v6, v3, v2, v5, v4}, Landroid/graphics/RectF;->set(FFFF)V
    .line 347: sget-object v2, Landroid/graphics/Path$Direction;->CCW:Landroid/graphics/Path$Direction;
    .line 349: iget-object v3, v1, Lk0/f;->a:Landroid/graphics/Path;
    .line 351: invoke-virtual {v3, v6, v2}, Landroid/graphics/Path;->addRect(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V
    .line 354: invoke-static {}, Landroidx/compose/ui/graphics/a;->g()Lk0/f;
    .line 357: move-result-object v2
    .line 358: invoke-virtual {v2, v0, v1, v7}, Lk0/f;->b(Lk0/c0;Lk0/c0;I)Z
    .line 361: iget-object v0, v2, Lk0/f;->a:Landroid/graphics/Path;
    .line 363: invoke-virtual {v0}, Landroid/graphics/Path;->isEmpty()Z
    .line 366: move-result v1
    .line 367: invoke-virtual {v0}, Landroid/graphics/Path;->reset()V
    .line 370: invoke-virtual {v3}, Landroid/graphics/Path;->reset()V
    .line 373: xor-int/lit8 v6, v1, 1
    .line 375: goto :goto_424
    .line 376: new-instance v0, Ljava/lang/IllegalStateException;
    .line 378: const-string v1, "Rect.bottom is NaN"
    .line 380: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 383: move-result-object v1
    .line 384: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 387: throw v0
    .line 388: new-instance v0, Ljava/lang/IllegalStateException;
    .line 390: const-string v1, "Rect.right is NaN"
    .line 392: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 395: move-result-object v1
    .line 396: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 399: throw v0
    .line 400: new-instance v0, Ljava/lang/IllegalStateException;
    .line 402: const-string v1, "Rect.top is NaN"
    .line 404: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 407: move-result-object v1
    .line 408: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 411: throw v0
    .line 412: new-instance v0, Ljava/lang/IllegalStateException;
    .line 414: const-string v1, "Rect.left is NaN"
    .line 416: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 419: move-result-object v1
    .line 420: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 423: throw v0
    .line 424: move v2, v6
    .line 425: return v2
    .line 426: new-instance v0, Lkotlinx/coroutines/internal/z;
    .line 428: invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V
    .line 431: throw v0
.end method

# virtual methods
.method public final d(Lk0/l0;FZFLr1/j;Lr1/b;)Z
    .registers 8

    .line 0: const-string v0, "shape"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "layoutDirection"
    .line 7: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "density"
    .line 12: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: iget-object v0, v1, Landroidx/compose/ui/platform/y1;->c:Landroid/graphics/Outline;
    .line 17: invoke-virtual {v0, v3}, Landroid/graphics/Outline;->setAlpha(F)V
    .line 20: iget-object v3, v1, Landroidx/compose/ui/platform/y1;->e:Lk0/l0;
    .line 22: invoke-static {v3, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 25: move-result v3
    .line 26: const/4 v0, 1
    .line 27: xor-int/2addr v3, v0
    .line 28: if-eqz v3, :cond_34
    .line 30: iput-object v2, v1, Landroidx/compose/ui/platform/y1;->e:Lk0/l0;
    .line 32: iput-boolean v0, v1, Landroidx/compose/ui/platform/y1;->h:Z
    .line 34: if-nez v4, :cond_44
    .line 36: const/4 v2, 0
    .line 37: cmpl-float v2, v5, v2
    .line 39: if-lez v2, :cond_42
    .line 41: goto :goto_44
    .line 42: const/4 v2, 0
    .line 43: goto :goto_45
    .line 44: move v2, v0
    .line 45: iget-boolean v4, v1, Landroidx/compose/ui/platform/y1;->o:Z
    .line 47: if-eq v4, v2, :cond_53
    .line 49: iput-boolean v2, v1, Landroidx/compose/ui/platform/y1;->o:Z
    .line 51: iput-boolean v0, v1, Landroidx/compose/ui/platform/y1;->h:Z
    .line 53: iget-object v2, v1, Landroidx/compose/ui/platform/y1;->p:Lr1/j;
    .line 55: if-eq v2, v6, :cond_61
    .line 57: iput-object v6, v1, Landroidx/compose/ui/platform/y1;->p:Lr1/j;
    .line 59: iput-boolean v0, v1, Landroidx/compose/ui/platform/y1;->h:Z
    .line 61: iget-object v2, v1, Landroidx/compose/ui/platform/y1;->a:Lr1/b;
    .line 63: invoke-static {v2, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 66: move-result v2
    .line 67: if-nez v2, :cond_73
    .line 69: iput-object v7, v1, Landroidx/compose/ui/platform/y1;->a:Lr1/b;
    .line 71: iput-boolean v0, v1, Landroidx/compose/ui/platform/y1;->h:Z
    .line 73: return v3
.end method

# virtual methods
.method public final e()V
    .registers 15

    .line 0: iget-boolean v0, v14, Landroidx/compose/ui/platform/y1;->h:Z
    .line 2: if-eqz v0, :cond_251
    .line 4: sget-wide v0, Lj0/c;->b:J
    .line 6: iput-wide v0, v14, Landroidx/compose/ui/platform/y1;->m:J
    .line 8: iget-wide v0, v14, Landroidx/compose/ui/platform/y1;->d:J
    .line 10: iput-wide v0, v14, Landroidx/compose/ui/platform/y1;->n:J
    .line 12: const/4 v2, 0
    .line 13: iput v2, v14, Landroidx/compose/ui/platform/y1;->l:F
    .line 15: const/4 v3, 0
    .line 16: iput-object v3, v14, Landroidx/compose/ui/platform/y1;->g:Lk0/c0;
    .line 18: const/4 v3, 0
    .line 19: iput-boolean v3, v14, Landroidx/compose/ui/platform/y1;->h:Z
    .line 21: iput-boolean v3, v14, Landroidx/compose/ui/platform/y1;->i:Z
    .line 23: iget-boolean v4, v14, Landroidx/compose/ui/platform/y1;->o:Z
    .line 25: iget-object v5, v14, Landroidx/compose/ui/platform/y1;->c:Landroid/graphics/Outline;
    .line 27: if-eqz v4, :cond_248
    .line 29: invoke-static {v0, v1}, Lj0/f;->d(J)F
    .line 32: move-result v0
    .line 33: cmpl-float v0, v0, v2
    .line 35: if-lez v0, :cond_248
    .line 37: iget-wide v0, v14, Landroidx/compose/ui/platform/y1;->d:J
    .line 39: invoke-static {v0, v1}, Lj0/f;->b(J)F
    .line 42: move-result v0
    .line 43: cmpl-float v0, v0, v2
    .line 45: if-lez v0, :cond_248
    .line 47: const/4 v0, 1
    .line 48: iput-boolean v0, v14, Landroidx/compose/ui/platform/y1;->b:Z
    .line 50: iget-object v1, v14, Landroidx/compose/ui/platform/y1;->e:Lk0/l0;
    .line 52: iget-wide v6, v14, Landroidx/compose/ui/platform/y1;->d:J
    .line 54: iget-object v2, v14, Landroidx/compose/ui/platform/y1;->p:Lr1/j;
    .line 56: iget-object v4, v14, Landroidx/compose/ui/platform/y1;->a:Lr1/b;
    .line 58: invoke-interface {v1, v6, v7, v2, v4}, Lk0/l0;->a(JLr1/j;Lr1/b;)Lk0/g0;
    .line 61: move-result-object v1
    .line 62: iput-object v1, v14, Landroidx/compose/ui/platform/y1;->q:Lk0/g0;
    .line 64: instance-of v2, v1, Lk0/a0;
    .line 66: if-eqz v2, :cond_123
    .line 68: check-cast v1, Lk0/a0;
    .line 70: iget-object v0, v1, Lk0/a0;->e:Lj0/d;
    .line 72: iget v1, v0, Lj0/d;->a:F
    .line 74: iget v2, v0, Lj0/d;->b:F
    .line 76: invoke-static {v1, v2}, Ln3/a0;->g(FF)J
    .line 79: move-result-wide v3
    .line 80: iput-wide v3, v14, Landroidx/compose/ui/platform/y1;->m:J
    .line 82: invoke-virtual {v0}, Lj0/d;->c()F
    .line 85: move-result v1
    .line 86: invoke-virtual {v0}, Lj0/d;->b()F
    .line 89: move-result v3
    .line 90: invoke-static {v1, v3}, Ld2/c;->f(FF)J
    .line 93: move-result-wide v3
    .line 94: iput-wide v3, v14, Landroidx/compose/ui/platform/y1;->n:J
    .line 96: iget v1, v0, Lj0/d;->a:F
    .line 98: invoke-static {v1}, Ld2/b;->a1(F)I
    .line 101: move-result v1
    .line 102: invoke-static {v2}, Ld2/b;->a1(F)I
    .line 105: move-result v2
    .line 106: iget v3, v0, Lj0/d;->c:F
    .line 108: invoke-static {v3}, Ld2/b;->a1(F)I
    .line 111: move-result v3
    .line 112: iget v0, v0, Lj0/d;->d:F
    .line 114: invoke-static {v0}, Ld2/b;->a1(F)I
    .line 117: move-result v0
    .line 118: invoke-virtual {v5, v1, v2, v3, v0}, Landroid/graphics/Outline;->setRect(IIII)V
    .line 121: goto/16 :goto_251
    .line 123: instance-of v2, v1, Lk0/b0;
    .line 125: if-eqz v2, :cond_251
    .line 127: check-cast v1, Lk0/b0;
    .line 129: iget-object v1, v1, Lk0/b0;->e:Lj0/e;
    .line 131: iget-wide v6, v1, Lj0/e;->e:J
    .line 133: invoke-static {v6, v7}, Lj0/a;->b(J)F
    .line 136: move-result v2
    .line 137: iget v4, v1, Lj0/e;->a:F
    .line 139: iget v6, v1, Lj0/e;->b:F
    .line 141: invoke-static {v4, v6}, Ln3/a0;->g(FF)J
    .line 144: move-result-wide v7
    .line 145: iput-wide v7, v14, Landroidx/compose/ui/platform/y1;->m:J
    .line 147: invoke-virtual {v1}, Lj0/e;->b()F
    .line 150: move-result v7
    .line 151: invoke-virtual {v1}, Lj0/e;->a()F
    .line 154: move-result v8
    .line 155: invoke-static {v7, v8}, Ld2/c;->f(FF)J
    .line 158: move-result-wide v7
    .line 159: iput-wide v7, v14, Landroidx/compose/ui/platform/y1;->n:J
    .line 161: invoke-static {v1}, Ld2/b;->D0(Lj0/e;)Z
    .line 164: move-result v7
    .line 165: if-eqz v7, :cond_196
    .line 167: iget-object v8, v14, Landroidx/compose/ui/platform/y1;->c:Landroid/graphics/Outline;
    .line 169: invoke-static {v4}, Ld2/b;->a1(F)I
    .line 172: move-result v9
    .line 173: invoke-static {v6}, Ld2/b;->a1(F)I
    .line 176: move-result v10
    .line 177: iget v0, v1, Lj0/e;->c:F
    .line 179: invoke-static {v0}, Ld2/b;->a1(F)I
    .line 182: move-result v11
    .line 183: iget v0, v1, Lj0/e;->d:F
    .line 185: invoke-static {v0}, Ld2/b;->a1(F)I
    .line 188: move-result v12
    .line 189: move v13, v2
    .line 190: invoke-virtual/range {v8 .. v13}, Landroid/graphics/Outline;->setRoundRect(IIIIF)V
    .line 193: iput v2, v14, Landroidx/compose/ui/platform/y1;->l:F
    .line 195: goto :goto_251
    .line 196: iget-object v2, v14, Landroidx/compose/ui/platform/y1;->f:Lk0/f;
    .line 198: if-nez v2, :cond_206
    .line 200: invoke-static {}, Landroidx/compose/ui/graphics/a;->g()Lk0/f;
    .line 203: move-result-object v2
    .line 204: iput-object v2, v14, Landroidx/compose/ui/platform/y1;->f:Lk0/f;
    .line 206: iget-object v4, v2, Lk0/f;->a:Landroid/graphics/Path;
    .line 208: invoke-virtual {v4}, Landroid/graphics/Path;->reset()V
    .line 211: invoke-virtual {v2, v1}, Lk0/f;->a(Lj0/e;)V
    .line 214: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 216: const/16 v6, 28
    .line 218: if-gt v1, v6, :cond_235
    .line 220: invoke-virtual {v4}, Landroid/graphics/Path;->isConvex()Z
    .line 223: move-result v1
    .line 224: if-eqz v1, :cond_227
    .line 226: goto :goto_235
    .line 227: iput-boolean v3, v14, Landroidx/compose/ui/platform/y1;->b:Z
    .line 229: invoke-virtual {v5}, Landroid/graphics/Outline;->setEmpty()V
    .line 232: iput-boolean v0, v14, Landroidx/compose/ui/platform/y1;->i:Z
    .line 234: goto :goto_245
    .line 235: invoke-virtual {v5, v4}, Landroid/graphics/Outline;->setConvexPath(Landroid/graphics/Path;)V
    .line 238: invoke-virtual {v5}, Landroid/graphics/Outline;->canClip()Z
    .line 241: move-result v1
    .line 242: xor-int/2addr v0, v1
    .line 243: iput-boolean v0, v14, Landroidx/compose/ui/platform/y1;->i:Z
    .line 245: iput-object v2, v14, Landroidx/compose/ui/platform/y1;->g:Lk0/c0;
    .line 247: goto :goto_251
    .line 248: invoke-virtual {v5}, Landroid/graphics/Outline;->setEmpty()V
    .line 251: return-void
.end method

.class public abstract interface Landroidx/compose/ui/platform/e1;
.super Ljava/lang/Object;
.source "SourceFile"

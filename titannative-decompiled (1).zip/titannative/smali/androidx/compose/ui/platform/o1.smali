.class public Landroidx/compose/ui/platform/o1;
.super Landroid/view/ViewGroup;
.source "SourceFile"

.field public i:Z

# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 0: invoke-direct {v1, v2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V
    .line 3: const/4 v2, 0
    .line 4: invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setClipChildren(Z)V
    .line 7: const v2, 0x7f060030
    .line 10: sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 12: invoke-virtual {v1, v2, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 15: return-void
.end method

# virtual methods
.method public final a(Lk0/o;Landroid/view/View;J)V
    .registers 6

    .line 0: const-string v0, "canvas"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "view"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: sget-object v0, Lk0/b;->a:Landroid/graphics/Canvas;
    .line 12: check-cast v2, Lk0/a;
    .line 14: iget-object v2, v2, Lk0/a;->a:Landroid/graphics/Canvas;
    .line 16: invoke-super {v1, v2, v3, v4, v5}, Landroid/view/ViewGroup;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z
    .line 19: return-void
.end method

# virtual methods
.method public dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 7

    .line 0: const-string v0, "canvas"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-super {v5}, Landroid/view/ViewGroup;->getChildCount()I
    .line 8: move-result v0
    .line 9: const/4 v1, 0
    .line 10: move v2, v1
    .line 11: if-ge v2, v0, :cond_44
    .line 13: invoke-virtual {v5, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 16: move-result-object v3
    .line 17: const-string v4, "null cannot be cast to non-null type androidx.compose.ui.platform.ViewLayer"
    .line 19: invoke-static {v3, v4}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: check-cast v3, Landroidx/compose/ui/platform/p2;
    .line 24: iget-boolean v3, v3, Landroidx/compose/ui/platform/p2;->p:Z
    .line 26: if-eqz v3, :cond_41
    .line 28: const/4 v0, 1
    .line 29: iput-boolean v0, v5, Landroidx/compose/ui/platform/o1;->i:Z
    .line 31: invoke-super {v5, v6}, Landroid/view/ViewGroup;->dispatchDraw(Landroid/graphics/Canvas;)V
    .line 34: iput-boolean v1, v5, Landroidx/compose/ui/platform/o1;->i:Z
    .line 36: goto :goto_44
    .line 37: move-exception v6
    .line 38: iput-boolean v1, v5, Landroidx/compose/ui/platform/o1;->i:Z
    .line 40: throw v6
    .line 41: add-int/lit8 v2, v2, 1
    .line 43: goto :goto_11
    .line 44: return-void
.end method

# virtual methods
.method public getChildCount()I
    .registers 2

    .line 0: iget-boolean v0, v1, Landroidx/compose/ui/platform/o1;->i:Z
    .line 2: if-eqz v0, :cond_9
    .line 4: invoke-super {v1}, Landroid/view/ViewGroup;->getChildCount()I
    .line 7: move-result v0
    .line 8: goto :goto_10
    .line 9: const/4 v0, 0
    .line 10: return v0
.end method

# virtual methods
.method public final onLayout(ZIIII)V
    .registers 6

    .line 0: return-void
.end method

# virtual methods
.method public final onMeasure(II)V
    .registers 3

    .line 0: const/4 v1, 0
    .line 1: invoke-virtual {v0, v1, v1}, Landroid/view/View;->setMeasuredDimension(II)V
    .line 4: return-void
.end method

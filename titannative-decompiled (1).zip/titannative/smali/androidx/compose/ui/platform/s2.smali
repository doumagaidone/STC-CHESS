.class public final Landroidx/compose/ui/platform/s2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/s2;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/s2;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/s2;->a:Landroidx/compose/ui/platform/s2;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/View;I)V
    .registers 4

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v2, v3}, Landroidx/compose/ui/platform/r2;->l(Landroid/view/View;I)V
    .line 8: return-void
.end method

# virtual methods
.method public final b(Landroid/view/View;I)V
    .registers 4

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v2, v3}, Landroidx/compose/ui/platform/r2;->g(Landroid/view/View;I)V
    .line 8: return-void
.end method

.class public abstract interface Landroidx/compose/ui/platform/g;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a(I)[I
.end method

# virtual methods
.method public abstract b(I)[I
.end method

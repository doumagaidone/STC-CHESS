.class public abstract synthetic Landroidx/compose/ui/platform/m;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static bridge synthetic a(Landroid/content/res/Configuration;)I
    .registers 1

    .line 0: iget v0, v0, Landroid/content/res/Configuration;->fontWeightAdjustment:I
    .line 2: return v0
.end method

# direct methods
.method public static bridge synthetic b()Landroid/graphics/Shader$TileMode;
    .registers 1

    .line 0: sget-object v0, Landroid/graphics/Shader$TileMode;->DECAL:Landroid/graphics/Shader$TileMode;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic c(Landroid/graphics/Canvas;Landroid/graphics/NinePatch;Landroid/graphics/Rect;Landroid/graphics/Paint;)V
    .registers 4

    .line 0: invoke-virtual {v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawPatch(Landroid/graphics/NinePatch;Landroid/graphics/Rect;Landroid/graphics/Paint;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic d(Landroid/graphics/Canvas;Landroid/graphics/NinePatch;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    .registers 4

    .line 0: invoke-virtual {v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawPatch(Landroid/graphics/NinePatch;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic e(Landroid/graphics/Canvas;[II[FIILandroid/graphics/fonts/Font;Landroid/graphics/Paint;)V
    .registers 8

    .line 0: invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawGlyphs([II[FIILandroid/graphics/fonts/Font;Landroid/graphics/Paint;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic f(Landroid/graphics/RenderNode;)V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Landroid/graphics/RenderNode;->setRenderEffect(Landroid/graphics/RenderEffect;)Z
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic g(Landroid/view/View;)V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Landroid/view/View;->setRenderEffect(Landroid/graphics/RenderEffect;)V
    .line 4: return-void
.end method

.class public abstract Landroidx/compose/ui/platform/z;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Landroid/view/accessibility/AccessibilityEvent;II)V
    .registers 4

    .line 0: const-string v0, "event"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityEvent;->setScrollDeltaX(I)V
    .line 8: invoke-virtual {v1, v3}, Landroid/view/accessibility/AccessibilityEvent;->setScrollDeltaY(I)V
    .line 11: return-void
.end method

.class public final Landroidx/compose/ui/platform/t0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/Choreographer$FrameCallback;
.implements Ljava/lang/Runnable;

.field public final synthetic i:Landroidx/compose/ui/platform/u0;

# direct methods
.method public constructor <init>(Landroidx/compose/ui/platform/u0;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/t0;->i:Landroidx/compose/ui/platform/u0;
    .line 5: return-void
.end method

# virtual methods
.method public final doFrame(J)V
    .registers 8

    .line 0: iget-object v0, v5, Landroidx/compose/ui/platform/t0;->i:Landroidx/compose/ui/platform/u0;
    .line 2: iget-object v0, v0, Landroidx/compose/ui/platform/u0;->l:Landroid/os/Handler;
    .line 4: invoke-virtual {v0, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    .line 7: iget-object v0, v5, Landroidx/compose/ui/platform/t0;->i:Landroidx/compose/ui/platform/u0;
    .line 9: invoke-static {v0}, Landroidx/compose/ui/platform/u0;->P(Landroidx/compose/ui/platform/u0;)V
    .line 12: iget-object v0, v5, Landroidx/compose/ui/platform/t0;->i:Landroidx/compose/ui/platform/u0;
    .line 14: iget-object v1, v0, Landroidx/compose/ui/platform/u0;->m:Ljava/lang/Object;
    .line 16: monitor-enter v1
    .line 17: iget-boolean v2, v0, Landroidx/compose/ui/platform/u0;->r:Z
    .line 19: if-nez v2, :cond_23
    .line 21: monitor-exit v1
    .line 22: goto :goto_56
    .line 23: const/4 v2, 0
    .line 24: iput-boolean v2, v0, Landroidx/compose/ui/platform/u0;->r:Z
    .line 26: iget-object v3, v0, Landroidx/compose/ui/platform/u0;->o:Ljava/util/List;
    .line 28: iget-object v4, v0, Landroidx/compose/ui/platform/u0;->p:Ljava/util/List;
    .line 30: iput-object v4, v0, Landroidx/compose/ui/platform/u0;->o:Ljava/util/List;
    .line 32: iput-object v3, v0, Landroidx/compose/ui/platform/u0;->p:Ljava/util/List;
    .line 34: monitor-exit v1
    .line 35: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 38: move-result v0
    .line 39: if-ge v2, v0, :cond_53
    .line 41: invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 44: move-result-object v1
    .line 45: check-cast v1, Landroid/view/Choreographer$FrameCallback;
    .line 47: invoke-interface {v1, v6, v7}, Landroid/view/Choreographer$FrameCallback;->doFrame(J)V
    .line 50: add-int/lit8 v2, v2, 1
    .line 52: goto :goto_39
    .line 53: invoke-interface {v3}, Ljava/util/List;->clear()V
    .line 56: return-void
    .line 57: move-exception v6
    .line 58: monitor-exit v1
    .line 59: throw v6
.end method

# virtual methods
.method public final run()V
    .registers 4

    .line 0: iget-object v0, v3, Landroidx/compose/ui/platform/t0;->i:Landroidx/compose/ui/platform/u0;
    .line 2: invoke-static {v0}, Landroidx/compose/ui/platform/u0;->P(Landroidx/compose/ui/platform/u0;)V
    .line 5: iget-object v0, v3, Landroidx/compose/ui/platform/t0;->i:Landroidx/compose/ui/platform/u0;
    .line 7: iget-object v1, v0, Landroidx/compose/ui/platform/u0;->m:Ljava/lang/Object;
    .line 9: monitor-enter v1
    .line 10: iget-object v2, v0, Landroidx/compose/ui/platform/u0;->o:Ljava/util/List;
    .line 12: invoke-interface {v2}, Ljava/util/List;->isEmpty()Z
    .line 15: move-result v2
    .line 16: if-eqz v2, :cond_29
    .line 18: iget-object v2, v0, Landroidx/compose/ui/platform/u0;->k:Landroid/view/Choreographer;
    .line 20: invoke-virtual {v2, v3}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V
    .line 23: const/4 v2, 0
    .line 24: iput-boolean v2, v0, Landroidx/compose/ui/platform/u0;->r:Z
    .line 26: goto :goto_29
    .line 27: move-exception v0
    .line 28: goto :goto_31
    .line 29: monitor-exit v1
    .line 30: return-void
    .line 31: monitor-exit v1
    .line 32: throw v0
.end method

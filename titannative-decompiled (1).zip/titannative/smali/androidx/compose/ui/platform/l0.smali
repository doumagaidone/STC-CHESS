.class public final Landroidx/compose/ui/platform/l0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/l0;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/l0;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/l0;->a:Landroidx/compose/ui/platform/l0;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/View;Lu0/n;)V
    .registers 4

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: instance-of v0, v3, Lu0/a;
    .line 7: if-eqz v0, :cond_27
    .line 9: invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 12: move-result-object v0
    .line 13: check-cast v3, Lu0/a;
    .line 15: iget v3, v3, Lu0/a;->c:I
    .line 17: invoke-static {v0, v3}, Landroid/view/PointerIcon;->getSystemIcon(Landroid/content/Context;I)Landroid/view/PointerIcon;
    .line 20: move-result-object v3
    .line 21: const-string v0, "getSystemIcon(view.context, icon.type)"
    .line 23: invoke-static {v3, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 26: goto :goto_42
    .line 27: invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 30: move-result-object v3
    .line 31: const/16 v0, 1000
    .line 33: invoke-static {v3, v0}, Landroid/view/PointerIcon;->getSystemIcon(Landroid/content/Context;I)Landroid/view/PointerIcon;
    .line 36: move-result-object v3
    .line 37: const-string v0, "getSystemIcon(\n         …DEFAULT\n                )"
    .line 39: invoke-static {v3, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 42: invoke-virtual {v2}, Landroid/view/View;->getPointerIcon()Landroid/view/PointerIcon;
    .line 45: move-result-object v0
    .line 46: invoke-static {v0, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 49: move-result v0
    .line 50: if-nez v0, :cond_55
    .line 52: invoke-virtual {v2, v3}, Landroid/view/View;->setPointerIcon(Landroid/view/PointerIcon;)V
    .line 55: return-void
.end method

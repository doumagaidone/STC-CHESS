.class public abstract Landroidx/compose/ui/platform/i1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/j3;
.field public static final b:Lu/j3;
.field public static final c:Lu/j3;
.field public static final d:Lu/j3;
.field public static final e:Lu/j3;
.field public static final f:Lu/j3;
.field public static final g:Lu/j3;
.field public static final h:Lu/j3;
.field public static final i:Lu/j3;
.field public static final j:Lu/j3;
.field public static final k:Lu/j3;
.field public static final l:Lu/j3;
.field public static final m:Lu/j3;
.field public static final n:Lu/j3;
.field public static final o:Lu/j3;
.field public static final p:Lu/j3;
.field public static final q:Lu/j3;
.field public static final r:Lu/j3;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Landroidx/compose/ui/platform/n0;->r:Landroidx/compose/ui/platform/n0;
    .line 2: new-instance v1, Lu/j3;
    .line 4: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 7: sput-object v1, Landroidx/compose/ui/platform/i1;->a:Lu/j3;
    .line 9: sget-object v0, Landroidx/compose/ui/platform/n0;->s:Landroidx/compose/ui/platform/n0;
    .line 11: new-instance v1, Lu/j3;
    .line 13: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 16: sput-object v1, Landroidx/compose/ui/platform/i1;->b:Lu/j3;
    .line 18: sget-object v0, Landroidx/compose/ui/platform/n0;->t:Landroidx/compose/ui/platform/n0;
    .line 20: new-instance v1, Lu/j3;
    .line 22: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 25: sput-object v1, Landroidx/compose/ui/platform/i1;->c:Lu/j3;
    .line 27: sget-object v0, Landroidx/compose/ui/platform/n0;->u:Landroidx/compose/ui/platform/n0;
    .line 29: new-instance v1, Lu/j3;
    .line 31: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 34: sput-object v1, Landroidx/compose/ui/platform/i1;->d:Lu/j3;
    .line 36: sget-object v0, Landroidx/compose/ui/platform/n0;->v:Landroidx/compose/ui/platform/n0;
    .line 38: new-instance v1, Lu/j3;
    .line 40: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 43: sput-object v1, Landroidx/compose/ui/platform/i1;->e:Lu/j3;
    .line 45: sget-object v0, Landroidx/compose/ui/platform/n0;->w:Landroidx/compose/ui/platform/n0;
    .line 47: new-instance v1, Lu/j3;
    .line 49: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 52: sput-object v1, Landroidx/compose/ui/platform/i1;->f:Lu/j3;
    .line 54: sget-object v0, Landroidx/compose/ui/platform/n0;->y:Landroidx/compose/ui/platform/n0;
    .line 56: new-instance v1, Lu/j3;
    .line 58: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 61: sput-object v1, Landroidx/compose/ui/platform/i1;->g:Lu/j3;
    .line 63: sget-object v0, Landroidx/compose/ui/platform/n0;->x:Landroidx/compose/ui/platform/n0;
    .line 65: new-instance v1, Lu/j3;
    .line 67: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 70: sput-object v1, Landroidx/compose/ui/platform/i1;->h:Lu/j3;
    .line 72: sget-object v0, Landroidx/compose/ui/platform/n0;->z:Landroidx/compose/ui/platform/n0;
    .line 74: new-instance v1, Lu/j3;
    .line 76: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 79: sput-object v1, Landroidx/compose/ui/platform/i1;->i:Lu/j3;
    .line 81: sget-object v0, Landroidx/compose/ui/platform/n0;->A:Landroidx/compose/ui/platform/n0;
    .line 83: new-instance v1, Lu/j3;
    .line 85: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 88: sput-object v1, Landroidx/compose/ui/platform/i1;->j:Lu/j3;
    .line 90: sget-object v0, Landroidx/compose/ui/platform/n0;->B:Landroidx/compose/ui/platform/n0;
    .line 92: new-instance v1, Lu/j3;
    .line 94: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 97: sput-object v1, Landroidx/compose/ui/platform/i1;->k:Lu/j3;
    .line 99: sget-object v0, Landroidx/compose/ui/platform/n0;->E:Landroidx/compose/ui/platform/n0;
    .line 101: new-instance v1, Lu/j3;
    .line 103: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 106: sput-object v1, Landroidx/compose/ui/platform/i1;->l:Lu/j3;
    .line 108: sget-object v0, Landroidx/compose/ui/platform/n0;->C:Landroidx/compose/ui/platform/n0;
    .line 110: new-instance v1, Lu/j3;
    .line 112: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 115: sput-object v1, Landroidx/compose/ui/platform/i1;->m:Lu/j3;
    .line 117: sget-object v0, Landroidx/compose/ui/platform/n0;->F:Landroidx/compose/ui/platform/n0;
    .line 119: new-instance v1, Lu/j3;
    .line 121: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 124: sput-object v1, Landroidx/compose/ui/platform/i1;->n:Lu/j3;
    .line 126: sget-object v0, Landroidx/compose/ui/platform/n0;->G:Landroidx/compose/ui/platform/n0;
    .line 128: new-instance v1, Lu/j3;
    .line 130: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 133: sput-object v1, Landroidx/compose/ui/platform/i1;->o:Lu/j3;
    .line 135: sget-object v0, Landroidx/compose/ui/platform/n0;->H:Landroidx/compose/ui/platform/n0;
    .line 137: new-instance v1, Lu/j3;
    .line 139: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 142: sput-object v1, Landroidx/compose/ui/platform/i1;->p:Lu/j3;
    .line 144: sget-object v0, Landroidx/compose/ui/platform/n0;->I:Landroidx/compose/ui/platform/n0;
    .line 146: new-instance v1, Lu/j3;
    .line 148: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 151: sput-object v1, Landroidx/compose/ui/platform/i1;->q:Lu/j3;
    .line 153: sget-object v0, Landroidx/compose/ui/platform/n0;->D:Landroidx/compose/ui/platform/n0;
    .line 155: new-instance v1, Lu/j3;
    .line 157: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 160: sput-object v1, Landroidx/compose/ui/platform/i1;->r:Lu/j3;
    .line 162: return-void
.end method

# direct methods
.method public static final a(Lz0/j1;Landroidx/compose/ui/platform/k2;Ld3/e;Lu/l;I)V
    .registers 31

    .line 0: move-object/from16 v1, v26
    .line 2: move-object/from16 v2, v27
    .line 4: move-object/from16 v3, v28
    .line 6: move/from16 v4, v30
    .line 8: const-string v0, "owner"
    .line 10: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: const-string v0, "uriHandler"
    .line 15: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 18: const-string v0, "content"
    .line 20: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 23: move-object/from16 v0, v29
    .line 25: check-cast v0, Lu/b0;
    .line 27: const v5, 0x34224bad
    .line 30: invoke-virtual {v0, v5}, Lu/b0;->e0(I)Lu/b0;
    .line 33: and-int/lit8 v5, v4, 14
    .line 35: if-nez v5, :cond_48
    .line 37: invoke-virtual {v0, v1}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 40: move-result v5
    .line 41: if-eqz v5, :cond_45
    .line 43: const/4 v5, 4
    .line 44: goto :goto_46
    .line 45: const/4 v5, 2
    .line 46: or-int/2addr v5, v4
    .line 47: goto :goto_49
    .line 48: move v5, v4
    .line 49: and-int/lit8 v6, v4, 112
    .line 51: if-nez v6, :cond_65
    .line 53: invoke-virtual {v0, v2}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 56: move-result v6
    .line 57: if-eqz v6, :cond_62
    .line 59: const/16 v6, 32
    .line 61: goto :goto_64
    .line 62: const/16 v6, 16
    .line 64: or-int/2addr v5, v6
    .line 65: and-int/lit16 v6, v4, 896
    .line 67: if-nez v6, :cond_81
    .line 69: invoke-virtual {v0, v3}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 72: move-result v6
    .line 73: if-eqz v6, :cond_78
    .line 75: const/16 v6, 256
    .line 77: goto :goto_80
    .line 78: const/16 v6, 128
    .line 80: or-int/2addr v5, v6
    .line 81: and-int/lit16 v6, v5, 731
    .line 83: const/16 v7, 146
    .line 85: if-ne v6, v7, :cond_99
    .line 87: invoke-virtual {v0}, Lu/b0;->F()Z
    .line 90: move-result v6
    .line 91: if-nez v6, :cond_94
    .line 93: goto :goto_99
    .line 94: invoke-virtual {v0}, Lu/b0;->Y()V
    .line 97: goto/16 :goto_298
    .line 99: sget-object v6, Landroidx/compose/ui/platform/i1;->a:Lu/j3;
    .line 101: invoke-interface/range {v26 .. v26}, Lz0/j1;->getAccessibilityManager()Landroidx/compose/ui/platform/i;
    .line 104: move-result-object v7
    .line 105: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 108: move-result-object v8
    .line 109: sget-object v6, Landroidx/compose/ui/platform/i1;->b:Lu/j3;
    .line 111: invoke-interface/range {v26 .. v26}, Lz0/j1;->getAutofill()Lg0/b;
    .line 114: move-result-object v7
    .line 115: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 118: move-result-object v9
    .line 119: sget-object v6, Landroidx/compose/ui/platform/i1;->c:Lu/j3;
    .line 121: invoke-interface/range {v26 .. v26}, Lz0/j1;->getAutofillTree()Lg0/g;
    .line 124: move-result-object v7
    .line 125: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 128: move-result-object v10
    .line 129: sget-object v6, Landroidx/compose/ui/platform/i1;->d:Lu/j3;
    .line 131: invoke-interface/range {v26 .. v26}, Lz0/j1;->getClipboardManager()Landroidx/compose/ui/platform/e1;
    .line 134: move-result-object v7
    .line 135: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 138: move-result-object v11
    .line 139: sget-object v6, Landroidx/compose/ui/platform/i1;->e:Lu/j3;
    .line 141: invoke-interface/range {v26 .. v26}, Lz0/j1;->getDensity()Lr1/b;
    .line 144: move-result-object v7
    .line 145: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 148: move-result-object v12
    .line 149: sget-object v6, Landroidx/compose/ui/platform/i1;->f:Lu/j3;
    .line 151: invoke-interface/range {v26 .. v26}, Lz0/j1;->getFocusOwner()Li0/e;
    .line 154: move-result-object v7
    .line 155: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 158: move-result-object v13
    .line 159: invoke-interface/range {v26 .. v26}, Lz0/j1;->getFontLoader()Lk1/p;
    .line 162: move-result-object v6
    .line 163: sget-object v7, Landroidx/compose/ui/platform/i1;->g:Lu/j3;
    .line 165: invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 168: new-instance v14, Lu/a2;
    .line 170: const/4 v15, 0
    .line 171: invoke-direct {v14, v7, v6, v15}, Lu/a2;-><init>(Lu/j0;Ljava/lang/Object;Z)V
    .line 174: invoke-interface/range {v26 .. v26}, Lz0/j1;->getFontFamilyResolver()Lk1/r;
    .line 177: move-result-object v6
    .line 178: sget-object v7, Landroidx/compose/ui/platform/i1;->h:Lu/j3;
    .line 180: invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 183: new-instance v1, Lu/a2;
    .line 185: invoke-direct {v1, v7, v6, v15}, Lu/a2;-><init>(Lu/j0;Ljava/lang/Object;Z)V
    .line 188: sget-object v6, Landroidx/compose/ui/platform/i1;->i:Lu/j3;
    .line 190: invoke-interface/range {v26 .. v26}, Lz0/j1;->getHapticFeedBack()Lq0/a;
    .line 193: move-result-object v7
    .line 194: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 197: move-result-object v16
    .line 198: sget-object v6, Landroidx/compose/ui/platform/i1;->j:Lu/j3;
    .line 200: invoke-interface/range {v26 .. v26}, Lz0/j1;->getInputModeManager()Lr0/b;
    .line 203: move-result-object v7
    .line 204: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 207: move-result-object v17
    .line 208: sget-object v6, Landroidx/compose/ui/platform/i1;->k:Lu/j3;
    .line 210: invoke-interface/range {v26 .. v26}, Lz0/j1;->getLayoutDirection()Lr1/j;
    .line 213: move-result-object v7
    .line 214: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 217: move-result-object v18
    .line 218: sget-object v6, Landroidx/compose/ui/platform/i1;->l:Lu/j3;
    .line 220: invoke-interface/range {v26 .. v26}, Lz0/j1;->getTextInputService()Ll1/f0;
    .line 223: move-result-object v7
    .line 224: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 227: move-result-object v19
    .line 228: sget-object v6, Landroidx/compose/ui/platform/i1;->m:Lu/j3;
    .line 230: invoke-interface/range {v26 .. v26}, Lz0/j1;->getPlatformTextInputPluginRegistry()Ll1/t;
    .line 233: move-result-object v7
    .line 234: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 237: move-result-object v20
    .line 238: sget-object v6, Landroidx/compose/ui/platform/i1;->n:Lu/j3;
    .line 240: invoke-interface/range {v26 .. v26}, Lz0/j1;->getTextToolbar()Landroidx/compose/ui/platform/i2;
    .line 243: move-result-object v7
    .line 244: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 247: move-result-object v21
    .line 248: sget-object v6, Landroidx/compose/ui/platform/i1;->o:Lu/j3;
    .line 250: invoke-virtual {v6, v2}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 253: move-result-object v22
    .line 254: sget-object v6, Landroidx/compose/ui/platform/i1;->p:Lu/j3;
    .line 256: invoke-interface/range {v26 .. v26}, Lz0/j1;->getViewConfiguration()Landroidx/compose/ui/platform/m2;
    .line 259: move-result-object v7
    .line 260: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 263: move-result-object v23
    .line 264: sget-object v6, Landroidx/compose/ui/platform/i1;->q:Lu/j3;
    .line 266: invoke-interface/range {v26 .. v26}, Lz0/j1;->getWindowInfo()Landroidx/compose/ui/platform/u2;
    .line 269: move-result-object v7
    .line 270: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 273: move-result-object v24
    .line 274: sget-object v6, Landroidx/compose/ui/platform/i1;->r:Lu/j3;
    .line 276: invoke-interface/range {v26 .. v26}, Lz0/j1;->getPointerIconService()Lu0/w;
    .line 279: move-result-object v7
    .line 280: invoke-virtual {v6, v7}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 283: move-result-object v25
    .line 284: move-object v15, v1
    .line 285: filled-new-array/range {v8 .. v25}, [Lu/a2;
    .line 288: move-result-object v1
    .line 289: shr-int/lit8 v5, v5, 3
    .line 291: and-int/lit8 v5, v5, 112
    .line 293: or-int/lit8 v5, v5, 8
    .line 295: invoke-static {v1, v3, v0, v5}, Le3/g;->d([Lu/a2;Ld3/e;Lu/l;I)V
    .line 298: invoke-virtual {v0}, Lu/b0;->x()Lu/c2;
    .line 301: move-result-object v6
    .line 302: if-nez v6, :cond_305
    .line 304: goto :goto_322
    .line 305: new-instance v7, Lo/e0;
    .line 307: const/4 v5, 4
    .line 308: move-object v0, v7
    .line 309: move-object/from16 v1, v26
    .line 311: move-object/from16 v2, v27
    .line 313: move-object/from16 v3, v28
    .line 315: move/from16 v4, v30
    .line 317: invoke-direct/range {v0 .. v5}, Lo/e0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .line 320: iput-object v7, v6, Lu/c2;->d:Ld3/e;
    .line 322: return-void
.end method

# direct methods
.method public static final b(Ljava/lang/String;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/IllegalStateException;
    .line 2: new-instance v1, Ljava/lang/StringBuilder;
    .line 4: const-string v2, "CompositionLocal "
    .line 6: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 9: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v3, " not present"
    .line 14: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 20: move-result-object v3
    .line 21: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 24: move-result-object v3
    .line 25: invoke-direct {v0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 28: throw v0
.end method

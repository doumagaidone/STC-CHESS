.class public abstract interface Landroidx/compose/ui/platform/k2;
.super Ljava/lang/Object;
.source "SourceFile"

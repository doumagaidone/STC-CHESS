.class public final Landroidx/compose/ui/platform/g0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Comparator;

.field public final synthetic a:I
.field public final synthetic b:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Landroidx/compose/ui/platform/g0;->a:I
    .line 5: iput-object v2, v0, Landroidx/compose/ui/platform/g0;->b:Ljava/lang/Object;
    .line 7: return-void
.end method

# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 5

    .line 0: iget v0, v2, Landroidx/compose/ui/platform/g0;->a:I
    .line 2: iget-object v1, v2, Landroidx/compose/ui/platform/g0;->b:Ljava/lang/Object;
    .line 4: packed-switch v0, :data_102
    .line 7: check-cast v4, Lt2/u;
    .line 9: check-cast v1, Ljava/util/HashMap;
    .line 11: iget-object v4, v4, Lt2/u;->b:Ljava/lang/Object;
    .line 13: invoke-static {v4, v1}, Lt2/k;->T0(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;
    .line 16: move-result-object v4
    .line 17: check-cast v4, Ls2/e;
    .line 19: iget-object v4, v4, Ls2/e;->j:Ljava/lang/Object;
    .line 21: check-cast v4, Ljava/lang/Comparable;
    .line 23: check-cast v3, Lt2/u;
    .line 25: iget-object v3, v3, Lt2/u;->b:Ljava/lang/Object;
    .line 27: invoke-static {v3, v1}, Lt2/k;->T0(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;
    .line 30: move-result-object v3
    .line 31: check-cast v3, Ls2/e;
    .line 33: iget-object v3, v3, Ls2/e;->j:Ljava/lang/Object;
    .line 35: check-cast v3, Ljava/lang/Comparable;
    .line 37: invoke-static {v4, v3}, Ld2/c;->x(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .line 40: move-result v3
    .line 41: return v3
    .line 42: check-cast v1, Ljava/util/Comparator;
    .line 44: invoke-interface {v1, v3, v4}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .line 47: move-result v0
    .line 48: if-eqz v0, :cond_51
    .line 50: goto :goto_71
    .line 51: check-cast v3, Lt2/u;
    .line 53: iget v3, v3, Lt2/u;->a:I
    .line 55: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 58: move-result-object v3
    .line 59: check-cast v4, Lt2/u;
    .line 61: iget v4, v4, Lt2/u;->a:I
    .line 63: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 66: move-result-object v4
    .line 67: invoke-static {v3, v4}, Ld2/c;->x(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .line 70: move-result v0
    .line 71: return v0
    .line 72: check-cast v1, Ljava/util/Comparator;
    .line 74: invoke-interface {v1, v3, v4}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .line 77: move-result v0
    .line 78: if-eqz v0, :cond_81
    .line 80: goto :goto_101
    .line 81: check-cast v3, Ld1/n;
    .line 83: iget v3, v3, Ld1/n;->g:I
    .line 85: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 88: move-result-object v3
    .line 89: check-cast v4, Ld1/n;
    .line 91: iget v4, v4, Ld1/n;->g:I
    .line 93: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 96: move-result-object v4
    .line 97: invoke-static {v3, v4}, Ld2/c;->x(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .line 100: move-result v0
    .line 101: return v0
    .line 102: nop
    .line 103: move/from16 v0, v0
    .line 105: nop
    .line 106: aget v0, v0, v0
    .line 108: fill-array-data v0, :data_196716
.end method

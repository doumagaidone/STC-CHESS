.class public final Landroidx/compose/ui/platform/m0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/m0;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/m0;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/m0;->a:Landroidx/compose/ui/platform/m0;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/View;IZ)V
    .registers 5

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v2, v3}, Lai/onnxruntime/a;->q(Landroid/view/View;I)V
    .line 8: invoke-static {v2, v4}, Lai/onnxruntime/a;->r(Landroid/view/View;Z)V
    .line 11: return-void
.end method

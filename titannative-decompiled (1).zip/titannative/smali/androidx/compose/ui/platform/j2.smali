.class public final Landroidx/compose/ui/platform/j2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/j2;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/j2;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/j2;->a:Landroidx/compose/ui/platform/j2;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/ActionMode;)V
    .registers 3

    .line 0: const-string v0, "actionMode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/view/ActionMode;->invalidateContentRect()V
    .line 8: return-void
.end method

# virtual methods
.method public final b(Landroid/view/View;Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;
    .registers 5

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "actionModeCallback"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-virtual {v2, v3, v4}, Landroid/view/View;->startActionMode(Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;
    .line 13: move-result-object v2
    .line 14: return-object v2
.end method

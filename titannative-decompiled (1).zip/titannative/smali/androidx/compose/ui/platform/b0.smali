.class public final Landroidx/compose/ui/platform/b0;
.super Landroid/view/accessibility/AccessibilityNodeProvider;
.source "SourceFile"

.field public final synthetic a:Landroidx/compose/ui/platform/j0;

# direct methods
.method public constructor <init>(Landroidx/compose/ui/platform/j0;)V
    .registers 2

    .line 0: iput-object v1, v0, Landroidx/compose/ui/platform/b0;->a:Landroidx/compose/ui/platform/j0;
    .line 2: invoke-direct {v0}, Landroid/view/accessibility/AccessibilityNodeProvider;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public final addExtraDataToAccessibilityNodeInfo(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Landroid/os/Bundle;)V
    .registers 6

    .line 0: const-string v0, "info"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "extraDataKey"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: iget-object v0, v1, Landroidx/compose/ui/platform/b0;->a:Landroidx/compose/ui/platform/j0;
    .line 12: invoke-virtual {v0, v2, v3, v4, v5}, Landroidx/compose/ui/platform/j0;->b(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Landroid/os/Bundle;)V
    .line 15: return-void
.end method

# virtual methods
.method public final createAccessibilityNodeInfo(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .registers 27

    .line 0: move/from16 v0, v26
    .line 2: move-object/from16 v1, v25
    .line 4: iget-object v2, v1, Landroidx/compose/ui/platform/b0;->a:Landroidx/compose/ui/platform/j0;
    .line 6: iget-object v3, v2, Landroidx/compose/ui/platform/j0;->d:Landroidx/compose/ui/platform/AndroidComposeView;
    .line 8: invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getViewTreeOwners()Landroidx/compose/ui/platform/q;
    .line 11: move-result-object v4
    .line 12: if-eqz v4, :cond_29
    .line 14: iget-object v4, v4, Landroidx/compose/ui/platform/q;->a:Landroidx/lifecycle/t;
    .line 16: if-eqz v4, :cond_29
    .line 18: invoke-interface {v4}, Landroidx/lifecycle/t;->getLifecycle()Landroidx/lifecycle/o;
    .line 21: move-result-object v4
    .line 22: if-eqz v4, :cond_29
    .line 24: check-cast v4, Landroidx/lifecycle/v;
    .line 26: iget-object v4, v4, Landroidx/lifecycle/v;->c:Landroidx/lifecycle/n;
    .line 28: goto :goto_30
    .line 29: const/4 v4, 0
    .line 30: sget-object v6, Landroidx/lifecycle/n;->i:Landroidx/lifecycle/n;
    .line 32: if-ne v4, v6, :cond_37
    .line 34: const/4 v5, 0
    .line 35: goto/16 :goto_2296
    .line 37: invoke-static {}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain()Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 40: move-result-object v4
    .line 41: new-instance v6, Lf2/k;
    .line 43: invoke-direct {v6, v4}, Lf2/k;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .line 46: invoke-virtual {v2}, Landroidx/compose/ui/platform/j0;->i()Ljava/util/Map;
    .line 49: move-result-object v7
    .line 50: invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 53: move-result-object v8
    .line 54: invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 57: move-result-object v7
    .line 58: check-cast v7, Landroidx/compose/ui/platform/h2;
    .line 60: if-nez v7, :cond_63
    .line 62: goto :goto_34
    .line 63: const/4 v8, -1
    .line 64: iget-object v9, v7, Landroidx/compose/ui/platform/h2;->a:Ld1/n;
    .line 66: if-ne v0, v8, :cond_88
    .line 68: sget v10, Le2/q;->a:I
    .line 70: invoke-static {v3}, Le2/j;->f(Landroid/view/View;)Landroid/view/ViewParent;
    .line 73: move-result-object v10
    .line 74: instance-of v11, v10, Landroid/view/View;
    .line 76: if-eqz v11, :cond_81
    .line 78: check-cast v10, Landroid/view/View;
    .line 80: goto :goto_82
    .line 81: const/4 v10, 0
    .line 82: iput v8, v6, Lf2/k;->b:I
    .line 84: invoke-virtual {v4, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->setParent(Landroid/view/View;)V
    .line 87: goto :goto_122
    .line 88: invoke-virtual {v9}, Ld1/n;->i()Ld1/n;
    .line 91: move-result-object v10
    .line 92: if-eqz v10, :cond_2297
    .line 94: invoke-virtual {v9}, Ld1/n;->i()Ld1/n;
    .line 97: move-result-object v10
    .line 98: invoke-static {v10}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 101: invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Ld1/o;
    .line 104: move-result-object v11
    .line 105: invoke-virtual {v11}, Ld1/o;->a()Ld1/n;
    .line 108: move-result-object v11
    .line 109: iget v11, v11, Ld1/n;->g:I
    .line 111: iget v10, v10, Ld1/n;->g:I
    .line 113: if-ne v10, v11, :cond_116
    .line 115: goto :goto_117
    .line 116: move v8, v10
    .line 117: iput v8, v6, Lf2/k;->b:I
    .line 119: invoke-virtual {v4, v3, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setParent(Landroid/view/View;I)V
    .line 122: iput v0, v6, Lf2/k;->c:I
    .line 124: invoke-virtual {v4, v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setSource(Landroid/view/View;I)V
    .line 127: iget-object v7, v7, Landroidx/compose/ui/platform/h2;->b:Landroid/graphics/Rect;
    .line 129: iget v8, v7, Landroid/graphics/Rect;->left:I
    .line 131: int-to-float v8, v8
    .line 132: iget v10, v7, Landroid/graphics/Rect;->top:I
    .line 134: int-to-float v10, v10
    .line 135: invoke-static {v8, v10}, Ln3/a0;->g(FF)J
    .line 138: move-result-wide v10
    .line 139: invoke-virtual {v3, v10, v11}, Landroidx/compose/ui/platform/AndroidComposeView;->p(J)J
    .line 142: move-result-wide v10
    .line 143: iget v8, v7, Landroid/graphics/Rect;->right:I
    .line 145: int-to-float v8, v8
    .line 146: iget v7, v7, Landroid/graphics/Rect;->bottom:I
    .line 148: int-to-float v7, v7
    .line 149: invoke-static {v8, v7}, Ln3/a0;->g(FF)J
    .line 152: move-result-wide v7
    .line 153: invoke-virtual {v3, v7, v8}, Landroidx/compose/ui/platform/AndroidComposeView;->p(J)J
    .line 156: move-result-wide v7
    .line 157: new-instance v12, Landroid/graphics/Rect;
    .line 159: invoke-static {v10, v11}, Lj0/c;->c(J)F
    .line 162: move-result v13
    .line 163: float-to-double v13, v13
    .line 164: invoke-static {v13, v14}, Ljava/lang/Math;->floor(D)D
    .line 167: move-result-wide v13
    .line 168: double-to-float v13, v13
    .line 169: float-to-int v13, v13
    .line 170: invoke-static {v10, v11}, Lj0/c;->d(J)F
    .line 173: move-result v10
    .line 174: float-to-double v10, v10
    .line 175: invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D
    .line 178: move-result-wide v10
    .line 179: double-to-float v10, v10
    .line 180: float-to-int v10, v10
    .line 181: invoke-static {v7, v8}, Lj0/c;->c(J)F
    .line 184: move-result v11
    .line 185: float-to-double v14, v11
    .line 186: invoke-static {v14, v15}, Ljava/lang/Math;->ceil(D)D
    .line 189: move-result-wide v14
    .line 190: double-to-float v11, v14
    .line 191: float-to-int v11, v11
    .line 192: invoke-static {v7, v8}, Lj0/c;->d(J)F
    .line 195: move-result v7
    .line 196: float-to-double v7, v7
    .line 197: invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D
    .line 200: move-result-wide v7
    .line 201: double-to-float v7, v7
    .line 202: float-to-int v7, v7
    .line 203: invoke-direct {v12, v13, v10, v11, v7}, Landroid/graphics/Rect;-><init>(IIII)V
    .line 206: invoke-virtual {v4, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInScreen(Landroid/graphics/Rect;)V
    .line 209: const-string v7, "semanticsNode"
    .line 211: invoke-static {v9, v7}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 214: const-string v7, "android.view.View"
    .line 216: invoke-virtual {v6, v7}, Lf2/k;->f(Ljava/lang/String;)V
    .line 219: sget-object v7, Ld1/q;->r:Ld1/t;
    .line 221: iget-object v8, v9, Ld1/n;->d:Ld1/i;
    .line 223: invoke-static {v8, v7}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 226: move-result-object v7
    .line 227: check-cast v7, Ld1/f;
    .line 229: const/4 v10, 2
    .line 230: const/4 v11, 0
    .line 231: const/4 v12, 1
    .line 232: iget-object v13, v9, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 234: const/4 v14, 4
    .line 235: if-eqz v7, :cond_354
    .line 237: iget-boolean v15, v9, Ld1/n;->e:Z
    .line 239: if-nez v15, :cond_251
    .line 241: invoke-virtual {v9, v11, v12}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 244: move-result-object v15
    .line 245: invoke-interface {v15}, Ljava/util/List;->isEmpty()Z
    .line 248: move-result v15
    .line 249: if-eqz v15, :cond_354
    .line 251: iget v15, v7, Ld1/f;->a:I
    .line 253: invoke-static {v15, v14}, Ld1/f;->a(II)Z
    .line 256: move-result v16
    .line 257: const-string v5, "AccessibilityNodeInfo.roleDescription"
    .line 259: if-eqz v16, :cond_284
    .line 261: invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 264: move-result-object v15
    .line 265: invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 268: move-result-object v15
    .line 269: const v14, 0x7f0a0044
    .line 272: invoke-virtual {v15, v14}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    .line 275: move-result-object v14
    .line 276: invoke-static {v4}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 279: move-result-object v15
    .line 280: invoke-virtual {v15, v5, v14}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 283: goto :goto_354
    .line 284: invoke-static {v15, v10}, Ld1/f;->a(II)Z
    .line 287: move-result v14
    .line 288: if-eqz v14, :cond_313
    .line 290: invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 293: move-result-object v14
    .line 294: invoke-virtual {v14}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 297: move-result-object v14
    .line 298: const v15, 0x7f0a0043
    .line 301: invoke-virtual {v14, v15}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    .line 304: move-result-object v14
    .line 305: invoke-static {v4}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 308: move-result-object v15
    .line 309: invoke-virtual {v15, v5, v14}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 312: goto :goto_354
    .line 313: invoke-static {v15}, Landroidx/compose/ui/platform/n1;->n(I)Ljava/lang/String;
    .line 316: move-result-object v5
    .line 317: const/4 v14, 5
    .line 318: invoke-static {v15, v14}, Ld1/f;->a(II)Z
    .line 321: move-result v14
    .line 322: if-eqz v14, :cond_351
    .line 324: iget-boolean v14, v9, Ld1/n;->e:Z
    .line 326: if-nez v14, :cond_347
    .line 328: invoke-virtual {v9, v11, v12}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 331: move-result-object v14
    .line 332: invoke-interface {v14}, Ljava/util/List;->isEmpty()Z
    .line 335: move-result v14
    .line 336: if-eqz v14, :cond_347
    .line 338: sget-object v14, Ld1/m;->k:Ld1/m;
    .line 340: invoke-static {v13, v14}, Ll0/j;->k(Landroidx/compose/ui/node/a;Ld1/m;)Landroidx/compose/ui/node/a;
    .line 343: move-result-object v14
    .line 344: if-nez v14, :cond_347
    .line 346: goto :goto_351
    .line 347: iget-boolean v14, v8, Ld1/i;->j:Z
    .line 349: if-eqz v14, :cond_354
    .line 351: invoke-virtual {v6, v5}, Lf2/k;->f(Ljava/lang/String;)V
    .line 354: sget-object v5, Ld1/h;->g:Ld1/t;
    .line 356: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 359: move-result v5
    .line 360: if-eqz v5, :cond_367
    .line 362: const-string v5, "android.widget.EditText"
    .line 364: invoke-virtual {v6, v5}, Lf2/k;->f(Ljava/lang/String;)V
    .line 367: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 370: move-result-object v5
    .line 371: sget-object v14, Ld1/q;->t:Ld1/t;
    .line 373: invoke-virtual {v5, v14}, Ld1/i;->b(Ld1/t;)Z
    .line 376: move-result v5
    .line 377: if-eqz v5, :cond_384
    .line 379: const-string v5, "android.widget.TextView"
    .line 381: invoke-virtual {v6, v5}, Lf2/k;->f(Ljava/lang/String;)V
    .line 384: invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 387: move-result-object v5
    .line 388: invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 391: move-result-object v5
    .line 392: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setPackageName(Ljava/lang/CharSequence;)V
    .line 395: invoke-virtual {v4, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setImportantForAccessibility(Z)V
    .line 398: invoke-virtual {v9, v11, v12}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 401: move-result-object v5
    .line 402: invoke-interface {v5}, Ljava/util/List;->size()I
    .line 405: move-result v14
    .line 406: move v15, v11
    .line 407: if-ge v15, v14, :cond_461
    .line 409: invoke-interface {v5, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 412: move-result-object v17
    .line 413: move-object/from16 v10, v17
    .line 415: check-cast v10, Ld1/n;
    .line 417: invoke-virtual {v2}, Landroidx/compose/ui/platform/j0;->i()Ljava/util/Map;
    .line 420: move-result-object v11
    .line 421: iget v12, v10, Ld1/n;->g:I
    .line 423: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 426: move-result-object v12
    .line 427: invoke-interface {v11, v12}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 430: move-result v11
    .line 431: if-eqz v11, :cond_455
    .line 433: invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui_release()Landroidx/compose/ui/platform/z0;
    .line 436: move-result-object v11
    .line 437: invoke-virtual {v11}, Landroidx/compose/ui/platform/z0;->getLayoutNodeToHolder()Ljava/util/HashMap;
    .line 440: move-result-object v11
    .line 441: iget-object v12, v10, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 443: invoke-virtual {v11, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 446: move-result-object v11
    .line 447: invoke-static {v11}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 450: iget v10, v10, Ld1/n;->g:I
    .line 452: invoke-virtual {v4, v3, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V
    .line 455: add-int/lit8 v15, v15, 1
    .line 457: const/4 v10, 2
    .line 458: const/4 v11, 0
    .line 459: const/4 v12, 1
    .line 460: goto :goto_407
    .line 461: iget v5, v2, Landroidx/compose/ui/platform/j0;->l:I
    .line 463: iget-object v10, v6, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 465: if-ne v5, v0, :cond_477
    .line 467: const/4 v5, 1
    .line 468: invoke-virtual {v10, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityFocused(Z)V
    .line 471: sget-object v5, Lf2/e;->d:Lf2/e;
    .line 473: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 476: goto :goto_486
    .line 477: const/4 v5, 0
    .line 478: invoke-virtual {v10, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityFocused(Z)V
    .line 481: sget-object v5, Lf2/e;->c:Lf2/e;
    .line 483: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 486: invoke-virtual {v2, v9}, Landroidx/compose/ui/platform/j0;->l(Ld1/n;)Landroid/text/SpannableString;
    .line 489: move-result-object v5
    .line 490: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V
    .line 493: sget-object v5, Ld1/q;->A:Ld1/t;
    .line 495: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 498: move-result v11
    .line 499: if-eqz v11, :cond_514
    .line 501: const/4 v11, 1
    .line 502: invoke-virtual {v4, v11}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentInvalid(Z)V
    .line 505: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 508: move-result-object v5
    .line 509: check-cast v5, Ljava/lang/CharSequence;
    .line 511: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setError(Ljava/lang/CharSequence;)V
    .line 514: invoke-virtual {v2, v9}, Landroidx/compose/ui/platform/j0;->k(Ld1/n;)Ljava/lang/String;
    .line 517: move-result-object v5
    .line 518: sget v11, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 520: const/16 v12, 30
    .line 522: if-lt v11, v12, :cond_528
    .line 524: invoke-static {v10, v5}, Lf2/g;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .line 527: goto :goto_537
    .line 528: invoke-static {v10}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 531: move-result-object v11
    .line 532: const-string v12, "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"
    .line 534: invoke-virtual {v11, v12, v5}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 537: invoke-static {v9}, Landroidx/compose/ui/platform/j0;->j(Ld1/n;)Z
    .line 540: move-result v5
    .line 541: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V
    .line 544: sget-object v5, Ld1/q;->y:Ld1/t;
    .line 546: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 549: move-result-object v5
    .line 550: check-cast v5, Le1/a;
    .line 552: if-eqz v5, :cond_571
    .line 554: sget-object v11, Le1/a;->i:Le1/a;
    .line 556: if-ne v5, v11, :cond_563
    .line 558: const/4 v11, 1
    .line 559: invoke-virtual {v10, v11}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V
    .line 562: goto :goto_571
    .line 563: sget-object v11, Le1/a;->j:Le1/a;
    .line 565: if-ne v5, v11, :cond_571
    .line 567: const/4 v5, 0
    .line 568: invoke-virtual {v10, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V
    .line 571: sget-object v5, Ld1/q;->x:Ld1/t;
    .line 573: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 576: move-result-object v5
    .line 577: check-cast v5, Ljava/lang/Boolean;
    .line 579: if-eqz v5, :cond_604
    .line 581: invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z
    .line 584: move-result v5
    .line 585: if-nez v7, :cond_588
    .line 587: goto :goto_601
    .line 588: iget v7, v7, Ld1/f;->a:I
    .line 590: const/4 v11, 4
    .line 591: invoke-static {v7, v11}, Ld1/f;->a(II)Z
    .line 594: move-result v7
    .line 595: if-eqz v7, :cond_601
    .line 597: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setSelected(Z)V
    .line 600: goto :goto_604
    .line 601: invoke-virtual {v10, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V
    .line 604: iget-boolean v5, v8, Ld1/i;->j:Z
    .line 606: if-eqz v5, :cond_620
    .line 608: const/4 v5, 0
    .line 609: const/4 v7, 1
    .line 610: invoke-virtual {v9, v5, v7}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 613: move-result-object v11
    .line 614: invoke-interface {v11}, Ljava/util/List;->isEmpty()Z
    .line 617: move-result v5
    .line 618: if-eqz v5, :cond_641
    .line 620: sget-object v5, Ld1/q;->a:Ld1/t;
    .line 622: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 625: move-result-object v5
    .line 626: check-cast v5, Ljava/util/List;
    .line 628: if-eqz v5, :cond_637
    .line 630: invoke-static {v5}, Lt2/p;->L1(Ljava/util/List;)Ljava/lang/Object;
    .line 633: move-result-object v5
    .line 634: check-cast v5, Ljava/lang/String;
    .line 636: goto :goto_638
    .line 637: const/4 v5, 0
    .line 638: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentDescription(Ljava/lang/CharSequence;)V
    .line 641: sget-object v5, Ld1/q;->s:Ld1/t;
    .line 643: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 646: move-result-object v5
    .line 647: check-cast v5, Ljava/lang/String;
    .line 649: if-eqz v5, :cond_685
    .line 651: move-object v7, v9
    .line 652: if-eqz v7, :cond_685
    .line 654: sget-object v11, Ld1/r;->a:Ld1/t;
    .line 656: iget-object v12, v7, Ld1/n;->d:Ld1/i;
    .line 658: invoke-virtual {v12, v11}, Ld1/i;->b(Ld1/t;)Z
    .line 661: move-result v14
    .line 662: if-eqz v14, :cond_680
    .line 664: invoke-virtual {v12, v11}, Ld1/i;->c(Ld1/t;)Ljava/lang/Object;
    .line 667: move-result-object v7
    .line 668: check-cast v7, Ljava/lang/Boolean;
    .line 670: invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z
    .line 673: move-result v7
    .line 674: if-eqz v7, :cond_685
    .line 676: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setViewIdResourceName(Ljava/lang/String;)V
    .line 679: goto :goto_685
    .line 680: invoke-virtual {v7}, Ld1/n;->i()Ld1/n;
    .line 683: move-result-object v7
    .line 684: goto :goto_652
    .line 685: sget-object v5, Ld1/q;->h:Ld1/t;
    .line 687: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 690: move-result-object v5
    .line 691: check-cast v5, Ls2/k;
    .line 693: const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY"
    .line 695: const/16 v11, 28
    .line 697: if-eqz v5, :cond_726
    .line 699: sget v5, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 701: if-lt v5, v11, :cond_708
    .line 703: const/4 v5, 1
    .line 704: invoke-static {v10, v5}, Landroidx/compose/ui/platform/r2;->m(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .line 707: goto :goto_726
    .line 708: invoke-static {v10}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 711: move-result-object v5
    .line 712: if-eqz v5, :cond_726
    .line 714: const/4 v12, 0
    .line 715: invoke-virtual {v5, v7, v12}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 718: move-result v14
    .line 719: and-int/lit8 v12, v14, -3
    .line 721: const/4 v14, 2
    .line 722: or-int/2addr v12, v14
    .line 723: invoke-virtual {v5, v7, v12}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 726: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 729: move-result-object v5
    .line 730: sget-object v12, Ld1/q;->z:Ld1/t;
    .line 732: invoke-virtual {v5, v12}, Ld1/i;->b(Ld1/t;)Z
    .line 735: move-result v5
    .line 736: invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setPassword(Z)V
    .line 739: sget-object v5, Ld1/h;->g:Ld1/t;
    .line 741: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 744: move-result v12
    .line 745: invoke-virtual {v4, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setEditable(Z)V
    .line 748: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 751: move-result v12
    .line 752: invoke-virtual {v4, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setEnabled(Z)V
    .line 755: sget-object v12, Ld1/q;->k:Ld1/t;
    .line 757: invoke-virtual {v8, v12}, Ld1/i;->b(Ld1/t;)Z
    .line 760: move-result v14
    .line 761: invoke-virtual {v4, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->setFocusable(Z)V
    .line 764: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocusable()Z
    .line 767: move-result v14
    .line 768: if-eqz v14, :cond_800
    .line 770: invoke-virtual {v8, v12}, Ld1/i;->c(Ld1/t;)Ljava/lang/Object;
    .line 773: move-result-object v14
    .line 774: check-cast v14, Ljava/lang/Boolean;
    .line 776: invoke-virtual {v14}, Ljava/lang/Boolean;->booleanValue()Z
    .line 779: move-result v14
    .line 780: invoke-virtual {v4, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->setFocused(Z)V
    .line 783: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z
    .line 786: move-result v14
    .line 787: if-eqz v14, :cond_794
    .line 789: const/4 v14, 2
    .line 790: invoke-virtual {v10, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V
    .line 793: goto :goto_801
    .line 794: const/4 v14, 2
    .line 795: const/4 v15, 1
    .line 796: invoke-virtual {v10, v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V
    .line 799: goto :goto_801
    .line 800: const/4 v14, 2
    .line 801: invoke-virtual {v9}, Ld1/n;->c()Lz0/a1;
    .line 804: move-result-object v15
    .line 805: if-eqz v15, :cond_813
    .line 807: invoke-virtual {v15}, Lz0/a1;->Q0()Z
    .line 810: move-result v15
    .line 811: if-nez v15, :cond_823
    .line 813: sget-object v15, Ld1/q;->m:Ld1/t;
    .line 815: invoke-virtual {v8, v15}, Ld1/i;->b(Ld1/t;)Z
    .line 818: move-result v15
    .line 819: if-nez v15, :cond_823
    .line 821: const/4 v15, 1
    .line 822: goto :goto_824
    .line 823: const/4 v15, 0
    .line 824: invoke-virtual {v4, v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->setVisibleToUser(Z)V
    .line 827: sget-object v15, Ld1/q;->j:Ld1/t;
    .line 829: invoke-static {v8, v15}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 832: move-result-object v15
    .line 833: check-cast v15, Ld1/d;
    .line 835: if-eqz v15, :cond_850
    .line 837: iget v15, v15, Ld1/d;->a:I
    .line 839: if-nez v15, :cond_843
    .line 841: const/4 v14, 1
    .line 842: goto :goto_847
    .line 843: const/4 v14, 1
    .line 844: if-ne v15, v14, :cond_841
    .line 846: const/4 v14, 2
    .line 847: invoke-virtual {v4, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLiveRegion(I)V
    .line 850: const/4 v14, 0
    .line 851: invoke-virtual {v10, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V
    .line 854: sget-object v14, Ld1/h;->b:Ld1/t;
    .line 856: invoke-static {v8, v14}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 859: move-result-object v14
    .line 860: check-cast v14, Ld1/a;
    .line 862: if-eqz v14, :cond_902
    .line 864: sget-object v15, Ld1/q;->x:Ld1/t;
    .line 866: invoke-static {v8, v15}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 869: move-result-object v15
    .line 870: sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 872: invoke-static {v15, v11}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 875: move-result v11
    .line 876: xor-int/lit8 v15, v11, 1
    .line 878: invoke-virtual {v10, v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V
    .line 881: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 884: move-result v15
    .line 885: if-eqz v15, :cond_902
    .line 887: if-nez v11, :cond_902
    .line 889: new-instance v11, Lf2/e;
    .line 891: const/16 v15, 16
    .line 893: iget-object v14, v14, Ld1/a;->a:Ljava/lang/String;
    .line 895: const/4 v1, 0
    .line 896: invoke-direct {v11, v1, v15, v14, v1}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 899: invoke-virtual {v6, v11}, Lf2/k;->a(Lf2/e;)V
    .line 902: const/4 v1, 0
    .line 903: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLongClickable(Z)V
    .line 906: sget-object v1, Ld1/h;->c:Ld1/t;
    .line 908: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 911: move-result-object v1
    .line 912: check-cast v1, Ld1/a;
    .line 914: const/16 v11, 32
    .line 916: if-eqz v1, :cond_939
    .line 918: const/4 v14, 1
    .line 919: invoke-virtual {v10, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLongClickable(Z)V
    .line 922: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 925: move-result v14
    .line 926: if-eqz v14, :cond_939
    .line 928: new-instance v14, Lf2/e;
    .line 930: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 932: const/4 v15, 0
    .line 933: invoke-direct {v14, v15, v11, v1, v15}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 936: invoke-virtual {v6, v14}, Lf2/k;->a(Lf2/e;)V
    .line 939: sget-object v1, Ld1/h;->j:Ld1/t;
    .line 941: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 944: move-result-object v1
    .line 945: check-cast v1, Ld1/a;
    .line 947: if-eqz v1, :cond_962
    .line 949: new-instance v14, Lf2/e;
    .line 951: const/16 v15, 16384
    .line 953: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 955: const/4 v11, 0
    .line 956: invoke-direct {v14, v11, v15, v1, v11}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 959: invoke-virtual {v6, v14}, Lf2/k;->a(Lf2/e;)V
    .line 962: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 965: move-result v1
    .line 966: if-eqz v1, :cond_1086
    .line 968: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 971: move-result-object v1
    .line 972: check-cast v1, Ld1/a;
    .line 974: if-eqz v1, :cond_989
    .line 976: new-instance v11, Lf2/e;
    .line 978: const/high16 v14, 0x20
    .line 980: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 982: const/4 v15, 0
    .line 983: invoke-direct {v11, v15, v14, v1, v15}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 986: invoke-virtual {v6, v11}, Lf2/k;->a(Lf2/e;)V
    .line 989: sget-object v1, Ld1/h;->i:Ld1/t;
    .line 991: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 994: move-result-object v1
    .line 995: check-cast v1, Ld1/a;
    .line 997: if-eqz v1, :cond_1013
    .line 999: new-instance v11, Lf2/e;
    .line 1001: const v14, 0x1020054
    .line 1004: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 1006: const/4 v15, 0
    .line 1007: invoke-direct {v11, v15, v14, v1, v15}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 1010: invoke-virtual {v6, v11}, Lf2/k;->a(Lf2/e;)V
    .line 1013: sget-object v1, Ld1/h;->k:Ld1/t;
    .line 1015: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1018: move-result-object v1
    .line 1019: check-cast v1, Ld1/a;
    .line 1021: if-eqz v1, :cond_1036
    .line 1023: new-instance v11, Lf2/e;
    .line 1025: const/high16 v14, 0x1
    .line 1027: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 1029: const/4 v15, 0
    .line 1030: invoke-direct {v11, v15, v14, v1, v15}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 1033: invoke-virtual {v6, v11}, Lf2/k;->a(Lf2/e;)V
    .line 1036: sget-object v1, Ld1/h;->l:Ld1/t;
    .line 1038: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1041: move-result-object v1
    .line 1042: check-cast v1, Ld1/a;
    .line 1044: if-eqz v1, :cond_1086
    .line 1046: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z
    .line 1049: move-result v11
    .line 1050: if-eqz v11, :cond_1086
    .line 1052: invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getClipboardManager()Landroidx/compose/ui/platform/l;
    .line 1055: move-result-object v11
    .line 1056: iget-object v11, v11, Landroidx/compose/ui/platform/l;->a:Landroid/content/ClipboardManager;
    .line 1058: invoke-virtual {v11}, Landroid/content/ClipboardManager;->getPrimaryClipDescription()Landroid/content/ClipDescription;
    .line 1061: move-result-object v11
    .line 1062: if-eqz v11, :cond_1086
    .line 1064: const-string v14, "text/*"
    .line 1066: invoke-virtual {v11, v14}, Landroid/content/ClipDescription;->hasMimeType(Ljava/lang/String;)Z
    .line 1069: move-result v11
    .line 1070: if-eqz v11, :cond_1086
    .line 1072: new-instance v11, Lf2/e;
    .line 1074: const v14, 0x8000
    .line 1077: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 1079: const/4 v15, 0
    .line 1080: invoke-direct {v11, v15, v14, v1, v15}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 1083: invoke-virtual {v6, v11}, Lf2/k;->a(Lf2/e;)V
    .line 1086: invoke-static {v9}, Landroidx/compose/ui/platform/j0;->m(Ld1/n;)Ljava/lang/String;
    .line 1089: move-result-object v1
    .line 1090: if-eqz v1, :cond_1230
    .line 1092: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 1095: move-result v1
    .line 1096: if-nez v1, :cond_1100
    .line 1098: goto/16 :goto_1230
    .line 1100: invoke-virtual {v2, v9}, Landroidx/compose/ui/platform/j0;->h(Ld1/n;)I
    .line 1103: move-result v1
    .line 1104: invoke-virtual {v2, v9}, Landroidx/compose/ui/platform/j0;->g(Ld1/n;)I
    .line 1107: move-result v11
    .line 1108: invoke-virtual {v4, v1, v11}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTextSelection(II)V
    .line 1111: sget-object v1, Ld1/h;->f:Ld1/t;
    .line 1113: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1116: move-result-object v1
    .line 1117: check-cast v1, Ld1/a;
    .line 1119: new-instance v11, Lf2/e;
    .line 1121: if-eqz v1, :cond_1126
    .line 1123: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 1125: goto :goto_1127
    .line 1126: const/4 v1, 0
    .line 1127: const/high16 v14, 0x2
    .line 1129: const/4 v15, 0
    .line 1130: invoke-direct {v11, v15, v14, v1, v15}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 1133: invoke-virtual {v6, v11}, Lf2/k;->a(Lf2/e;)V
    .line 1136: const/16 v1, 256
    .line 1138: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V
    .line 1141: const/16 v1, 512
    .line 1143: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V
    .line 1146: const/16 v1, 11
    .line 1148: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMovementGranularities(I)V
    .line 1151: sget-object v1, Ld1/q;->a:Ld1/t;
    .line 1153: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1156: move-result-object v1
    .line 1157: check-cast v1, Ljava/util/List;
    .line 1159: if-eqz v1, :cond_1167
    .line 1161: invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z
    .line 1164: move-result v1
    .line 1165: if-eqz v1, :cond_1230
    .line 1167: sget-object v1, Ld1/h;->a:Ld1/t;
    .line 1169: invoke-virtual {v8, v1}, Ld1/i;->b(Ld1/t;)Z
    .line 1172: move-result v1
    .line 1173: if-eqz v1, :cond_1230
    .line 1175: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 1178: move-result v1
    .line 1179: if-eqz v1, :cond_1194
    .line 1181: invoke-static {v8, v12}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1184: move-result-object v1
    .line 1185: sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 1187: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 1190: move-result v1
    .line 1191: if-nez v1, :cond_1194
    .line 1193: goto :goto_1230
    .line 1194: sget-object v1, Landroidx/compose/ui/platform/s;->y:Landroidx/compose/ui/platform/s;
    .line 1196: invoke-static {v13, v1}, Landroidx/compose/ui/platform/n1;->r(Landroidx/compose/ui/node/a;Landroidx/compose/ui/platform/s;)Landroidx/compose/ui/node/a;
    .line 1199: move-result-object v1
    .line 1200: if-eqz v1, :cond_1221
    .line 1202: invoke-virtual {v1}, Landroidx/compose/ui/node/a;->l()Ld1/i;
    .line 1205: move-result-object v1
    .line 1206: if-eqz v1, :cond_1230
    .line 1208: invoke-static {v1, v12}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1211: move-result-object v1
    .line 1212: sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 1214: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 1217: move-result v1
    .line 1218: if-nez v1, :cond_1221
    .line 1220: goto :goto_1230
    .line 1221: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getMovementGranularities()I
    .line 1224: move-result v1
    .line 1225: or-int/lit8 v1, v1, 20
    .line 1227: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMovementGranularities(I)V
    .line 1230: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 1232: const/16 v5, 26
    .line 1234: if-lt v1, v5, :cond_1290
    .line 1236: new-instance v1, Ljava/util/ArrayList;
    .line 1238: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 1241: const-string v5, "androidx.compose.ui.semantics.id"
    .line 1243: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1246: invoke-virtual {v6}, Lf2/k;->e()Ljava/lang/CharSequence;
    .line 1249: move-result-object v5
    .line 1250: if-eqz v5, :cond_1272
    .line 1252: invoke-interface {v5}, Ljava/lang/CharSequence;->length()I
    .line 1255: move-result v5
    .line 1256: if-nez v5, :cond_1259
    .line 1258: goto :goto_1272
    .line 1259: sget-object v5, Ld1/h;->a:Ld1/t;
    .line 1261: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 1264: move-result v5
    .line 1265: if-eqz v5, :cond_1272
    .line 1267: const-string v5, "android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_KEY"
    .line 1269: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1272: sget-object v5, Ld1/q;->s:Ld1/t;
    .line 1274: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 1277: move-result v5
    .line 1278: if-eqz v5, :cond_1285
    .line 1280: const-string v5, "androidx.compose.ui.semantics.testTag"
    .line 1282: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1285: sget-object v5, Landroidx/compose/ui/platform/j;->a:Landroidx/compose/ui/platform/j;
    .line 1287: invoke-virtual {v5, v4, v1}, Landroidx/compose/ui/platform/j;->a(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/util/List;)V
    .line 1290: sget-object v1, Ld1/q;->c:Ld1/t;
    .line 1292: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1295: move-result-object v1
    .line 1296: check-cast v1, Ld1/e;
    .line 1298: if-eqz v1, :cond_1432
    .line 1300: sget-object v5, Ld1/h;->e:Ld1/t;
    .line 1302: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 1305: move-result v11
    .line 1306: if-eqz v11, :cond_1314
    .line 1308: const-string v11, "android.widget.SeekBar"
    .line 1310: invoke-virtual {v6, v11}, Lf2/k;->f(Ljava/lang/String;)V
    .line 1313: goto :goto_1319
    .line 1314: const-string v11, "android.widget.ProgressBar"
    .line 1316: invoke-virtual {v6, v11}, Lf2/k;->f(Ljava/lang/String;)V
    .line 1319: sget-object v11, Ld1/e;->d:Ld1/e;
    .line 1321: iget v12, v1, Ld1/e;->a:F
    .line 1323: iget-object v14, v1, Ld1/e;->b:Lj3/a;
    .line 1325: if-eq v1, v11, :cond_1355
    .line 1327: iget v1, v14, Lj3/a;->a:F
    .line 1329: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1332: move-result-object v1
    .line 1333: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 1336: move-result v1
    .line 1337: iget v11, v14, Lj3/a;->b:F
    .line 1339: invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1342: move-result-object v11
    .line 1343: invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F
    .line 1346: move-result v11
    .line 1347: const/4 v15, 1
    .line 1348: invoke-static {v15, v1, v11, v12}, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;->obtain(IFFF)Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;
    .line 1351: move-result-object v1
    .line 1352: invoke-virtual {v4, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setRangeInfo(Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;)V
    .line 1355: invoke-virtual {v8, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 1358: move-result v1
    .line 1359: if-eqz v1, :cond_1432
    .line 1361: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 1364: move-result v1
    .line 1365: if-eqz v1, :cond_1432
    .line 1367: iget v1, v14, Lj3/a;->b:F
    .line 1369: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1372: move-result-object v1
    .line 1373: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 1376: move-result v1
    .line 1377: iget v5, v14, Lj3/a;->a:F
    .line 1379: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1382: move-result-object v11
    .line 1383: invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F
    .line 1386: move-result v11
    .line 1387: invoke-static {v1, v11}, Ld2/b;->D(FF)F
    .line 1390: move-result v1
    .line 1391: cmpg-float v1, v12, v1
    .line 1393: if-gez v1, :cond_1400
    .line 1395: sget-object v1, Lf2/e;->e:Lf2/e;
    .line 1397: invoke-virtual {v6, v1}, Lf2/k;->a(Lf2/e;)V
    .line 1400: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1403: move-result-object v1
    .line 1404: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 1407: move-result v1
    .line 1408: iget v5, v14, Lj3/a;->b:F
    .line 1410: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1413: move-result-object v5
    .line 1414: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 1417: move-result v5
    .line 1418: cmpl-float v11, v1, v5
    .line 1420: if-lez v11, :cond_1423
    .line 1422: move v1, v5
    .line 1423: cmpl-float v1, v12, v1
    .line 1425: if-lez v1, :cond_1432
    .line 1427: sget-object v1, Lf2/e;->f:Lf2/e;
    .line 1429: invoke-virtual {v6, v1}, Lf2/k;->a(Lf2/e;)V
    .line 1432: invoke-static {v6, v9}, Landroidx/compose/ui/platform/y;->a(Lf2/k;Ld1/n;)V
    .line 1435: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 1438: move-result-object v1
    .line 1439: sget-object v5, Ld1/q;->f:Ld1/t;
    .line 1441: invoke-static {v1, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1444: move-result-object v1
    .line 1445: invoke-static {v1}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 1448: new-instance v1, Ljava/util/ArrayList;
    .line 1450: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 1453: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 1456: move-result-object v5
    .line 1457: sget-object v11, Ld1/q;->e:Ld1/t;
    .line 1459: invoke-static {v5, v11}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1462: move-result-object v5
    .line 1463: if-eqz v5, :cond_1506
    .line 1465: const/4 v5, 0
    .line 1466: const/4 v11, 1
    .line 1467: invoke-virtual {v9, v5, v11}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 1470: move-result-object v12
    .line 1471: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 1474: move-result v5
    .line 1475: const/4 v11, 0
    .line 1476: if-ge v11, v5, :cond_1506
    .line 1478: invoke-interface {v12, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1481: move-result-object v14
    .line 1482: check-cast v14, Ld1/n;
    .line 1484: invoke-virtual {v14}, Ld1/n;->h()Ld1/i;
    .line 1487: move-result-object v15
    .line 1488: move/from16 v19, v5
    .line 1490: sget-object v5, Ld1/q;->x:Ld1/t;
    .line 1492: invoke-virtual {v15, v5}, Ld1/i;->b(Ld1/t;)Z
    .line 1495: move-result v5
    .line 1496: if-eqz v5, :cond_1501
    .line 1498: invoke-virtual {v1, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1501: add-int/lit8 v11, v11, 1
    .line 1503: move/from16 v5, v19
    .line 1505: goto :goto_1476
    .line 1506: invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z
    .line 1509: move-result v5
    .line 1510: const/4 v11, 1
    .line 1511: xor-int/2addr v5, v11
    .line 1512: if-eqz v5, :cond_1543
    .line 1514: invoke-static {v1}, Ld2/c;->o(Ljava/util/ArrayList;)Z
    .line 1517: move-result v5
    .line 1518: if-eqz v5, :cond_1522
    .line 1520: const/4 v11, 1
    .line 1521: goto :goto_1526
    .line 1522: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 1525: move-result v11
    .line 1526: if-eqz v5, :cond_1534
    .line 1528: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 1531: move-result v1
    .line 1532: const/4 v5, 0
    .line 1533: goto :goto_1536
    .line 1534: const/4 v1, 1
    .line 1535: goto :goto_1532
    .line 1536: invoke-static {v11, v1, v5, v5}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;->obtain(IIZI)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;
    .line 1539: move-result-object v1
    .line 1540: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCollectionInfo(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;)V
    .line 1543: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 1546: move-result-object v1
    .line 1547: sget-object v5, Ld1/q;->g:Ld1/t;
    .line 1549: invoke-static {v1, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1552: move-result-object v1
    .line 1553: invoke-static {v1}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 1556: invoke-virtual {v9}, Ld1/n;->i()Ld1/n;
    .line 1559: move-result-object v1
    .line 1560: if-nez v1, :cond_1564
    .line 1562: goto/16 :goto_1737
    .line 1564: invoke-virtual {v1}, Ld1/n;->h()Ld1/i;
    .line 1567: move-result-object v5
    .line 1568: sget-object v11, Ld1/q;->e:Ld1/t;
    .line 1570: invoke-static {v5, v11}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1573: move-result-object v5
    .line 1574: if-eqz v5, :cond_1737
    .line 1576: invoke-virtual {v1}, Ld1/n;->h()Ld1/i;
    .line 1579: move-result-object v5
    .line 1580: sget-object v11, Ld1/q;->f:Ld1/t;
    .line 1582: invoke-static {v5, v11}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1585: move-result-object v5
    .line 1586: invoke-static {v5}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 1589: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 1592: move-result-object v5
    .line 1593: sget-object v11, Ld1/q;->x:Ld1/t;
    .line 1595: invoke-virtual {v5, v11}, Ld1/i;->b(Ld1/t;)Z
    .line 1598: move-result v5
    .line 1599: if-nez v5, :cond_1603
    .line 1601: goto/16 :goto_1737
    .line 1603: new-instance v5, Ljava/util/ArrayList;
    .line 1605: invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V
    .line 1608: const/4 v11, 0
    .line 1609: const/4 v12, 1
    .line 1610: invoke-virtual {v1, v11, v12}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 1613: move-result-object v1
    .line 1614: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 1617: move-result v11
    .line 1618: const/4 v12, 0
    .line 1619: const/4 v14, 0
    .line 1620: if-ge v12, v11, :cond_1668
    .line 1622: invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1625: move-result-object v15
    .line 1626: check-cast v15, Ld1/n;
    .line 1628: move-object/from16 v19, v1
    .line 1630: invoke-virtual {v15}, Ld1/n;->h()Ld1/i;
    .line 1633: move-result-object v1
    .line 1634: move/from16 v20, v11
    .line 1636: sget-object v11, Ld1/q;->x:Ld1/t;
    .line 1638: invoke-virtual {v1, v11}, Ld1/i;->b(Ld1/t;)Z
    .line 1641: move-result v1
    .line 1642: if-eqz v1, :cond_1661
    .line 1644: invoke-virtual {v5, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1647: iget-object v1, v15, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 1649: invoke-virtual {v1}, Landroidx/compose/ui/node/a;->p()I
    .line 1652: move-result v1
    .line 1653: invoke-virtual {v13}, Landroidx/compose/ui/node/a;->p()I
    .line 1656: move-result v11
    .line 1657: if-ge v1, v11, :cond_1661
    .line 1659: add-int/lit8 v14, v14, 1
    .line 1661: add-int/lit8 v12, v12, 1
    .line 1663: move-object/from16 v1, v19
    .line 1665: move/from16 v11, v20
    .line 1667: goto :goto_1620
    .line 1668: invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z
    .line 1671: move-result v1
    .line 1672: const/4 v11, 1
    .line 1673: xor-int/2addr v1, v11
    .line 1674: if-eqz v1, :cond_1737
    .line 1676: invoke-static {v5}, Ld2/c;->o(Ljava/util/ArrayList;)Z
    .line 1679: move-result v1
    .line 1680: if-eqz v1, :cond_1685
    .line 1682: const/16 v19, 0
    .line 1684: goto :goto_1687
    .line 1685: move/from16 v19, v14
    .line 1687: if-eqz v1, :cond_1692
    .line 1689: move/from16 v21, v14
    .line 1691: goto :goto_1694
    .line 1692: const/16 v21, 0
    .line 1694: invoke-virtual {v9}, Ld1/n;->h()Ld1/i;
    .line 1697: move-result-object v1
    .line 1698: sget-object v5, Ld1/q;->x:Ld1/t;
    .line 1700: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 1703: const-string v11, "key"
    .line 1705: invoke-static {v5, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1708: iget-object v1, v1, Ld1/i;->i:Ljava/util/LinkedHashMap;
    .line 1710: invoke-virtual {v1, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 1713: move-result-object v1
    .line 1714: if-nez v1, :cond_1718
    .line 1716: sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 1718: check-cast v1, Ljava/lang/Boolean;
    .line 1720: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1723: move-result v24
    .line 1724: const/16 v20, 1
    .line 1726: const/16 v22, 1
    .line 1728: const/16 v23, 0
    .line 1730: invoke-static/range {v19 .. v24}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->obtain(IIIIZZ)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;
    .line 1733: move-result-object v1
    .line 1734: invoke-virtual {v10, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCollectionItemInfo(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V
    .line 1737: sget-object v1, Ld1/q;->o:Ld1/t;
    .line 1739: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1742: move-result-object v1
    .line 1743: check-cast v1, Ld1/g;
    .line 1745: sget-object v5, Ld1/h;->d:Ld1/t;
    .line 1747: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1750: move-result-object v5
    .line 1751: check-cast v5, Ld1/a;
    .line 1753: const/4 v11, 0
    .line 1754: if-eqz v1, :cond_1845
    .line 1756: if-eqz v5, :cond_1845
    .line 1758: invoke-static {v9}, Ld2/c;->b0(Ld1/n;)Z
    .line 1761: move-result v12
    .line 1762: if-nez v12, :cond_1769
    .line 1764: const-string v12, "android.widget.HorizontalScrollView"
    .line 1766: invoke-virtual {v6, v12}, Lf2/k;->f(Ljava/lang/String;)V
    .line 1769: iget-object v12, v1, Ld1/g;->b:Ld3/a;
    .line 1771: invoke-interface {v12}, Ld3/a;->s()Ljava/lang/Object;
    .line 1774: move-result-object v12
    .line 1775: check-cast v12, Ljava/lang/Number;
    .line 1777: invoke-virtual {v12}, Ljava/lang/Number;->floatValue()F
    .line 1780: move-result v12
    .line 1781: cmpl-float v12, v12, v11
    .line 1783: if-lez v12, :cond_1789
    .line 1785: const/4 v12, 1
    .line 1786: invoke-virtual {v10, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setScrollable(Z)V
    .line 1789: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 1792: move-result v12
    .line 1793: if-eqz v12, :cond_1845
    .line 1795: invoke-static {v1}, Landroidx/compose/ui/platform/j0;->t(Ld1/g;)Z
    .line 1798: move-result v12
    .line 1799: if-eqz v12, :cond_1820
    .line 1801: sget-object v12, Lf2/e;->e:Lf2/e;
    .line 1803: invoke-virtual {v6, v12}, Lf2/k;->a(Lf2/e;)V
    .line 1806: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->l(Ld1/n;)Z
    .line 1809: move-result v12
    .line 1810: if-nez v12, :cond_1815
    .line 1812: sget-object v12, Lf2/e;->j:Lf2/e;
    .line 1814: goto :goto_1817
    .line 1815: sget-object v12, Lf2/e;->h:Lf2/e;
    .line 1817: invoke-virtual {v6, v12}, Lf2/k;->a(Lf2/e;)V
    .line 1820: invoke-static {v1}, Landroidx/compose/ui/platform/j0;->s(Ld1/g;)Z
    .line 1823: move-result v1
    .line 1824: if-eqz v1, :cond_1845
    .line 1826: sget-object v1, Lf2/e;->f:Lf2/e;
    .line 1828: invoke-virtual {v6, v1}, Lf2/k;->a(Lf2/e;)V
    .line 1831: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->l(Ld1/n;)Z
    .line 1834: move-result v1
    .line 1835: if-nez v1, :cond_1840
    .line 1837: sget-object v1, Lf2/e;->h:Lf2/e;
    .line 1839: goto :goto_1842
    .line 1840: sget-object v1, Lf2/e;->j:Lf2/e;
    .line 1842: invoke-virtual {v6, v1}, Lf2/k;->a(Lf2/e;)V
    .line 1845: sget-object v1, Ld1/q;->p:Ld1/t;
    .line 1847: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1850: move-result-object v1
    .line 1851: check-cast v1, Ld1/g;
    .line 1853: if-eqz v1, :cond_1926
    .line 1855: if-eqz v5, :cond_1926
    .line 1857: invoke-static {v9}, Ld2/c;->b0(Ld1/n;)Z
    .line 1860: move-result v5
    .line 1861: if-nez v5, :cond_1868
    .line 1863: const-string v5, "android.widget.ScrollView"
    .line 1865: invoke-virtual {v6, v5}, Lf2/k;->f(Ljava/lang/String;)V
    .line 1868: iget-object v5, v1, Ld1/g;->b:Ld3/a;
    .line 1870: invoke-interface {v5}, Ld3/a;->s()Ljava/lang/Object;
    .line 1873: move-result-object v5
    .line 1874: check-cast v5, Ljava/lang/Number;
    .line 1876: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 1879: move-result v5
    .line 1880: cmpl-float v5, v5, v11
    .line 1882: if-lez v5, :cond_1888
    .line 1884: const/4 v5, 1
    .line 1885: invoke-virtual {v10, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setScrollable(Z)V
    .line 1888: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 1891: move-result v5
    .line 1892: if-eqz v5, :cond_1926
    .line 1894: invoke-static {v1}, Landroidx/compose/ui/platform/j0;->t(Ld1/g;)Z
    .line 1897: move-result v5
    .line 1898: if-eqz v5, :cond_1910
    .line 1900: sget-object v5, Lf2/e;->e:Lf2/e;
    .line 1902: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 1905: sget-object v5, Lf2/e;->i:Lf2/e;
    .line 1907: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 1910: invoke-static {v1}, Landroidx/compose/ui/platform/j0;->s(Ld1/g;)Z
    .line 1913: move-result v1
    .line 1914: if-eqz v1, :cond_1926
    .line 1916: sget-object v1, Lf2/e;->f:Lf2/e;
    .line 1918: invoke-virtual {v6, v1}, Lf2/k;->a(Lf2/e;)V
    .line 1921: sget-object v1, Lf2/e;->g:Lf2/e;
    .line 1923: invoke-virtual {v6, v1}, Lf2/k;->a(Lf2/e;)V
    .line 1926: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 1928: const/16 v5, 29
    .line 1930: if-lt v1, v5, :cond_1935
    .line 1932: invoke-static {v6, v9}, Landroidx/compose/ui/platform/a0;->a(Lf2/k;Ld1/n;)V
    .line 1935: sget-object v5, Ld1/q;->d:Ld1/t;
    .line 1937: invoke-static {v8, v5}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1940: move-result-object v5
    .line 1941: check-cast v5, Ljava/lang/CharSequence;
    .line 1943: const/16 v11, 28
    .line 1945: if-lt v1, v11, :cond_1951
    .line 1947: invoke-static {v10, v5}, Landroidx/compose/ui/platform/r2;->h(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .line 1950: goto :goto_1960
    .line 1951: invoke-static {v10}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 1954: move-result-object v1
    .line 1955: const-string v11, "androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY"
    .line 1957: invoke-virtual {v1, v11, v5}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 1960: invoke-static {v9}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 1963: move-result v1
    .line 1964: if-eqz v1, :cond_2195
    .line 1966: sget-object v1, Ld1/h;->m:Ld1/t;
    .line 1968: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1971: move-result-object v1
    .line 1972: check-cast v1, Ld1/a;
    .line 1974: if-eqz v1, :cond_1989
    .line 1976: new-instance v5, Lf2/e;
    .line 1978: const/high16 v11, 0x4
    .line 1980: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 1982: const/4 v12, 0
    .line 1983: invoke-direct {v5, v12, v11, v1, v12}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 1986: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 1989: sget-object v1, Ld1/h;->n:Ld1/t;
    .line 1991: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1994: move-result-object v1
    .line 1995: check-cast v1, Ld1/a;
    .line 1997: if-eqz v1, :cond_2012
    .line 1999: new-instance v5, Lf2/e;
    .line 2001: const/high16 v11, 0x8
    .line 2003: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 2005: const/4 v12, 0
    .line 2006: invoke-direct {v5, v12, v11, v1, v12}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 2009: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 2012: sget-object v1, Ld1/h;->o:Ld1/t;
    .line 2014: invoke-static {v8, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 2017: move-result-object v1
    .line 2018: check-cast v1, Ld1/a;
    .line 2020: if-eqz v1, :cond_2035
    .line 2022: new-instance v5, Lf2/e;
    .line 2024: const/high16 v11, 0x10
    .line 2026: iget-object v1, v1, Ld1/a;->a:Ljava/lang/String;
    .line 2028: const/4 v12, 0
    .line 2029: invoke-direct {v5, v12, v11, v1, v12}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 2032: invoke-virtual {v6, v5}, Lf2/k;->a(Lf2/e;)V
    .line 2035: sget-object v1, Ld1/h;->q:Ld1/t;
    .line 2037: invoke-virtual {v8, v1}, Ld1/i;->b(Ld1/t;)Z
    .line 2040: move-result v5
    .line 2041: if-eqz v5, :cond_2195
    .line 2043: invoke-virtual {v8, v1}, Ld1/i;->c(Ld1/t;)Ljava/lang/Object;
    .line 2046: move-result-object v1
    .line 2047: check-cast v1, Ljava/util/List;
    .line 2049: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 2052: move-result v5
    .line 2053: const/16 v6, 32
    .line 2055: if-ge v5, v6, :cond_2187
    .line 2057: new-instance v5, Lf/l;
    .line 2059: invoke-direct {v5}, Lf/l;-><init>()V
    .line 2062: new-instance v6, Ljava/util/LinkedHashMap;
    .line 2064: invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V
    .line 2067: iget-object v8, v2, Landroidx/compose/ui/platform/j0;->n:Lf/l;
    .line 2069: iget-object v11, v8, Lf/l;->i:[I
    .line 2071: iget v12, v8, Lf/l;->k:I
    .line 2073: invoke-static {v11, v12, v0}, Lf/d;->a([III)I
    .line 2076: move-result v11
    .line 2077: if-ltz v11, :cond_2162
    .line 2079: invoke-virtual {v8, v0}, Lf/l;->a(I)Ljava/lang/Object;
    .line 2082: move-result-object v11
    .line 2083: check-cast v11, Ljava/util/Map;
    .line 2085: sget-object v12, Landroidx/compose/ui/platform/j0;->K:[I
    .line 2087: new-instance v13, Ljava/util/ArrayList;
    .line 2089: const/16 v14, 32
    .line 2091: invoke-direct {v13, v14}, Ljava/util/ArrayList;-><init>(I)V
    .line 2094: const/4 v15, 0
    .line 2095: if-ge v15, v14, :cond_2111
    .line 2097: aget v18, v12, v15
    .line 2099: invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 2102: move-result-object v14
    .line 2103: invoke-virtual {v13, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 2106: add-int/lit8 v15, v15, 1
    .line 2108: const/16 v14, 32
    .line 2110: goto :goto_2095
    .line 2111: new-instance v12, Ljava/util/ArrayList;
    .line 2113: invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V
    .line 2116: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 2119: move-result v14
    .line 2120: if-gtz v14, :cond_2149
    .line 2122: invoke-virtual {v12}, Ljava/util/ArrayList;->size()I
    .line 2125: move-result v1
    .line 2126: if-gtz v1, :cond_2130
    .line 2128: const/4 v12, 0
    .line 2129: goto :goto_2169
    .line 2130: const/4 v14, 0
    .line 2131: invoke-virtual {v12, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 2134: move-result-object v0
    .line 2135: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 2138: invoke-virtual {v13, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 2141: move-result-object v0
    .line 2142: check-cast v0, Ljava/lang/Number;
    .line 2144: invoke-virtual {v0}, Ljava/lang/Number;->intValue()I
    .line 2147: const/4 v12, 0
    .line 2148: throw v12
    .line 2149: const/4 v12, 0
    .line 2150: const/4 v14, 0
    .line 2151: invoke-interface {v1, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 2154: move-result-object v0
    .line 2155: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 2158: invoke-static {v11}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 2161: throw v12
    .line 2162: const/4 v12, 0
    .line 2163: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 2166: move-result v11
    .line 2167: if-gtz v11, :cond_2178
    .line 2169: iget-object v1, v2, Landroidx/compose/ui/platform/j0;->m:Lf/l;
    .line 2171: invoke-virtual {v1, v0, v5}, Lf/l;->b(ILjava/lang/Cloneable;)V
    .line 2174: invoke-virtual {v8, v0, v6}, Lf/l;->b(ILjava/lang/Cloneable;)V
    .line 2177: goto :goto_2195
    .line 2178: const/4 v5, 0
    .line 2179: invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 2182: move-result-object v0
    .line 2183: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 2186: throw v12
    .line 2187: new-instance v0, Ljava/lang/IllegalStateException;
    .line 2189: const-string v1, "Can't have more than 32 custom actions for one widget"
    .line 2191: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 2194: throw v0
    .line 2195: invoke-virtual {v2, v9}, Landroidx/compose/ui/platform/j0;->o(Ld1/n;)Z
    .line 2198: move-result v1
    .line 2199: sget v5, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2201: const/16 v6, 28
    .line 2203: if-lt v5, v6, :cond_2209
    .line 2205: invoke-static {v10, v1}, Landroidx/compose/ui/platform/r2;->i(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .line 2208: goto :goto_2226
    .line 2209: invoke-static {v10}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 2212: move-result-object v5
    .line 2213: if-eqz v5, :cond_2226
    .line 2215: const/4 v6, 0
    .line 2216: invoke-virtual {v5, v7, v6}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 2219: move-result v6
    .line 2220: and-int/lit8 v6, v6, -2
    .line 2222: or-int/2addr v1, v6
    .line 2223: invoke-virtual {v5, v7, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 2226: iget-object v1, v2, Landroidx/compose/ui/platform/j0;->z:Ljava/util/HashMap;
    .line 2228: invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 2231: move-result-object v5
    .line 2232: invoke-virtual {v1, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 2235: move-result-object v1
    .line 2236: check-cast v1, Ljava/lang/Integer;
    .line 2238: if-eqz v1, :cond_2267
    .line 2240: invoke-virtual {v1}, Ljava/lang/Number;->intValue()I
    .line 2243: invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui_release()Landroidx/compose/ui/platform/z0;
    .line 2246: move-result-object v5
    .line 2247: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    .line 2250: move-result v6
    .line 2251: invoke-static {v5, v6}, Landroidx/compose/ui/platform/n1;->v(Landroidx/compose/ui/platform/z0;I)V
    .line 2254: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    .line 2257: move-result v1
    .line 2258: invoke-virtual {v4, v3, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTraversalBefore(Landroid/view/View;I)V
    .line 2261: iget-object v1, v2, Landroidx/compose/ui/platform/j0;->B:Ljava/lang/String;
    .line 2263: const/4 v5, 0
    .line 2264: invoke-virtual {v2, v0, v4, v1, v5}, Landroidx/compose/ui/platform/j0;->b(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Landroid/os/Bundle;)V
    .line 2267: iget-object v1, v2, Landroidx/compose/ui/platform/j0;->A:Ljava/util/HashMap;
    .line 2269: invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 2272: move-result-object v0
    .line 2273: invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 2276: move-result-object v0
    .line 2277: check-cast v0, Ljava/lang/Integer;
    .line 2279: if-eqz v0, :cond_2295
    .line 2281: invoke-virtual {v0}, Ljava/lang/Number;->intValue()I
    .line 2284: invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui_release()Landroidx/compose/ui/platform/z0;
    .line 2287: move-result-object v1
    .line 2288: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    .line 2291: move-result v0
    .line 2292: invoke-static {v1, v0}, Landroidx/compose/ui/platform/n1;->v(Landroidx/compose/ui/platform/z0;I)V
    .line 2295: move-object v5, v10
    .line 2296: return-object v5
    .line 2297: new-instance v1, Ljava/lang/IllegalStateException;
    .line 2299: const-string v2, "semanticsNode "
    .line 2301: const-string v3, " has null parent"
    .line 2303: invoke-static {v2, v0, v3}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 2306: move-result-object v0
    .line 2307: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 2310: throw v1
.end method

# virtual methods
.method public final performAction(IILandroid/os/Bundle;)Z
    .registers 22

    .line 0: move/from16 v0, v19
    .line 2: move/from16 v1, v20
    .line 4: move-object/from16 v2, v21
    .line 6: move-object/from16 v3, v18
    .line 8: iget-object v4, v3, Landroidx/compose/ui/platform/b0;->a:Landroidx/compose/ui/platform/j0;
    .line 10: invoke-virtual {v4}, Landroidx/compose/ui/platform/j0;->i()Ljava/util/Map;
    .line 13: move-result-object v5
    .line 14: invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 17: move-result-object v6
    .line 18: invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 21: move-result-object v5
    .line 22: check-cast v5, Landroidx/compose/ui/platform/h2;
    .line 24: const/4 v6, 0
    .line 25: if-eqz v5, :cond_1793
    .line 27: iget-object v5, v5, Landroidx/compose/ui/platform/h2;->a:Ld1/n;
    .line 29: if-nez v5, :cond_33
    .line 31: goto/16 :goto_1793
    .line 33: const/high16 v7, 0x1
    .line 35: const/4 v15, 1
    .line 36: const/16 v8, 12
    .line 38: const/4 v9, 0
    .line 39: const/16 v10, 64
    .line 41: const/high16 v11, 0x8000
    .line 43: iget-object v12, v4, Landroidx/compose/ui/platform/j0;->d:Landroidx/compose/ui/platform/AndroidComposeView;
    .line 45: if-eq v1, v10, :cond_1756
    .line 47: const/16 v10, 128
    .line 49: if-eq v1, v10, :cond_1742
    .line 51: const/4 v7, 2
    .line 52: const/16 v10, 512
    .line 54: const/16 v11, 256
    .line 56: iget v14, v5, Ld1/n;->g:I
    .line 58: iget-object v13, v5, Ld1/n;->d:Ld1/i;
    .line 60: if-eq v1, v11, :cond_1312
    .line 62: if-eq v1, v10, :cond_1312
    .line 64: const/16 v10, 16384
    .line 66: if-eq v1, v10, :cond_1284
    .line 68: const/high16 v10, 0x2
    .line 70: if-eq v1, v10, :cond_1244
    .line 72: invoke-static {v5}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 75: move-result v10
    .line 76: if-nez v10, :cond_80
    .line 78: goto/16 :goto_1793
    .line 80: if-eq v1, v15, :cond_1216
    .line 82: if-eq v1, v7, :cond_1190
    .line 84: const/4 v7, 0
    .line 85: sparse-switch v1, :data_1794
    .line 88: packed-switch v1, :data_1848
    .line 91: packed-switch v1, :data_1860
    .line 94: iget-object v2, v4, Landroidx/compose/ui/platform/j0;->m:Lf/l;
    .line 96: invoke-virtual {v2, v0}, Lf/l;->a(I)Ljava/lang/Object;
    .line 99: move-result-object v0
    .line 100: check-cast v0, Lf/l;
    .line 102: if-eqz v0, :cond_1793
    .line 104: invoke-virtual {v0, v1}, Lf/l;->a(I)Ljava/lang/Object;
    .line 107: move-result-object v0
    .line 108: check-cast v0, Ljava/lang/CharSequence;
    .line 110: if-nez v0, :cond_114
    .line 112: goto/16 :goto_1793
    .line 114: sget-object v0, Ld1/h;->q:Ld1/t;
    .line 116: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 119: move-result-object v0
    .line 120: check-cast v0, Ljava/util/List;
    .line 122: if-nez v0, :cond_126
    .line 124: goto/16 :goto_1793
    .line 126: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 129: move-result v1
    .line 130: if-gtz v1, :cond_134
    .line 132: goto/16 :goto_1793
    .line 134: invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 137: move-result-object v0
    .line 138: invoke-static {v0}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 141: throw v9
    .line 142: sget-object v0, Ld1/h;->u:Ld1/t;
    .line 144: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 147: move-result-object v0
    .line 148: check-cast v0, Ld1/a;
    .line 150: if-eqz v0, :cond_1793
    .line 152: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 154: check-cast v0, Ld3/a;
    .line 156: if-eqz v0, :cond_1793
    .line 158: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 161: move-result-object v0
    .line 162: check-cast v0, Ljava/lang/Boolean;
    .line 164: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 167: move-result v6
    .line 168: goto/16 :goto_1793
    .line 170: sget-object v0, Ld1/h;->s:Ld1/t;
    .line 172: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 175: move-result-object v0
    .line 176: check-cast v0, Ld1/a;
    .line 178: if-eqz v0, :cond_1793
    .line 180: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 182: check-cast v0, Ld3/a;
    .line 184: if-eqz v0, :cond_1793
    .line 186: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 189: move-result-object v0
    .line 190: check-cast v0, Ljava/lang/Boolean;
    .line 192: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 195: move-result v6
    .line 196: goto/16 :goto_1793
    .line 198: sget-object v0, Ld1/h;->t:Ld1/t;
    .line 200: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 203: move-result-object v0
    .line 204: check-cast v0, Ld1/a;
    .line 206: if-eqz v0, :cond_1793
    .line 208: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 210: check-cast v0, Ld3/a;
    .line 212: if-eqz v0, :cond_1793
    .line 214: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 217: move-result-object v0
    .line 218: check-cast v0, Ljava/lang/Boolean;
    .line 220: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 223: move-result v6
    .line 224: goto/16 :goto_1793
    .line 226: sget-object v0, Ld1/h;->r:Ld1/t;
    .line 228: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 231: move-result-object v0
    .line 232: check-cast v0, Ld1/a;
    .line 234: if-eqz v0, :cond_1793
    .line 236: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 238: check-cast v0, Ld3/a;
    .line 240: if-eqz v0, :cond_1793
    .line 242: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 245: move-result-object v0
    .line 246: check-cast v0, Ljava/lang/Boolean;
    .line 248: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 251: move-result v6
    .line 252: goto/16 :goto_1793
    .line 254: sget-object v0, Ld1/h;->i:Ld1/t;
    .line 256: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 259: move-result-object v0
    .line 260: check-cast v0, Ld1/a;
    .line 262: if-eqz v0, :cond_1793
    .line 264: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 266: check-cast v0, Ld3/a;
    .line 268: if-eqz v0, :cond_1793
    .line 270: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 273: move-result-object v0
    .line 274: check-cast v0, Ljava/lang/Boolean;
    .line 276: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 279: move-result v6
    .line 280: goto/16 :goto_1793
    .line 282: if-eqz v2, :cond_1793
    .line 284: const-string v0, "android.view.accessibility.action.ARGUMENT_PROGRESS_VALUE"
    .line 286: invoke-virtual {v2, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z
    .line 289: move-result v1
    .line 290: if-nez v1, :cond_294
    .line 292: goto/16 :goto_1793
    .line 294: sget-object v1, Ld1/h;->e:Ld1/t;
    .line 296: invoke-static {v13, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 299: move-result-object v1
    .line 300: check-cast v1, Ld1/a;
    .line 302: if-eqz v1, :cond_1793
    .line 304: iget-object v1, v1, Ld1/a;->b:Ls2/a;
    .line 306: check-cast v1, Ld3/c;
    .line 308: if-eqz v1, :cond_1793
    .line 310: invoke-virtual {v2, v0}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F
    .line 313: move-result v0
    .line 314: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 317: move-result-object v0
    .line 318: invoke-interface {v1, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 321: move-result-object v0
    .line 322: check-cast v0, Ljava/lang/Boolean;
    .line 324: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 327: move-result v6
    .line 328: goto/16 :goto_1793
    .line 330: invoke-virtual {v5}, Ld1/n;->i()Ld1/n;
    .line 333: move-result-object v0
    .line 334: if-eqz v0, :cond_351
    .line 336: invoke-virtual {v0}, Ld1/n;->h()Ld1/i;
    .line 339: move-result-object v1
    .line 340: if-eqz v1, :cond_351
    .line 342: sget-object v2, Ld1/h;->d:Ld1/t;
    .line 344: invoke-static {v1, v2}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 347: move-result-object v1
    .line 348: check-cast v1, Ld1/a;
    .line 350: goto :goto_352
    .line 351: move-object v1, v9
    .line 352: if-eqz v0, :cond_378
    .line 354: if-eqz v1, :cond_357
    .line 356: goto :goto_378
    .line 357: invoke-virtual {v0}, Ld1/n;->i()Ld1/n;
    .line 360: move-result-object v0
    .line 361: if-eqz v0, :cond_351
    .line 363: invoke-virtual {v0}, Ld1/n;->h()Ld1/i;
    .line 366: move-result-object v1
    .line 367: if-eqz v1, :cond_351
    .line 369: sget-object v2, Ld1/h;->d:Ld1/t;
    .line 371: invoke-static {v1, v2}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 374: move-result-object v1
    .line 375: check-cast v1, Ld1/a;
    .line 377: goto :goto_352
    .line 378: if-nez v0, :cond_382
    .line 380: goto/16 :goto_1793
    .line 382: iget-object v2, v0, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 384: iget-object v4, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 386: iget-object v4, v4, Lz0/v0;->b:Lz0/w;
    .line 388: invoke-static {v4}, Landroidx/compose/ui/layout/a;->b(Lz0/w;)Lj0/d;
    .line 391: move-result-object v4
    .line 392: iget-object v2, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 394: iget-object v2, v2, Lz0/v0;->b:Lz0/w;
    .line 396: invoke-virtual {v2}, Lz0/a1;->T()Lx0/q;
    .line 399: move-result-object v2
    .line 400: if-eqz v2, :cond_407
    .line 402: invoke-static {v2}, Landroidx/compose/ui/layout/a;->l(Lx0/q;)J
    .line 405: move-result-wide v10
    .line 406: goto :goto_409
    .line 407: sget-wide v10, Lj0/c;->b:J
    .line 409: invoke-virtual {v4, v10, v11}, Lj0/d;->f(J)Lj0/d;
    .line 412: move-result-object v2
    .line 413: invoke-virtual {v5}, Ld1/n;->c()Lz0/a1;
    .line 416: move-result-object v4
    .line 417: if-eqz v4, :cond_433
    .line 419: invoke-virtual {v4}, Lz0/a1;->H()Z
    .line 422: move-result v8
    .line 423: if-eqz v8, :cond_426
    .line 425: move-object v9, v4
    .line 426: if-eqz v9, :cond_433
    .line 428: invoke-static {v9}, Landroidx/compose/ui/layout/a;->l(Lx0/q;)J
    .line 431: move-result-wide v8
    .line 432: goto :goto_435
    .line 433: sget-wide v8, Lj0/c;->b:J
    .line 435: invoke-virtual {v5}, Ld1/n;->c()Lz0/a1;
    .line 438: move-result-object v4
    .line 439: if-eqz v4, :cond_444
    .line 441: iget-wide v10, v4, Lx0/l0;->k:J
    .line 443: goto :goto_446
    .line 444: const-wide/16 v10, 0
    .line 446: invoke-static {v10, v11}, Ld2/b;->j1(J)J
    .line 449: move-result-wide v10
    .line 450: invoke-static {v8, v9, v10, v11}, Lo/g1;->b(JJ)Lj0/d;
    .line 453: move-result-object v4
    .line 454: sget-object v8, Ld1/q;->o:Ld1/t;
    .line 456: iget-object v0, v0, Ld1/n;->d:Ld1/i;
    .line 458: invoke-static {v0, v8}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 461: move-result-object v8
    .line 462: check-cast v8, Ld1/g;
    .line 464: sget-object v9, Ld1/q;->p:Ld1/t;
    .line 466: invoke-static {v0, v9}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 469: move-result-object v0
    .line 470: check-cast v0, Ld1/g;
    .line 472: iget v9, v4, Lj0/d;->a:F
    .line 474: iget v10, v2, Lj0/d;->a:F
    .line 476: sub-float/2addr v9, v10
    .line 477: iget v10, v4, Lj0/d;->c:F
    .line 479: iget v11, v2, Lj0/d;->c:F
    .line 481: sub-float/2addr v10, v11
    .line 482: invoke-static {v9}, Ljava/lang/Math;->signum(F)F
    .line 485: move-result v11
    .line 486: invoke-static {v10}, Ljava/lang/Math;->signum(F)F
    .line 489: move-result v12
    .line 490: cmpg-float v11, v11, v12
    .line 492: if-nez v11, :cond_509
    .line 494: invoke-static {v9}, Ljava/lang/Math;->abs(F)F
    .line 497: move-result v11
    .line 498: invoke-static {v10}, Ljava/lang/Math;->abs(F)F
    .line 501: move-result v12
    .line 502: cmpg-float v11, v11, v12
    .line 504: if-gez v11, :cond_507
    .line 506: goto :goto_510
    .line 507: move v9, v10
    .line 508: goto :goto_510
    .line 509: move v9, v7
    .line 510: if-eqz v8, :cond_517
    .line 512: iget-boolean v8, v8, Ld1/g;->c:Z
    .line 514: if-ne v8, v15, :cond_517
    .line 516: neg-float v9, v9
    .line 517: invoke-static {v5}, Landroidx/compose/ui/platform/n1;->l(Ld1/n;)Z
    .line 520: move-result v5
    .line 521: if-eqz v5, :cond_524
    .line 523: neg-float v9, v9
    .line 524: iget v5, v4, Lj0/d;->b:F
    .line 526: iget v8, v2, Lj0/d;->b:F
    .line 528: sub-float/2addr v5, v8
    .line 529: iget v4, v4, Lj0/d;->d:F
    .line 531: iget v2, v2, Lj0/d;->d:F
    .line 533: sub-float/2addr v4, v2
    .line 534: invoke-static {v5}, Ljava/lang/Math;->signum(F)F
    .line 537: move-result v2
    .line 538: invoke-static {v4}, Ljava/lang/Math;->signum(F)F
    .line 541: move-result v8
    .line 542: cmpg-float v2, v2, v8
    .line 544: if-nez v2, :cond_561
    .line 546: invoke-static {v5}, Ljava/lang/Math;->abs(F)F
    .line 549: move-result v2
    .line 550: invoke-static {v4}, Ljava/lang/Math;->abs(F)F
    .line 553: move-result v7
    .line 554: cmpg-float v2, v2, v7
    .line 556: if-gez v2, :cond_560
    .line 558: move v7, v5
    .line 559: goto :goto_561
    .line 560: move v7, v4
    .line 561: if-eqz v0, :cond_568
    .line 563: iget-boolean v0, v0, Ld1/g;->c:Z
    .line 565: if-ne v0, v15, :cond_568
    .line 567: neg-float v7, v7
    .line 568: if-eqz v1, :cond_1793
    .line 570: iget-object v0, v1, Ld1/a;->b:Ls2/a;
    .line 572: check-cast v0, Ld3/e;
    .line 574: if-eqz v0, :cond_1793
    .line 576: invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 579: move-result-object v1
    .line 580: invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 583: move-result-object v2
    .line 584: invoke-interface {v0, v1, v2}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 587: move-result-object v0
    .line 588: check-cast v0, Ljava/lang/Boolean;
    .line 590: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 593: move-result v6
    .line 594: goto/16 :goto_1793
    .line 596: if-eqz v2, :cond_605
    .line 598: const-string v0, "ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE"
    .line 600: invoke-virtual {v2, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 603: move-result-object v0
    .line 604: goto :goto_606
    .line 605: move-object v0, v9
    .line 606: sget-object v1, Ld1/h;->g:Ld1/t;
    .line 608: invoke-static {v13, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 611: move-result-object v1
    .line 612: check-cast v1, Ld1/a;
    .line 614: if-eqz v1, :cond_1793
    .line 616: iget-object v1, v1, Ld1/a;->b:Ls2/a;
    .line 618: check-cast v1, Ld3/c;
    .line 620: if-eqz v1, :cond_1793
    .line 622: new-instance v2, Lf1/e;
    .line 624: if-nez v0, :cond_628
    .line 626: const-string v0, ""
    .line 628: const/4 v4, 6
    .line 629: invoke-direct {v2, v0, v9, v4}, Lf1/e;-><init>(Ljava/lang/String;Ljava/util/ArrayList;I)V
    .line 632: invoke-interface {v1, v2}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 635: move-result-object v0
    .line 636: check-cast v0, Ljava/lang/Boolean;
    .line 638: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 641: move-result v6
    .line 642: goto/16 :goto_1793
    .line 644: sget-object v0, Ld1/h;->o:Ld1/t;
    .line 646: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 649: move-result-object v0
    .line 650: check-cast v0, Ld1/a;
    .line 652: if-eqz v0, :cond_1793
    .line 654: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 656: check-cast v0, Ld3/a;
    .line 658: if-eqz v0, :cond_1793
    .line 660: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 663: move-result-object v0
    .line 664: check-cast v0, Ljava/lang/Boolean;
    .line 666: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 669: move-result v6
    .line 670: goto/16 :goto_1793
    .line 672: sget-object v0, Ld1/h;->n:Ld1/t;
    .line 674: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 677: move-result-object v0
    .line 678: check-cast v0, Ld1/a;
    .line 680: if-eqz v0, :cond_1793
    .line 682: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 684: check-cast v0, Ld3/a;
    .line 686: if-eqz v0, :cond_1793
    .line 688: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 691: move-result-object v0
    .line 692: check-cast v0, Ljava/lang/Boolean;
    .line 694: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 697: move-result v6
    .line 698: goto/16 :goto_1793
    .line 700: sget-object v0, Ld1/h;->m:Ld1/t;
    .line 702: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 705: move-result-object v0
    .line 706: check-cast v0, Ld1/a;
    .line 708: if-eqz v0, :cond_1793
    .line 710: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 712: check-cast v0, Ld3/a;
    .line 714: if-eqz v0, :cond_1793
    .line 716: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 719: move-result-object v0
    .line 720: check-cast v0, Ljava/lang/Boolean;
    .line 722: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 725: move-result v6
    .line 726: goto/16 :goto_1793
    .line 728: sget-object v0, Ld1/h;->k:Ld1/t;
    .line 730: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 733: move-result-object v0
    .line 734: check-cast v0, Ld1/a;
    .line 736: if-eqz v0, :cond_1793
    .line 738: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 740: check-cast v0, Ld3/a;
    .line 742: if-eqz v0, :cond_1793
    .line 744: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 747: move-result-object v0
    .line 748: check-cast v0, Ljava/lang/Boolean;
    .line 750: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 753: move-result v6
    .line 754: goto/16 :goto_1793
    .line 756: sget-object v0, Ld1/h;->l:Ld1/t;
    .line 758: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 761: move-result-object v0
    .line 762: check-cast v0, Ld1/a;
    .line 764: if-eqz v0, :cond_1793
    .line 766: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 768: check-cast v0, Ld3/a;
    .line 770: if-eqz v0, :cond_1793
    .line 772: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 775: move-result-object v0
    .line 776: check-cast v0, Ljava/lang/Boolean;
    .line 778: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 781: move-result v6
    .line 782: goto/16 :goto_1793
    .line 784: const/16 v0, 4096
    .line 786: if-ne v1, v0, :cond_790
    .line 788: move v0, v15
    .line 789: goto :goto_791
    .line 790: move v0, v6
    .line 791: const/16 v2, 8192
    .line 793: if-ne v1, v2, :cond_797
    .line 795: move v2, v15
    .line 796: goto :goto_798
    .line 797: move v2, v6
    .line 798: const v4, 0x1020039
    .line 801: if-ne v1, v4, :cond_805
    .line 803: move v4, v15
    .line 804: goto :goto_806
    .line 805: move v4, v6
    .line 806: const v8, 0x102003b
    .line 809: if-ne v1, v8, :cond_813
    .line 811: move v8, v15
    .line 812: goto :goto_814
    .line 813: move v8, v6
    .line 814: const v9, 0x1020038
    .line 817: if-ne v1, v9, :cond_821
    .line 819: move v9, v15
    .line 820: goto :goto_822
    .line 821: move v9, v6
    .line 822: const v10, 0x102003a
    .line 825: if-ne v1, v10, :cond_829
    .line 827: move v1, v15
    .line 828: goto :goto_830
    .line 829: move v1, v6
    .line 830: if-nez v4, :cond_841
    .line 832: if-nez v8, :cond_841
    .line 834: if-nez v0, :cond_841
    .line 836: if-eqz v2, :cond_839
    .line 838: goto :goto_841
    .line 839: move v10, v6
    .line 840: goto :goto_842
    .line 841: move v10, v15
    .line 842: if-nez v9, :cond_853
    .line 844: if-nez v1, :cond_853
    .line 846: if-nez v0, :cond_853
    .line 848: if-eqz v2, :cond_851
    .line 850: goto :goto_853
    .line 851: move v1, v6
    .line 852: goto :goto_854
    .line 853: move v1, v15
    .line 854: if-nez v0, :cond_858
    .line 856: if-eqz v2, :cond_968
    .line 858: sget-object v0, Ld1/q;->c:Ld1/t;
    .line 860: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 863: move-result-object v0
    .line 864: check-cast v0, Ld1/e;
    .line 866: sget-object v11, Ld1/h;->e:Ld1/t;
    .line 868: invoke-static {v13, v11}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 871: move-result-object v11
    .line 872: check-cast v11, Ld1/a;
    .line 874: if-eqz v0, :cond_968
    .line 876: if-eqz v11, :cond_968
    .line 878: iget-object v1, v0, Ld1/e;->b:Lj3/a;
    .line 880: iget v4, v1, Lj3/a;->b:F
    .line 882: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 885: move-result-object v4
    .line 886: invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F
    .line 889: move-result v4
    .line 890: iget v5, v1, Lj3/a;->a:F
    .line 892: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 895: move-result-object v7
    .line 896: invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F
    .line 899: move-result v7
    .line 900: invoke-static {v4, v7}, Ld2/b;->D(FF)F
    .line 903: move-result v4
    .line 904: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 907: move-result-object v5
    .line 908: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 911: move-result v5
    .line 912: iget v1, v1, Lj3/a;->b:F
    .line 914: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 917: move-result-object v1
    .line 918: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 921: move-result v1
    .line 922: cmpl-float v7, v5, v1
    .line 924: if-lez v7, :cond_927
    .line 926: move v5, v1
    .line 927: iget v1, v0, Ld1/e;->c:I
    .line 929: if-lez v1, :cond_936
    .line 931: sub-float/2addr v4, v5
    .line 932: add-int/2addr v1, v15
    .line 933: int-to-float v1, v1
    .line 934: div-float/2addr v4, v1
    .line 935: goto :goto_940
    .line 936: sub-float/2addr v4, v5
    .line 937: const/16 v1, 20
    .line 939: goto :goto_933
    .line 940: if-eqz v2, :cond_943
    .line 942: neg-float v4, v4
    .line 943: iget-object v1, v11, Ld1/a;->b:Ls2/a;
    .line 945: check-cast v1, Ld3/c;
    .line 947: if-eqz v1, :cond_1793
    .line 949: iget v0, v0, Ld1/e;->a:F
    .line 951: add-float/2addr v0, v4
    .line 952: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 955: move-result-object v0
    .line 956: invoke-interface {v1, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 959: move-result-object v0
    .line 960: check-cast v0, Ljava/lang/Boolean;
    .line 962: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 965: move-result v6
    .line 966: goto/16 :goto_1793
    .line 968: iget-object v0, v5, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 970: iget-object v0, v0, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 972: iget-object v0, v0, Lz0/v0;->b:Lz0/w;
    .line 974: invoke-static {v0}, Landroidx/compose/ui/layout/a;->b(Lz0/w;)Lj0/d;
    .line 977: move-result-object v0
    .line 978: invoke-virtual {v0}, Lj0/d;->c()F
    .line 981: move-result v11
    .line 982: invoke-virtual {v0}, Lj0/d;->b()F
    .line 985: move-result v0
    .line 986: invoke-static {v11, v0}, Ld2/c;->f(FF)J
    .line 989: move-result-wide v11
    .line 990: sget-object v0, Ld1/h;->d:Ld1/t;
    .line 992: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 995: move-result-object v0
    .line 996: check-cast v0, Ld1/a;
    .line 998: if-nez v0, :cond_1002
    .line 1000: goto/16 :goto_1793
    .line 1002: sget-object v14, Ld1/q;->o:Ld1/t;
    .line 1004: invoke-static {v13, v14}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1007: move-result-object v14
    .line 1008: check-cast v14, Ld1/g;
    .line 1010: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 1012: if-eqz v14, :cond_1071
    .line 1014: if-eqz v10, :cond_1071
    .line 1016: invoke-static {v11, v12}, Lj0/f;->d(J)F
    .line 1019: move-result v10
    .line 1020: if-nez v4, :cond_1024
    .line 1022: if-eqz v2, :cond_1025
    .line 1024: neg-float v10, v10
    .line 1025: iget-boolean v15, v14, Ld1/g;->c:Z
    .line 1027: if-eqz v15, :cond_1030
    .line 1029: neg-float v10, v10
    .line 1030: invoke-static {v5}, Landroidx/compose/ui/platform/n1;->l(Ld1/n;)Z
    .line 1033: move-result v5
    .line 1034: if-eqz v5, :cond_1041
    .line 1036: if-nez v4, :cond_1040
    .line 1038: if-eqz v8, :cond_1041
    .line 1040: neg-float v10, v10
    .line 1041: invoke-static {v14, v10}, Landroidx/compose/ui/platform/j0;->r(Ld1/g;F)Z
    .line 1044: move-result v4
    .line 1045: if-eqz v4, :cond_1071
    .line 1047: check-cast v0, Ld3/e;
    .line 1049: if-eqz v0, :cond_1793
    .line 1051: invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1054: move-result-object v1
    .line 1055: invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1058: move-result-object v2
    .line 1059: invoke-interface {v0, v1, v2}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 1062: move-result-object v0
    .line 1063: check-cast v0, Ljava/lang/Boolean;
    .line 1065: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1068: move-result v6
    .line 1069: goto/16 :goto_1793
    .line 1071: sget-object v4, Ld1/q;->p:Ld1/t;
    .line 1073: invoke-static {v13, v4}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1076: move-result-object v4
    .line 1077: check-cast v4, Ld1/g;
    .line 1079: if-eqz v4, :cond_1793
    .line 1081: if-eqz v1, :cond_1793
    .line 1083: invoke-static {v11, v12}, Lj0/f;->b(J)F
    .line 1086: move-result v1
    .line 1087: if-nez v9, :cond_1091
    .line 1089: if-eqz v2, :cond_1092
    .line 1091: neg-float v1, v1
    .line 1092: iget-boolean v2, v4, Ld1/g;->c:Z
    .line 1094: if-eqz v2, :cond_1097
    .line 1096: neg-float v1, v1
    .line 1097: invoke-static {v4, v1}, Landroidx/compose/ui/platform/j0;->r(Ld1/g;F)Z
    .line 1100: move-result v2
    .line 1101: if-eqz v2, :cond_1793
    .line 1103: check-cast v0, Ld3/e;
    .line 1105: if-eqz v0, :cond_1793
    .line 1107: invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1110: move-result-object v2
    .line 1111: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 1114: move-result-object v1
    .line 1115: invoke-interface {v0, v2, v1}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 1118: move-result-object v0
    .line 1119: check-cast v0, Ljava/lang/Boolean;
    .line 1121: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1124: move-result v6
    .line 1125: goto/16 :goto_1793
    .line 1127: sget-object v0, Ld1/h;->c:Ld1/t;
    .line 1129: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1132: move-result-object v0
    .line 1133: check-cast v0, Ld1/a;
    .line 1135: if-eqz v0, :cond_1793
    .line 1137: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 1139: check-cast v0, Ld3/a;
    .line 1141: if-eqz v0, :cond_1793
    .line 1143: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 1146: move-result-object v0
    .line 1147: check-cast v0, Ljava/lang/Boolean;
    .line 1149: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1152: move-result v6
    .line 1153: goto/16 :goto_1793
    .line 1155: sget-object v1, Ld1/h;->b:Ld1/t;
    .line 1157: invoke-static {v13, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1160: move-result-object v1
    .line 1161: check-cast v1, Ld1/a;
    .line 1163: if-eqz v1, :cond_1178
    .line 1165: iget-object v1, v1, Ld1/a;->b:Ls2/a;
    .line 1167: check-cast v1, Ld3/a;
    .line 1169: if-eqz v1, :cond_1178
    .line 1171: invoke-interface {v1}, Ld3/a;->s()Ljava/lang/Object;
    .line 1174: move-result-object v1
    .line 1175: check-cast v1, Ljava/lang/Boolean;
    .line 1177: goto :goto_1179
    .line 1178: move-object v1, v9
    .line 1179: invoke-static {v4, v0, v15, v9, v8}, Landroidx/compose/ui/platform/j0;->z(Landroidx/compose/ui/platform/j0;IILjava/lang/Integer;I)V
    .line 1182: if-eqz v1, :cond_1793
    .line 1184: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1187: move-result v6
    .line 1188: goto/16 :goto_1793
    .line 1190: sget-object v0, Ld1/q;->k:Ld1/t;
    .line 1192: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1195: move-result-object v0
    .line 1196: sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 1198: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 1201: move-result v0
    .line 1202: if-eqz v0, :cond_1793
    .line 1204: invoke-virtual {v12}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Li0/e;
    .line 1207: move-result-object v0
    .line 1208: check-cast v0, Li0/f;
    .line 1210: invoke-virtual {v0, v6, v15}, Li0/f;->a(ZZ)V
    .line 1213: move v6, v15
    .line 1214: goto/16 :goto_1793
    .line 1216: sget-object v0, Ld1/h;->p:Ld1/t;
    .line 1218: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1221: move-result-object v0
    .line 1222: check-cast v0, Ld1/a;
    .line 1224: if-eqz v0, :cond_1793
    .line 1226: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 1228: check-cast v0, Ld3/a;
    .line 1230: if-eqz v0, :cond_1793
    .line 1232: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 1235: move-result-object v0
    .line 1236: check-cast v0, Ljava/lang/Boolean;
    .line 1238: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1241: move-result v6
    .line 1242: goto/16 :goto_1793
    .line 1244: if-eqz v2, :cond_1256
    .line 1246: const-string v0, "ACTION_ARGUMENT_SELECTION_START_INT"
    .line 1248: const/4 v1, -1
    .line 1249: invoke-virtual {v2, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 1252: move-result v16
    .line 1253: move/from16 v0, v16
    .line 1255: goto :goto_1258
    .line 1256: const/4 v1, -1
    .line 1257: move v0, v1
    .line 1258: if-eqz v2, :cond_1267
    .line 1260: const-string v7, "ACTION_ARGUMENT_SELECTION_END_INT"
    .line 1262: invoke-virtual {v2, v7, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 1265: move-result v13
    .line 1266: goto :goto_1268
    .line 1267: const/4 v13, -1
    .line 1268: invoke-virtual {v4, v5, v0, v13, v6}, Landroidx/compose/ui/platform/j0;->D(Ld1/n;IIZ)Z
    .line 1271: move-result v0
    .line 1272: if-eqz v0, :cond_1281
    .line 1274: invoke-virtual {v4, v14}, Landroidx/compose/ui/platform/j0;->u(I)I
    .line 1277: move-result v1
    .line 1278: invoke-static {v4, v1, v6, v9, v8}, Landroidx/compose/ui/platform/j0;->z(Landroidx/compose/ui/platform/j0;IILjava/lang/Integer;I)V
    .line 1281: move v6, v0
    .line 1282: goto/16 :goto_1793
    .line 1284: sget-object v0, Ld1/h;->j:Ld1/t;
    .line 1286: invoke-static {v13, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 1289: move-result-object v0
    .line 1290: check-cast v0, Ld1/a;
    .line 1292: if-eqz v0, :cond_1793
    .line 1294: iget-object v0, v0, Ld1/a;->b:Ls2/a;
    .line 1296: check-cast v0, Ld3/a;
    .line 1298: if-eqz v0, :cond_1793
    .line 1300: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 1303: move-result-object v0
    .line 1304: check-cast v0, Ljava/lang/Boolean;
    .line 1306: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 1309: move-result v6
    .line 1310: goto/16 :goto_1793
    .line 1312: if-eqz v2, :cond_1793
    .line 1314: const-string v0, "ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT"
    .line 1316: invoke-virtual {v2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I
    .line 1319: move-result v0
    .line 1320: const-string v8, "ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN"
    .line 1322: invoke-virtual {v2, v8}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z
    .line 1325: move-result v2
    .line 1326: if-ne v1, v11, :cond_1330
    .line 1328: move v1, v15
    .line 1329: goto :goto_1331
    .line 1330: move v1, v6
    .line 1331: iget-object v8, v4, Landroidx/compose/ui/platform/j0;->p:Ljava/lang/Integer;
    .line 1333: if-nez v8, :cond_1337
    .line 1335: const/4 v8, -1
    .line 1336: goto :goto_1344
    .line 1337: invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I
    .line 1340: move-result v8
    .line 1341: if-eq v14, v8, :cond_1352
    .line 1343: goto :goto_1335
    .line 1344: iput v8, v4, Landroidx/compose/ui/platform/j0;->o:I
    .line 1346: invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 1349: move-result-object v8
    .line 1350: iput-object v8, v4, Landroidx/compose/ui/platform/j0;->p:Ljava/lang/Integer;
    .line 1352: invoke-static {v5}, Landroidx/compose/ui/platform/j0;->m(Ld1/n;)Ljava/lang/String;
    .line 1355: move-result-object v8
    .line 1356: if-eqz v8, :cond_1793
    .line 1358: invoke-virtual {v8}, Ljava/lang/String;->length()I
    .line 1361: move-result v14
    .line 1362: if-nez v14, :cond_1366
    .line 1364: goto/16 :goto_1793
    .line 1366: invoke-static {v5}, Landroidx/compose/ui/platform/j0;->m(Ld1/n;)Ljava/lang/String;
    .line 1369: move-result-object v14
    .line 1370: if-eqz v14, :cond_1636
    .line 1372: invoke-virtual {v14}, Ljava/lang/String;->length()I
    .line 1375: move-result v17
    .line 1376: if-nez v17, :cond_1380
    .line 1378: goto/16 :goto_1636
    .line 1380: const-string v10, "view.context.resources.configuration.locale"
    .line 1382: if-eq v0, v15, :cond_1585
    .line 1384: if-eq v0, v7, :cond_1534
    .line 1386: const/4 v7, 4
    .line 1387: if-eq v0, v7, :cond_1422
    .line 1389: const/16 v10, 8
    .line 1391: if-eq v0, v10, :cond_1399
    .line 1393: const/16 v10, 16
    .line 1395: if-eq v0, v10, :cond_1422
    .line 1397: goto/16 :goto_1636
    .line 1399: sget-object v7, Landroidx/compose/ui/platform/f;->c:Landroidx/compose/ui/platform/f;
    .line 1401: if-nez v7, :cond_1410
    .line 1403: new-instance v7, Landroidx/compose/ui/platform/f;
    .line 1405: invoke-direct {v7}, Landroidx/compose/ui/platform/b;-><init>()V
    .line 1408: sput-object v7, Landroidx/compose/ui/platform/f;->c:Landroidx/compose/ui/platform/f;
    .line 1410: sget-object v7, Landroidx/compose/ui/platform/f;->c:Landroidx/compose/ui/platform/f;
    .line 1412: const-string v9, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.ParagraphTextSegmentIterator"
    .line 1414: invoke-static {v7, v9}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1417: iput-object v14, v7, Landroidx/compose/ui/platform/b;->a:Ljava/lang/String;
    .line 1419: move-object v9, v7
    .line 1420: goto/16 :goto_1636
    .line 1422: sget-object v10, Ld1/h;->a:Ld1/t;
    .line 1424: invoke-virtual {v13, v10}, Ld1/i;->b(Ld1/t;)Z
    .line 1427: move-result v12
    .line 1428: if-nez v12, :cond_1432
    .line 1430: goto/16 :goto_1636
    .line 1432: new-instance v12, Ljava/util/ArrayList;
    .line 1434: invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V
    .line 1437: invoke-virtual {v13, v10}, Ld1/i;->c(Ld1/t;)Ljava/lang/Object;
    .line 1440: move-result-object v10
    .line 1441: check-cast v10, Ld1/a;
    .line 1443: iget-object v10, v10, Ld1/a;->b:Ls2/a;
    .line 1445: check-cast v10, Ld3/c;
    .line 1447: if-eqz v10, :cond_1456
    .line 1449: invoke-interface {v10, v12}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 1452: move-result-object v10
    .line 1453: check-cast v10, Ljava/lang/Boolean;
    .line 1455: goto :goto_1457
    .line 1456: move-object v10, v9
    .line 1457: sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 1459: invoke-static {v10, v11}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 1462: move-result v10
    .line 1463: if-eqz v10, :cond_1636
    .line 1465: invoke-virtual {v12, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 1468: move-result-object v9
    .line 1469: check-cast v9, Lf1/z;
    .line 1471: const-string v10, "layoutResult"
    .line 1473: if-ne v0, v7, :cond_1501
    .line 1475: sget-object v7, Landroidx/compose/ui/platform/d;->d:Landroidx/compose/ui/platform/d;
    .line 1477: if-nez v7, :cond_1486
    .line 1479: new-instance v7, Landroidx/compose/ui/platform/d;
    .line 1481: invoke-direct {v7}, Landroidx/compose/ui/platform/b;-><init>()V
    .line 1484: sput-object v7, Landroidx/compose/ui/platform/d;->d:Landroidx/compose/ui/platform/d;
    .line 1486: sget-object v7, Landroidx/compose/ui/platform/d;->d:Landroidx/compose/ui/platform/d;
    .line 1488: const-string v11, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.LineTextSegmentIterator"
    .line 1490: invoke-static {v7, v11}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1493: invoke-static {v9, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1496: iput-object v14, v7, Landroidx/compose/ui/platform/b;->a:Ljava/lang/String;
    .line 1498: iput-object v9, v7, Landroidx/compose/ui/platform/d;->c:Lf1/z;
    .line 1500: goto :goto_1419
    .line 1501: sget-object v7, Landroidx/compose/ui/platform/e;->e:Landroidx/compose/ui/platform/e;
    .line 1503: if-nez v7, :cond_1517
    .line 1505: new-instance v7, Landroidx/compose/ui/platform/e;
    .line 1507: invoke-direct {v7}, Landroidx/compose/ui/platform/b;-><init>()V
    .line 1510: new-instance v11, Landroid/graphics/Rect;
    .line 1512: invoke-direct {v11}, Landroid/graphics/Rect;-><init>()V
    .line 1515: sput-object v7, Landroidx/compose/ui/platform/e;->e:Landroidx/compose/ui/platform/e;
    .line 1517: sget-object v7, Landroidx/compose/ui/platform/e;->e:Landroidx/compose/ui/platform/e;
    .line 1519: const-string v11, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.PageTextSegmentIterator"
    .line 1521: invoke-static {v7, v11}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1524: invoke-static {v9, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1527: iput-object v14, v7, Landroidx/compose/ui/platform/b;->a:Ljava/lang/String;
    .line 1529: iput-object v9, v7, Landroidx/compose/ui/platform/e;->c:Lf1/z;
    .line 1531: iput-object v5, v7, Landroidx/compose/ui/platform/e;->d:Ld1/n;
    .line 1533: goto :goto_1419
    .line 1534: invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 1537: move-result-object v7
    .line 1538: invoke-virtual {v7}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 1541: move-result-object v7
    .line 1542: invoke-virtual {v7}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    .line 1545: move-result-object v7
    .line 1546: iget-object v7, v7, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;
    .line 1548: invoke-static {v7, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1551: sget-object v9, Landroidx/compose/ui/platform/h;->d:Landroidx/compose/ui/platform/h;
    .line 1553: if-nez v9, :cond_1573
    .line 1555: new-instance v9, Landroidx/compose/ui/platform/h;
    .line 1557: invoke-direct {v9}, Landroidx/compose/ui/platform/b;-><init>()V
    .line 1560: invoke-static {v7}, Ljava/text/BreakIterator;->getWordInstance(Ljava/util/Locale;)Ljava/text/BreakIterator;
    .line 1563: move-result-object v7
    .line 1564: const-string v10, "getWordInstance(locale)"
    .line 1566: invoke-static {v7, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1569: iput-object v7, v9, Landroidx/compose/ui/platform/h;->c:Ljava/text/BreakIterator;
    .line 1571: sput-object v9, Landroidx/compose/ui/platform/h;->d:Landroidx/compose/ui/platform/h;
    .line 1573: sget-object v7, Landroidx/compose/ui/platform/h;->d:Landroidx/compose/ui/platform/h;
    .line 1575: const-string v9, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.WordTextSegmentIterator"
    .line 1577: invoke-static {v7, v9}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1580: invoke-virtual {v7, v14}, Landroidx/compose/ui/platform/h;->e(Ljava/lang/String;)V
    .line 1583: goto/16 :goto_1419
    .line 1585: invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 1588: move-result-object v7
    .line 1589: invoke-virtual {v7}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 1592: move-result-object v7
    .line 1593: invoke-virtual {v7}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    .line 1596: move-result-object v7
    .line 1597: iget-object v7, v7, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;
    .line 1599: invoke-static {v7, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1602: sget-object v9, Landroidx/compose/ui/platform/c;->d:Landroidx/compose/ui/platform/c;
    .line 1604: if-nez v9, :cond_1624
    .line 1606: new-instance v9, Landroidx/compose/ui/platform/c;
    .line 1608: invoke-direct {v9}, Landroidx/compose/ui/platform/b;-><init>()V
    .line 1611: invoke-static {v7}, Ljava/text/BreakIterator;->getCharacterInstance(Ljava/util/Locale;)Ljava/text/BreakIterator;
    .line 1614: move-result-object v7
    .line 1615: const-string v10, "getCharacterInstance(locale)"
    .line 1617: invoke-static {v7, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1620: iput-object v7, v9, Landroidx/compose/ui/platform/c;->c:Ljava/text/BreakIterator;
    .line 1622: sput-object v9, Landroidx/compose/ui/platform/c;->d:Landroidx/compose/ui/platform/c;
    .line 1624: sget-object v7, Landroidx/compose/ui/platform/c;->d:Landroidx/compose/ui/platform/c;
    .line 1626: const-string v9, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.CharacterTextSegmentIterator"
    .line 1628: invoke-static {v7, v9}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1631: invoke-virtual {v7, v14}, Landroidx/compose/ui/platform/c;->e(Ljava/lang/String;)V
    .line 1634: goto/16 :goto_1419
    .line 1636: if-nez v9, :cond_1640
    .line 1638: goto/16 :goto_1793
    .line 1640: invoke-virtual {v4, v5}, Landroidx/compose/ui/platform/j0;->g(Ld1/n;)I
    .line 1643: move-result v7
    .line 1644: const/4 v10, -1
    .line 1645: if-ne v7, v10, :cond_1655
    .line 1647: if-eqz v1, :cond_1651
    .line 1649: move v7, v6
    .line 1650: goto :goto_1655
    .line 1651: invoke-virtual {v8}, Ljava/lang/String;->length()I
    .line 1654: move-result v7
    .line 1655: if-eqz v1, :cond_1662
    .line 1657: invoke-interface {v9, v7}, Landroidx/compose/ui/platform/g;->b(I)[I
    .line 1660: move-result-object v7
    .line 1661: goto :goto_1666
    .line 1662: invoke-interface {v9, v7}, Landroidx/compose/ui/platform/g;->a(I)[I
    .line 1665: move-result-object v7
    .line 1666: if-nez v7, :cond_1670
    .line 1668: goto/16 :goto_1793
    .line 1670: aget v11, v7, v6
    .line 1672: aget v12, v7, v15
    .line 1674: if-eqz v2, :cond_1710
    .line 1676: sget-object v2, Ld1/q;->a:Ld1/t;
    .line 1678: invoke-virtual {v13, v2}, Ld1/i;->b(Ld1/t;)Z
    .line 1681: move-result v2
    .line 1682: if-nez v2, :cond_1710
    .line 1684: sget-object v2, Ld1/q;->u:Ld1/t;
    .line 1686: invoke-virtual {v13, v2}, Ld1/i;->b(Ld1/t;)Z
    .line 1689: move-result v2
    .line 1690: if-eqz v2, :cond_1710
    .line 1692: invoke-virtual {v4, v5}, Landroidx/compose/ui/platform/j0;->h(Ld1/n;)I
    .line 1695: move-result v2
    .line 1696: const/4 v6, -1
    .line 1697: if-ne v2, v6, :cond_1704
    .line 1699: if-eqz v1, :cond_1703
    .line 1701: move v2, v11
    .line 1702: goto :goto_1704
    .line 1703: move v2, v12
    .line 1704: if-eqz v1, :cond_1708
    .line 1706: move v6, v12
    .line 1707: goto :goto_1716
    .line 1708: move v6, v11
    .line 1709: goto :goto_1716
    .line 1710: if-eqz v1, :cond_1714
    .line 1712: move v2, v12
    .line 1713: goto :goto_1715
    .line 1714: move v2, v11
    .line 1715: move v6, v2
    .line 1716: if-eqz v1, :cond_1721
    .line 1718: const/16 v9, 256
    .line 1720: goto :goto_1723
    .line 1721: const/16 v9, 512
    .line 1723: new-instance v1, Landroidx/compose/ui/platform/c0;
    .line 1725: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    .line 1728: move-result-wide v13
    .line 1729: move-object v7, v1
    .line 1730: move-object v8, v5
    .line 1731: move v10, v0
    .line 1732: invoke-direct/range {v7 .. v14}, Landroidx/compose/ui/platform/c0;-><init>(Ld1/n;IIIIJ)V
    .line 1735: iput-object v1, v4, Landroidx/compose/ui/platform/j0;->w:Landroidx/compose/ui/platform/c0;
    .line 1737: invoke-virtual {v4, v5, v2, v6, v15}, Landroidx/compose/ui/platform/j0;->D(Ld1/n;IIZ)Z
    .line 1740: goto/16 :goto_1213
    .line 1742: iget v1, v4, Landroidx/compose/ui/platform/j0;->l:I
    .line 1744: if-ne v1, v0, :cond_1793
    .line 1746: iput v11, v4, Landroidx/compose/ui/platform/j0;->l:I
    .line 1748: invoke-virtual {v12}, Landroid/view/View;->invalidate()V
    .line 1751: invoke-static {v4, v0, v7, v9, v8}, Landroidx/compose/ui/platform/j0;->z(Landroidx/compose/ui/platform/j0;IILjava/lang/Integer;I)V
    .line 1754: goto/16 :goto_1213
    .line 1756: iget-object v1, v4, Landroidx/compose/ui/platform/j0;->f:Landroid/view/accessibility/AccessibilityManager;
    .line 1758: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z
    .line 1761: move-result v2
    .line 1762: if-eqz v2, :cond_1793
    .line 1764: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityManager;->isTouchExplorationEnabled()Z
    .line 1767: move-result v1
    .line 1768: if-eqz v1, :cond_1793
    .line 1770: iget v1, v4, Landroidx/compose/ui/platform/j0;->l:I
    .line 1772: if-ne v1, v0, :cond_1775
    .line 1774: goto :goto_1793
    .line 1775: if-eq v1, v11, :cond_1780
    .line 1777: invoke-static {v4, v1, v7, v9, v8}, Landroidx/compose/ui/platform/j0;->z(Landroidx/compose/ui/platform/j0;IILjava/lang/Integer;I)V
    .line 1780: iput v0, v4, Landroidx/compose/ui/platform/j0;->l:I
    .line 1782: invoke-virtual {v12}, Landroid/view/View;->invalidate()V
    .line 1785: const v1, 0x8000
    .line 1788: invoke-static {v4, v0, v1, v9, v8}, Landroidx/compose/ui/platform/j0;->z(Landroidx/compose/ui/platform/j0;IILjava/lang/Integer;I)V
    .line 1791: goto/16 :goto_1213
    .line 1793: return v6
    .line 1794: nop
    .line 1795: move-exception v0
    .line 1796: return-wide v0
    .line 1797: nop
    .line 1798: instance-of v0, v0, B
    .line 1800: nop
    .line 1801: nop
    .line 1802: nop
    .line 1803: nop
    .line 1804: nop
    .line 1805: nop
    .line 1806: nop
    .line 1807: move v0, v0
    .line 1808: nop
    .line 1809: move-wide v0, v0
    .line 1810: nop
    .line 1811: move-object/from16 v0, v0
    .line 1813: return-wide v0
    .line 1814: nop
    .line 1815: instance-of v0, v0, Lai/onnxruntime/OnnxValue$OnnxValueType;
    .line 1817: move/from16 v1, v61
    .line 1819: move/from16 v1, v84
    .line 1821: move/from16 v1, v1070
    .line 1823: nop
    .line 1824: const/4 v4, 0
    .line 1825: nop
    .line 1826: add-long/2addr v2, v0
    .line 1827: nop
    .line 1828: add-long/2addr v2, v0
    .line 1829: nop
    .line 1830: rem-long v2, v0, v0
    .line 1832: int-to-double v2, v0
    .line 1833: nop
    .line 1834: sput v2, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 1836: aput v2, v0, v0
    .line 1838: cmpl-double v2, v0, v0
    .line 1840: 0xff ; unknown opcode
    .line 1841: nop
    .line 1842: 0xf5 ; unknown opcode
    .line 1843: nop
    .line 1844: ushr-long/2addr v0, v0
    .line 1845: nop
    .line 1846: div-float v0, v0, v0
    .line 1848: nop
    .line 1849: move-wide v0, v0
    .line 1850: if-eqz v0, :cond_2108
    .line 1852: shl-int/2addr v2, v0
    .line 1853: nop
    .line 1854: shl-int/2addr v2, v0
    .line 1855: nop
    .line 1856: shl-int/2addr v2, v0
    .line 1857: nop
    .line 1858: shl-int/2addr v2, v0
    .line 1859: nop
    .line 1860: nop
    .line 1861: move-wide v0, v0
    .line 1862: aget-object v0, v2, v1
    .line 1864: float-to-int v0, v0
    .line 1865: nop
    .line 1866: sput-byte v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 1868: aput-byte v0, v0, v0
    .line 1870: if-ne v0, v0, :cond_1870
.end method

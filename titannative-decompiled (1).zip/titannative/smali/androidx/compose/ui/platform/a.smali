.class public abstract Landroidx/compose/ui/platform/a;
.super Landroid/view/ViewGroup;
.source "SourceFile"

.field public i:Ljava/lang/ref/WeakReference;
.field public j:Landroid/os/IBinder;
.field public k:Lu/d0;
.field public l:Lu/e0;
.field public m:Li/q1;
.field public n:Z
.field public o:Z
.field public p:Z

# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 5

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1, v2, v3, v4}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .line 8: const/4 v2, 0
    .line 9: invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setClipChildren(Z)V
    .line 12: invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setClipToPadding(Z)V
    .line 15: new-instance v2, Landroidx/compose/ui/platform/x;
    .line 17: const/4 v3, 1
    .line 18: invoke-direct {v2, v3, v1}, Landroidx/compose/ui/platform/x;-><init>(ILjava/lang/Object;)V
    .line 21: invoke-virtual {v1, v2}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V
    .line 24: new-instance v3, Landroidx/compose/ui/platform/r1;
    .line 26: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 29: invoke-static {v1}, Ld2/c;->X(Landroid/view/View;)Lh2/a;
    .line 32: move-result-object v4
    .line 33: iget-object v4, v4, Lh2/a;->a:Ljava/util/ArrayList;
    .line 35: invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 38: new-instance v4, Li/q1;
    .line 40: const/4 v0, 2
    .line 41: invoke-direct {v4, v1, v2, v3, v0}, Li/q1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .line 44: iput-object v4, v1, Landroidx/compose/ui/platform/a;->m:Li/q1;
    .line 46: return-void
.end method

# direct methods
.method private static synthetic getDisposeViewCompositionStrategy$annotations()V
    .registers 0

    .line 0: return-void
.end method

# direct methods
.method public static synthetic getShowLayoutBounds$annotations()V
    .registers 0

    .line 0: return-void
.end method

# direct methods
.method private final setParentContext(Lu/e0;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/a;->l:Lu/e0;
    .line 2: if-eq v0, v2, :cond_29
    .line 4: iput-object v2, v1, Landroidx/compose/ui/platform/a;->l:Lu/e0;
    .line 6: const/4 v0, 0
    .line 7: if-eqz v2, :cond_11
    .line 9: iput-object v0, v1, Landroidx/compose/ui/platform/a;->i:Ljava/lang/ref/WeakReference;
    .line 11: iget-object v2, v1, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 13: if-eqz v2, :cond_29
    .line 15: invoke-interface {v2}, Lu/d0;->a()V
    .line 18: iput-object v0, v1, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 20: invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z
    .line 23: move-result v2
    .line 24: if-eqz v2, :cond_29
    .line 26: invoke-virtual {v1}, Landroidx/compose/ui/platform/a;->d()V
    .line 29: return-void
.end method

# direct methods
.method private final setPreviousAttachedWindowToken(Landroid/os/IBinder;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/a;->j:Landroid/os/IBinder;
    .line 2: if-eq v0, v2, :cond_9
    .line 4: iput-object v2, v1, Landroidx/compose/ui/platform/a;->j:Landroid/os/IBinder;
    .line 6: const/4 v2, 0
    .line 7: iput-object v2, v1, Landroidx/compose/ui/platform/a;->i:Ljava/lang/ref/WeakReference;
    .line 9: return-void
.end method

# virtual methods
.method public abstract a(Lu/l;I)V
.end method

# virtual methods
.method public final addView(Landroid/view/View;)V
    .registers 2

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 6: return-void
.end method

# virtual methods
.method public final addView(Landroid/view/View;I)V
    .registers 3

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V
    .line 6: return-void
.end method

# virtual methods
.method public final addView(Landroid/view/View;II)V
    .registers 4

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;II)V
    .line 6: return-void
.end method

# virtual methods
.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .line 6: return-void
.end method

# virtual methods
.method public final addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 3

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 6: return-void
.end method

# virtual methods
.method public final addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)Z
    .registers 4

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1, v2, v3}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)Z
    .line 6: move-result v1
    .line 7: return v1
.end method

# virtual methods
.method public final addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z
    .registers 5

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->b()V
    .line 3: invoke-super {v0, v1, v2, v3, v4}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z
    .line 6: move-result v1
    .line 7: return v1
.end method

# virtual methods
.method public final b()V
    .registers 4

    .line 0: iget-boolean v0, v3, Landroidx/compose/ui/platform/a;->o:Z
    .line 2: if-eqz v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/UnsupportedOperationException;
    .line 7: new-instance v1, Ljava/lang/StringBuilder;
    .line 9: const-string v2, "Cannot add views to "
    .line 11: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 14: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 17: move-result-object v2
    .line 18: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    .line 21: move-result-object v2
    .line 22: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 25: const-string v2, "; only Compose content is supported"
    .line 27: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 33: move-result-object v1
    .line 34: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 37: throw v0
.end method

# virtual methods
.method public final c()V
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 2: if-eqz v0, :cond_7
    .line 4: invoke-interface {v0}, Lu/d0;->a()V
    .line 7: const/4 v0, 0
    .line 8: iput-object v0, v1, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 10: invoke-virtual {v1}, Landroid/view/View;->requestLayout()V
    .line 13: return-void
.end method

# virtual methods
.method public final d()V
    .registers 6

    .line 0: iget-object v0, v5, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 2: if-nez v0, :cond_38
    .line 4: const/4 v0, 0
    .line 5: const/4 v1, 1
    .line 6: iput-boolean v1, v5, Landroidx/compose/ui/platform/a;->o:Z
    .line 8: invoke-virtual {v5}, Landroidx/compose/ui/platform/a;->g()Lu/e0;
    .line 11: move-result-object v2
    .line 12: new-instance v3, Ll/v0;
    .line 14: const/4 v4, 5
    .line 15: invoke-direct {v3, v4, v5}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 18: const v4, 0xd8e40040
    .line 21: invoke-static {v4, v3, v1}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 24: move-result-object v1
    .line 25: invoke-static {v5, v2, v1}, Landroidx/compose/ui/platform/m3;->a(Landroidx/compose/ui/platform/a;Lu/e0;Lb0/c;)Lu/d0;
    .line 28: move-result-object v1
    .line 29: iput-object v1, v5, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 31: iput-boolean v0, v5, Landroidx/compose/ui/platform/a;->o:Z
    .line 33: goto :goto_38
    .line 34: move-exception v1
    .line 35: iput-boolean v0, v5, Landroidx/compose/ui/platform/a;->o:Z
    .line 37: throw v1
    .line 38: return-void
.end method

# virtual methods
.method public e(IIIIZ)V
    .registers 8

    .line 0: const/4 v7, 0
    .line 1: invoke-virtual {v2, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 4: move-result-object v7
    .line 5: if-eqz v7, :cond_30
    .line 7: invoke-virtual {v2}, Landroid/view/View;->getPaddingLeft()I
    .line 10: move-result v0
    .line 11: invoke-virtual {v2}, Landroid/view/View;->getPaddingTop()I
    .line 14: move-result v1
    .line 15: sub-int/2addr v5, v3
    .line 16: invoke-virtual {v2}, Landroid/view/View;->getPaddingRight()I
    .line 19: move-result v3
    .line 20: sub-int/2addr v5, v3
    .line 21: sub-int/2addr v6, v4
    .line 22: invoke-virtual {v2}, Landroid/view/View;->getPaddingBottom()I
    .line 25: move-result v3
    .line 26: sub-int/2addr v6, v3
    .line 27: invoke-virtual {v7, v0, v1, v5, v6}, Landroid/view/View;->layout(IIII)V
    .line 30: return-void
.end method

# virtual methods
.method public f(II)V
    .registers 8

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v5, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 4: move-result-object v1
    .line 5: if-nez v1, :cond_11
    .line 7: invoke-super {v5, v6, v7}, Landroid/view/View;->onMeasure(II)V
    .line 10: return-void
    .line 11: invoke-static {v6}, Landroid/view/View$MeasureSpec;->getSize(I)I
    .line 14: move-result v2
    .line 15: invoke-virtual {v5}, Landroid/view/View;->getPaddingLeft()I
    .line 18: move-result v3
    .line 19: sub-int/2addr v2, v3
    .line 20: invoke-virtual {v5}, Landroid/view/View;->getPaddingRight()I
    .line 23: move-result v3
    .line 24: sub-int/2addr v2, v3
    .line 25: invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I
    .line 28: move-result v2
    .line 29: invoke-static {v7}, Landroid/view/View$MeasureSpec;->getSize(I)I
    .line 32: move-result v3
    .line 33: invoke-virtual {v5}, Landroid/view/View;->getPaddingTop()I
    .line 36: move-result v4
    .line 37: sub-int/2addr v3, v4
    .line 38: invoke-virtual {v5}, Landroid/view/View;->getPaddingBottom()I
    .line 41: move-result v4
    .line 42: sub-int/2addr v3, v4
    .line 43: invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I
    .line 46: move-result v0
    .line 47: invoke-static {v6}, Landroid/view/View$MeasureSpec;->getMode(I)I
    .line 50: move-result v6
    .line 51: invoke-static {v2, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    .line 54: move-result v6
    .line 55: invoke-static {v7}, Landroid/view/View$MeasureSpec;->getMode(I)I
    .line 58: move-result v7
    .line 59: invoke-static {v0, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    .line 62: move-result v7
    .line 63: invoke-virtual {v1, v6, v7}, Landroid/view/View;->measure(II)V
    .line 66: invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I
    .line 69: move-result v6
    .line 70: invoke-virtual {v5}, Landroid/view/View;->getPaddingLeft()I
    .line 73: move-result v7
    .line 74: add-int/2addr v7, v6
    .line 75: invoke-virtual {v5}, Landroid/view/View;->getPaddingRight()I
    .line 78: move-result v6
    .line 79: add-int/2addr v6, v7
    .line 80: invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I
    .line 83: move-result v7
    .line 84: invoke-virtual {v5}, Landroid/view/View;->getPaddingTop()I
    .line 87: move-result v0
    .line 88: add-int/2addr v0, v7
    .line 89: invoke-virtual {v5}, Landroid/view/View;->getPaddingBottom()I
    .line 92: move-result v7
    .line 93: add-int/2addr v7, v0
    .line 94: invoke-virtual {v5, v6, v7}, Landroid/view/View;->setMeasuredDimension(II)V
    .line 97: return-void
.end method

# virtual methods
.method public final g()Lu/e0;
    .registers 14

    .line 0: iget-object v0, v13, Landroidx/compose/ui/platform/a;->l:Lu/e0;
    .line 2: if-nez v0, :cond_523
    .line 4: invoke-static {v13}, Landroidx/compose/ui/platform/g3;->b(Landroid/view/View;)Lu/e0;
    .line 7: move-result-object v0
    .line 8: if-eqz v0, :cond_11
    .line 10: goto :goto_33
    .line 11: invoke-virtual {v13}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 14: move-result-object v1
    .line 15: if-nez v0, :cond_33
    .line 17: instance-of v2, v1, Landroid/view/View;
    .line 19: if-eqz v2, :cond_33
    .line 21: move-object v0, v1
    .line 22: check-cast v0, Landroid/view/View;
    .line 24: invoke-static {v0}, Landroidx/compose/ui/platform/g3;->b(Landroid/view/View;)Lu/e0;
    .line 27: move-result-object v0
    .line 28: invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;
    .line 31: move-result-object v1
    .line 32: goto :goto_15
    .line 33: const/4 v1, 0
    .line 34: if-eqz v0, :cond_73
    .line 36: instance-of v2, v0, Lu/o2;
    .line 38: if-eqz v2, :cond_62
    .line 40: move-object v2, v0
    .line 41: check-cast v2, Lu/o2;
    .line 43: iget-object v2, v2, Lu/o2;->q:Lkotlinx/coroutines/flow/p0;
    .line 45: invoke-virtual {v2}, Lkotlinx/coroutines/flow/p0;->getValue()Ljava/lang/Object;
    .line 48: move-result-object v2
    .line 49: check-cast v2, Lu/e2;
    .line 51: sget-object v3, Lu/e2;->j:Lu/e2;
    .line 53: invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I
    .line 56: move-result v2
    .line 57: if-lez v2, :cond_60
    .line 59: goto :goto_62
    .line 60: move-object v2, v1
    .line 61: goto :goto_63
    .line 62: move-object v2, v0
    .line 63: if-eqz v2, :cond_74
    .line 65: new-instance v3, Ljava/lang/ref/WeakReference;
    .line 67: invoke-direct {v3, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 70: iput-object v3, v13, Landroidx/compose/ui/platform/a;->i:Ljava/lang/ref/WeakReference;
    .line 72: goto :goto_74
    .line 73: move-object v0, v1
    .line 74: if-nez v0, :cond_523
    .line 76: iget-object v0, v13, Landroidx/compose/ui/platform/a;->i:Ljava/lang/ref/WeakReference;
    .line 78: if-eqz v0, :cond_112
    .line 80: invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 83: move-result-object v0
    .line 84: check-cast v0, Lu/e0;
    .line 86: if-eqz v0, :cond_112
    .line 88: instance-of v2, v0, Lu/o2;
    .line 90: if-eqz v2, :cond_113
    .line 92: move-object v2, v0
    .line 93: check-cast v2, Lu/o2;
    .line 95: iget-object v2, v2, Lu/o2;->q:Lkotlinx/coroutines/flow/p0;
    .line 97: invoke-virtual {v2}, Lkotlinx/coroutines/flow/p0;->getValue()Ljava/lang/Object;
    .line 100: move-result-object v2
    .line 101: check-cast v2, Lu/e2;
    .line 103: sget-object v3, Lu/e2;->j:Lu/e2;
    .line 105: invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I
    .line 108: move-result v2
    .line 109: if-lez v2, :cond_112
    .line 111: goto :goto_113
    .line 112: move-object v0, v1
    .line 113: if-nez v0, :cond_523
    .line 115: invoke-virtual {v13}, Landroid/view/View;->isAttachedToWindow()Z
    .line 118: move-result v0
    .line 119: if-eqz v0, :cond_494
    .line 121: invoke-virtual {v13}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 124: move-result-object v0
    .line 125: move-object v8, v13
    .line 126: instance-of v2, v0, Landroid/view/View;
    .line 128: if-eqz v2, :cond_149
    .line 130: check-cast v0, Landroid/view/View;
    .line 132: invoke-virtual {v0}, Landroid/view/View;->getId()I
    .line 135: move-result v2
    .line 136: const v3, 0x1020002
    .line 139: if-ne v2, v3, :cond_142
    .line 141: goto :goto_149
    .line 142: invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 145: move-result-object v2
    .line 146: move-object v8, v0
    .line 147: move-object v0, v2
    .line 148: goto :goto_126
    .line 149: invoke-static {v8}, Landroidx/compose/ui/platform/g3;->b(Landroid/view/View;)Lu/e0;
    .line 152: move-result-object v0
    .line 153: if-nez v0, :cond_449
    .line 155: sget-object v0, Landroidx/compose/ui/platform/z2;->a:Ljava/util/concurrent/atomic/AtomicReference;
    .line 157: invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 160: move-result-object v0
    .line 161: check-cast v0, Landroidx/compose/ui/platform/x2;
    .line 163: check-cast v0, Landroidx/compose/ui/platform/w2;
    .line 165: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 168: sget-object v0, Lw2/k;->i:Lw2/k;
    .line 170: sget-object v2, Landroidx/compose/ui/platform/u0;->u:Ls2/h;
    .line 172: invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;
    .line 175: move-result-object v2
    .line 176: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    .line 179: move-result-object v3
    .line 180: if-ne v2, v3, :cond_191
    .line 182: sget-object v2, Landroidx/compose/ui/platform/u0;->u:Ls2/h;
    .line 184: invoke-virtual {v2}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 187: move-result-object v2
    .line 188: check-cast v2, Lw2/j;
    .line 190: goto :goto_201
    .line 191: sget-object v2, Landroidx/compose/ui/platform/u0;->v:Landroidx/compose/ui/platform/s0;
    .line 193: invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    .line 196: move-result-object v2
    .line 197: check-cast v2, Lw2/j;
    .line 199: if-eqz v2, :cond_437
    .line 201: invoke-interface {v2, v0}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 204: move-result-object v2
    .line 205: sget-object v3, Lu/k;->j:Lu/k;
    .line 207: invoke-interface {v2, v3}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 210: move-result-object v3
    .line 211: check-cast v3, Lu/g1;
    .line 213: const/4 v9, 0
    .line 214: if-eqz v3, :cond_233
    .line 216: new-instance v4, Lu/u1;
    .line 218: invoke-direct {v4, v3}, Lu/u1;-><init>(Lu/g1;)V
    .line 221: iget-object v3, v4, Lu/u1;->j:Lu/d1;
    .line 223: iget-object v5, v3, Lu/d1;->c:Ljava/lang/Object;
    .line 225: monitor-enter v5
    .line 226: iput-boolean v9, v3, Lu/d1;->b:Z
    .line 228: monitor-exit v5
    .line 229: goto :goto_234
    .line 230: move-exception v0
    .line 231: monitor-exit v5
    .line 232: throw v0
    .line 233: move-object v4, v1
    .line 234: new-instance v6, Le3/s;
    .line 236: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 239: sget-object v3, Lf0/a;->r:Lf0/a;
    .line 241: invoke-interface {v2, v3}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 244: move-result-object v3
    .line 245: check-cast v3, Lf0/q;
    .line 247: if-nez v3, :cond_256
    .line 249: new-instance v3, Landroidx/compose/ui/platform/w1;
    .line 251: invoke-direct {v3}, Landroidx/compose/ui/platform/w1;-><init>()V
    .line 254: iput-object v3, v6, Le3/s;->i:Ljava/lang/Object;
    .line 256: if-eqz v4, :cond_259
    .line 258: move-object v0, v4
    .line 259: invoke-interface {v2, v0}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 262: move-result-object v0
    .line 263: invoke-interface {v0, v3}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 266: move-result-object v0
    .line 267: new-instance v10, Lu/o2;
    .line 269: invoke-direct {v10, v0}, Lu/o2;-><init>(Lw2/j;)V
    .line 272: iget-object v2, v10, Lu/o2;->b:Ljava/lang/Object;
    .line 274: monitor-enter v2
    .line 275: const/4 v11, 1
    .line 276: iput-boolean v11, v10, Lu/o2;->p:Z
    .line 278: monitor-exit v2
    .line 279: invoke-static {v0}, Ld2/b;->c(Lw2/j;)Lkotlinx/coroutines/internal/d;
    .line 282: move-result-object v3
    .line 283: invoke-static {v8}, Ld2/c;->R(Landroid/view/View;)Landroidx/lifecycle/t;
    .line 286: move-result-object v0
    .line 287: if-eqz v0, :cond_294
    .line 289: invoke-interface {v0}, Landroidx/lifecycle/t;->getLifecycle()Landroidx/lifecycle/o;
    .line 292: move-result-object v0
    .line 293: goto :goto_295
    .line 294: move-object v0, v1
    .line 295: if-eqz v0, :cond_410
    .line 297: new-instance v2, Landroidx/compose/ui/platform/a3;
    .line 299: invoke-direct {v2, v8, v10}, Landroidx/compose/ui/platform/a3;-><init>(Landroid/view/View;Lu/o2;)V
    .line 302: invoke-virtual {v8, v2}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V
    .line 305: new-instance v12, Landroidx/compose/ui/platform/WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2;
    .line 307: move-object v2, v12
    .line 308: move-object v5, v10
    .line 309: move-object v7, v8
    .line 310: invoke-direct/range {v2 .. v7}, Landroidx/compose/ui/platform/WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2;-><init>(Lkotlinx/coroutines/internal/d;Lu/u1;Lu/o2;Le3/s;Landroid/view/View;)V
    .line 313: invoke-virtual {v0, v12}, Landroidx/lifecycle/o;->a(Landroidx/lifecycle/s;)V
    .line 316: const v0, 0x7f060026
    .line 319: invoke-virtual {v8, v0, v10}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 322: invoke-virtual {v8}, Landroid/view/View;->getHandler()Landroid/os/Handler;
    .line 325: move-result-object v0
    .line 326: const-string v2, "rootView.handler"
    .line 328: invoke-static {v0, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 331: const-string v2, "windowRecomposer cleanup"
    .line 333: sget v3, Lo3/g;->a:I
    .line 335: new-instance v3, Lo3/e;
    .line 337: invoke-direct {v3, v0, v2, v9}, Lo3/e;-><init>(Landroid/os/Handler;Ljava/lang/String;Z)V
    .line 340: iget-object v0, v3, Lo3/e;->n:Lo3/e;
    .line 342: new-instance v2, Landroidx/compose/ui/platform/y2;
    .line 344: invoke-direct {v2, v10, v8, v1}, Landroidx/compose/ui/platform/y2;-><init>(Lu/o2;Landroid/view/View;Lw2/e;)V
    .line 347: const/4 v3, 2
    .line 348: and-int/2addr v3, v11
    .line 349: if-eqz v3, :cond_353
    .line 351: sget-object v0, Lw2/k;->i:Lw2/k;
    .line 353: const/4 v3, 2
    .line 354: and-int v4, v3, v3
    .line 356: if-eqz v4, :cond_359
    .line 358: move v9, v11
    .line 359: sget-object v4, Lw2/k;->i:Lw2/k;
    .line 361: invoke-static {v4, v0, v11}, Ld2/b;->i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .line 364: move-result-object v0
    .line 365: sget-object v4, Ln3/h0;->a:Lkotlinx/coroutines/scheduling/d;
    .line 367: if-eq v0, v4, :cond_381
    .line 369: sget-object v5, Lw2/f;->i:Lw2/f;
    .line 371: invoke-interface {v0, v5}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 374: move-result-object v5
    .line 375: if-nez v5, :cond_381
    .line 377: invoke-interface {v0, v4}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 380: move-result-object v0
    .line 381: if-eqz v9, :cond_409
    .line 383: if-ne v9, v3, :cond_391
    .line 385: new-instance v4, Ln3/h1;
    .line 387: invoke-direct {v4, v0, v2}, Ln3/h1;-><init>(Lw2/j;Ld3/e;)V
    .line 390: goto :goto_396
    .line 391: new-instance v4, Ln3/o1;
    .line 393: invoke-direct {v4, v0, v11}, Ln3/a;-><init>(Lw2/j;Z)V
    .line 396: invoke-virtual {v4, v9, v4, v2}, Ln3/a;->b0(ILn3/a;Ld3/e;)V
    .line 399: new-instance v0, Landroidx/compose/ui/platform/x;
    .line 401: invoke-direct {v0, v3, v4}, Landroidx/compose/ui/platform/x;-><init>(ILjava/lang/Object;)V
    .line 404: invoke-virtual {v8, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V
    .line 407: move-object v0, v10
    .line 408: goto :goto_455
    .line 409: throw v1
    .line 410: new-instance v0, Ljava/lang/StringBuilder;
    .line 412: const-string v1, "ViewTreeLifecycleOwner not found from "
    .line 414: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 417: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 420: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 423: move-result-object v0
    .line 424: new-instance v1, Ljava/lang/IllegalStateException;
    .line 426: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 429: move-result-object v0
    .line 430: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 433: throw v1
    .line 434: move-exception v0
    .line 435: monitor-exit v2
    .line 436: throw v0
    .line 437: new-instance v0, Ljava/lang/IllegalStateException;
    .line 439: const-string v1, "no AndroidUiDispatcher for this thread"
    .line 441: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 444: move-result-object v1
    .line 445: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 448: throw v0
    .line 449: instance-of v2, v0, Lu/o2;
    .line 451: if-eqz v2, :cond_482
    .line 453: check-cast v0, Lu/o2;
    .line 455: iget-object v2, v0, Lu/o2;->q:Lkotlinx/coroutines/flow/p0;
    .line 457: invoke-virtual {v2}, Lkotlinx/coroutines/flow/p0;->getValue()Ljava/lang/Object;
    .line 460: move-result-object v2
    .line 461: check-cast v2, Lu/e2;
    .line 463: sget-object v3, Lu/e2;->j:Lu/e2;
    .line 465: invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I
    .line 468: move-result v2
    .line 469: if-lez v2, :cond_472
    .line 471: move-object v1, v0
    .line 472: if-eqz v1, :cond_523
    .line 474: new-instance v2, Ljava/lang/ref/WeakReference;
    .line 476: invoke-direct {v2, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 479: iput-object v2, v13, Landroidx/compose/ui/platform/a;->i:Ljava/lang/ref/WeakReference;
    .line 481: goto :goto_523
    .line 482: new-instance v0, Ljava/lang/IllegalStateException;
    .line 484: const-string v1, "root viewTreeParentCompositionContext is not a Recomposer"
    .line 486: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 489: move-result-object v1
    .line 490: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 493: throw v0
    .line 494: new-instance v0, Ljava/lang/StringBuilder;
    .line 496: const-string v1, "Cannot locate windowRecomposer; View "
    .line 498: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 501: invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 504: const-string v1, " is not attached to a window"
    .line 506: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 509: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 512: move-result-object v0
    .line 513: new-instance v1, Ljava/lang/IllegalStateException;
    .line 515: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 518: move-result-object v0
    .line 519: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 522: throw v1
    .line 523: return-object v0
.end method

# virtual methods
.method public final getHasComposition()Z
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/a;->k:Lu/d0;
    .line 2: if-eqz v0, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_7
    .line 6: const/4 v0, 0
    .line 7: return v0
.end method

# virtual methods
.method public getShouldCreateCompositionOnAttachedToWindow()Z
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: return v0
.end method

# virtual methods
.method public final getShowLayoutBounds()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Landroidx/compose/ui/platform/a;->n:Z
    .line 2: return v0
.end method

# virtual methods
.method public final isTransitionGroup()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Landroidx/compose/ui/platform/a;->p:Z
    .line 2: if-eqz v0, :cond_13
    .line 4: invoke-super {v1}, Landroid/view/ViewGroup;->isTransitionGroup()Z
    .line 7: move-result v0
    .line 8: if-eqz v0, :cond_11
    .line 10: goto :goto_13
    .line 11: const/4 v0, 0
    .line 12: goto :goto_14
    .line 13: const/4 v0, 1
    .line 14: return v0
.end method

# virtual methods
.method public final onAttachedToWindow()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/view/ViewGroup;->onAttachedToWindow()V
    .line 3: invoke-virtual {v1}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;
    .line 6: move-result-object v0
    .line 7: invoke-direct {v1, v0}, Landroidx/compose/ui/platform/a;->setPreviousAttachedWindowToken(Landroid/os/IBinder;)V
    .line 10: invoke-virtual {v1}, Landroidx/compose/ui/platform/a;->getShouldCreateCompositionOnAttachedToWindow()Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_19
    .line 16: invoke-virtual {v1}, Landroidx/compose/ui/platform/a;->d()V
    .line 19: return-void
.end method

# virtual methods
.method public final onLayout(ZIIII)V
    .registers 12

    .line 0: move-object v0, v6
    .line 1: move v1, v8
    .line 2: move v2, v9
    .line 3: move v3, v10
    .line 4: move v4, v11
    .line 5: move v5, v7
    .line 6: invoke-virtual/range {v0 .. v5}, Landroidx/compose/ui/platform/a;->e(IIIIZ)V
    .line 9: return-void
.end method

# virtual methods
.method public final onMeasure(II)V
    .registers 3

    .line 0: invoke-virtual {v0}, Landroidx/compose/ui/platform/a;->d()V
    .line 3: invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/a;->f(II)V
    .line 6: return-void
.end method

# virtual methods
.method public final onRtlPropertiesChanged(I)V
    .registers 3

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 4: move-result-object v0
    .line 5: if-nez v0, :cond_8
    .line 7: goto :goto_11
    .line 8: invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutDirection(I)V
    .line 11: return-void
.end method

# virtual methods
.method public final setParentCompositionContext(Lu/e0;)V
    .registers 2

    .line 0: invoke-direct {v0, v1}, Landroidx/compose/ui/platform/a;->setParentContext(Lu/e0;)V
    .line 3: return-void
.end method

# virtual methods
.method public final setShowLayoutBounds(Z)V
    .registers 3

    .line 0: iput-boolean v2, v1, Landroidx/compose/ui/platform/a;->n:Z
    .line 2: const/4 v0, 0
    .line 3: invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 6: move-result-object v0
    .line 7: if-eqz v0, :cond_14
    .line 9: check-cast v0, Lz0/j1;
    .line 11: invoke-interface {v0, v2}, Lz0/j1;->setShowLayoutBounds(Z)V
    .line 14: return-void
.end method

# virtual methods
.method public setTransitionGroup(Z)V
    .registers 2

    .line 0: invoke-super {v0, v1}, Landroid/view/ViewGroup;->setTransitionGroup(Z)V
    .line 3: const/4 v1, 1
    .line 4: iput-boolean v1, v0, Landroidx/compose/ui/platform/a;->p:Z
    .line 6: return-void
.end method

# virtual methods
.method public final setViewCompositionStrategy(Landroidx/compose/ui/platform/l2;)V
    .registers 5

    .line 0: const-string v0, "strategy"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v4, v3, Landroidx/compose/ui/platform/a;->m:Li/q1;
    .line 7: if-eqz v4, :cond_12
    .line 9: invoke-virtual {v4}, Li/q1;->s()Ljava/lang/Object;
    .line 12: new-instance v4, Landroidx/compose/ui/platform/x;
    .line 14: const/4 v0, 1
    .line 15: invoke-direct {v4, v0, v3}, Landroidx/compose/ui/platform/x;-><init>(ILjava/lang/Object;)V
    .line 18: invoke-virtual {v3, v4}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V
    .line 21: new-instance v0, Landroidx/compose/ui/platform/r1;
    .line 23: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 26: invoke-static {v3}, Ld2/c;->X(Landroid/view/View;)Lh2/a;
    .line 29: move-result-object v1
    .line 30: iget-object v1, v1, Lh2/a;->a:Ljava/util/ArrayList;
    .line 32: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 35: new-instance v1, Li/q1;
    .line 37: const/4 v2, 2
    .line 38: invoke-direct {v1, v3, v4, v0, v2}, Li/q1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .line 41: iput-object v1, v3, Landroidx/compose/ui/platform/a;->m:Li/q1;
    .line 43: return-void
.end method

# virtual methods
.method public final shouldDelayChildPressedState()Z
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

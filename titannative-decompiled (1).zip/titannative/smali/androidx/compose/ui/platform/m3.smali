.class public abstract Landroidx/compose/ui/platform/m3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroid/view/ViewGroup$LayoutParams;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Landroid/view/ViewGroup$LayoutParams;
    .line 2: const/4 v1, -2
    .line 3: invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V
    .line 6: sput-object v0, Landroidx/compose/ui/platform/m3;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 8: return-void
.end method

# direct methods
.method public static final a(Landroidx/compose/ui/platform/a;Lu/e0;Lb0/c;)Lu/d0;
    .registers 10

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Landroidx/compose/ui/platform/q1;->a:Ljava/util/concurrent/atomic/AtomicBoolean;
    .line 7: const/4 v1, 0
    .line 8: const/4 v2, 1
    .line 9: invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z
    .line 12: move-result v0
    .line 13: const/4 v3, 0
    .line 14: if-eqz v0, :cond_66
    .line 16: const/4 v0, -1
    .line 17: const/4 v4, 6
    .line 18: invoke-static {v0, v3, v4}, Ld2/b;->b(ILp3/m;I)Lp3/h;
    .line 21: move-result-object v0
    .line 22: sget-object v4, Landroidx/compose/ui/platform/u0;->u:Ls2/h;
    .line 24: invoke-virtual {v4}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 27: move-result-object v4
    .line 28: check-cast v4, Lw2/j;
    .line 30: invoke-static {v4}, Ld2/b;->c(Lw2/j;)Lkotlinx/coroutines/internal/d;
    .line 33: move-result-object v4
    .line 34: new-instance v5, Landroidx/compose/ui/platform/p1;
    .line 36: invoke-direct {v5, v0, v3}, Landroidx/compose/ui/platform/p1;-><init>(Lp3/o;Lw2/e;)V
    .line 39: const/4 v6, 3
    .line 40: invoke-static {v4, v3, v1, v5, v6}, Ld2/b;->E0(Ln3/z;Ln3/u;ILd3/e;I)Ln3/o1;
    .line 43: new-instance v4, Lg/n;
    .line 45: const/16 v5, 28
    .line 47: invoke-direct {v4, v5, v0}, Lg/n;-><init>(ILjava/lang/Object;)V
    .line 50: sget-object v0, Ld0/p;->b:Ljava/lang/Object;
    .line 52: monitor-enter v0
    .line 53: sget-object v5, Ld0/p;->h:Ljava/util/ArrayList;
    .line 55: invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 58: monitor-exit v0
    .line 59: invoke-static {}, Ld0/p;->a()V
    .line 62: goto :goto_66
    .line 63: move-exception v7
    .line 64: monitor-exit v0
    .line 65: throw v7
    .line 66: invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I
    .line 69: move-result v0
    .line 70: if-lez v0, :cond_85
    .line 72: invoke-virtual {v7, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 75: move-result-object v0
    .line 76: instance-of v1, v0, Landroidx/compose/ui/platform/AndroidComposeView;
    .line 78: if-eqz v1, :cond_83
    .line 80: check-cast v0, Landroidx/compose/ui/platform/AndroidComposeView;
    .line 82: goto :goto_89
    .line 83: move-object v0, v3
    .line 84: goto :goto_89
    .line 85: invoke-virtual {v7}, Landroid/view/ViewGroup;->removeAllViews()V
    .line 88: goto :goto_83
    .line 89: if-nez v0, :cond_118
    .line 91: new-instance v0, Landroidx/compose/ui/platform/AndroidComposeView;
    .line 93: invoke-virtual {v7}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 96: move-result-object v1
    .line 97: const-string v4, "context"
    .line 99: invoke-static {v1, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 102: invoke-virtual {v8}, Lu/e0;->f()Lw2/j;
    .line 105: move-result-object v4
    .line 106: invoke-direct {v0, v1, v4}, Landroidx/compose/ui/platform/AndroidComposeView;-><init>(Landroid/content/Context;Lw2/j;)V
    .line 109: invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getView()Landroid/view/View;
    .line 112: move-result-object v1
    .line 113: sget-object v4, Landroidx/compose/ui/platform/m3;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 115: invoke-virtual {v7, v1, v4}, Landroidx/compose/ui/platform/a;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 118: sget v7, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 120: const/16 v1, 29
    .line 122: if-lt v7, v1, :cond_174
    .line 124: sget-object v7, Landroidx/compose/ui/platform/l3;->a:Landroidx/compose/ui/platform/l3;
    .line 126: invoke-virtual {v7, v0}, Landroidx/compose/ui/platform/l3;->a(Landroid/view/View;)Ljava/util/Map;
    .line 129: move-result-object v7
    .line 130: invoke-interface {v7}, Ljava/util/Map;->isEmpty()Z
    .line 133: move-result v7
    .line 134: xor-int/2addr v7, v2
    .line 135: if-eqz v7, :cond_174
    .line 137: new-instance v7, Ljava/util/WeakHashMap;
    .line 139: invoke-direct {v7}, Ljava/util/WeakHashMap;-><init>()V
    .line 142: invoke-static {v7}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;
    .line 145: move-result-object v7
    .line 146: const v1, 0x7f060034
    .line 149: invoke-virtual {v0, v1, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 152: const-class v7, Landroidx/compose/ui/platform/u1;
    .line 154: const-string v1, "a"
    .line 156: invoke-virtual {v7, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    .line 159: move-result-object v7
    .line 160: invoke-virtual {v7, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    .line 163: invoke-virtual {v7, v3, v2}, Ljava/lang/reflect/Field;->setBoolean(Ljava/lang/Object;Z)V
    .line 166: goto :goto_174
    .line 167: const-string v7, "Wrapper"
    .line 169: const-string v1, "Could not access isDebugInspectorInfoEnabled. Please set explicitly."
    .line 171: invoke-static {v7, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    .line 174: new-instance v7, Lz0/s1;
    .line 176: invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/a;
    .line 179: move-result-object v1
    .line 180: const-string v2, "root"
    .line 182: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 185: invoke-direct {v7, v1}, Lu/a;-><init>(Ljava/lang/Object;)V
    .line 188: sget-object v1, Lu/i0;->a:Ljava/lang/Object;
    .line 190: new-instance v1, Lu/h0;
    .line 192: invoke-direct {v1, v8, v7}, Lu/h0;-><init>(Lu/e0;Lu/a;)V
    .line 195: invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getView()Landroid/view/View;
    .line 198: move-result-object v7
    .line 199: const v8, 0x7f060056
    .line 202: invoke-virtual {v7, v8}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 205: move-result-object v7
    .line 206: instance-of v2, v7, Landroidx/compose/ui/platform/WrappedComposition;
    .line 208: if-eqz v2, :cond_213
    .line 210: move-object v3, v7
    .line 211: check-cast v3, Landroidx/compose/ui/platform/WrappedComposition;
    .line 213: if-nez v3, :cond_227
    .line 215: new-instance v3, Landroidx/compose/ui/platform/WrappedComposition;
    .line 217: invoke-direct {v3, v0, v1}, Landroidx/compose/ui/platform/WrappedComposition;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;Lu/h0;)V
    .line 220: invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getView()Landroid/view/View;
    .line 223: move-result-object v7
    .line 224: invoke-virtual {v7, v8, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 227: invoke-virtual {v3, v9}, Landroidx/compose/ui/platform/WrappedComposition;->c(Ld3/e;)V
    .line 230: return-object v3
.end method

.class public abstract synthetic Landroidx/compose/ui/platform/b3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:[I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Landroidx/lifecycle/m;->values()[Landroidx/lifecycle/m;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sget-object v1, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;
    .line 9: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 12: move-result v1
    .line 13: const/4 v2, 1
    .line 14: aput v2, v0, v1
    .line 16: sget-object v1, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 18: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 21: move-result v1
    .line 22: const/4 v2, 2
    .line 23: aput v2, v0, v1
    .line 25: sget-object v1, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;
    .line 27: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 30: move-result v1
    .line 31: const/4 v2, 3
    .line 32: aput v2, v0, v1
    .line 34: sget-object v1, Landroidx/lifecycle/m;->ON_DESTROY:Landroidx/lifecycle/m;
    .line 36: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 39: move-result v1
    .line 40: const/4 v2, 4
    .line 41: aput v2, v0, v1
    .line 43: sget-object v1, Landroidx/lifecycle/m;->ON_PAUSE:Landroidx/lifecycle/m;
    .line 45: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 48: move-result v1
    .line 49: const/4 v2, 5
    .line 50: aput v2, v0, v1
    .line 52: sget-object v1, Landroidx/lifecycle/m;->ON_RESUME:Landroidx/lifecycle/m;
    .line 54: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 57: move-result v1
    .line 58: const/4 v2, 6
    .line 59: aput v2, v0, v1
    .line 61: sget-object v1, Landroidx/lifecycle/m;->ON_ANY:Landroidx/lifecycle/m;
    .line 63: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 66: move-result v1
    .line 67: const/4 v2, 7
    .line 68: aput v2, v0, v1
    .line 70: sput-object v0, Landroidx/compose/ui/platform/b3;->a:[I
    .line 72: return-void
.end method

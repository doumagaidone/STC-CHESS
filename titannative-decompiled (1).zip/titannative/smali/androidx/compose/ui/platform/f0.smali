.class public final Landroidx/compose/ui/platform/f0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Comparator;

.field public final synthetic a:Ljava/util/Comparator;
.field public final synthetic b:Ljava/util/Comparator;

# direct methods
.method public constructor <init>(Lv2/a;Lz0/c0;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/f0;->a:Ljava/util/Comparator;
    .line 5: iput-object v2, v0, Landroidx/compose/ui/platform/f0;->b:Ljava/util/Comparator;
    .line 7: return-void
.end method

# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/f0;->a:Ljava/util/Comparator;
    .line 2: invoke-interface {v0, v2, v3}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_9
    .line 8: goto :goto_23
    .line 9: check-cast v2, Ld1/n;
    .line 11: iget-object v2, v2, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 13: check-cast v3, Ld1/n;
    .line 15: iget-object v3, v3, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 17: iget-object v0, v1, Landroidx/compose/ui/platform/f0;->b:Ljava/util/Comparator;
    .line 19: invoke-interface {v0, v2, v3}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .line 22: move-result v0
    .line 23: return v0
.end method

.class public abstract Landroidx/compose/ui/platform/n1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final c:[Ljava/lang/Class;

# direct methods
.method static synthetic constructor <clinit>()V
    .registers 3

    .line 0: const/4 v0, 7
    .line 1: new-array v0, v0, [Ljava/lang/Class;
    .line 3: const/4 v1, 0
    .line 4: const-class v2, Ljava/io/Serializable;
    .line 6: aput-object v2, v0, v1
    .line 8: const/4 v1, 1
    .line 9: const-class v2, Landroid/os/Parcelable;
    .line 11: aput-object v2, v0, v1
    .line 13: const/4 v1, 2
    .line 14: const-class v2, Ljava/lang/String;
    .line 16: aput-object v2, v0, v1
    .line 18: const/4 v1, 3
    .line 19: const-class v2, Landroid/util/SparseArray;
    .line 21: aput-object v2, v0, v1
    .line 23: const/4 v1, 4
    .line 24: const-class v2, Landroid/os/Binder;
    .line 26: aput-object v2, v0, v1
    .line 28: const/4 v1, 5
    .line 29: const-class v2, Landroid/util/Size;
    .line 31: aput-object v2, v0, v1
    .line 33: const/4 v1, 6
    .line 34: const-class v2, Landroid/util/SizeF;
    .line 36: aput-object v2, v0, v1
    .line 38: sput-object v0, Landroidx/compose/ui/platform/n1;->c:[Ljava/lang/Class;
    .line 40: return-void
.end method

# direct methods
.method public static final k(Ld1/n;)Z
    .registers 2

    .line 0: invoke-virtual {v1}, Ld1/n;->h()Ld1/i;
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ld1/q;->i:Ld1/t;
    .line 6: invoke-static {v1, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 9: move-result-object v1
    .line 10: if-nez v1, :cond_14
    .line 12: const/4 v1, 1
    .line 13: goto :goto_15
    .line 14: const/4 v1, 0
    .line 15: return v1
.end method

# direct methods
.method public static final l(Ld1/n;)Z
    .registers 2

    .line 0: iget-object v1, v1, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 2: iget-object v1, v1, Landroidx/compose/ui/node/a;->z:Lr1/j;
    .line 4: sget-object v0, Lr1/j;->j:Lr1/j;
    .line 6: if-ne v1, v0, :cond_10
    .line 8: const/4 v1, 1
    .line 9: goto :goto_11
    .line 10: const/4 v1, 0
    .line 11: return v1
.end method

# direct methods
.method public static final m([F[F)V
    .registers 23

    .line 0: move-object/from16 v0, v21
    .line 2: move-object/from16 v1, v22
    .line 4: const/4 v2, 0
    .line 5: invoke-static {v1, v2, v0, v2}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 8: move-result v3
    .line 9: const/4 v4, 1
    .line 10: invoke-static {v1, v2, v0, v4}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 13: move-result v5
    .line 14: const/4 v6, 2
    .line 15: invoke-static {v1, v2, v0, v6}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 18: move-result v7
    .line 19: const/4 v8, 3
    .line 20: invoke-static {v1, v2, v0, v8}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 23: move-result v9
    .line 24: invoke-static {v1, v4, v0, v2}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 27: move-result v10
    .line 28: invoke-static {v1, v4, v0, v4}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 31: move-result v11
    .line 32: invoke-static {v1, v4, v0, v6}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 35: move-result v12
    .line 36: invoke-static {v1, v4, v0, v8}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 39: move-result v13
    .line 40: invoke-static {v1, v6, v0, v2}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 43: move-result v14
    .line 44: invoke-static {v1, v6, v0, v4}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 47: move-result v15
    .line 48: invoke-static {v1, v6, v0, v6}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 51: move-result v16
    .line 52: invoke-static {v1, v6, v0, v8}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 55: move-result v17
    .line 56: invoke-static {v1, v8, v0, v2}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 59: move-result v18
    .line 60: invoke-static {v1, v8, v0, v4}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 63: move-result v19
    .line 64: invoke-static {v1, v8, v0, v6}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 67: move-result v20
    .line 68: invoke-static {v1, v8, v0, v8}, Landroidx/compose/ui/platform/n1;->p([FI[FI)F
    .line 71: move-result v1
    .line 72: aput v3, v0, v2
    .line 74: aput v5, v0, v4
    .line 76: aput v7, v0, v6
    .line 78: aput v9, v0, v8
    .line 80: const/4 v2, 4
    .line 81: aput v10, v0, v2
    .line 83: const/4 v2, 5
    .line 84: aput v11, v0, v2
    .line 86: const/4 v2, 6
    .line 87: aput v12, v0, v2
    .line 89: const/4 v2, 7
    .line 90: aput v13, v0, v2
    .line 92: const/16 v2, 8
    .line 94: aput v14, v0, v2
    .line 96: const/16 v2, 9
    .line 98: aput v15, v0, v2
    .line 100: const/16 v2, 10
    .line 102: aput v16, v0, v2
    .line 104: const/16 v2, 11
    .line 106: aput v17, v0, v2
    .line 108: const/16 v2, 12
    .line 110: aput v18, v0, v2
    .line 112: const/16 v2, 13
    .line 114: aput v19, v0, v2
    .line 116: const/16 v2, 14
    .line 118: aput v20, v0, v2
    .line 120: const/16 v2, 15
    .line 122: aput v1, v0, v2
    .line 124: return-void
.end method

# direct methods
.method public static final n(I)Ljava/lang/String;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: const-string v1, "android.widget.Button"
    .line 9: goto :goto_51
    .line 10: const/4 v0, 1
    .line 11: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: const-string v1, "android.widget.CheckBox"
    .line 19: goto :goto_51
    .line 20: const/4 v0, 3
    .line 21: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_30
    .line 27: const-string v1, "android.widget.RadioButton"
    .line 29: goto :goto_51
    .line 30: const/4 v0, 5
    .line 31: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 34: move-result v0
    .line 35: if-eqz v0, :cond_40
    .line 37: const-string v1, "android.widget.ImageView"
    .line 39: goto :goto_51
    .line 40: const/4 v0, 6
    .line 41: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 44: move-result v1
    .line 45: if-eqz v1, :cond_50
    .line 47: const-string v1, "android.widget.Spinner"
    .line 49: goto :goto_51
    .line 50: const/4 v1, 0
    .line 51: return-object v1
.end method

# direct methods
.method public static final o(Ljava/lang/Object;)Z
    .registers 6

    .line 0: instance-of v0, v5, Ld0/s;
    .line 2: const/4 v1, 1
    .line 3: const/4 v2, 0
    .line 4: if-eqz v0, :cond_46
    .line 6: check-cast v5, Ld0/s;
    .line 8: invoke-interface {v5}, Ld0/s;->a()Lu/f3;
    .line 11: move-result-object v0
    .line 12: sget-object v3, Lu/m1;->a:Lu/m1;
    .line 14: if-eq v0, v3, :cond_34
    .line 16: invoke-interface {v5}, Ld0/s;->a()Lu/f3;
    .line 19: move-result-object v0
    .line 20: sget-object v3, Lu/l3;->a:Lu/l3;
    .line 22: if-eq v0, v3, :cond_34
    .line 24: invoke-interface {v5}, Ld0/s;->a()Lu/f3;
    .line 27: move-result-object v0
    .line 28: sget-object v3, Lu/p2;->a:Lu/p2;
    .line 30: if-ne v0, v3, :cond_33
    .line 32: goto :goto_34
    .line 33: return v2
    .line 34: invoke-interface {v5}, Lu/i3;->getValue()Ljava/lang/Object;
    .line 37: move-result-object v5
    .line 38: if-nez v5, :cond_41
    .line 40: goto :goto_45
    .line 41: invoke-static {v5}, Landroidx/compose/ui/platform/n1;->o(Ljava/lang/Object;)Z
    .line 44: move-result v1
    .line 45: return v1
    .line 46: instance-of v0, v5, Ls2/a;
    .line 48: if-eqz v0, :cond_55
    .line 50: instance-of v0, v5, Ljava/io/Serializable;
    .line 52: if-eqz v0, :cond_55
    .line 54: return v2
    .line 55: sget-object v0, Landroidx/compose/ui/platform/n1;->c:[Ljava/lang/Class;
    .line 57: move v3, v2
    .line 58: const/4 v4, 7
    .line 59: if-ge v3, v4, :cond_73
    .line 61: aget-object v4, v0, v3
    .line 63: invoke-virtual {v4, v5}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 66: move-result v4
    .line 67: if-eqz v4, :cond_70
    .line 69: return v1
    .line 70: add-int/lit8 v3, v3, 1
    .line 72: goto :goto_58
    .line 73: return v2
.end method

# direct methods
.method public static final p([FI[FI)F
    .registers 7

    .line 0: const/4 v0, 4
    .line 1: mul-int/2addr v4, v0
    .line 2: aget v1, v3, v4
    .line 4: aget v2, v5, v6
    .line 6: mul-float/2addr v1, v2
    .line 7: add-int/lit8 v2, v4, 1
    .line 9: aget v2, v3, v2
    .line 11: add-int/2addr v0, v6
    .line 12: aget v0, v5, v0
    .line 14: mul-float/2addr v2, v0
    .line 15: add-float/2addr v2, v1
    .line 16: add-int/lit8 v0, v4, 2
    .line 18: aget v0, v3, v0
    .line 20: const/16 v1, 8
    .line 22: add-int/2addr v1, v6
    .line 23: aget v1, v5, v1
    .line 25: mul-float/2addr v0, v1
    .line 26: add-float/2addr v0, v2
    .line 27: add-int/lit8 v4, v4, 3
    .line 29: aget v3, v3, v4
    .line 31: const/16 v4, 12
    .line 33: add-int/2addr v4, v6
    .line 34: aget v4, v5, v4
    .line 36: mul-float/2addr v3, v4
    .line 37: add-float/2addr v3, v0
    .line 38: return v3
.end method

# direct methods
.method public static final q(ILjava/util/ArrayList;)Landroidx/compose/ui/platform/g2;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    .line 8: move-result v0
    .line 9: const/4 v1, 0
    .line 10: if-ge v1, v0, :cond_32
    .line 12: invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 15: move-result-object v2
    .line 16: check-cast v2, Landroidx/compose/ui/platform/g2;
    .line 18: iget v2, v2, Landroidx/compose/ui/platform/g2;->i:I
    .line 20: if-ne v2, v3, :cond_29
    .line 22: invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 25: move-result-object v3
    .line 26: check-cast v3, Landroidx/compose/ui/platform/g2;
    .line 28: return-object v3
    .line 29: add-int/lit8 v1, v1, 1
    .line 31: goto :goto_10
    .line 32: const/4 v3, 0
    .line 33: return-object v3
.end method

# direct methods
.method public static final r(Landroidx/compose/ui/node/a;Landroidx/compose/ui/platform/s;)Landroidx/compose/ui/node/a;
    .registers 3

    .line 0: invoke-virtual {v1}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 3: move-result-object v1
    .line 4: if-eqz v1, :cond_24
    .line 6: invoke-virtual {v2, v1}, Landroidx/compose/ui/platform/s;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v0
    .line 10: check-cast v0, Ljava/lang/Boolean;
    .line 12: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 15: move-result v0
    .line 16: if-eqz v0, :cond_19
    .line 18: return-object v1
    .line 19: invoke-virtual {v1}, Landroidx/compose/ui/node/a;->o()Landroidx/compose/ui/node/a;
    .line 22: move-result-object v1
    .line 23: goto :goto_4
    .line 24: const/4 v1, 0
    .line 25: return-object v1
.end method

# direct methods
.method public static final s(Landroid/graphics/Region;Ld1/n;Ljava/util/LinkedHashMap;Ld1/n;)V
    .registers 21

    .line 0: move-object/from16 v0, v17
    .line 2: move-object/from16 v1, v18
    .line 4: move-object/from16 v2, v19
    .line 6: move-object/from16 v3, v20
    .line 8: iget-object v4, v3, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 10: invoke-virtual {v4}, Landroidx/compose/ui/node/a;->y()Z
    .line 13: move-result v4
    .line 14: const/4 v5, 1
    .line 15: const/4 v6, 0
    .line 16: iget-object v7, v3, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 18: if-eqz v4, :cond_29
    .line 20: invoke-virtual {v7}, Landroidx/compose/ui/node/a;->x()Z
    .line 23: move-result v4
    .line 24: if-nez v4, :cond_27
    .line 26: goto :goto_29
    .line 27: move v4, v6
    .line 28: goto :goto_30
    .line 29: move v4, v5
    .line 30: invoke-virtual/range {v17 .. v17}, Landroid/graphics/Region;->isEmpty()Z
    .line 33: move-result v8
    .line 34: iget v9, v1, Ld1/n;->g:I
    .line 36: iget v10, v3, Ld1/n;->g:I
    .line 38: if-eqz v8, :cond_42
    .line 40: if-ne v10, v9, :cond_48
    .line 42: if-eqz v4, :cond_49
    .line 44: iget-boolean v4, v3, Ld1/n;->e:Z
    .line 46: if-nez v4, :cond_49
    .line 48: return-void
    .line 49: iget-object v4, v3, Ld1/n;->d:Ld1/i;
    .line 51: iget-boolean v8, v4, Ld1/i;->j:Z
    .line 53: iget-object v11, v3, Ld1/n;->a:Lf0/o;
    .line 55: if-eqz v8, :cond_64
    .line 57: invoke-static {v7}, Ll0/j;->p(Landroidx/compose/ui/node/a;)Lz0/p1;
    .line 60: move-result-object v7
    .line 61: if-eqz v7, :cond_64
    .line 63: move-object v11, v7
    .line 64: check-cast v11, Lf0/o;
    .line 66: iget-object v7, v11, Lf0/o;->i:Lf0/o;
    .line 68: sget-object v8, Ld1/h;->b:Ld1/t;
    .line 70: invoke-static {v4, v8}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 73: move-result-object v4
    .line 74: if-eqz v4, :cond_78
    .line 76: move v4, v5
    .line 77: goto :goto_79
    .line 78: move v4, v6
    .line 79: const-string v8, "<this>"
    .line 81: invoke-static {v7, v8}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 84: iget-object v8, v7, Lf0/o;->i:Lf0/o;
    .line 86: iget-boolean v8, v8, Lf0/o;->u:Z
    .line 88: sget-object v11, Lj0/d;->e:Lj0/d;
    .line 90: const/4 v12, 0
    .line 91: if-nez v8, :cond_95
    .line 93: goto/16 :goto_224
    .line 95: const/16 v8, 8
    .line 97: if-nez v4, :cond_112
    .line 99: invoke-static {v7, v8}, Lz0/h;->w(Lz0/o;I)Lz0/a1;
    .line 102: move-result-object v4
    .line 103: invoke-static {v4}, Landroidx/compose/ui/layout/a;->d(Lx0/q;)Lx0/q;
    .line 106: move-result-object v7
    .line 107: invoke-interface {v7, v4, v5}, Lx0/q;->D(Lx0/q;Z)Lj0/d;
    .line 110: move-result-object v11
    .line 111: goto :goto_224
    .line 112: invoke-static {v7, v8}, Lz0/h;->w(Lz0/o;I)Lz0/a1;
    .line 115: move-result-object v4
    .line 116: invoke-virtual {v4}, Lz0/a1;->H()Z
    .line 119: move-result v7
    .line 120: if-nez v7, :cond_123
    .line 122: goto :goto_224
    .line 123: invoke-static {v4}, Landroidx/compose/ui/layout/a;->d(Lx0/q;)Lx0/q;
    .line 126: move-result-object v7
    .line 127: iget-object v8, v4, Lz0/a1;->C:Lj0/b;
    .line 129: if-nez v8, :cond_146
    .line 131: new-instance v8, Lj0/b;
    .line 133: invoke-direct {v8}, Ljava/lang/Object;-><init>()V
    .line 136: iput v12, v8, Lj0/b;->a:F
    .line 138: iput v12, v8, Lj0/b;->b:F
    .line 140: iput v12, v8, Lj0/b;->c:F
    .line 142: iput v12, v8, Lj0/b;->d:F
    .line 144: iput-object v8, v4, Lz0/a1;->C:Lj0/b;
    .line 146: invoke-virtual {v4}, Lz0/a1;->J0()J
    .line 149: move-result-wide v13
    .line 150: invoke-virtual {v4, v13, v14}, Lz0/a1;->A0(J)J
    .line 153: move-result-wide v13
    .line 154: invoke-static {v13, v14}, Lj0/f;->d(J)F
    .line 157: move-result v15
    .line 158: neg-float v15, v15
    .line 159: iput v15, v8, Lj0/b;->a:F
    .line 161: invoke-static {v13, v14}, Lj0/f;->b(J)F
    .line 164: move-result v15
    .line 165: neg-float v15, v15
    .line 166: iput v15, v8, Lj0/b;->b:F
    .line 168: invoke-virtual {v4}, Lx0/l0;->d0()I
    .line 171: move-result v15
    .line 172: int-to-float v15, v15
    .line 173: invoke-static {v13, v14}, Lj0/f;->d(J)F
    .line 176: move-result v16
    .line 177: add-float v15, v16, v15
    .line 179: iput v15, v8, Lj0/b;->c:F
    .line 181: invoke-virtual {v4}, Lx0/l0;->Z()I
    .line 184: move-result v15
    .line 185: int-to-float v15, v15
    .line 186: invoke-static {v13, v14}, Lj0/f;->b(J)F
    .line 189: move-result v13
    .line 190: add-float/2addr v13, v15
    .line 191: iput v13, v8, Lj0/b;->d:F
    .line 193: if-eq v4, v7, :cond_211
    .line 195: invoke-virtual {v4, v8, v6, v5}, Lz0/a1;->W0(Lj0/b;ZZ)V
    .line 198: invoke-virtual {v8}, Lj0/b;->b()Z
    .line 201: move-result v13
    .line 202: if-eqz v13, :cond_205
    .line 204: goto :goto_224
    .line 205: iget-object v4, v4, Lz0/a1;->r:Lz0/a1;
    .line 207: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 210: goto :goto_193
    .line 211: new-instance v11, Lj0/d;
    .line 213: iget v4, v8, Lj0/b;->a:F
    .line 215: iget v7, v8, Lj0/b;->b:F
    .line 217: iget v13, v8, Lj0/b;->c:F
    .line 219: iget v8, v8, Lj0/b;->d:F
    .line 221: invoke-direct {v11, v4, v7, v13, v8}, Lj0/d;-><init>(FFFF)V
    .line 224: new-instance v4, Landroid/graphics/Rect;
    .line 226: iget v7, v11, Lj0/d;->a:F
    .line 228: invoke-static {v7}, Ld2/b;->a1(F)I
    .line 231: move-result v7
    .line 232: iget v8, v11, Lj0/d;->b:F
    .line 234: invoke-static {v8}, Ld2/b;->a1(F)I
    .line 237: move-result v8
    .line 238: iget v13, v11, Lj0/d;->c:F
    .line 240: invoke-static {v13}, Ld2/b;->a1(F)I
    .line 243: move-result v13
    .line 244: iget v11, v11, Lj0/d;->d:F
    .line 246: invoke-static {v11}, Ld2/b;->a1(F)I
    .line 249: move-result v11
    .line 250: invoke-direct {v4, v7, v8, v13, v11}, Landroid/graphics/Rect;-><init>(IIII)V
    .line 253: new-instance v7, Landroid/graphics/Region;
    .line 255: invoke-direct {v7}, Landroid/graphics/Region;-><init>()V
    .line 258: invoke-virtual {v7, v4}, Landroid/graphics/Region;->set(Landroid/graphics/Rect;)Z
    .line 261: const/4 v8, -1
    .line 262: if-ne v10, v9, :cond_265
    .line 264: move v10, v8
    .line 265: sget-object v9, Landroid/graphics/Region$Op;->INTERSECT:Landroid/graphics/Region$Op;
    .line 267: invoke-virtual {v7, v0, v7, v9}, Landroid/graphics/Region;->op(Landroid/graphics/Region;Landroid/graphics/Region;Landroid/graphics/Region$Op;)Z
    .line 270: move-result v9
    .line 271: const-string v11, "region.bounds"
    .line 273: if-eqz v9, :cond_323
    .line 275: invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 278: move-result-object v9
    .line 279: new-instance v10, Landroidx/compose/ui/platform/h2;
    .line 281: invoke-virtual {v7}, Landroid/graphics/Region;->getBounds()Landroid/graphics/Rect;
    .line 284: move-result-object v7
    .line 285: invoke-static {v7, v11}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 288: invoke-direct {v10, v3, v7}, Landroidx/compose/ui/platform/h2;-><init>(Ld1/n;Landroid/graphics/Rect;)V
    .line 291: invoke-interface {v2, v9, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 294: invoke-virtual {v3, v6, v5}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 297: move-result-object v3
    .line 298: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 301: move-result v6
    .line 302: sub-int/2addr v6, v5
    .line 303: if-ge v8, v6, :cond_317
    .line 305: invoke-interface {v3, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 308: move-result-object v5
    .line 309: check-cast v5, Ld1/n;
    .line 311: invoke-static {v0, v1, v2, v5}, Landroidx/compose/ui/platform/n1;->s(Landroid/graphics/Region;Ld1/n;Ljava/util/LinkedHashMap;Ld1/n;)V
    .line 314: add-int/lit8 v6, v6, -1
    .line 316: goto :goto_303
    .line 317: sget-object v1, Landroid/graphics/Region$Op;->REVERSE_DIFFERENCE:Landroid/graphics/Region$Op;
    .line 319: invoke-virtual {v0, v4, v0, v1}, Landroid/graphics/Region;->op(Landroid/graphics/Rect;Landroid/graphics/Region;Landroid/graphics/Region$Op;)Z
    .line 322: goto :goto_418
    .line 323: iget-boolean v0, v3, Ld1/n;->e:Z
    .line 325: if-eqz v0, :cond_397
    .line 327: invoke-virtual/range {v20 .. v20}, Ld1/n;->i()Ld1/n;
    .line 330: move-result-object v0
    .line 331: if-eqz v0, :cond_348
    .line 333: iget-object v1, v0, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 335: if-eqz v1, :cond_348
    .line 337: invoke-virtual {v1}, Landroidx/compose/ui/node/a;->y()Z
    .line 340: move-result v1
    .line 341: if-ne v1, v5, :cond_348
    .line 343: invoke-virtual {v0}, Ld1/n;->e()Lj0/d;
    .line 346: move-result-object v0
    .line 347: goto :goto_355
    .line 348: new-instance v0, Lj0/d;
    .line 350: const/high16 v1, 0x4120
    .line 352: invoke-direct {v0, v12, v12, v1, v1}, Lj0/d;-><init>(FFFF)V
    .line 355: invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 358: move-result-object v1
    .line 359: new-instance v4, Landroidx/compose/ui/platform/h2;
    .line 361: new-instance v5, Landroid/graphics/Rect;
    .line 363: iget v6, v0, Lj0/d;->a:F
    .line 365: invoke-static {v6}, Ld2/b;->a1(F)I
    .line 368: move-result v6
    .line 369: iget v7, v0, Lj0/d;->b:F
    .line 371: invoke-static {v7}, Ld2/b;->a1(F)I
    .line 374: move-result v7
    .line 375: iget v8, v0, Lj0/d;->c:F
    .line 377: invoke-static {v8}, Ld2/b;->a1(F)I
    .line 380: move-result v8
    .line 381: iget v0, v0, Lj0/d;->d:F
    .line 383: invoke-static {v0}, Ld2/b;->a1(F)I
    .line 386: move-result v0
    .line 387: invoke-direct {v5, v6, v7, v8, v0}, Landroid/graphics/Rect;-><init>(IIII)V
    .line 390: invoke-direct {v4, v3, v5}, Landroidx/compose/ui/platform/h2;-><init>(Ld1/n;Landroid/graphics/Rect;)V
    .line 393: invoke-interface {v2, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 396: goto :goto_418
    .line 397: if-ne v10, v8, :cond_418
    .line 399: invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 402: move-result-object v0
    .line 403: new-instance v1, Landroidx/compose/ui/platform/h2;
    .line 405: invoke-virtual {v7}, Landroid/graphics/Region;->getBounds()Landroid/graphics/Rect;
    .line 408: move-result-object v4
    .line 409: invoke-static {v4, v11}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 412: invoke-direct {v1, v3, v4}, Landroidx/compose/ui/platform/h2;-><init>(Ld1/n;Landroid/graphics/Rect;)V
    .line 415: invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 418: return-void
.end method

# direct methods
.method public static final t([F[F)Z
    .registers 48

    .line 0: move-object/from16 v0, v46
    .line 2: move-object/from16 v1, v47
    .line 4: const-string v2, "$this$invertTo"
    .line 6: invoke-static {v0, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: const-string v2, "other"
    .line 11: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: const/4 v2, 0
    .line 15: aget v3, v0, v2
    .line 17: const/4 v4, 1
    .line 18: aget v5, v0, v4
    .line 20: const/4 v6, 2
    .line 21: aget v7, v0, v6
    .line 23: const/4 v8, 3
    .line 24: aget v9, v0, v8
    .line 26: const/4 v10, 4
    .line 27: aget v11, v0, v10
    .line 29: const/4 v12, 5
    .line 30: aget v13, v0, v12
    .line 32: const/4 v14, 6
    .line 33: aget v15, v0, v14
    .line 35: const/16 v16, 7
    .line 37: aget v17, v0, v16
    .line 39: const/16 v18, 8
    .line 41: aget v14, v0, v18
    .line 43: const/16 v19, 9
    .line 45: aget v12, v0, v19
    .line 47: const/16 v21, 10
    .line 49: aget v22, v0, v21
    .line 51: const/16 v23, 11
    .line 53: aget v24, v0, v23
    .line 55: const/16 v25, 12
    .line 57: aget v10, v0, v25
    .line 59: const/16 v26, 13
    .line 61: aget v27, v0, v26
    .line 63: const/16 v28, 14
    .line 65: aget v29, v0, v28
    .line 67: const/16 v30, 15
    .line 69: aget v0, v0, v30
    .line 71: mul-float v31, v3, v13
    .line 73: mul-float v32, v5, v11
    .line 75: sub-float v31, v31, v32
    .line 77: mul-float v32, v3, v15
    .line 79: mul-float v33, v7, v11
    .line 81: sub-float v32, v32, v33
    .line 83: mul-float v33, v3, v17
    .line 85: mul-float v34, v9, v11
    .line 87: sub-float v33, v33, v34
    .line 89: mul-float v34, v5, v15
    .line 91: mul-float v35, v7, v13
    .line 93: sub-float v34, v34, v35
    .line 95: mul-float v35, v5, v17
    .line 97: mul-float v36, v9, v13
    .line 99: sub-float v35, v35, v36
    .line 101: mul-float v36, v7, v17
    .line 103: mul-float v37, v9, v15
    .line 105: sub-float v36, v36, v37
    .line 107: mul-float v37, v14, v27
    .line 109: mul-float v38, v12, v10
    .line 111: sub-float v37, v37, v38
    .line 113: mul-float v38, v14, v29
    .line 115: mul-float v39, v22, v10
    .line 117: sub-float v38, v38, v39
    .line 119: mul-float v39, v14, v0
    .line 121: mul-float v40, v24, v10
    .line 123: sub-float v39, v39, v40
    .line 125: mul-float v40, v12, v29
    .line 127: mul-float v41, v22, v27
    .line 129: sub-float v40, v40, v41
    .line 131: mul-float v41, v12, v0
    .line 133: mul-float v42, v24, v27
    .line 135: sub-float v41, v41, v42
    .line 137: mul-float v42, v22, v0
    .line 139: mul-float v43, v24, v29
    .line 141: sub-float v42, v42, v43
    .line 143: mul-float v43, v31, v42
    .line 145: mul-float v44, v32, v41
    .line 147: sub-float v43, v43, v44
    .line 149: mul-float v44, v33, v40
    .line 151: add-float v44, v44, v43
    .line 153: mul-float v43, v34, v39
    .line 155: add-float v43, v43, v44
    .line 157: mul-float v44, v35, v38
    .line 159: sub-float v43, v43, v44
    .line 161: mul-float v44, v36, v37
    .line 163: add-float v44, v44, v43
    .line 165: const/16 v43, 0
    .line 167: cmpg-float v43, v44, v43
    .line 169: if-nez v43, :cond_172
    .line 171: return v2
    .line 172: const/high16 v43, 0x3f80
    .line 174: div-float v43, v43, v44
    .line 176: mul-float v44, v13, v42
    .line 178: mul-float v45, v15, v41
    .line 180: sub-float v44, v44, v45
    .line 182: mul-float v45, v17, v40
    .line 184: add-float v45, v45, v44
    .line 186: mul-float v45, v45, v43
    .line 188: aput v45, v1, v2
    .line 190: neg-float v2, v5
    .line 191: mul-float v2, v2, v42
    .line 193: mul-float v44, v7, v41
    .line 195: add-float v44, v44, v2
    .line 197: mul-float v2, v9, v40
    .line 199: sub-float v44, v44, v2
    .line 201: mul-float v44, v44, v43
    .line 203: aput v44, v1, v4
    .line 205: mul-float v2, v27, v36
    .line 207: mul-float v44, v29, v35
    .line 209: sub-float v2, v2, v44
    .line 211: mul-float v44, v0, v34
    .line 213: add-float v44, v44, v2
    .line 215: mul-float v44, v44, v43
    .line 217: aput v44, v1, v6
    .line 219: neg-float v2, v12
    .line 220: mul-float v2, v2, v36
    .line 222: mul-float v6, v22, v35
    .line 224: add-float/2addr v6, v2
    .line 225: mul-float v2, v24, v34
    .line 227: sub-float/2addr v6, v2
    .line 228: mul-float v6, v6, v43
    .line 230: aput v6, v1, v8
    .line 232: neg-float v2, v11
    .line 233: mul-float v6, v2, v42
    .line 235: mul-float v8, v15, v39
    .line 237: add-float/2addr v8, v6
    .line 238: mul-float v6, v17, v38
    .line 240: sub-float/2addr v8, v6
    .line 241: mul-float v8, v8, v43
    .line 243: const/4 v6, 4
    .line 244: aput v8, v1, v6
    .line 246: mul-float v42, v42, v3
    .line 248: mul-float v6, v7, v39
    .line 250: sub-float v42, v42, v6
    .line 252: mul-float v6, v9, v38
    .line 254: add-float v6, v6, v42
    .line 256: mul-float v6, v6, v43
    .line 258: const/4 v8, 5
    .line 259: aput v6, v1, v8
    .line 261: neg-float v6, v10
    .line 262: mul-float v8, v6, v36
    .line 264: mul-float v20, v29, v33
    .line 266: add-float v20, v20, v8
    .line 268: mul-float v8, v0, v32
    .line 270: sub-float v20, v20, v8
    .line 272: mul-float v20, v20, v43
    .line 274: const/4 v8, 6
    .line 275: aput v20, v1, v8
    .line 277: mul-float v36, v36, v14
    .line 279: mul-float v8, v22, v33
    .line 281: sub-float v36, v36, v8
    .line 283: mul-float v8, v24, v32
    .line 285: add-float v8, v8, v36
    .line 287: mul-float v8, v8, v43
    .line 289: aput v8, v1, v16
    .line 291: mul-float v11, v11, v41
    .line 293: mul-float v8, v13, v39
    .line 295: sub-float/2addr v11, v8
    .line 296: mul-float v17, v17, v37
    .line 298: add-float v17, v17, v11
    .line 300: mul-float v17, v17, v43
    .line 302: aput v17, v1, v18
    .line 304: neg-float v8, v3
    .line 305: mul-float v8, v8, v41
    .line 307: mul-float v39, v39, v5
    .line 309: add-float v39, v39, v8
    .line 311: mul-float v9, v9, v37
    .line 313: sub-float v39, v39, v9
    .line 315: mul-float v39, v39, v43
    .line 317: aput v39, v1, v19
    .line 319: mul-float v10, v10, v35
    .line 321: mul-float v8, v27, v33
    .line 323: sub-float/2addr v10, v8
    .line 324: mul-float v0, v0, v31
    .line 326: add-float/2addr v0, v10
    .line 327: mul-float v0, v0, v43
    .line 329: aput v0, v1, v21
    .line 331: neg-float v0, v14
    .line 332: mul-float v0, v0, v35
    .line 334: mul-float v33, v33, v12
    .line 336: add-float v33, v33, v0
    .line 338: mul-float v24, v24, v31
    .line 340: sub-float v33, v33, v24
    .line 342: mul-float v33, v33, v43
    .line 344: aput v33, v1, v23
    .line 346: mul-float v2, v2, v40
    .line 348: mul-float v13, v13, v38
    .line 350: add-float/2addr v13, v2
    .line 351: mul-float v15, v15, v37
    .line 353: sub-float/2addr v13, v15
    .line 354: mul-float v13, v13, v43
    .line 356: aput v13, v1, v25
    .line 358: mul-float v3, v3, v40
    .line 360: mul-float v5, v5, v38
    .line 362: sub-float/2addr v3, v5
    .line 363: mul-float v7, v7, v37
    .line 365: add-float/2addr v7, v3
    .line 366: mul-float v7, v7, v43
    .line 368: aput v7, v1, v26
    .line 370: mul-float v6, v6, v34
    .line 372: mul-float v27, v27, v32
    .line 374: add-float v27, v27, v6
    .line 376: mul-float v29, v29, v31
    .line 378: sub-float v27, v27, v29
    .line 380: mul-float v27, v27, v43
    .line 382: aput v27, v1, v28
    .line 384: mul-float v14, v14, v34
    .line 386: mul-float v12, v12, v32
    .line 388: sub-float/2addr v14, v12
    .line 389: mul-float v22, v22, v31
    .line 391: add-float v22, v22, v14
    .line 393: mul-float v22, v22, v43
    .line 395: aput v22, v1, v30
    .line 397: return v4
.end method

# direct methods
.method public static final u(FFFFJ)Z
    .registers 6

    .line 0: sub-float/2addr v0, v2
    .line 1: sub-float/2addr v1, v3
    .line 2: invoke-static {v4, v5}, Lj0/a;->b(J)F
    .line 5: move-result v2
    .line 6: invoke-static {v4, v5}, Lj0/a;->c(J)F
    .line 9: move-result v3
    .line 10: mul-float/2addr v0, v0
    .line 11: mul-float/2addr v2, v2
    .line 12: div-float/2addr v0, v2
    .line 13: mul-float/2addr v1, v1
    .line 14: mul-float/2addr v3, v3
    .line 15: div-float/2addr v1, v3
    .line 16: add-float/2addr v1, v0
    .line 17: const/high16 v0, 0x3f80
    .line 19: cmpg-float v0, v1, v0
    .line 21: if-gtz v0, :cond_25
    .line 23: const/4 v0, 1
    .line 24: goto :goto_26
    .line 25: const/4 v0, 0
    .line 26: return v0
.end method

# direct methods
.method public static final v(Landroidx/compose/ui/platform/z0;I)V
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroidx/compose/ui/platform/z0;->getLayoutNodeToHolder()Ljava/util/HashMap;
    .line 8: move-result-object v2
    .line 9: invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;
    .line 12: move-result-object v2
    .line 13: const-string v0, "layoutNodeToHolder.entries"
    .line 15: invoke-static {v2, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 18: check-cast v2, Ljava/lang/Iterable;
    .line 20: invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 23: move-result-object v2
    .line 24: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 27: move-result v0
    .line 28: if-eqz v0, :cond_48
    .line 30: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 33: move-result-object v0
    .line 34: move-object v1, v0
    .line 35: check-cast v1, Ljava/util/Map$Entry;
    .line 37: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 40: move-result-object v1
    .line 41: check-cast v1, Landroidx/compose/ui/node/a;
    .line 43: iget v1, v1, Landroidx/compose/ui/node/a;->j:I
    .line 45: if-ne v1, v3, :cond_24
    .line 47: goto :goto_49
    .line 48: const/4 v0, 0
    .line 49: check-cast v0, Ljava/util/Map$Entry;
    .line 51: if-eqz v0, :cond_60
    .line 53: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 56: move-result-object v2
    .line 57: invoke-static {v2}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 60: return-void
.end method

# direct methods
.method public static final w(Ljava/lang/Object;)Ljava/lang/String;
    .registers 3

    .line 0: const-string v0, "obj"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 8: move-result-object v0
    .line 9: invoke-virtual {v0}, Ljava/lang/Class;->isAnonymousClass()Z
    .line 12: move-result v0
    .line 13: if-eqz v0, :cond_24
    .line 15: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 18: move-result-object v0
    .line 19: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 22: move-result-object v0
    .line 23: goto :goto_32
    .line 24: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 27: move-result-object v0
    .line 28: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    .line 31: move-result-object v0
    .line 32: new-instance v1, Ljava/lang/StringBuilder;
    .line 34: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 37: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 40: const/16 v0, 64
    .line 42: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 45: invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    .line 48: move-result v2
    .line 49: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 52: move-result-object v2
    .line 53: filled-new-array {v2}, [Ljava/lang/Object;
    .line 56: move-result-object v2
    .line 57: const/4 v0, 1
    .line 58: invoke-static {v2, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 61: move-result-object v2
    .line 62: const-string v0, "%07x"
    .line 64: invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 67: move-result-object v2
    .line 68: const-string v0, "format(format, *args)"
    .line 70: invoke-static {v2, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 73: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 76: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 79: move-result-object v2
    .line 80: return-object v2
.end method

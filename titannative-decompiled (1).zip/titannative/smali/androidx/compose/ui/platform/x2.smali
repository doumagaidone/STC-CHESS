.class public abstract interface Landroidx/compose/ui/platform/x2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/r1;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Landroidx/compose/ui/platform/r1;->j:Landroidx/compose/ui/platform/r1;
    .line 2: sput-object v0, Landroidx/compose/ui/platform/x2;->a:Landroidx/compose/ui/platform/r1;
    .line 4: return-void
.end method

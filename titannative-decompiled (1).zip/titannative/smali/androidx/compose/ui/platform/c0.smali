.class public final Landroidx/compose/ui/platform/c0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld1/n;
.field public final b:I
.field public final c:I
.field public final d:I
.field public final e:I
.field public final f:J

# direct methods
.method public constructor <init>(Ld1/n;IIIIJ)V
    .registers 8

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/c0;->a:Ld1/n;
    .line 5: iput v2, v0, Landroidx/compose/ui/platform/c0;->b:I
    .line 7: iput v3, v0, Landroidx/compose/ui/platform/c0;->c:I
    .line 9: iput v4, v0, Landroidx/compose/ui/platform/c0;->d:I
    .line 11: iput v5, v0, Landroidx/compose/ui/platform/c0;->e:I
    .line 13: iput-wide v6, v0, Landroidx/compose/ui/platform/c0;->f:J
    .line 15: return-void
.end method

.class public abstract interface Landroidx/compose/ui/platform/l2;
.super Ljava/lang/Object;
.source "SourceFile"

.class public final Landroidx/compose/ui/platform/n2;
.super Landroid/view/ViewOutlineProvider;
.source "SourceFile"

.field public final synthetic a:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: iput v1, v0, Landroidx/compose/ui/platform/n2;->a:I
    .line 2: invoke-direct {v0}, Landroid/view/ViewOutlineProvider;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public final getOutline(Landroid/view/View;Landroid/graphics/Outline;)V
    .registers 5

    .line 0: iget v0, v2, Landroidx/compose/ui/platform/n2;->a:I
    .line 2: const-string v1, "view"
    .line 4: packed-switch v0, :data_56
    .line 7: invoke-static {v3, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "result"
    .line 12: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: invoke-virtual {v3}, Landroid/view/View;->getWidth()I
    .line 18: move-result v0
    .line 19: invoke-virtual {v3}, Landroid/view/View;->getHeight()I
    .line 22: move-result v3
    .line 23: const/4 v1, 0
    .line 24: invoke-virtual {v4, v1, v1, v0, v3}, Landroid/graphics/Outline;->setRect(IIII)V
    .line 27: const/4 v3, 0
    .line 28: invoke-virtual {v4, v3}, Landroid/graphics/Outline;->setAlpha(F)V
    .line 31: return-void
    .line 32: invoke-static {v3, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 35: const-string v0, "outline"
    .line 37: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 40: check-cast v3, Landroidx/compose/ui/platform/p2;
    .line 42: iget-object v3, v3, Landroidx/compose/ui/platform/p2;->m:Landroidx/compose/ui/platform/y1;
    .line 44: invoke-virtual {v3}, Landroidx/compose/ui/platform/y1;->b()Landroid/graphics/Outline;
    .line 47: move-result-object v3
    .line 48: invoke-static {v3}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 51: invoke-virtual {v4, v3}, Landroid/graphics/Outline;->set(Landroid/graphics/Outline;)V
    .line 54: return-void
    .line 55: nop
    .line 56: nop
    .line 57: move v0, v0
    .line 58: nop
    .line 59: nop
    .line 60: const-class v0, B
.end method

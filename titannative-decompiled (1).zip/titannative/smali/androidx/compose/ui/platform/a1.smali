.class public final Landroidx/compose/ui/platform/a1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/a1;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/a1;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/a1;->a:Landroidx/compose/ui/platform/a1;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/accessibility/AccessibilityManager;II)I
    .registers 5

    .line 0: const-string v0, "accessibilityManager"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2, v3, v4}, Landroid/view/accessibility/AccessibilityManager;->getRecommendedTimeoutMillis(II)I
    .line 8: move-result v2
    .line 9: return v2
.end method

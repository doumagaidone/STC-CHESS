.class public final Landroidx/compose/ui/platform/a3;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/View$OnAttachStateChangeListener;

.field public final synthetic a:Landroid/view/View;
.field public final synthetic b:Lu/o2;

# direct methods
.method public constructor <init>(Landroid/view/View;Lu/o2;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/a3;->a:Landroid/view/View;
    .line 5: iput-object v2, v0, Landroidx/compose/ui/platform/a3;->b:Lu/o2;
    .line 7: return-void
.end method

# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .registers 3

    .line 0: const-string v0, "v"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .registers 3

    .line 0: const-string v0, "v"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v2, v1, Landroidx/compose/ui/platform/a3;->a:Landroid/view/View;
    .line 7: invoke-virtual {v2, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V
    .line 10: iget-object v2, v1, Landroidx/compose/ui/platform/a3;->b:Lu/o2;
    .line 12: invoke-virtual {v2}, Lu/o2;->r()V
    .line 15: return-void
.end method

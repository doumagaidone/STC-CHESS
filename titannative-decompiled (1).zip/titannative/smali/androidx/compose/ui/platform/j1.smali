.class public final Landroidx/compose/ui/platform/j1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Landroid/os/Parcel;

# virtual methods
.method public final a()J
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/compose/ui/platform/j1;->a:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readByte()B
    .line 5: move-result v0
    .line 6: const/4 v1, 1
    .line 7: const-wide/16 v2, 0
    .line 9: if-ne v0, v1, :cond_17
    .line 11: const-wide v0, 0x0100
    .line 16: goto :goto_27
    .line 17: const/4 v1, 2
    .line 18: if-ne v0, v1, :cond_26
    .line 20: const-wide v0, 0x0200
    .line 25: goto :goto_27
    .line 26: move-wide v0, v2
    .line 27: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 30: move-result v2
    .line 31: if-eqz v2, :cond_38
    .line 33: sget-object v0, Lr1/k;->b:[Lr1/l;
    .line 35: sget-wide v0, Lr1/k;->c:J
    .line 37: return-wide v0
    .line 38: iget-object v2, v4, Landroidx/compose/ui/platform/j1;->a:Landroid/os/Parcel;
    .line 40: invoke-virtual {v2}, Landroid/os/Parcel;->readFloat()F
    .line 43: move-result v2
    .line 44: invoke-static {v2, v0, v1}, Ld2/c;->m0(FJ)J
    .line 47: move-result-wide v0
    .line 48: return-wide v0
.end method

# virtual methods
.method public final b(B)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/j1;->a:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeByte(B)V
    .line 5: return-void
.end method

# virtual methods
.method public final c(F)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/j1;->a:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeFloat(F)V
    .line 5: return-void
.end method

# virtual methods
.method public final d(J)V
    .registers 11

    .line 0: invoke-static {v9, v10}, Lr1/k;->b(J)J
    .line 3: move-result-wide v0
    .line 4: const-wide/16 v2, 0
    .line 6: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 9: move-result v4
    .line 10: const/4 v5, 0
    .line 11: if-eqz v4, :cond_14
    .line 13: goto :goto_39
    .line 14: const-wide v6, 0x0100
    .line 19: invoke-static {v0, v1, v6, v7}, Lr1/l;->a(JJ)Z
    .line 22: move-result v4
    .line 23: if-eqz v4, :cond_27
    .line 25: const/4 v5, 1
    .line 26: goto :goto_39
    .line 27: const-wide v6, 0x0200
    .line 32: invoke-static {v0, v1, v6, v7}, Lr1/l;->a(JJ)Z
    .line 35: move-result v0
    .line 36: if-eqz v0, :cond_39
    .line 38: const/4 v5, 2
    .line 39: invoke-virtual {v8, v5}, Landroidx/compose/ui/platform/j1;->b(B)V
    .line 42: invoke-static {v9, v10}, Lr1/k;->b(J)J
    .line 45: move-result-wide v0
    .line 46: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 49: move-result v0
    .line 50: if-nez v0, :cond_59
    .line 52: invoke-static {v9, v10}, Lr1/k;->c(J)F
    .line 55: move-result v9
    .line 56: invoke-virtual {v8, v9}, Landroidx/compose/ui/platform/j1;->c(F)V
    .line 59: return-void
.end method

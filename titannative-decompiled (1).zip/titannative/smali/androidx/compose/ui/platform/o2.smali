.class public abstract Landroidx/compose/ui/platform/o2;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Landroid/view/View;)J
    .registers 3

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v2}, Landroidx/compose/ui/platform/a2;->c(Landroid/view/View;)J
    .line 8: move-result-wide v0
    .line 9: return-wide v0
.end method

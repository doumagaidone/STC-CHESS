.class public final Landroidx/compose/ui/platform/f3;
.super Landroid/database/ContentObserver;
.source "SourceFile"

.field public final synthetic a:I
.field public final synthetic b:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(Lp3/h;Landroid/os/Handler;I)V
    .registers 4

    .line 0: iput v3, v0, Landroidx/compose/ui/platform/f3;->a:I
    .line 2: iput-object v1, v0, Landroidx/compose/ui/platform/f3;->b:Ljava/lang/Object;
    .line 4: invoke-direct {v0, v2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V
    .line 7: return-void
.end method

# virtual methods
.method public final onChange(ZLandroid/net/Uri;)V
    .registers 3

    .line 0: iget v1, v0, Landroidx/compose/ui/platform/f3;->a:I
    .line 2: iget-object v2, v0, Landroidx/compose/ui/platform/f3;->b:Ljava/lang/Object;
    .line 4: packed-switch v1, :data_22
    .line 7: check-cast v2, Landroidx/emoji2/text/u;
    .line 9: invoke-virtual {v2}, Landroidx/emoji2/text/u;->c()V
    .line 12: return-void
    .line 13: check-cast v2, Lp3/o;
    .line 15: sget-object v1, Ls2/k;->a:Ls2/k;
    .line 17: invoke-interface {v2, v1}, Lp3/d0;->o(Ljava/lang/Object;)Ljava/lang/Object;
    .line 20: return-void
    .line 21: nop
    .line 22: nop
    .line 23: move v0, v0
    .line 24: nop
    .line 25: nop
    .line 26: move-object/16 v0, v11
.end method

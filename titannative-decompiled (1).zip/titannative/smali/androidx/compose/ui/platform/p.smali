.class public final synthetic Landroidx/compose/ui/platform/p;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;

.field public final synthetic a:Landroidx/compose/ui/platform/AndroidComposeView;

# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/platform/AndroidComposeView;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/p;->a:Landroidx/compose/ui/platform/AndroidComposeView;
    .line 5: return-void
.end method

# virtual methods
.method public final onTouchModeChanged(Z)V
    .registers 4

    .line 0: sget-object v0, Landroidx/compose/ui/platform/AndroidComposeView;->z0:Ljava/lang/Class;
    .line 2: iget-object v0, v2, Landroidx/compose/ui/platform/p;->a:Landroidx/compose/ui/platform/AndroidComposeView;
    .line 4: const-string v1, "this$0"
    .line 6: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: if-eqz v3, :cond_13
    .line 11: const/4 v3, 1
    .line 12: goto :goto_14
    .line 13: const/4 v3, 2
    .line 14: iget-object v0, v0, Landroidx/compose/ui/platform/AndroidComposeView;->k0:Lr0/c;
    .line 16: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 19: new-instance v1, Lr0/a;
    .line 21: invoke-direct {v1, v3}, Lr0/a;-><init>(I)V
    .line 24: iget-object v3, v0, Lr0/c;->a:Lu/s1;
    .line 26: invoke-virtual {v3, v1}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 29: return-void
.end method

.class public final Landroidx/compose/ui/platform/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/j;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/j;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/j;->a:Landroidx/compose/ui/platform/j;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/util/List;)V
    .registers 4

    .line 0: const-string v0, "node"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "data"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {v2, v3}, Lai/onnxruntime/a;->w(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/util/List;)V
    .line 13: return-void
.end method

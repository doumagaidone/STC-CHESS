.class public final Landroidx/compose/ui/platform/o0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/content/ComponentCallbacks2;

.field public final synthetic i:Landroid/content/res/Configuration;
.field public final synthetic j:Lc1/c;

# direct methods
.method public constructor <init>(Landroid/content/res/Configuration;Lc1/c;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/o0;->i:Landroid/content/res/Configuration;
    .line 5: iput-object v2, v0, Landroidx/compose/ui/platform/o0;->j:Lc1/c;
    .line 7: return-void
.end method

# virtual methods
.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 7

    .line 0: const-string v0, "configuration"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v5, Landroidx/compose/ui/platform/o0;->i:Landroid/content/res/Configuration;
    .line 7: invoke-virtual {v0, v6}, Landroid/content/res/Configuration;->updateFrom(Landroid/content/res/Configuration;)I
    .line 10: move-result v1
    .line 11: iget-object v2, v5, Landroidx/compose/ui/platform/o0;->j:Lc1/c;
    .line 13: iget-object v2, v2, Lc1/c;->a:Ljava/util/HashMap;
    .line 15: invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;
    .line 18: move-result-object v2
    .line 19: invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 22: move-result-object v2
    .line 23: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 26: move-result v3
    .line 27: if-eqz v3, :cond_66
    .line 29: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 32: move-result-object v3
    .line 33: const-string v4, "it.next()"
    .line 35: invoke-static {v3, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 38: check-cast v3, Ljava/util/Map$Entry;
    .line 40: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 43: move-result-object v3
    .line 44: check-cast v3, Ljava/lang/ref/WeakReference;
    .line 46: invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 49: move-result-object v3
    .line 50: check-cast v3, Lc1/a;
    .line 52: if-eqz v3, :cond_62
    .line 54: iget v3, v3, Lc1/a;->b:I
    .line 56: invoke-static {v1, v3}, Landroid/content/res/Configuration;->needNewResources(II)Z
    .line 59: move-result v3
    .line 60: if-eqz v3, :cond_23
    .line 62: invoke-interface {v2}, Ljava/util/Iterator;->remove()V
    .line 65: goto :goto_23
    .line 66: invoke-virtual {v0, v6}, Landroid/content/res/Configuration;->setTo(Landroid/content/res/Configuration;)V
    .line 69: return-void
.end method

# virtual methods
.method public final onLowMemory()V
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/o0;->j:Lc1/c;
    .line 2: iget-object v0, v0, Lc1/c;->a:Ljava/util/HashMap;
    .line 4: invoke-virtual {v0}, Ljava/util/HashMap;->clear()V
    .line 7: return-void
.end method

# virtual methods
.method public final onTrimMemory(I)V
    .registers 2

    .line 0: iget-object v1, v0, Landroidx/compose/ui/platform/o0;->j:Lc1/c;
    .line 2: iget-object v1, v1, Lc1/c;->a:Ljava/util/HashMap;
    .line 4: invoke-virtual {v1}, Ljava/util/HashMap;->clear()V
    .line 7: return-void
.end method

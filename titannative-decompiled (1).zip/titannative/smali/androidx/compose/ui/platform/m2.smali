.class public abstract interface Landroidx/compose/ui/platform/m2;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a()J
.end method

# virtual methods
.method public abstract b()F
.end method

# virtual methods
.method public c()J
    .registers 3

    .line 0: const/16 v0, 48
    .line 2: int-to-float v0, v0
    .line 3: invoke-static {v0, v0}, Ld2/b;->f(FF)J
    .line 6: move-result-wide v0
    .line 7: return-wide v0
.end method

# virtual methods
.method public abstract d()J
.end method

# virtual methods
.method public abstract e()V
.end method

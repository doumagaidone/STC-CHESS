.class public abstract synthetic Landroidx/compose/ui/platform/a2;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static bridge synthetic A()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_PAGE_LEFT:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic B(Landroid/graphics/RenderNode;)V
    .registers 3

    .line 0: const/4 v0, 0
    .line 1: const/4 v1, 0
    .line 2: invoke-virtual {v2, v0, v1}, Landroid/graphics/RenderNode;->setUseCompositingLayer(ZLandroid/graphics/Paint;)Z
    .line 5: return-void
.end method

# direct methods
.method public static bridge synthetic C()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_PAGE_RIGHT:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic D(Landroid/graphics/RenderNode;)V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Landroid/graphics/RenderNode;->setHasOverlappingRendering(Z)Z
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic a(Landroid/graphics/RenderNode;)F
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getAlpha()F
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic b(Landroid/graphics/RenderNode;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getBottom()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic c(Landroid/view/View;)J
    .registers 3

    .line 0: invoke-virtual {v2}, Landroid/view/View;->getUniqueDrawingId()J
    .line 3: move-result-wide v0
    .line 4: return-wide v0
.end method

# direct methods
.method public static bridge synthetic d(Landroid/graphics/RenderNode;)Landroid/graphics/RecordingCanvas;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->beginRecording()Landroid/graphics/RecordingCanvas;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static synthetic e()Landroid/graphics/RenderNode;
    .registers 2

    .line 0: new-instance v0, Landroid/graphics/RenderNode;
    .line 2: const-string v1, "Compose"
    .line 4: invoke-direct {v0, v1}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V
    .line 7: return-object v0
.end method

# direct methods
.method public static bridge synthetic f()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_PAGE_UP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic g(Ljava/lang/Object;)Landroid/view/contentcapture/ContentCaptureSession;
    .registers 1

    .line 0: check-cast v0, Landroid/view/contentcapture/ContentCaptureSession;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic h(Landroid/view/View;)Ljava/util/Map;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->getAttributeSourceResourceMap()Ljava/util/Map;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic i(Landroid/app/Activity;Landroidx/lifecycle/e0;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/app/Activity;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic j(Landroid/graphics/Canvas;ILandroid/graphics/BlendMode;)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/BlendMode;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic k(Landroid/graphics/Canvas;J)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/graphics/Canvas;->drawColor(J)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic l(Landroid/graphics/Canvas;JLandroid/graphics/BlendMode;)V
    .registers 4

    .line 0: invoke-virtual {v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawColor(JLandroid/graphics/BlendMode;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic m(Landroid/graphics/Canvas;Landroid/graphics/RectF;FFLandroid/graphics/RectF;FFLandroid/graphics/Paint;)V
    .registers 8

    .line 0: invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawDoubleRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/RectF;FFLandroid/graphics/Paint;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic n(Landroid/graphics/Canvas;Landroid/graphics/RectF;[FLandroid/graphics/RectF;[FLandroid/graphics/Paint;)V
    .registers 6

    .line 0: invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawDoubleRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/RectF;[FLandroid/graphics/Paint;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic o(Landroid/graphics/Paint;Ljava/lang/CharSequence;IILandroid/graphics/Rect;)V
    .registers 5

    .line 0: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/CharSequence;IILandroid/graphics/Rect;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic p(Landroid/graphics/RenderNode;)V
    .registers 3

    .line 0: const/4 v0, 1
    .line 1: const/4 v1, 0
    .line 2: invoke-virtual {v2, v0, v1}, Landroid/graphics/RenderNode;->setUseCompositingLayer(ZLandroid/graphics/Paint;)Z
    .line 5: return-void
.end method

# direct methods
.method public static bridge synthetic q(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setScaleY(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic r(Landroid/graphics/RenderNode;Landroid/graphics/Matrix;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->getMatrix(Landroid/graphics/Matrix;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic s(Landroid/graphics/RenderNode;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setClipToOutline(Z)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic t(Landroid/graphics/RenderNode;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getClipToOutline()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic u(Landroid/graphics/RenderNode;IIII)Z
    .registers 5

    .line 0: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/RenderNode;->setPosition(IIII)Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic v(Landroid/graphics/RenderNode;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getRight()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic w()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_PAGE_DOWN:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic x(Landroid/graphics/RenderNode;)V
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: invoke-virtual {v1, v0}, Landroid/graphics/RenderNode;->setHasOverlappingRendering(Z)Z
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic y(Landroid/graphics/RenderNode;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getClipToBounds()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic z(Landroid/graphics/RenderNode;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getWidth()I
    .line 3: move-result v0
    .line 4: return v0
.end method

.class public final Landroidx/compose/ui/platform/c2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/c2;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/c2;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/c2;->a:Landroidx/compose/ui/platform/c2;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/graphics/RenderNode;Lk0/h0;)V
    .registers 3

    .line 0: const-string v2, "renderNode"
    .line 2: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v1}, Landroidx/compose/ui/platform/m;->f(Landroid/graphics/RenderNode;)V
    .line 8: return-void
.end method

.class public final Landroidx/compose/ui/platform/k3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/k3;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/k3;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/k3;->a:Landroidx/compose/ui/platform/k3;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroidx/compose/ui/platform/AndroidComposeView;)V
    .registers 3

    .line 0: const-string v0, "ownerView"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 8: move-result-object v0
    .line 9: if-eqz v0, :cond_14
    .line 11: invoke-static {v0, v2, v2}, Lai/onnxruntime/a;->s(Landroid/view/ViewParent;Landroid/view/View;Landroid/view/View;)V
    .line 14: return-void
.end method

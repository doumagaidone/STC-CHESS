.class public abstract Landroidx/compose/ui/platform/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf2/k;Ld1/n;)V
    .registers 6

    .line 0: const-string v0, "info"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "semanticsNode"
    .line 7: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {v5}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_111
    .line 16: sget-object v0, Ld1/h;->r:Ld1/t;
    .line 18: iget-object v5, v5, Ld1/n;->d:Ld1/i;
    .line 20: invoke-static {v5, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 23: move-result-object v0
    .line 24: check-cast v0, Ld1/a;
    .line 26: const/4 v1, 0
    .line 27: if-eqz v0, :cond_42
    .line 29: new-instance v2, Lf2/e;
    .line 31: const v3, 0x1020046
    .line 34: iget-object v0, v0, Ld1/a;->a:Ljava/lang/String;
    .line 36: invoke-direct {v2, v1, v3, v0, v1}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 39: invoke-virtual {v4, v2}, Lf2/k;->a(Lf2/e;)V
    .line 42: sget-object v0, Ld1/h;->t:Ld1/t;
    .line 44: invoke-static {v5, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 47: move-result-object v0
    .line 48: check-cast v0, Ld1/a;
    .line 50: if-eqz v0, :cond_65
    .line 52: new-instance v2, Lf2/e;
    .line 54: const v3, 0x1020047
    .line 57: iget-object v0, v0, Ld1/a;->a:Ljava/lang/String;
    .line 59: invoke-direct {v2, v1, v3, v0, v1}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 62: invoke-virtual {v4, v2}, Lf2/k;->a(Lf2/e;)V
    .line 65: sget-object v0, Ld1/h;->s:Ld1/t;
    .line 67: invoke-static {v5, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 70: move-result-object v0
    .line 71: check-cast v0, Ld1/a;
    .line 73: if-eqz v0, :cond_88
    .line 75: new-instance v2, Lf2/e;
    .line 77: const v3, 0x1020048
    .line 80: iget-object v0, v0, Ld1/a;->a:Ljava/lang/String;
    .line 82: invoke-direct {v2, v1, v3, v0, v1}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 85: invoke-virtual {v4, v2}, Lf2/k;->a(Lf2/e;)V
    .line 88: sget-object v0, Ld1/h;->u:Ld1/t;
    .line 90: invoke-static {v5, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 93: move-result-object v5
    .line 94: check-cast v5, Ld1/a;
    .line 96: if-eqz v5, :cond_111
    .line 98: new-instance v0, Lf2/e;
    .line 100: const v2, 0x1020049
    .line 103: iget-object v5, v5, Ld1/a;->a:Ljava/lang/String;
    .line 105: invoke-direct {v0, v1, v2, v5, v1}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 108: invoke-virtual {v4, v0}, Lf2/k;->a(Lf2/e;)V
    .line 111: return-void
.end method

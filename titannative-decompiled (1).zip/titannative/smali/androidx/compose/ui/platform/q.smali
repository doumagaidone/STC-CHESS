.class public final Landroidx/compose/ui/platform/q;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroidx/lifecycle/t;
.field public final b:Ll2/f;

# direct methods
.method public constructor <init>(Landroidx/lifecycle/t;Ll2/f;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/q;->a:Landroidx/lifecycle/t;
    .line 5: iput-object v2, v0, Landroidx/compose/ui/platform/q;->b:Ll2/f;
    .line 7: return-void
.end method

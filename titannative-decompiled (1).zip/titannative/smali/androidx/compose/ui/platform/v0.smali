.class public final Landroidx/compose/ui/platform/v0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/Choreographer$FrameCallback;

.field public final synthetic i:Ln3/g;
.field public final synthetic j:Ld3/c;

# direct methods
.method public constructor <init>(Ln3/h;Landroidx/compose/ui/platform/w0;Ld3/c;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/v0;->i:Ln3/g;
    .line 5: iput-object v3, v0, Landroidx/compose/ui/platform/v0;->j:Ld3/c;
    .line 7: return-void
.end method

# virtual methods
.method public final doFrame(J)V
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/v0;->j:Ld3/c;
    .line 2: invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 5: move-result-object v2
    .line 6: invoke-interface {v0, v2}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v2
    .line 10: goto :goto_16
    .line 11: move-exception v2
    .line 12: invoke-static {v2}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 15: move-result-object v2
    .line 16: iget-object v3, v1, Landroidx/compose/ui/platform/v0;->i:Ln3/g;
    .line 18: check-cast v3, Ln3/h;
    .line 20: invoke-virtual {v3, v2}, Ln3/h;->c(Ljava/lang/Object;)V
    .line 23: return-void
.end method

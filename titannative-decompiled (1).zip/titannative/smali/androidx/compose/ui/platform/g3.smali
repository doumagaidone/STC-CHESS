.class public abstract Landroidx/compose/ui/platform/g3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/LinkedHashMap;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/util/LinkedHashMap;
    .line 2: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/g3;->a:Ljava/util/LinkedHashMap;
    .line 7: return-void
.end method

# direct methods
.method public static final a(Landroid/content/Context;)Lkotlinx/coroutines/flow/n0;
    .registers 11

    .line 0: sget-object v0, Landroidx/compose/ui/platform/g3;->a:Ljava/util/LinkedHashMap;
    .line 2: monitor-enter v0
    .line 3: invoke-virtual {v0, v10}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 6: move-result-object v1
    .line 7: if-nez v1, :cond_109
    .line 9: invoke-virtual {v10}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    .line 12: move-result-object v3
    .line 13: const-string v1, "animator_duration_scale"
    .line 15: invoke-static {v1}, Landroid/provider/Settings$Global;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;
    .line 18: move-result-object v4
    .line 19: const/4 v1, -1
    .line 20: const/4 v2, 6
    .line 21: const/4 v9, 0
    .line 22: invoke-static {v1, v9, v2}, Ld2/b;->b(ILp3/m;I)Lp3/h;
    .line 25: move-result-object v6
    .line 26: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    .line 29: move-result-object v1
    .line 30: invoke-static {v1}, Ld2/b;->S(Landroid/os/Looper;)Landroid/os/Handler;
    .line 33: move-result-object v1
    .line 34: new-instance v5, Landroidx/compose/ui/platform/f3;
    .line 36: const/4 v2, 0
    .line 37: invoke-direct {v5, v6, v1, v2}, Landroidx/compose/ui/platform/f3;-><init>(Lp3/h;Landroid/os/Handler;I)V
    .line 40: new-instance v1, Landroidx/compose/ui/platform/e3;
    .line 42: const/4 v8, 0
    .line 43: move-object v2, v1
    .line 44: move-object v7, v10
    .line 45: invoke-direct/range {v2 .. v8}, Landroidx/compose/ui/platform/e3;-><init>(Landroid/content/ContentResolver;Landroid/net/Uri;Landroidx/compose/ui/platform/f3;Lp3/o;Landroid/content/Context;Lw2/e;)V
    .line 48: new-instance v2, Lkotlinx/coroutines/flow/g;
    .line 50: invoke-direct {v2, v1}, Lkotlinx/coroutines/flow/g;-><init>(Ld3/e;)V
    .line 53: new-instance v1, Lkotlinx/coroutines/internal/d;
    .line 55: new-instance v3, Ln3/p1;
    .line 57: invoke-direct {v3, v9}, Ln3/a1;-><init>(Ln3/x0;)V
    .line 60: sget-object v4, Ln3/h0;->a:Lkotlinx/coroutines/scheduling/d;
    .line 62: sget-object v4, Lkotlinx/coroutines/internal/o;->a:Ln3/i1;
    .line 64: invoke-virtual {v3, v4}, Ln3/g1;->g(Lw2/j;)Lw2/j;
    .line 67: move-result-object v3
    .line 68: invoke-direct {v1, v3}, Lkotlinx/coroutines/internal/d;-><init>(Lw2/j;)V
    .line 71: new-instance v3, Lkotlinx/coroutines/flow/m0;
    .line 73: const-wide/16 v4, 0
    .line 75: const-wide v6, 0x7fffffffffffffff
    .line 80: invoke-direct {v3, v4, v5, v6, v7}, Lkotlinx/coroutines/flow/m0;-><init>(JJ)V
    .line 83: invoke-virtual {v10}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    .line 86: move-result-object v4
    .line 87: const-string v5, "animator_duration_scale"
    .line 89: const/high16 v6, 0x3f80
    .line 91: invoke-static {v4, v5, v6}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F
    .line 94: move-result v4
    .line 95: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 98: move-result-object v4
    .line 99: invoke-static {v2, v1, v3, v4}, Ld2/c;->C0(Lkotlinx/coroutines/flow/g;Lkotlinx/coroutines/internal/d;Lkotlinx/coroutines/flow/m0;Ljava/lang/Float;)Lkotlinx/coroutines/flow/y;
    .line 102: move-result-object v1
    .line 103: invoke-interface {v0, v10, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 106: goto :goto_109
    .line 107: move-exception v10
    .line 108: goto :goto_113
    .line 109: check-cast v1, Lkotlinx/coroutines/flow/n0;
    .line 111: monitor-exit v0
    .line 112: return-object v1
    .line 113: monitor-exit v0
    .line 114: throw v10
.end method

# direct methods
.method public static final b(Landroid/view/View;)Lu/e0;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const v0, 0x7f060026
    .line 8: invoke-virtual {v1, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 11: move-result-object v1
    .line 12: instance-of v0, v1, Lu/e0;
    .line 14: if-eqz v0, :cond_19
    .line 16: check-cast v1, Lu/e0;
    .line 18: goto :goto_20
    .line 19: const/4 v1, 0
    .line 20: return-object v1
.end method

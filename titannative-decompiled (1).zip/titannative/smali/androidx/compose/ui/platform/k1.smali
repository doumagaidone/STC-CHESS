.class public abstract interface Landroidx/compose/ui/platform/k1;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract A()F
.end method

# virtual methods
.method public abstract B(I)V
.end method

# virtual methods
.method public abstract C()Z
.end method

# virtual methods
.method public abstract D()I
.end method

# virtual methods
.method public abstract E()V
.end method

# virtual methods
.method public abstract F(Landroid/graphics/Canvas;)V
.end method

# virtual methods
.method public abstract G()I
.end method

# virtual methods
.method public abstract H()I
.end method

# virtual methods
.method public abstract I(Z)V
.end method

# virtual methods
.method public abstract J()I
.end method

# virtual methods
.method public abstract K(I)V
.end method

# virtual methods
.method public abstract L(I)V
.end method

# virtual methods
.method public abstract a()F
.end method

# virtual methods
.method public abstract b(F)V
.end method

# virtual methods
.method public abstract c(F)V
.end method

# virtual methods
.method public abstract d(F)V
.end method

# virtual methods
.method public abstract e(F)V
.end method

# virtual methods
.method public abstract f(F)V
.end method

# virtual methods
.method public abstract g(F)V
.end method

# virtual methods
.method public abstract h(F)V
.end method

# virtual methods
.method public abstract i()Z
.end method

# virtual methods
.method public abstract j(F)V
.end method

# virtual methods
.method public abstract k(F)V
.end method

# virtual methods
.method public abstract l(F)V
.end method

# virtual methods
.method public abstract m(I)V
.end method

# virtual methods
.method public abstract n(Z)V
.end method

# virtual methods
.method public abstract o(Landroid/graphics/Outline;)V
.end method

# virtual methods
.method public abstract p(I)V
.end method

# virtual methods
.method public abstract q(IIII)Z
.end method

# virtual methods
.method public abstract r(F)V
.end method

# virtual methods
.method public abstract s(F)V
.end method

# virtual methods
.method public abstract t(Lu/d;Lk0/c0;Ld3/c;)V
.end method

# virtual methods
.method public abstract u()I
.end method

# virtual methods
.method public abstract v()Z
.end method

# virtual methods
.method public abstract w(Landroid/graphics/Matrix;)V
.end method

# virtual methods
.method public abstract x()I
.end method

# virtual methods
.method public abstract y()Z
.end method

# virtual methods
.method public abstract z()V
.end method

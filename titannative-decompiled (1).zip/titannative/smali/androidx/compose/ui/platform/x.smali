.class public final Landroidx/compose/ui/platform/x;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/View$OnAttachStateChangeListener;

.field public final synthetic a:I
.field public final synthetic b:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Landroidx/compose/ui/platform/x;->a:I
    .line 5: iput-object v2, v0, Landroidx/compose/ui/platform/x;->b:Ljava/lang/Object;
    .line 7: return-void
.end method

# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .registers 6

    .line 0: iget v0, v4, Landroidx/compose/ui/platform/x;->a:I
    .line 2: const-string v1, "v"
    .line 4: packed-switch v0, :data_70
    .line 7: invoke-static {v5, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: return-void
    .line 11: invoke-static {v5, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: return-void
    .line 15: const-string v0, "view"
    .line 17: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: iget-object v0, v4, Landroidx/compose/ui/platform/x;->b:Ljava/lang/Object;
    .line 22: check-cast v0, Landroidx/compose/ui/platform/j0;
    .line 24: iget-object v1, v0, Landroidx/compose/ui/platform/j0;->f:Landroid/view/accessibility/AccessibilityManager;
    .line 26: iget-object v2, v0, Landroidx/compose/ui/platform/j0;->g:Landroidx/compose/ui/platform/v;
    .line 28: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityManager;->addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;)Z
    .line 31: iget-object v1, v0, Landroidx/compose/ui/platform/j0;->f:Landroid/view/accessibility/AccessibilityManager;
    .line 33: iget-object v2, v0, Landroidx/compose/ui/platform/j0;->h:Landroidx/compose/ui/platform/w;
    .line 35: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityManager;->addTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z
    .line 38: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 40: const/16 v2, 30
    .line 42: if-lt v1, v2, :cond_48
    .line 44: const/4 v2, 1
    .line 45: invoke-static {v5, v2}, Lb1/h;->a(Landroid/view/View;I)V
    .line 48: const/16 v2, 29
    .line 50: const/4 v3, 0
    .line 51: if-lt v1, v2, :cond_66
    .line 53: invoke-static {v5}, Lb1/g;->a(Landroid/view/View;)Landroid/view/contentcapture/ContentCaptureSession;
    .line 56: move-result-object v1
    .line 57: if-nez v1, :cond_60
    .line 59: goto :goto_66
    .line 60: new-instance v3, Lo/g2;
    .line 62: const/4 v2, 7
    .line 63: invoke-direct {v3, v1, v2, v5}, Lo/g2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 66: iput-object v3, v0, Landroidx/compose/ui/platform/j0;->t:Lo/g2;
    .line 68: return-void
    .line 69: nop
    .line 70: nop
    .line 71: move/from16 v0, v0
    .line 73: nop
    .line 74: move-result-wide v0
    .line 75: nop
    .line 76: move-object v0, v0
    .line 77: nop
.end method

# virtual methods
.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .registers 7

    .line 0: iget v0, v5, Landroidx/compose/ui/platform/x;->a:I
    .line 2: const-string v1, "v"
    .line 4: const/4 v2, 0
    .line 5: iget-object v3, v5, Landroidx/compose/ui/platform/x;->b:Ljava/lang/Object;
    .line 7: packed-switch v0, :data_124
    .line 10: invoke-static {v6, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: invoke-virtual {v6, v5}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V
    .line 16: check-cast v3, Ln3/x0;
    .line 18: invoke-interface {v3, v2}, Ln3/x0;->a(Ljava/util/concurrent/CancellationException;)V
    .line 21: return-void
    .line 22: invoke-static {v6, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: check-cast v3, Landroidx/compose/ui/platform/a;
    .line 27: const-string v6, "<this>"
    .line 29: invoke-static {v3, v6}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 32: invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 35: move-result-object v0
    .line 36: sget-object v1, Le2/t;->q:Le2/t;
    .line 38: invoke-static {v0, v1}, Lc3/d;->E1(Ljava/lang/Object;Ld3/c;)Ll3/h;
    .line 41: move-result-object v0
    .line 42: invoke-interface {v0}, Ll3/h;->iterator()Ljava/util/Iterator;
    .line 45: move-result-object v0
    .line 46: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 49: move-result v1
    .line 50: if-eqz v1, :cond_91
    .line 52: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 55: move-result-object v1
    .line 56: check-cast v1, Landroid/view/ViewParent;
    .line 58: instance-of v4, v1, Landroid/view/View;
    .line 60: if-eqz v4, :cond_46
    .line 62: check-cast v1, Landroid/view/View;
    .line 64: invoke-static {v1, v6}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 67: const v4, 0x7f060035
    .line 70: invoke-virtual {v1, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 73: move-result-object v1
    .line 74: instance-of v4, v1, Ljava/lang/Boolean;
    .line 76: if-eqz v4, :cond_81
    .line 78: check-cast v1, Ljava/lang/Boolean;
    .line 80: goto :goto_82
    .line 81: move-object v1, v2
    .line 82: if-eqz v1, :cond_46
    .line 84: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    .line 87: move-result v1
    .line 88: if-eqz v1, :cond_46
    .line 90: goto :goto_94
    .line 91: invoke-virtual {v3}, Landroidx/compose/ui/platform/a;->c()V
    .line 94: return-void
    .line 95: const-string v0, "view"
    .line 97: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 100: check-cast v3, Landroidx/compose/ui/platform/j0;
    .line 102: iget-object v6, v3, Landroidx/compose/ui/platform/j0;->j:Landroid/os/Handler;
    .line 104: iget-object v0, v3, Landroidx/compose/ui/platform/j0;->H:Landroidx/activity/d;
    .line 106: invoke-virtual {v6, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    .line 109: iget-object v6, v3, Landroidx/compose/ui/platform/j0;->f:Landroid/view/accessibility/AccessibilityManager;
    .line 111: iget-object v0, v3, Landroidx/compose/ui/platform/j0;->g:Landroidx/compose/ui/platform/v;
    .line 113: invoke-virtual {v6, v0}, Landroid/view/accessibility/AccessibilityManager;->removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;)Z
    .line 116: iget-object v0, v3, Landroidx/compose/ui/platform/j0;->h:Landroidx/compose/ui/platform/w;
    .line 118: invoke-virtual {v6, v0}, Landroid/view/accessibility/AccessibilityManager;->removeTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z
    .line 121: iput-object v2, v3, Landroidx/compose/ui/platform/j0;->t:Lo/g2;
    .line 123: return-void
    .line 124: nop
    .line 125: move/from16 v0, v0
    .line 127: nop
    .line 128: iget-short v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 130: return v0
    .line 131: nop
.end method

.class public abstract interface Landroidx/compose/ui/platform/u2;
.super Ljava/lang/Object;
.source "SourceFile"

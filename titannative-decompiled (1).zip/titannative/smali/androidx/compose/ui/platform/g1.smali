.class public abstract Landroidx/compose/ui/platform/g1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lb0/c;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: sget-object v0, Landroidx/compose/ui/platform/f1;->k:Landroidx/compose/ui/platform/f1;
    .line 2: const v1, 0x97212992
    .line 5: const/4 v2, 0
    .line 6: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Landroidx/compose/ui/platform/g1;->a:Lb0/c;
    .line 12: return-void
.end method

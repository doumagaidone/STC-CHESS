.class public abstract interface Landroidx/compose/ui/platform/i;
.super Ljava/lang/Object;
.source "SourceFile"

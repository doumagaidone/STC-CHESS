.class public final Landroidx/compose/ui/platform/z0;
.super Landroid/view/ViewGroup;
.source "SourceFile"

.field public final i:Ljava/util/HashMap;
.field public final j:Ljava/util/HashMap;

# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 0: invoke-direct {v0, v1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V
    .line 3: const/4 v1, 0
    .line 4: invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setClipChildren(Z)V
    .line 7: new-instance v1, Ljava/util/HashMap;
    .line 9: invoke-direct {v1}, Ljava/util/HashMap;-><init>()V
    .line 12: iput-object v1, v0, Landroidx/compose/ui/platform/z0;->i:Ljava/util/HashMap;
    .line 14: new-instance v1, Ljava/util/HashMap;
    .line 16: invoke-direct {v1}, Ljava/util/HashMap;-><init>()V
    .line 19: iput-object v1, v0, Landroidx/compose/ui/platform/z0;->j:Ljava/util/HashMap;
    .line 21: return-void
.end method

# virtual methods
.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 2

    .line 0: const/4 v1, 1
    .line 1: return v1
.end method

# virtual methods
.method public final getHolderToLayoutNode()Ljava/util/HashMap;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/z0;->i:Ljava/util/HashMap;
    .line 2: return-object v0
.end method

# virtual methods
.method public final getLayoutNodeToHolder()Ljava/util/HashMap;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/compose/ui/platform/z0;->j:Ljava/util/HashMap;
    .line 2: return-object v0
.end method

# virtual methods
.method public final bridge synthetic invalidateChildInParent([ILandroid/graphics/Rect;)Landroid/view/ViewParent;
    .registers 3

    .line 0: const/4 v1, 0
    .line 1: return-object v1
.end method

# virtual methods
.method public final onDescendantInvalidated(Landroid/view/View;Landroid/view/View;)V
    .registers 4

    .line 0: const-string v0, "child"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v2, "target"
    .line 7: invoke-static {v3, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: return-void
.end method

# virtual methods
.method public final onLayout(ZIIII)V
    .registers 6

    .line 0: iget-object v1, v0, Landroidx/compose/ui/platform/z0;->i:Ljava/util/HashMap;
    .line 2: invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;
    .line 5: move-result-object v1
    .line 6: const-string v2, "holderToLayoutNode.keys"
    .line 8: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: check-cast v1, Ljava/lang/Iterable;
    .line 13: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 16: move-result-object v1
    .line 17: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 20: move-result v2
    .line 21: if-nez v2, :cond_24
    .line 23: return-void
    .line 24: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 27: move-result-object v1
    .line 28: invoke-static {v1}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 31: const/4 v1, 0
    .line 32: throw v1
.end method

# virtual methods
.method public final onMeasure(II)V
    .registers 6

    .line 0: invoke-static {v4}, Landroid/view/View$MeasureSpec;->getMode(I)I
    .line 3: move-result v0
    .line 4: const-string v1, "Failed requirement."
    .line 6: const/high16 v2, 0x4000
    .line 8: if-ne v0, v2, :cond_70
    .line 10: invoke-static {v5}, Landroid/view/View$MeasureSpec;->getMode(I)I
    .line 13: move-result v0
    .line 14: if-ne v0, v2, :cond_60
    .line 16: invoke-static {v4}, Landroid/view/View$MeasureSpec;->getSize(I)I
    .line 19: move-result v4
    .line 20: invoke-static {v5}, Landroid/view/View$MeasureSpec;->getSize(I)I
    .line 23: move-result v5
    .line 24: invoke-virtual {v3, v4, v5}, Landroid/view/View;->setMeasuredDimension(II)V
    .line 27: iget-object v4, v3, Landroidx/compose/ui/platform/z0;->i:Ljava/util/HashMap;
    .line 29: invoke-virtual {v4}, Ljava/util/HashMap;->keySet()Ljava/util/Set;
    .line 32: move-result-object v4
    .line 33: const-string v5, "holderToLayoutNode.keys"
    .line 35: invoke-static {v4, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 38: check-cast v4, Ljava/lang/Iterable;
    .line 40: invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 43: move-result-object v4
    .line 44: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 47: move-result v5
    .line 48: if-nez v5, :cond_51
    .line 50: return-void
    .line 51: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 54: move-result-object v4
    .line 55: invoke-static {v4}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 58: const/4 v4, 0
    .line 59: throw v4
    .line 60: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 62: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 65: move-result-object v5
    .line 66: invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 69: throw v4
    .line 70: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 72: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 75: move-result-object v5
    .line 76: invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 79: throw v4
.end method

# virtual methods
.method public final requestLayout()V
    .registers 6

    .line 0: invoke-virtual {v5, v5}, Landroid/view/ViewGroup;->cleanupLayoutState(Landroid/view/View;)V
    .line 3: invoke-virtual {v5}, Landroid/view/ViewGroup;->getChildCount()I
    .line 6: move-result v0
    .line 7: const/4 v1, 0
    .line 8: move v2, v1
    .line 9: if-ge v2, v0, :cond_38
    .line 11: invoke-virtual {v5, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 14: move-result-object v3
    .line 15: iget-object v4, v5, Landroidx/compose/ui/platform/z0;->i:Ljava/util/HashMap;
    .line 17: invoke-virtual {v4, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 20: move-result-object v4
    .line 21: check-cast v4, Landroidx/compose/ui/node/a;
    .line 23: invoke-virtual {v3}, Landroid/view/View;->isLayoutRequested()Z
    .line 26: move-result v3
    .line 27: if-eqz v3, :cond_35
    .line 29: if-eqz v4, :cond_35
    .line 31: const/4 v3, 3
    .line 32: invoke-static {v4, v1, v3}, Landroidx/compose/ui/node/a;->F(Landroidx/compose/ui/node/a;ZI)V
    .line 35: add-int/lit8 v2, v2, 1
    .line 37: goto :goto_9
    .line 38: return-void
.end method

# virtual methods
.method public final shouldDelayChildPressedState()Z
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

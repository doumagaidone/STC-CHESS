.class public abstract Landroidx/compose/ui/platform/u1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static a:Z

# direct methods
.method public static final a(Lf0/p;Ld3/c;Lf0/p;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "wrapped"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/ui/platform/t1;
    .line 12: invoke-direct {v0, v2}, Landroidx/compose/ui/platform/t1;-><init>(Ld3/c;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: invoke-interface {v1, v3}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 22: move-result-object v1
    .line 23: iget-object v2, v0, Landroidx/compose/ui/platform/t1;->d:Landroidx/compose/ui/platform/s1;
    .line 25: invoke-interface {v1, v2}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 28: move-result-object v1
    .line 29: return-object v1
.end method

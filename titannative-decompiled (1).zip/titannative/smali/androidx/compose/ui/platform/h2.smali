.class public final Landroidx/compose/ui/platform/h2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld1/n;
.field public final b:Landroid/graphics/Rect;

# direct methods
.method public constructor <init>(Ld1/n;Landroid/graphics/Rect;)V
    .registers 4

    .line 0: const-string v0, "semanticsNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Landroidx/compose/ui/platform/h2;->a:Ld1/n;
    .line 10: iput-object v3, v1, Landroidx/compose/ui/platform/h2;->b:Landroid/graphics/Rect;
    .line 12: return-void
.end method

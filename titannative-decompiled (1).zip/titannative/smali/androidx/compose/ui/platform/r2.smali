.class public abstract synthetic Landroidx/compose/ui/platform/r2;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static bridge synthetic a(Landroid/content/pm/PackageInfo;)J
    .registers 3

    .line 0: invoke-virtual {v2}, Landroid/content/pm/PackageInfo;->getLongVersionCode()J
    .line 3: move-result-wide v0
    .line 4: return-wide v0
.end method

# direct methods
.method public static bridge synthetic b(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;
    .registers 3

    .line 0: invoke-static {v0, v1, v2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic c(Landroid/os/Looper;)Landroid/os/Handler;
    .registers 1

    .line 0: invoke-static {v0}, Landroid/os/Handler;->createAsync(Landroid/os/Looper;)Landroid/os/Handler;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic d()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_HIDE_TOOLTIP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic e(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/CharSequence;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getTooltipText()Ljava/lang/CharSequence;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic f(Landroid/text/StaticLayout$Builder;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setUseLineSpacingFromFallbacks(Z)Landroid/text/StaticLayout$Builder;
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic g(Landroid/view/View;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setOutlineSpotShadowColor(I)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic h(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setPaneTitle(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic i(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setScreenReaderFocusable(Z)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic j(Landroid/text/Spannable;)Z
    .registers 1

    .line 0: instance-of v0, v0, Landroid/text/PrecomputedText;
    .line 2: return v0
.end method

# direct methods
.method public static bridge synthetic k()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SHOW_TOOLTIP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic l(Landroid/view/View;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setOutlineAmbientShadowColor(I)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic m(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setHeading(Z)V
    .line 3: return-void
.end method

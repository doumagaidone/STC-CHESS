.class public final Landroidx/compose/ui/platform/i0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/Comparator;

# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 6

    .line 0: check-cast v4, Ld1/n;
    .line 2: invoke-virtual {v4}, Ld1/n;->h()Ld1/i;
    .line 5: move-result-object v0
    .line 6: sget-object v1, Ld1/q;->n:Ld1/t;
    .line 8: invoke-virtual {v0, v1}, Ld1/i;->b(Ld1/t;)Z
    .line 11: move-result v0
    .line 12: const/4 v2, 0
    .line 13: if-eqz v0, :cond_30
    .line 15: invoke-virtual {v4}, Ld1/n;->h()Ld1/i;
    .line 18: move-result-object v4
    .line 19: invoke-virtual {v4, v1}, Ld1/i;->c(Ld1/t;)Ljava/lang/Object;
    .line 22: move-result-object v4
    .line 23: check-cast v4, Ljava/lang/Number;
    .line 25: invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F
    .line 28: move-result v4
    .line 29: goto :goto_31
    .line 30: move v4, v2
    .line 31: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 34: move-result-object v4
    .line 35: check-cast v5, Ld1/n;
    .line 37: invoke-virtual {v5}, Ld1/n;->h()Ld1/i;
    .line 40: move-result-object v0
    .line 41: invoke-virtual {v0, v1}, Ld1/i;->b(Ld1/t;)Z
    .line 44: move-result v0
    .line 45: if-eqz v0, :cond_61
    .line 47: invoke-virtual {v5}, Ld1/n;->h()Ld1/i;
    .line 50: move-result-object v5
    .line 51: invoke-virtual {v5, v1}, Ld1/i;->c(Ld1/t;)Ljava/lang/Object;
    .line 54: move-result-object v5
    .line 55: check-cast v5, Ljava/lang/Number;
    .line 57: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 60: move-result v2
    .line 61: invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 64: move-result-object v5
    .line 65: invoke-static {v4, v5}, Ld2/c;->x(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .line 68: move-result v4
    .line 69: return v4
.end method

.class public final Landroidx/compose/ui/platform/x1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/x1;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/x1;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/x1;->a:Landroidx/compose/ui/platform/x1;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/MotionEvent;I)Z
    .registers 5

    .line 0: const-string v0, "event"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v3, v4}, Lk0/j;->a(Landroid/view/MotionEvent;I)F
    .line 8: move-result v0
    .line 9: invoke-static {v0}, Ljava/lang/Float;->isInfinite(F)Z
    .line 12: move-result v1
    .line 13: if-nez v1, :cond_39
    .line 15: invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z
    .line 18: move-result v0
    .line 19: if-nez v0, :cond_39
    .line 21: invoke-static {v3, v4}, Lk0/j;->j(Landroid/view/MotionEvent;I)F
    .line 24: move-result v3
    .line 25: invoke-static {v3}, Ljava/lang/Float;->isInfinite(F)Z
    .line 28: move-result v4
    .line 29: if-nez v4, :cond_39
    .line 31: invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z
    .line 34: move-result v3
    .line 35: if-nez v3, :cond_39
    .line 37: const/4 v3, 1
    .line 38: goto :goto_40
    .line 39: const/4 v3, 0
    .line 40: return v3
.end method

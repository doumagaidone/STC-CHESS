.class public final synthetic Landroidx/compose/ui/platform/w;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;

.field public final synthetic a:Landroidx/compose/ui/platform/j0;

# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/platform/j0;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/w;->a:Landroidx/compose/ui/platform/j0;
    .line 5: return-void
.end method

# virtual methods
.method public final onTouchExplorationStateChanged(Z)V
    .registers 4

    .line 0: const-string v3, "this$0"
    .line 2: iget-object v0, v2, Landroidx/compose/ui/platform/w;->a:Landroidx/compose/ui/platform/j0;
    .line 4: invoke-static {v0, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: iget-object v3, v0, Landroidx/compose/ui/platform/j0;->f:Landroid/view/accessibility/AccessibilityManager;
    .line 9: const/4 v1, -1
    .line 10: invoke-virtual {v3, v1}, Landroid/view/accessibility/AccessibilityManager;->getEnabledAccessibilityServiceList(I)Ljava/util/List;
    .line 13: move-result-object v3
    .line 14: iput-object v3, v0, Landroidx/compose/ui/platform/j0;->i:Ljava/util/List;
    .line 16: return-void
.end method

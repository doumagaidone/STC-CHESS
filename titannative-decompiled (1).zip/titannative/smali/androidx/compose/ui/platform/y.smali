.class public abstract Landroidx/compose/ui/platform/y;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static final a(Lf2/k;Ld1/n;)V
    .registers 5

    .line 0: const-string v0, "info"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "semanticsNode"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {v4}, Landroidx/compose/ui/platform/n1;->k(Ld1/n;)Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_42
    .line 16: sget-object v0, Ld1/h;->e:Ld1/t;
    .line 18: iget-object v4, v4, Ld1/n;->d:Ld1/i;
    .line 20: invoke-static {v4, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 23: move-result-object v4
    .line 24: check-cast v4, Ld1/a;
    .line 26: if-eqz v4, :cond_42
    .line 28: new-instance v0, Lf2/e;
    .line 30: const/4 v1, 0
    .line 31: const v2, 0x102003d
    .line 34: iget-object v4, v4, Ld1/a;->a:Ljava/lang/String;
    .line 36: invoke-direct {v0, v1, v2, v4, v1}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 39: invoke-virtual {v3, v0}, Lf2/k;->a(Lf2/e;)V
    .line 42: return-void
.end method

.class public abstract Landroidx/compose/ui/platform/p0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/w0;
.field public static final b:Lu/j3;
.field public static final c:Lu/j3;
.field public static final d:Lu/j3;
.field public static final e:Lu/j3;
.field public static final f:Lu/j3;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Landroidx/compose/ui/platform/n0;->k:Landroidx/compose/ui/platform/n0;
    .line 2: invoke-static {v0}, Le3/g;->o(Ld3/a;)Lu/w0;
    .line 5: move-result-object v0
    .line 6: sput-object v0, Landroidx/compose/ui/platform/p0;->a:Lu/w0;
    .line 8: sget-object v0, Landroidx/compose/ui/platform/n0;->l:Landroidx/compose/ui/platform/n0;
    .line 10: new-instance v1, Lu/j3;
    .line 12: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 15: sput-object v1, Landroidx/compose/ui/platform/p0;->b:Lu/j3;
    .line 17: sget-object v0, Landroidx/compose/ui/platform/n0;->m:Landroidx/compose/ui/platform/n0;
    .line 19: new-instance v1, Lu/j3;
    .line 21: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 24: sput-object v1, Landroidx/compose/ui/platform/p0;->c:Lu/j3;
    .line 26: sget-object v0, Landroidx/compose/ui/platform/n0;->n:Landroidx/compose/ui/platform/n0;
    .line 28: new-instance v1, Lu/j3;
    .line 30: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 33: sput-object v1, Landroidx/compose/ui/platform/p0;->d:Lu/j3;
    .line 35: sget-object v0, Landroidx/compose/ui/platform/n0;->o:Landroidx/compose/ui/platform/n0;
    .line 37: new-instance v1, Lu/j3;
    .line 39: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 42: sput-object v1, Landroidx/compose/ui/platform/p0;->e:Lu/j3;
    .line 44: sget-object v0, Landroidx/compose/ui/platform/n0;->p:Landroidx/compose/ui/platform/n0;
    .line 46: new-instance v1, Lu/j3;
    .line 48: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 51: sput-object v1, Landroidx/compose/ui/platform/p0;->f:Lu/j3;
    .line 53: return-void
.end method

# direct methods
.method public static final a(Landroidx/compose/ui/platform/AndroidComposeView;Ld3/e;Lu/l;I)V
    .registers 26

    .line 0: move-object/from16 v6, v22
    .line 2: move-object/from16 v7, v23
    .line 4: const-string v0, "owner"
    .line 6: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: const-string v1, "content"
    .line 11: invoke-static {v7, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: move-object/from16 v8, v24
    .line 16: check-cast v8, Lu/b0;
    .line 18: const v1, 0x5342453c
    .line 21: invoke-virtual {v8, v1}, Lu/b0;->e0(I)Lu/b0;
    .line 24: invoke-virtual/range {v22 .. v22}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 27: move-result-object v1
    .line 28: const v2, 0xe2a708a4
    .line 31: invoke-virtual {v8, v2}, Lu/b0;->d0(I)V
    .line 34: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 37: move-result-object v3
    .line 38: sget-object v4, Lu/k;->i:Landroidx/activity/b;
    .line 40: if-ne v3, v4, :cond_64
    .line 42: new-instance v3, Landroid/content/res/Configuration;
    .line 44: invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 47: move-result-object v5
    .line 48: invoke-virtual {v5}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    .line 51: move-result-object v5
    .line 52: invoke-direct {v3, v5}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V
    .line 55: sget-object v5, Lu/l3;->a:Lu/l3;
    .line 57: invoke-static {v3, v5}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 60: move-result-object v3
    .line 61: invoke-virtual {v8, v3}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 64: const/4 v5, 0
    .line 65: invoke-virtual {v8, v5}, Lu/b0;->t(Z)V
    .line 68: check-cast v3, Lu/l1;
    .line 70: const v9, 0x44faf204
    .line 73: invoke-virtual {v8, v9}, Lu/b0;->d0(I)V
    .line 76: invoke-virtual {v8, v3}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 79: move-result v9
    .line 80: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 83: move-result-object v10
    .line 84: const/4 v11, 1
    .line 85: if-nez v9, :cond_89
    .line 87: if-ne v10, v4, :cond_97
    .line 89: new-instance v10, Li/o1;
    .line 91: invoke-direct {v10, v3, v11}, Li/o1;-><init>(Lu/l1;I)V
    .line 94: invoke-virtual {v8, v10}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 97: invoke-virtual {v8, v5}, Lu/b0;->t(Z)V
    .line 100: check-cast v10, Ld3/c;
    .line 102: invoke-virtual {v6, v10}, Landroidx/compose/ui/platform/AndroidComposeView;->setConfigurationChangeObserver(Ld3/c;)V
    .line 105: invoke-virtual {v8, v2}, Lu/b0;->d0(I)V
    .line 108: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 111: move-result-object v9
    .line 112: const-string v10, "context"
    .line 114: if-ne v9, v4, :cond_127
    .line 116: new-instance v9, Landroidx/compose/ui/platform/x0;
    .line 118: invoke-static {v1, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 121: invoke-direct {v9}, Ljava/lang/Object;-><init>()V
    .line 124: invoke-virtual {v8, v9}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 127: invoke-virtual {v8, v5}, Lu/b0;->t(Z)V
    .line 130: check-cast v9, Landroidx/compose/ui/platform/x0;
    .line 132: invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/platform/AndroidComposeView;->getViewTreeOwners()Landroidx/compose/ui/platform/q;
    .line 135: move-result-object v12
    .line 136: if-eqz v12, :cond_556
    .line 138: invoke-virtual {v8, v2}, Lu/b0;->d0(I)V
    .line 141: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 144: move-result-object v13
    .line 145: iget-object v14, v12, Landroidx/compose/ui/platform/q;->b:Ll2/f;
    .line 147: if-ne v13, v4, :cond_326
    .line 149: invoke-static {v14, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 152: invoke-virtual/range {v22 .. v22}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 155: move-result-object v0
    .line 156: const-string v13, "null cannot be cast to non-null type android.view.View"
    .line 158: invoke-static {v0, v13}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 161: check-cast v0, Landroid/view/View;
    .line 163: const v13, 0x7f06002a
    .line 166: invoke-virtual {v0, v13}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 169: move-result-object v13
    .line 170: instance-of v15, v13, Ljava/lang/String;
    .line 172: const/16 v16, 0
    .line 174: if-eqz v15, :cond_179
    .line 176: check-cast v13, Ljava/lang/String;
    .line 178: goto :goto_181
    .line 179: move-object/from16 v13, v16
    .line 181: if-nez v13, :cond_191
    .line 183: invoke-virtual {v0}, Landroid/view/View;->getId()I
    .line 186: move-result v0
    .line 187: invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 190: move-result-object v13
    .line 191: const-string v0, "id"
    .line 193: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 196: new-instance v0, Ljava/lang/StringBuilder;
    .line 198: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 201: const-class v15, Lc0/e;
    .line 203: invoke-virtual {v15}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    .line 206: move-result-object v15
    .line 207: invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 210: const/16 v15, 58
    .line 212: invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 215: invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 218: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 221: move-result-object v0
    .line 222: invoke-interface {v14}, Ll2/f;->getSavedStateRegistry()Ll2/d;
    .line 225: move-result-object v13
    .line 226: invoke-virtual {v13, v0}, Ll2/d;->a(Ljava/lang/String;)Landroid/os/Bundle;
    .line 229: move-result-object v15
    .line 230: if-eqz v15, :cond_290
    .line 232: new-instance v11, Ljava/util/LinkedHashMap;
    .line 234: invoke-direct {v11}, Ljava/util/LinkedHashMap;-><init>()V
    .line 237: invoke-virtual {v15}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;
    .line 240: move-result-object v2
    .line 241: const-string v5, "this.keySet()"
    .line 243: invoke-static {v2, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 246: check-cast v2, Ljava/lang/Iterable;
    .line 248: invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 251: move-result-object v2
    .line 252: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 255: move-result v5
    .line 256: if-eqz v5, :cond_292
    .line 258: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 261: move-result-object v5
    .line 262: check-cast v5, Ljava/lang/String;
    .line 264: move-object/from16 v16, v2
    .line 266: invoke-virtual {v15, v5}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 269: move-result-object v2
    .line 270: move-object/from16 v19, v15
    .line 272: const-string v15, "null cannot be cast to non-null type java.util.ArrayList<kotlin.Any?>{ kotlin.collections.TypeAliasesKt.ArrayList<kotlin.Any?> }"
    .line 274: invoke-static {v2, v15}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 277: const-string v15, "key"
    .line 279: invoke-static {v5, v15}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 282: invoke-interface {v11, v5, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 285: move-object/from16 v2, v16
    .line 287: move-object/from16 v15, v19
    .line 289: goto :goto_252
    .line 290: move-object/from16 v11, v16
    .line 292: sget-object v2, Lc0/i;->a:Lu/j3;
    .line 294: new-instance v2, Lc0/g;
    .line 296: invoke-direct {v2, v11}, Lc0/g;-><init>(Ljava/util/LinkedHashMap;)V
    .line 299: new-instance v5, Landroidx/compose/ui/platform/m1;
    .line 301: invoke-direct {v5, v2}, Landroidx/compose/ui/platform/m1;-><init>(Lc0/g;)V
    .line 304: invoke-virtual {v13, v0, v5}, Ll2/d;->c(Ljava/lang/String;Ll2/c;)V
    .line 307: const/4 v5, 1
    .line 308: goto :goto_310
    .line 309: const/4 v5, 0
    .line 310: new-instance v11, Landroidx/compose/ui/platform/l1;
    .line 312: new-instance v15, Lo/c0;
    .line 314: invoke-direct {v15, v5, v13, v0}, Lo/c0;-><init>(ZLl2/d;Ljava/lang/String;)V
    .line 317: invoke-direct {v11, v2, v15}, Landroidx/compose/ui/platform/l1;-><init>(Lc0/g;Lo/c0;)V
    .line 320: invoke-virtual {v8, v11}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 323: move-object v13, v11
    .line 324: const/4 v0, 0
    .line 325: goto :goto_327
    .line 326: move v0, v5
    .line 327: invoke-virtual {v8, v0}, Lu/b0;->t(Z)V
    .line 330: check-cast v13, Landroidx/compose/ui/platform/l1;
    .line 332: sget-object v0, Ls2/k;->a:Ls2/k;
    .line 334: new-instance v2, Lg/n;
    .line 336: const/16 v5, 27
    .line 338: invoke-direct {v2, v5, v13}, Lg/n;-><init>(ILjava/lang/Object;)V
    .line 341: invoke-static {v0, v2, v8}, Lu/c0;->a(Ljava/lang/Object;Ld3/c;Lu/l;)V
    .line 344: invoke-static {v1, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 347: invoke-interface {v3}, Lu/i3;->getValue()Ljava/lang/Object;
    .line 350: move-result-object v0
    .line 351: check-cast v0, Landroid/content/res/Configuration;
    .line 353: const v2, 0xe309a0ba
    .line 356: invoke-virtual {v8, v2}, Lu/b0;->d0(I)V
    .line 359: const v2, 0xe2a708a4
    .line 362: invoke-virtual {v8, v2}, Lu/b0;->d0(I)V
    .line 365: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 368: move-result-object v2
    .line 369: if-ne v2, v4, :cond_379
    .line 371: new-instance v2, Lc1/c;
    .line 373: invoke-direct {v2}, Lc1/c;-><init>()V
    .line 376: invoke-virtual {v8, v2}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 379: const/4 v5, 0
    .line 380: invoke-virtual {v8, v5}, Lu/b0;->t(Z)V
    .line 383: check-cast v2, Lc1/c;
    .line 385: const v5, 0xe2a708a4
    .line 388: invoke-virtual {v8, v5}, Lu/b0;->d0(I)V
    .line 391: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 394: move-result-object v5
    .line 395: if-ne v5, v4, :cond_410
    .line 397: new-instance v5, Landroid/content/res/Configuration;
    .line 399: invoke-direct {v5}, Landroid/content/res/Configuration;-><init>()V
    .line 402: if-eqz v0, :cond_407
    .line 404: invoke-virtual {v5, v0}, Landroid/content/res/Configuration;->setTo(Landroid/content/res/Configuration;)V
    .line 407: invoke-virtual {v8, v5}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 410: const/4 v0, 0
    .line 411: invoke-virtual {v8, v0}, Lu/b0;->t(Z)V
    .line 414: check-cast v5, Landroid/content/res/Configuration;
    .line 416: const v0, 0xe2a708a4
    .line 419: invoke-virtual {v8, v0}, Lu/b0;->d0(I)V
    .line 422: invoke-virtual {v8}, Lu/b0;->I()Ljava/lang/Object;
    .line 425: move-result-object v0
    .line 426: if-ne v0, v4, :cond_436
    .line 428: new-instance v0, Landroidx/compose/ui/platform/o0;
    .line 430: invoke-direct {v0, v5, v2}, Landroidx/compose/ui/platform/o0;-><init>(Landroid/content/res/Configuration;Lc1/c;)V
    .line 433: invoke-virtual {v8, v0}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 436: const/4 v4, 0
    .line 437: invoke-virtual {v8, v4}, Lu/b0;->t(Z)V
    .line 440: check-cast v0, Landroidx/compose/ui/platform/o0;
    .line 442: new-instance v5, Landroidx/compose/ui/platform/j3;
    .line 444: const/4 v10, 1
    .line 445: invoke-direct {v5, v1, v10, v0}, Landroidx/compose/ui/platform/j3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 448: invoke-static {v2, v5, v8}, Lu/c0;->a(Ljava/lang/Object;Ld3/c;Lu/l;)V
    .line 451: invoke-virtual {v8, v4}, Lu/b0;->t(Z)V
    .line 454: invoke-interface {v3}, Lu/i3;->getValue()Ljava/lang/Object;
    .line 457: move-result-object v0
    .line 458: check-cast v0, Landroid/content/res/Configuration;
    .line 460: sget-object v3, Landroidx/compose/ui/platform/p0;->a:Lu/w0;
    .line 462: invoke-virtual {v3, v0}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 465: move-result-object v15
    .line 466: sget-object v0, Landroidx/compose/ui/platform/p0;->b:Lu/j3;
    .line 468: invoke-virtual {v0, v1}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 471: move-result-object v16
    .line 472: iget-object v0, v12, Landroidx/compose/ui/platform/q;->a:Landroidx/lifecycle/t;
    .line 474: sget-object v1, Landroidx/compose/ui/platform/p0;->d:Lu/j3;
    .line 476: invoke-virtual {v1, v0}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 479: move-result-object v17
    .line 480: sget-object v0, Landroidx/compose/ui/platform/p0;->e:Lu/j3;
    .line 482: invoke-virtual {v0, v14}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 485: move-result-object v18
    .line 486: sget-object v0, Lc0/i;->a:Lu/j3;
    .line 488: invoke-virtual {v0, v13}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 491: move-result-object v19
    .line 492: sget-object v0, Landroidx/compose/ui/platform/p0;->f:Lu/j3;
    .line 494: invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/platform/AndroidComposeView;->getView()Landroid/view/View;
    .line 497: move-result-object v1
    .line 498: invoke-virtual {v0, v1}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 501: move-result-object v20
    .line 502: sget-object v0, Landroidx/compose/ui/platform/p0;->c:Lu/j3;
    .line 504: invoke-virtual {v0, v2}, Lu/z1;->b(Ljava/lang/Object;)Lu/a2;
    .line 507: move-result-object v21
    .line 508: filled-new-array/range {v15 .. v21}, [Lu/a2;
    .line 511: move-result-object v10
    .line 512: new-instance v11, Lo/e0;
    .line 514: const/4 v5, 3
    .line 515: move-object v0, v11
    .line 516: move-object/from16 v1, v22
    .line 518: move-object v2, v9
    .line 519: move-object/from16 v3, v23
    .line 521: move/from16 v4, v25
    .line 523: invoke-direct/range {v0 .. v5}, Lo/e0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .line 526: const v0, 0x57b729fc
    .line 529: invoke-static {v8, v0, v11}, Ln3/a0;->A(Lu/l;ILe3/h;)Lb0/c;
    .line 532: move-result-object v0
    .line 533: const/16 v1, 56
    .line 535: invoke-static {v10, v0, v8, v1}, Le3/g;->d([Lu/a2;Ld3/e;Lu/l;I)V
    .line 538: invoke-virtual {v8}, Lu/b0;->x()Lu/c2;
    .line 541: move-result-object v0
    .line 542: if-nez v0, :cond_545
    .line 544: goto :goto_555
    .line 545: new-instance v1, Li/x;
    .line 547: const/4 v2, 6
    .line 548: move/from16 v3, v25
    .line 550: invoke-direct {v1, v3, v2, v6, v7}, Li/x;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .line 553: iput-object v1, v0, Lu/c2;->d:Ld3/e;
    .line 555: return-void
    .line 556: new-instance v0, Ljava/lang/IllegalStateException;
    .line 558: const-string v1, "Called when the ViewTreeOwnersAvailability is not yet in Available state"
    .line 560: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 563: throw v0
.end method

# direct methods
.method public static final b(Ljava/lang/String;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/IllegalStateException;
    .line 2: new-instance v1, Ljava/lang/StringBuilder;
    .line 4: const-string v2, "CompositionLocal "
    .line 6: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 9: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v3, " not present"
    .line 14: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 20: move-result-object v3
    .line 21: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 24: move-result-object v3
    .line 25: invoke-direct {v0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 28: throw v0
.end method

# direct methods
.method public static final c()Lu/j3;
    .registers 1

    .line 0: sget-object v0, Landroidx/compose/ui/platform/p0;->b:Lu/j3;
    .line 2: return-object v0
.end method

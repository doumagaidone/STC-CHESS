.class public final Landroidx/compose/ui/platform/s0;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"

.field public final synthetic a:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: iput v1, v0, Landroidx/compose/ui/platform/s0;->a:I
    .line 2: invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public final initialValue()Ljava/lang/Object;
    .registers 5

    .line 0: iget v0, v4, Landroidx/compose/ui/platform/s0;->a:I
    .line 2: packed-switch v0, :data_78
    .line 5: new-instance v0, Ljava/text/SimpleDateFormat;
    .line 7: const-string v1, "EEE, dd MMM yyyy HH:mm:ss 'GMT'"
    .line 9: sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;
    .line 11: invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V
    .line 14: const/4 v1, 0
    .line 15: invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setLenient(Z)V
    .line 18: sget-object v1, Ls3/b;->d:Ljava/util/TimeZone;
    .line 20: invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V
    .line 23: return-object v0
    .line 24: new-instance v0, Ljava/util/Random;
    .line 26: invoke-direct {v0}, Ljava/util/Random;-><init>()V
    .line 29: return-object v0
    .line 30: new-instance v0, Landroidx/compose/ui/platform/u0;
    .line 32: invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;
    .line 35: move-result-object v1
    .line 36: const-string v2, "getInstance()"
    .line 38: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 41: invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;
    .line 44: move-result-object v2
    .line 45: if-eqz v2, :cond_66
    .line 47: invoke-static {v2}, Ld2/b;->S(Landroid/os/Looper;)Landroid/os/Handler;
    .line 50: move-result-object v2
    .line 51: const-string v3, "createAsync(\n           …d\")\n                    )"
    .line 53: invoke-static {v2, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 56: invoke-direct {v0, v1, v2}, Landroidx/compose/ui/platform/u0;-><init>(Landroid/view/Choreographer;Landroid/os/Handler;)V
    .line 59: iget-object v1, v0, Landroidx/compose/ui/platform/u0;->t:Landroidx/compose/ui/platform/w0;
    .line 61: invoke-virtual {v0, v1}, Lw2/a;->g(Lw2/j;)Lw2/j;
    .line 64: move-result-object v0
    .line 65: return-object v0
    .line 66: new-instance v0, Ljava/lang/IllegalStateException;
    .line 68: const-string v1, "no Looper on this thread"
    .line 70: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 73: move-result-object v1
    .line 74: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 77: throw v0
    .line 78: nop
    .line 79: move/from16 v0, v0
    .line 81: nop
    .line 82: const-class v0, B
    .line 84: const-wide/16 v0, 0
.end method

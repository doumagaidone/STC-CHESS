.class public final Landroidx/compose/ui/platform/d0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld1/n;
.field public final b:Ld1/i;
.field public final c:Ljava/util/LinkedHashSet;

# direct methods
.method public constructor <init>(Ld1/n;Ljava/util/Map;)V
    .registers 7

    .line 0: const-string v0, "semanticsNode"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "currentSemanticsNodes"
    .line 7: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 13: iput-object v5, v4, Landroidx/compose/ui/platform/d0;->a:Ld1/n;
    .line 15: iget-object v0, v5, Ld1/n;->d:Ld1/i;
    .line 17: iput-object v0, v4, Landroidx/compose/ui/platform/d0;->b:Ld1/i;
    .line 19: new-instance v0, Ljava/util/LinkedHashSet;
    .line 21: invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V
    .line 24: iput-object v0, v4, Landroidx/compose/ui/platform/d0;->c:Ljava/util/LinkedHashSet;
    .line 26: const/4 v0, 0
    .line 27: const/4 v1, 1
    .line 28: invoke-virtual {v5, v0, v1}, Ld1/n;->g(ZZ)Ljava/util/List;
    .line 31: move-result-object v5
    .line 32: invoke-interface {v5}, Ljava/util/List;->size()I
    .line 35: move-result v1
    .line 36: if-ge v0, v1, :cond_70
    .line 38: invoke-interface {v5, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 41: move-result-object v2
    .line 42: check-cast v2, Ld1/n;
    .line 44: iget v3, v2, Ld1/n;->g:I
    .line 46: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 49: move-result-object v3
    .line 50: invoke-interface {v6, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 53: move-result v3
    .line 54: if-eqz v3, :cond_67
    .line 56: iget-object v3, v4, Landroidx/compose/ui/platform/d0;->c:Ljava/util/LinkedHashSet;
    .line 58: iget v2, v2, Ld1/n;->g:I
    .line 60: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 63: move-result-object v2
    .line 64: invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    .line 67: add-int/lit8 v0, v0, 1
    .line 69: goto :goto_36
    .line 70: return-void
.end method

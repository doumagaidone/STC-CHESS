.class public final Landroidx/compose/ui/platform/f2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/f2;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/f2;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/f2;->a:Landroidx/compose/ui/platform/f2;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/RenderNode;)I
    .registers 3

    .line 0: const-string v0, "renderNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/view/RenderNode;->getAmbientShadowColor()I
    .line 8: move-result v2
    .line 9: return v2
.end method

# virtual methods
.method public final b(Landroid/view/RenderNode;)I
    .registers 3

    .line 0: const-string v0, "renderNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/view/RenderNode;->getSpotShadowColor()I
    .line 8: move-result v2
    .line 9: return v2
.end method

# virtual methods
.method public final c(Landroid/view/RenderNode;I)V
    .registers 4

    .line 0: const-string v0, "renderNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2, v3}, Landroid/view/RenderNode;->setAmbientShadowColor(I)Z
    .line 8: return-void
.end method

# virtual methods
.method public final d(Landroid/view/RenderNode;I)V
    .registers 4

    .line 0: const-string v0, "renderNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2, v3}, Landroid/view/RenderNode;->setSpotShadowColor(I)Z
    .line 8: return-void
.end method

.class public final Landroidx/compose/ui/platform/v1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld3/e;
.field public b:Landroid/graphics/Matrix;
.field public c:Landroid/graphics/Matrix;
.field public d:[F
.field public e:[F
.field public f:Z
.field public g:Z
.field public h:Z

# direct methods
.method public constructor <init>(Landroidx/compose/ui/platform/f1;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/v1;->a:Ld3/e;
    .line 5: const/4 v1, 1
    .line 6: iput-boolean v1, v0, Landroidx/compose/ui/platform/v1;->f:Z
    .line 8: iput-boolean v1, v0, Landroidx/compose/ui/platform/v1;->g:Z
    .line 10: iput-boolean v1, v0, Landroidx/compose/ui/platform/v1;->h:Z
    .line 12: return-void
.end method

# virtual methods
.method public final a(Ljava/lang/Object;)[F
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/compose/ui/platform/v1;->e:[F
    .line 2: if-nez v0, :cond_13
    .line 4: const/16 v0, 16
    .line 6: new-array v0, v0, [F
    .line 8: fill-array-data v0, :data_38
    .line 11: iput-object v0, v2, Landroidx/compose/ui/platform/v1;->e:[F
    .line 13: iget-boolean v1, v2, Landroidx/compose/ui/platform/v1;->g:Z
    .line 15: if-eqz v1, :cond_30
    .line 17: invoke-virtual {v2, v3}, Landroidx/compose/ui/platform/v1;->b(Ljava/lang/Object;)[F
    .line 20: move-result-object v3
    .line 21: invoke-static {v3, v0}, Landroidx/compose/ui/platform/n1;->t([F[F)Z
    .line 24: move-result v3
    .line 25: iput-boolean v3, v2, Landroidx/compose/ui/platform/v1;->h:Z
    .line 27: const/4 v3, 0
    .line 28: iput-boolean v3, v2, Landroidx/compose/ui/platform/v1;->g:Z
    .line 30: iget-boolean v3, v2, Landroidx/compose/ui/platform/v1;->h:Z
    .line 32: if-eqz v3, :cond_35
    .line 34: goto :goto_36
    .line 35: const/4 v0, 0
    .line 36: return-object v0
    .line 37: nop
    .line 38: nop
    .line 39: move-wide v0, v0
    .line 40: return-wide v0
    .line 41: nop
    .line 42: nop
    .line 43: neg-double v15, v3
    .line 44: nop
    .line 45: nop
    .line 46: nop
    .line 47: nop
    .line 48: nop
    .line 49: nop
    .line 50: nop
    .line 51: nop
    .line 52: nop
    .line 53: neg-double v15, v3
    .line 54: nop
    .line 55: nop
    .line 56: nop
    .line 57: nop
    .line 58: nop
    .line 59: nop
    .line 60: nop
    .line 61: nop
    .line 62: nop
    .line 63: neg-double v15, v3
    .line 64: nop
    .line 65: nop
    .line 66: nop
    .line 67: nop
    .line 68: nop
    .line 69: nop
    .line 70: nop
    .line 71: nop
    .line 72: nop
    .line 73: neg-double v15, v3
.end method

# virtual methods
.method public final b(Ljava/lang/Object;)[F
    .registers 5

    .line 0: iget-object v0, v3, Landroidx/compose/ui/platform/v1;->d:[F
    .line 2: if-nez v0, :cond_13
    .line 4: const/16 v0, 16
    .line 6: new-array v0, v0, [F
    .line 8: fill-array-data v0, :data_56
    .line 11: iput-object v0, v3, Landroidx/compose/ui/platform/v1;->d:[F
    .line 13: iget-boolean v1, v3, Landroidx/compose/ui/platform/v1;->f:Z
    .line 15: if-nez v1, :cond_18
    .line 17: return-object v0
    .line 18: iget-object v1, v3, Landroidx/compose/ui/platform/v1;->b:Landroid/graphics/Matrix;
    .line 20: if-nez v1, :cond_29
    .line 22: new-instance v1, Landroid/graphics/Matrix;
    .line 24: invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V
    .line 27: iput-object v1, v3, Landroidx/compose/ui/platform/v1;->b:Landroid/graphics/Matrix;
    .line 29: iget-object v2, v3, Landroidx/compose/ui/platform/v1;->a:Ld3/e;
    .line 31: invoke-interface {v2, v4, v1}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 34: iget-object v4, v3, Landroidx/compose/ui/platform/v1;->c:Landroid/graphics/Matrix;
    .line 36: if-eqz v4, :cond_44
    .line 38: invoke-static {v1, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v2
    .line 42: if-nez v2, :cond_51
    .line 44: invoke-static {v1, v0}, Landroidx/compose/ui/graphics/a;->q(Landroid/graphics/Matrix;[F)V
    .line 47: iput-object v4, v3, Landroidx/compose/ui/platform/v1;->b:Landroid/graphics/Matrix;
    .line 49: iput-object v1, v3, Landroidx/compose/ui/platform/v1;->c:Landroid/graphics/Matrix;
    .line 51: const/4 v4, 0
    .line 52: iput-boolean v4, v3, Landroidx/compose/ui/platform/v1;->f:Z
    .line 54: return-object v0
    .line 55: nop
    .line 56: nop
    .line 57: move-wide v0, v0
    .line 58: return-wide v0
    .line 59: nop
    .line 60: nop
    .line 61: neg-double v15, v3
    .line 62: nop
    .line 63: nop
    .line 64: nop
    .line 65: nop
    .line 66: nop
    .line 67: nop
    .line 68: nop
    .line 69: nop
    .line 70: nop
    .line 71: neg-double v15, v3
    .line 72: nop
    .line 73: nop
    .line 74: nop
    .line 75: nop
    .line 76: nop
    .line 77: nop
    .line 78: nop
    .line 79: nop
    .line 80: nop
    .line 81: neg-double v15, v3
    .line 82: nop
    .line 83: nop
    .line 84: nop
    .line 85: nop
    .line 86: nop
    .line 87: nop
    .line 88: nop
    .line 89: nop
    .line 90: nop
    .line 91: neg-double v15, v3
.end method

# virtual methods
.method public final c()V
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: iput-boolean v0, v1, Landroidx/compose/ui/platform/v1;->f:Z
    .line 3: iput-boolean v0, v1, Landroidx/compose/ui/platform/v1;->g:Z
    .line 5: return-void
.end method

.class public final synthetic Landroidx/compose/ui/platform/n;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field public final synthetic a:Landroidx/compose/ui/platform/AndroidComposeView;

# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/platform/AndroidComposeView;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/n;->a:Landroidx/compose/ui/platform/AndroidComposeView;
    .line 5: return-void
.end method

# virtual methods
.method public final onGlobalLayout()V
    .registers 3

    .line 0: sget-object v0, Landroidx/compose/ui/platform/AndroidComposeView;->z0:Ljava/lang/Class;
    .line 2: const-string v0, "this$0"
    .line 4: iget-object v1, v2, Landroidx/compose/ui/platform/n;->a:Landroidx/compose/ui/platform/AndroidComposeView;
    .line 6: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: invoke-virtual {v1}, Landroidx/compose/ui/platform/AndroidComposeView;->E()V
    .line 12: return-void
.end method

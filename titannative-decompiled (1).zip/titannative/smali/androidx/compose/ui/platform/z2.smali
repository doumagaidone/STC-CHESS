.class public abstract Landroidx/compose/ui/platform/z2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/concurrent/atomic/AtomicReference;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;
    .line 2: sget-object v1, Landroidx/compose/ui/platform/x2;->a:Landroidx/compose/ui/platform/r1;
    .line 4: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 7: sget-object v1, Landroidx/compose/ui/platform/w2;->b:Landroidx/compose/ui/platform/w2;
    .line 9: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V
    .line 12: sput-object v0, Landroidx/compose/ui/platform/z2;->a:Ljava/util/concurrent/atomic/AtomicReference;
    .line 14: return-void
.end method

.class public final Landroidx/compose/ui/platform/l3;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroidx/compose/ui/platform/l3;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/compose/ui/platform/l3;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/compose/ui/platform/l3;->a:Landroidx/compose/ui/platform/l3;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/View;)Ljava/util/Map;
    .registers 3

    .line 0: const-string v0, "view"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v2}, Landroidx/compose/ui/platform/a2;->h(Landroid/view/View;)Ljava/util/Map;
    .line 8: move-result-object v2
    .line 9: const-string v0, "view.attributeSourceResourceMap"
    .line 11: invoke-static {v2, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: return-object v2
.end method

.class public final synthetic Landroidx/compose/ui/platform/v;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;

.field public final synthetic a:Landroidx/compose/ui/platform/j0;

# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/platform/j0;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/compose/ui/platform/v;->a:Landroidx/compose/ui/platform/j0;
    .line 5: return-void
.end method

# virtual methods
.method public final onAccessibilityStateChanged(Z)V
    .registers 4

    .line 0: const-string v0, "this$0"
    .line 2: iget-object v1, v2, Landroidx/compose/ui/platform/v;->a:Landroidx/compose/ui/platform/j0;
    .line 4: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: if-eqz v3, :cond_17
    .line 9: iget-object v3, v1, Landroidx/compose/ui/platform/j0;->f:Landroid/view/accessibility/AccessibilityManager;
    .line 11: const/4 v0, -1
    .line 12: invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityManager;->getEnabledAccessibilityServiceList(I)Ljava/util/List;
    .line 15: move-result-object v3
    .line 16: goto :goto_19
    .line 17: sget-object v3, Lt2/r;->i:Lt2/r;
    .line 19: iput-object v3, v1, Landroidx/compose/ui/platform/j0;->i:Ljava/util/List;
    .line 21: return-void
.end method

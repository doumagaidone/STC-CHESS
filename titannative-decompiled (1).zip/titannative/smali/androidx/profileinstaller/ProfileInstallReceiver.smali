.class public Landroidx/profileinstaller/ProfileInstallReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 8

    .line 0: if-nez v7, :cond_3
    .line 2: return-void
    .line 3: invoke-virtual {v7}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    .line 6: move-result-object v0
    .line 7: const-string v1, "androidx.profileinstaller.action.INSTALL_PROFILE"
    .line 9: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 12: move-result v1
    .line 13: const/16 v2, 15
    .line 15: if-eqz v1, :cond_34
    .line 17: new-instance v7, Ld/a;
    .line 19: const/4 v0, 2
    .line 20: invoke-direct {v7, v0}, Ld/a;-><init>(I)V
    .line 23: new-instance v0, Lu/d;
    .line 25: invoke-direct {v0, v2, v5}, Lu/d;-><init>(ILjava/lang/Object;)V
    .line 28: const/4 v1, 1
    .line 29: invoke-static {v6, v7, v0, v1}, Lk2/e;->p(Landroid/content/Context;Ld/a;Lk2/d;Z)V
    .line 32: goto/16 :goto_229
    .line 34: const-string v1, "androidx.profileinstaller.action.SKIP_FILE"
    .line 36: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 39: move-result v1
    .line 40: const/16 v3, 10
    .line 42: const/4 v4, 0
    .line 43: if-eqz v1, :cond_139
    .line 45: invoke-virtual {v7}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    .line 48: move-result-object v7
    .line 49: if-eqz v7, :cond_229
    .line 51: const-string v0, "EXTRA_SKIP_FILE_OPERATION"
    .line 53: invoke-virtual {v7, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 56: move-result-object v7
    .line 57: const-string v0, "WRITE_SKIP_FILE"
    .line 59: invoke-virtual {v0, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 62: move-result v0
    .line 63: if-eqz v0, :cond_106
    .line 65: new-instance v7, Lu/d;
    .line 67: invoke-direct {v7, v2, v5}, Lu/d;-><init>(ILjava/lang/Object;)V
    .line 70: invoke-virtual {v6}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    .line 73: move-result-object v0
    .line 74: invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 77: move-result-object v0
    .line 78: invoke-virtual {v6}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 81: move-result-object v1
    .line 82: const/4 v2, 0
    .line 83: invoke-virtual {v1, v0, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    .line 86: move-result-object v0
    .line 87: invoke-virtual {v6}, Landroid/content/Context;->getFilesDir()Ljava/io/File;
    .line 90: move-result-object v6
    .line 91: invoke-static {v0, v6}, Lk2/e;->d(Landroid/content/pm/PackageInfo;Ljava/io/File;)V
    .line 94: invoke-interface {v7, v3, v4}, Lk2/d;->e(ILjava/lang/Object;)V
    .line 97: goto/16 :goto_229
    .line 99: move-exception v6
    .line 100: const/4 v0, 7
    .line 101: invoke-interface {v7, v0, v6}, Lk2/d;->e(ILjava/lang/Object;)V
    .line 104: goto/16 :goto_229
    .line 106: const-string v0, "DELETE_SKIP_FILE"
    .line 108: invoke-virtual {v0, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 111: move-result v7
    .line 112: if-eqz v7, :cond_229
    .line 114: new-instance v7, Lu/d;
    .line 116: invoke-direct {v7, v2, v5}, Lu/d;-><init>(ILjava/lang/Object;)V
    .line 119: invoke-virtual {v6}, Landroid/content/Context;->getFilesDir()Ljava/io/File;
    .line 122: move-result-object v6
    .line 123: new-instance v0, Ljava/io/File;
    .line 125: const-string v1, "profileinstaller_profileWrittenFor_lastUpdateTime.dat"
    .line 127: invoke-direct {v0, v6, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 130: invoke-virtual {v0}, Ljava/io/File;->delete()Z
    .line 133: const/16 v6, 11
    .line 135: invoke-interface {v7, v6, v4}, Lk2/d;->e(ILjava/lang/Object;)V
    .line 138: goto :goto_229
    .line 139: const-string v1, "androidx.profileinstaller.action.SAVE_PROFILE"
    .line 141: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 144: move-result v1
    .line 145: if-eqz v1, :cond_167
    .line 147: invoke-static {}, Landroid/os/Process;->myPid()I
    .line 150: move-result v6
    .line 151: invoke-static {v6, v3}, Landroid/os/Process;->sendSignal(II)V
    .line 154: const-string v6, "ProfileInstaller"
    .line 156: const-string v7, ""
    .line 158: invoke-static {v6, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    .line 161: const/16 v6, 12
    .line 163: invoke-virtual {v5, v6}, Landroid/content/BroadcastReceiver;->setResultCode(I)V
    .line 166: goto :goto_229
    .line 167: const-string v1, "androidx.profileinstaller.action.BENCHMARK_OPERATION"
    .line 169: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 172: move-result v0
    .line 173: if-eqz v0, :cond_229
    .line 175: invoke-virtual {v7}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    .line 178: move-result-object v7
    .line 179: if-eqz v7, :cond_229
    .line 181: const-string v0, "EXTRA_BENCHMARK_OPERATION"
    .line 183: invoke-virtual {v7, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 186: move-result-object v7
    .line 187: new-instance v0, Lu/d;
    .line 189: invoke-direct {v0, v2, v5}, Lu/d;-><init>(ILjava/lang/Object;)V
    .line 192: const-string v1, "DROP_SHADER_CACHE"
    .line 194: invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 197: move-result v7
    .line 198: if-eqz v7, :cond_224
    .line 200: invoke-virtual {v6}, Landroid/content/Context;->createDeviceProtectedStorageContext()Landroid/content/Context;
    .line 203: move-result-object v6
    .line 204: invoke-virtual {v6}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;
    .line 207: move-result-object v6
    .line 208: invoke-static {v6}, Ld2/b;->W(Ljava/io/File;)Z
    .line 211: move-result v6
    .line 212: if-eqz v6, :cond_220
    .line 214: const/16 v6, 14
    .line 216: invoke-virtual {v0, v6, v4}, Lu/d;->e(ILjava/lang/Object;)V
    .line 219: goto :goto_229
    .line 220: invoke-virtual {v0, v2, v4}, Lu/d;->e(ILjava/lang/Object;)V
    .line 223: goto :goto_229
    .line 224: const/16 v6, 16
    .line 226: invoke-virtual {v0, v6, v4}, Lu/d;->e(ILjava/lang/Object;)V
    .line 229: return-void
.end method

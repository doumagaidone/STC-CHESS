.class public Landroidx/versionedparcelable/ParcelImpl;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/os/Parcelable;

.field public static final CREATOR:Landroid/os/Parcelable$Creator;

.field public final i:Lo2/c;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Landroidx/activity/result/a;
    .line 2: const/4 v1, 4
    .line 3: invoke-direct {v0, v1}, Landroidx/activity/result/a;-><init>(I)V
    .line 6: sput-object v0, Landroidx/versionedparcelable/ParcelImpl;->CREATOR:Landroid/os/Parcelable$Creator;
    .line 8: return-void
.end method

# direct methods
.method public constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Lo2/b;
    .line 5: invoke-direct {v0, v2}, Lo2/b;-><init>(Landroid/os/Parcel;)V
    .line 8: invoke-virtual {v0}, Lo2/a;->g()Lo2/c;
    .line 11: move-result-object v2
    .line 12: iput-object v2, v1, Landroidx/versionedparcelable/ParcelImpl;->i:Lo2/c;
    .line 14: return-void
.end method

# virtual methods
.method public final describeContents()I
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 3

    .line 0: new-instance v2, Lo2/b;
    .line 2: invoke-direct {v2, v1}, Lo2/b;-><init>(Landroid/os/Parcel;)V
    .line 5: iget-object v1, v0, Landroidx/versionedparcelable/ParcelImpl;->i:Lo2/c;
    .line 7: invoke-virtual {v2, v1}, Lo2/a;->i(Lo2/c;)V
    .line 10: return-void
.end method

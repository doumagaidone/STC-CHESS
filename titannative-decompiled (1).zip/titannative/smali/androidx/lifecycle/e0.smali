.class public final Landroidx/lifecycle/e0;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/app/Application$ActivityLifecycleCallbacks;

.field public static final Companion:Landroidx/lifecycle/d0;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/lifecycle/d0;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/lifecycle/e0;->Companion:Landroidx/lifecycle/d0;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static final registerIn(Landroid/app/Activity;)V
    .registers 2

    .line 0: sget-object v0, Landroidx/lifecycle/e0;->Companion:Landroidx/lifecycle/d0;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: const-string v0, "activity"
    .line 7: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/lifecycle/e0;
    .line 12: invoke-direct {v0}, Landroidx/lifecycle/e0;-><init>()V
    .line 15: invoke-static {v1, v0}, Landroidx/compose/ui/platform/a2;->i(Landroid/app/Activity;Landroidx/lifecycle/e0;)V
    .line 18: return-void
.end method

# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 0: const-string v2, "activity"
    .line 2: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityDestroyed(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPaused(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 0: const-string v2, "activity"
    .line 2: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v2, Landroidx/lifecycle/f0;->j:I
    .line 7: sget-object v2, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;
    .line 9: invoke-static {v1, v2}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 12: return-void
.end method

# virtual methods
.method public onActivityPostResumed(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroidx/lifecycle/f0;->j:I
    .line 7: sget-object v0, Landroidx/lifecycle/m;->ON_RESUME:Landroidx/lifecycle/m;
    .line 9: invoke-static {v2, v0}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 12: return-void
.end method

# virtual methods
.method public onActivityPostStarted(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroidx/lifecycle/f0;->j:I
    .line 7: sget-object v0, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 9: invoke-static {v2, v0}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 12: return-void
.end method

# virtual methods
.method public onActivityPreDestroyed(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroidx/lifecycle/f0;->j:I
    .line 7: sget-object v0, Landroidx/lifecycle/m;->ON_DESTROY:Landroidx/lifecycle/m;
    .line 9: invoke-static {v2, v0}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 12: return-void
.end method

# virtual methods
.method public onActivityPrePaused(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroidx/lifecycle/f0;->j:I
    .line 7: sget-object v0, Landroidx/lifecycle/m;->ON_PAUSE:Landroidx/lifecycle/m;
    .line 9: invoke-static {v2, v0}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 12: return-void
.end method

# virtual methods
.method public onActivityPreStopped(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroidx/lifecycle/f0;->j:I
    .line 7: sget-object v0, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;
    .line 9: invoke-static {v2, v0}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 12: return-void
.end method

# virtual methods
.method public onActivityResumed(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 4

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v2, "bundle"
    .line 7: invoke-static {v3, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: return-void
.end method

# virtual methods
.method public onActivityStarted(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityStopped(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

.class public abstract Landroidx/lifecycle/g;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/app/Application$ActivityLifecycleCallbacks;

# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 0: const-string v2, "activity"
    .line 2: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityDestroyed(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPaused(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityResumed(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 4

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v2, "outState"
    .line 7: invoke-static {v3, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: return-void
.end method

# virtual methods
.method public onActivityStarted(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityStopped(Landroid/app/Activity;)V
    .registers 3

    .line 0: const-string v0, "activity"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: return-void
.end method

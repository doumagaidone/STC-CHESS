.class public abstract Landroidx/lifecycle/w;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/HashMap;
.field public static final b:Ljava/util/HashMap;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/util/HashMap;
    .line 2: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 5: sput-object v0, Landroidx/lifecycle/w;->a:Ljava/util/HashMap;
    .line 7: new-instance v0, Ljava/util/HashMap;
    .line 9: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 12: sput-object v0, Landroidx/lifecycle/w;->b:Ljava/util/HashMap;
    .line 14: return-void
.end method

# direct methods
.method public static a(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)V
    .registers 2

    .line 0: filled-new-array {v1}, [Ljava/lang/Object;
    .line 3: move-result-object v1
    .line 4: invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    .line 7: move-result-object v0
    .line 8: const-string v1, "{\n            constructo…tance(`object`)\n        }"
    .line 10: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: invoke-static {v0}, Lai/onnxruntime/b;->x(Ljava/lang/Object;)V
    .line 16: const/4 v0, 0
    .line 17: throw v0
    .line 18: move-exception v0
    .line 19: goto :goto_24
    .line 20: move-exception v0
    .line 21: goto :goto_30
    .line 22: move-exception v0
    .line 23: goto :goto_36
    .line 24: new-instance v1, Ljava/lang/RuntimeException;
    .line 26: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 29: throw v1
    .line 30: new-instance v1, Ljava/lang/RuntimeException;
    .line 32: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 35: throw v1
    .line 36: new-instance v1, Ljava/lang/RuntimeException;
    .line 38: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 41: throw v1
.end method

# direct methods
.method public static b(Ljava/lang/Class;)I
    .registers 14

    .line 0: sget-object v0, Landroidx/lifecycle/w;->a:Ljava/util/HashMap;
    .line 2: invoke-virtual {v0, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Ljava/lang/Integer;
    .line 8: if-eqz v1, :cond_15
    .line 10: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    .line 13: move-result v13
    .line 14: return v13
    .line 15: invoke-virtual {v13}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 18: move-result-object v1
    .line 19: const/4 v2, 1
    .line 20: if-nez v1, :cond_24
    .line 22: goto/16 :goto_322
    .line 24: const/4 v1, 0
    .line 25: const/4 v3, 0
    .line 26: invoke-virtual {v13}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;
    .line 29: move-result-object v4
    .line 30: invoke-virtual {v13}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 33: move-result-object v5
    .line 34: if-eqz v4, :cond_43
    .line 36: invoke-virtual {v4}, Ljava/lang/Package;->getName()Ljava/lang/String;
    .line 39: move-result-object v4
    .line 40: goto :goto_45
    .line 41: move-exception v13
    .line 42: goto :goto_144
    .line 43: const-string v4, ""
    .line 45: const-string v6, "fullPackage"
    .line 47: invoke-static {v4, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 50: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 53: move-result v6
    .line 54: if-nez v6, :cond_57
    .line 56: goto :goto_76
    .line 57: const-string v6, "name"
    .line 59: invoke-static {v5, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 62: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 65: move-result v6
    .line 66: add-int/2addr v6, v2
    .line 67: invoke-virtual {v5, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 70: move-result-object v5
    .line 71: const-string v6, "this as java.lang.String).substring(startIndex)"
    .line 73: invoke-static {v5, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 76: const-string v6, "if (fullPackage.isEmpty(…g(fullPackage.length + 1)"
    .line 78: invoke-static {v5, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 81: const-string v6, "."
    .line 83: const-string v7, "_"
    .line 85: invoke-static {v5, v6, v7}, Lm3/j;->a2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 88: move-result-object v5
    .line 89: const-string v6, "_LifecycleAdapter"
    .line 91: invoke-virtual {v5, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 94: move-result-object v5
    .line 95: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 98: move-result v6
    .line 99: if-nez v6, :cond_102
    .line 101: goto :goto_122
    .line 102: new-instance v6, Ljava/lang/StringBuilder;
    .line 104: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    .line 107: invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 110: const/16 v4, 46
    .line 112: invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 115: invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 118: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 121: move-result-object v5
    .line 122: invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    .line 125: move-result-object v4
    .line 126: new-array v5, v2, [Ljava/lang/Class;
    .line 128: aput-object v13, v5, v3
    .line 130: invoke-virtual {v4, v5}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .line 133: move-result-object v4
    .line 134: invoke-virtual {v4}, Ljava/lang/reflect/AccessibleObject;->isAccessible()Z
    .line 137: move-result v5
    .line 138: if-nez v5, :cond_151
    .line 140: invoke-virtual {v4, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    .line 143: goto :goto_151
    .line 144: new-instance v0, Ljava/lang/RuntimeException;
    .line 146: invoke-direct {v0, v13}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 149: throw v0
    .line 150: move-object v4, v1
    .line 151: sget-object v5, Landroidx/lifecycle/w;->b:Ljava/util/HashMap;
    .line 153: const/4 v6, 2
    .line 154: if-eqz v4, :cond_166
    .line 156: invoke-static {v4}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 159: move-result-object v1
    .line 160: invoke-virtual {v5, v13, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 163: move v2, v6
    .line 164: goto/16 :goto_322
    .line 166: sget-object v4, Landroidx/lifecycle/d;->c:Landroidx/lifecycle/d;
    .line 168: iget-object v7, v4, Landroidx/lifecycle/d;->b:Ljava/util/HashMap;
    .line 170: invoke-virtual {v7, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 173: move-result-object v8
    .line 174: check-cast v8, Ljava/lang/Boolean;
    .line 176: if-eqz v8, :cond_186
    .line 178: invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z
    .line 181: move-result v4
    .line 182: if-eqz v4, :cond_219
    .line 184: goto/16 :goto_322
    .line 186: invoke-virtual {v13}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;
    .line 189: move-result-object v8
    .line 190: array-length v9, v8
    .line 191: move v10, v3
    .line 192: if-ge v10, v9, :cond_214
    .line 194: aget-object v11, v8, v10
    .line 196: const-class v12, Landroidx/lifecycle/x;
    .line 198: invoke-virtual {v11, v12}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    .line 201: move-result-object v11
    .line 202: check-cast v11, Landroidx/lifecycle/x;
    .line 204: if-eqz v11, :cond_211
    .line 206: invoke-virtual {v4, v13, v8}, Landroidx/lifecycle/d;->a(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/b;
    .line 209: goto/16 :goto_322
    .line 211: add-int/lit8 v10, v10, 1
    .line 213: goto :goto_192
    .line 214: sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 216: invoke-virtual {v7, v13, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 219: invoke-virtual {v13}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    .line 222: move-result-object v4
    .line 223: const-class v7, Landroidx/lifecycle/s;
    .line 225: if-eqz v4, :cond_259
    .line 227: invoke-virtual {v7, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 230: move-result v8
    .line 231: if-eqz v8, :cond_259
    .line 233: const-string v1, "superclass"
    .line 235: invoke-static {v4, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 238: invoke-static {v4}, Landroidx/lifecycle/w;->b(Ljava/lang/Class;)I
    .line 241: move-result v1
    .line 242: if-ne v1, v2, :cond_245
    .line 244: goto :goto_322
    .line 245: new-instance v1, Ljava/util/ArrayList;
    .line 247: invoke-virtual {v5, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 250: move-result-object v4
    .line 251: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 254: check-cast v4, Ljava/util/Collection;
    .line 256: invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 259: invoke-virtual {v13}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;
    .line 262: move-result-object v4
    .line 263: const-string v8, "klass.interfaces"
    .line 265: invoke-static {v4, v8}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 268: array-length v8, v4
    .line 269: if-ge v3, v8, :cond_315
    .line 271: aget-object v9, v4, v3
    .line 273: if-eqz v9, :cond_312
    .line 275: invoke-virtual {v7, v9}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 278: move-result v10
    .line 279: if-eqz v10, :cond_312
    .line 281: const-string v10, "intrface"
    .line 283: invoke-static {v9, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 286: invoke-static {v9}, Landroidx/lifecycle/w;->b(Ljava/lang/Class;)I
    .line 289: move-result v10
    .line 290: if-ne v10, v2, :cond_293
    .line 292: goto :goto_322
    .line 293: if-nez v1, :cond_300
    .line 295: new-instance v1, Ljava/util/ArrayList;
    .line 297: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 300: invoke-virtual {v5, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 303: move-result-object v9
    .line 304: invoke-static {v9}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 307: check-cast v9, Ljava/util/Collection;
    .line 309: invoke-interface {v1, v9}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    .line 312: add-int/lit8 v3, v3, 1
    .line 314: goto :goto_269
    .line 315: if-eqz v1, :cond_322
    .line 317: invoke-virtual {v5, v13, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 320: goto/16 :goto_163
    .line 322: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 325: move-result-object v1
    .line 326: invoke-virtual {v0, v13, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 329: return v2
    .line 330: move-exception v13
    .line 331: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 333: const-string v1, "The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor."
    .line 335: invoke-direct {v0, v1, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 338: throw v0
.end method

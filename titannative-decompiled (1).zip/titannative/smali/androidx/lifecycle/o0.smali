.class public abstract Landroidx/lifecycle/o0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/HashMap;
.field public final b:Ljava/util/LinkedHashSet;
.field public volatile c:Z

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/o0;->a:Ljava/util/HashMap;
    .line 10: new-instance v0, Ljava/util/LinkedHashSet;
    .line 12: invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V
    .line 15: iput-object v0, v1, Landroidx/lifecycle/o0;->b:Ljava/util/LinkedHashSet;
    .line 17: const/4 v0, 0
    .line 18: iput-boolean v0, v1, Landroidx/lifecycle/o0;->c:Z
    .line 20: return-void
.end method

# direct methods
.method public static a(Ljava/lang/Object;)V
    .registers 2

    .line 0: instance-of v0, v1, Ljava/io/Closeable;
    .line 2: if-eqz v0, :cond_17
    .line 4: check-cast v1, Ljava/io/Closeable;
    .line 6: invoke-interface {v1}, Ljava/io/Closeable;->close()V
    .line 9: goto :goto_17
    .line 10: move-exception v1
    .line 11: new-instance v0, Ljava/lang/RuntimeException;
    .line 13: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 16: throw v0
    .line 17: return-void
.end method

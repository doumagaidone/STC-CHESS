.class public abstract Landroidx/lifecycle/q;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/concurrent/atomic/AtomicBoolean;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V
    .line 6: sput-object v0, Landroidx/lifecycle/q;->a:Ljava/util/concurrent/atomic/AtomicBoolean;
    .line 8: return-void
.end method

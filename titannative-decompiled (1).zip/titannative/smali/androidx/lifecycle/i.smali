.class public abstract interface Landroidx/lifecycle/i;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract getDefaultViewModelCreationExtras()Lj2/b;
.end method

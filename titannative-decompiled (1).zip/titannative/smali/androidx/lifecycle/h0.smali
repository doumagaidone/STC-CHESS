.class public final Landroidx/lifecycle/h0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final f:[Ljava/lang/Class;

.field public final a:Ljava/util/LinkedHashMap;
.field public final b:Ljava/util/LinkedHashMap;
.field public final c:Ljava/util/LinkedHashMap;
.field public final d:Ljava/util/LinkedHashMap;
.field public final e:Landroidx/lifecycle/g0;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: const/16 v0, 29
    .line 2: new-array v0, v0, [Ljava/lang/Class;
    .line 4: const/4 v1, 0
    .line 5: sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 7: aput-object v2, v0, v1
    .line 9: const/4 v1, 1
    .line 10: const-class v2, [Z
    .line 12: aput-object v2, v0, v1
    .line 14: const/4 v1, 2
    .line 15: sget-object v2, Ljava/lang/Double;->TYPE:Ljava/lang/Class;
    .line 17: aput-object v2, v0, v1
    .line 19: const/4 v1, 3
    .line 20: const-class v2, [D
    .line 22: aput-object v2, v0, v1
    .line 24: const/4 v1, 4
    .line 25: sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 27: aput-object v2, v0, v1
    .line 29: const/4 v1, 5
    .line 30: const-class v2, [I
    .line 32: aput-object v2, v0, v1
    .line 34: const/4 v1, 6
    .line 35: sget-object v2, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 37: aput-object v2, v0, v1
    .line 39: const/4 v1, 7
    .line 40: const-class v2, [J
    .line 42: aput-object v2, v0, v1
    .line 44: const/16 v1, 8
    .line 46: const-class v2, Ljava/lang/String;
    .line 48: aput-object v2, v0, v1
    .line 50: const/16 v1, 9
    .line 52: const-class v2, [Ljava/lang/String;
    .line 54: aput-object v2, v0, v1
    .line 56: const/16 v1, 10
    .line 58: const-class v2, Landroid/os/Binder;
    .line 60: aput-object v2, v0, v1
    .line 62: const/16 v1, 11
    .line 64: const-class v2, Landroid/os/Bundle;
    .line 66: aput-object v2, v0, v1
    .line 68: const/16 v1, 12
    .line 70: sget-object v2, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;
    .line 72: aput-object v2, v0, v1
    .line 74: const/16 v1, 13
    .line 76: const-class v2, [B
    .line 78: aput-object v2, v0, v1
    .line 80: const/16 v1, 14
    .line 82: sget-object v2, Ljava/lang/Character;->TYPE:Ljava/lang/Class;
    .line 84: aput-object v2, v0, v1
    .line 86: const/16 v1, 15
    .line 88: const-class v2, [C
    .line 90: aput-object v2, v0, v1
    .line 92: const/16 v1, 16
    .line 94: const-class v2, Ljava/lang/CharSequence;
    .line 96: aput-object v2, v0, v1
    .line 98: const/16 v1, 17
    .line 100: const-class v2, [Ljava/lang/CharSequence;
    .line 102: aput-object v2, v0, v1
    .line 104: const/16 v1, 18
    .line 106: const-class v2, Ljava/util/ArrayList;
    .line 108: aput-object v2, v0, v1
    .line 110: const/16 v1, 19
    .line 112: sget-object v2, Ljava/lang/Float;->TYPE:Ljava/lang/Class;
    .line 114: aput-object v2, v0, v1
    .line 116: const/16 v1, 20
    .line 118: const-class v2, [F
    .line 120: aput-object v2, v0, v1
    .line 122: const/16 v1, 21
    .line 124: const-class v2, Landroid/os/Parcelable;
    .line 126: aput-object v2, v0, v1
    .line 128: const/16 v1, 22
    .line 130: const-class v2, [Landroid/os/Parcelable;
    .line 132: aput-object v2, v0, v1
    .line 134: const/16 v1, 23
    .line 136: const-class v2, Ljava/io/Serializable;
    .line 138: aput-object v2, v0, v1
    .line 140: const/16 v1, 24
    .line 142: sget-object v2, Ljava/lang/Short;->TYPE:Ljava/lang/Class;
    .line 144: aput-object v2, v0, v1
    .line 146: const-class v1, [S
    .line 148: const/16 v2, 25
    .line 150: aput-object v1, v0, v2
    .line 152: const/16 v1, 26
    .line 154: const-class v2, Landroid/util/SparseArray;
    .line 156: aput-object v2, v0, v1
    .line 158: const/16 v1, 27
    .line 160: const-class v2, Landroid/util/Size;
    .line 162: aput-object v2, v0, v1
    .line 164: const/16 v1, 28
    .line 166: const-class v2, Landroid/util/SizeF;
    .line 168: aput-object v2, v0, v1
    .line 170: sput-object v0, Landroidx/lifecycle/h0;->f:[Ljava/lang/Class;
    .line 172: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/LinkedHashMap;
    .line 5: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 8: iput-object v0, v2, Landroidx/lifecycle/h0;->a:Ljava/util/LinkedHashMap;
    .line 10: new-instance v0, Ljava/util/LinkedHashMap;
    .line 12: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 15: iput-object v0, v2, Landroidx/lifecycle/h0;->b:Ljava/util/LinkedHashMap;
    .line 17: new-instance v0, Ljava/util/LinkedHashMap;
    .line 19: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 22: iput-object v0, v2, Landroidx/lifecycle/h0;->c:Ljava/util/LinkedHashMap;
    .line 24: new-instance v0, Ljava/util/LinkedHashMap;
    .line 26: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 29: iput-object v0, v2, Landroidx/lifecycle/h0;->d:Ljava/util/LinkedHashMap;
    .line 31: new-instance v0, Landroidx/lifecycle/g0;
    .line 33: const/4 v1, 1
    .line 34: invoke-direct {v0, v1, v2}, Landroidx/lifecycle/g0;-><init>(ILjava/lang/Object;)V
    .line 37: iput-object v0, v2, Landroidx/lifecycle/h0;->e:Landroidx/lifecycle/g0;
    .line 39: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/util/HashMap;)V
    .registers 5

    .line 0: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/LinkedHashMap;
    .line 5: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 8: iput-object v0, v3, Landroidx/lifecycle/h0;->a:Ljava/util/LinkedHashMap;
    .line 10: new-instance v1, Ljava/util/LinkedHashMap;
    .line 12: invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V
    .line 15: iput-object v1, v3, Landroidx/lifecycle/h0;->b:Ljava/util/LinkedHashMap;
    .line 17: new-instance v1, Ljava/util/LinkedHashMap;
    .line 19: invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V
    .line 22: iput-object v1, v3, Landroidx/lifecycle/h0;->c:Ljava/util/LinkedHashMap;
    .line 24: new-instance v1, Ljava/util/LinkedHashMap;
    .line 26: invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V
    .line 29: iput-object v1, v3, Landroidx/lifecycle/h0;->d:Ljava/util/LinkedHashMap;
    .line 31: new-instance v1, Landroidx/lifecycle/g0;
    .line 33: const/4 v2, 0
    .line 34: invoke-direct {v1, v2, v3}, Landroidx/lifecycle/g0;-><init>(ILjava/lang/Object;)V
    .line 37: iput-object v1, v3, Landroidx/lifecycle/h0;->e:Landroidx/lifecycle/g0;
    .line 39: invoke-interface {v0, v4}, Ljava/util/Map;->putAll(Ljava/util/Map;)V
    .line 42: return-void
.end method

# direct methods
.method public static a(Landroidx/lifecycle/h0;)Landroid/os/Bundle;
    .registers 10

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v9, Landroidx/lifecycle/h0;->b:Ljava/util/LinkedHashMap;
    .line 7: const-string v1, "<this>"
    .line 9: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 12: invoke-interface {v0}, Ljava/util/Map;->size()I
    .line 15: move-result v1
    .line 16: if-eqz v1, :cond_59
    .line 18: const/4 v2, 1
    .line 19: if-eq v1, v2, :cond_27
    .line 21: new-instance v1, Ljava/util/LinkedHashMap;
    .line 23: invoke-direct {v1, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V
    .line 26: goto :goto_61
    .line 27: invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;
    .line 30: move-result-object v0
    .line 31: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 34: move-result-object v0
    .line 35: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 38: move-result-object v0
    .line 39: check-cast v0, Ljava/util/Map$Entry;
    .line 41: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 44: move-result-object v1
    .line 45: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 48: move-result-object v0
    .line 49: invoke-static {v1, v0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;
    .line 52: move-result-object v1
    .line 53: const-string v0, "with(entries.iterator().…ingletonMap(key, value) }"
    .line 55: invoke-static {v1, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 58: goto :goto_61
    .line 59: sget-object v1, Lt2/s;->i:Lt2/s;
    .line 61: invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 64: move-result-object v0
    .line 65: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 68: move-result-object v0
    .line 69: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 72: move-result v1
    .line 73: iget-object v2, v9, Landroidx/lifecycle/h0;->a:Ljava/util/LinkedHashMap;
    .line 75: const/4 v3, 0
    .line 76: if-eqz v1, :cond_180
    .line 78: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 81: move-result-object v1
    .line 82: check-cast v1, Ljava/util/Map$Entry;
    .line 84: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 87: move-result-object v4
    .line 88: check-cast v4, Ljava/lang/String;
    .line 90: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 93: move-result-object v1
    .line 94: check-cast v1, Ll2/c;
    .line 96: invoke-interface {v1}, Ll2/c;->a()Landroid/os/Bundle;
    .line 99: move-result-object v1
    .line 100: const-string v5, "key"
    .line 102: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 105: if-nez v1, :cond_108
    .line 107: goto :goto_125
    .line 108: sget-object v5, Landroidx/lifecycle/h0;->f:[Ljava/lang/Class;
    .line 110: const/16 v6, 29
    .line 112: if-ge v3, v6, :cond_151
    .line 114: aget-object v6, v5, v3
    .line 116: invoke-static {v6}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 119: invoke-virtual {v6, v1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 122: move-result v6
    .line 123: if-eqz v6, :cond_148
    .line 125: iget-object v3, v9, Landroidx/lifecycle/h0;->c:Ljava/util/LinkedHashMap;
    .line 127: invoke-virtual {v3, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 130: invoke-interface {v2, v4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 133: iget-object v2, v9, Landroidx/lifecycle/h0;->d:Ljava/util/LinkedHashMap;
    .line 135: invoke-virtual {v2, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 138: move-result-object v2
    .line 139: check-cast v2, Lkotlinx/coroutines/flow/p0;
    .line 141: if-nez v2, :cond_144
    .line 143: goto :goto_69
    .line 144: invoke-virtual {v2, v1}, Lkotlinx/coroutines/flow/p0;->k(Ljava/lang/Object;)V
    .line 147: goto :goto_69
    .line 148: add-int/lit8 v3, v3, 1
    .line 150: goto :goto_110
    .line 151: new-instance v9, Ljava/lang/IllegalArgumentException;
    .line 153: new-instance v0, Ljava/lang/StringBuilder;
    .line 155: const-string v2, "Can't put value with type "
    .line 157: invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 160: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 163: move-result-object v1
    .line 164: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 167: const-string v1, " into saved state"
    .line 169: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 172: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 175: move-result-object v0
    .line 176: invoke-direct {v9, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 179: throw v9
    .line 180: invoke-virtual {v2}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;
    .line 183: move-result-object v9
    .line 184: new-instance v0, Ljava/util/ArrayList;
    .line 186: invoke-interface {v9}, Ljava/util/Set;->size()I
    .line 189: move-result v1
    .line 190: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    .line 193: new-instance v1, Ljava/util/ArrayList;
    .line 195: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 198: move-result v4
    .line 199: invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 202: invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 205: move-result-object v9
    .line 206: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 209: move-result v4
    .line 210: if-eqz v4, :cond_229
    .line 212: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 215: move-result-object v4
    .line 216: check-cast v4, Ljava/lang/String;
    .line 218: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 221: invoke-virtual {v2, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 224: move-result-object v4
    .line 225: invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 228: goto :goto_206
    .line 229: new-instance v9, Ls2/e;
    .line 231: const-string v2, "keys"
    .line 233: invoke-direct {v9, v2, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 236: new-instance v0, Ls2/e;
    .line 238: const-string v2, "values"
    .line 240: invoke-direct {v0, v2, v1}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 243: filled-new-array {v9, v0}, [Ls2/e;
    .line 246: move-result-object v9
    .line 247: new-instance v0, Landroid/os/Bundle;
    .line 249: const/4 v1, 2
    .line 250: invoke-direct {v0, v1}, Landroid/os/Bundle;-><init>(I)V
    .line 253: if-ge v3, v1, :cond_701
    .line 255: aget-object v2, v9, v3
    .line 257: iget-object v4, v2, Ls2/e;->i:Ljava/lang/Object;
    .line 259: check-cast v4, Ljava/lang/String;
    .line 261: iget-object v2, v2, Ls2/e;->j:Ljava/lang/Object;
    .line 263: if-nez v2, :cond_271
    .line 265: const/4 v2, 0
    .line 266: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    .line 269: goto/16 :goto_660
    .line 271: instance-of v5, v2, Ljava/lang/Boolean;
    .line 273: if-eqz v5, :cond_286
    .line 275: check-cast v2, Ljava/lang/Boolean;
    .line 277: invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z
    .line 280: move-result v2
    .line 281: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V
    .line 284: goto/16 :goto_660
    .line 286: instance-of v5, v2, Ljava/lang/Byte;
    .line 288: if-eqz v5, :cond_301
    .line 290: check-cast v2, Ljava/lang/Number;
    .line 292: invoke-virtual {v2}, Ljava/lang/Number;->byteValue()B
    .line 295: move-result v2
    .line 296: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putByte(Ljava/lang/String;B)V
    .line 299: goto/16 :goto_660
    .line 301: instance-of v5, v2, Ljava/lang/Character;
    .line 303: if-eqz v5, :cond_316
    .line 305: check-cast v2, Ljava/lang/Character;
    .line 307: invoke-virtual {v2}, Ljava/lang/Character;->charValue()C
    .line 310: move-result v2
    .line 311: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putChar(Ljava/lang/String;C)V
    .line 314: goto/16 :goto_660
    .line 316: instance-of v5, v2, Ljava/lang/Double;
    .line 318: if-eqz v5, :cond_331
    .line 320: check-cast v2, Ljava/lang/Number;
    .line 322: invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D
    .line 325: move-result-wide v5
    .line 326: invoke-virtual {v0, v4, v5, v6}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V
    .line 329: goto/16 :goto_660
    .line 331: instance-of v5, v2, Ljava/lang/Float;
    .line 333: if-eqz v5, :cond_346
    .line 335: check-cast v2, Ljava/lang/Number;
    .line 337: invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F
    .line 340: move-result v2
    .line 341: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V
    .line 344: goto/16 :goto_660
    .line 346: instance-of v5, v2, Ljava/lang/Integer;
    .line 348: if-eqz v5, :cond_361
    .line 350: check-cast v2, Ljava/lang/Number;
    .line 352: invoke-virtual {v2}, Ljava/lang/Number;->intValue()I
    .line 355: move-result v2
    .line 356: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 359: goto/16 :goto_660
    .line 361: instance-of v5, v2, Ljava/lang/Long;
    .line 363: if-eqz v5, :cond_376
    .line 365: check-cast v2, Ljava/lang/Number;
    .line 367: invoke-virtual {v2}, Ljava/lang/Number;->longValue()J
    .line 370: move-result-wide v5
    .line 371: invoke-virtual {v0, v4, v5, v6}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V
    .line 374: goto/16 :goto_660
    .line 376: instance-of v5, v2, Ljava/lang/Short;
    .line 378: if-eqz v5, :cond_391
    .line 380: check-cast v2, Ljava/lang/Number;
    .line 382: invoke-virtual {v2}, Ljava/lang/Number;->shortValue()S
    .line 385: move-result v2
    .line 386: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V
    .line 389: goto/16 :goto_660
    .line 391: instance-of v5, v2, Landroid/os/Bundle;
    .line 393: if-eqz v5, :cond_402
    .line 395: check-cast v2, Landroid/os/Bundle;
    .line 397: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V
    .line 400: goto/16 :goto_660
    .line 402: instance-of v5, v2, Ljava/lang/CharSequence;
    .line 404: if-eqz v5, :cond_413
    .line 406: check-cast v2, Ljava/lang/CharSequence;
    .line 408: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 411: goto/16 :goto_660
    .line 413: instance-of v5, v2, Landroid/os/Parcelable;
    .line 415: if-eqz v5, :cond_424
    .line 417: check-cast v2, Landroid/os/Parcelable;
    .line 419: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    .line 422: goto/16 :goto_660
    .line 424: instance-of v5, v2, [Z
    .line 426: if-eqz v5, :cond_435
    .line 428: check-cast v2, [Z
    .line 430: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putBooleanArray(Ljava/lang/String;[Z)V
    .line 433: goto/16 :goto_660
    .line 435: instance-of v5, v2, [B
    .line 437: if-eqz v5, :cond_446
    .line 439: check-cast v2, [B
    .line 441: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V
    .line 444: goto/16 :goto_660
    .line 446: instance-of v5, v2, [C
    .line 448: if-eqz v5, :cond_457
    .line 450: check-cast v2, [C
    .line 452: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putCharArray(Ljava/lang/String;[C)V
    .line 455: goto/16 :goto_660
    .line 457: instance-of v5, v2, [D
    .line 459: if-eqz v5, :cond_468
    .line 461: check-cast v2, [D
    .line 463: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putDoubleArray(Ljava/lang/String;[D)V
    .line 466: goto/16 :goto_660
    .line 468: instance-of v5, v2, [F
    .line 470: if-eqz v5, :cond_479
    .line 472: check-cast v2, [F
    .line 474: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putFloatArray(Ljava/lang/String;[F)V
    .line 477: goto/16 :goto_660
    .line 479: instance-of v5, v2, [I
    .line 481: if-eqz v5, :cond_490
    .line 483: check-cast v2, [I
    .line 485: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putIntArray(Ljava/lang/String;[I)V
    .line 488: goto/16 :goto_660
    .line 490: instance-of v5, v2, [J
    .line 492: if-eqz v5, :cond_501
    .line 494: check-cast v2, [J
    .line 496: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putLongArray(Ljava/lang/String;[J)V
    .line 499: goto/16 :goto_660
    .line 501: instance-of v5, v2, [S
    .line 503: if-eqz v5, :cond_512
    .line 505: check-cast v2, [S
    .line 507: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putShortArray(Ljava/lang/String;[S)V
    .line 510: goto/16 :goto_660
    .line 512: instance-of v5, v2, [Ljava/lang/Object;
    .line 514: const/16 v6, 34
    .line 516: const-string v7, " for key \""
    .line 518: if-eqz v5, :cond_621
    .line 520: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 523: move-result-object v5
    .line 524: invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    .line 527: move-result-object v5
    .line 528: invoke-static {v5}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 531: const-class v8, Landroid/os/Parcelable;
    .line 533: invoke-virtual {v8, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 536: move-result v8
    .line 537: if-eqz v8, :cond_546
    .line 539: check-cast v2, [Landroid/os/Parcelable;
    .line 541: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V
    .line 544: goto/16 :goto_660
    .line 546: const-class v8, Ljava/lang/String;
    .line 548: invoke-virtual {v8, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 551: move-result v8
    .line 552: if-eqz v8, :cond_560
    .line 554: check-cast v2, [Ljava/lang/String;
    .line 556: invoke-virtual {v0, v4, v2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V
    .line 559: goto :goto_660
    .line 560: const-class v8, Ljava/lang/CharSequence;
    .line 562: invoke-virtual {v8, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 565: move-result v8
    .line 566: if-eqz v8, :cond_574
    .line 568: check-cast v2, [Ljava/lang/CharSequence;
    .line 570: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putCharSequenceArray(Ljava/lang/String;[Ljava/lang/CharSequence;)V
    .line 573: goto :goto_660
    .line 574: const-class v8, Ljava/io/Serializable;
    .line 576: invoke-virtual {v8, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 579: move-result v8
    .line 580: if-eqz v8, :cond_588
    .line 582: check-cast v2, Ljava/io/Serializable;
    .line 584: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V
    .line 587: goto :goto_660
    .line 588: invoke-virtual {v5}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 591: move-result-object v9
    .line 592: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 594: new-instance v1, Ljava/lang/StringBuilder;
    .line 596: const-string v2, "Illegal value array type "
    .line 598: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 601: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 604: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 607: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 610: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 613: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 616: move-result-object v9
    .line 617: invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 620: throw v0
    .line 621: instance-of v5, v2, Ljava/io/Serializable;
    .line 623: if-eqz v5, :cond_631
    .line 625: check-cast v2, Ljava/io/Serializable;
    .line 627: invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V
    .line 630: goto :goto_660
    .line 631: instance-of v5, v2, Landroid/os/IBinder;
    .line 633: if-eqz v5, :cond_641
    .line 635: check-cast v2, Landroid/os/IBinder;
    .line 637: invoke-static {v0, v4, v2}, La2/a;->a(Landroid/os/Bundle;Ljava/lang/String;Landroid/os/IBinder;)V
    .line 640: goto :goto_660
    .line 641: instance-of v5, v2, Landroid/util/Size;
    .line 643: if-eqz v5, :cond_651
    .line 645: check-cast v2, Landroid/util/Size;
    .line 647: invoke-static {v0, v4, v2}, La2/b;->a(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/Size;)V
    .line 650: goto :goto_660
    .line 651: instance-of v5, v2, Landroid/util/SizeF;
    .line 653: if-eqz v5, :cond_664
    .line 655: check-cast v2, Landroid/util/SizeF;
    .line 657: invoke-static {v0, v4, v2}, La2/b;->b(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/SizeF;)V
    .line 660: add-int/lit8 v3, v3, 1
    .line 662: goto/16 :goto_253
    .line 664: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 667: move-result-object v9
    .line 668: invoke-virtual {v9}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 671: move-result-object v9
    .line 672: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 674: new-instance v1, Ljava/lang/StringBuilder;
    .line 676: const-string v2, "Illegal value type "
    .line 678: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 681: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 684: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 687: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 690: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 693: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 696: move-result-object v9
    .line 697: invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 700: throw v0
    .line 701: return-object v0
.end method

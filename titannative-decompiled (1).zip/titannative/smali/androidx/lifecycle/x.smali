.class public abstract annotation interface Landroidx/lifecycle/x;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/annotation/Annotation;

# virtual methods
.method public abstract value()Landroidx/lifecycle/m;
.end method

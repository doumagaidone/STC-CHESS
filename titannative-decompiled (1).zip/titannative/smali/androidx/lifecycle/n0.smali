.class public abstract Landroidx/lifecycle/n0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/List;
.field public static final b:Ljava/util/List;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: const/4 v0, 2
    .line 1: new-array v0, v0, [Ljava/lang/Class;
    .line 3: const/4 v1, 0
    .line 4: const-class v2, Landroid/app/Application;
    .line 6: aput-object v2, v0, v1
    .line 8: const/4 v1, 1
    .line 9: const-class v2, Landroidx/lifecycle/h0;
    .line 11: aput-object v2, v0, v1
    .line 13: invoke-static {v0}, Ld2/b;->I0([Ljava/lang/Object;)Ljava/util/List;
    .line 16: move-result-object v0
    .line 17: sput-object v0, Landroidx/lifecycle/n0;->a:Ljava/util/List;
    .line 19: invoke-static {v2}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 22: move-result-object v0
    .line 23: sput-object v0, Landroidx/lifecycle/n0;->b:Ljava/util/List;
    .line 25: return-void
.end method

# direct methods
.method public static final a(Ljava/util/List;)Ljava/lang/reflect/Constructor;
    .registers 10

    .line 0: const-string v0, "signature"
    .line 2: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-class v0, Landroidx/lifecycle/l0;
    .line 7: invoke-virtual {v0}, Ljava/lang/Class;->getConstructors()[Ljava/lang/reflect/Constructor;
    .line 10: move-result-object v1
    .line 11: const-string v2, "modelClass.constructors"
    .line 13: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: array-length v2, v1
    .line 17: const/4 v3, 0
    .line 18: move v4, v3
    .line 19: if-ge v4, v2, :cond_117
    .line 21: aget-object v5, v1, v4
    .line 23: invoke-virtual {v5}, Ljava/lang/reflect/Constructor;->getParameterTypes()[Ljava/lang/Class;
    .line 26: move-result-object v6
    .line 27: const-string v7, "constructor.parameterTypes"
    .line 29: invoke-static {v6, v7}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 32: array-length v7, v6
    .line 33: if-eqz v7, :cond_56
    .line 35: const/4 v8, 1
    .line 36: if-eq v7, v8, :cond_49
    .line 38: new-instance v7, Ljava/util/ArrayList;
    .line 40: new-instance v8, Lt2/i;
    .line 42: invoke-direct {v8, v6, v3}, Lt2/i;-><init>([Ljava/lang/Object;Z)V
    .line 45: invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 48: goto :goto_58
    .line 49: aget-object v6, v6, v3
    .line 51: invoke-static {v6}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 54: move-result-object v7
    .line 55: goto :goto_58
    .line 56: sget-object v7, Lt2/r;->i:Lt2/r;
    .line 58: invoke-static {v9, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 61: move-result v6
    .line 62: if-eqz v6, :cond_65
    .line 64: return-object v5
    .line 65: invoke-interface {v9}, Ljava/util/List;->size()I
    .line 68: move-result v5
    .line 69: invoke-interface {v7}, Ljava/util/List;->size()I
    .line 72: move-result v6
    .line 73: if-ne v5, v6, :cond_114
    .line 75: invoke-interface {v7, v9}, Ljava/util/List;->containsAll(Ljava/util/Collection;)Z
    .line 78: move-result v5
    .line 79: if-nez v5, :cond_82
    .line 81: goto :goto_114
    .line 82: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 84: new-instance v2, Ljava/lang/StringBuilder;
    .line 86: const-string v3, "Class "
    .line 88: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 91: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    .line 94: move-result-object v0
    .line 95: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 98: const-string v0, " must have parameters in the proper order: "
    .line 100: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 103: invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 106: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 109: move-result-object v9
    .line 110: invoke-direct {v1, v9}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 113: throw v1
    .line 114: add-int/lit8 v4, v4, 1
    .line 116: goto :goto_19
    .line 117: const/4 v9, 0
    .line 118: return-object v9
.end method

# direct methods
.method public static final varargs b(Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Landroidx/lifecycle/o0;
    .registers 5

    .line 0: const-class v0, Landroidx/lifecycle/l0;
    .line 2: array-length v1, v4
    .line 3: invoke-static {v4, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 6: move-result-object v4
    .line 7: invoke-virtual {v3, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    .line 10: move-result-object v3
    .line 11: check-cast v3, Landroidx/lifecycle/o0;
    .line 13: return-object v3
    .line 14: move-exception v3
    .line 15: goto :goto_20
    .line 16: move-exception v3
    .line 17: goto :goto_44
    .line 18: move-exception v3
    .line 19: goto :goto_69
    .line 20: new-instance v4, Ljava/lang/RuntimeException;
    .line 22: new-instance v1, Ljava/lang/StringBuilder;
    .line 24: const-string v2, "An exception happened in constructor of "
    .line 26: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 29: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 35: move-result-object v0
    .line 36: invoke-virtual {v3}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 39: move-result-object v3
    .line 40: invoke-direct {v4, v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 43: throw v4
    .line 44: new-instance v4, Ljava/lang/RuntimeException;
    .line 46: new-instance v1, Ljava/lang/StringBuilder;
    .line 48: const-string v2, "A "
    .line 50: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 53: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 56: const-string v0, " cannot be instantiated."
    .line 58: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 61: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 64: move-result-object v0
    .line 65: invoke-direct {v4, v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 68: throw v4
    .line 69: new-instance v4, Ljava/lang/RuntimeException;
    .line 71: new-instance v1, Ljava/lang/StringBuilder;
    .line 73: const-string v2, "Failed to access "
    .line 75: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 78: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 81: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 84: move-result-object v0
    .line 85: invoke-direct {v4, v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 88: throw v4
.end method

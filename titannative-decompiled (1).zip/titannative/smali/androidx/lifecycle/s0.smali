.class public abstract Landroidx/lifecycle/s0;
.super Ljava/lang/Object;
.source "SourceFile"

.class public final Landroidx/lifecycle/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:Ljava/lang/reflect/Method;

# direct methods
.method public constructor <init>(ILjava/lang/reflect/Method;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Landroidx/lifecycle/c;->a:I
    .line 5: iput-object v2, v0, Landroidx/lifecycle/c;->b:Ljava/lang/reflect/Method;
    .line 7: const/4 v1, 1
    .line 8: invoke-virtual {v2, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    .line 11: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Landroidx/lifecycle/c;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Landroidx/lifecycle/c;
    .line 12: iget v1, v5, Landroidx/lifecycle/c;->a:I
    .line 14: iget v3, v4, Landroidx/lifecycle/c;->a:I
    .line 16: if-ne v3, v1, :cond_37
    .line 18: iget-object v1, v4, Landroidx/lifecycle/c;->b:Ljava/lang/reflect/Method;
    .line 20: invoke-virtual {v1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 23: move-result-object v1
    .line 24: iget-object v5, v5, Landroidx/lifecycle/c;->b:Ljava/lang/reflect/Method;
    .line 26: invoke-virtual {v5}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 29: move-result-object v5
    .line 30: invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 33: move-result v5
    .line 34: if-eqz v5, :cond_37
    .line 36: goto :goto_38
    .line 37: move v0, v2
    .line 38: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget v0, v2, Landroidx/lifecycle/c;->a:I
    .line 2: mul-int/lit8 v0, v0, 31
    .line 4: iget-object v1, v2, Landroidx/lifecycle/c;->b:Ljava/lang/reflect/Method;
    .line 6: invoke-virtual {v1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 9: move-result-object v1
    .line 10: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: return v1
.end method

.class public final Landroidx/lifecycle/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final c:Landroidx/lifecycle/d;

.field public final a:Ljava/util/HashMap;
.field public final b:Ljava/util/HashMap;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/lifecycle/d;
    .line 2: invoke-direct {v0}, Landroidx/lifecycle/d;-><init>()V
    .line 5: sput-object v0, Landroidx/lifecycle/d;->c:Landroidx/lifecycle/d;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/d;->a:Ljava/util/HashMap;
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: iput-object v0, v1, Landroidx/lifecycle/d;->b:Ljava/util/HashMap;
    .line 17: return-void
.end method

# direct methods
.method public static b(Ljava/util/HashMap;Landroidx/lifecycle/c;Landroidx/lifecycle/m;Ljava/lang/Class;)V
    .registers 7

    .line 0: invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 3: move-result-object v0
    .line 4: check-cast v0, Landroidx/lifecycle/m;
    .line 6: if-eqz v0, :cond_65
    .line 8: if-ne v5, v0, :cond_11
    .line 10: goto :goto_65
    .line 11: iget-object v3, v4, Landroidx/lifecycle/c;->b:Ljava/lang/reflect/Method;
    .line 13: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 15: new-instance v1, Ljava/lang/StringBuilder;
    .line 17: const-string v2, "Method "
    .line 19: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 22: invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 25: move-result-object v3
    .line 26: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 29: const-string v3, " in "
    .line 31: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 34: invoke-virtual {v6}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 37: move-result-object v3
    .line 38: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 41: const-string v3, " already declared with different @OnLifecycleEvent value: previous value "
    .line 43: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 46: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 49: const-string v3, ", new value "
    .line 51: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 54: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 60: move-result-object v3
    .line 61: invoke-direct {v4, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 64: throw v4
    .line 65: if-nez v0, :cond_70
    .line 67: invoke-virtual {v3, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 70: return-void
.end method

# virtual methods
.method public final a(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/b;
    .registers 15

    .line 0: invoke-virtual {v13}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    .line 3: move-result-object v0
    .line 4: new-instance v1, Ljava/util/HashMap;
    .line 6: invoke-direct {v1}, Ljava/util/HashMap;-><init>()V
    .line 9: const/4 v2, 0
    .line 10: iget-object v3, v12, Landroidx/lifecycle/d;->a:Ljava/util/HashMap;
    .line 12: if-eqz v0, :cond_32
    .line 14: invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 17: move-result-object v4
    .line 18: check-cast v4, Landroidx/lifecycle/b;
    .line 20: if-eqz v4, :cond_23
    .line 22: goto :goto_27
    .line 23: invoke-virtual {v12, v0, v2}, Landroidx/lifecycle/d;->a(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/b;
    .line 26: move-result-object v4
    .line 27: iget-object v0, v4, Landroidx/lifecycle/b;->b:Ljava/util/Map;
    .line 29: invoke-virtual {v1, v0}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V
    .line 32: invoke-virtual {v13}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;
    .line 35: move-result-object v0
    .line 36: array-length v4, v0
    .line 37: const/4 v5, 0
    .line 38: move v6, v5
    .line 39: if-ge v6, v4, :cond_97
    .line 41: aget-object v7, v0, v6
    .line 43: invoke-virtual {v3, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 46: move-result-object v8
    .line 47: check-cast v8, Landroidx/lifecycle/b;
    .line 49: if-eqz v8, :cond_52
    .line 51: goto :goto_56
    .line 52: invoke-virtual {v12, v7, v2}, Landroidx/lifecycle/d;->a(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/b;
    .line 55: move-result-object v8
    .line 56: iget-object v7, v8, Landroidx/lifecycle/b;->b:Ljava/util/Map;
    .line 58: invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 61: move-result-object v7
    .line 62: invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 65: move-result-object v7
    .line 66: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 69: move-result v8
    .line 70: if-eqz v8, :cond_94
    .line 72: invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 75: move-result-object v8
    .line 76: check-cast v8, Ljava/util/Map$Entry;
    .line 78: invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 81: move-result-object v9
    .line 82: check-cast v9, Landroidx/lifecycle/c;
    .line 84: invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 87: move-result-object v8
    .line 88: check-cast v8, Landroidx/lifecycle/m;
    .line 90: invoke-static {v1, v9, v8, v13}, Landroidx/lifecycle/d;->b(Ljava/util/HashMap;Landroidx/lifecycle/c;Landroidx/lifecycle/m;Ljava/lang/Class;)V
    .line 93: goto :goto_66
    .line 94: add-int/lit8 v6, v6, 1
    .line 96: goto :goto_39
    .line 97: if-eqz v14, :cond_100
    .line 99: goto :goto_104
    .line 100: invoke-virtual {v13}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;
    .line 103: move-result-object v14
    .line 104: array-length v0, v14
    .line 105: move v2, v5
    .line 106: move v4, v2
    .line 107: if-ge v2, v0, :cond_214
    .line 109: aget-object v6, v14, v2
    .line 111: const-class v7, Landroidx/lifecycle/x;
    .line 113: invoke-virtual {v6, v7}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    .line 116: move-result-object v7
    .line 117: check-cast v7, Landroidx/lifecycle/x;
    .line 119: if-nez v7, :cond_122
    .line 121: goto :goto_203
    .line 122: invoke-virtual {v6}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;
    .line 125: move-result-object v4
    .line 126: array-length v8, v4
    .line 127: const/4 v9, 1
    .line 128: if-lez v8, :cond_150
    .line 130: const-class v8, Landroidx/lifecycle/t;
    .line 132: aget-object v10, v4, v5
    .line 134: invoke-virtual {v8, v10}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 137: move-result v8
    .line 138: if-eqz v8, :cond_142
    .line 140: move v8, v9
    .line 141: goto :goto_151
    .line 142: new-instance v13, Ljava/lang/IllegalArgumentException;
    .line 144: const-string v14, "invalid parameter type. Must be one and instanceof LifecycleOwner"
    .line 146: invoke-direct {v13, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 149: throw v13
    .line 150: move v8, v5
    .line 151: invoke-interface {v7}, Landroidx/lifecycle/x;->value()Landroidx/lifecycle/m;
    .line 154: move-result-object v7
    .line 155: array-length v10, v4
    .line 156: const/4 v11, 2
    .line 157: if-le v10, v9, :cond_191
    .line 159: const-class v8, Landroidx/lifecycle/m;
    .line 161: aget-object v10, v4, v9
    .line 163: invoke-virtual {v8, v10}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 166: move-result v8
    .line 167: if-eqz v8, :cond_183
    .line 169: sget-object v8, Landroidx/lifecycle/m;->ON_ANY:Landroidx/lifecycle/m;
    .line 171: if-ne v7, v8, :cond_175
    .line 173: move v8, v11
    .line 174: goto :goto_191
    .line 175: new-instance v13, Ljava/lang/IllegalArgumentException;
    .line 177: const-string v14, "Second arg is supported only for ON_ANY value"
    .line 179: invoke-direct {v13, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 182: throw v13
    .line 183: new-instance v13, Ljava/lang/IllegalArgumentException;
    .line 185: const-string v14, "invalid parameter type. second arg must be an event"
    .line 187: invoke-direct {v13, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 190: throw v13
    .line 191: array-length v4, v4
    .line 192: if-gt v4, v11, :cond_206
    .line 194: new-instance v4, Landroidx/lifecycle/c;
    .line 196: invoke-direct {v4, v8, v6}, Landroidx/lifecycle/c;-><init>(ILjava/lang/reflect/Method;)V
    .line 199: invoke-static {v1, v4, v7, v13}, Landroidx/lifecycle/d;->b(Ljava/util/HashMap;Landroidx/lifecycle/c;Landroidx/lifecycle/m;Ljava/lang/Class;)V
    .line 202: move v4, v9
    .line 203: add-int/lit8 v2, v2, 1
    .line 205: goto :goto_107
    .line 206: new-instance v13, Ljava/lang/IllegalArgumentException;
    .line 208: const-string v14, "cannot have more than 2 params"
    .line 210: invoke-direct {v13, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 213: throw v13
    .line 214: new-instance v14, Landroidx/lifecycle/b;
    .line 216: invoke-direct {v14, v1}, Landroidx/lifecycle/b;-><init>(Ljava/util/HashMap;)V
    .line 219: invoke-virtual {v3, v13, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 222: iget-object v0, v12, Landroidx/lifecycle/d;->b:Ljava/util/HashMap;
    .line 224: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 227: move-result-object v1
    .line 228: invoke-virtual {v0, v13, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 231: return-object v14
    .line 232: move-exception v13
    .line 233: new-instance v14, Ljava/lang/IllegalArgumentException;
    .line 235: const-string v0, "The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor."
    .line 237: invoke-direct {v14, v0, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 240: throw v14
.end method

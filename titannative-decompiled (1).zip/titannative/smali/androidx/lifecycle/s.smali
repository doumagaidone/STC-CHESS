.class public abstract interface Landroidx/lifecycle/s;
.super Ljava/lang/Object;
.source "SourceFile"

.class public abstract interface Landroidx/lifecycle/r0;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public create()Landroidx/lifecycle/o0;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/UnsupportedOperationException;
    .line 2: const-string v1, "Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method."
    .line 4: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

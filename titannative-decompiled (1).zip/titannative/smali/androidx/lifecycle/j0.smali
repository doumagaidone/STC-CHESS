.class public abstract Landroidx/lifecycle/j0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final i:Landroidx/lifecycle/p0;
.field public static final j:Landroidx/lifecycle/p0;
.field public static final k:Landroidx/lifecycle/p0;

# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/lifecycle/p0;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Landroidx/lifecycle/j0;->i:Landroidx/lifecycle/p0;
    .line 7: new-instance v0, Landroidx/lifecycle/p0;
    .line 9: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 12: sput-object v0, Landroidx/lifecycle/j0;->j:Landroidx/lifecycle/p0;
    .line 14: new-instance v0, Landroidx/lifecycle/p0;
    .line 16: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 19: sput-object v0, Landroidx/lifecycle/j0;->k:Landroidx/lifecycle/p0;
    .line 21: return-void
.end method

# direct methods
.method public static final a(Landroidx/lifecycle/o0;Ll2/d;Landroidx/lifecycle/o;)V
    .registers 5

    .line 0: const-string v0, "registry"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "lifecycle"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "androidx.lifecycle.savedstate.vm.tag"
    .line 12: iget-object v1, v2, Landroidx/lifecycle/o0;->a:Ljava/util/HashMap;
    .line 14: if-nez v1, :cond_18
    .line 16: const/4 v2, 0
    .line 17: goto :goto_26
    .line 18: monitor-enter v1
    .line 19: iget-object v2, v2, Landroidx/lifecycle/o0;->a:Ljava/util/HashMap;
    .line 21: invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 24: move-result-object v2
    .line 25: monitor-exit v1
    .line 26: check-cast v2, Landroidx/lifecycle/SavedStateHandleController;
    .line 28: if-eqz v2, :cond_67
    .line 30: iget-boolean v0, v2, Landroidx/lifecycle/SavedStateHandleController;->k:Z
    .line 32: if-nez v0, :cond_67
    .line 34: invoke-virtual {v2, v4, v3}, Landroidx/lifecycle/SavedStateHandleController;->a(Landroidx/lifecycle/o;Ll2/d;)V
    .line 37: move-object v2, v4
    .line 38: check-cast v2, Landroidx/lifecycle/v;
    .line 40: iget-object v2, v2, Landroidx/lifecycle/v;->c:Landroidx/lifecycle/n;
    .line 42: sget-object v0, Landroidx/lifecycle/n;->j:Landroidx/lifecycle/n;
    .line 44: if-eq v2, v0, :cond_64
    .line 46: sget-object v0, Landroidx/lifecycle/n;->l:Landroidx/lifecycle/n;
    .line 48: invoke-virtual {v2, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I
    .line 51: move-result v2
    .line 52: if-ltz v2, :cond_55
    .line 54: goto :goto_64
    .line 55: new-instance v2, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;
    .line 57: invoke-direct {v2, v4, v3}, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;-><init>(Landroidx/lifecycle/o;Ll2/d;)V
    .line 60: invoke-virtual {v4, v2}, Landroidx/lifecycle/o;->a(Landroidx/lifecycle/s;)V
    .line 63: goto :goto_67
    .line 64: invoke-virtual {v3}, Ll2/d;->d()V
    .line 67: return-void
    .line 68: move-exception v2
    .line 69: monitor-exit v1
    .line 70: throw v2
.end method

# direct methods
.method public static final c(Landroidx/lifecycle/u0;)Landroidx/lifecycle/l0;
    .registers 12

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Ljava/util/ArrayList;
    .line 7: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 10: const-class v1, Landroidx/lifecycle/l0;
    .line 12: invoke-static {v1}, Le3/t;->a(Ljava/lang/Class;)Le3/d;
    .line 15: move-result-object v2
    .line 16: new-instance v3, Lj2/e;
    .line 18: invoke-interface {v2}, Le3/c;->a()Ljava/lang/Class;
    .line 21: move-result-object v2
    .line 22: const-string v4, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>"
    .line 24: invoke-static {v2, v4}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 27: invoke-direct {v3, v2}, Lj2/e;-><init>(Ljava/lang/Class;)V
    .line 30: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 33: new-instance v2, Lj2/c;
    .line 35: const/4 v3, 0
    .line 36: new-array v4, v3, [Lj2/e;
    .line 38: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 41: move-result-object v0
    .line 42: check-cast v0, [Lj2/e;
    .line 44: array-length v4, v0
    .line 45: invoke-static {v0, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 48: move-result-object v0
    .line 49: check-cast v0, [Lj2/e;
    .line 51: invoke-direct {v2, v0}, Lj2/c;-><init>([Lj2/e;)V
    .line 54: invoke-interface {v11}, Landroidx/lifecycle/u0;->getViewModelStore()Landroidx/lifecycle/t0;
    .line 57: move-result-object v0
    .line 58: instance-of v4, v11, Landroidx/lifecycle/i;
    .line 60: if-eqz v4, :cond_69
    .line 62: check-cast v11, Landroidx/lifecycle/i;
    .line 64: invoke-interface {v11}, Landroidx/lifecycle/i;->getDefaultViewModelCreationExtras()Lj2/b;
    .line 67: move-result-object v11
    .line 68: goto :goto_71
    .line 69: sget-object v11, Lj2/a;->b:Lj2/a;
    .line 71: const-string v4, "store"
    .line 73: invoke-static {v0, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 76: const-string v4, "defaultCreationExtras"
    .line 78: invoke-static {v11, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 81: iget-object v0, v0, Landroidx/lifecycle/t0;->a:Ljava/util/LinkedHashMap;
    .line 83: const-string v4, "androidx.lifecycle.internal.SavedStateHandlesVM"
    .line 85: invoke-virtual {v0, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 88: move-result-object v5
    .line 89: check-cast v5, Landroidx/lifecycle/o0;
    .line 91: invoke-virtual {v1, v5}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 94: move-result v6
    .line 95: const/4 v7, 0
    .line 96: if-eqz v6, :cond_130
    .line 98: instance-of v11, v2, Landroidx/lifecycle/s0;
    .line 100: if-eqz v11, :cond_105
    .line 102: move-object v7, v2
    .line 103: check-cast v7, Landroidx/lifecycle/s0;
    .line 105: if-eqz v7, :cond_124
    .line 107: invoke-static {v5}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 110: check-cast v7, Landroidx/lifecycle/m0;
    .line 112: iget-object v11, v7, Landroidx/lifecycle/m0;->d:Landroidx/lifecycle/o;
    .line 114: if-eqz v11, :cond_124
    .line 116: iget-object v0, v7, Landroidx/lifecycle/m0;->e:Ll2/d;
    .line 118: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 121: invoke-static {v5, v0, v11}, Landroidx/lifecycle/j0;->a(Landroidx/lifecycle/o0;Ll2/d;Landroidx/lifecycle/o;)V
    .line 124: const-string v11, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get"
    .line 126: invoke-static {v5, v11}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 129: goto :goto_184
    .line 130: new-instance v5, Lj2/d;
    .line 132: invoke-direct {v5, v11}, Lj2/d;-><init>(Lj2/b;)V
    .line 135: sget-object v11, Landroidx/lifecycle/p0;->b:Landroidx/lifecycle/p0;
    .line 137: iget-object v6, v5, Lj2/b;->a:Ljava/util/LinkedHashMap;
    .line 139: invoke-interface {v6, v11, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 142: iget-object v11, v2, Lj2/c;->a:[Lj2/e;
    .line 144: array-length v6, v11
    .line 145: move-object v8, v7
    .line 146: if-ge v3, v6, :cond_175
    .line 148: aget-object v9, v11, v3
    .line 150: iget-object v10, v9, Lj2/e;->a:Ljava/lang/Class;
    .line 152: invoke-static {v10, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 155: move-result v10
    .line 156: if-eqz v10, :cond_172
    .line 158: iget-object v8, v9, Lj2/e;->b:Ld3/c;
    .line 160: invoke-interface {v8, v5}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 163: move-result-object v8
    .line 164: instance-of v9, v8, Landroidx/lifecycle/o0;
    .line 166: if-eqz v9, :cond_171
    .line 168: check-cast v8, Landroidx/lifecycle/o0;
    .line 170: goto :goto_172
    .line 171: move-object v8, v7
    .line 172: add-int/lit8 v3, v3, 1
    .line 174: goto :goto_146
    .line 175: if-eqz v8, :cond_187
    .line 177: invoke-interface {v0, v4, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 180: move-result-object v11
    .line 181: check-cast v11, Landroidx/lifecycle/o0;
    .line 183: move-object v5, v8
    .line 184: check-cast v5, Landroidx/lifecycle/l0;
    .line 186: return-object v5
    .line 187: new-instance v11, Ljava/lang/IllegalArgumentException;
    .line 189: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 192: move-result-object v0
    .line 193: const-string v1, "No initializer set for given class "
    .line 195: invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 198: move-result-object v0
    .line 199: invoke-direct {v11, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 202: throw v11
    .line 203: invoke-interface {v2}, Landroidx/lifecycle/r0;->create()Landroidx/lifecycle/o0;
    .line 206: throw v7
.end method

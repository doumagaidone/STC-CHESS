.class public final Landroidx/lifecycle/b0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:Landroidx/lifecycle/c0;

# direct methods
.method public constructor <init>(Landroidx/lifecycle/c0;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/lifecycle/b0;->a:Landroidx/lifecycle/c0;
    .line 5: return-void
.end method

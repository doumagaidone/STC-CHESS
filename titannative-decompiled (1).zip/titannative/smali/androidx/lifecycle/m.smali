.class public final enum Landroidx/lifecycle/m;
.super Ljava/lang/Enum;
.source "SourceFile"

.field private static final synthetic $VALUES:[Landroidx/lifecycle/m;
.field public static final Companion:Landroidx/lifecycle/k;
.field public static final enum ON_ANY:Landroidx/lifecycle/m;
.field public static final enum ON_CREATE:Landroidx/lifecycle/m;
.field public static final enum ON_DESTROY:Landroidx/lifecycle/m;
.field public static final enum ON_PAUSE:Landroidx/lifecycle/m;
.field public static final enum ON_RESUME:Landroidx/lifecycle/m;
.field public static final enum ON_START:Landroidx/lifecycle/m;
.field public static final enum ON_STOP:Landroidx/lifecycle/m;

# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 0: new-instance v0, Landroidx/lifecycle/m;
    .line 2: const-string v1, "ON_CREATE"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;
    .line 10: new-instance v1, Landroidx/lifecycle/m;
    .line 12: const-string v2, "ON_START"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 20: new-instance v2, Landroidx/lifecycle/m;
    .line 22: const-string v3, "ON_RESUME"
    .line 24: const/4 v4, 2
    .line 25: invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 28: sput-object v2, Landroidx/lifecycle/m;->ON_RESUME:Landroidx/lifecycle/m;
    .line 30: new-instance v3, Landroidx/lifecycle/m;
    .line 32: const-string v4, "ON_PAUSE"
    .line 34: const/4 v5, 3
    .line 35: invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 38: sput-object v3, Landroidx/lifecycle/m;->ON_PAUSE:Landroidx/lifecycle/m;
    .line 40: new-instance v4, Landroidx/lifecycle/m;
    .line 42: const-string v5, "ON_STOP"
    .line 44: const/4 v6, 4
    .line 45: invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 48: sput-object v4, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;
    .line 50: new-instance v5, Landroidx/lifecycle/m;
    .line 52: const-string v6, "ON_DESTROY"
    .line 54: const/4 v7, 5
    .line 55: invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 58: sput-object v5, Landroidx/lifecycle/m;->ON_DESTROY:Landroidx/lifecycle/m;
    .line 60: new-instance v6, Landroidx/lifecycle/m;
    .line 62: const-string v7, "ON_ANY"
    .line 64: const/4 v8, 6
    .line 65: invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 68: sput-object v6, Landroidx/lifecycle/m;->ON_ANY:Landroidx/lifecycle/m;
    .line 70: filled-new-array/range {v0 .. v6}, [Landroidx/lifecycle/m;
    .line 73: move-result-object v0
    .line 74: sput-object v0, Landroidx/lifecycle/m;->$VALUES:[Landroidx/lifecycle/m;
    .line 76: new-instance v0, Landroidx/lifecycle/k;
    .line 78: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 81: sput-object v0, Landroidx/lifecycle/m;->Companion:Landroidx/lifecycle/k;
    .line 83: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Landroidx/lifecycle/m;
    .registers 2

    .line 0: const-class v0, Landroidx/lifecycle/m;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Landroidx/lifecycle/m;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Landroidx/lifecycle/m;
    .registers 1

    .line 0: sget-object v0, Landroidx/lifecycle/m;->$VALUES:[Landroidx/lifecycle/m;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Landroidx/lifecycle/m;
    .line 8: return-object v0
.end method

# virtual methods
.method public final a()Landroidx/lifecycle/n;
    .registers 4

    .line 0: sget-object v0, Landroidx/lifecycle/l;->a:[I
    .line 2: invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_46
    .line 11: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 13: new-instance v1, Ljava/lang/StringBuilder;
    .line 15: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 18: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 21: const-string v2, " has no target state"
    .line 23: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 29: move-result-object v1
    .line 30: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 33: throw v0
    .line 34: sget-object v0, Landroidx/lifecycle/n;->i:Landroidx/lifecycle/n;
    .line 36: return-object v0
    .line 37: sget-object v0, Landroidx/lifecycle/n;->m:Landroidx/lifecycle/n;
    .line 39: return-object v0
    .line 40: sget-object v0, Landroidx/lifecycle/n;->l:Landroidx/lifecycle/n;
    .line 42: return-object v0
    .line 43: sget-object v0, Landroidx/lifecycle/n;->k:Landroidx/lifecycle/n;
    .line 45: return-object v0
    .line 46: nop
    .line 47: move-wide/16 v1, v0
    .line 50: new-array v0, v0, B
    .line 52: new-array v0, v0, B
    .line 54: instance-of v0, v0, B
    .line 56: instance-of v0, v0, B
    .line 58: monitor-enter v0
    .line 59: nop
    .line 60: const-string v0, ""
.end method

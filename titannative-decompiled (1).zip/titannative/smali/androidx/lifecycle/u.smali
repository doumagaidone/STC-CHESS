.class public final Landroidx/lifecycle/u;
.super Ljava/lang/Object;
.source "SourceFile"

.field public a:Landroidx/lifecycle/n;
.field public b:Landroidx/lifecycle/r;

# virtual methods
.method public final a(Landroidx/lifecycle/t;Landroidx/lifecycle/m;)V
    .registers 6

    .line 0: invoke-virtual {v5}, Landroidx/lifecycle/m;->a()Landroidx/lifecycle/n;
    .line 3: move-result-object v0
    .line 4: iget-object v1, v3, Landroidx/lifecycle/u;->a:Landroidx/lifecycle/n;
    .line 6: const-string v2, "state1"
    .line 8: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: invoke-virtual {v0, v1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I
    .line 14: move-result v2
    .line 15: if-gez v2, :cond_18
    .line 17: move-object v1, v0
    .line 18: iput-object v1, v3, Landroidx/lifecycle/u;->a:Landroidx/lifecycle/n;
    .line 20: iget-object v1, v3, Landroidx/lifecycle/u;->b:Landroidx/lifecycle/r;
    .line 22: invoke-interface {v1, v4, v5}, Landroidx/lifecycle/r;->d(Landroidx/lifecycle/t;Landroidx/lifecycle/m;)V
    .line 25: iput-object v0, v3, Landroidx/lifecycle/u;->a:Landroidx/lifecycle/n;
    .line 27: return-void
.end method

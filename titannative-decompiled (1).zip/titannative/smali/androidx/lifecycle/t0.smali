.class public final Landroidx/lifecycle/t0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/LinkedHashMap;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/LinkedHashMap;
    .line 5: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/t0;->a:Ljava/util/LinkedHashMap;
    .line 10: return-void
.end method

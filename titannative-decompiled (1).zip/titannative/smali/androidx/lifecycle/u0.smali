.class public abstract interface Landroidx/lifecycle/u0;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract getViewModelStore()Landroidx/lifecycle/t0;
.end method

.class public final enum Landroidx/lifecycle/n;
.super Ljava/lang/Enum;
.source "SourceFile"

.field public static final enum i:Landroidx/lifecycle/n;
.field public static final enum j:Landroidx/lifecycle/n;
.field public static final enum k:Landroidx/lifecycle/n;
.field public static final enum l:Landroidx/lifecycle/n;
.field public static final enum m:Landroidx/lifecycle/n;
.field public static final synthetic n:[Landroidx/lifecycle/n;

# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 0: new-instance v0, Landroidx/lifecycle/n;
    .line 2: const-string v1, "DESTROYED"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Landroidx/lifecycle/n;->i:Landroidx/lifecycle/n;
    .line 10: new-instance v1, Landroidx/lifecycle/n;
    .line 12: const-string v2, "INITIALIZED"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Landroidx/lifecycle/n;->j:Landroidx/lifecycle/n;
    .line 20: new-instance v2, Landroidx/lifecycle/n;
    .line 22: const-string v3, "CREATED"
    .line 24: const/4 v4, 2
    .line 25: invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 28: sput-object v2, Landroidx/lifecycle/n;->k:Landroidx/lifecycle/n;
    .line 30: new-instance v3, Landroidx/lifecycle/n;
    .line 32: const-string v4, "STARTED"
    .line 34: const/4 v5, 3
    .line 35: invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 38: sput-object v3, Landroidx/lifecycle/n;->l:Landroidx/lifecycle/n;
    .line 40: new-instance v4, Landroidx/lifecycle/n;
    .line 42: const-string v5, "RESUMED"
    .line 44: const/4 v6, 4
    .line 45: invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 48: sput-object v4, Landroidx/lifecycle/n;->m:Landroidx/lifecycle/n;
    .line 50: filled-new-array {v0, v1, v2, v3, v4}, [Landroidx/lifecycle/n;
    .line 53: move-result-object v0
    .line 54: sput-object v0, Landroidx/lifecycle/n;->n:[Landroidx/lifecycle/n;
    .line 56: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Landroidx/lifecycle/n;
    .registers 2

    .line 0: const-class v0, Landroidx/lifecycle/n;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Landroidx/lifecycle/n;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Landroidx/lifecycle/n;
    .registers 1

    .line 0: sget-object v0, Landroidx/lifecycle/n;->n:[Landroidx/lifecycle/n;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Landroidx/lifecycle/n;
    .line 8: return-object v0
.end method

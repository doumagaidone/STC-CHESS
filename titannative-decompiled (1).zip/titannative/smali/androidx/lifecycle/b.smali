.class public final Landroidx/lifecycle/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/HashMap;
.field public final b:Ljava/util/Map;

# direct methods
.method public constructor <init>(Ljava/util/HashMap;)V
    .registers 6

    .line 0: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v5, v4, Landroidx/lifecycle/b;->b:Ljava/util/Map;
    .line 5: new-instance v0, Ljava/util/HashMap;
    .line 7: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 10: iput-object v0, v4, Landroidx/lifecycle/b;->a:Ljava/util/HashMap;
    .line 12: invoke-virtual {v5}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;
    .line 15: move-result-object v5
    .line 16: invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 19: move-result-object v5
    .line 20: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 23: move-result v0
    .line 24: if-eqz v0, :cond_68
    .line 26: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 29: move-result-object v0
    .line 30: check-cast v0, Ljava/util/Map$Entry;
    .line 32: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 35: move-result-object v1
    .line 36: check-cast v1, Landroidx/lifecycle/m;
    .line 38: iget-object v2, v4, Landroidx/lifecycle/b;->a:Ljava/util/HashMap;
    .line 40: invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 43: move-result-object v2
    .line 44: check-cast v2, Ljava/util/List;
    .line 46: if-nez v2, :cond_58
    .line 48: new-instance v2, Ljava/util/ArrayList;
    .line 50: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 53: iget-object v3, v4, Landroidx/lifecycle/b;->a:Ljava/util/HashMap;
    .line 55: invoke-virtual {v3, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 58: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 61: move-result-object v0
    .line 62: check-cast v0, Landroidx/lifecycle/c;
    .line 64: invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 67: goto :goto_20
    .line 68: return-void
.end method

# direct methods
.method public static a(Ljava/util/List;Landroidx/lifecycle/t;Landroidx/lifecycle/m;Ljava/lang/Object;)V
    .registers 9

    .line 0: if-eqz v5, :cond_78
    .line 2: invoke-interface {v5}, Ljava/util/List;->size()I
    .line 5: move-result v0
    .line 6: const/4 v1, 1
    .line 7: sub-int/2addr v0, v1
    .line 8: if-ltz v0, :cond_78
    .line 10: invoke-interface {v5, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 13: move-result-object v2
    .line 14: check-cast v2, Landroidx/lifecycle/c;
    .line 16: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 19: iget v3, v2, Landroidx/lifecycle/c;->a:I
    .line 21: iget-object v2, v2, Landroidx/lifecycle/c;->b:Ljava/lang/reflect/Method;
    .line 23: if-eqz v3, :cond_51
    .line 25: if-eq v3, v1, :cond_43
    .line 27: const/4 v4, 2
    .line 28: if-eq v3, v4, :cond_31
    .line 30: goto :goto_57
    .line 31: filled-new-array {v6, v7}, [Ljava/lang/Object;
    .line 34: move-result-object v3
    .line 35: invoke-virtual {v2, v8, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 38: goto :goto_57
    .line 39: move-exception v5
    .line 40: goto :goto_60
    .line 41: move-exception v5
    .line 42: goto :goto_66
    .line 43: filled-new-array {v6}, [Ljava/lang/Object;
    .line 46: move-result-object v3
    .line 47: invoke-virtual {v2, v8, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 50: goto :goto_57
    .line 51: const/4 v3, 0
    .line 52: new-array v3, v3, [Ljava/lang/Object;
    .line 54: invoke-virtual {v2, v8, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 57: add-int/lit8 v0, v0, -1
    .line 59: goto :goto_8
    .line 60: new-instance v6, Ljava/lang/RuntimeException;
    .line 62: invoke-direct {v6, v5}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 65: throw v6
    .line 66: new-instance v6, Ljava/lang/RuntimeException;
    .line 68: const-string v7, "Failed to call observer method"
    .line 70: invoke-virtual {v5}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 73: move-result-object v5
    .line 74: invoke-direct {v6, v7, v5}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 77: throw v6
    .line 78: return-void
.end method

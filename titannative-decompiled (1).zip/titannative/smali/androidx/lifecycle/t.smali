.class public abstract interface Landroidx/lifecycle/t;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract getLifecycle()Landroidx/lifecycle/o;
.end method

.class public abstract interface Landroidx/lifecycle/h;
.super Ljava/lang/Object;
.source "SourceFile"

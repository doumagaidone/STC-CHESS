.class public final Landroidx/lifecycle/f0;
.super Landroid/app/Fragment;
.source "SourceFile"

.field public static final synthetic j:I

.field public i:Landroidx/lifecycle/b0;

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Landroid/app/Fragment;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method public final a(Landroidx/lifecycle/m;)V
    .registers 4

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 29
    .line 4: if-ge v0, v1, :cond_18
    .line 6: invoke-virtual {v2}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;
    .line 9: move-result-object v0
    .line 10: const-string v1, "activity"
    .line 12: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: invoke-static {v0, v3}, Lz3/b;->r(Landroid/app/Activity;Landroidx/lifecycle/m;)V
    .line 18: return-void
.end method

# virtual methods
.method public final onActivityCreated(Landroid/os/Bundle;)V
    .registers 2

    .line 0: invoke-super {v0, v1}, Landroid/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V
    .line 3: sget-object v1, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;
    .line 5: invoke-virtual {v0, v1}, Landroidx/lifecycle/f0;->a(Landroidx/lifecycle/m;)V
    .line 8: return-void
.end method

# virtual methods
.method public final onDestroy()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onDestroy()V
    .line 3: sget-object v0, Landroidx/lifecycle/m;->ON_DESTROY:Landroidx/lifecycle/m;
    .line 5: invoke-virtual {v1, v0}, Landroidx/lifecycle/f0;->a(Landroidx/lifecycle/m;)V
    .line 8: const/4 v0, 0
    .line 9: iput-object v0, v1, Landroidx/lifecycle/f0;->i:Landroidx/lifecycle/b0;
    .line 11: return-void
.end method

# virtual methods
.method public final onPause()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onPause()V
    .line 3: sget-object v0, Landroidx/lifecycle/m;->ON_PAUSE:Landroidx/lifecycle/m;
    .line 5: invoke-virtual {v1, v0}, Landroidx/lifecycle/f0;->a(Landroidx/lifecycle/m;)V
    .line 8: return-void
.end method

# virtual methods
.method public final onResume()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onResume()V
    .line 3: iget-object v0, v1, Landroidx/lifecycle/f0;->i:Landroidx/lifecycle/b0;
    .line 5: if-eqz v0, :cond_12
    .line 7: iget-object v0, v0, Landroidx/lifecycle/b0;->a:Landroidx/lifecycle/c0;
    .line 9: invoke-virtual {v0}, Landroidx/lifecycle/c0;->a()V
    .line 12: sget-object v0, Landroidx/lifecycle/m;->ON_RESUME:Landroidx/lifecycle/m;
    .line 14: invoke-virtual {v1, v0}, Landroidx/lifecycle/f0;->a(Landroidx/lifecycle/m;)V
    .line 17: return-void
.end method

# virtual methods
.method public final onStart()V
    .registers 4

    .line 0: invoke-super {v3}, Landroid/app/Fragment;->onStart()V
    .line 3: iget-object v0, v3, Landroidx/lifecycle/f0;->i:Landroidx/lifecycle/b0;
    .line 5: if-eqz v0, :cond_31
    .line 7: iget-object v0, v0, Landroidx/lifecycle/b0;->a:Landroidx/lifecycle/c0;
    .line 9: iget v1, v0, Landroidx/lifecycle/c0;->i:I
    .line 11: const/4 v2, 1
    .line 12: add-int/2addr v1, v2
    .line 13: iput v1, v0, Landroidx/lifecycle/c0;->i:I
    .line 15: if-ne v1, v2, :cond_31
    .line 17: iget-boolean v1, v0, Landroidx/lifecycle/c0;->l:Z
    .line 19: if-eqz v1, :cond_31
    .line 21: iget-object v1, v0, Landroidx/lifecycle/c0;->n:Landroidx/lifecycle/v;
    .line 23: sget-object v2, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 25: invoke-virtual {v1, v2}, Landroidx/lifecycle/v;->e(Landroidx/lifecycle/m;)V
    .line 28: const/4 v1, 0
    .line 29: iput-boolean v1, v0, Landroidx/lifecycle/c0;->l:Z
    .line 31: sget-object v0, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 33: invoke-virtual {v3, v0}, Landroidx/lifecycle/f0;->a(Landroidx/lifecycle/m;)V
    .line 36: return-void
.end method

# virtual methods
.method public final onStop()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onStop()V
    .line 3: sget-object v0, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;
    .line 5: invoke-virtual {v1, v0}, Landroidx/lifecycle/f0;->a(Landroidx/lifecycle/m;)V
    .line 8: return-void
.end method

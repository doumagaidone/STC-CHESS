.class public final Landroidx/lifecycle/k;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroidx/lifecycle/n;)Landroidx/lifecycle/m;
    .registers 2

    .line 0: const-string v0, "state"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 8: move-result v1
    .line 9: const/4 v0, 2
    .line 10: if-eq v1, v0, :cond_26
    .line 12: const/4 v0, 3
    .line 13: if-eq v1, v0, :cond_23
    .line 15: const/4 v0, 4
    .line 16: if-eq v1, v0, :cond_20
    .line 18: const/4 v1, 0
    .line 19: goto :goto_28
    .line 20: sget-object v1, Landroidx/lifecycle/m;->ON_PAUSE:Landroidx/lifecycle/m;
    .line 22: goto :goto_28
    .line 23: sget-object v1, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;
    .line 25: goto :goto_28
    .line 26: sget-object v1, Landroidx/lifecycle/m;->ON_DESTROY:Landroidx/lifecycle/m;
    .line 28: return-object v1
.end method

# direct methods
.method public static b(Landroidx/lifecycle/n;)Landroidx/lifecycle/m;
    .registers 2

    .line 0: const-string v0, "state"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 8: move-result v1
    .line 9: const/4 v0, 1
    .line 10: if-eq v1, v0, :cond_26
    .line 12: const/4 v0, 2
    .line 13: if-eq v1, v0, :cond_23
    .line 15: const/4 v0, 3
    .line 16: if-eq v1, v0, :cond_20
    .line 18: const/4 v1, 0
    .line 19: goto :goto_28
    .line 20: sget-object v1, Landroidx/lifecycle/m;->ON_RESUME:Landroidx/lifecycle/m;
    .line 22: goto :goto_28
    .line 23: sget-object v1, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 25: goto :goto_28
    .line 26: sget-object v1, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;
    .line 28: return-object v1
.end method

# direct methods
.method public static c(Landroidx/lifecycle/n;)Landroidx/lifecycle/m;
    .registers 2

    .line 0: const-string v0, "state"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I
    .line 8: move-result v1
    .line 9: const/4 v0, 2
    .line 10: if-eq v1, v0, :cond_26
    .line 12: const/4 v0, 3
    .line 13: if-eq v1, v0, :cond_23
    .line 15: const/4 v0, 4
    .line 16: if-eq v1, v0, :cond_20
    .line 18: const/4 v1, 0
    .line 19: goto :goto_28
    .line 20: sget-object v1, Landroidx/lifecycle/m;->ON_RESUME:Landroidx/lifecycle/m;
    .line 22: goto :goto_28
    .line 23: sget-object v1, Landroidx/lifecycle/m;->ON_START:Landroidx/lifecycle/m;
    .line 25: goto :goto_28
    .line 26: sget-object v1, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;
    .line 28: return-object v1
.end method

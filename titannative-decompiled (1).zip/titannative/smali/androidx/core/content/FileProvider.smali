.class public Landroidx/core/content/FileProvider;
.super Landroid/content/ContentProvider;
.source "SourceFile"

.field public static final k:[Ljava/lang/String;
.field public static final l:Ljava/io/File;
.field public static final m:Ljava/util/HashMap;

.field public i:Lw1/c;
.field public j:Ljava/lang/String;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const-string v0, "_display_name"
    .line 2: const-string v1, "_size"
    .line 4: filled-new-array {v0, v1}, [Ljava/lang/String;
    .line 7: move-result-object v0
    .line 8: sput-object v0, Landroidx/core/content/FileProvider;->k:[Ljava/lang/String;
    .line 10: new-instance v0, Ljava/io/File;
    .line 12: const-string v1, "/"
    .line 14: invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    .line 17: sput-object v0, Landroidx/core/content/FileProvider;->l:Ljava/io/File;
    .line 19: new-instance v0, Ljava/util/HashMap;
    .line 21: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 24: sput-object v0, Landroidx/core/content/FileProvider;->m:Ljava/util/HashMap;
    .line 26: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Landroid/content/ContentProvider;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static b(Landroid/content/Context;Ljava/lang/String;)Lw1/c;
    .registers 4

    .line 0: sget-object v0, Landroidx/core/content/FileProvider;->m:Ljava/util/HashMap;
    .line 2: monitor-enter v0
    .line 3: invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 6: move-result-object v1
    .line 7: check-cast v1, Lw1/c;
    .line 9: if-nez v1, :cond_39
    .line 11: invoke-static {v2, v3}, Landroidx/core/content/FileProvider;->c(Landroid/content/Context;Ljava/lang/String;)Lw1/c;
    .line 14: move-result-object v1
    .line 15: invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 18: goto :goto_39
    .line 19: move-exception v2
    .line 20: goto :goto_41
    .line 21: move-exception v2
    .line 22: new-instance v3, Ljava/lang/IllegalArgumentException;
    .line 24: const-string v1, "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data"
    .line 26: invoke-direct {v3, v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 29: throw v3
    .line 30: move-exception v2
    .line 31: new-instance v3, Ljava/lang/IllegalArgumentException;
    .line 33: const-string v1, "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data"
    .line 35: invoke-direct {v3, v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 38: throw v3
    .line 39: monitor-exit v0
    .line 40: return-object v1
    .line 41: monitor-exit v0
    .line 42: throw v2
.end method

# direct methods
.method public static c(Landroid/content/Context;Ljava/lang/String;)Lw1/c;
    .registers 9

    .line 0: new-instance v0, Lw1/c;
    .line 2: invoke-direct {v0, v8}, Lw1/c;-><init>(Ljava/lang/String;)V
    .line 5: invoke-virtual {v7}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 8: move-result-object v1
    .line 9: const/16 v2, 128
    .line 11: invoke-virtual {v1, v8, v2}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;
    .line 14: move-result-object v1
    .line 15: if-eqz v1, :cond_231
    .line 17: invoke-virtual {v7}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 20: move-result-object v8
    .line 21: const-string v2, "android.support.FILE_PROVIDER_PATHS"
    .line 23: invoke-virtual {v1, v8, v2}, Landroid/content/pm/PackageItemInfo;->loadXmlMetaData(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/res/XmlResourceParser;
    .line 26: move-result-object v8
    .line 27: if-eqz v8, :cond_223
    .line 29: invoke-interface {v8}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 32: move-result v1
    .line 33: const/4 v2, 1
    .line 34: if-eq v1, v2, :cond_222
    .line 36: const/4 v2, 2
    .line 37: if-ne v1, v2, :cond_29
    .line 39: invoke-interface {v8}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    .line 42: move-result-object v1
    .line 43: const/4 v2, 0
    .line 44: const-string v3, "name"
    .line 46: invoke-interface {v8, v2, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 49: move-result-object v3
    .line 50: const-string v4, "path"
    .line 52: invoke-interface {v8, v2, v4}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 55: move-result-object v4
    .line 56: const-string v5, "root-path"
    .line 58: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 61: move-result v5
    .line 62: const/4 v6, 0
    .line 63: if-eqz v5, :cond_68
    .line 65: sget-object v2, Landroidx/core/content/FileProvider;->l:Ljava/io/File;
    .line 67: goto :goto_160
    .line 68: const-string v5, "files-path"
    .line 70: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 73: move-result v5
    .line 74: if-eqz v5, :cond_81
    .line 76: invoke-virtual {v7}, Landroid/content/Context;->getFilesDir()Ljava/io/File;
    .line 79: move-result-object v2
    .line 80: goto :goto_160
    .line 81: const-string v5, "cache-path"
    .line 83: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 86: move-result v5
    .line 87: if-eqz v5, :cond_94
    .line 89: invoke-virtual {v7}, Landroid/content/Context;->getCacheDir()Ljava/io/File;
    .line 92: move-result-object v2
    .line 93: goto :goto_160
    .line 94: const-string v5, "external-path"
    .line 96: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 99: move-result v5
    .line 100: if-eqz v5, :cond_107
    .line 102: invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;
    .line 105: move-result-object v2
    .line 106: goto :goto_160
    .line 107: const-string v5, "external-files-path"
    .line 109: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 112: move-result v5
    .line 113: if-eqz v5, :cond_125
    .line 115: invoke-static {v7, v2}, Lw1/a;->b(Landroid/content/Context;Ljava/lang/String;)[Ljava/io/File;
    .line 118: move-result-object v1
    .line 119: array-length v5, v1
    .line 120: if-lez v5, :cond_160
    .line 122: aget-object v2, v1, v6
    .line 124: goto :goto_160
    .line 125: const-string v5, "external-cache-path"
    .line 127: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 130: move-result v5
    .line 131: if-eqz v5, :cond_143
    .line 133: invoke-static {v7}, Lw1/a;->a(Landroid/content/Context;)[Ljava/io/File;
    .line 136: move-result-object v1
    .line 137: array-length v5, v1
    .line 138: if-lez v5, :cond_160
    .line 140: aget-object v2, v1, v6
    .line 142: goto :goto_160
    .line 143: const-string v5, "external-media-path"
    .line 145: invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 148: move-result v1
    .line 149: if-eqz v1, :cond_160
    .line 151: invoke-static {v7}, Lw1/b;->a(Landroid/content/Context;)[Ljava/io/File;
    .line 154: move-result-object v1
    .line 155: array-length v5, v1
    .line 156: if-lez v5, :cond_160
    .line 158: aget-object v2, v1, v6
    .line 160: if-eqz v2, :cond_29
    .line 162: filled-new-array {v4}, [Ljava/lang/String;
    .line 165: move-result-object v1
    .line 166: aget-object v1, v1, v6
    .line 168: if-eqz v1, :cond_176
    .line 170: new-instance v4, Ljava/io/File;
    .line 172: invoke-direct {v4, v2, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 175: move-object v2, v4
    .line 176: invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    .line 179: move-result v1
    .line 180: if-nez v1, :cond_214
    .line 182: invoke-virtual {v2}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;
    .line 185: move-result-object v1
    .line 186: iget-object v2, v0, Lw1/c;->b:Ljava/util/HashMap;
    .line 188: invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 191: goto/16 :goto_29
    .line 193: move-exception v7
    .line 194: new-instance v8, Ljava/lang/IllegalArgumentException;
    .line 196: new-instance v0, Ljava/lang/StringBuilder;
    .line 198: const-string v1, "Failed to resolve canonical path for "
    .line 200: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 203: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 206: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 209: move-result-object v0
    .line 210: invoke-direct {v8, v0, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 213: throw v8
    .line 214: new-instance v7, Ljava/lang/IllegalArgumentException;
    .line 216: const-string v8, "Name must not be empty"
    .line 218: invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 221: throw v7
    .line 222: return-object v0
    .line 223: new-instance v7, Ljava/lang/IllegalArgumentException;
    .line 225: const-string v8, "Missing android.support.FILE_PROVIDER_PATHS meta-data"
    .line 227: invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 230: throw v7
    .line 231: new-instance v7, Ljava/lang/IllegalArgumentException;
    .line 233: new-instance v0, Ljava/lang/StringBuilder;
    .line 235: const-string v1, "Couldn't find meta-data for provider with authority "
    .line 237: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 240: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 243: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 246: move-result-object v8
    .line 247: invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 250: throw v7
.end method

# virtual methods
.method public final a()Lw1/c;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: iget-object v0, v2, Landroidx/core/content/FileProvider;->i:Lw1/c;
    .line 3: if-nez v0, :cond_20
    .line 5: invoke-virtual {v2}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;
    .line 8: move-result-object v0
    .line 9: iget-object v1, v2, Landroidx/core/content/FileProvider;->j:Ljava/lang/String;
    .line 11: invoke-static {v0, v1}, Landroidx/core/content/FileProvider;->b(Landroid/content/Context;Ljava/lang/String;)Lw1/c;
    .line 14: move-result-object v0
    .line 15: iput-object v0, v2, Landroidx/core/content/FileProvider;->i:Lw1/c;
    .line 17: goto :goto_20
    .line 18: move-exception v0
    .line 19: goto :goto_24
    .line 20: iget-object v0, v2, Landroidx/core/content/FileProvider;->i:Lw1/c;
    .line 22: monitor-exit v2
    .line 23: return-object v0
    .line 24: monitor-exit v2
    .line 25: throw v0
.end method

# virtual methods
.method public final attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    .registers 3

    .line 0: invoke-super {v0, v1, v2}, Landroid/content/ContentProvider;->attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    .line 3: iget-boolean v1, v2, Landroid/content/pm/ProviderInfo;->exported:Z
    .line 5: if-nez v1, :cond_45
    .line 7: iget-boolean v1, v2, Landroid/content/pm/ProviderInfo;->grantUriPermissions:Z
    .line 9: if-eqz v1, :cond_37
    .line 11: iget-object v1, v2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;
    .line 13: const-string v2, ";"
    .line 15: invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    .line 18: move-result-object v1
    .line 19: const/4 v2, 0
    .line 20: aget-object v1, v1, v2
    .line 22: iput-object v1, v0, Landroidx/core/content/FileProvider;->j:Ljava/lang/String;
    .line 24: sget-object v1, Landroidx/core/content/FileProvider;->m:Ljava/util/HashMap;
    .line 26: monitor-enter v1
    .line 27: iget-object v2, v0, Landroidx/core/content/FileProvider;->j:Ljava/lang/String;
    .line 29: invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 32: monitor-exit v1
    .line 33: return-void
    .line 34: move-exception v2
    .line 35: monitor-exit v1
    .line 36: throw v2
    .line 37: new-instance v1, Ljava/lang/SecurityException;
    .line 39: const-string v2, "Provider must grant uri permissions"
    .line 41: invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V
    .line 44: throw v1
    .line 45: new-instance v1, Ljava/lang/SecurityException;
    .line 47: const-string v2, "Provider must not be exported"
    .line 49: invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V
    .line 52: throw v1
.end method

# virtual methods
.method public final delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 4

    .line 0: invoke-virtual {v0}, Landroidx/core/content/FileProvider;->a()Lw1/c;
    .line 3: move-result-object v2
    .line 4: invoke-virtual {v2, v1}, Lw1/c;->a(Landroid/net/Uri;)Ljava/io/File;
    .line 7: move-result-object v1
    .line 8: invoke-virtual {v1}, Ljava/io/File;->delete()Z
    .line 11: move-result v1
    .line 12: return v1
.end method

# virtual methods
.method public final getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 4

    .line 0: invoke-virtual {v2}, Landroidx/core/content/FileProvider;->a()Lw1/c;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v0, v3}, Lw1/c;->a(Landroid/net/Uri;)Ljava/io/File;
    .line 7: move-result-object v3
    .line 8: invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;
    .line 11: move-result-object v0
    .line 12: const/16 v1, 46
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/String;->lastIndexOf(I)I
    .line 17: move-result v0
    .line 18: if-ltz v0, :cond_41
    .line 20: invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;
    .line 23: move-result-object v3
    .line 24: add-int/lit8 v0, v0, 1
    .line 26: invoke-virtual {v3, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 29: move-result-object v3
    .line 30: invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;
    .line 33: move-result-object v0
    .line 34: invoke-virtual {v0, v3}, Landroid/webkit/MimeTypeMap;->getMimeTypeFromExtension(Ljava/lang/String;)Ljava/lang/String;
    .line 37: move-result-object v3
    .line 38: if-eqz v3, :cond_41
    .line 40: return-object v3
    .line 41: const-string v3, "application/octet-stream"
    .line 43: return-object v3
.end method

# virtual methods
.method public final getTypeAnonymous(Landroid/net/Uri;)Ljava/lang/String;
    .registers 2

    .line 0: const-string v1, "application/octet-stream"
    .line 2: return-object v1
.end method

# virtual methods
.method public final insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 3

    .line 0: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 2: const-string v2, "No external inserts"
    .line 4: invoke-direct {v1, v2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 7: throw v1
.end method

# virtual methods
.method public final onCreate()Z
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: return v0
.end method

# virtual methods
.method public final openFile(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .registers 5

    .line 0: invoke-virtual {v2}, Landroidx/core/content/FileProvider;->a()Lw1/c;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v0, v3}, Lw1/c;->a(Landroid/net/Uri;)Ljava/io/File;
    .line 7: move-result-object v3
    .line 8: const-string v0, "r"
    .line 10: invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_19
    .line 16: const/high16 v4, 0x1000
    .line 18: goto :goto_91
    .line 19: const-string v0, "w"
    .line 21: invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 24: move-result v0
    .line 25: if-nez v0, :cond_89
    .line 27: const-string v0, "wt"
    .line 29: invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 32: move-result v0
    .line 33: if-eqz v0, :cond_36
    .line 35: goto :goto_89
    .line 36: const-string v0, "wa"
    .line 38: invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 41: move-result v0
    .line 42: if-eqz v0, :cond_47
    .line 44: const/high16 v4, 0x2a00
    .line 46: goto :goto_91
    .line 47: const-string v0, "rw"
    .line 49: invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 52: move-result v0
    .line 53: if-eqz v0, :cond_58
    .line 55: const/high16 v4, 0x3800
    .line 57: goto :goto_91
    .line 58: const-string v0, "rwt"
    .line 60: invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 63: move-result v0
    .line 64: if-eqz v0, :cond_69
    .line 66: const/high16 v4, 0x3c00
    .line 68: goto :goto_91
    .line 69: new-instance v3, Ljava/lang/IllegalArgumentException;
    .line 71: new-instance v0, Ljava/lang/StringBuilder;
    .line 73: const-string v1, "Invalid mode: "
    .line 75: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 78: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 81: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 84: move-result-object v4
    .line 85: invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 88: throw v3
    .line 89: const/high16 v4, 0x2c00
    .line 91: invoke-static {v3, v4}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;
    .line 94: move-result-object v3
    .line 95: return-object v3
.end method

# virtual methods
.method public final query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 13

    .line 0: invoke-virtual {v7}, Landroidx/core/content/FileProvider;->a()Lw1/c;
    .line 3: move-result-object v10
    .line 4: invoke-virtual {v10, v8}, Lw1/c;->a(Landroid/net/Uri;)Ljava/io/File;
    .line 7: move-result-object v10
    .line 8: const-string v11, "displayName"
    .line 10: invoke-virtual {v8, v11}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;
    .line 13: move-result-object v8
    .line 14: if-nez v9, :cond_18
    .line 16: sget-object v9, Landroidx/core/content/FileProvider;->k:[Ljava/lang/String;
    .line 18: array-length v11, v9
    .line 19: new-array v11, v11, [Ljava/lang/String;
    .line 21: array-length v12, v9
    .line 22: new-array v12, v12, [Ljava/lang/Object;
    .line 24: array-length v0, v9
    .line 25: const/4 v1, 0
    .line 26: move v2, v1
    .line 27: move v3, v2
    .line 28: if-ge v2, v0, :cond_82
    .line 30: aget-object v4, v9, v2
    .line 32: const-string v5, "_display_name"
    .line 34: invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 37: move-result v6
    .line 38: if-eqz v6, :cond_56
    .line 40: aput-object v5, v11, v3
    .line 42: add-int/lit8 v4, v3, 1
    .line 44: if-nez v8, :cond_51
    .line 46: invoke-virtual {v10}, Ljava/io/File;->getName()Ljava/lang/String;
    .line 49: move-result-object v5
    .line 50: goto :goto_52
    .line 51: move-object v5, v8
    .line 52: aput-object v5, v12, v3
    .line 54: move v3, v4
    .line 55: goto :goto_79
    .line 56: const-string v5, "_size"
    .line 58: invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 61: move-result v4
    .line 62: if-eqz v4, :cond_79
    .line 64: aput-object v5, v11, v3
    .line 66: add-int/lit8 v4, v3, 1
    .line 68: invoke-virtual {v10}, Ljava/io/File;->length()J
    .line 71: move-result-wide v5
    .line 72: invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 75: move-result-object v5
    .line 76: aput-object v5, v12, v3
    .line 78: goto :goto_54
    .line 79: add-int/lit8 v2, v2, 1
    .line 81: goto :goto_28
    .line 82: new-array v8, v3, [Ljava/lang/String;
    .line 84: invoke-static {v11, v1, v8, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 87: new-array v9, v3, [Ljava/lang/Object;
    .line 89: invoke-static {v12, v1, v9, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 92: new-instance v10, Landroid/database/MatrixCursor;
    .line 94: const/4 v11, 1
    .line 95: invoke-direct {v10, v8, v11}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;I)V
    .line 98: invoke-virtual {v10, v9}, Landroid/database/MatrixCursor;->addRow([Ljava/lang/Object;)V
    .line 101: return-object v10
.end method

# virtual methods
.method public final update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 5

    .line 0: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 2: const-string v2, "No external updates"
    .line 4: invoke-direct {v1, v2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 7: throw v1
.end method

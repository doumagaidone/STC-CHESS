.class public Landroidx/core/app/RemoteActionCompatParcelizer;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static read(Lo2/a;)Landroidx/core/app/RemoteActionCompat;
    .registers 6

    .line 0: new-instance v0, Landroidx/core/app/RemoteActionCompat;
    .line 2: invoke-direct {v0}, Landroidx/core/app/RemoteActionCompat;-><init>()V
    .line 5: iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->a:Landroidx/core/graphics/drawable/IconCompat;
    .line 7: const/4 v2, 1
    .line 8: invoke-virtual {v5, v2}, Lo2/a;->e(I)Z
    .line 11: move-result v3
    .line 12: if-nez v3, :cond_15
    .line 14: goto :goto_19
    .line 15: invoke-virtual {v5}, Lo2/a;->g()Lo2/c;
    .line 18: move-result-object v1
    .line 19: check-cast v1, Landroidx/core/graphics/drawable/IconCompat;
    .line 21: iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->a:Landroidx/core/graphics/drawable/IconCompat;
    .line 23: iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->b:Ljava/lang/CharSequence;
    .line 25: const/4 v3, 2
    .line 26: invoke-virtual {v5, v3}, Lo2/a;->e(I)Z
    .line 29: move-result v3
    .line 30: if-nez v3, :cond_33
    .line 32: goto :goto_46
    .line 33: move-object v1, v5
    .line 34: check-cast v1, Lo2/b;
    .line 36: sget-object v3, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 38: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 40: invoke-interface {v3, v1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .line 43: move-result-object v1
    .line 44: check-cast v1, Ljava/lang/CharSequence;
    .line 46: iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->b:Ljava/lang/CharSequence;
    .line 48: iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->c:Ljava/lang/CharSequence;
    .line 50: const/4 v3, 3
    .line 51: invoke-virtual {v5, v3}, Lo2/a;->e(I)Z
    .line 54: move-result v3
    .line 55: if-nez v3, :cond_58
    .line 57: goto :goto_71
    .line 58: move-object v1, v5
    .line 59: check-cast v1, Lo2/b;
    .line 61: sget-object v3, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 63: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 65: invoke-interface {v3, v1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .line 68: move-result-object v1
    .line 69: check-cast v1, Ljava/lang/CharSequence;
    .line 71: iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->c:Ljava/lang/CharSequence;
    .line 73: iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->d:Landroid/app/PendingIntent;
    .line 75: const/4 v3, 4
    .line 76: invoke-virtual {v5, v1, v3}, Lo2/a;->f(Landroid/os/Parcelable;I)Landroid/os/Parcelable;
    .line 79: move-result-object v1
    .line 80: check-cast v1, Landroid/app/PendingIntent;
    .line 82: iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->d:Landroid/app/PendingIntent;
    .line 84: iget-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->e:Z
    .line 86: const/4 v3, 5
    .line 87: invoke-virtual {v5, v3}, Lo2/a;->e(I)Z
    .line 90: move-result v3
    .line 91: const/4 v4, 0
    .line 92: if-nez v3, :cond_95
    .line 94: goto :goto_109
    .line 95: move-object v1, v5
    .line 96: check-cast v1, Lo2/b;
    .line 98: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 100: invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    .line 103: move-result v1
    .line 104: if-eqz v1, :cond_108
    .line 106: move v1, v2
    .line 107: goto :goto_109
    .line 108: move v1, v4
    .line 109: iput-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->e:Z
    .line 111: iget-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->f:Z
    .line 113: const/4 v3, 6
    .line 114: invoke-virtual {v5, v3}, Lo2/a;->e(I)Z
    .line 117: move-result v3
    .line 118: if-nez v3, :cond_121
    .line 120: goto :goto_134
    .line 121: check-cast v5, Lo2/b;
    .line 123: iget-object v5, v5, Lo2/b;->e:Landroid/os/Parcel;
    .line 125: invoke-virtual {v5}, Landroid/os/Parcel;->readInt()I
    .line 128: move-result v5
    .line 129: if-eqz v5, :cond_132
    .line 131: goto :goto_133
    .line 132: move v2, v4
    .line 133: move v1, v2
    .line 134: iput-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->f:Z
    .line 136: return-object v0
.end method

# direct methods
.method public static write(Landroidx/core/app/RemoteActionCompat;Lo2/a;)V
    .registers 6

    .line 0: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: iget-object v0, v4, Landroidx/core/app/RemoteActionCompat;->a:Landroidx/core/graphics/drawable/IconCompat;
    .line 5: const/4 v1, 1
    .line 6: invoke-virtual {v5, v1}, Lo2/a;->h(I)V
    .line 9: invoke-virtual {v5, v0}, Lo2/a;->i(Lo2/c;)V
    .line 12: iget-object v0, v4, Landroidx/core/app/RemoteActionCompat;->b:Ljava/lang/CharSequence;
    .line 14: const/4 v1, 2
    .line 15: invoke-virtual {v5, v1}, Lo2/a;->h(I)V
    .line 18: move-object v1, v5
    .line 19: check-cast v1, Lo2/b;
    .line 21: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 23: const/4 v2, 0
    .line 24: invoke-static {v0, v1, v2}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V
    .line 27: iget-object v0, v4, Landroidx/core/app/RemoteActionCompat;->c:Ljava/lang/CharSequence;
    .line 29: const/4 v3, 3
    .line 30: invoke-virtual {v5, v3}, Lo2/a;->h(I)V
    .line 33: invoke-static {v0, v1, v2}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V
    .line 36: iget-object v0, v4, Landroidx/core/app/RemoteActionCompat;->d:Landroid/app/PendingIntent;
    .line 38: const/4 v3, 4
    .line 39: invoke-virtual {v5, v3}, Lo2/a;->h(I)V
    .line 42: invoke-virtual {v1, v0, v2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V
    .line 45: iget-boolean v0, v4, Landroidx/core/app/RemoteActionCompat;->e:Z
    .line 47: const/4 v2, 5
    .line 48: invoke-virtual {v5, v2}, Lo2/a;->h(I)V
    .line 51: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInt(I)V
    .line 54: iget-boolean v4, v4, Landroidx/core/app/RemoteActionCompat;->f:Z
    .line 56: const/4 v0, 6
    .line 57: invoke-virtual {v5, v0}, Lo2/a;->h(I)V
    .line 60: invoke-virtual {v1, v4}, Landroid/os/Parcel;->writeInt(I)V
    .line 63: return-void
.end method

.class public Landroidx/core/graphics/drawable/IconCompatParcelizer;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static read(Lo2/a;)Landroidx/core/graphics/drawable/IconCompat;
    .registers 6

    .line 0: new-instance v0, Landroidx/core/graphics/drawable/IconCompat;
    .line 2: invoke-direct {v0}, Landroidx/core/graphics/drawable/IconCompat;-><init>()V
    .line 5: iget v1, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 7: const/4 v2, 1
    .line 8: invoke-virtual {v5, v2}, Lo2/a;->e(I)Z
    .line 11: move-result v2
    .line 12: if-nez v2, :cond_15
    .line 14: goto :goto_24
    .line 15: move-object v1, v5
    .line 16: check-cast v1, Lo2/b;
    .line 18: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 20: invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    .line 23: move-result v1
    .line 24: iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 26: iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 28: const/4 v2, 2
    .line 29: invoke-virtual {v5, v2}, Lo2/a;->e(I)Z
    .line 32: move-result v3
    .line 33: if-nez v3, :cond_36
    .line 35: goto :goto_55
    .line 36: move-object v1, v5
    .line 37: check-cast v1, Lo2/b;
    .line 39: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 41: invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    .line 44: move-result v3
    .line 45: if-gez v3, :cond_49
    .line 47: const/4 v1, 0
    .line 48: goto :goto_55
    .line 49: new-array v3, v3, [B
    .line 51: invoke-virtual {v1, v3}, Landroid/os/Parcel;->readByteArray([B)V
    .line 54: move-object v1, v3
    .line 55: iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 57: iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 59: const/4 v3, 3
    .line 60: invoke-virtual {v5, v1, v3}, Lo2/a;->f(Landroid/os/Parcelable;I)Landroid/os/Parcelable;
    .line 63: move-result-object v1
    .line 64: iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 66: iget v1, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I
    .line 68: const/4 v4, 4
    .line 69: invoke-virtual {v5, v4}, Lo2/a;->e(I)Z
    .line 72: move-result v4
    .line 73: if-nez v4, :cond_76
    .line 75: goto :goto_85
    .line 76: move-object v1, v5
    .line 77: check-cast v1, Lo2/b;
    .line 79: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 81: invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    .line 84: move-result v1
    .line 85: iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I
    .line 87: iget v1, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I
    .line 89: const/4 v4, 5
    .line 90: invoke-virtual {v5, v4}, Lo2/a;->e(I)Z
    .line 93: move-result v4
    .line 94: if-nez v4, :cond_97
    .line 96: goto :goto_106
    .line 97: move-object v1, v5
    .line 98: check-cast v1, Lo2/b;
    .line 100: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 102: invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    .line 105: move-result v1
    .line 106: iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I
    .line 108: iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;
    .line 110: const/4 v4, 6
    .line 111: invoke-virtual {v5, v1, v4}, Lo2/a;->f(Landroid/os/Parcelable;I)Landroid/os/Parcelable;
    .line 114: move-result-object v1
    .line 115: check-cast v1, Landroid/content/res/ColorStateList;
    .line 117: iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;
    .line 119: iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;
    .line 121: const/4 v4, 7
    .line 122: invoke-virtual {v5, v4}, Lo2/a;->e(I)Z
    .line 125: move-result v4
    .line 126: if-nez v4, :cond_129
    .line 128: goto :goto_138
    .line 129: move-object v1, v5
    .line 130: check-cast v1, Lo2/b;
    .line 132: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 134: invoke-virtual {v1}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    .line 137: move-result-object v1
    .line 138: iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;
    .line 140: iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;
    .line 142: const/16 v4, 8
    .line 144: invoke-virtual {v5, v4}, Lo2/a;->e(I)Z
    .line 147: move-result v4
    .line 148: if-nez v4, :cond_151
    .line 150: goto :goto_159
    .line 151: check-cast v5, Lo2/b;
    .line 153: iget-object v5, v5, Lo2/b;->e:Landroid/os/Parcel;
    .line 155: invoke-virtual {v5}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    .line 158: move-result-object v1
    .line 159: iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;
    .line 161: iget-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;
    .line 163: invoke-static {v5}, Landroid/graphics/PorterDuff$Mode;->valueOf(Ljava/lang/String;)Landroid/graphics/PorterDuff$Mode;
    .line 166: move-result-object v5
    .line 167: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;
    .line 169: iget v5, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 171: const/4 v1, 0
    .line 172: packed-switch v5, :data_250
    .line 175: goto :goto_241
    .line 176: iget-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 178: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 180: goto :goto_241
    .line 181: new-instance v5, Ljava/lang/String;
    .line 183: iget-object v3, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 185: const-string v4, "UTF-16"
    .line 187: invoke-static {v4}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;
    .line 190: move-result-object v4
    .line 191: invoke-direct {v5, v3, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 194: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 196: iget v3, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 198: if-ne v3, v2, :cond_241
    .line 200: iget-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;
    .line 202: if-nez v2, :cond_241
    .line 204: const-string v2, ":"
    .line 206: const/4 v3, -1
    .line 207: invoke-virtual {v5, v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;
    .line 210: move-result-object v5
    .line 211: aget-object v5, v5, v1
    .line 213: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;
    .line 215: goto :goto_241
    .line 216: iget-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 218: if-eqz v5, :cond_223
    .line 220: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 222: goto :goto_241
    .line 223: iget-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 225: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 227: iput v3, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 229: iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I
    .line 231: array-length v5, v5
    .line 232: iput v5, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I
    .line 234: goto :goto_241
    .line 235: iget-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 237: if-eqz v5, :cond_242
    .line 239: iput-object v5, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 241: return-object v0
    .line 242: new-instance v5, Ljava/lang/IllegalArgumentException;
    .line 244: const-string v0, "Invalid icon"
    .line 246: invoke-direct {v5, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 249: throw v5
    .line 250: nop
    .line 251: move-object/from16 v0, v65535
    .line 253: 0xff ; unknown opcode
    .line 254: 0x3f ; unknown opcode
    .line 255: nop
    .line 256: move/16 v0, v44
    .line 259: nop
    .line 260: move-object/16 v0, v4
    .line 263: nop
    .line 264: move-object/16 v0, v44
    .line 267: nop
    .line 268: move-object/16 v0, v1
.end method

# direct methods
.method public static write(Landroidx/core/graphics/drawable/IconCompat;Lo2/a;)V
    .registers 5

    .line 0: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;
    .line 5: invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;
    .line 8: move-result-object v0
    .line 9: iput-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;
    .line 11: iget v0, v3, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 13: const-string v1, "UTF-16"
    .line 15: packed-switch v0, :data_206
    .line 18: goto :goto_71
    .line 19: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 21: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 24: move-result-object v0
    .line 25: invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;
    .line 28: move-result-object v1
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B
    .line 32: move-result-object v0
    .line 33: iput-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 35: goto :goto_71
    .line 36: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 38: check-cast v0, [B
    .line 40: iput-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 42: goto :goto_71
    .line 43: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 45: check-cast v0, Ljava/lang/String;
    .line 47: invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;
    .line 50: move-result-object v1
    .line 51: invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B
    .line 54: move-result-object v0
    .line 55: iput-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 57: goto :goto_71
    .line 58: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 60: check-cast v0, Landroid/os/Parcelable;
    .line 62: iput-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 64: goto :goto_71
    .line 65: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;
    .line 67: check-cast v0, Landroid/os/Parcelable;
    .line 69: iput-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 71: iget v0, v3, Landroidx/core/graphics/drawable/IconCompat;->a:I
    .line 73: const/4 v1, -1
    .line 74: if-eq v1, v0, :cond_88
    .line 76: const/4 v1, 1
    .line 77: invoke-virtual {v4, v1}, Lo2/a;->h(I)V
    .line 80: move-object v1, v4
    .line 81: check-cast v1, Lo2/b;
    .line 83: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 85: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInt(I)V
    .line 88: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->c:[B
    .line 90: if-eqz v0, :cond_108
    .line 92: const/4 v1, 2
    .line 93: invoke-virtual {v4, v1}, Lo2/a;->h(I)V
    .line 96: move-object v1, v4
    .line 97: check-cast v1, Lo2/b;
    .line 99: array-length v2, v0
    .line 100: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 102: invoke-virtual {v1, v2}, Landroid/os/Parcel;->writeInt(I)V
    .line 105: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeByteArray([B)V
    .line 108: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;
    .line 110: const/4 v1, 0
    .line 111: if-eqz v0, :cond_125
    .line 113: const/4 v2, 3
    .line 114: invoke-virtual {v4, v2}, Lo2/a;->h(I)V
    .line 117: move-object v2, v4
    .line 118: check-cast v2, Lo2/b;
    .line 120: iget-object v2, v2, Lo2/b;->e:Landroid/os/Parcel;
    .line 122: invoke-virtual {v2, v0, v1}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V
    .line 125: iget v0, v3, Landroidx/core/graphics/drawable/IconCompat;->e:I
    .line 127: if-eqz v0, :cond_141
    .line 129: const/4 v2, 4
    .line 130: invoke-virtual {v4, v2}, Lo2/a;->h(I)V
    .line 133: move-object v2, v4
    .line 134: check-cast v2, Lo2/b;
    .line 136: iget-object v2, v2, Lo2/b;->e:Landroid/os/Parcel;
    .line 138: invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeInt(I)V
    .line 141: iget v0, v3, Landroidx/core/graphics/drawable/IconCompat;->f:I
    .line 143: if-eqz v0, :cond_157
    .line 145: const/4 v2, 5
    .line 146: invoke-virtual {v4, v2}, Lo2/a;->h(I)V
    .line 149: move-object v2, v4
    .line 150: check-cast v2, Lo2/b;
    .line 152: iget-object v2, v2, Lo2/b;->e:Landroid/os/Parcel;
    .line 154: invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeInt(I)V
    .line 157: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;
    .line 159: if-eqz v0, :cond_173
    .line 161: const/4 v2, 6
    .line 162: invoke-virtual {v4, v2}, Lo2/a;->h(I)V
    .line 165: move-object v2, v4
    .line 166: check-cast v2, Lo2/b;
    .line 168: iget-object v2, v2, Lo2/b;->e:Landroid/os/Parcel;
    .line 170: invoke-virtual {v2, v0, v1}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V
    .line 173: iget-object v0, v3, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;
    .line 175: if-eqz v0, :cond_189
    .line 177: const/4 v1, 7
    .line 178: invoke-virtual {v4, v1}, Lo2/a;->h(I)V
    .line 181: move-object v1, v4
    .line 182: check-cast v1, Lo2/b;
    .line 184: iget-object v1, v1, Lo2/b;->e:Landroid/os/Parcel;
    .line 186: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    .line 189: iget-object v3, v3, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;
    .line 191: if-eqz v3, :cond_205
    .line 193: const/16 v0, 8
    .line 195: invoke-virtual {v4, v0}, Lo2/a;->h(I)V
    .line 198: check-cast v4, Lo2/b;
    .line 200: iget-object v4, v4, Lo2/b;->e:Landroid/os/Parcel;
    .line 202: invoke-virtual {v4, v3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    .line 205: return-void
    .line 206: nop
    .line 207: move-object/from16 v0, v65535
    .line 209: 0xff ; unknown opcode
    .line 210: if-eq v0, v0, :cond_210
    .line 212: move/16 v0, v43
    .line 215: nop
    .line 216: const-class v0, B
    .line 218: const/high16 v0, 0x0
    .line 220: move-wide v0, v0
    .line 221: nop
    .line 222: packed-switch v0, :data_262366
    .line 225: nop
.end method

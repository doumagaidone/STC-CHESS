.class public abstract Le0/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lu/j3;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Le0/a;->j:Le0/a;
    .line 2: new-instance v1, Lu/j3;
    .line 4: invoke-direct {v1, v0}, Lu/j0;-><init>(Ld3/a;)V
    .line 7: sput-object v1, Le0/b;->a:Lu/j3;
    .line 9: return-void
.end method

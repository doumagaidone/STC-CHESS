.class public final Lf1/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ln1/c;
.field public final b:I
.field public final c:J
.field public final d:Lg1/s;
.field public final e:Ljava/lang/CharSequence;
.field public final f:Ljava/util/List;
.field public final g:Ls2/b;

# direct methods
.method public constructor <init>(Ln1/c;IZJ)V
    .registers 30

    .line 0: move-object/from16 v9, v24
    .line 2: move-object/from16 v0, v25
    .line 4: move/from16 v10, v26
    .line 6: const-string v1, "paragraphIntrinsics"
    .line 8: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: invoke-direct/range {v24 .. v24}, Ljava/lang/Object;-><init>()V
    .line 14: iput-object v0, v9, Lf1/a;->a:Ln1/c;
    .line 16: iput v10, v9, Lf1/a;->b:I
    .line 18: move-wide/from16 v11, v28
    .line 20: iput-wide v11, v9, Lf1/a;->c:J
    .line 22: invoke-static/range {v28 .. v29}, Lr1/a;->i(J)I
    .line 25: move-result v1
    .line 26: if-nez v1, :cond_872
    .line 28: invoke-static/range {v28 .. v29}, Lr1/a;->j(J)I
    .line 31: move-result v1
    .line 32: if-nez v1, :cond_872
    .line 34: const/4 v13, 1
    .line 35: if-lt v10, v13, :cond_860
    .line 37: const/4 v14, 0
    .line 38: const/4 v1, 5
    .line 39: const/4 v2, 4
    .line 40: iget-object v3, v0, Ln1/c;->h:Ljava/lang/CharSequence;
    .line 42: iget-object v15, v0, Ln1/c;->b:Lf1/b0;
    .line 44: if-eqz v27, :cond_137
    .line 46: iget-object v0, v15, Lf1/b0;->a:Lf1/w;
    .line 48: iget-wide v4, v0, Lf1/w;->h:J
    .line 50: invoke-static {v14}, Ld2/c;->Z(I)J
    .line 53: move-result-wide v6
    .line 54: invoke-static {v4, v5, v6, v7}, Lr1/k;->a(JJ)Z
    .line 57: move-result v0
    .line 58: if-nez v0, :cond_137
    .line 60: iget-object v0, v15, Lf1/b0;->a:Lf1/w;
    .line 62: iget-wide v4, v0, Lf1/w;->h:J
    .line 64: sget-wide v6, Lr1/k;->c:J
    .line 66: invoke-static {v4, v5, v6, v7}, Lr1/k;->a(JJ)Z
    .line 69: move-result v0
    .line 70: if-nez v0, :cond_137
    .line 72: iget-object v0, v15, Lf1/b0;->b:Lf1/o;
    .line 74: iget-object v4, v0, Lf1/o;->a:Lq1/l;
    .line 76: if-eqz v4, :cond_137
    .line 78: iget v4, v4, Lq1/l;->a:I
    .line 80: invoke-static {v4, v1}, Lq1/l;->a(II)Z
    .line 83: move-result v4
    .line 84: if-nez v4, :cond_137
    .line 86: iget-object v0, v0, Lf1/o;->a:Lq1/l;
    .line 88: if-nez v0, :cond_91
    .line 90: goto :goto_99
    .line 91: iget v0, v0, Lq1/l;->a:I
    .line 93: invoke-static {v0, v2}, Lq1/l;->a(II)Z
    .line 96: move-result v0
    .line 97: if-nez v0, :cond_137
    .line 99: invoke-interface {v3}, Ljava/lang/CharSequence;->length()I
    .line 102: move-result v0
    .line 103: if-nez v0, :cond_106
    .line 105: goto :goto_137
    .line 106: instance-of v0, v3, Landroid/text/Spannable;
    .line 108: if-eqz v0, :cond_113
    .line 110: check-cast v3, Landroid/text/Spannable;
    .line 112: goto :goto_119
    .line 113: new-instance v0, Landroid/text/SpannableString;
    .line 115: invoke-direct {v0, v3}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V
    .line 118: move-object v3, v0
    .line 119: new-instance v0, Li1/c;
    .line 121: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 124: invoke-interface {v3}, Ljava/lang/CharSequence;->length()I
    .line 127: move-result v4
    .line 128: sub-int/2addr v4, v13
    .line 129: invoke-interface {v3}, Ljava/lang/CharSequence;->length()I
    .line 132: move-result v5
    .line 133: sub-int/2addr v5, v13
    .line 134: invoke-static {v3, v0, v4, v5}, Ld2/c;->z0(Landroid/text/Spannable;Ljava/lang/Object;II)V
    .line 137: iput-object v3, v9, Lf1/a;->e:Ljava/lang/CharSequence;
    .line 139: iget-object v0, v15, Lf1/b0;->b:Lf1/o;
    .line 141: iget-object v0, v0, Lf1/o;->a:Lq1/l;
    .line 143: const/4 v3, 3
    .line 144: const/4 v4, 2
    .line 145: if-nez v0, :cond_148
    .line 147: goto :goto_159
    .line 148: iget v5, v0, Lq1/l;->a:I
    .line 150: invoke-static {v5, v13}, Lq1/l;->a(II)Z
    .line 153: move-result v5
    .line 154: if-eqz v5, :cond_159
    .line 156: move/from16 v16, v3
    .line 158: goto :goto_215
    .line 159: if-nez v0, :cond_162
    .line 161: goto :goto_173
    .line 162: iget v5, v0, Lq1/l;->a:I
    .line 164: invoke-static {v5, v4}, Lq1/l;->a(II)Z
    .line 167: move-result v5
    .line 168: if-eqz v5, :cond_173
    .line 170: move/from16 v16, v2
    .line 172: goto :goto_215
    .line 173: if-nez v0, :cond_176
    .line 175: goto :goto_187
    .line 176: iget v5, v0, Lq1/l;->a:I
    .line 178: invoke-static {v5, v3}, Lq1/l;->a(II)Z
    .line 181: move-result v5
    .line 182: if-eqz v5, :cond_187
    .line 184: move/from16 v16, v4
    .line 186: goto :goto_215
    .line 187: if-nez v0, :cond_190
    .line 189: goto :goto_201
    .line 190: iget v5, v0, Lq1/l;->a:I
    .line 192: invoke-static {v5, v1}, Lq1/l;->a(II)Z
    .line 195: move-result v1
    .line 196: if-eqz v1, :cond_201
    .line 198: move/from16 v16, v14
    .line 200: goto :goto_215
    .line 201: if-nez v0, :cond_204
    .line 203: goto :goto_198
    .line 204: iget v0, v0, Lq1/l;->a:I
    .line 206: const/4 v1, 6
    .line 207: invoke-static {v0, v1}, Lq1/l;->a(II)Z
    .line 210: move-result v0
    .line 211: if-eqz v0, :cond_198
    .line 213: move/from16 v16, v13
    .line 215: iget-object v0, v15, Lf1/b0;->b:Lf1/o;
    .line 217: iget-object v1, v0, Lf1/o;->a:Lq1/l;
    .line 219: if-nez v1, :cond_224
    .line 221: move/from16 v17, v14
    .line 223: goto :goto_232
    .line 224: iget v1, v1, Lq1/l;->a:I
    .line 226: invoke-static {v1, v2}, Lq1/l;->a(II)Z
    .line 229: move-result v1
    .line 230: move/from16 v17, v1
    .line 232: iget-object v1, v0, Lf1/o;->h:Lq1/d;
    .line 234: if-nez v1, :cond_237
    .line 236: goto :goto_253
    .line 237: iget v5, v1, Lq1/d;->a:I
    .line 239: if-ne v5, v4, :cond_253
    .line 241: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 243: const/16 v5, 32
    .line 245: if-gt v1, v5, :cond_250
    .line 247: move/from16 v18, v4
    .line 249: goto :goto_260
    .line 250: move/from16 v18, v2
    .line 252: goto :goto_260
    .line 253: if-nez v1, :cond_256
    .line 255: goto :goto_258
    .line 256: iget v1, v1, Lq1/d;->a:I
    .line 258: move/from16 v18, v14
    .line 260: iget-object v0, v0, Lf1/o;->g:Lq1/h;
    .line 262: const/16 v19, 0
    .line 264: if-eqz v0, :cond_276
    .line 266: iget v1, v0, Lq1/h;->a:I
    .line 268: and-int/lit16 v1, v1, 255
    .line 270: new-instance v5, Lq1/e;
    .line 272: invoke-direct {v5, v1}, Lq1/e;-><init>(I)V
    .line 275: goto :goto_278
    .line 276: move-object/from16 v5, v19
    .line 278: if-nez v5, :cond_281
    .line 280: goto :goto_292
    .line 281: iget v1, v5, Lq1/e;->a:I
    .line 283: invoke-static {v1, v13}, Lq1/e;->a(II)Z
    .line 286: move-result v1
    .line 287: if-eqz v1, :cond_292
    .line 289: move/from16 v20, v14
    .line 291: goto :goto_319
    .line 292: if-nez v5, :cond_295
    .line 294: goto :goto_306
    .line 295: iget v1, v5, Lq1/e;->a:I
    .line 297: invoke-static {v1, v4}, Lq1/e;->a(II)Z
    .line 300: move-result v1
    .line 301: if-eqz v1, :cond_306
    .line 303: move/from16 v20, v13
    .line 305: goto :goto_319
    .line 306: if-nez v5, :cond_309
    .line 308: goto :goto_289
    .line 309: iget v1, v5, Lq1/e;->a:I
    .line 311: invoke-static {v1, v3}, Lq1/e;->a(II)Z
    .line 314: move-result v1
    .line 315: if-eqz v1, :cond_289
    .line 317: move/from16 v20, v4
    .line 319: if-eqz v0, :cond_333
    .line 321: iget v1, v0, Lq1/h;->a:I
    .line 323: shr-int/lit8 v1, v1, 8
    .line 325: and-int/lit16 v1, v1, 255
    .line 327: new-instance v5, Lq1/f;
    .line 329: invoke-direct {v5, v1}, Lq1/f;-><init>(I)V
    .line 332: goto :goto_335
    .line 333: move-object/from16 v5, v19
    .line 335: if-nez v5, :cond_338
    .line 337: goto :goto_349
    .line 338: iget v1, v5, Lq1/f;->a:I
    .line 340: invoke-static {v1, v13}, Lq1/f;->a(II)Z
    .line 343: move-result v1
    .line 344: if-eqz v1, :cond_349
    .line 346: move/from16 v21, v14
    .line 348: goto :goto_390
    .line 349: if-nez v5, :cond_352
    .line 351: goto :goto_363
    .line 352: iget v1, v5, Lq1/f;->a:I
    .line 354: invoke-static {v1, v4}, Lq1/f;->a(II)Z
    .line 357: move-result v1
    .line 358: if-eqz v1, :cond_363
    .line 360: move/from16 v21, v13
    .line 362: goto :goto_390
    .line 363: if-nez v5, :cond_366
    .line 365: goto :goto_377
    .line 366: iget v1, v5, Lq1/f;->a:I
    .line 368: invoke-static {v1, v3}, Lq1/f;->a(II)Z
    .line 371: move-result v1
    .line 372: if-eqz v1, :cond_377
    .line 374: move/from16 v21, v4
    .line 376: goto :goto_390
    .line 377: if-nez v5, :cond_380
    .line 379: goto :goto_346
    .line 380: iget v1, v5, Lq1/f;->a:I
    .line 382: invoke-static {v1, v2}, Lq1/f;->a(II)Z
    .line 385: move-result v1
    .line 386: if-eqz v1, :cond_346
    .line 388: move/from16 v21, v3
    .line 390: if-eqz v0, :cond_404
    .line 392: iget v0, v0, Lq1/h;->a:I
    .line 394: shr-int/lit8 v0, v0, 16
    .line 396: and-int/lit16 v0, v0, 255
    .line 398: new-instance v1, Lq1/g;
    .line 400: invoke-direct {v1, v0}, Lq1/g;-><init>(I)V
    .line 403: goto :goto_406
    .line 404: move-object/from16 v1, v19
    .line 406: if-nez v1, :cond_409
    .line 408: goto :goto_416
    .line 409: iget v0, v1, Lq1/g;->a:I
    .line 411: if-ne v0, v13, :cond_416
    .line 413: move/from16 v22, v14
    .line 415: goto :goto_425
    .line 416: if-nez v1, :cond_419
    .line 418: goto :goto_413
    .line 419: iget v0, v1, Lq1/g;->a:I
    .line 421: if-ne v0, v4, :cond_413
    .line 423: move/from16 v22, v13
    .line 425: if-eqz v27, :cond_432
    .line 427: sget-object v0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;
    .line 429: move-object/from16 v23, v0
    .line 431: goto :goto_434
    .line 432: move-object/from16 v23, v19
    .line 434: move-object/from16 v0, v24
    .line 436: move/from16 v1, v16
    .line 438: move/from16 v2, v17
    .line 440: move-object/from16 v3, v23
    .line 442: move/from16 v4, v26
    .line 444: move/from16 v5, v18
    .line 446: move/from16 v6, v20
    .line 448: move/from16 v7, v21
    .line 450: move/from16 v8, v22
    .line 452: invoke-virtual/range {v0 .. v8}, Lf1/a;->a(IILandroid/text/TextUtils$TruncateAt;IIIII)Lg1/s;
    .line 455: move-result-object v0
    .line 456: if-eqz v27, :cond_527
    .line 458: invoke-virtual {v0}, Lg1/s;->a()I
    .line 461: move-result v1
    .line 462: invoke-static/range {v28 .. v29}, Lr1/a;->g(J)I
    .line 465: move-result v2
    .line 466: if-le v1, v2, :cond_527
    .line 468: if-le v10, v13, :cond_527
    .line 470: invoke-static/range {v28 .. v29}, Lr1/a;->g(J)I
    .line 473: move-result v1
    .line 474: move v2, v14
    .line 475: iget v3, v0, Lg1/s;->e:I
    .line 477: if-ge v2, v3, :cond_492
    .line 479: invoke-virtual {v0, v2}, Lg1/s;->d(I)F
    .line 482: move-result v3
    .line 483: int-to-float v4, v1
    .line 484: cmpl-float v3, v3, v4
    .line 486: if-lez v3, :cond_489
    .line 488: goto :goto_493
    .line 489: add-int/lit8 v2, v2, 1
    .line 491: goto :goto_475
    .line 492: move v2, v3
    .line 493: if-ltz v2, :cond_524
    .line 495: iget v1, v9, Lf1/a;->b:I
    .line 497: if-eq v2, v1, :cond_524
    .line 499: if-ge v2, v13, :cond_503
    .line 501: move v4, v13
    .line 502: goto :goto_504
    .line 503: move v4, v2
    .line 504: move-object/from16 v0, v24
    .line 506: move/from16 v1, v16
    .line 508: move/from16 v2, v17
    .line 510: move-object/from16 v3, v23
    .line 512: move/from16 v5, v18
    .line 514: move/from16 v6, v20
    .line 516: move/from16 v7, v21
    .line 518: move/from16 v8, v22
    .line 520: invoke-virtual/range {v0 .. v8}, Lf1/a;->a(IILandroid/text/TextUtils$TruncateAt;IIIII)Lg1/s;
    .line 523: move-result-object v0
    .line 524: iput-object v0, v9, Lf1/a;->d:Lg1/s;
    .line 526: goto :goto_529
    .line 527: iput-object v0, v9, Lf1/a;->d:Lg1/s;
    .line 529: iget-object v0, v9, Lf1/a;->a:Ln1/c;
    .line 531: iget-object v0, v0, Ln1/c;->g:Ln1/d;
    .line 533: iget-object v1, v15, Lf1/b0;->a:Lf1/w;
    .line 535: iget-object v2, v1, Lf1/w;->a:Lq1/q;
    .line 537: invoke-interface {v2}, Lq1/q;->c()Lk0/m;
    .line 540: move-result-object v2
    .line 541: invoke-virtual/range {v24 .. v24}, Lf1/a;->c()F
    .line 544: move-result v3
    .line 545: invoke-virtual/range {v24 .. v24}, Lf1/a;->b()F
    .line 548: move-result v4
    .line 549: invoke-static {v3, v4}, Ld2/c;->f(FF)J
    .line 552: move-result-wide v3
    .line 553: iget-object v1, v1, Lf1/w;->a:Lq1/q;
    .line 555: invoke-interface {v1}, Lq1/q;->a()F
    .line 558: move-result v1
    .line 559: invoke-virtual {v0, v2, v3, v4, v1}, Ln1/d;->a(Lk0/m;JF)V
    .line 562: iget-object v0, v9, Lf1/a;->d:Lg1/s;
    .line 564: invoke-virtual {v0}, Lg1/s;->h()Ljava/lang/CharSequence;
    .line 567: move-result-object v1
    .line 568: instance-of v1, v1, Landroid/text/Spanned;
    .line 570: if-nez v1, :cond_575
    .line 572: new-array v0, v14, [Lp1/b;
    .line 574: goto :goto_607
    .line 575: invoke-virtual {v0}, Lg1/s;->h()Ljava/lang/CharSequence;
    .line 578: move-result-object v1
    .line 579: check-cast v1, Landroid/text/Spanned;
    .line 581: invoke-virtual {v0}, Lg1/s;->h()Ljava/lang/CharSequence;
    .line 584: move-result-object v0
    .line 585: invoke-interface {v0}, Ljava/lang/CharSequence;->length()I
    .line 588: move-result v0
    .line 589: const-class v2, Lp1/b;
    .line 591: invoke-interface {v1, v14, v0, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .line 594: move-result-object v0
    .line 595: check-cast v0, [Lp1/b;
    .line 597: const-string v1, "brushSpans"
    .line 599: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 602: array-length v1, v0
    .line 603: if-nez v1, :cond_607
    .line 605: new-array v0, v14, [Lp1/b;
    .line 607: array-length v1, v0
    .line 608: move v2, v14
    .line 609: if-ge v2, v1, :cond_630
    .line 611: aget-object v3, v0, v2
    .line 613: invoke-virtual/range {v24 .. v24}, Lf1/a;->c()F
    .line 616: move-result v4
    .line 617: invoke-virtual/range {v24 .. v24}, Lf1/a;->b()F
    .line 620: move-result v5
    .line 621: invoke-static {v4, v5}, Ld2/c;->f(FF)J
    .line 624: move-result-wide v4
    .line 625: iput-wide v4, v3, Lp1/b;->c:J
    .line 627: add-int/lit8 v2, v2, 1
    .line 629: goto :goto_609
    .line 630: iget-object v0, v9, Lf1/a;->e:Ljava/lang/CharSequence;
    .line 632: instance-of v1, v0, Landroid/text/Spanned;
    .line 634: if-nez v1, :cond_640
    .line 636: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 638: goto/16 :goto_844
    .line 640: move-object v1, v0
    .line 641: check-cast v1, Landroid/text/Spanned;
    .line 643: invoke-interface {v0}, Ljava/lang/CharSequence;->length()I
    .line 646: move-result v2
    .line 647: const-class v3, Li1/i;
    .line 649: invoke-interface {v1, v14, v2, v3}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .line 652: move-result-object v1
    .line 653: const-string v2, "getSpans(0, length, PlaceholderSpan::class.java)"
    .line 655: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 658: new-instance v2, Ljava/util/ArrayList;
    .line 660: array-length v3, v1
    .line 661: invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V
    .line 664: array-length v3, v1
    .line 665: move v4, v14
    .line 666: if-ge v4, v3, :cond_843
    .line 668: aget-object v5, v1, v4
    .line 670: check-cast v5, Li1/i;
    .line 672: move-object v6, v0
    .line 673: check-cast v6, Landroid/text/Spanned;
    .line 675: invoke-interface {v6, v5}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I
    .line 678: move-result v7
    .line 679: invoke-interface {v6, v5}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I
    .line 682: move-result v6
    .line 683: iget-object v8, v9, Lf1/a;->d:Lg1/s;
    .line 685: iget-object v8, v8, Lg1/s;->d:Landroid/text/Layout;
    .line 687: invoke-virtual {v8, v7}, Landroid/text/Layout;->getLineForOffset(I)I
    .line 690: move-result v8
    .line 691: iget v10, v9, Lf1/a;->b:I
    .line 693: if-lt v8, v10, :cond_697
    .line 695: move v10, v13
    .line 696: goto :goto_698
    .line 697: move v10, v14
    .line 698: iget-object v11, v9, Lf1/a;->d:Lg1/s;
    .line 700: iget-object v11, v11, Lg1/s;->d:Landroid/text/Layout;
    .line 702: invoke-virtual {v11, v8}, Landroid/text/Layout;->getEllipsisCount(I)I
    .line 705: move-result v11
    .line 706: if-lez v11, :cond_720
    .line 708: iget-object v11, v9, Lf1/a;->d:Lg1/s;
    .line 710: iget-object v11, v11, Lg1/s;->d:Landroid/text/Layout;
    .line 712: invoke-virtual {v11, v8}, Landroid/text/Layout;->getEllipsisStart(I)I
    .line 715: move-result v11
    .line 716: if-le v6, v11, :cond_720
    .line 718: move v11, v13
    .line 719: goto :goto_721
    .line 720: move v11, v14
    .line 721: iget-object v12, v9, Lf1/a;->d:Lg1/s;
    .line 723: iget-object v12, v12, Lg1/s;->d:Landroid/text/Layout;
    .line 725: invoke-virtual {v12, v8}, Landroid/text/Layout;->getEllipsisStart(I)I
    .line 728: move-result v15
    .line 729: if-nez v15, :cond_736
    .line 731: invoke-virtual {v12, v8}, Landroid/text/Layout;->getLineEnd(I)I
    .line 734: move-result v12
    .line 735: goto :goto_744
    .line 736: invoke-virtual {v12}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;
    .line 739: move-result-object v12
    .line 740: invoke-interface {v12}, Ljava/lang/CharSequence;->length()I
    .line 743: move-result v12
    .line 744: if-le v6, v12, :cond_748
    .line 746: move v6, v13
    .line 747: goto :goto_749
    .line 748: move v6, v14
    .line 749: if-nez v11, :cond_834
    .line 751: if-nez v6, :cond_834
    .line 753: if-eqz v10, :cond_756
    .line 755: goto :goto_834
    .line 756: iget-object v6, v9, Lf1/a;->d:Lg1/s;
    .line 758: iget-object v6, v6, Lg1/s;->d:Landroid/text/Layout;
    .line 760: invoke-virtual {v6, v7}, Landroid/text/Layout;->isRtlCharAt(I)Z
    .line 763: move-result v6
    .line 764: if-eqz v6, :cond_769
    .line 766: sget-object v6, Lq1/k;->j:Lq1/k;
    .line 768: goto :goto_771
    .line 769: sget-object v6, Lq1/k;->i:Lq1/k;
    .line 771: invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I
    .line 774: move-result v6
    .line 775: if-eqz v6, :cond_798
    .line 777: if-ne v6, v13, :cond_792
    .line 779: iget-object v6, v9, Lf1/a;->d:Lg1/s;
    .line 781: invoke-virtual {v6, v7, v14}, Lg1/s;->f(IZ)F
    .line 784: move-result v6
    .line 785: invoke-virtual {v5}, Li1/i;->c()I
    .line 788: move-result v7
    .line 789: int-to-float v7, v7
    .line 790: sub-float/2addr v6, v7
    .line 791: goto :goto_804
    .line 792: new-instance v0, Lkotlinx/coroutines/internal/z;
    .line 794: invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V
    .line 797: throw v0
    .line 798: iget-object v6, v9, Lf1/a;->d:Lg1/s;
    .line 800: invoke-virtual {v6, v7, v14}, Lg1/s;->f(IZ)F
    .line 803: move-result v6
    .line 804: invoke-virtual {v5}, Li1/i;->c()I
    .line 807: move-result v7
    .line 808: int-to-float v7, v7
    .line 809: add-float/2addr v7, v6
    .line 810: iget-object v10, v9, Lf1/a;->d:Lg1/s;
    .line 812: invoke-virtual {v10, v8}, Lg1/s;->c(I)F
    .line 815: move-result v8
    .line 816: invoke-virtual {v5}, Li1/i;->b()I
    .line 819: move-result v10
    .line 820: int-to-float v10, v10
    .line 821: sub-float/2addr v8, v10
    .line 822: invoke-virtual {v5}, Li1/i;->b()I
    .line 825: move-result v5
    .line 826: int-to-float v5, v5
    .line 827: add-float/2addr v5, v8
    .line 828: new-instance v10, Lj0/d;
    .line 830: invoke-direct {v10, v6, v8, v7, v5}, Lj0/d;-><init>(FFFF)V
    .line 833: goto :goto_836
    .line 834: move-object/from16 v10, v19
    .line 836: invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 839: add-int/lit8 v4, v4, 1
    .line 841: goto/16 :goto_666
    .line 843: move-object v0, v2
    .line 844: iput-object v0, v9, Lf1/a;->f:Ljava/util/List;
    .line 846: new-instance v0, Lh/i0;
    .line 848: const/16 v1, 20
    .line 850: invoke-direct {v0, v1, v9}, Lh/i0;-><init>(ILjava/lang/Object;)V
    .line 853: invoke-static {v0}, Ld2/b;->F0(Ld3/a;)Ls2/b;
    .line 856: move-result-object v0
    .line 857: iput-object v0, v9, Lf1/a;->g:Ls2/b;
    .line 859: return-void
    .line 860: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 862: const-string v1, "maxLines should be greater than 0"
    .line 864: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 867: move-result-object v1
    .line 868: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 871: throw v0
    .line 872: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 874: const-string v1, "Setting Constraints.minWidth and Constraints.minHeight is not supported, these should be the default zero values instead."
    .line 876: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 879: move-result-object v1
    .line 880: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 883: throw v0
.end method

# virtual methods
.method public final a(IILandroid/text/TextUtils$TruncateAt;IIIII)Lg1/s;
    .registers 26

    .line 0: move-object/from16 v0, v17
    .line 2: iget-object v2, v0, Lf1/a;->e:Ljava/lang/CharSequence;
    .line 4: invoke-virtual/range {v17 .. v17}, Lf1/a;->c()F
    .line 7: move-result v3
    .line 8: iget-object v1, v0, Lf1/a;->a:Ln1/c;
    .line 10: iget-object v4, v1, Ln1/c;->g:Ln1/d;
    .line 12: iget v7, v1, Ln1/c;->l:I
    .line 14: iget-object v15, v1, Ln1/c;->i:Lg1/g;
    .line 16: sget-object v5, Ln1/b;->a:Ln1/a;
    .line 18: const-string v5, "<this>"
    .line 20: iget-object v1, v1, Ln1/c;->b:Lf1/b0;
    .line 22: invoke-static {v1, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: iget-object v1, v1, Lf1/b0;->c:Lf1/s;
    .line 27: if-eqz v1, :cond_37
    .line 29: iget-object v1, v1, Lf1/s;->b:Lf1/q;
    .line 31: if-eqz v1, :cond_37
    .line 33: iget-boolean v1, v1, Lf1/q;->a:Z
    .line 35: move v8, v1
    .line 36: goto :goto_39
    .line 37: const/4 v1, 1
    .line 38: goto :goto_35
    .line 39: new-instance v16, Lg1/s;
    .line 41: move-object/from16 v1, v16
    .line 43: move/from16 v5, v18
    .line 45: move-object/from16 v6, v20
    .line 47: move/from16 v9, v21
    .line 49: move/from16 v10, v23
    .line 51: move/from16 v11, v24
    .line 53: move/from16 v12, v25
    .line 55: move/from16 v13, v22
    .line 57: move/from16 v14, v19
    .line 59: invoke-direct/range {v1 .. v15}, Lg1/s;-><init>(Ljava/lang/CharSequence;FLn1/d;ILandroid/text/TextUtils$TruncateAt;IZIIIIIILg1/g;)V
    .line 62: return-object v16
.end method

# virtual methods
.method public final b()F
    .registers 2

    .line 0: iget-object v0, v1, Lf1/a;->d:Lg1/s;
    .line 2: invoke-virtual {v0}, Lg1/s;->a()I
    .line 5: move-result v0
    .line 6: int-to-float v0, v0
    .line 7: return v0
.end method

# virtual methods
.method public final c()F
    .registers 3

    .line 0: iget-wide v0, v2, Lf1/a;->c:J
    .line 2: invoke-static {v0, v1}, Lr1/a;->h(J)I
    .line 5: move-result v0
    .line 6: int-to-float v0, v0
    .line 7: return v0
.end method

# virtual methods
.method public final d(Lk0/o;)V
    .registers 7

    .line 0: sget-object v0, Lk0/b;->a:Landroid/graphics/Canvas;
    .line 2: const-string v0, "<this>"
    .line 4: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: check-cast v6, Lk0/a;
    .line 9: iget-object v6, v6, Lk0/a;->a:Landroid/graphics/Canvas;
    .line 11: iget-object v0, v5, Lf1/a;->d:Lg1/s;
    .line 13: iget-boolean v1, v0, Lg1/s;->c:Z
    .line 15: const/4 v2, 0
    .line 16: if-eqz v1, :cond_32
    .line 18: invoke-virtual {v6}, Landroid/graphics/Canvas;->save()I
    .line 21: invoke-virtual {v5}, Lf1/a;->c()F
    .line 24: move-result v1
    .line 25: invoke-virtual {v5}, Lf1/a;->b()F
    .line 28: move-result v3
    .line 29: invoke-virtual {v6, v2, v2, v1, v3}, Landroid/graphics/Canvas;->clipRect(FFFF)Z
    .line 32: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 35: const-string v1, "canvas"
    .line 37: invoke-static {v6, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 40: iget-object v1, v0, Lg1/s;->n:Landroid/graphics/Rect;
    .line 42: invoke-virtual {v6, v1}, Landroid/graphics/Canvas;->getClipBounds(Landroid/graphics/Rect;)Z
    .line 45: move-result v1
    .line 46: if-nez v1, :cond_49
    .line 48: goto :goto_78
    .line 49: iget v1, v0, Lg1/s;->f:I
    .line 51: if-eqz v1, :cond_57
    .line 53: int-to-float v3, v1
    .line 54: invoke-virtual {v6, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V
    .line 57: sget-object v3, Lg1/t;->a:Lg1/r;
    .line 59: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 62: iput-object v6, v3, Lg1/r;->a:Landroid/graphics/Canvas;
    .line 64: iget-object v4, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 66: invoke-virtual {v4, v3}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V
    .line 69: if-eqz v1, :cond_78
    .line 71: const/4 v3, -1
    .line 72: int-to-float v3, v3
    .line 73: int-to-float v1, v1
    .line 74: mul-float/2addr v3, v1
    .line 75: invoke-virtual {v6, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V
    .line 78: iget-boolean v0, v0, Lg1/s;->c:Z
    .line 80: if-eqz v0, :cond_85
    .line 82: invoke-virtual {v6}, Landroid/graphics/Canvas;->restore()V
    .line 85: return-void
.end method

# virtual methods
.method public final e(Lk0/o;JLk0/k0;Lq1/m;Lm0/h;I)V
    .registers 14

    .line 0: const-string v0, "canvas"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v6, Lf1/a;->a:Ln1/c;
    .line 7: iget-object v1, v0, Ln1/c;->g:Ln1/d;
    .line 9: iget-object v2, v1, Ln1/d;->a:Lk0/d;
    .line 11: iget v3, v2, Lk0/d;->b:I
    .line 13: sget-wide v4, Lk0/q;->g:J
    .line 15: cmp-long v4, v8, v4
    .line 17: if-eqz v4, :cond_26
    .line 19: invoke-virtual {v2, v8, v9}, Lk0/d;->e(J)V
    .line 22: const/4 v8, 0
    .line 23: invoke-virtual {v2, v8}, Lk0/d;->h(Landroid/graphics/Shader;)V
    .line 26: invoke-virtual {v1, v10}, Ln1/d;->c(Lk0/k0;)V
    .line 29: invoke-virtual {v1, v11}, Ln1/d;->d(Lq1/m;)V
    .line 32: invoke-virtual {v1, v12}, Ln1/d;->b(Lm0/h;)V
    .line 35: iget-object v8, v1, Ln1/d;->a:Lk0/d;
    .line 37: invoke-virtual {v8, v13}, Lk0/d;->d(I)V
    .line 40: invoke-virtual {v6, v7}, Lf1/a;->d(Lk0/o;)V
    .line 43: iget-object v7, v0, Ln1/c;->g:Ln1/d;
    .line 45: iget-object v7, v7, Ln1/d;->a:Lk0/d;
    .line 47: invoke-virtual {v7, v3}, Lk0/d;->d(I)V
    .line 50: return-void
.end method

# virtual methods
.method public final f(Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;I)V
    .registers 13

    .line 0: const-string v0, "canvas"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v5, Lf1/a;->a:Ln1/c;
    .line 7: iget-object v1, v0, Ln1/c;->g:Ln1/d;
    .line 9: iget-object v2, v1, Ln1/d;->a:Lk0/d;
    .line 11: iget v2, v2, Lk0/d;->b:I
    .line 13: invoke-virtual {v5}, Lf1/a;->c()F
    .line 16: move-result v3
    .line 17: invoke-virtual {v5}, Lf1/a;->b()F
    .line 20: move-result v4
    .line 21: invoke-static {v3, v4}, Ld2/c;->f(FF)J
    .line 24: move-result-wide v3
    .line 25: invoke-virtual {v1, v7, v3, v4, v8}, Ln1/d;->a(Lk0/m;JF)V
    .line 28: invoke-virtual {v1, v9}, Ln1/d;->c(Lk0/k0;)V
    .line 31: invoke-virtual {v1, v10}, Ln1/d;->d(Lq1/m;)V
    .line 34: invoke-virtual {v1, v11}, Ln1/d;->b(Lm0/h;)V
    .line 37: iget-object v7, v1, Ln1/d;->a:Lk0/d;
    .line 39: invoke-virtual {v7, v12}, Lk0/d;->d(I)V
    .line 42: invoke-virtual {v5, v6}, Lf1/a;->d(Lk0/o;)V
    .line 45: iget-object v6, v0, Ln1/c;->g:Ln1/d;
    .line 47: iget-object v6, v6, Ln1/d;->a:Lk0/d;
    .line 49: invoke-virtual {v6, v2}, Lk0/d;->d(I)V
    .line 52: return-void
.end method

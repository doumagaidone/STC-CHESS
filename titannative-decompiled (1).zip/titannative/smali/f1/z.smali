.class public final Lf1/z;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lf1/y;
.field public final b:Lf1/i;
.field public final c:J
.field public final d:F
.field public final e:F
.field public final f:Ljava/util/ArrayList;

# direct methods
.method public constructor <init>(Lf1/y;Lf1/i;J)V
    .registers 6

    .line 0: const-string v0, "multiParagraph"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lf1/z;->a:Lf1/y;
    .line 10: iput-object v3, v1, Lf1/z;->b:Lf1/i;
    .line 12: iput-wide v4, v1, Lf1/z;->c:J
    .line 14: iget-object v2, v3, Lf1/i;->h:Ljava/util/ArrayList;
    .line 16: invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z
    .line 19: move-result v4
    .line 20: const/4 v5, 0
    .line 21: if-eqz v4, :cond_25
    .line 23: move v4, v5
    .line 24: goto :goto_40
    .line 25: const/4 v4, 0
    .line 26: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 29: move-result-object v0
    .line 30: check-cast v0, Lf1/l;
    .line 32: iget-object v0, v0, Lf1/l;->a:Lf1/a;
    .line 34: iget-object v0, v0, Lf1/a;->d:Lg1/s;
    .line 36: invoke-virtual {v0, v4}, Lg1/s;->c(I)F
    .line 39: move-result v4
    .line 40: iput v4, v1, Lf1/z;->d:F
    .line 42: invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z
    .line 45: move-result v4
    .line 46: if-eqz v4, :cond_49
    .line 48: goto :goto_71
    .line 49: invoke-static {v2}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 52: move-result-object v2
    .line 53: check-cast v2, Lf1/l;
    .line 55: iget-object v4, v2, Lf1/l;->a:Lf1/a;
    .line 57: iget-object v4, v4, Lf1/a;->d:Lg1/s;
    .line 59: iget v5, v4, Lg1/s;->e:I
    .line 61: add-int/lit8 v5, v5, -1
    .line 63: invoke-virtual {v4, v5}, Lg1/s;->c(I)F
    .line 66: move-result v4
    .line 67: iget v2, v2, Lf1/l;->f:F
    .line 69: add-float v5, v4, v2
    .line 71: iput v5, v1, Lf1/z;->e:F
    .line 73: iget-object v2, v3, Lf1/i;->g:Ljava/util/ArrayList;
    .line 75: iput-object v2, v1, Lf1/z;->f:Ljava/util/ArrayList;
    .line 77: return-void
.end method

# virtual methods
.method public final a(I)Lq1/k;
    .registers 4

    .line 0: iget-object v0, v2, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v3}, Lf1/i;->c(I)V
    .line 5: iget-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 7: iget-object v1, v1, Lf1/k;->a:Lf1/e;
    .line 9: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 11: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 14: move-result v1
    .line 15: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 17: if-ne v3, v1, :cond_24
    .line 19: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 22: move-result v1
    .line 23: goto :goto_28
    .line 24: invoke-static {v3, v0}, Ld2/b;->f0(ILjava/util/ArrayList;)I
    .line 27: move-result v1
    .line 28: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v0
    .line 32: check-cast v0, Lf1/l;
    .line 34: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 36: invoke-virtual {v0, v3}, Lf1/l;->a(I)I
    .line 39: move-result v3
    .line 40: iget-object v0, v1, Lf1/a;->d:Lg1/s;
    .line 42: iget-object v0, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 44: invoke-virtual {v0, v3}, Landroid/text/Layout;->isRtlCharAt(I)Z
    .line 47: move-result v3
    .line 48: if-eqz v3, :cond_53
    .line 50: sget-object v3, Lq1/k;->j:Lq1/k;
    .line 52: goto :goto_55
    .line 53: sget-object v3, Lq1/k;->i:Lq1/k;
    .line 55: return-object v3
.end method

# virtual methods
.method public final b(I)Lj0/d;
    .registers 11

    .line 0: iget-object v0, v9, Lf1/z;->b:Lf1/i;
    .line 2: iget-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 4: if-ltz v10, :cond_163
    .line 6: iget-object v2, v1, Lf1/k;->a:Lf1/e;
    .line 8: iget-object v2, v2, Lf1/e;->a:Ljava/lang/String;
    .line 10: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 13: move-result v2
    .line 14: if-ge v10, v2, :cond_163
    .line 16: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 18: invoke-static {v10, v0}, Ld2/b;->f0(ILjava/util/ArrayList;)I
    .line 21: move-result v1
    .line 22: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 25: move-result-object v0
    .line 26: check-cast v0, Lf1/l;
    .line 28: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 30: invoke-virtual {v0, v10}, Lf1/l;->a(I)I
    .line 33: move-result v10
    .line 34: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 36: iget-object v2, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 38: invoke-virtual {v2, v10}, Landroid/text/Layout;->getLineForOffset(I)I
    .line 41: move-result v3
    .line 42: invoke-virtual {v1, v3}, Lg1/s;->e(I)F
    .line 45: move-result v4
    .line 46: invoke-virtual {v1, v3}, Lg1/s;->d(I)F
    .line 49: move-result v5
    .line 50: invoke-virtual {v2, v3}, Landroid/text/Layout;->getParagraphDirection(I)I
    .line 53: move-result v3
    .line 54: const/4 v6, 0
    .line 55: const/4 v7, 1
    .line 56: if-ne v3, v7, :cond_60
    .line 58: move v3, v7
    .line 59: goto :goto_61
    .line 60: move v3, v6
    .line 61: invoke-virtual {v2, v10}, Landroid/text/Layout;->isRtlCharAt(I)Z
    .line 64: move-result v2
    .line 65: if-eqz v3, :cond_79
    .line 67: if-nez v2, :cond_79
    .line 69: invoke-virtual {v1, v10, v6}, Lg1/s;->f(IZ)F
    .line 72: move-result v2
    .line 73: add-int/2addr v10, v7
    .line 74: invoke-virtual {v1, v10, v7}, Lg1/s;->f(IZ)F
    .line 77: move-result v10
    .line 78: goto :goto_117
    .line 79: if-eqz v3, :cond_96
    .line 81: if-eqz v2, :cond_96
    .line 83: invoke-virtual {v1, v10, v6}, Lg1/s;->g(IZ)F
    .line 86: move-result v2
    .line 87: add-int/2addr v10, v7
    .line 88: invoke-virtual {v1, v10, v7}, Lg1/s;->g(IZ)F
    .line 91: move-result v10
    .line 92: move v8, v2
    .line 93: move v2, v10
    .line 94: move v10, v8
    .line 95: goto :goto_117
    .line 96: if-eqz v2, :cond_108
    .line 98: invoke-virtual {v1, v10, v6}, Lg1/s;->f(IZ)F
    .line 101: move-result v2
    .line 102: add-int/2addr v10, v7
    .line 103: invoke-virtual {v1, v10, v7}, Lg1/s;->f(IZ)F
    .line 106: move-result v10
    .line 107: goto :goto_92
    .line 108: invoke-virtual {v1, v10, v6}, Lg1/s;->g(IZ)F
    .line 111: move-result v2
    .line 112: add-int/2addr v10, v7
    .line 113: invoke-virtual {v1, v10, v7}, Lg1/s;->g(IZ)F
    .line 116: move-result v10
    .line 117: new-instance v1, Landroid/graphics/RectF;
    .line 119: invoke-direct {v1, v2, v4, v10, v5}, Landroid/graphics/RectF;-><init>(FFFF)V
    .line 122: iget v10, v1, Landroid/graphics/RectF;->left:F
    .line 124: iget v2, v1, Landroid/graphics/RectF;->top:F
    .line 126: iget v3, v1, Landroid/graphics/RectF;->right:F
    .line 128: iget v1, v1, Landroid/graphics/RectF;->bottom:F
    .line 130: const/4 v4, 0
    .line 131: iget v0, v0, Lf1/l;->f:F
    .line 133: invoke-static {v4, v0}, Ln3/a0;->g(FF)J
    .line 136: move-result-wide v4
    .line 137: new-instance v0, Lj0/d;
    .line 139: invoke-static {v4, v5}, Lj0/c;->c(J)F
    .line 142: move-result v6
    .line 143: add-float/2addr v6, v10
    .line 144: invoke-static {v4, v5}, Lj0/c;->d(J)F
    .line 147: move-result v10
    .line 148: add-float/2addr v10, v2
    .line 149: invoke-static {v4, v5}, Lj0/c;->c(J)F
    .line 152: move-result v2
    .line 153: add-float/2addr v2, v3
    .line 154: invoke-static {v4, v5}, Lj0/c;->d(J)F
    .line 157: move-result v3
    .line 158: add-float/2addr v3, v1
    .line 159: invoke-direct {v0, v6, v10, v2, v3}, Lj0/d;-><init>(FFFF)V
    .line 162: return-object v0
    .line 163: new-instance v0, Ljava/lang/StringBuilder;
    .line 165: const-string v2, "offset("
    .line 167: invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 170: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 173: const-string v10, ") is out of bounds [0, "
    .line 175: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 178: iget-object v10, v1, Lf1/k;->a:Lf1/e;
    .line 180: iget-object v10, v10, Lf1/e;->a:Ljava/lang/String;
    .line 182: invoke-virtual {v10}, Ljava/lang/String;->length()I
    .line 185: move-result v10
    .line 186: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 189: const/16 v10, 41
    .line 191: invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 194: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 197: move-result-object v10
    .line 198: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 200: invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 203: move-result-object v10
    .line 204: invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 207: throw v0
.end method

# virtual methods
.method public final c(I)Lj0/d;
    .registers 9

    .line 0: iget-object v0, v7, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v8}, Lf1/i;->c(I)V
    .line 5: iget-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 7: iget-object v1, v1, Lf1/k;->a:Lf1/e;
    .line 9: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 11: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 14: move-result v1
    .line 15: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 17: if-ne v8, v1, :cond_24
    .line 19: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 22: move-result v1
    .line 23: goto :goto_28
    .line 24: invoke-static {v8, v0}, Ld2/b;->f0(ILjava/util/ArrayList;)I
    .line 27: move-result v1
    .line 28: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v0
    .line 32: check-cast v0, Lf1/l;
    .line 34: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 36: invoke-virtual {v0, v8}, Lf1/l;->a(I)I
    .line 39: move-result v8
    .line 40: iget-object v2, v1, Lf1/a;->e:Ljava/lang/CharSequence;
    .line 42: if-ltz v8, :cond_104
    .line 44: invoke-interface {v2}, Ljava/lang/CharSequence;->length()I
    .line 47: move-result v3
    .line 48: if-gt v8, v3, :cond_104
    .line 50: const/4 v2, 0
    .line 51: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 53: invoke-virtual {v1, v8, v2}, Lg1/s;->f(IZ)F
    .line 56: move-result v2
    .line 57: iget-object v3, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 59: invoke-virtual {v3, v8}, Landroid/text/Layout;->getLineForOffset(I)I
    .line 62: move-result v8
    .line 63: invoke-virtual {v1, v8}, Lg1/s;->e(I)F
    .line 66: move-result v3
    .line 67: invoke-virtual {v1, v8}, Lg1/s;->d(I)F
    .line 70: move-result v8
    .line 71: const/4 v1, 0
    .line 72: iget v0, v0, Lf1/l;->f:F
    .line 74: invoke-static {v1, v0}, Ln3/a0;->g(FF)J
    .line 77: move-result-wide v0
    .line 78: new-instance v4, Lj0/d;
    .line 80: invoke-static {v0, v1}, Lj0/c;->c(J)F
    .line 83: move-result v5
    .line 84: add-float/2addr v5, v2
    .line 85: invoke-static {v0, v1}, Lj0/c;->d(J)F
    .line 88: move-result v6
    .line 89: add-float/2addr v6, v3
    .line 90: invoke-static {v0, v1}, Lj0/c;->c(J)F
    .line 93: move-result v3
    .line 94: add-float/2addr v3, v2
    .line 95: invoke-static {v0, v1}, Lj0/c;->d(J)F
    .line 98: move-result v0
    .line 99: add-float/2addr v0, v8
    .line 100: invoke-direct {v4, v5, v6, v3, v0}, Lj0/d;-><init>(FFFF)V
    .line 103: return-object v4
    .line 104: new-instance v0, Ljava/lang/AssertionError;
    .line 106: new-instance v1, Ljava/lang/StringBuilder;
    .line 108: const-string v3, "offset("
    .line 110: invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 113: invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 116: const-string v8, ") is out of bounds (0,"
    .line 118: invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 121: invoke-interface {v2}, Ljava/lang/CharSequence;->length()I
    .line 124: move-result v8
    .line 125: invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 128: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 131: move-result-object v8
    .line 132: invoke-direct {v0, v8}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V
    .line 135: throw v0
.end method

# virtual methods
.method public final d()Z
    .registers 7

    .line 0: iget-wide v0, v6, Lf1/z;->c:J
    .line 2: const/16 v2, 32
    .line 4: shr-long v2, v0, v2
    .line 6: long-to-int v2, v2
    .line 7: int-to-float v2, v2
    .line 8: iget-object v3, v6, Lf1/z;->b:Lf1/i;
    .line 10: iget v4, v3, Lf1/i;->d:F
    .line 12: cmpg-float v2, v2, v4
    .line 14: if-gez v2, :cond_17
    .line 16: goto :goto_38
    .line 17: iget-boolean v2, v3, Lf1/i;->c:Z
    .line 19: if-nez v2, :cond_38
    .line 21: const-wide v4, 0x00ffffffff
    .line 26: and-long/2addr v0, v4
    .line 27: long-to-int v0, v0
    .line 28: int-to-float v0, v0
    .line 29: iget v1, v3, Lf1/i;->e:F
    .line 31: cmpg-float v0, v0, v1
    .line 33: if-gez v0, :cond_36
    .line 35: goto :goto_38
    .line 36: const/4 v0, 0
    .line 37: goto :goto_39
    .line 38: const/4 v0, 1
    .line 39: return v0
.end method

# virtual methods
.method public final e(I)F
    .registers 5

    .line 0: iget-object v0, v3, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v4}, Lf1/i;->d(I)V
    .line 5: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: invoke-static {v4, v0}, Ld2/b;->g0(ILjava/util/ArrayList;)I
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v0
    .line 15: check-cast v0, Lf1/l;
    .line 17: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 19: iget v2, v0, Lf1/l;->d:I
    .line 21: sub-int/2addr v4, v2
    .line 22: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 24: invoke-virtual {v1, v4}, Lg1/s;->d(I)F
    .line 27: move-result v4
    .line 28: iget v0, v0, Lf1/l;->f:F
    .line 30: add-float/2addr v4, v0
    .line 31: return v4
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lf1/z;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lf1/z;
    .line 12: iget-object v1, v8, Lf1/z;->a:Lf1/y;
    .line 14: iget-object v3, v7, Lf1/z;->a:Lf1/y;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v7, Lf1/z;->b:Lf1/i;
    .line 25: iget-object v3, v8, Lf1/z;->b:Lf1/i;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-wide v3, v7, Lf1/z;->c:J
    .line 36: iget-wide v5, v8, Lf1/z;->c:J
    .line 38: invoke-static {v3, v4, v5, v6}, Lr1/i;->a(JJ)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget v1, v7, Lf1/z;->d:F
    .line 47: iget v3, v8, Lf1/z;->d:F
    .line 49: cmpg-float v1, v1, v3
    .line 51: if-nez v1, :cond_73
    .line 53: iget v1, v7, Lf1/z;->e:F
    .line 55: iget v3, v8, Lf1/z;->e:F
    .line 57: cmpg-float v1, v1, v3
    .line 59: if-nez v1, :cond_73
    .line 61: iget-object v1, v7, Lf1/z;->f:Ljava/util/ArrayList;
    .line 63: iget-object v8, v8, Lf1/z;->f:Ljava/util/ArrayList;
    .line 65: invoke-static {v1, v8}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 68: move-result v8
    .line 69: if-nez v8, :cond_72
    .line 71: return v2
    .line 72: return v0
    .line 73: return v2
.end method

# virtual methods
.method public final f(IZ)I
    .registers 6

    .line 0: iget-object v0, v3, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v4}, Lf1/i;->d(I)V
    .line 5: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: invoke-static {v4, v0}, Ld2/b;->g0(ILjava/util/ArrayList;)I
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v0
    .line 15: check-cast v0, Lf1/l;
    .line 17: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 19: iget v2, v0, Lf1/l;->d:I
    .line 21: sub-int/2addr v4, v2
    .line 22: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 24: if-eqz v5, :cond_49
    .line 26: iget-object v5, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 28: invoke-virtual {v5, v4}, Landroid/text/Layout;->getEllipsisStart(I)I
    .line 31: move-result v1
    .line 32: if-nez v1, :cond_39
    .line 34: invoke-virtual {v5, v4}, Landroid/text/Layout;->getLineVisibleEnd(I)I
    .line 37: move-result v4
    .line 38: goto :goto_70
    .line 39: invoke-virtual {v5, v4}, Landroid/text/Layout;->getLineStart(I)I
    .line 42: move-result v1
    .line 43: invoke-virtual {v5, v4}, Landroid/text/Layout;->getEllipsisStart(I)I
    .line 46: move-result v4
    .line 47: add-int/2addr v4, v1
    .line 48: goto :goto_70
    .line 49: iget-object v5, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 51: invoke-virtual {v5, v4}, Landroid/text/Layout;->getEllipsisStart(I)I
    .line 54: move-result v1
    .line 55: if-nez v1, :cond_62
    .line 57: invoke-virtual {v5, v4}, Landroid/text/Layout;->getLineEnd(I)I
    .line 60: move-result v4
    .line 61: goto :goto_70
    .line 62: invoke-virtual {v5}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;
    .line 65: move-result-object v4
    .line 66: invoke-interface {v4}, Ljava/lang/CharSequence;->length()I
    .line 69: move-result v4
    .line 70: iget v5, v0, Lf1/l;->b:I
    .line 72: add-int/2addr v4, v5
    .line 73: return v4
.end method

# virtual methods
.method public final g(I)I
    .registers 4

    .line 0: iget-object v0, v2, Lf1/z;->b:Lf1/i;
    .line 2: iget-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 4: iget-object v1, v1, Lf1/k;->a:Lf1/e;
    .line 6: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 8: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 11: move-result v1
    .line 12: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 14: if-lt v3, v1, :cond_21
    .line 16: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 19: move-result v1
    .line 20: goto :goto_29
    .line 21: if-gez v3, :cond_25
    .line 23: const/4 v1, 0
    .line 24: goto :goto_29
    .line 25: invoke-static {v3, v0}, Ld2/b;->f0(ILjava/util/ArrayList;)I
    .line 28: move-result v1
    .line 29: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 32: move-result-object v0
    .line 33: check-cast v0, Lf1/l;
    .line 35: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 37: invoke-virtual {v0, v3}, Lf1/l;->a(I)I
    .line 40: move-result v3
    .line 41: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 43: iget-object v1, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 45: invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineForOffset(I)I
    .line 48: move-result v3
    .line 49: iget v0, v0, Lf1/l;->d:I
    .line 51: add-int/2addr v3, v0
    .line 52: return v3
.end method

# virtual methods
.method public final h(F)I
    .registers 6

    .line 0: const/4 v0, 0
    .line 1: cmpg-float v0, v5, v0
    .line 3: iget-object v1, v4, Lf1/z;->b:Lf1/i;
    .line 5: iget-object v2, v1, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: const/4 v3, 0
    .line 8: if-gtz v0, :cond_12
    .line 10: move v0, v3
    .line 11: goto :goto_27
    .line 12: iget v0, v1, Lf1/i;->e:F
    .line 14: cmpl-float v0, v5, v0
    .line 16: if-ltz v0, :cond_23
    .line 18: invoke-static {v2}, Ld2/b;->r0(Ljava/util/List;)I
    .line 21: move-result v0
    .line 22: goto :goto_27
    .line 23: invoke-static {v2, v5}, Ld2/b;->h0(Ljava/util/ArrayList;F)I
    .line 26: move-result v0
    .line 27: invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 30: move-result-object v0
    .line 31: check-cast v0, Lf1/l;
    .line 33: iget v1, v0, Lf1/l;->c:I
    .line 35: iget v2, v0, Lf1/l;->b:I
    .line 37: sub-int/2addr v1, v2
    .line 38: if-nez v1, :cond_47
    .line 40: add-int/lit8 v2, v2, -1
    .line 42: invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I
    .line 45: move-result v5
    .line 46: goto :goto_67
    .line 47: iget v1, v0, Lf1/l;->f:F
    .line 49: sub-float/2addr v5, v1
    .line 50: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 52: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 54: float-to-int v5, v5
    .line 55: iget v2, v1, Lg1/s;->f:I
    .line 57: sub-int/2addr v5, v2
    .line 58: iget-object v1, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 60: invoke-virtual {v1, v5}, Landroid/text/Layout;->getLineForVertical(I)I
    .line 63: move-result v5
    .line 64: iget v0, v0, Lf1/l;->d:I
    .line 66: add-int/2addr v5, v0
    .line 67: return v5
.end method

# virtual methods
.method public final hashCode()I
    .registers 6

    .line 0: iget-object v0, v5, Lf1/z;->a:Lf1/y;
    .line 2: invoke-virtual {v0}, Lf1/y;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v5, Lf1/z;->b:Lf1/i;
    .line 11: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 14: move-result v2
    .line 15: add-int/2addr v2, v0
    .line 16: mul-int/2addr v2, v1
    .line 17: iget-wide v3, v5, Lf1/z;->c:J
    .line 19: invoke-static {v3, v4, v2, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 22: move-result v0
    .line 23: iget v2, v5, Lf1/z;->d:F
    .line 25: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 28: move-result v0
    .line 29: iget v2, v5, Lf1/z;->e:F
    .line 31: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 34: move-result v0
    .line 35: iget-object v1, v5, Lf1/z;->f:Ljava/util/ArrayList;
    .line 37: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 40: move-result v1
    .line 41: add-int/2addr v1, v0
    .line 42: return v1
.end method

# virtual methods
.method public final i(I)F
    .registers 5

    .line 0: iget-object v0, v3, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v4}, Lf1/i;->d(I)V
    .line 5: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: invoke-static {v4, v0}, Ld2/b;->g0(ILjava/util/ArrayList;)I
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v0
    .line 15: check-cast v0, Lf1/l;
    .line 17: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 19: iget v0, v0, Lf1/l;->d:I
    .line 21: sub-int/2addr v4, v0
    .line 22: iget-object v0, v1, Lf1/a;->d:Lg1/s;
    .line 24: iget-object v1, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 26: invoke-virtual {v1, v4}, Landroid/text/Layout;->getLineLeft(I)F
    .line 29: move-result v1
    .line 30: iget v2, v0, Lg1/s;->e:I
    .line 32: add-int/lit8 v2, v2, -1
    .line 34: if-ne v4, v2, :cond_39
    .line 36: iget v4, v0, Lg1/s;->h:F
    .line 38: goto :goto_40
    .line 39: const/4 v4, 0
    .line 40: add-float/2addr v1, v4
    .line 41: return v1
.end method

# virtual methods
.method public final j(I)F
    .registers 5

    .line 0: iget-object v0, v3, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v4}, Lf1/i;->d(I)V
    .line 5: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: invoke-static {v4, v0}, Ld2/b;->g0(ILjava/util/ArrayList;)I
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v0
    .line 15: check-cast v0, Lf1/l;
    .line 17: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 19: iget v0, v0, Lf1/l;->d:I
    .line 21: sub-int/2addr v4, v0
    .line 22: iget-object v0, v1, Lf1/a;->d:Lg1/s;
    .line 24: iget-object v1, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 26: invoke-virtual {v1, v4}, Landroid/text/Layout;->getLineRight(I)F
    .line 29: move-result v1
    .line 30: iget v2, v0, Lg1/s;->e:I
    .line 32: add-int/lit8 v2, v2, -1
    .line 34: if-ne v4, v2, :cond_39
    .line 36: iget v4, v0, Lg1/s;->i:F
    .line 38: goto :goto_40
    .line 39: const/4 v4, 0
    .line 40: add-float/2addr v1, v4
    .line 41: return v1
.end method

# virtual methods
.method public final k(I)I
    .registers 5

    .line 0: iget-object v0, v3, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v4}, Lf1/i;->d(I)V
    .line 5: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: invoke-static {v4, v0}, Ld2/b;->g0(ILjava/util/ArrayList;)I
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v0
    .line 15: check-cast v0, Lf1/l;
    .line 17: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 19: iget v2, v0, Lf1/l;->d:I
    .line 21: sub-int/2addr v4, v2
    .line 22: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 24: iget-object v1, v1, Lg1/s;->d:Landroid/text/Layout;
    .line 26: invoke-virtual {v1, v4}, Landroid/text/Layout;->getLineStart(I)I
    .line 29: move-result v4
    .line 30: iget v0, v0, Lf1/l;->b:I
    .line 32: add-int/2addr v4, v0
    .line 33: return v4
.end method

# virtual methods
.method public final l(I)F
    .registers 5

    .line 0: iget-object v0, v3, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v4}, Lf1/i;->d(I)V
    .line 5: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 7: invoke-static {v4, v0}, Ld2/b;->g0(ILjava/util/ArrayList;)I
    .line 10: move-result v1
    .line 11: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v0
    .line 15: check-cast v0, Lf1/l;
    .line 17: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 19: iget v2, v0, Lf1/l;->d:I
    .line 21: sub-int/2addr v4, v2
    .line 22: iget-object v1, v1, Lf1/a;->d:Lg1/s;
    .line 24: invoke-virtual {v1, v4}, Lg1/s;->e(I)F
    .line 27: move-result v4
    .line 28: iget v0, v0, Lf1/l;->f:F
    .line 30: add-float/2addr v4, v0
    .line 31: return v4
.end method

# virtual methods
.method public final m(J)I
    .registers 7

    .line 0: iget-object v0, v4, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 8: move-result v1
    .line 9: const/4 v2, 0
    .line 10: cmpg-float v1, v1, v2
    .line 12: iget-object v2, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 14: const/4 v3, 0
    .line 15: if-gtz v1, :cond_19
    .line 17: move v0, v3
    .line 18: goto :goto_42
    .line 19: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 22: move-result v1
    .line 23: iget v0, v0, Lf1/i;->e:F
    .line 25: cmpl-float v0, v1, v0
    .line 27: if-ltz v0, :cond_34
    .line 29: invoke-static {v2}, Ld2/b;->r0(Ljava/util/List;)I
    .line 32: move-result v0
    .line 33: goto :goto_42
    .line 34: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 37: move-result v0
    .line 38: invoke-static {v2, v0}, Ld2/b;->h0(Ljava/util/ArrayList;F)I
    .line 41: move-result v0
    .line 42: invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 45: move-result-object v0
    .line 46: check-cast v0, Lf1/l;
    .line 48: iget v1, v0, Lf1/l;->c:I
    .line 50: iget v2, v0, Lf1/l;->b:I
    .line 52: sub-int/2addr v1, v2
    .line 53: if-nez v1, :cond_62
    .line 55: add-int/lit8 v2, v2, -1
    .line 57: invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I
    .line 60: move-result v5
    .line 61: goto :goto_115
    .line 62: invoke-static {v5, v6}, Lj0/c;->c(J)F
    .line 65: move-result v1
    .line 66: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 69: move-result v5
    .line 70: iget v6, v0, Lf1/l;->f:F
    .line 72: sub-float/2addr v5, v6
    .line 73: invoke-static {v1, v5}, Ln3/a0;->g(FF)J
    .line 76: move-result-wide v5
    .line 77: iget-object v0, v0, Lf1/l;->a:Lf1/a;
    .line 79: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 82: invoke-static {v5, v6}, Lj0/c;->d(J)F
    .line 85: move-result v1
    .line 86: float-to-int v1, v1
    .line 87: iget-object v0, v0, Lf1/a;->d:Lg1/s;
    .line 89: iget v3, v0, Lg1/s;->f:I
    .line 91: sub-int/2addr v1, v3
    .line 92: iget-object v3, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 94: invoke-virtual {v3, v1}, Landroid/text/Layout;->getLineForVertical(I)I
    .line 97: move-result v1
    .line 98: invoke-static {v5, v6}, Lj0/c;->c(J)F
    .line 101: move-result v5
    .line 102: const/4 v6, -1
    .line 103: int-to-float v6, v6
    .line 104: invoke-virtual {v0, v1}, Lg1/s;->b(I)F
    .line 107: move-result v0
    .line 108: mul-float/2addr v0, v6
    .line 109: add-float/2addr v0, v5
    .line 110: invoke-virtual {v3, v1, v0}, Landroid/text/Layout;->getOffsetForHorizontal(IF)I
    .line 113: move-result v5
    .line 114: add-int/2addr v5, v2
    .line 115: return v5
.end method

# virtual methods
.method public final n(I)Lq1/k;
    .registers 4

    .line 0: iget-object v0, v2, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v3}, Lf1/i;->c(I)V
    .line 5: iget-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 7: iget-object v1, v1, Lf1/k;->a:Lf1/e;
    .line 9: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 11: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 14: move-result v1
    .line 15: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 17: if-ne v3, v1, :cond_24
    .line 19: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 22: move-result v1
    .line 23: goto :goto_28
    .line 24: invoke-static {v3, v0}, Ld2/b;->f0(ILjava/util/ArrayList;)I
    .line 27: move-result v1
    .line 28: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v0
    .line 32: check-cast v0, Lf1/l;
    .line 34: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 36: invoke-virtual {v0, v3}, Lf1/l;->a(I)I
    .line 39: move-result v3
    .line 40: iget-object v0, v1, Lf1/a;->d:Lg1/s;
    .line 42: iget-object v1, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 44: invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineForOffset(I)I
    .line 47: move-result v3
    .line 48: iget-object v0, v0, Lg1/s;->d:Landroid/text/Layout;
    .line 50: invoke-virtual {v0, v3}, Landroid/text/Layout;->getParagraphDirection(I)I
    .line 53: move-result v3
    .line 54: const/4 v0, 1
    .line 55: if-ne v3, v0, :cond_60
    .line 57: sget-object v3, Lq1/k;->i:Lq1/k;
    .line 59: goto :goto_62
    .line 60: sget-object v3, Lq1/k;->j:Lq1/k;
    .line 62: return-object v3
.end method

# virtual methods
.method public final o(I)J
    .registers 9

    .line 0: iget-object v0, v7, Lf1/z;->b:Lf1/i;
    .line 2: invoke-virtual {v0, v8}, Lf1/i;->c(I)V
    .line 5: iget-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 7: iget-object v1, v1, Lf1/k;->a:Lf1/e;
    .line 9: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 11: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 14: move-result v1
    .line 15: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 17: if-ne v8, v1, :cond_24
    .line 19: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 22: move-result v1
    .line 23: goto :goto_28
    .line 24: invoke-static {v8, v0}, Ld2/b;->f0(ILjava/util/ArrayList;)I
    .line 27: move-result v1
    .line 28: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v0
    .line 32: check-cast v0, Lf1/l;
    .line 34: iget-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 36: invoke-virtual {v0, v8}, Lf1/l;->a(I)I
    .line 39: move-result v8
    .line 40: iget-object v2, v1, Lf1/a;->g:Ls2/b;
    .line 42: invoke-interface {v2}, Ls2/b;->getValue()Ljava/lang/Object;
    .line 45: move-result-object v2
    .line 46: check-cast v2, Lh1/a;
    .line 48: iget-object v2, v2, Lh1/a;->a:Lh1/b;
    .line 50: invoke-virtual {v2, v8}, Lh1/b;->a(I)V
    .line 53: iget-object v3, v2, Lh1/b;->d:Ljava/text/BreakIterator;
    .line 55: invoke-virtual {v3, v8}, Ljava/text/BreakIterator;->preceding(I)I
    .line 58: move-result v4
    .line 59: invoke-virtual {v2, v4}, Lh1/b;->e(I)Z
    .line 62: move-result v4
    .line 63: const/4 v5, -1
    .line 64: if-eqz v4, :cond_93
    .line 66: invoke-virtual {v2, v8}, Lh1/b;->a(I)V
    .line 69: move v4, v8
    .line 70: if-eq v4, v5, :cond_135
    .line 72: invoke-virtual {v2, v4}, Lh1/b;->e(I)Z
    .line 75: move-result v6
    .line 76: if-eqz v6, :cond_85
    .line 78: invoke-virtual {v2, v4}, Lh1/b;->c(I)Z
    .line 81: move-result v6
    .line 82: if-nez v6, :cond_85
    .line 84: goto :goto_135
    .line 85: invoke-virtual {v2, v4}, Lh1/b;->a(I)V
    .line 88: invoke-virtual {v3, v4}, Ljava/text/BreakIterator;->preceding(I)I
    .line 91: move-result v4
    .line 92: goto :goto_70
    .line 93: invoke-virtual {v2, v8}, Lh1/b;->a(I)V
    .line 96: invoke-virtual {v2, v8}, Lh1/b;->d(I)Z
    .line 99: move-result v4
    .line 100: if-eqz v4, :cond_123
    .line 102: invoke-virtual {v3, v8}, Ljava/text/BreakIterator;->isBoundary(I)Z
    .line 105: move-result v4
    .line 106: if-eqz v4, :cond_117
    .line 108: invoke-virtual {v2, v8}, Lh1/b;->b(I)Z
    .line 111: move-result v2
    .line 112: if-eqz v2, :cond_115
    .line 114: goto :goto_117
    .line 115: move v2, v8
    .line 116: goto :goto_121
    .line 117: invoke-virtual {v3, v8}, Ljava/text/BreakIterator;->preceding(I)I
    .line 120: move-result v2
    .line 121: move v4, v2
    .line 122: goto :goto_135
    .line 123: invoke-virtual {v2, v8}, Lh1/b;->b(I)Z
    .line 126: move-result v2
    .line 127: if-eqz v2, :cond_134
    .line 129: invoke-virtual {v3, v8}, Ljava/text/BreakIterator;->preceding(I)I
    .line 132: move-result v2
    .line 133: goto :goto_121
    .line 134: move v4, v5
    .line 135: if-ne v4, v5, :cond_138
    .line 137: move v4, v8
    .line 138: iget-object v1, v1, Lf1/a;->g:Ls2/b;
    .line 140: invoke-interface {v1}, Ls2/b;->getValue()Ljava/lang/Object;
    .line 143: move-result-object v1
    .line 144: check-cast v1, Lh1/a;
    .line 146: iget-object v1, v1, Lh1/a;->a:Lh1/b;
    .line 148: invoke-virtual {v1, v8}, Lh1/b;->a(I)V
    .line 151: iget-object v2, v1, Lh1/b;->d:Ljava/text/BreakIterator;
    .line 153: invoke-virtual {v2, v8}, Ljava/text/BreakIterator;->following(I)I
    .line 156: move-result v3
    .line 157: invoke-virtual {v1, v3}, Lh1/b;->c(I)Z
    .line 160: move-result v3
    .line 161: if-eqz v3, :cond_190
    .line 163: invoke-virtual {v1, v8}, Lh1/b;->a(I)V
    .line 166: move v3, v8
    .line 167: if-eq v3, v5, :cond_232
    .line 169: invoke-virtual {v1, v3}, Lh1/b;->e(I)Z
    .line 172: move-result v6
    .line 173: if-nez v6, :cond_182
    .line 175: invoke-virtual {v1, v3}, Lh1/b;->c(I)Z
    .line 178: move-result v6
    .line 179: if-eqz v6, :cond_182
    .line 181: goto :goto_232
    .line 182: invoke-virtual {v1, v3}, Lh1/b;->a(I)V
    .line 185: invoke-virtual {v2, v3}, Ljava/text/BreakIterator;->following(I)I
    .line 188: move-result v3
    .line 189: goto :goto_167
    .line 190: invoke-virtual {v1, v8}, Lh1/b;->a(I)V
    .line 193: invoke-virtual {v1, v8}, Lh1/b;->b(I)Z
    .line 196: move-result v3
    .line 197: if-eqz v3, :cond_220
    .line 199: invoke-virtual {v2, v8}, Ljava/text/BreakIterator;->isBoundary(I)Z
    .line 202: move-result v3
    .line 203: if-eqz v3, :cond_214
    .line 205: invoke-virtual {v1, v8}, Lh1/b;->d(I)Z
    .line 208: move-result v1
    .line 209: if-eqz v1, :cond_212
    .line 211: goto :goto_214
    .line 212: move v1, v8
    .line 213: goto :goto_218
    .line 214: invoke-virtual {v2, v8}, Ljava/text/BreakIterator;->following(I)I
    .line 217: move-result v1
    .line 218: move v3, v1
    .line 219: goto :goto_232
    .line 220: invoke-virtual {v1, v8}, Lh1/b;->d(I)Z
    .line 223: move-result v1
    .line 224: if-eqz v1, :cond_231
    .line 226: invoke-virtual {v2, v8}, Ljava/text/BreakIterator;->following(I)I
    .line 229: move-result v1
    .line 230: goto :goto_218
    .line 231: move v3, v5
    .line 232: if-ne v3, v5, :cond_235
    .line 234: goto :goto_236
    .line 235: move v8, v3
    .line 236: invoke-static {v4, v8}, Ld2/c;->g(II)J
    .line 239: move-result-wide v1
    .line 240: sget v8, Lf1/a0;->c:I
    .line 242: const/16 v8, 32
    .line 244: shr-long v3, v1, v8
    .line 246: long-to-int v8, v3
    .line 247: iget v0, v0, Lf1/l;->b:I
    .line 249: add-int/2addr v8, v0
    .line 250: const-wide v3, 0x00ffffffff
    .line 255: and-long/2addr v1, v3
    .line 256: long-to-int v1, v1
    .line 257: add-int/2addr v1, v0
    .line 258: invoke-static {v8, v1}, Ld2/c;->g(II)J
    .line 261: move-result-wide v0
    .line 262: return-wide v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "TextLayoutResult(layoutInput="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lf1/z;->a:Lf1/y;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", multiParagraph="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lf1/z;->b:Lf1/i;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", size="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-wide v1, v3, Lf1/z;->c:J
    .line 29: invoke-static {v1, v2}, Lr1/i;->b(J)Ljava/lang/String;
    .line 32: move-result-object v1
    .line 33: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 36: const-string v1, ", firstBaseline="
    .line 38: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 41: iget v1, v3, Lf1/z;->d:F
    .line 43: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 46: const-string v1, ", lastBaseline="
    .line 48: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 51: iget v1, v3, Lf1/z;->e:F
    .line 53: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 56: const-string v1, ", placeholderRects="
    .line 58: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 61: iget-object v1, v3, Lf1/z;->f:Ljava/util/ArrayList;
    .line 63: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 66: const/16 v1, 41
    .line 68: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 71: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 74: move-result-object v0
    .line 75: return-object v0
.end method

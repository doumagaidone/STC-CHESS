.class public final Lf1/r;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lf1/r;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Lf1/r;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Lf1/r;->a:Lf1/r;
    .line 7: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .line 0: const/4 v0, 1
    .line 1: if-ne v1, v2, :cond_4
    .line 3: return v0
    .line 4: instance-of v2, v2, Lf1/r;
    .line 6: if-nez v2, :cond_10
    .line 8: const/4 v2, 0
    .line 9: return v2
    .line 10: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 2

    .line 0: invoke-super {v1}, Ljava/lang/Object;->hashCode()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: const-string v0, "PlatformSpanStyle()"
    .line 2: return-object v0
.end method

.class public final Lf1/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lf1/h;->a:I
    .line 5: return-void
.end method

# direct methods
.method public static a(I)Ljava/lang/String;
    .registers 3

    .line 0: if-nez v2, :cond_5
    .line 2: const-string v2, "EmojiSupportMatch.Default"
    .line 4: goto :goto_30
    .line 5: const/4 v0, 1
    .line 6: if-ne v2, v0, :cond_11
    .line 8: const-string v2, "EmojiSupportMatch.None"
    .line 10: goto :goto_30
    .line 11: new-instance v0, Ljava/lang/StringBuilder;
    .line 13: const-string v1, "Invalid(value="
    .line 15: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 18: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 21: const/16 v2, 41
    .line 23: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 29: move-result-object v2
    .line 30: return-object v2
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 0: instance-of v0, v3, Lf1/h;
    .line 2: const/4 v1, 0
    .line 3: if-nez v0, :cond_6
    .line 5: goto :goto_16
    .line 6: check-cast v3, Lf1/h;
    .line 8: iget v3, v3, Lf1/h;->a:I
    .line 10: iget v0, v2, Lf1/h;->a:I
    .line 12: if-eq v0, v3, :cond_15
    .line 14: goto :goto_16
    .line 15: const/4 v1, 1
    .line 16: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 2

    .line 0: iget v0, v1, Lf1/h;->a:I
    .line 2: invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget v0, v1, Lf1/h;->a:I
    .line 2: invoke-static {v0}, Lf1/h;->a(I)Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

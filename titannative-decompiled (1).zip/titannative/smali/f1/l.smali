.class public final Lf1/l;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lf1/a;
.field public final b:I
.field public final c:I
.field public final d:I
.field public final e:I
.field public final f:F
.field public final g:F

# direct methods
.method public constructor <init>(Lf1/a;IIIIFF)V
    .registers 8

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lf1/l;->a:Lf1/a;
    .line 5: iput v2, v0, Lf1/l;->b:I
    .line 7: iput v3, v0, Lf1/l;->c:I
    .line 9: iput v4, v0, Lf1/l;->d:I
    .line 11: iput v5, v0, Lf1/l;->e:I
    .line 13: iput v6, v0, Lf1/l;->f:F
    .line 15: iput v7, v0, Lf1/l;->g:F
    .line 17: return-void
.end method

# virtual methods
.method public final a(I)I
    .registers 4

    .line 0: iget v0, v2, Lf1/l;->c:I
    .line 2: iget v1, v2, Lf1/l;->b:I
    .line 4: invoke-static {v3, v1, v0}, Ld2/b;->G(III)I
    .line 7: move-result v3
    .line 8: sub-int/2addr v3, v1
    .line 9: return v3
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lf1/l;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lf1/l;
    .line 12: iget-object v1, v5, Lf1/l;->a:Lf1/a;
    .line 14: iget-object v3, v4, Lf1/l;->a:Lf1/a;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lf1/l;->b:I
    .line 25: iget v3, v5, Lf1/l;->b:I
    .line 27: if-eq v1, v3, :cond_30
    .line 29: return v2
    .line 30: iget v1, v4, Lf1/l;->c:I
    .line 32: iget v3, v5, Lf1/l;->c:I
    .line 34: if-eq v1, v3, :cond_37
    .line 36: return v2
    .line 37: iget v1, v4, Lf1/l;->d:I
    .line 39: iget v3, v5, Lf1/l;->d:I
    .line 41: if-eq v1, v3, :cond_44
    .line 43: return v2
    .line 44: iget v1, v4, Lf1/l;->e:I
    .line 46: iget v3, v5, Lf1/l;->e:I
    .line 48: if-eq v1, v3, :cond_51
    .line 50: return v2
    .line 51: iget v1, v4, Lf1/l;->f:F
    .line 53: iget v3, v5, Lf1/l;->f:F
    .line 55: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 58: move-result v1
    .line 59: if-eqz v1, :cond_62
    .line 61: return v2
    .line 62: iget v1, v4, Lf1/l;->g:F
    .line 64: iget v5, v5, Lf1/l;->g:F
    .line 66: invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I
    .line 69: move-result v5
    .line 70: if-eqz v5, :cond_73
    .line 72: return v2
    .line 73: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lf1/l;->a:Lf1/a;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lf1/l;->b:I
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 14: move-result v0
    .line 15: iget v2, v3, Lf1/l;->c:I
    .line 17: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 20: move-result v0
    .line 21: iget v2, v3, Lf1/l;->d:I
    .line 23: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 26: move-result v0
    .line 27: iget v2, v3, Lf1/l;->e:I
    .line 29: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 32: move-result v0
    .line 33: iget v2, v3, Lf1/l;->f:F
    .line 35: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 38: move-result v0
    .line 39: iget v1, v3, Lf1/l;->g:F
    .line 41: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 44: move-result v1
    .line 45: add-int/2addr v1, v0
    .line 46: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ParagraphInfo(paragraph="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lf1/l;->a:Lf1/a;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", startIndex="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v3, Lf1/l;->b:I
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", endIndex="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v3, Lf1/l;->c:I
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", startLineIndex="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v3, Lf1/l;->d:I
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", endLineIndex="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget v1, v3, Lf1/l;->e:I
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", top="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget v1, v3, Lf1/l;->f:F
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ", bottom="
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget v1, v3, Lf1/l;->g:F
    .line 69: const/16 v2, 41
    .line 71: invoke-static {v0, v1, v2}, Lai/onnxruntime/b;->i(Ljava/lang/StringBuilder;FC)Ljava/lang/String;
    .line 74: move-result-object v0
    .line 75: return-object v0
.end method

.class public final Lf1/d0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;

# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    .line 0: const-string v0, "url"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lf1/d0;->a:Ljava/lang/String;
    .line 10: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 0: const/4 v0, 1
    .line 1: if-ne v3, v4, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v4, Lf1/d0;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v4, Lf1/d0;
    .line 12: iget-object v4, v4, Lf1/d0;->a:Ljava/lang/String;
    .line 14: iget-object v1, v3, Lf1/d0;->a:Ljava/lang/String;
    .line 16: invoke-static {v1, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v4
    .line 20: if-nez v4, :cond_23
    .line 22: return v2
    .line 23: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 2

    .line 0: iget-object v0, v1, Lf1/d0;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "UrlAnnotation(url="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lf1/d0;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const/16 v1, 41
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 17: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 20: move-result-object v0
    .line 21: return-object v0
.end method

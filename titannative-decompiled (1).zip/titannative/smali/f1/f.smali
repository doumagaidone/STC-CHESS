.class public abstract Lf1/f;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lf1/e;

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: new-instance v0, Lf1/e;
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 6
    .line 4: const-string v3, ""
    .line 6: invoke-direct {v0, v3, v1, v2}, Lf1/e;-><init>(Ljava/lang/String;Ljava/util/ArrayList;I)V
    .line 9: sput-object v0, Lf1/f;->a:Lf1/e;
    .line 11: return-void
.end method

# direct methods
.method public static final a(IILjava/util/List;)Ljava/util/ArrayList;
    .registers 12

    .line 0: if-gt v9, v10, :cond_105
    .line 2: const/4 v0, 0
    .line 3: if-nez v11, :cond_6
    .line 5: goto :goto_104
    .line 6: new-instance v1, Ljava/util/ArrayList;
    .line 8: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 11: move-result v2
    .line 12: invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 15: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 18: move-result v2
    .line 19: const/4 v3, 0
    .line 20: move v4, v3
    .line 21: if-ge v4, v2, :cond_46
    .line 23: invoke-interface {v11, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 26: move-result-object v5
    .line 27: move-object v6, v5
    .line 28: check-cast v6, Lf1/d;
    .line 30: iget v7, v6, Lf1/d;->b:I
    .line 32: iget v6, v6, Lf1/d;->c:I
    .line 34: invoke-static {v9, v10, v7, v6}, Lf1/f;->c(IIII)Z
    .line 37: move-result v6
    .line 38: if-eqz v6, :cond_43
    .line 40: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 43: add-int/lit8 v4, v4, 1
    .line 45: goto :goto_21
    .line 46: new-instance v11, Ljava/util/ArrayList;
    .line 48: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 51: move-result v2
    .line 52: invoke-direct {v11, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 55: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 58: move-result v2
    .line 59: if-ge v3, v2, :cond_96
    .line 61: invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 64: move-result-object v4
    .line 65: check-cast v4, Lf1/d;
    .line 67: new-instance v5, Lf1/d;
    .line 69: iget-object v6, v4, Lf1/d;->a:Ljava/lang/Object;
    .line 71: iget v7, v4, Lf1/d;->b:I
    .line 73: invoke-static {v9, v7}, Ljava/lang/Math;->max(II)I
    .line 76: move-result v7
    .line 77: sub-int/2addr v7, v9
    .line 78: iget v8, v4, Lf1/d;->c:I
    .line 80: invoke-static {v10, v8}, Ljava/lang/Math;->min(II)I
    .line 83: move-result v8
    .line 84: sub-int/2addr v8, v9
    .line 85: iget-object v4, v4, Lf1/d;->d:Ljava/lang/String;
    .line 87: invoke-direct {v5, v6, v7, v8, v4}, Lf1/d;-><init>(Ljava/lang/Object;IILjava/lang/String;)V
    .line 90: invoke-virtual {v11, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 93: add-int/lit8 v3, v3, 1
    .line 95: goto :goto_59
    .line 96: invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z
    .line 99: move-result v9
    .line 100: if-eqz v9, :cond_103
    .line 102: goto :goto_104
    .line 103: move-object v0, v11
    .line 104: return-object v0
    .line 105: new-instance v11, Ljava/lang/StringBuilder;
    .line 107: const-string v0, "start ("
    .line 109: invoke-direct {v11, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 112: invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 115: const-string v9, ") should be less than or equal to end ("
    .line 117: invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 120: invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 123: const/16 v9, 41
    .line 125: invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 128: invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 131: move-result-object v9
    .line 132: new-instance v10, Ljava/lang/IllegalArgumentException;
    .line 134: invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 137: move-result-object v9
    .line 138: invoke-direct {v10, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 141: throw v10
.end method

# direct methods
.method public static final b(Lf1/e;II)Ljava/util/List;
    .registers 10

    .line 0: const/4 v0, 0
    .line 1: if-ne v8, v9, :cond_4
    .line 3: return-object v0
    .line 4: iget-object v1, v7, Lf1/e;->b:Ljava/util/List;
    .line 6: if-nez v1, :cond_9
    .line 8: return-object v0
    .line 9: if-nez v8, :cond_20
    .line 11: iget-object v7, v7, Lf1/e;->a:Ljava/lang/String;
    .line 13: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 16: move-result v7
    .line 17: if-lt v9, v7, :cond_20
    .line 19: return-object v1
    .line 20: new-instance v7, Ljava/util/ArrayList;
    .line 22: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 25: move-result v0
    .line 26: invoke-direct {v7, v0}, Ljava/util/ArrayList;-><init>(I)V
    .line 29: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 32: move-result v0
    .line 33: const/4 v2, 0
    .line 34: move v3, v2
    .line 35: if-ge v3, v0, :cond_60
    .line 37: invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 40: move-result-object v4
    .line 41: move-object v5, v4
    .line 42: check-cast v5, Lf1/d;
    .line 44: iget v6, v5, Lf1/d;->b:I
    .line 46: iget v5, v5, Lf1/d;->c:I
    .line 48: invoke-static {v8, v9, v6, v5}, Lf1/f;->c(IIII)Z
    .line 51: move-result v5
    .line 52: if-eqz v5, :cond_57
    .line 54: invoke-interface {v7, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 57: add-int/lit8 v3, v3, 1
    .line 59: goto :goto_35
    .line 60: new-instance v0, Ljava/util/ArrayList;
    .line 62: invoke-interface {v7}, Ljava/util/List;->size()I
    .line 65: move-result v1
    .line 66: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    .line 69: invoke-interface {v7}, Ljava/util/List;->size()I
    .line 72: move-result v1
    .line 73: if-ge v2, v1, :cond_108
    .line 75: invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 78: move-result-object v3
    .line 79: check-cast v3, Lf1/d;
    .line 81: new-instance v4, Lf1/d;
    .line 83: iget-object v5, v3, Lf1/d;->a:Ljava/lang/Object;
    .line 85: iget v6, v3, Lf1/d;->b:I
    .line 87: invoke-static {v6, v8, v9}, Ld2/b;->G(III)I
    .line 90: move-result v6
    .line 91: sub-int/2addr v6, v8
    .line 92: iget v3, v3, Lf1/d;->c:I
    .line 94: invoke-static {v3, v8, v9}, Ld2/b;->G(III)I
    .line 97: move-result v3
    .line 98: sub-int/2addr v3, v8
    .line 99: invoke-direct {v4, v6, v3, v5}, Lf1/d;-><init>(IILjava/lang/Object;)V
    .line 102: invoke-interface {v0, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 105: add-int/lit8 v2, v2, 1
    .line 107: goto :goto_73
    .line 108: return-object v0
.end method

# direct methods
.method public static final c(IIII)Z
    .registers 8

    .line 0: invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I
    .line 3: move-result v0
    .line 4: invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I
    .line 7: move-result v1
    .line 8: const/4 v2, 1
    .line 9: if-lt v0, v1, :cond_51
    .line 11: const/4 v0, 0
    .line 12: if-gt v4, v6, :cond_31
    .line 14: if-gt v7, v5, :cond_31
    .line 16: if-ne v5, v7, :cond_51
    .line 18: if-ne v6, v7, :cond_22
    .line 20: move v1, v2
    .line 21: goto :goto_23
    .line 22: move v1, v0
    .line 23: if-ne v4, v5, :cond_27
    .line 25: move v3, v2
    .line 26: goto :goto_28
    .line 27: move v3, v0
    .line 28: if-ne v1, v3, :cond_31
    .line 30: goto :goto_51
    .line 31: if-gt v6, v4, :cond_50
    .line 33: if-gt v5, v7, :cond_50
    .line 35: if-ne v7, v5, :cond_51
    .line 37: if-ne v4, v5, :cond_41
    .line 39: move v4, v2
    .line 40: goto :goto_42
    .line 41: move v4, v0
    .line 42: if-ne v6, v7, :cond_46
    .line 44: move v5, v2
    .line 45: goto :goto_47
    .line 46: move v5, v0
    .line 47: if-ne v4, v5, :cond_50
    .line 49: goto :goto_51
    .line 50: move v2, v0
    .line 51: return v2
.end method

.class public final Lf1/o;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lq1/l;
.field public final b:Lq1/n;
.field public final c:J
.field public final d:Lq1/s;
.field public final e:Lf1/q;
.field public final f:Lq1/j;
.field public final g:Lq1/h;
.field public final h:Lq1/d;
.field public final i:Lq1/t;
.field public final j:I
.field public final k:I
.field public final l:I

# direct methods
.method public constructor <init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;I)V
    .registers 25

    .line 0: move/from16 v0, v24
    .line 2: and-int/lit8 v1, v0, 1
    .line 4: const/4 v2, 0
    .line 5: if-eqz v1, :cond_9
    .line 7: move-object v4, v2
    .line 8: goto :goto_10
    .line 9: move-object v4, v15
    .line 10: and-int/lit8 v1, v0, 2
    .line 12: if-eqz v1, :cond_16
    .line 14: move-object v5, v2
    .line 15: goto :goto_18
    .line 16: move-object/from16 v5, v16
    .line 18: and-int/lit8 v1, v0, 4
    .line 20: if-eqz v1, :cond_25
    .line 22: sget-wide v6, Lr1/k;->c:J
    .line 24: goto :goto_27
    .line 25: move-wide/from16 v6, v17
    .line 27: and-int/lit8 v1, v0, 8
    .line 29: if-eqz v1, :cond_33
    .line 31: move-object v8, v2
    .line 32: goto :goto_35
    .line 33: move-object/from16 v8, v19
    .line 35: and-int/lit8 v1, v0, 16
    .line 37: if-eqz v1, :cond_41
    .line 39: move-object v9, v2
    .line 40: goto :goto_43
    .line 41: move-object/from16 v9, v20
    .line 43: and-int/lit8 v1, v0, 32
    .line 45: if-eqz v1, :cond_49
    .line 47: move-object v10, v2
    .line 48: goto :goto_51
    .line 49: move-object/from16 v10, v21
    .line 51: and-int/lit8 v1, v0, 64
    .line 53: if-eqz v1, :cond_57
    .line 55: move-object v11, v2
    .line 56: goto :goto_59
    .line 57: move-object/from16 v11, v22
    .line 59: and-int/lit16 v0, v0, 128
    .line 61: if-eqz v0, :cond_65
    .line 63: move-object v12, v2
    .line 64: goto :goto_67
    .line 65: move-object/from16 v12, v23
    .line 67: const/4 v13, 0
    .line 68: move-object v3, v14
    .line 69: invoke-direct/range {v3 .. v13}, Lf1/o;-><init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;Lq1/t;)V
    .line 72: return-void
.end method

# direct methods
.method public constructor <init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;Lq1/t;)V
    .registers 11

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lf1/o;->a:Lq1/l;
    .line 5: iput-object v2, v0, Lf1/o;->b:Lq1/n;
    .line 7: iput-wide v3, v0, Lf1/o;->c:J
    .line 9: iput-object v5, v0, Lf1/o;->d:Lq1/s;
    .line 11: iput-object v6, v0, Lf1/o;->e:Lf1/q;
    .line 13: iput-object v7, v0, Lf1/o;->f:Lq1/j;
    .line 15: iput-object v8, v0, Lf1/o;->g:Lq1/h;
    .line 17: iput-object v9, v0, Lf1/o;->h:Lq1/d;
    .line 19: iput-object v10, v0, Lf1/o;->i:Lq1/t;
    .line 21: if-eqz v1, :cond_26
    .line 23: iget v1, v1, Lq1/l;->a:I
    .line 25: goto :goto_27
    .line 26: const/4 v1, 5
    .line 27: iput v1, v0, Lf1/o;->j:I
    .line 29: if-eqz v8, :cond_34
    .line 31: iget v1, v8, Lq1/h;->a:I
    .line 33: goto :goto_36
    .line 34: sget v1, Lq1/h;->b:I
    .line 36: iput v1, v0, Lf1/o;->k:I
    .line 38: if-eqz v9, :cond_43
    .line 40: iget v1, v9, Lq1/d;->a:I
    .line 42: goto :goto_44
    .line 43: const/4 v1, 1
    .line 44: iput v1, v0, Lf1/o;->l:I
    .line 46: sget-wide v1, Lr1/k;->c:J
    .line 48: invoke-static {v3, v4, v1, v2}, Lr1/k;->a(JJ)Z
    .line 51: move-result v1
    .line 52: if-nez v1, :cond_97
    .line 54: invoke-static {v3, v4}, Lr1/k;->c(J)F
    .line 57: move-result v1
    .line 58: const/4 v2, 0
    .line 59: cmpl-float v1, v1, v2
    .line 61: if-ltz v1, :cond_64
    .line 63: goto :goto_97
    .line 64: new-instance v1, Ljava/lang/StringBuilder;
    .line 66: const-string v2, "lineHeight can't be negative ("
    .line 68: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 71: invoke-static {v3, v4}, Lr1/k;->c(J)F
    .line 74: move-result v2
    .line 75: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 78: const/16 v2, 41
    .line 80: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 83: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 86: move-result-object v1
    .line 87: new-instance v2, Ljava/lang/IllegalStateException;
    .line 89: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 92: move-result-object v1
    .line 93: invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 96: throw v2
    .line 97: return-void
.end method

# virtual methods
.method public final a(Lf1/o;)Lf1/o;
    .registers 35

    .line 0: move-object/from16 v0, v33
    .line 2: move-object/from16 v1, v34
    .line 4: if-nez v1, :cond_7
    .line 6: return-object v0
    .line 7: sget v2, Lf1/p;->b:I
    .line 9: iget-object v2, v1, Lf1/o;->a:Lq1/l;
    .line 11: iget-object v3, v1, Lf1/o;->b:Lq1/n;
    .line 13: iget-wide v4, v1, Lf1/o;->c:J
    .line 15: iget-object v6, v1, Lf1/o;->d:Lq1/s;
    .line 17: iget-object v7, v1, Lf1/o;->e:Lf1/q;
    .line 19: iget-object v8, v1, Lf1/o;->f:Lq1/j;
    .line 21: iget-object v9, v1, Lf1/o;->g:Lq1/h;
    .line 23: iget-object v10, v1, Lf1/o;->h:Lq1/d;
    .line 25: iget-object v1, v1, Lf1/o;->i:Lq1/t;
    .line 27: iget-object v11, v0, Lf1/o;->i:Lq1/t;
    .line 29: iget-object v12, v0, Lf1/o;->h:Lq1/d;
    .line 31: iget-object v13, v0, Lf1/o;->g:Lq1/h;
    .line 33: iget-object v14, v0, Lf1/o;->f:Lq1/j;
    .line 35: iget-object v15, v0, Lf1/o;->e:Lf1/q;
    .line 37: move-object/from16 v34, v11
    .line 39: iget-object v11, v0, Lf1/o;->b:Lq1/n;
    .line 41: move-object/from16 v16, v1
    .line 43: iget-object v1, v0, Lf1/o;->d:Lq1/s;
    .line 45: move-object/from16 v17, v12
    .line 47: move-object/from16 v18, v13
    .line 49: iget-wide v12, v0, Lf1/o;->c:J
    .line 51: move-object/from16 v19, v10
    .line 53: iget-object v10, v0, Lf1/o;->a:Lq1/l;
    .line 55: if-eqz v2, :cond_78
    .line 57: invoke-static {v2, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 60: move-result v20
    .line 61: if-eqz v20, :cond_64
    .line 63: goto :goto_78
    .line 64: move-object/from16 v0, v19
    .line 66: move-object/from16 v19, v17
    .line 68: move-object/from16 v17, v1
    .line 70: move-object/from16 v1, v16
    .line 72: move-object/from16 v16, v10
    .line 74: move-object/from16 v10, v34
    .line 76: goto/16 :goto_176
    .line 78: invoke-static {v4, v5}, Ld2/c;->d0(J)Z
    .line 81: move-result v20
    .line 82: xor-int/lit8 v20, v20, 1
    .line 84: if-eqz v20, :cond_92
    .line 86: invoke-static {v4, v5, v12, v13}, Lr1/k;->a(JJ)Z
    .line 89: move-result v20
    .line 90: if-eqz v20, :cond_64
    .line 92: if-eqz v6, :cond_100
    .line 94: invoke-static {v6, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 97: move-result v20
    .line 98: if-eqz v20, :cond_64
    .line 100: if-eqz v3, :cond_108
    .line 102: invoke-static {v3, v11}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 105: move-result v20
    .line 106: if-eqz v20, :cond_64
    .line 108: if-eqz v7, :cond_116
    .line 110: invoke-static {v7, v15}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 113: move-result v20
    .line 114: if-eqz v20, :cond_64
    .line 116: if-eqz v8, :cond_124
    .line 118: invoke-static {v8, v14}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 121: move-result v20
    .line 122: if-eqz v20, :cond_64
    .line 124: move-object/from16 v0, v18
    .line 126: if-eqz v9, :cond_138
    .line 128: invoke-static {v9, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 131: move-result v18
    .line 132: if-eqz v18, :cond_135
    .line 134: goto :goto_138
    .line 135: move-object/from16 v18, v0
    .line 137: goto :goto_64
    .line 138: move-object/from16 v18, v0
    .line 140: move-object/from16 v0, v19
    .line 142: move-object/from16 v32, v17
    .line 144: move-object/from16 v17, v1
    .line 146: move-object/from16 v1, v32
    .line 148: if-eqz v19, :cond_160
    .line 150: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 153: move-result v19
    .line 154: if-eqz v19, :cond_157
    .line 156: goto :goto_160
    .line 157: move-object/from16 v19, v1
    .line 159: goto :goto_70
    .line 160: if-eqz v16, :cond_253
    .line 162: move-object/from16 v19, v1
    .line 164: move-object/from16 v1, v16
    .line 166: move-object/from16 v16, v10
    .line 168: move-object/from16 v10, v34
    .line 170: invoke-static {v1, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 173: move-result v20
    .line 174: if-nez v20, :cond_253
    .line 176: invoke-static {v4, v5}, Ld2/c;->d0(J)Z
    .line 179: move-result v20
    .line 180: if-eqz v20, :cond_185
    .line 182: move-wide/from16 v24, v12
    .line 184: goto :goto_187
    .line 185: move-wide/from16 v24, v4
    .line 187: if-nez v6, :cond_192
    .line 189: move-object/from16 v26, v17
    .line 191: goto :goto_194
    .line 192: move-object/from16 v26, v6
    .line 194: if-nez v2, :cond_199
    .line 196: move-object/from16 v22, v16
    .line 198: goto :goto_201
    .line 199: move-object/from16 v22, v2
    .line 201: if-nez v3, :cond_206
    .line 203: move-object/from16 v23, v11
    .line 205: goto :goto_208
    .line 206: move-object/from16 v23, v3
    .line 208: if-nez v15, :cond_213
    .line 210: move-object/from16 v27, v7
    .line 212: goto :goto_217
    .line 213: if-nez v7, :cond_210
    .line 215: move-object/from16 v27, v15
    .line 217: if-nez v8, :cond_222
    .line 219: move-object/from16 v28, v14
    .line 221: goto :goto_224
    .line 222: move-object/from16 v28, v8
    .line 224: if-nez v9, :cond_229
    .line 226: move-object/from16 v29, v18
    .line 228: goto :goto_231
    .line 229: move-object/from16 v29, v9
    .line 231: if-nez v0, :cond_236
    .line 233: move-object/from16 v30, v19
    .line 235: goto :goto_238
    .line 236: move-object/from16 v30, v0
    .line 238: if-nez v1, :cond_243
    .line 240: move-object/from16 v31, v10
    .line 242: goto :goto_245
    .line 243: move-object/from16 v31, v1
    .line 245: new-instance v0, Lf1/o;
    .line 247: move-object/from16 v21, v0
    .line 249: invoke-direct/range {v21 .. v31}, Lf1/o;-><init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;Lq1/t;)V
    .line 252: goto :goto_255
    .line 253: move-object/from16 v0, v33
    .line 255: return-object v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lf1/o;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lf1/o;
    .line 12: iget-object v1, v8, Lf1/o;->a:Lq1/l;
    .line 14: iget-object v3, v7, Lf1/o;->a:Lq1/l;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v7, Lf1/o;->b:Lq1/n;
    .line 25: iget-object v3, v8, Lf1/o;->b:Lq1/n;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-wide v3, v7, Lf1/o;->c:J
    .line 36: iget-wide v5, v8, Lf1/o;->c:J
    .line 38: invoke-static {v3, v4, v5, v6}, Lr1/k;->a(JJ)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget-object v1, v7, Lf1/o;->d:Lq1/s;
    .line 47: iget-object v3, v8, Lf1/o;->d:Lq1/s;
    .line 49: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v1
    .line 53: if-nez v1, :cond_56
    .line 55: return v2
    .line 56: iget-object v1, v7, Lf1/o;->e:Lf1/q;
    .line 58: iget-object v3, v8, Lf1/o;->e:Lf1/q;
    .line 60: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 63: move-result v1
    .line 64: if-nez v1, :cond_67
    .line 66: return v2
    .line 67: iget-object v1, v7, Lf1/o;->f:Lq1/j;
    .line 69: iget-object v3, v8, Lf1/o;->f:Lq1/j;
    .line 71: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 74: move-result v1
    .line 75: if-nez v1, :cond_78
    .line 77: return v2
    .line 78: iget-object v1, v7, Lf1/o;->g:Lq1/h;
    .line 80: iget-object v3, v8, Lf1/o;->g:Lq1/h;
    .line 82: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 85: move-result v1
    .line 86: if-nez v1, :cond_89
    .line 88: return v2
    .line 89: iget-object v1, v7, Lf1/o;->h:Lq1/d;
    .line 91: iget-object v3, v8, Lf1/o;->h:Lq1/d;
    .line 93: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 96: move-result v1
    .line 97: if-nez v1, :cond_100
    .line 99: return v2
    .line 100: iget-object v1, v7, Lf1/o;->i:Lq1/t;
    .line 102: iget-object v8, v8, Lf1/o;->i:Lq1/t;
    .line 104: invoke-static {v1, v8}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 107: move-result v8
    .line 108: if-nez v8, :cond_111
    .line 110: return v2
    .line 111: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 6

    .line 0: const/4 v0, 0
    .line 1: iget-object v1, v5, Lf1/o;->a:Lq1/l;
    .line 3: if-eqz v1, :cond_12
    .line 5: iget v1, v1, Lq1/l;->a:I
    .line 7: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 10: move-result v1
    .line 11: goto :goto_13
    .line 12: move v1, v0
    .line 13: const/16 v2, 31
    .line 15: mul-int/2addr v1, v2
    .line 16: iget-object v3, v5, Lf1/o;->b:Lq1/n;
    .line 18: if-eqz v3, :cond_27
    .line 20: iget v3, v3, Lq1/n;->a:I
    .line 22: invoke-static {v3}, Ljava/lang/Integer;->hashCode(I)I
    .line 25: move-result v3
    .line 26: goto :goto_28
    .line 27: move v3, v0
    .line 28: add-int/2addr v1, v3
    .line 29: mul-int/2addr v1, v2
    .line 30: sget-object v3, Lr1/k;->b:[Lr1/l;
    .line 32: iget-wide v3, v5, Lf1/o;->c:J
    .line 34: invoke-static {v3, v4, v1, v2}, Lai/onnxruntime/b;->d(JII)I
    .line 37: move-result v1
    .line 38: iget-object v3, v5, Lf1/o;->d:Lq1/s;
    .line 40: if-eqz v3, :cond_47
    .line 42: invoke-virtual {v3}, Lq1/s;->hashCode()I
    .line 45: move-result v3
    .line 46: goto :goto_48
    .line 47: move v3, v0
    .line 48: add-int/2addr v1, v3
    .line 49: mul-int/2addr v1, v2
    .line 50: iget-object v3, v5, Lf1/o;->e:Lf1/q;
    .line 52: if-eqz v3, :cond_59
    .line 54: invoke-virtual {v3}, Lf1/q;->hashCode()I
    .line 57: move-result v3
    .line 58: goto :goto_60
    .line 59: move v3, v0
    .line 60: add-int/2addr v1, v3
    .line 61: mul-int/2addr v1, v2
    .line 62: iget-object v3, v5, Lf1/o;->f:Lq1/j;
    .line 64: if-eqz v3, :cond_71
    .line 66: invoke-virtual {v3}, Lq1/j;->hashCode()I
    .line 69: move-result v3
    .line 70: goto :goto_72
    .line 71: move v3, v0
    .line 72: add-int/2addr v1, v3
    .line 73: mul-int/2addr v1, v2
    .line 74: iget-object v3, v5, Lf1/o;->g:Lq1/h;
    .line 76: if-eqz v3, :cond_85
    .line 78: iget v3, v3, Lq1/h;->a:I
    .line 80: invoke-static {v3}, Ljava/lang/Integer;->hashCode(I)I
    .line 83: move-result v3
    .line 84: goto :goto_86
    .line 85: move v3, v0
    .line 86: add-int/2addr v1, v3
    .line 87: mul-int/2addr v1, v2
    .line 88: iget-object v3, v5, Lf1/o;->h:Lq1/d;
    .line 90: if-eqz v3, :cond_99
    .line 92: iget v3, v3, Lq1/d;->a:I
    .line 94: invoke-static {v3}, Ljava/lang/Integer;->hashCode(I)I
    .line 97: move-result v3
    .line 98: goto :goto_100
    .line 99: move v3, v0
    .line 100: add-int/2addr v1, v3
    .line 101: mul-int/2addr v1, v2
    .line 102: iget-object v2, v5, Lf1/o;->i:Lq1/t;
    .line 104: if-eqz v2, :cond_110
    .line 106: invoke-virtual {v2}, Lq1/t;->hashCode()I
    .line 109: move-result v0
    .line 110: add-int/2addr v1, v0
    .line 111: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ParagraphStyle(textAlign="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lf1/o;->a:Lq1/l;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", textDirection="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lf1/o;->b:Lq1/n;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", lineHeight="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-wide v1, v3, Lf1/o;->c:J
    .line 29: invoke-static {v1, v2}, Lr1/k;->d(J)Ljava/lang/String;
    .line 32: move-result-object v1
    .line 33: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 36: const-string v1, ", textIndent="
    .line 38: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 41: iget-object v1, v3, Lf1/o;->d:Lq1/s;
    .line 43: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 46: const-string v1, ", platformStyle="
    .line 48: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 51: iget-object v1, v3, Lf1/o;->e:Lf1/q;
    .line 53: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 56: const-string v1, ", lineHeightStyle="
    .line 58: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 61: iget-object v1, v3, Lf1/o;->f:Lq1/j;
    .line 63: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 66: const-string v1, ", lineBreak="
    .line 68: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 71: iget-object v1, v3, Lf1/o;->g:Lq1/h;
    .line 73: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 76: const-string v1, ", hyphens="
    .line 78: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 81: iget-object v1, v3, Lf1/o;->h:Lq1/d;
    .line 83: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 86: const-string v1, ", textMotion="
    .line 88: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 91: iget-object v1, v3, Lf1/o;->i:Lq1/t;
    .line 93: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 96: const/16 v1, 41
    .line 98: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 101: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 104: move-result-object v0
    .line 105: return-object v0
.end method

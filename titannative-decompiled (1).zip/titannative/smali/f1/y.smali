.class public final Lf1/y;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lf1/e;
.field public final b:Lf1/b0;
.field public final c:Ljava/util/List;
.field public final d:I
.field public final e:Z
.field public final f:I
.field public final g:Lr1/b;
.field public final h:Lr1/j;
.field public final i:Lk1/r;
.field public final j:J

# direct methods
.method public constructor <init>(Lf1/e;Lf1/b0;Ljava/util/List;IZILr1/b;Lr1/j;Lk1/r;J)V
    .registers 13

    .line 0: const-string v0, "text"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "style"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "placeholders"
    .line 12: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: const-string v0, "density"
    .line 17: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: const-string v0, "layoutDirection"
    .line 22: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: const-string v0, "fontFamilyResolver"
    .line 27: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 30: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 33: iput-object v2, v1, Lf1/y;->a:Lf1/e;
    .line 35: iput-object v3, v1, Lf1/y;->b:Lf1/b0;
    .line 37: iput-object v4, v1, Lf1/y;->c:Ljava/util/List;
    .line 39: iput v5, v1, Lf1/y;->d:I
    .line 41: iput-boolean v6, v1, Lf1/y;->e:Z
    .line 43: iput v7, v1, Lf1/y;->f:I
    .line 45: iput-object v8, v1, Lf1/y;->g:Lr1/b;
    .line 47: iput-object v9, v1, Lf1/y;->h:Lr1/j;
    .line 49: iput-object v10, v1, Lf1/y;->i:Lk1/r;
    .line 51: iput-wide v11, v1, Lf1/y;->j:J
    .line 53: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lf1/y;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lf1/y;
    .line 12: iget-object v1, v8, Lf1/y;->a:Lf1/e;
    .line 14: iget-object v3, v7, Lf1/y;->a:Lf1/e;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v7, Lf1/y;->b:Lf1/b0;
    .line 25: iget-object v3, v8, Lf1/y;->b:Lf1/b0;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v7, Lf1/y;->c:Ljava/util/List;
    .line 36: iget-object v3, v8, Lf1/y;->c:Ljava/util/List;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget v1, v7, Lf1/y;->d:I
    .line 47: iget v3, v8, Lf1/y;->d:I
    .line 49: if-eq v1, v3, :cond_52
    .line 51: return v2
    .line 52: iget-boolean v1, v7, Lf1/y;->e:Z
    .line 54: iget-boolean v3, v8, Lf1/y;->e:Z
    .line 56: if-eq v1, v3, :cond_59
    .line 58: return v2
    .line 59: iget v1, v7, Lf1/y;->f:I
    .line 61: iget v3, v8, Lf1/y;->f:I
    .line 63: invoke-static {v1, v3}, Ld2/c;->O(II)Z
    .line 66: move-result v1
    .line 67: if-nez v1, :cond_70
    .line 69: return v2
    .line 70: iget-object v1, v7, Lf1/y;->g:Lr1/b;
    .line 72: iget-object v3, v8, Lf1/y;->g:Lr1/b;
    .line 74: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 77: move-result v1
    .line 78: if-nez v1, :cond_81
    .line 80: return v2
    .line 81: iget-object v1, v7, Lf1/y;->h:Lr1/j;
    .line 83: iget-object v3, v8, Lf1/y;->h:Lr1/j;
    .line 85: if-eq v1, v3, :cond_88
    .line 87: return v2
    .line 88: iget-object v1, v7, Lf1/y;->i:Lk1/r;
    .line 90: iget-object v3, v8, Lf1/y;->i:Lk1/r;
    .line 92: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 95: move-result v1
    .line 96: if-nez v1, :cond_99
    .line 98: return v2
    .line 99: iget-wide v3, v7, Lf1/y;->j:J
    .line 101: iget-wide v5, v8, Lf1/y;->j:J
    .line 103: invoke-static {v3, v4, v5, v6}, Lr1/a;->b(JJ)Z
    .line 106: move-result v8
    .line 107: if-nez v8, :cond_110
    .line 109: return v2
    .line 110: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lf1/y;->a:Lf1/e;
    .line 2: invoke-virtual {v0}, Lf1/e;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v3, Lf1/y;->b:Lf1/b0;
    .line 11: invoke-virtual {v2}, Lf1/b0;->hashCode()I
    .line 14: move-result v2
    .line 15: add-int/2addr v2, v0
    .line 16: mul-int/2addr v2, v1
    .line 17: iget-object v0, v3, Lf1/y;->c:Ljava/util/List;
    .line 19: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 22: move-result v0
    .line 23: add-int/2addr v0, v2
    .line 24: mul-int/2addr v0, v1
    .line 25: iget v2, v3, Lf1/y;->d:I
    .line 27: add-int/2addr v0, v2
    .line 28: mul-int/2addr v0, v1
    .line 29: iget-boolean v2, v3, Lf1/y;->e:Z
    .line 31: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->e(ZII)I
    .line 34: move-result v0
    .line 35: iget v2, v3, Lf1/y;->f:I
    .line 37: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 40: move-result v0
    .line 41: iget-object v2, v3, Lf1/y;->g:Lr1/b;
    .line 43: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 46: move-result v2
    .line 47: add-int/2addr v2, v0
    .line 48: mul-int/2addr v2, v1
    .line 49: iget-object v0, v3, Lf1/y;->h:Lr1/j;
    .line 51: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 54: move-result v0
    .line 55: add-int/2addr v0, v2
    .line 56: mul-int/2addr v0, v1
    .line 57: iget-object v2, v3, Lf1/y;->i:Lk1/r;
    .line 59: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 62: move-result v2
    .line 63: add-int/2addr v2, v0
    .line 64: mul-int/2addr v2, v1
    .line 65: iget-wide v0, v3, Lf1/y;->j:J
    .line 67: invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I
    .line 70: move-result v0
    .line 71: add-int/2addr v0, v2
    .line 72: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "TextLayoutInput(text="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lf1/y;->a:Lf1/e;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", style="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lf1/y;->b:Lf1/b0;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", placeholders="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v3, Lf1/y;->c:Ljava/util/List;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", maxLines="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v3, Lf1/y;->d:I
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", softWrap="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-boolean v1, v3, Lf1/y;->e:Z
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", overflow="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget v1, v3, Lf1/y;->f:I
    .line 59: invoke-static {v1}, Ld2/c;->H0(I)Ljava/lang/String;
    .line 62: move-result-object v1
    .line 63: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 66: const-string v1, ", density="
    .line 68: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 71: iget-object v1, v3, Lf1/y;->g:Lr1/b;
    .line 73: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 76: const-string v1, ", layoutDirection="
    .line 78: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 81: iget-object v1, v3, Lf1/y;->h:Lr1/j;
    .line 83: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 86: const-string v1, ", fontFamilyResolver="
    .line 88: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 91: iget-object v1, v3, Lf1/y;->i:Lk1/r;
    .line 93: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 96: const-string v1, ", constraints="
    .line 98: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 101: iget-wide v1, v3, Lf1/y;->j:J
    .line 103: invoke-static {v1, v2}, Lr1/a;->k(J)Ljava/lang/String;
    .line 106: move-result-object v1
    .line 107: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 110: const/16 v1, 41
    .line 112: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 115: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 118: move-result-object v0
    .line 119: return-object v0
.end method

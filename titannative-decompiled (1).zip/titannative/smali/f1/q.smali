.class public final Lf1/q;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final c:Lf1/q;

.field public final a:Z
.field public final b:I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: new-instance v0, Lf1/q;
    .line 2: const/4 v1, 0
    .line 3: const/4 v2, 1
    .line 4: invoke-direct {v0, v1, v2}, Lf1/q;-><init>(IZ)V
    .line 7: sput-object v0, Lf1/q;->c:Lf1/q;
    .line 9: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 1
    .line 4: iput-boolean v0, v1, Lf1/q;->a:Z
    .line 6: const/4 v0, 0
    .line 7: iput v0, v1, Lf1/q;->b:I
    .line 9: return-void
.end method

# direct methods
.method public constructor <init>(IZ)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-boolean v2, v0, Lf1/q;->a:Z
    .line 5: iput v1, v0, Lf1/q;->b:I
    .line 7: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lf1/q;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lf1/q;
    .line 12: iget-boolean v1, v5, Lf1/q;->a:Z
    .line 14: iget-boolean v3, v4, Lf1/q;->a:Z
    .line 16: if-eq v3, v1, :cond_19
    .line 18: return v2
    .line 19: iget v1, v4, Lf1/q;->b:I
    .line 21: iget v5, v5, Lf1/q;->b:I
    .line 23: if-ne v1, v5, :cond_26
    .line 25: return v0
    .line 26: return v2
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-boolean v0, v2, Lf1/q;->a:Z
    .line 2: invoke-static {v0}, Ljava/lang/Boolean;->hashCode(Z)I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget v1, v2, Lf1/q;->b:I
    .line 10: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "PlatformParagraphStyle(includeFontPadding="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-boolean v1, v2, Lf1/q;->a:Z
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", emojiSupportMatch="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lf1/q;->b:I
    .line 19: invoke-static {v1}, Lf1/h;->a(I)Ljava/lang/String;
    .line 22: move-result-object v1
    .line 23: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 26: const/16 v1, 41
    .line 28: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 31: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 34: move-result-object v0
    .line 35: return-object v0
.end method

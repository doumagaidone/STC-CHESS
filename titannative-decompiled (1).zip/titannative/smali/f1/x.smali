.class public abstract Lf1/x;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:J
.field public static final b:J
.field public static final c:J
.field public static final d:J
.field public static final synthetic e:I

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/16 v0, 14
    .line 2: invoke-static {v0}, Ld2/c;->Z(I)J
    .line 5: move-result-wide v0
    .line 6: sput-wide v0, Lf1/x;->a:J
    .line 8: const/4 v0, 0
    .line 9: invoke-static {v0}, Ld2/c;->Z(I)J
    .line 12: move-result-wide v0
    .line 13: sput-wide v0, Lf1/x;->b:J
    .line 15: sget v0, Lk0/q;->h:I
    .line 17: sget-wide v0, Lk0/q;->f:J
    .line 19: sput-wide v0, Lf1/x;->c:J
    .line 21: sget-wide v0, Lk0/q;->b:J
    .line 23: sput-wide v0, Lf1/x;->d:J
    .line 25: return-void
.end method

# direct methods
.method public static final a(Ljava/lang/Object;Ljava/lang/Object;F)Ljava/lang/Object;
    .registers 7

    .line 0: float-to-double v0, v6
    .line 1: const-wide/high16 v2, 0x3fe0
    .line 3: cmpg-double v6, v0, v2
    .line 5: if-gez v6, :cond_8
    .line 7: goto :goto_9
    .line 8: move-object v4, v5
    .line 9: return-object v4
.end method

# direct methods
.method public static final b(JJF)J
    .registers 9

    .line 0: invoke-static {v4, v5}, Ld2/c;->d0(J)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_122
    .line 6: invoke-static {v6, v7}, Ld2/c;->d0(J)Z
    .line 9: move-result v0
    .line 10: if-eqz v0, :cond_13
    .line 12: goto :goto_122
    .line 13: invoke-static {v4, v5}, Ld2/c;->d0(J)Z
    .line 16: move-result v0
    .line 17: if-nez v0, :cond_110
    .line 19: invoke-static {v6, v7}, Ld2/c;->d0(J)Z
    .line 22: move-result v0
    .line 23: if-nez v0, :cond_110
    .line 25: invoke-static {v4, v5}, Lr1/k;->b(J)J
    .line 28: move-result-wide v0
    .line 29: invoke-static {v6, v7}, Lr1/k;->b(J)J
    .line 32: move-result-wide v2
    .line 33: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 36: move-result v0
    .line 37: if-eqz v0, :cond_62
    .line 39: const-wide v0, 0x0ff00
    .line 44: and-long/2addr v0, v4
    .line 45: invoke-static {v4, v5}, Lr1/k;->c(J)F
    .line 48: move-result v4
    .line 49: invoke-static {v6, v7}, Lr1/k;->c(J)F
    .line 52: move-result v5
    .line 53: invoke-static {v4, v5, v8}, Ld2/b;->G0(FFF)F
    .line 56: move-result v4
    .line 57: invoke-static {v4, v0, v1}, Ld2/c;->m0(FJ)J
    .line 60: move-result-wide v4
    .line 61: return-wide v4
    .line 62: new-instance v8, Ljava/lang/StringBuilder;
    .line 64: const-string v0, "Cannot perform operation for "
    .line 66: invoke-direct {v8, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 69: invoke-static {v4, v5}, Lr1/k;->b(J)J
    .line 72: move-result-wide v4
    .line 73: invoke-static {v4, v5}, Lr1/l;->b(J)Ljava/lang/String;
    .line 76: move-result-object v4
    .line 77: invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 80: const-string v4, " and "
    .line 82: invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 85: invoke-static {v6, v7}, Lr1/k;->b(J)J
    .line 88: move-result-wide v4
    .line 89: invoke-static {v4, v5}, Lr1/l;->b(J)Ljava/lang/String;
    .line 92: move-result-object v4
    .line 93: invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 96: invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 99: move-result-object v4
    .line 100: new-instance v5, Ljava/lang/IllegalArgumentException;
    .line 102: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 105: move-result-object v4
    .line 106: invoke-direct {v5, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 109: throw v5
    .line 110: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 112: const-string v5, "Cannot perform operation for Unspecified type."
    .line 114: invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 117: move-result-object v5
    .line 118: invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 121: throw v4
    .line 122: new-instance v0, Lr1/k;
    .line 124: invoke-direct {v0, v4, v5}, Lr1/k;-><init>(J)V
    .line 127: new-instance v4, Lr1/k;
    .line 129: invoke-direct {v4, v6, v7}, Lr1/k;-><init>(J)V
    .line 132: invoke-static {v0, v4, v8}, Lf1/x;->a(Ljava/lang/Object;Ljava/lang/Object;F)Ljava/lang/Object;
    .line 135: move-result-object v4
    .line 136: check-cast v4, Lr1/k;
    .line 138: iget-wide v4, v4, Lr1/k;->a:J
    .line 140: return-wide v4
.end method

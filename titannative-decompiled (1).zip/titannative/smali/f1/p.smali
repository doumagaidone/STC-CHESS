.class public abstract Lf1/p;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:J
.field public static final synthetic b:I

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Lr1/k;->b:[Lr1/l;
    .line 2: sget-wide v0, Lr1/k;->c:J
    .line 4: sput-wide v0, Lf1/p;->a:J
    .line 6: return-void
.end method

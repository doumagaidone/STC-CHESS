.class public final Lf1/i;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lf1/k;
.field public final b:I
.field public final c:Z
.field public final d:F
.field public final e:F
.field public final f:I
.field public final g:Ljava/util/ArrayList;
.field public final h:Ljava/util/ArrayList;

# direct methods
.method public constructor <init>(Lf1/k;JIZ)V
    .registers 26

    .line 0: move-object/from16 v0, v20
    .line 2: move-object/from16 v1, v21
    .line 4: invoke-direct/range {v20 .. v20}, Ljava/lang/Object;-><init>()V
    .line 7: iput-object v1, v0, Lf1/i;->a:Lf1/k;
    .line 9: move/from16 v2, v24
    .line 11: iput v2, v0, Lf1/i;->b:I
    .line 13: invoke-static/range {v22 .. v23}, Lr1/a;->j(J)I
    .line 16: move-result v2
    .line 17: if-nez v2, :cond_316
    .line 19: invoke-static/range {v22 .. v23}, Lr1/a;->i(J)I
    .line 22: move-result v2
    .line 23: if-nez v2, :cond_316
    .line 25: new-instance v2, Ljava/util/ArrayList;
    .line 27: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 30: iget-object v1, v1, Lf1/k;->e:Ljava/util/ArrayList;
    .line 32: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 35: move-result v3
    .line 36: const/4 v6, 0
    .line 37: const/4 v11, 0
    .line 38: const/4 v13, 0
    .line 39: if-ge v6, v3, :cond_174
    .line 41: invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 44: move-result-object v7
    .line 45: check-cast v7, Lf1/m;
    .line 47: iget-object v8, v7, Lf1/m;->a:Lf1/n;
    .line 49: invoke-static/range {v22 .. v23}, Lr1/a;->h(J)I
    .line 52: move-result v9
    .line 53: invoke-static/range {v22 .. v23}, Lr1/a;->c(J)Z
    .line 56: move-result v10
    .line 57: if-eqz v10, :cond_75
    .line 59: invoke-static/range {v22 .. v23}, Lr1/a;->g(J)I
    .line 62: move-result v10
    .line 63: float-to-double v14, v13
    .line 64: invoke-static {v14, v15}, Ljava/lang/Math;->ceil(D)D
    .line 67: move-result-wide v14
    .line 68: double-to-float v12, v14
    .line 69: float-to-int v12, v12
    .line 70: sub-int/2addr v10, v12
    .line 71: if-gez v10, :cond_79
    .line 73: const/4 v10, 0
    .line 74: goto :goto_79
    .line 75: invoke-static/range {v22 .. v23}, Lr1/a;->g(J)I
    .line 78: move-result v10
    .line 79: const/4 v12, 5
    .line 80: invoke-static {v9, v10, v12}, Ld2/c;->b(III)J
    .line 83: move-result-wide v18
    .line 84: iget v9, v0, Lf1/i;->b:I
    .line 86: sub-int v16, v9, v11
    .line 88: const-string v9, "paragraphIntrinsics"
    .line 90: invoke-static {v8, v9}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 93: new-instance v9, Lf1/a;
    .line 95: move-object v15, v8
    .line 96: check-cast v15, Ln1/c;
    .line 98: move-object v14, v9
    .line 99: move/from16 v17, v25
    .line 101: invoke-direct/range {v14 .. v19}, Lf1/a;-><init>(Ln1/c;IZJ)V
    .line 104: invoke-virtual {v9}, Lf1/a;->b()F
    .line 107: move-result v8
    .line 108: add-float v15, v8, v13
    .line 110: iget-object v14, v9, Lf1/a;->d:Lg1/s;
    .line 112: iget v8, v14, Lg1/s;->e:I
    .line 114: add-int v12, v11, v8
    .line 116: new-instance v10, Lf1/l;
    .line 118: iget v8, v7, Lf1/m;->b:I
    .line 120: iget v7, v7, Lf1/m;->c:I
    .line 122: move/from16 v16, v7
    .line 124: move-object v7, v10
    .line 125: move/from16 v17, v8
    .line 127: move-object v8, v9
    .line 128: move/from16 v9, v17
    .line 130: move-object v5, v10
    .line 131: move/from16 v10, v16
    .line 133: move/from16 v24, v12
    .line 135: move-object v4, v14
    .line 136: move v14, v15
    .line 137: invoke-direct/range {v7 .. v14}, Lf1/l;-><init>(Lf1/a;IIIIFF)V
    .line 140: invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 143: iget-boolean v4, v4, Lg1/s;->c:Z
    .line 145: if-nez v4, :cond_169
    .line 147: iget v4, v0, Lf1/i;->b:I
    .line 149: move/from16 v11, v24
    .line 151: if-ne v11, v4, :cond_164
    .line 153: iget-object v4, v0, Lf1/i;->a:Lf1/k;
    .line 155: iget-object v4, v4, Lf1/k;->e:Ljava/util/ArrayList;
    .line 157: invoke-static {v4}, Ld2/b;->r0(Ljava/util/List;)I
    .line 160: move-result v4
    .line 161: if-eq v6, v4, :cond_164
    .line 163: goto :goto_171
    .line 164: add-int/lit8 v6, v6, 1
    .line 166: move v13, v15
    .line 167: goto/16 :goto_39
    .line 169: move/from16 v11, v24
    .line 171: const/4 v1, 1
    .line 172: move v13, v15
    .line 173: goto :goto_175
    .line 174: const/4 v1, 0
    .line 175: iput v13, v0, Lf1/i;->e:F
    .line 177: iput v11, v0, Lf1/i;->f:I
    .line 179: iput-boolean v1, v0, Lf1/i;->c:Z
    .line 181: iput-object v2, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 183: invoke-static/range {v22 .. v23}, Lr1/a;->h(J)I
    .line 186: move-result v1
    .line 187: int-to-float v1, v1
    .line 188: iput v1, v0, Lf1/i;->d:F
    .line 190: new-instance v1, Ljava/util/ArrayList;
    .line 192: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 195: move-result v3
    .line 196: invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V
    .line 199: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 202: move-result v3
    .line 203: const/4 v4, 0
    .line 204: const/4 v5, 0
    .line 205: if-ge v4, v3, :cond_268
    .line 207: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 210: move-result-object v6
    .line 211: check-cast v6, Lf1/l;
    .line 213: iget-object v7, v6, Lf1/l;->a:Lf1/a;
    .line 215: iget-object v7, v7, Lf1/a;->f:Ljava/util/List;
    .line 217: new-instance v8, Ljava/util/ArrayList;
    .line 219: invoke-interface {v7}, Ljava/util/List;->size()I
    .line 222: move-result v9
    .line 223: invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V
    .line 226: invoke-interface {v7}, Ljava/util/List;->size()I
    .line 229: move-result v9
    .line 230: const/4 v10, 0
    .line 231: if-ge v10, v9, :cond_261
    .line 233: invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 236: move-result-object v11
    .line 237: check-cast v11, Lj0/d;
    .line 239: if-eqz v11, :cond_253
    .line 241: iget v12, v6, Lf1/l;->f:F
    .line 243: const/4 v13, 0
    .line 244: invoke-static {v13, v12}, Ln3/a0;->g(FF)J
    .line 247: move-result-wide v14
    .line 248: invoke-virtual {v11, v14, v15}, Lj0/d;->f(J)Lj0/d;
    .line 251: move-result-object v11
    .line 252: goto :goto_255
    .line 253: const/4 v13, 0
    .line 254: move-object v11, v5
    .line 255: invoke-virtual {v8, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 258: add-int/lit8 v10, v10, 1
    .line 260: goto :goto_231
    .line 261: const/4 v13, 0
    .line 262: invoke-static {v8, v1}, Lt2/m;->G1(Ljava/lang/Iterable;Ljava/util/Collection;)V
    .line 265: add-int/lit8 v4, v4, 1
    .line 267: goto :goto_204
    .line 268: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 271: move-result v2
    .line 272: iget-object v3, v0, Lf1/i;->a:Lf1/k;
    .line 274: iget-object v3, v3, Lf1/k;->b:Ljava/util/List;
    .line 276: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 279: move-result v3
    .line 280: if-ge v2, v3, :cond_313
    .line 282: iget-object v2, v0, Lf1/i;->a:Lf1/k;
    .line 284: iget-object v2, v2, Lf1/k;->b:Ljava/util/List;
    .line 286: invoke-interface {v2}, Ljava/util/List;->size()I
    .line 289: move-result v2
    .line 290: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 293: move-result v3
    .line 294: sub-int/2addr v2, v3
    .line 295: new-instance v3, Ljava/util/ArrayList;
    .line 297: invoke-direct {v3, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 300: const/4 v4, 0
    .line 301: if-ge v4, v2, :cond_309
    .line 303: invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 306: add-int/lit8 v4, v4, 1
    .line 308: goto :goto_301
    .line 309: invoke-static {v3, v1}, Lt2/p;->U1(Ljava/util/List;Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 312: move-result-object v1
    .line 313: iput-object v1, v0, Lf1/i;->g:Ljava/util/ArrayList;
    .line 315: return-void
    .line 316: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 318: const-string v2, "Setting Constraints.minWidth and Constraints.minHeight is not supported, these should be the default zero values instead."
    .line 320: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 323: move-result-object v2
    .line 324: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 327: throw v1
.end method

# direct methods
.method public static a(Lf1/i;Lk0/o;JLk0/k0;Lq1/m;Lm0/h;)V
    .registers 21

    .line 0: move-object v8, v15
    .line 1: const/4 v9, 3
    .line 2: invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: const-string v0, "canvas"
    .line 7: invoke-static {v15, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-interface {v15}, Lk0/o;->k()V
    .line 13: move-object v0, v14
    .line 14: iget-object v10, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 16: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    .line 19: move-result v11
    .line 20: const/4 v0, 0
    .line 21: move v12, v0
    .line 22: if-ge v12, v11, :cond_59
    .line 24: invoke-virtual {v10, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 27: move-result-object v0
    .line 28: move-object v13, v0
    .line 29: check-cast v13, Lf1/l;
    .line 31: iget-object v0, v13, Lf1/l;->a:Lf1/a;
    .line 33: move-object v1, v15
    .line 34: move-wide/from16 v2, v16
    .line 36: move-object/from16 v4, v18
    .line 38: move-object/from16 v5, v19
    .line 40: move-object/from16 v6, v20
    .line 42: move v7, v9
    .line 43: invoke-virtual/range {v0 .. v7}, Lf1/a;->e(Lk0/o;JLk0/k0;Lq1/m;Lm0/h;I)V
    .line 46: iget-object v0, v13, Lf1/l;->a:Lf1/a;
    .line 48: invoke-virtual {v0}, Lf1/a;->b()F
    .line 51: move-result v0
    .line 52: const/4 v1, 0
    .line 53: invoke-interface {v15, v1, v0}, Lk0/o;->r(FF)V
    .line 56: add-int/lit8 v12, v12, 1
    .line 58: goto :goto_22
    .line 59: invoke-interface {v15}, Lk0/o;->b()V
    .line 62: return-void
.end method

# direct methods
.method public static b(Lf1/i;Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;)V
    .registers 23

    .line 0: move-object/from16 v8, v17
    .line 2: move-object/from16 v2, v18
    .line 4: const/4 v9, 3
    .line 5: invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 8: const-string v0, "canvas"
    .line 10: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: invoke-interface/range {v17 .. v17}, Lk0/o;->k()V
    .line 16: move-object/from16 v0, v16
    .line 18: iget-object v10, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 20: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    .line 23: move-result v1
    .line 24: const/4 v3, 1
    .line 25: if-gt v1, v3, :cond_47
    .line 27: move-object/from16 v0, v16
    .line 29: move-object/from16 v1, v17
    .line 31: move-object/from16 v2, v18
    .line 33: move/from16 v3, v19
    .line 35: move-object/from16 v4, v20
    .line 37: move-object/from16 v5, v21
    .line 39: move-object/from16 v6, v22
    .line 41: move v7, v9
    .line 42: invoke-static/range {v0 .. v7}, Ld2/b;->Y(Lf1/i;Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;I)V
    .line 45: goto/16 :goto_190
    .line 47: instance-of v1, v2, Lk0/o0;
    .line 49: if-eqz v1, :cond_71
    .line 51: move-object/from16 v0, v16
    .line 53: move-object/from16 v1, v17
    .line 55: move-object/from16 v2, v18
    .line 57: move/from16 v3, v19
    .line 59: move-object/from16 v4, v20
    .line 61: move-object/from16 v5, v21
    .line 63: move-object/from16 v6, v22
    .line 65: move v7, v9
    .line 66: invoke-static/range {v0 .. v7}, Ld2/b;->Y(Lf1/i;Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;I)V
    .line 69: goto/16 :goto_190
    .line 71: instance-of v0, v2, Lk0/j0;
    .line 73: if-eqz v0, :cond_190
    .line 75: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    .line 78: move-result v0
    .line 79: const/4 v1, 0
    .line 80: move v3, v1
    .line 81: const/4 v4, 0
    .line 82: const/4 v5, 0
    .line 83: if-ge v3, v0, :cond_111
    .line 85: invoke-virtual {v10, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 88: move-result-object v6
    .line 89: check-cast v6, Lf1/l;
    .line 91: iget-object v7, v6, Lf1/l;->a:Lf1/a;
    .line 93: invoke-virtual {v7}, Lf1/a;->b()F
    .line 96: move-result v7
    .line 97: add-float/2addr v5, v7
    .line 98: iget-object v6, v6, Lf1/l;->a:Lf1/a;
    .line 100: invoke-virtual {v6}, Lf1/a;->c()F
    .line 103: move-result v6
    .line 104: invoke-static {v4, v6}, Ljava/lang/Math;->max(FF)F
    .line 107: move-result v4
    .line 108: add-int/lit8 v3, v3, 1
    .line 110: goto :goto_83
    .line 111: move-object v0, v2
    .line 112: check-cast v0, Lk0/j0;
    .line 114: invoke-static {v4, v5}, Ld2/c;->f(FF)J
    .line 117: move-result-wide v2
    .line 118: invoke-virtual {v0, v2, v3}, Lk0/j0;->b(J)Landroid/graphics/Shader;
    .line 121: move-result-object v12
    .line 122: new-instance v13, Landroid/graphics/Matrix;
    .line 124: invoke-direct {v13}, Landroid/graphics/Matrix;-><init>()V
    .line 127: invoke-virtual {v12, v13}, Landroid/graphics/Shader;->getLocalMatrix(Landroid/graphics/Matrix;)Z
    .line 130: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    .line 133: move-result v14
    .line 134: move v15, v1
    .line 135: if-ge v15, v14, :cond_190
    .line 137: invoke-virtual {v10, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 140: move-result-object v0
    .line 141: move-object v7, v0
    .line 142: check-cast v7, Lf1/l;
    .line 144: iget-object v0, v7, Lf1/l;->a:Lf1/a;
    .line 146: new-instance v2, Lk0/n;
    .line 148: invoke-direct {v2, v12}, Lk0/n;-><init>(Landroid/graphics/Shader;)V
    .line 151: move-object/from16 v1, v17
    .line 153: move/from16 v3, v19
    .line 155: move-object/from16 v4, v20
    .line 157: move-object/from16 v5, v21
    .line 159: move-object/from16 v6, v22
    .line 161: move-object v11, v7
    .line 162: move v7, v9
    .line 163: invoke-virtual/range {v0 .. v7}, Lf1/a;->f(Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;I)V
    .line 166: iget-object v0, v11, Lf1/l;->a:Lf1/a;
    .line 168: invoke-virtual {v0}, Lf1/a;->b()F
    .line 171: move-result v1
    .line 172: const/4 v2, 0
    .line 173: invoke-interface {v8, v2, v1}, Lk0/o;->r(FF)V
    .line 176: invoke-virtual {v0}, Lf1/a;->b()F
    .line 179: move-result v0
    .line 180: neg-float v0, v0
    .line 181: invoke-virtual {v13, v2, v0}, Landroid/graphics/Matrix;->setTranslate(FF)V
    .line 184: invoke-virtual {v12, v13}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V
    .line 187: add-int/lit8 v15, v15, 1
    .line 189: goto :goto_135
    .line 190: invoke-interface/range {v17 .. v17}, Lk0/o;->b()V
    .line 193: return-void
.end method

# virtual methods
.method public final c(I)V
    .registers 5

    .line 0: iget-object v0, v3, Lf1/i;->a:Lf1/k;
    .line 2: if-ltz v4, :cond_15
    .line 4: iget-object v1, v0, Lf1/k;->a:Lf1/e;
    .line 6: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 8: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 11: move-result v1
    .line 12: if-gt v4, v1, :cond_15
    .line 14: return-void
    .line 15: new-instance v1, Ljava/lang/StringBuilder;
    .line 17: const-string v2, "offset("
    .line 19: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 22: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 25: const-string v4, ") is out of bounds [0, "
    .line 27: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: iget-object v4, v0, Lf1/k;->a:Lf1/e;
    .line 32: iget-object v4, v4, Lf1/e;->a:Ljava/lang/String;
    .line 34: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 37: move-result v4
    .line 38: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 41: const/16 v4, 93
    .line 43: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 46: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 49: move-result-object v4
    .line 50: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 52: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 55: move-result-object v4
    .line 56: invoke-direct {v0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 59: throw v0
.end method

# virtual methods
.method public final d(I)V
    .registers 5

    .line 0: iget v0, v3, Lf1/i;->f:I
    .line 2: if-ltz v4, :cond_7
    .line 4: if-ge v4, v0, :cond_7
    .line 6: return-void
    .line 7: new-instance v1, Ljava/lang/StringBuilder;
    .line 9: const-string v2, "lineIndex("
    .line 11: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 14: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 17: const-string v4, ") is out of bounds [0, "
    .line 19: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 25: const/16 v4, 41
    .line 27: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 33: move-result-object v4
    .line 34: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 36: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 39: move-result-object v4
    .line 40: invoke-direct {v0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 43: throw v0
.end method

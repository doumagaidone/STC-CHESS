.class public final Lf1/b0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final d:Lf1/b0;

.field public final a:Lf1/w;
.field public final b:Lf1/o;
.field public final c:Lf1/s;

# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 0: new-instance v0, Lf1/b0;
    .line 2: const/4 v1, 0
    .line 3: const v2, 0xffffff
    .line 6: const-wide/16 v3, 0
    .line 8: invoke-direct {v0, v3, v4, v1, v2}, Lf1/b0;-><init>(JLk1/w;I)V
    .line 11: sput-object v0, Lf1/b0;->d:Lf1/b0;
    .line 13: return-void
.end method

# direct methods
.method public constructor <init>(JJLk1/e0;Lk1/a0;Lk1/s;JLq1/m;Lq1/l;JI)V
    .registers 45

    .line 0: move/from16 v0, v44
    .line 2: and-int/lit8 v1, v0, 1
    .line 4: if-eqz v1, :cond_10
    .line 6: sget-wide v1, Lk0/q;->g:J
    .line 8: move-wide v4, v1
    .line 9: goto :goto_12
    .line 10: move-wide/from16 v4, v31
    .line 12: and-int/lit8 v1, v0, 2
    .line 14: if-eqz v1, :cond_20
    .line 16: sget-wide v1, Lr1/k;->c:J
    .line 18: move-wide v6, v1
    .line 19: goto :goto_22
    .line 20: move-wide/from16 v6, v33
    .line 22: and-int/lit8 v1, v0, 4
    .line 24: const/4 v2, 0
    .line 25: if-eqz v1, :cond_29
    .line 27: move-object v8, v2
    .line 28: goto :goto_31
    .line 29: move-object/from16 v8, v35
    .line 31: and-int/lit8 v1, v0, 8
    .line 33: if-eqz v1, :cond_37
    .line 35: move-object v9, v2
    .line 36: goto :goto_39
    .line 37: move-object/from16 v9, v36
    .line 39: const/4 v10, 0
    .line 40: and-int/lit8 v1, v0, 32
    .line 42: if-eqz v1, :cond_46
    .line 44: move-object v11, v2
    .line 45: goto :goto_48
    .line 46: move-object/from16 v11, v37
    .line 48: const/4 v12, 0
    .line 49: and-int/lit16 v1, v0, 128
    .line 51: if-eqz v1, :cond_56
    .line 53: sget-wide v13, Lr1/k;->c:J
    .line 55: goto :goto_58
    .line 56: move-wide/from16 v13, v38
    .line 58: const/4 v15, 0
    .line 59: const/16 v16, 0
    .line 61: const/16 v17, 0
    .line 63: and-int/lit16 v1, v0, 2048
    .line 65: if-eqz v1, :cond_70
    .line 67: sget-wide v18, Lk0/q;->g:J
    .line 69: goto :goto_72
    .line 70: const-wide/16 v18, 0
    .line 72: and-int/lit16 v1, v0, 4096
    .line 74: if-eqz v1, :cond_79
    .line 76: move-object/from16 v20, v2
    .line 78: goto :goto_81
    .line 79: move-object/from16 v20, v40
    .line 81: const/16 v21, 0
    .line 83: and-int/lit16 v1, v0, 16384
    .line 85: if-eqz v1, :cond_89
    .line 87: move-object v1, v2
    .line 88: goto :goto_91
    .line 89: move-object/from16 v1, v41
    .line 91: const/16 v24, 0
    .line 93: const/high16 v3, 0x1
    .line 95: and-int/2addr v0, v3
    .line 96: if-eqz v0, :cond_103
    .line 98: sget-wide v22, Lr1/k;->c:J
    .line 100: move-wide/from16 v25, v22
    .line 102: goto :goto_105
    .line 103: move-wide/from16 v25, v42
    .line 105: const/4 v0, 0
    .line 106: const/16 v27, 0
    .line 108: const/16 v28, 0
    .line 110: const/16 v29, 0
    .line 112: new-instance v3, Lf1/w;
    .line 114: const/16 v22, 0
    .line 116: const v23, 0x8000
    .line 119: move-object/from16 v42, v3
    .line 121: invoke-direct/range {v3 .. v23}, Lf1/w;-><init>(JJLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;I)V
    .line 124: new-instance v3, Lf1/o;
    .line 126: const/4 v4, 0
    .line 127: const/16 v5, 256
    .line 129: move-object/from16 v31, v3
    .line 131: move-object/from16 v32, v1
    .line 133: move-object/from16 v33, v24
    .line 135: move-wide/from16 v34, v25
    .line 137: move-object/from16 v36, v0
    .line 139: move-object/from16 v37, v4
    .line 141: move-object/from16 v38, v27
    .line 143: move-object/from16 v39, v28
    .line 145: move-object/from16 v40, v29
    .line 147: move/from16 v41, v5
    .line 149: invoke-direct/range {v31 .. v41}, Lf1/o;-><init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;I)V
    .line 152: move-object/from16 v0, v30
    .line 154: move-object/from16 v1, v42
    .line 156: invoke-direct {v0, v1, v3, v2}, Lf1/b0;-><init>(Lf1/w;Lf1/o;Lf1/s;)V
    .line 159: return-void
.end method

# direct methods
.method public constructor <init>(JLk1/w;I)V
    .registers 43

    .line 0: move/from16 v0, v42
    .line 2: and-int/lit8 v1, v0, 1
    .line 4: const-wide/16 v2, 0
    .line 6: if-eqz v1, :cond_12
    .line 8: sget-wide v4, Lk0/q;->g:J
    .line 10: move-wide v7, v4
    .line 11: goto :goto_13
    .line 12: move-wide v7, v2
    .line 13: and-int/lit8 v1, v0, 2
    .line 15: if-eqz v1, :cond_21
    .line 17: sget-wide v4, Lr1/k;->c:J
    .line 19: move-wide v9, v4
    .line 20: goto :goto_23
    .line 21: move-wide/from16 v9, v39
    .line 23: const/4 v11, 0
    .line 24: const/4 v12, 0
    .line 25: const/4 v13, 0
    .line 26: and-int/lit8 v1, v0, 32
    .line 28: const/4 v4, 0
    .line 29: if-eqz v1, :cond_33
    .line 31: move-object v14, v4
    .line 32: goto :goto_35
    .line 33: move-object/from16 v14, v41
    .line 35: const/4 v15, 0
    .line 36: and-int/lit16 v1, v0, 128
    .line 38: if-eqz v1, :cond_45
    .line 40: sget-wide v5, Lr1/k;->c:J
    .line 42: move-wide/from16 v16, v5
    .line 44: goto :goto_47
    .line 45: move-wide/from16 v16, v2
    .line 47: const/16 v18, 0
    .line 49: const/16 v19, 0
    .line 51: const/16 v20, 0
    .line 53: and-int/lit16 v1, v0, 2048
    .line 55: if-eqz v1, :cond_62
    .line 57: sget-wide v5, Lk0/q;->g:J
    .line 59: move-wide/from16 v21, v5
    .line 61: goto :goto_64
    .line 62: move-wide/from16 v21, v2
    .line 64: const/16 v23, 0
    .line 66: const/16 v24, 0
    .line 68: const/16 v26, 0
    .line 70: const/16 v28, 0
    .line 72: const/16 v29, 0
    .line 74: const/high16 v1, 0x2
    .line 76: and-int/2addr v0, v1
    .line 77: if-eqz v0, :cond_81
    .line 79: sget-wide v2, Lr1/k;->c:J
    .line 81: move-wide/from16 v30, v2
    .line 83: const/16 v32, 0
    .line 85: const/16 v34, 0
    .line 87: const/16 v35, 0
    .line 89: const/16 v36, 0
    .line 91: const/16 v37, 0
    .line 93: new-instance v0, Lf1/w;
    .line 95: const/16 v25, 0
    .line 97: move-object v6, v0
    .line 98: invoke-direct/range {v6 .. v26}, Lf1/w;-><init>(JJLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .line 101: new-instance v1, Lf1/o;
    .line 103: const/16 v33, 0
    .line 105: move-object/from16 v27, v1
    .line 107: invoke-direct/range {v27 .. v37}, Lf1/o;-><init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;Lq1/t;)V
    .line 110: move-object/from16 v2, v38
    .line 112: invoke-direct {v2, v0, v1, v4}, Lf1/b0;-><init>(Lf1/w;Lf1/o;Lf1/s;)V
    .line 115: return-void
.end method

# direct methods
.method public constructor <init>(Lf1/w;Lf1/o;)V
    .registers 6

    .line 0: const-string v0, "spanStyle"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v4, Lf1/w;->o:Lf1/r;
    .line 7: iget-object v1, v5, Lf1/o;->e:Lf1/q;
    .line 9: if-nez v0, :cond_15
    .line 11: if-nez v1, :cond_15
    .line 13: const/4 v0, 0
    .line 14: goto :goto_21
    .line 15: new-instance v2, Lf1/s;
    .line 17: invoke-direct {v2, v0, v1}, Lf1/s;-><init>(Lf1/r;Lf1/q;)V
    .line 20: move-object v0, v2
    .line 21: invoke-direct {v3, v4, v5, v0}, Lf1/b0;-><init>(Lf1/w;Lf1/o;Lf1/s;)V
    .line 24: return-void
.end method

# direct methods
.method public constructor <init>(Lf1/w;Lf1/o;Lf1/s;)V
    .registers 5

    .line 0: const-string v0, "spanStyle"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lf1/b0;->a:Lf1/w;
    .line 10: iput-object v3, v1, Lf1/b0;->b:Lf1/o;
    .line 12: iput-object v4, v1, Lf1/b0;->c:Lf1/s;
    .line 14: return-void
.end method

# direct methods
.method public static a(Lf1/b0;JJLk1/e0;Lk1/f0;JJLf1/s;I)Lf1/b0;
    .registers 45

    .line 0: move-object/from16 v0, v32
    .line 2: move/from16 v1, v44
    .line 4: and-int/lit8 v2, v1, 1
    .line 6: if-eqz v2, :cond_17
    .line 8: iget-object v2, v0, Lf1/b0;->a:Lf1/w;
    .line 10: iget-object v2, v2, Lf1/w;->a:Lq1/q;
    .line 12: invoke-interface {v2}, Lq1/q;->b()J
    .line 15: move-result-wide v2
    .line 16: goto :goto_19
    .line 17: move-wide/from16 v2, v33
    .line 19: and-int/lit8 v4, v1, 2
    .line 21: if-eqz v4, :cond_29
    .line 23: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 25: iget-wide v4, v4, Lf1/w;->b:J
    .line 27: move-wide v8, v4
    .line 28: goto :goto_31
    .line 29: move-wide/from16 v8, v35
    .line 31: and-int/lit8 v4, v1, 4
    .line 33: if-eqz v4, :cond_41
    .line 35: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 37: iget-object v4, v4, Lf1/w;->c:Lk1/e0;
    .line 39: move-object v10, v4
    .line 40: goto :goto_43
    .line 41: move-object/from16 v10, v37
    .line 43: and-int/lit8 v4, v1, 8
    .line 45: if-eqz v4, :cond_53
    .line 47: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 49: iget-object v4, v4, Lf1/w;->d:Lk1/a0;
    .line 51: move-object v11, v4
    .line 52: goto :goto_54
    .line 53: const/4 v11, 0
    .line 54: and-int/lit8 v4, v1, 16
    .line 56: if-eqz v4, :cond_64
    .line 58: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 60: iget-object v4, v4, Lf1/w;->e:Lk1/b0;
    .line 62: move-object v12, v4
    .line 63: goto :goto_65
    .line 64: const/4 v12, 0
    .line 65: and-int/lit8 v4, v1, 32
    .line 67: if-eqz v4, :cond_75
    .line 69: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 71: iget-object v4, v4, Lf1/w;->f:Lk1/s;
    .line 73: move-object v13, v4
    .line 74: goto :goto_77
    .line 75: move-object/from16 v13, v38
    .line 77: and-int/lit8 v4, v1, 64
    .line 79: if-eqz v4, :cond_87
    .line 81: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 83: iget-object v4, v4, Lf1/w;->g:Ljava/lang/String;
    .line 85: move-object v14, v4
    .line 86: goto :goto_88
    .line 87: const/4 v14, 0
    .line 88: and-int/lit16 v4, v1, 128
    .line 90: if-eqz v4, :cond_98
    .line 92: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 94: iget-wide v6, v4, Lf1/w;->h:J
    .line 96: move-wide v15, v6
    .line 97: goto :goto_100
    .line 98: move-wide/from16 v15, v39
    .line 100: and-int/lit16 v4, v1, 256
    .line 102: if-eqz v4, :cond_111
    .line 104: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 106: iget-object v4, v4, Lf1/w;->i:Lq1/a;
    .line 108: move-object/from16 v17, v4
    .line 110: goto :goto_113
    .line 111: const/16 v17, 0
    .line 113: and-int/lit16 v4, v1, 512
    .line 115: if-eqz v4, :cond_124
    .line 117: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 119: iget-object v4, v4, Lf1/w;->j:Lq1/r;
    .line 121: move-object/from16 v18, v4
    .line 123: goto :goto_126
    .line 124: const/16 v18, 0
    .line 126: and-int/lit16 v4, v1, 1024
    .line 128: if-eqz v4, :cond_137
    .line 130: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 132: iget-object v4, v4, Lf1/w;->k:Lm1/d;
    .line 134: move-object/from16 v19, v4
    .line 136: goto :goto_139
    .line 137: const/16 v19, 0
    .line 139: and-int/lit16 v4, v1, 2048
    .line 141: if-eqz v4, :cond_150
    .line 143: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 145: iget-wide v6, v4, Lf1/w;->l:J
    .line 147: move-wide/from16 v20, v6
    .line 149: goto :goto_153
    .line 150: const-wide/16 v6, 0
    .line 152: goto :goto_147
    .line 153: and-int/lit16 v4, v1, 4096
    .line 155: if-eqz v4, :cond_164
    .line 157: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 159: iget-object v4, v4, Lf1/w;->m:Lq1/m;
    .line 161: move-object/from16 v22, v4
    .line 163: goto :goto_166
    .line 164: const/16 v22, 0
    .line 166: and-int/lit16 v4, v1, 8192
    .line 168: if-eqz v4, :cond_177
    .line 170: iget-object v4, v0, Lf1/b0;->a:Lf1/w;
    .line 172: iget-object v4, v4, Lf1/w;->n:Lk0/k0;
    .line 174: move-object/from16 v23, v4
    .line 176: goto :goto_179
    .line 177: const/16 v23, 0
    .line 179: and-int/lit16 v4, v1, 16384
    .line 181: if-eqz v4, :cond_188
    .line 183: iget-object v4, v0, Lf1/b0;->b:Lf1/o;
    .line 185: iget-object v4, v4, Lf1/o;->a:Lq1/l;
    .line 187: goto :goto_189
    .line 188: const/4 v4, 0
    .line 189: const v6, 0x8000
    .line 192: and-int/2addr v6, v1
    .line 193: if-eqz v6, :cond_202
    .line 195: iget-object v6, v0, Lf1/b0;->b:Lf1/o;
    .line 197: iget-object v6, v6, Lf1/o;->b:Lq1/n;
    .line 199: move-object/from16 v26, v6
    .line 201: goto :goto_204
    .line 202: const/16 v26, 0
    .line 204: const/high16 v6, 0x1
    .line 206: and-int/2addr v6, v1
    .line 207: if-eqz v6, :cond_216
    .line 209: iget-object v6, v0, Lf1/b0;->b:Lf1/o;
    .line 211: iget-wide v6, v6, Lf1/o;->c:J
    .line 213: move-wide/from16 v27, v6
    .line 215: goto :goto_218
    .line 216: move-wide/from16 v27, v41
    .line 218: const/high16 v6, 0x2
    .line 220: and-int/2addr v6, v1
    .line 221: if-eqz v6, :cond_230
    .line 223: iget-object v6, v0, Lf1/b0;->b:Lf1/o;
    .line 225: iget-object v6, v6, Lf1/o;->d:Lq1/s;
    .line 227: move-object/from16 v29, v6
    .line 229: goto :goto_232
    .line 230: const/16 v29, 0
    .line 232: const/high16 v6, 0x4
    .line 234: and-int/2addr v6, v1
    .line 235: if-eqz v6, :cond_241
    .line 237: iget-object v6, v0, Lf1/b0;->c:Lf1/s;
    .line 239: move-object v7, v6
    .line 240: goto :goto_243
    .line 241: move-object/from16 v7, v43
    .line 243: const/high16 v6, 0x8
    .line 245: and-int/2addr v6, v1
    .line 246: if-eqz v6, :cond_255
    .line 248: iget-object v6, v0, Lf1/b0;->b:Lf1/o;
    .line 250: iget-object v6, v6, Lf1/o;->f:Lq1/j;
    .line 252: move-object/from16 v30, v6
    .line 254: goto :goto_257
    .line 255: const/16 v30, 0
    .line 257: const/high16 v6, 0x10
    .line 259: and-int/2addr v6, v1
    .line 260: if-eqz v6, :cond_269
    .line 262: iget-object v6, v0, Lf1/b0;->b:Lf1/o;
    .line 264: iget-object v6, v6, Lf1/o;->g:Lq1/h;
    .line 266: move-object/from16 v31, v6
    .line 268: goto :goto_271
    .line 269: const/16 v31, 0
    .line 271: const/high16 v6, 0x20
    .line 273: and-int/2addr v1, v6
    .line 274: if-eqz v1, :cond_281
    .line 276: iget-object v1, v0, Lf1/b0;->b:Lf1/o;
    .line 278: iget-object v1, v1, Lf1/o;->h:Lq1/d;
    .line 280: goto :goto_282
    .line 281: const/4 v1, 0
    .line 282: new-instance v6, Lf1/b0;
    .line 284: new-instance v5, Lf1/w;
    .line 286: move-object/from16 v34, v6
    .line 288: iget-object v6, v0, Lf1/b0;->a:Lf1/w;
    .line 290: move-object/from16 v41, v1
    .line 292: iget-object v1, v6, Lf1/w;->a:Lq1/q;
    .line 294: invoke-interface {v1}, Lq1/q;->b()J
    .line 297: move-result-wide v0
    .line 298: invoke-static {v2, v3, v0, v1}, Lk0/q;->d(JJ)Z
    .line 301: move-result v0
    .line 302: if-eqz v0, :cond_307
    .line 304: iget-object v0, v6, Lf1/w;->a:Lq1/q;
    .line 306: goto :goto_321
    .line 307: sget-wide v0, Lk0/q;->g:J
    .line 309: cmp-long v0, v2, v0
    .line 311: if-eqz v0, :cond_319
    .line 313: new-instance v0, Lq1/c;
    .line 315: invoke-direct {v0, v2, v3}, Lq1/c;-><init>(J)V
    .line 318: goto :goto_321
    .line 319: sget-object v0, Lq1/p;->a:Lq1/p;
    .line 321: if-eqz v7, :cond_328
    .line 323: iget-object v1, v7, Lf1/s;->a:Lf1/r;
    .line 325: move-object/from16 v24, v1
    .line 327: goto :goto_330
    .line 328: const/16 v24, 0
    .line 330: iget-object v1, v6, Lf1/w;->p:Lm0/h;
    .line 332: move-object/from16 v2, v34
    .line 334: move-object v6, v5
    .line 335: move-object v3, v7
    .line 336: move-object v7, v0
    .line 337: move-object/from16 v25, v1
    .line 339: invoke-direct/range {v6 .. v25}, Lf1/w;-><init>(Lq1/q;JLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .line 342: new-instance v0, Lf1/o;
    .line 344: if-eqz v3, :cond_351
    .line 346: iget-object v1, v3, Lf1/s;->b:Lf1/q;
    .line 348: move-object/from16 v6, v32
    .line 350: goto :goto_353
    .line 351: const/4 v1, 0
    .line 352: goto :goto_348
    .line 353: iget-object v6, v6, Lf1/b0;->b:Lf1/o;
    .line 355: iget-object v6, v6, Lf1/o;->i:Lq1/t;
    .line 357: move-object/from16 v32, v0
    .line 359: move-object/from16 v33, v4
    .line 361: move-object/from16 v34, v26
    .line 363: move-wide/from16 v35, v27
    .line 365: move-object/from16 v37, v29
    .line 367: move-object/from16 v38, v1
    .line 369: move-object/from16 v39, v30
    .line 371: move-object/from16 v40, v31
    .line 373: move-object/from16 v42, v6
    .line 375: invoke-direct/range {v32 .. v42}, Lf1/o;-><init>(Lq1/l;Lq1/n;JLq1/s;Lf1/q;Lq1/j;Lq1/h;Lq1/d;Lq1/t;)V
    .line 378: invoke-direct {v2, v5, v0, v3}, Lf1/b0;-><init>(Lf1/w;Lf1/o;Lf1/s;)V
    .line 381: return-object v2
.end method

# virtual methods
.method public final b()J
    .registers 3

    .line 0: iget-object v0, v2, Lf1/b0;->a:Lf1/w;
    .line 2: iget-object v0, v0, Lf1/w;->a:Lq1/q;
    .line 4: invoke-interface {v0}, Lq1/q;->b()J
    .line 7: move-result-wide v0
    .line 8: return-wide v0
.end method

# virtual methods
.method public final c(Lf1/b0;)Z
    .registers 4

    .line 0: const-string v0, "other"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: if-eq v2, v3, :cond_30
    .line 7: iget-object v0, v2, Lf1/b0;->b:Lf1/o;
    .line 9: iget-object v1, v3, Lf1/b0;->b:Lf1/o;
    .line 11: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_28
    .line 17: iget-object v0, v2, Lf1/b0;->a:Lf1/w;
    .line 19: iget-object v3, v3, Lf1/b0;->a:Lf1/w;
    .line 21: invoke-virtual {v0, v3}, Lf1/w;->a(Lf1/w;)Z
    .line 24: move-result v3
    .line 25: if-eqz v3, :cond_28
    .line 27: goto :goto_30
    .line 28: const/4 v3, 0
    .line 29: goto :goto_31
    .line 30: const/4 v3, 1
    .line 31: return v3
.end method

# virtual methods
.method public final d(Lf1/b0;)Lf1/b0;
    .registers 5

    .line 0: if-eqz v4, :cond_33
    .line 2: sget-object v0, Lf1/b0;->d:Lf1/b0;
    .line 4: invoke-static {v4, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 7: move-result v0
    .line 8: if-eqz v0, :cond_11
    .line 10: goto :goto_33
    .line 11: new-instance v0, Lf1/b0;
    .line 13: iget-object v1, v3, Lf1/b0;->a:Lf1/w;
    .line 15: iget-object v2, v4, Lf1/b0;->a:Lf1/w;
    .line 17: invoke-virtual {v1, v2}, Lf1/w;->c(Lf1/w;)Lf1/w;
    .line 20: move-result-object v1
    .line 21: iget-object v2, v3, Lf1/b0;->b:Lf1/o;
    .line 23: iget-object v4, v4, Lf1/b0;->b:Lf1/o;
    .line 25: invoke-virtual {v2, v4}, Lf1/o;->a(Lf1/o;)Lf1/o;
    .line 28: move-result-object v4
    .line 29: invoke-direct {v0, v1, v4}, Lf1/b0;-><init>(Lf1/w;Lf1/o;)V
    .line 32: return-object v0
    .line 33: return-object v3
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lf1/b0;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lf1/b0;
    .line 12: iget-object v1, v5, Lf1/b0;->a:Lf1/w;
    .line 14: iget-object v3, v4, Lf1/b0;->a:Lf1/w;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Lf1/b0;->b:Lf1/o;
    .line 25: iget-object v3, v5, Lf1/b0;->b:Lf1/o;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Lf1/b0;->c:Lf1/s;
    .line 36: iget-object v5, v5, Lf1/b0;->c:Lf1/s;
    .line 38: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v5
    .line 42: if-nez v5, :cond_45
    .line 44: return v2
    .line 45: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Lf1/b0;->a:Lf1/w;
    .line 2: invoke-virtual {v0}, Lf1/w;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v2, Lf1/b0;->b:Lf1/o;
    .line 10: invoke-virtual {v1}, Lf1/o;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget-object v0, v2, Lf1/b0;->c:Lf1/s;
    .line 19: if-eqz v0, :cond_26
    .line 21: invoke-virtual {v0}, Lf1/s;->hashCode()I
    .line 24: move-result v0
    .line 25: goto :goto_27
    .line 26: const/4 v0, 0
    .line 27: add-int/2addr v1, v0
    .line 28: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 6

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "TextStyle(color="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: invoke-virtual {v5}, Lf1/b0;->b()J
    .line 10: move-result-wide v1
    .line 11: invoke-static {v1, v2}, Lk0/q;->j(J)Ljava/lang/String;
    .line 14: move-result-object v1
    .line 15: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 18: const-string v1, ", brush="
    .line 20: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 23: iget-object v1, v5, Lf1/b0;->a:Lf1/w;
    .line 25: iget-object v2, v1, Lf1/w;->a:Lq1/q;
    .line 27: invoke-interface {v2}, Lq1/q;->c()Lk0/m;
    .line 30: move-result-object v2
    .line 31: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 34: const-string v2, ", alpha="
    .line 36: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: iget-object v2, v1, Lf1/w;->a:Lq1/q;
    .line 41: invoke-interface {v2}, Lq1/q;->a()F
    .line 44: move-result v2
    .line 45: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 48: const-string v2, ", fontSize="
    .line 50: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 53: iget-wide v2, v1, Lf1/w;->b:J
    .line 55: invoke-static {v2, v3}, Lr1/k;->d(J)Ljava/lang/String;
    .line 58: move-result-object v2
    .line 59: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 62: const-string v2, ", fontWeight="
    .line 64: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget-object v2, v1, Lf1/w;->c:Lk1/e0;
    .line 69: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 72: const-string v2, ", fontStyle="
    .line 74: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: iget-object v2, v1, Lf1/w;->d:Lk1/a0;
    .line 79: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 82: const-string v2, ", fontSynthesis="
    .line 84: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 87: iget-object v2, v1, Lf1/w;->e:Lk1/b0;
    .line 89: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 92: const-string v2, ", fontFamily="
    .line 94: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 97: iget-object v2, v1, Lf1/w;->f:Lk1/s;
    .line 99: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 102: const-string v2, ", fontFeatureSettings="
    .line 104: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 107: iget-object v2, v1, Lf1/w;->g:Ljava/lang/String;
    .line 109: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 112: const-string v2, ", letterSpacing="
    .line 114: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 117: iget-wide v2, v1, Lf1/w;->h:J
    .line 119: invoke-static {v2, v3}, Lr1/k;->d(J)Ljava/lang/String;
    .line 122: move-result-object v2
    .line 123: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 126: const-string v2, ", baselineShift="
    .line 128: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 131: iget-object v2, v1, Lf1/w;->i:Lq1/a;
    .line 133: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 136: const-string v2, ", textGeometricTransform="
    .line 138: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 141: iget-object v2, v1, Lf1/w;->j:Lq1/r;
    .line 143: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 146: const-string v2, ", localeList="
    .line 148: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 151: iget-object v2, v1, Lf1/w;->k:Lm1/d;
    .line 153: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 156: const-string v2, ", background="
    .line 158: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 161: iget-wide v2, v1, Lf1/w;->l:J
    .line 163: const-string v4, ", textDecoration="
    .line 165: invoke-static {v2, v3, v0, v4}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 168: iget-object v2, v1, Lf1/w;->m:Lq1/m;
    .line 170: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 173: const-string v2, ", shadow="
    .line 175: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 178: iget-object v2, v1, Lf1/w;->n:Lk0/k0;
    .line 180: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 183: const-string v2, ", drawStyle="
    .line 185: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 188: iget-object v1, v1, Lf1/w;->p:Lm0/h;
    .line 190: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 193: const-string v1, ", textAlign="
    .line 195: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 198: iget-object v1, v5, Lf1/b0;->b:Lf1/o;
    .line 200: iget-object v2, v1, Lf1/o;->a:Lq1/l;
    .line 202: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 205: const-string v2, ", textDirection="
    .line 207: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 210: iget-object v2, v1, Lf1/o;->b:Lq1/n;
    .line 212: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 215: const-string v2, ", lineHeight="
    .line 217: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 220: iget-wide v2, v1, Lf1/o;->c:J
    .line 222: invoke-static {v2, v3}, Lr1/k;->d(J)Ljava/lang/String;
    .line 225: move-result-object v2
    .line 226: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 229: const-string v2, ", textIndent="
    .line 231: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 234: iget-object v2, v1, Lf1/o;->d:Lq1/s;
    .line 236: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 239: const-string v2, ", platformStyle="
    .line 241: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 244: iget-object v2, v5, Lf1/b0;->c:Lf1/s;
    .line 246: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 249: const-string v2, ", lineHeightStyle="
    .line 251: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 254: iget-object v2, v1, Lf1/o;->f:Lq1/j;
    .line 256: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 259: const-string v2, ", lineBreak="
    .line 261: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 264: iget-object v2, v1, Lf1/o;->g:Lq1/h;
    .line 266: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 269: const-string v2, ", hyphens="
    .line 271: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 274: iget-object v2, v1, Lf1/o;->h:Lq1/d;
    .line 276: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 279: const-string v2, ", textMotion="
    .line 281: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 284: iget-object v1, v1, Lf1/o;->i:Lq1/t;
    .line 286: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 289: const/16 v1, 41
    .line 291: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 294: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 297: move-result-object v0
    .line 298: return-object v0
.end method

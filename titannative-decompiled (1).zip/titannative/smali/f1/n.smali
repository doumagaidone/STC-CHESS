.class public abstract interface Lf1/n;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a()F
.end method

# virtual methods
.method public abstract b()Z
.end method

# virtual methods
.method public abstract c()F
.end method

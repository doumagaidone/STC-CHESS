.class public final Lf1/c;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Appendable;

.field public final a:Ljava/lang/StringBuilder;
.field public final b:Ljava/util/ArrayList;
.field public final c:Ljava/util/ArrayList;
.field public final d:Ljava/util/ArrayList;

# direct methods
.method public constructor <init>(Lf1/e;)V
    .registers 4

    .line 0: const-string v0, "text"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 8: new-instance v0, Ljava/lang/StringBuilder;
    .line 10: const/16 v1, 16
    .line 12: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    .line 15: iput-object v0, v2, Lf1/c;->a:Ljava/lang/StringBuilder;
    .line 17: new-instance v0, Ljava/util/ArrayList;
    .line 19: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 22: iput-object v0, v2, Lf1/c;->b:Ljava/util/ArrayList;
    .line 24: new-instance v0, Ljava/util/ArrayList;
    .line 26: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 29: iput-object v0, v2, Lf1/c;->c:Ljava/util/ArrayList;
    .line 31: new-instance v0, Ljava/util/ArrayList;
    .line 33: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 36: iput-object v0, v2, Lf1/c;->d:Ljava/util/ArrayList;
    .line 38: new-instance v0, Ljava/util/ArrayList;
    .line 40: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 43: invoke-virtual {v2, v3}, Lf1/c;->b(Lf1/e;)V
    .line 46: return-void
.end method

# virtual methods
.method public final a(Lf1/w;II)V
    .registers 6

    .line 0: const-string v0, "style"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v2, Lf1/c;->b:Ljava/util/ArrayList;
    .line 7: new-instance v1, Lf1/b;
    .line 9: invoke-direct {v1, v3, v4, v5}, Lf1/b;-><init>(Ljava/lang/Object;II)V
    .line 12: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 15: return-void
.end method

# virtual methods
.method public final append(C)Ljava/lang/Appendable;
    .registers 3

    .line 0: iget-object v0, v1, Lf1/c;->a:Ljava/lang/StringBuilder;
    .line 2: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 5: return-object v1
.end method

# virtual methods
.method public final append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .registers 3

    .line 0: instance-of v0, v2, Lf1/e;
    .line 2: if-eqz v0, :cond_10
    .line 4: check-cast v2, Lf1/e;
    .line 6: invoke-virtual {v1, v2}, Lf1/c;->b(Lf1/e;)V
    .line 9: goto :goto_15
    .line 10: iget-object v0, v1, Lf1/c;->a:Ljava/lang/StringBuilder;
    .line 12: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 15: return-object v1
.end method

# virtual methods
.method public final append(Ljava/lang/CharSequence;II)Ljava/lang/Appendable;
    .registers 16

    .line 0: instance-of v0, v13, Lf1/e;
    .line 2: iget-object v1, v12, Lf1/c;->a:Ljava/lang/StringBuilder;
    .line 4: if-eqz v0, :cond_354
    .line 6: check-cast v13, Lf1/e;
    .line 8: const-string v0, "text"
    .line 10: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I
    .line 16: move-result v0
    .line 17: iget-object v2, v13, Lf1/e;->a:Ljava/lang/String;
    .line 19: invoke-virtual {v1, v2, v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;
    .line 22: invoke-static {v13, v14, v15}, Lf1/f;->b(Lf1/e;II)Ljava/util/List;
    .line 25: move-result-object v1
    .line 26: const/4 v3, 0
    .line 27: if-eqz v1, :cond_58
    .line 29: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 32: move-result v4
    .line 33: move v5, v3
    .line 34: if-ge v5, v4, :cond_58
    .line 36: invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 39: move-result-object v6
    .line 40: check-cast v6, Lf1/d;
    .line 42: iget-object v7, v6, Lf1/d;->a:Ljava/lang/Object;
    .line 44: check-cast v7, Lf1/w;
    .line 46: iget v8, v6, Lf1/d;->b:I
    .line 48: add-int/2addr v8, v0
    .line 49: iget v6, v6, Lf1/d;->c:I
    .line 51: add-int/2addr v6, v0
    .line 52: invoke-virtual {v12, v7, v8, v6}, Lf1/c;->a(Lf1/w;II)V
    .line 55: add-int/lit8 v5, v5, 1
    .line 57: goto :goto_34
    .line 58: const/4 v1, 0
    .line 59: if-ne v14, v15, :cond_63
    .line 61: move-object v4, v1
    .line 62: goto :goto_165
    .line 63: iget-object v4, v13, Lf1/e;->c:Ljava/util/List;
    .line 65: if-nez v4, :cond_68
    .line 67: goto :goto_61
    .line 68: if-nez v14, :cond_77
    .line 70: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 73: move-result v5
    .line 74: if-lt v15, v5, :cond_77
    .line 76: goto :goto_165
    .line 77: new-instance v5, Ljava/util/ArrayList;
    .line 79: invoke-interface {v4}, Ljava/util/List;->size()I
    .line 82: move-result v6
    .line 83: invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V
    .line 86: invoke-interface {v4}, Ljava/util/List;->size()I
    .line 89: move-result v6
    .line 90: move v7, v3
    .line 91: if-ge v7, v6, :cond_116
    .line 93: invoke-interface {v4, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 96: move-result-object v8
    .line 97: move-object v9, v8
    .line 98: check-cast v9, Lf1/d;
    .line 100: iget v10, v9, Lf1/d;->b:I
    .line 102: iget v9, v9, Lf1/d;->c:I
    .line 104: invoke-static {v14, v15, v10, v9}, Lf1/f;->c(IIII)Z
    .line 107: move-result v9
    .line 108: if-eqz v9, :cond_113
    .line 110: invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 113: add-int/lit8 v7, v7, 1
    .line 115: goto :goto_91
    .line 116: new-instance v4, Ljava/util/ArrayList;
    .line 118: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 121: move-result v6
    .line 122: invoke-direct {v4, v6}, Ljava/util/ArrayList;-><init>(I)V
    .line 125: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 128: move-result v6
    .line 129: move v7, v3
    .line 130: if-ge v7, v6, :cond_165
    .line 132: invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 135: move-result-object v8
    .line 136: check-cast v8, Lf1/d;
    .line 138: new-instance v9, Lf1/d;
    .line 140: iget-object v10, v8, Lf1/d;->a:Ljava/lang/Object;
    .line 142: iget v11, v8, Lf1/d;->b:I
    .line 144: invoke-static {v11, v14, v15}, Ld2/b;->G(III)I
    .line 147: move-result v11
    .line 148: sub-int/2addr v11, v14
    .line 149: iget v8, v8, Lf1/d;->c:I
    .line 151: invoke-static {v8, v14, v15}, Ld2/b;->G(III)I
    .line 154: move-result v8
    .line 155: sub-int/2addr v8, v14
    .line 156: invoke-direct {v9, v11, v8, v10}, Lf1/d;-><init>(IILjava/lang/Object;)V
    .line 159: invoke-virtual {v4, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 162: add-int/lit8 v7, v7, 1
    .line 164: goto :goto_130
    .line 165: if-eqz v4, :cond_208
    .line 167: invoke-interface {v4}, Ljava/util/List;->size()I
    .line 170: move-result v5
    .line 171: move v6, v3
    .line 172: if-ge v6, v5, :cond_208
    .line 174: invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 177: move-result-object v7
    .line 178: check-cast v7, Lf1/d;
    .line 180: iget-object v8, v7, Lf1/d;->a:Ljava/lang/Object;
    .line 182: check-cast v8, Lf1/o;
    .line 184: iget v9, v7, Lf1/d;->b:I
    .line 186: add-int/2addr v9, v0
    .line 187: iget v7, v7, Lf1/d;->c:I
    .line 189: add-int/2addr v7, v0
    .line 190: const-string v10, "style"
    .line 192: invoke-static {v8, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 195: iget-object v10, v12, Lf1/c;->c:Ljava/util/ArrayList;
    .line 197: new-instance v11, Lf1/b;
    .line 199: invoke-direct {v11, v8, v9, v7}, Lf1/b;-><init>(Ljava/lang/Object;II)V
    .line 202: invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 205: add-int/lit8 v6, v6, 1
    .line 207: goto :goto_172
    .line 208: if-ne v14, v15, :cond_212
    .line 210: goto/16 :goto_317
    .line 212: iget-object v13, v13, Lf1/e;->d:Ljava/util/List;
    .line 214: if-nez v13, :cond_217
    .line 216: goto :goto_317
    .line 217: if-nez v14, :cond_227
    .line 219: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 222: move-result v1
    .line 223: if-lt v15, v1, :cond_227
    .line 225: move-object v1, v13
    .line 226: goto :goto_317
    .line 227: new-instance v1, Ljava/util/ArrayList;
    .line 229: invoke-interface {v13}, Ljava/util/List;->size()I
    .line 232: move-result v2
    .line 233: invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 236: invoke-interface {v13}, Ljava/util/List;->size()I
    .line 239: move-result v2
    .line 240: move v4, v3
    .line 241: if-ge v4, v2, :cond_266
    .line 243: invoke-interface {v13, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 246: move-result-object v5
    .line 247: move-object v6, v5
    .line 248: check-cast v6, Lf1/d;
    .line 250: iget v7, v6, Lf1/d;->b:I
    .line 252: iget v6, v6, Lf1/d;->c:I
    .line 254: invoke-static {v14, v15, v7, v6}, Lf1/f;->c(IIII)Z
    .line 257: move-result v6
    .line 258: if-eqz v6, :cond_263
    .line 260: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 263: add-int/lit8 v4, v4, 1
    .line 265: goto :goto_241
    .line 266: new-instance v13, Ljava/util/ArrayList;
    .line 268: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 271: move-result v2
    .line 272: invoke-direct {v13, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 275: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 278: move-result v2
    .line 279: move v4, v3
    .line 280: if-ge v4, v2, :cond_225
    .line 282: invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 285: move-result-object v5
    .line 286: check-cast v5, Lf1/d;
    .line 288: iget-object v6, v5, Lf1/d;->d:Ljava/lang/String;
    .line 290: iget v7, v5, Lf1/d;->b:I
    .line 292: invoke-static {v7, v14, v15}, Ld2/b;->G(III)I
    .line 295: move-result v7
    .line 296: sub-int/2addr v7, v14
    .line 297: iget v8, v5, Lf1/d;->c:I
    .line 299: invoke-static {v8, v14, v15}, Ld2/b;->G(III)I
    .line 302: move-result v8
    .line 303: sub-int/2addr v8, v14
    .line 304: new-instance v9, Lf1/d;
    .line 306: iget-object v5, v5, Lf1/d;->a:Ljava/lang/Object;
    .line 308: invoke-direct {v9, v5, v7, v8, v6}, Lf1/d;-><init>(Ljava/lang/Object;IILjava/lang/String;)V
    .line 311: invoke-virtual {v13, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 314: add-int/lit8 v4, v4, 1
    .line 316: goto :goto_280
    .line 317: if-eqz v1, :cond_357
    .line 319: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 322: move-result v13
    .line 323: if-ge v3, v13, :cond_357
    .line 325: invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 328: move-result-object v14
    .line 329: check-cast v14, Lf1/d;
    .line 331: iget-object v15, v12, Lf1/c;->d:Ljava/util/ArrayList;
    .line 333: new-instance v2, Lf1/b;
    .line 335: iget-object v4, v14, Lf1/d;->a:Ljava/lang/Object;
    .line 337: iget v5, v14, Lf1/d;->b:I
    .line 339: add-int/2addr v5, v0
    .line 340: iget v6, v14, Lf1/d;->c:I
    .line 342: add-int/2addr v6, v0
    .line 343: iget-object v14, v14, Lf1/d;->d:Ljava/lang/String;
    .line 345: invoke-direct {v2, v4, v5, v6, v14}, Lf1/b;-><init>(Ljava/lang/Object;IILjava/lang/String;)V
    .line 348: invoke-virtual {v15, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 351: add-int/lit8 v3, v3, 1
    .line 353: goto :goto_323
    .line 354: invoke-virtual {v1, v13, v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;
    .line 357: return-object v12
.end method

# virtual methods
.method public final b(Lf1/e;)V
    .registers 12

    .line 0: const-string v0, "text"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v10, Lf1/c;->a:Ljava/lang/StringBuilder;
    .line 7: invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I
    .line 10: move-result v1
    .line 11: iget-object v2, v11, Lf1/e;->a:Ljava/lang/String;
    .line 13: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 16: const/4 v0, 0
    .line 17: iget-object v2, v11, Lf1/e;->b:Ljava/util/List;
    .line 19: if-eqz v2, :cond_50
    .line 21: invoke-interface {v2}, Ljava/util/List;->size()I
    .line 24: move-result v3
    .line 25: move v4, v0
    .line 26: if-ge v4, v3, :cond_50
    .line 28: invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v5
    .line 32: check-cast v5, Lf1/d;
    .line 34: iget-object v6, v5, Lf1/d;->a:Ljava/lang/Object;
    .line 36: check-cast v6, Lf1/w;
    .line 38: iget v7, v5, Lf1/d;->b:I
    .line 40: add-int/2addr v7, v1
    .line 41: iget v5, v5, Lf1/d;->c:I
    .line 43: add-int/2addr v5, v1
    .line 44: invoke-virtual {v10, v6, v7, v5}, Lf1/c;->a(Lf1/w;II)V
    .line 47: add-int/lit8 v4, v4, 1
    .line 49: goto :goto_26
    .line 50: iget-object v2, v11, Lf1/e;->c:Ljava/util/List;
    .line 52: if-eqz v2, :cond_95
    .line 54: invoke-interface {v2}, Ljava/util/List;->size()I
    .line 57: move-result v3
    .line 58: move v4, v0
    .line 59: if-ge v4, v3, :cond_95
    .line 61: invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 64: move-result-object v5
    .line 65: check-cast v5, Lf1/d;
    .line 67: iget-object v6, v5, Lf1/d;->a:Ljava/lang/Object;
    .line 69: check-cast v6, Lf1/o;
    .line 71: iget v7, v5, Lf1/d;->b:I
    .line 73: add-int/2addr v7, v1
    .line 74: iget v5, v5, Lf1/d;->c:I
    .line 76: add-int/2addr v5, v1
    .line 77: const-string v8, "style"
    .line 79: invoke-static {v6, v8}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 82: iget-object v8, v10, Lf1/c;->c:Ljava/util/ArrayList;
    .line 84: new-instance v9, Lf1/b;
    .line 86: invoke-direct {v9, v6, v7, v5}, Lf1/b;-><init>(Ljava/lang/Object;II)V
    .line 89: invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 92: add-int/lit8 v4, v4, 1
    .line 94: goto :goto_59
    .line 95: iget-object v11, v11, Lf1/e;->d:Ljava/util/List;
    .line 97: if-eqz v11, :cond_134
    .line 99: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 102: move-result v2
    .line 103: if-ge v0, v2, :cond_134
    .line 105: invoke-interface {v11, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 108: move-result-object v3
    .line 109: check-cast v3, Lf1/d;
    .line 111: iget-object v4, v10, Lf1/c;->d:Ljava/util/ArrayList;
    .line 113: new-instance v5, Lf1/b;
    .line 115: iget-object v6, v3, Lf1/d;->a:Ljava/lang/Object;
    .line 117: iget v7, v3, Lf1/d;->b:I
    .line 119: add-int/2addr v7, v1
    .line 120: iget v8, v3, Lf1/d;->c:I
    .line 122: add-int/2addr v8, v1
    .line 123: iget-object v3, v3, Lf1/d;->d:Ljava/lang/String;
    .line 125: invoke-direct {v5, v6, v7, v8, v3}, Lf1/b;-><init>(Ljava/lang/Object;IILjava/lang/String;)V
    .line 128: invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 131: add-int/lit8 v0, v0, 1
    .line 133: goto :goto_103
    .line 134: return-void
.end method

# virtual methods
.method public final c()Lf1/e;
    .registers 12

    .line 0: iget-object v0, v11, Lf1/c;->a:Ljava/lang/StringBuilder;
    .line 2: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 5: move-result-object v1
    .line 6: const-string v2, "text.toString()"
    .line 8: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: iget-object v2, v11, Lf1/c;->b:Ljava/util/ArrayList;
    .line 13: new-instance v3, Ljava/util/ArrayList;
    .line 15: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 18: move-result v4
    .line 19: invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 22: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 25: move-result v4
    .line 26: const/4 v5, 0
    .line 27: move v6, v5
    .line 28: if-ge v6, v4, :cond_50
    .line 30: invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 33: move-result-object v7
    .line 34: check-cast v7, Lf1/b;
    .line 36: invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I
    .line 39: move-result v8
    .line 40: invoke-virtual {v7, v8}, Lf1/b;->a(I)Lf1/d;
    .line 43: move-result-object v7
    .line 44: invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 47: add-int/lit8 v6, v6, 1
    .line 49: goto :goto_28
    .line 50: invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z
    .line 53: move-result v2
    .line 54: const/4 v4, 0
    .line 55: if-eqz v2, :cond_58
    .line 57: move-object v3, v4
    .line 58: iget-object v2, v11, Lf1/c;->c:Ljava/util/ArrayList;
    .line 60: new-instance v6, Ljava/util/ArrayList;
    .line 62: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 65: move-result v7
    .line 66: invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V
    .line 69: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 72: move-result v7
    .line 73: move v8, v5
    .line 74: if-ge v8, v7, :cond_96
    .line 76: invoke-virtual {v2, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 79: move-result-object v9
    .line 80: check-cast v9, Lf1/b;
    .line 82: invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I
    .line 85: move-result v10
    .line 86: invoke-virtual {v9, v10}, Lf1/b;->a(I)Lf1/d;
    .line 89: move-result-object v9
    .line 90: invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 93: add-int/lit8 v8, v8, 1
    .line 95: goto :goto_74
    .line 96: invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z
    .line 99: move-result v2
    .line 100: if-eqz v2, :cond_103
    .line 102: move-object v6, v4
    .line 103: iget-object v2, v11, Lf1/c;->d:Ljava/util/ArrayList;
    .line 105: new-instance v7, Ljava/util/ArrayList;
    .line 107: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 110: move-result v8
    .line 111: invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V
    .line 114: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 117: move-result v8
    .line 118: if-ge v5, v8, :cond_140
    .line 120: invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 123: move-result-object v9
    .line 124: check-cast v9, Lf1/b;
    .line 126: invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I
    .line 129: move-result v10
    .line 130: invoke-virtual {v9, v10}, Lf1/b;->a(I)Lf1/d;
    .line 133: move-result-object v9
    .line 134: invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 137: add-int/lit8 v5, v5, 1
    .line 139: goto :goto_118
    .line 140: invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z
    .line 143: move-result v0
    .line 144: if-eqz v0, :cond_147
    .line 146: goto :goto_148
    .line 147: move-object v4, v7
    .line 148: new-instance v0, Lf1/e;
    .line 150: invoke-direct {v0, v1, v3, v6, v4}, Lf1/e;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .line 153: return-object v0
.end method

.class public final Lf1/a0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final b:J
.field public static final synthetic c:I

.field public final a:J

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v0, v0}, Ld2/c;->g(II)J
    .line 4: move-result-wide v0
    .line 5: sput-wide v0, Lf1/a0;->b:J
    .line 7: return-void
.end method

# direct methods
.method public synthetic constructor <init>(J)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-wide v1, v0, Lf1/a0;->a:J
    .line 5: return-void
.end method

# direct methods
.method public static final a(JJ)Z
    .registers 4

    .line 0: cmp-long v0, v0, v2
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_7
    .line 6: const/4 v0, 0
    .line 7: return v0
.end method

# direct methods
.method public static final b(J)Z
    .registers 5

    .line 0: const/16 v0, 32
    .line 2: shr-long v0, v3, v0
    .line 4: long-to-int v0, v0
    .line 5: const-wide v1, 0x00ffffffff
    .line 10: and-long/2addr v3, v1
    .line 11: long-to-int v3, v3
    .line 12: if-ne v0, v3, :cond_16
    .line 14: const/4 v3, 1
    .line 15: goto :goto_17
    .line 16: const/4 v3, 0
    .line 17: return v3
.end method

# direct methods
.method public static final c(J)I
    .registers 5

    .line 0: const/16 v0, 32
    .line 2: shr-long v0, v3, v0
    .line 4: long-to-int v0, v0
    .line 5: const-wide v1, 0x00ffffffff
    .line 10: and-long/2addr v3, v1
    .line 11: long-to-int v3, v3
    .line 12: if-le v0, v3, :cond_15
    .line 14: goto :goto_16
    .line 15: move v0, v3
    .line 16: return v0
.end method

# direct methods
.method public static final d(J)I
    .registers 5

    .line 0: const/16 v0, 32
    .line 2: shr-long v0, v3, v0
    .line 4: long-to-int v0, v0
    .line 5: const-wide v1, 0x00ffffffff
    .line 10: and-long/2addr v3, v1
    .line 11: long-to-int v3, v3
    .line 12: if-le v0, v3, :cond_15
    .line 14: move v0, v3
    .line 15: return v0
.end method

# direct methods
.method public static final e(J)Z
    .registers 5

    .line 0: const/16 v0, 32
    .line 2: shr-long v0, v3, v0
    .line 4: long-to-int v0, v0
    .line 5: const-wide v1, 0x00ffffffff
    .line 10: and-long/2addr v3, v1
    .line 11: long-to-int v3, v3
    .line 12: if-le v0, v3, :cond_16
    .line 14: const/4 v3, 1
    .line 15: goto :goto_17
    .line 16: const/4 v3, 0
    .line 17: return v3
.end method

# direct methods
.method public static f(J)Ljava/lang/String;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "TextRange("
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: const/16 v1, 32
    .line 9: shr-long v1, v3, v1
    .line 11: long-to-int v1, v1
    .line 12: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 15: const-string v1, ", "
    .line 17: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 20: const-wide v1, 0x00ffffffff
    .line 25: and-long/2addr v3, v1
    .line 26: long-to-int v3, v3
    .line 27: const/16 v4, 41
    .line 29: invoke-static {v0, v3, v4}, Lai/onnxruntime/b;->j(Ljava/lang/StringBuilder;IC)Ljava/lang/String;
    .line 32: move-result-object v3
    .line 33: return-object v3
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    .line 0: instance-of v0, v7, Lf1/a0;
    .line 2: const/4 v1, 0
    .line 3: if-nez v0, :cond_6
    .line 5: goto :goto_18
    .line 6: check-cast v7, Lf1/a0;
    .line 8: iget-wide v2, v7, Lf1/a0;->a:J
    .line 10: iget-wide v4, v6, Lf1/a0;->a:J
    .line 12: cmp-long v7, v4, v2
    .line 14: if-eqz v7, :cond_17
    .line 16: goto :goto_18
    .line 17: const/4 v1, 1
    .line 18: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-wide v0, v2, Lf1/a0;->a:J
    .line 2: invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: iget-wide v0, v2, Lf1/a0;->a:J
    .line 2: invoke-static {v0, v1}, Lf1/a0;->f(J)Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

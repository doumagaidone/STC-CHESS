.class public final Lf1/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/Object;
.field public final b:I
.field public final c:I
.field public final d:Ljava/lang/String;

# direct methods
.method public constructor <init>(IILjava/lang/Object;)V
    .registers 5

    .line 0: const-string v0, ""
    .line 2: invoke-direct {v1, v4, v2, v3, v0}, Lf1/d;-><init>(Ljava/lang/Object;IILjava/lang/String;)V
    .line 5: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/lang/Object;IILjava/lang/String;)V
    .registers 6

    .line 0: const-string v0, "tag"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lf1/d;->a:Ljava/lang/Object;
    .line 10: iput v3, v1, Lf1/d;->b:I
    .line 12: iput v4, v1, Lf1/d;->c:I
    .line 14: iput-object v5, v1, Lf1/d;->d:Ljava/lang/String;
    .line 16: if-gt v3, v4, :cond_19
    .line 18: return-void
    .line 19: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 21: const-string v3, "Reversed range is not supported"
    .line 23: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 26: move-result-object v3
    .line 27: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 30: throw v2
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lf1/d;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lf1/d;
    .line 12: iget-object v1, v5, Lf1/d;->a:Ljava/lang/Object;
    .line 14: iget-object v3, v4, Lf1/d;->a:Ljava/lang/Object;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lf1/d;->b:I
    .line 25: iget v3, v5, Lf1/d;->b:I
    .line 27: if-eq v1, v3, :cond_30
    .line 29: return v2
    .line 30: iget v1, v4, Lf1/d;->c:I
    .line 32: iget v3, v5, Lf1/d;->c:I
    .line 34: if-eq v1, v3, :cond_37
    .line 36: return v2
    .line 37: iget-object v1, v4, Lf1/d;->d:Ljava/lang/String;
    .line 39: iget-object v5, v5, Lf1/d;->d:Ljava/lang/String;
    .line 41: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 44: move-result v5
    .line 45: if-nez v5, :cond_48
    .line 47: return v2
    .line 48: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lf1/d;->a:Ljava/lang/Object;
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, 0
    .line 5: goto :goto_10
    .line 6: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 9: move-result v0
    .line 10: const/16 v1, 31
    .line 12: mul-int/2addr v0, v1
    .line 13: iget v2, v3, Lf1/d;->b:I
    .line 15: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 18: move-result v0
    .line 19: iget v2, v3, Lf1/d;->c:I
    .line 21: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 24: move-result v0
    .line 25: iget-object v1, v3, Lf1/d;->d:Ljava/lang/String;
    .line 27: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 30: move-result v1
    .line 31: add-int/2addr v1, v0
    .line 32: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Range(item="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lf1/d;->a:Ljava/lang/Object;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", start="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lf1/d;->b:I
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", end="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v2, Lf1/d;->c:I
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", tag="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v2, Lf1/d;->d:Ljava/lang/String;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: const/16 v1, 41
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v0
    .line 51: return-object v0
.end method

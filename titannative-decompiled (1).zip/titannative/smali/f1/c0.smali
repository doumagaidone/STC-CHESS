.class public abstract Lf1/c0;
.super Ljava/lang/Object;
.source "SourceFile"

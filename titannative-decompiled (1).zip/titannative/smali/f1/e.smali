.class public final Lf1/e;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/CharSequence;

.field public final a:Ljava/lang/String;
.field public final b:Ljava/util/List;
.field public final c:Ljava/util/List;
.field public final d:Ljava/util/List;

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/ArrayList;I)V
    .registers 6

    .line 0: and-int/lit8 v0, v5, 2
    .line 2: sget-object v1, Lt2/r;->i:Lt2/r;
    .line 4: if-eqz v0, :cond_7
    .line 6: move-object v4, v1
    .line 7: and-int/lit8 v5, v5, 4
    .line 9: const/4 v0, 0
    .line 10: if-eqz v5, :cond_13
    .line 12: goto :goto_14
    .line 13: move-object v1, v0
    .line 14: const-string v5, "text"
    .line 16: invoke-static {v3, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 19: const-string v5, "spanStyles"
    .line 21: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 24: const-string v5, "paragraphStyles"
    .line 26: invoke-static {v1, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 29: invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z
    .line 32: move-result v5
    .line 33: if-eqz v5, :cond_36
    .line 35: move-object v4, v0
    .line 36: invoke-direct {v2, v3, v4, v0, v0}, Lf1/e;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .line 39: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .registers 7

    .line 0: const-string v0, "text"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v3, v2, Lf1/e;->a:Ljava/lang/String;
    .line 10: iput-object v4, v2, Lf1/e;->b:Ljava/util/List;
    .line 12: iput-object v5, v2, Lf1/e;->c:Ljava/util/List;
    .line 14: iput-object v6, v2, Lf1/e;->d:Ljava/util/List;
    .line 16: if-eqz v5, :cond_111
    .line 18: new-instance v3, Lu/r;
    .line 20: const/4 v4, 2
    .line 21: invoke-direct {v3, v4}, Lu/r;-><init>(I)V
    .line 24: invoke-static {v5, v3}, Lt2/p;->W1(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;
    .line 27: move-result-object v3
    .line 28: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 31: move-result v4
    .line 32: const/4 v5, -1
    .line 33: const/4 v6, 0
    .line 34: if-ge v6, v4, :cond_111
    .line 36: invoke-interface {v3, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 39: move-result-object v0
    .line 40: check-cast v0, Lf1/d;
    .line 42: iget v1, v0, Lf1/d;->b:I
    .line 44: if-lt v1, v5, :cond_99
    .line 46: iget-object v5, v2, Lf1/e;->a:Ljava/lang/String;
    .line 48: invoke-virtual {v5}, Ljava/lang/String;->length()I
    .line 51: move-result v5
    .line 52: iget v1, v0, Lf1/d;->c:I
    .line 54: if-gt v1, v5, :cond_60
    .line 56: add-int/lit8 v6, v6, 1
    .line 58: move v5, v1
    .line 59: goto :goto_34
    .line 60: new-instance v3, Ljava/lang/StringBuilder;
    .line 62: const-string v4, "ParagraphStyle range ["
    .line 64: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 67: iget v4, v0, Lf1/d;->b:I
    .line 69: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 72: const-string v4, ", "
    .line 74: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 80: const-string v4, ") is out of boundary"
    .line 82: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 85: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 88: move-result-object v3
    .line 89: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 91: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 94: move-result-object v3
    .line 95: invoke-direct {v4, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 98: throw v4
    .line 99: new-instance v3, Ljava/lang/IllegalArgumentException;
    .line 101: const-string v4, "ParagraphStyle should not overlap"
    .line 103: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 106: move-result-object v4
    .line 107: invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 110: throw v3
    .line 111: return-void
.end method

# virtual methods
.method public final a(Lf1/e;)Lf1/e;
    .registers 3

    .line 0: new-instance v0, Lf1/c;
    .line 2: invoke-direct {v0, v1}, Lf1/c;-><init>(Lf1/e;)V
    .line 5: invoke-virtual {v0, v2}, Lf1/c;->b(Lf1/e;)V
    .line 8: invoke-virtual {v0}, Lf1/c;->c()Lf1/e;
    .line 11: move-result-object v2
    .line 12: return-object v2
.end method

# virtual methods
.method public final b(II)Lf1/e;
    .registers 8

    .line 0: if-gt v6, v7, :cond_46
    .line 2: iget-object v0, v5, Lf1/e;->a:Ljava/lang/String;
    .line 4: if-nez v6, :cond_13
    .line 6: invoke-virtual {v0}, Ljava/lang/String;->length()I
    .line 9: move-result v1
    .line 10: if-ne v7, v1, :cond_13
    .line 12: return-object v5
    .line 13: invoke-virtual {v0, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 16: move-result-object v0
    .line 17: const-string v1, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 19: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: new-instance v1, Lf1/e;
    .line 24: iget-object v2, v5, Lf1/e;->b:Ljava/util/List;
    .line 26: invoke-static {v6, v7, v2}, Lf1/f;->a(IILjava/util/List;)Ljava/util/ArrayList;
    .line 29: move-result-object v2
    .line 30: iget-object v3, v5, Lf1/e;->c:Ljava/util/List;
    .line 32: invoke-static {v6, v7, v3}, Lf1/f;->a(IILjava/util/List;)Ljava/util/ArrayList;
    .line 35: move-result-object v3
    .line 36: iget-object v4, v5, Lf1/e;->d:Ljava/util/List;
    .line 38: invoke-static {v6, v7, v4}, Lf1/f;->a(IILjava/util/List;)Ljava/util/ArrayList;
    .line 41: move-result-object v6
    .line 42: invoke-direct {v1, v0, v2, v3, v6}, Lf1/e;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .line 45: return-object v1
    .line 46: new-instance v0, Ljava/lang/StringBuilder;
    .line 48: const-string v1, "start ("
    .line 50: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 53: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 56: const-string v6, ") should be less or equal to end ("
    .line 58: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 61: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 64: const/16 v6, 41
    .line 66: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 69: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 72: move-result-object v6
    .line 73: new-instance v7, Ljava/lang/IllegalArgumentException;
    .line 75: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 78: move-result-object v6
    .line 79: invoke-direct {v7, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 82: throw v7
.end method

# virtual methods
.method public final charAt(I)C
    .registers 3

    .line 0: iget-object v0, v1, Lf1/e;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lf1/e;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lf1/e;
    .line 12: iget-object v1, v5, Lf1/e;->a:Ljava/lang/String;
    .line 14: iget-object v3, v4, Lf1/e;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Lf1/e;->b:Ljava/util/List;
    .line 25: iget-object v3, v5, Lf1/e;->b:Ljava/util/List;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Lf1/e;->c:Ljava/util/List;
    .line 36: iget-object v3, v5, Lf1/e;->c:Ljava/util/List;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget-object v1, v4, Lf1/e;->d:Ljava/util/List;
    .line 47: iget-object v5, v5, Lf1/e;->d:Ljava/util/List;
    .line 49: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v5
    .line 53: if-nez v5, :cond_56
    .line 55: return v2
    .line 56: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lf1/e;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: const/4 v1, 0
    .line 9: iget-object v2, v3, Lf1/e;->b:Ljava/util/List;
    .line 11: if-eqz v2, :cond_18
    .line 13: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 16: move-result v2
    .line 17: goto :goto_19
    .line 18: move v2, v1
    .line 19: add-int/2addr v0, v2
    .line 20: mul-int/lit8 v0, v0, 31
    .line 22: iget-object v2, v3, Lf1/e;->c:Ljava/util/List;
    .line 24: if-eqz v2, :cond_31
    .line 26: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 29: move-result v2
    .line 30: goto :goto_32
    .line 31: move v2, v1
    .line 32: add-int/2addr v0, v2
    .line 33: mul-int/lit8 v0, v0, 31
    .line 35: iget-object v2, v3, Lf1/e;->d:Ljava/util/List;
    .line 37: if-eqz v2, :cond_43
    .line 39: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 42: move-result v1
    .line 43: add-int/2addr v0, v1
    .line 44: return v0
.end method

# virtual methods
.method public final length()I
    .registers 2

    .line 0: iget-object v0, v1, Lf1/e;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->length()I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final bridge synthetic subSequence(II)Ljava/lang/CharSequence;
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Lf1/e;->b(II)Lf1/e;
    .line 3: move-result-object v1
    .line 4: return-object v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lf1/e;->a:Ljava/lang/String;
    .line 2: return-object v0
.end method

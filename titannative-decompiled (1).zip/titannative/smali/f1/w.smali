.class public final Lf1/w;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lq1/q;
.field public final b:J
.field public final c:Lk1/e0;
.field public final d:Lk1/a0;
.field public final e:Lk1/b0;
.field public final f:Lk1/s;
.field public final g:Ljava/lang/String;
.field public final h:J
.field public final i:Lq1/a;
.field public final j:Lq1/r;
.field public final k:Lm1/d;
.field public final l:J
.field public final m:Lq1/m;
.field public final n:Lk0/k0;
.field public final o:Lf1/r;
.field public final p:Lm0/h;

# direct methods
.method public constructor <init>(JJLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;I)V
    .registers 45

    .line 0: move/from16 v0, v44
    .line 2: and-int/lit8 v1, v0, 1
    .line 4: if-eqz v1, :cond_10
    .line 6: sget-wide v1, Lk0/q;->g:J
    .line 8: move-wide v4, v1
    .line 9: goto :goto_12
    .line 10: move-wide/from16 v4, v25
    .line 12: and-int/lit8 v1, v0, 2
    .line 14: if-eqz v1, :cond_20
    .line 16: sget-wide v1, Lr1/k;->c:J
    .line 18: move-wide v6, v1
    .line 19: goto :goto_22
    .line 20: move-wide/from16 v6, v27
    .line 22: and-int/lit8 v1, v0, 4
    .line 24: const/4 v2, 0
    .line 25: if-eqz v1, :cond_29
    .line 27: move-object v8, v2
    .line 28: goto :goto_31
    .line 29: move-object/from16 v8, v29
    .line 31: and-int/lit8 v1, v0, 8
    .line 33: if-eqz v1, :cond_37
    .line 35: move-object v9, v2
    .line 36: goto :goto_39
    .line 37: move-object/from16 v9, v30
    .line 39: and-int/lit8 v1, v0, 16
    .line 41: if-eqz v1, :cond_45
    .line 43: move-object v10, v2
    .line 44: goto :goto_47
    .line 45: move-object/from16 v10, v31
    .line 47: and-int/lit8 v1, v0, 32
    .line 49: if-eqz v1, :cond_53
    .line 51: move-object v11, v2
    .line 52: goto :goto_55
    .line 53: move-object/from16 v11, v32
    .line 55: and-int/lit8 v1, v0, 64
    .line 57: if-eqz v1, :cond_61
    .line 59: move-object v12, v2
    .line 60: goto :goto_63
    .line 61: move-object/from16 v12, v33
    .line 63: and-int/lit16 v1, v0, 128
    .line 65: if-eqz v1, :cond_70
    .line 67: sget-wide v13, Lr1/k;->c:J
    .line 69: goto :goto_72
    .line 70: move-wide/from16 v13, v34
    .line 72: and-int/lit16 v1, v0, 256
    .line 74: if-eqz v1, :cond_78
    .line 76: move-object v15, v2
    .line 77: goto :goto_80
    .line 78: move-object/from16 v15, v36
    .line 80: and-int/lit16 v1, v0, 512
    .line 82: if-eqz v1, :cond_87
    .line 84: move-object/from16 v16, v2
    .line 86: goto :goto_89
    .line 87: move-object/from16 v16, v37
    .line 89: and-int/lit16 v1, v0, 1024
    .line 91: if-eqz v1, :cond_96
    .line 93: move-object/from16 v17, v2
    .line 95: goto :goto_98
    .line 96: move-object/from16 v17, v38
    .line 98: and-int/lit16 v1, v0, 2048
    .line 100: if-eqz v1, :cond_105
    .line 102: sget-wide v18, Lk0/q;->g:J
    .line 104: goto :goto_107
    .line 105: move-wide/from16 v18, v39
    .line 107: and-int/lit16 v1, v0, 4096
    .line 109: if-eqz v1, :cond_114
    .line 111: move-object/from16 v20, v2
    .line 113: goto :goto_116
    .line 114: move-object/from16 v20, v41
    .line 116: and-int/lit16 v1, v0, 8192
    .line 118: if-eqz v1, :cond_123
    .line 120: move-object/from16 v21, v2
    .line 122: goto :goto_125
    .line 123: move-object/from16 v21, v42
    .line 125: and-int/lit16 v0, v0, 16384
    .line 127: if-eqz v0, :cond_132
    .line 129: move-object/from16 v22, v2
    .line 131: goto :goto_134
    .line 132: move-object/from16 v22, v43
    .line 134: const/16 v23, 0
    .line 136: move-object/from16 v3, v24
    .line 138: invoke-direct/range {v3 .. v23}, Lf1/w;-><init>(JJLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .line 141: return-void
.end method

# direct methods
.method public constructor <init>(JJLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .registers 44

    .line 0: move-wide/from16 v0, v24
    .line 2: sget-wide v2, Lk0/q;->g:J
    .line 4: cmp-long v2, v0, v2
    .line 6: if-eqz v2, :cond_15
    .line 8: new-instance v2, Lq1/c;
    .line 10: invoke-direct {v2, v0, v1}, Lq1/c;-><init>(J)V
    .line 13: move-object v4, v2
    .line 14: goto :goto_18
    .line 15: sget-object v2, Lq1/p;->a:Lq1/p;
    .line 17: goto :goto_13
    .line 18: move-object/from16 v3, v23
    .line 20: move-wide/from16 v5, v26
    .line 22: move-object/from16 v7, v28
    .line 24: move-object/from16 v8, v29
    .line 26: move-object/from16 v9, v30
    .line 28: move-object/from16 v10, v31
    .line 30: move-object/from16 v11, v32
    .line 32: move-wide/from16 v12, v33
    .line 34: move-object/from16 v14, v35
    .line 36: move-object/from16 v15, v36
    .line 38: move-object/from16 v16, v37
    .line 40: move-wide/from16 v17, v38
    .line 42: move-object/from16 v19, v40
    .line 44: move-object/from16 v20, v41
    .line 46: move-object/from16 v21, v42
    .line 48: move-object/from16 v22, v43
    .line 50: invoke-direct/range {v3 .. v22}, Lf1/w;-><init>(Lq1/q;JLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .line 53: return-void
.end method

# direct methods
.method public constructor <init>(Lq1/q;JLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .registers 23

    .line 0: move-object v0, v3
    .line 1: move-object v1, v4
    .line 2: const-string v2, "textForegroundStyle"
    .line 4: invoke-static {v4, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 10: iput-object v1, v0, Lf1/w;->a:Lq1/q;
    .line 12: move-wide v1, v5
    .line 13: iput-wide v1, v0, Lf1/w;->b:J
    .line 15: move-object v1, v7
    .line 16: iput-object v1, v0, Lf1/w;->c:Lk1/e0;
    .line 18: move-object v1, v8
    .line 19: iput-object v1, v0, Lf1/w;->d:Lk1/a0;
    .line 21: move-object v1, v9
    .line 22: iput-object v1, v0, Lf1/w;->e:Lk1/b0;
    .line 24: move-object v1, v10
    .line 25: iput-object v1, v0, Lf1/w;->f:Lk1/s;
    .line 27: move-object v1, v11
    .line 28: iput-object v1, v0, Lf1/w;->g:Ljava/lang/String;
    .line 30: move-wide v1, v12
    .line 31: iput-wide v1, v0, Lf1/w;->h:J
    .line 33: move-object v1, v14
    .line 34: iput-object v1, v0, Lf1/w;->i:Lq1/a;
    .line 36: move-object v1, v15
    .line 37: iput-object v1, v0, Lf1/w;->j:Lq1/r;
    .line 39: move-object/from16 v1, v16
    .line 41: iput-object v1, v0, Lf1/w;->k:Lm1/d;
    .line 43: move-wide/from16 v1, v17
    .line 45: iput-wide v1, v0, Lf1/w;->l:J
    .line 47: move-object/from16 v1, v19
    .line 49: iput-object v1, v0, Lf1/w;->m:Lq1/m;
    .line 51: move-object/from16 v1, v20
    .line 53: iput-object v1, v0, Lf1/w;->n:Lk0/k0;
    .line 55: move-object/from16 v1, v21
    .line 57: iput-object v1, v0, Lf1/w;->o:Lf1/r;
    .line 59: move-object/from16 v1, v22
    .line 61: iput-object v1, v0, Lf1/w;->p:Lm0/h;
    .line 63: return-void
.end method

# virtual methods
.method public final a(Lf1/w;)Z
    .registers 9

    .line 0: const-string v0, "other"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const/4 v0, 1
    .line 6: if-ne v7, v8, :cond_9
    .line 8: return v0
    .line 9: iget-wide v1, v7, Lf1/w;->b:J
    .line 11: iget-wide v3, v8, Lf1/w;->b:J
    .line 13: invoke-static {v1, v2, v3, v4}, Lr1/k;->a(JJ)Z
    .line 16: move-result v1
    .line 17: const/4 v2, 0
    .line 18: if-nez v1, :cond_21
    .line 20: return v2
    .line 21: iget-object v1, v7, Lf1/w;->c:Lk1/e0;
    .line 23: iget-object v3, v8, Lf1/w;->c:Lk1/e0;
    .line 25: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 28: move-result v1
    .line 29: if-nez v1, :cond_32
    .line 31: return v2
    .line 32: iget-object v1, v7, Lf1/w;->d:Lk1/a0;
    .line 34: iget-object v3, v8, Lf1/w;->d:Lk1/a0;
    .line 36: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 39: move-result v1
    .line 40: if-nez v1, :cond_43
    .line 42: return v2
    .line 43: iget-object v1, v7, Lf1/w;->e:Lk1/b0;
    .line 45: iget-object v3, v8, Lf1/w;->e:Lk1/b0;
    .line 47: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 50: move-result v1
    .line 51: if-nez v1, :cond_54
    .line 53: return v2
    .line 54: iget-object v1, v7, Lf1/w;->f:Lk1/s;
    .line 56: iget-object v3, v8, Lf1/w;->f:Lk1/s;
    .line 58: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 61: move-result v1
    .line 62: if-nez v1, :cond_65
    .line 64: return v2
    .line 65: iget-object v1, v7, Lf1/w;->g:Ljava/lang/String;
    .line 67: iget-object v3, v8, Lf1/w;->g:Ljava/lang/String;
    .line 69: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 72: move-result v1
    .line 73: if-nez v1, :cond_76
    .line 75: return v2
    .line 76: iget-wide v3, v7, Lf1/w;->h:J
    .line 78: iget-wide v5, v8, Lf1/w;->h:J
    .line 80: invoke-static {v3, v4, v5, v6}, Lr1/k;->a(JJ)Z
    .line 83: move-result v1
    .line 84: if-nez v1, :cond_87
    .line 86: return v2
    .line 87: iget-object v1, v7, Lf1/w;->i:Lq1/a;
    .line 89: iget-object v3, v8, Lf1/w;->i:Lq1/a;
    .line 91: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 94: move-result v1
    .line 95: if-nez v1, :cond_98
    .line 97: return v2
    .line 98: iget-object v1, v7, Lf1/w;->j:Lq1/r;
    .line 100: iget-object v3, v8, Lf1/w;->j:Lq1/r;
    .line 102: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 105: move-result v1
    .line 106: if-nez v1, :cond_109
    .line 108: return v2
    .line 109: iget-object v1, v7, Lf1/w;->k:Lm1/d;
    .line 111: iget-object v3, v8, Lf1/w;->k:Lm1/d;
    .line 113: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 116: move-result v1
    .line 117: if-nez v1, :cond_120
    .line 119: return v2
    .line 120: iget-wide v3, v7, Lf1/w;->l:J
    .line 122: iget-wide v5, v8, Lf1/w;->l:J
    .line 124: invoke-static {v3, v4, v5, v6}, Lk0/q;->d(JJ)Z
    .line 127: move-result v1
    .line 128: if-nez v1, :cond_131
    .line 130: return v2
    .line 131: iget-object v1, v7, Lf1/w;->o:Lf1/r;
    .line 133: iget-object v8, v8, Lf1/w;->o:Lf1/r;
    .line 135: invoke-static {v1, v8}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 138: move-result v8
    .line 139: if-nez v8, :cond_142
    .line 141: return v2
    .line 142: return v0
.end method

# virtual methods
.method public final b(Lf1/w;)Z
    .registers 5

    .line 0: const-string v0, "other"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v3, Lf1/w;->a:Lq1/q;
    .line 7: iget-object v1, v4, Lf1/w;->a:Lq1/q;
    .line 9: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 12: move-result v0
    .line 13: const/4 v1, 0
    .line 14: if-nez v0, :cond_17
    .line 16: return v1
    .line 17: iget-object v0, v3, Lf1/w;->m:Lq1/m;
    .line 19: iget-object v2, v4, Lf1/w;->m:Lq1/m;
    .line 21: invoke-static {v0, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 24: move-result v0
    .line 25: if-nez v0, :cond_28
    .line 27: return v1
    .line 28: iget-object v0, v3, Lf1/w;->n:Lk0/k0;
    .line 30: iget-object v2, v4, Lf1/w;->n:Lk0/k0;
    .line 32: invoke-static {v0, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 35: move-result v0
    .line 36: if-nez v0, :cond_39
    .line 38: return v1
    .line 39: iget-object v0, v3, Lf1/w;->p:Lm0/h;
    .line 41: iget-object v4, v4, Lf1/w;->p:Lm0/h;
    .line 43: invoke-static {v0, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 46: move-result v4
    .line 47: if-nez v4, :cond_50
    .line 49: return v1
    .line 50: const/4 v4, 1
    .line 51: return v4
.end method

# virtual methods
.method public final c(Lf1/w;)Lf1/w;
    .registers 68

    .line 0: move-object/from16 v0, v66
    .line 2: move-object/from16 v1, v67
    .line 4: if-nez v1, :cond_7
    .line 6: return-object v0
    .line 7: iget-object v2, v1, Lf1/w;->a:Lq1/q;
    .line 9: invoke-interface {v2}, Lq1/q;->b()J
    .line 12: move-result-wide v3
    .line 13: invoke-interface {v2}, Lq1/q;->c()Lk0/m;
    .line 16: move-result-object v5
    .line 17: invoke-interface {v2}, Lq1/q;->a()F
    .line 20: move-result v2
    .line 21: sget v6, Lf1/x;->e:I
    .line 23: iget-wide v6, v1, Lf1/w;->b:J
    .line 25: invoke-static {v6, v7}, Ld2/c;->d0(J)Z
    .line 28: move-result v8
    .line 29: xor-int/lit8 v8, v8, 1
    .line 31: iget-object v9, v1, Lf1/w;->c:Lk1/e0;
    .line 33: iget-object v10, v1, Lf1/w;->d:Lk1/a0;
    .line 35: iget-object v11, v1, Lf1/w;->e:Lk1/b0;
    .line 37: iget-object v12, v1, Lf1/w;->f:Lk1/s;
    .line 39: iget-object v13, v1, Lf1/w;->g:Ljava/lang/String;
    .line 41: iget-wide v14, v1, Lf1/w;->h:J
    .line 43: move-object/from16 v16, v13
    .line 45: iget-object v13, v1, Lf1/w;->i:Lq1/a;
    .line 47: move-object/from16 v17, v13
    .line 49: iget-object v13, v1, Lf1/w;->j:Lq1/r;
    .line 51: move-object/from16 v18, v13
    .line 53: iget-object v13, v1, Lf1/w;->k:Lm1/d;
    .line 55: move-wide/from16 v19, v14
    .line 57: move-object v15, v13
    .line 58: iget-wide v13, v1, Lf1/w;->l:J
    .line 60: move-wide/from16 v21, v13
    .line 62: iget-object v13, v1, Lf1/w;->m:Lq1/m;
    .line 64: iget-object v14, v1, Lf1/w;->n:Lk0/k0;
    .line 66: move-object/from16 v23, v14
    .line 68: iget-object v14, v1, Lf1/w;->o:Lf1/r;
    .line 70: iget-object v1, v1, Lf1/w;->p:Lm0/h;
    .line 72: move-object/from16 v67, v1
    .line 74: iget-object v1, v0, Lf1/w;->p:Lm0/h;
    .line 76: move-object/from16 v24, v1
    .line 78: iget-object v1, v0, Lf1/w;->o:Lf1/r;
    .line 80: move-object/from16 v25, v1
    .line 82: iget-object v1, v0, Lf1/w;->n:Lk0/k0;
    .line 84: move-object/from16 v27, v14
    .line 86: move-object/from16 v26, v15
    .line 88: iget-wide v14, v0, Lf1/w;->l:J
    .line 90: move-object/from16 v28, v1
    .line 92: iget-object v1, v0, Lf1/w;->k:Lm1/d;
    .line 94: move-wide/from16 v29, v14
    .line 96: iget-object v14, v0, Lf1/w;->j:Lq1/r;
    .line 98: iget-object v15, v0, Lf1/w;->i:Lq1/a;
    .line 100: move-object/from16 v31, v1
    .line 102: iget-object v1, v0, Lf1/w;->g:Ljava/lang/String;
    .line 104: move-object/from16 v32, v14
    .line 106: iget-object v14, v0, Lf1/w;->e:Lk1/b0;
    .line 108: move-object/from16 v33, v15
    .line 110: iget-object v15, v0, Lf1/w;->m:Lq1/m;
    .line 112: move-object/from16 v35, v1
    .line 114: move/from16 v34, v2
    .line 116: iget-wide v1, v0, Lf1/w;->h:J
    .line 118: move-object/from16 v36, v14
    .line 120: iget-object v14, v0, Lf1/w;->f:Lk1/s;
    .line 122: move-object/from16 v37, v11
    .line 124: iget-object v11, v0, Lf1/w;->c:Lk1/e0;
    .line 126: move-object/from16 v38, v15
    .line 128: iget-object v15, v0, Lf1/w;->d:Lk1/a0;
    .line 130: move-wide/from16 v39, v1
    .line 132: iget-wide v1, v0, Lf1/w;->b:J
    .line 134: move-object/from16 v41, v13
    .line 136: iget-object v13, v0, Lf1/w;->a:Lq1/q;
    .line 138: if-eqz v8, :cond_173
    .line 140: invoke-static {v6, v7, v1, v2}, Lr1/k;->a(JJ)Z
    .line 143: move-result v8
    .line 144: if-eqz v8, :cond_147
    .line 146: goto :goto_173
    .line 147: move-wide/from16 v42, v1
    .line 149: move-object/from16 v2, v26
    .line 151: move-object/from16 v8, v37
    .line 153: move-object/from16 v1, v67
    .line 155: move-object/from16 v37, v36
    .line 157: move-object/from16 v36, v11
    .line 159: move-object/from16 v11, v16
    .line 161: move-wide/from16 v64, v19
    .line 163: move-object/from16 v19, v14
    .line 165: move-object/from16 v20, v15
    .line 167: move-wide/from16 v14, v21
    .line 169: move-wide/from16 v21, v64
    .line 171: goto/16 :goto_540
    .line 173: if-nez v5, :cond_201
    .line 175: sget-wide v42, Lk0/q;->g:J
    .line 177: cmp-long v8, v3, v42
    .line 179: if-eqz v8, :cond_201
    .line 181: move-wide/from16 v42, v1
    .line 183: invoke-interface {v13}, Lq1/q;->b()J
    .line 186: move-result-wide v0
    .line 187: invoke-static {v3, v4, v0, v1}, Lk0/q;->d(JJ)Z
    .line 190: move-result v0
    .line 191: if-eqz v0, :cond_194
    .line 193: goto :goto_203
    .line 194: move-object/from16 v1, v67
    .line 196: move-object/from16 v2, v26
    .line 198: move-object/from16 v8, v37
    .line 200: goto :goto_155
    .line 201: move-wide/from16 v42, v1
    .line 203: if-eqz v10, :cond_211
    .line 205: invoke-static {v10, v15}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 208: move-result v0
    .line 209: if-eqz v0, :cond_194
    .line 211: if-eqz v9, :cond_219
    .line 213: invoke-static {v9, v11}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 216: move-result v0
    .line 217: if-eqz v0, :cond_194
    .line 219: if-eqz v12, :cond_223
    .line 221: if-ne v12, v14, :cond_194
    .line 223: invoke-static/range {v19 .. v20}, Ld2/c;->d0(J)Z
    .line 226: move-result v0
    .line 227: xor-int/lit8 v0, v0, 1
    .line 229: move-object v2, v14
    .line 230: move-object v8, v15
    .line 231: if-eqz v0, :cond_268
    .line 233: move-wide/from16 v0, v19
    .line 235: move-wide/from16 v14, v39
    .line 237: invoke-static {v0, v1, v14, v15}, Lr1/k;->a(JJ)Z
    .line 240: move-result v19
    .line 241: if-eqz v19, :cond_244
    .line 243: goto :goto_272
    .line 244: move-object/from16 v19, v2
    .line 246: move-object/from16 v20, v8
    .line 248: move-wide/from16 v39, v14
    .line 250: move-wide/from16 v14, v21
    .line 252: move-object/from16 v2, v26
    .line 254: move-object/from16 v8, v37
    .line 256: move-wide/from16 v21, v0
    .line 258: move-object/from16 v37, v36
    .line 260: move-object/from16 v1, v67
    .line 262: move-object/from16 v36, v11
    .line 264: move-object/from16 v11, v16
    .line 266: goto/16 :goto_540
    .line 268: move-wide/from16 v0, v19
    .line 270: move-wide/from16 v14, v39
    .line 272: move-object/from16 v19, v2
    .line 274: move-object/from16 v20, v8
    .line 276: if-eqz v41, :cond_296
    .line 278: move-object/from16 v8, v38
    .line 280: move-object/from16 v2, v41
    .line 282: invoke-static {v2, v8}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 285: move-result v38
    .line 286: if-eqz v38, :cond_291
    .line 288: move-object/from16 v38, v8
    .line 290: goto :goto_298
    .line 291: move-object/from16 v41, v2
    .line 293: move-object/from16 v38, v8
    .line 295: goto :goto_248
    .line 296: move-object/from16 v2, v41
    .line 298: invoke-interface {v13}, Lq1/q;->c()Lk0/m;
    .line 301: move-result-object v8
    .line 302: invoke-static {v5, v8}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 305: move-result v8
    .line 306: if-eqz v8, :cond_319
    .line 308: if-eqz v5, :cond_322
    .line 310: invoke-interface {v13}, Lq1/q;->a()F
    .line 313: move-result v8
    .line 314: cmpg-float v8, v34, v8
    .line 316: if-nez v8, :cond_319
    .line 318: goto :goto_322
    .line 319: move-object/from16 v41, v2
    .line 321: goto :goto_248
    .line 322: move-object/from16 v8, v37
    .line 324: move-object/from16 v64, v36
    .line 326: move-object/from16 v36, v11
    .line 328: move-object/from16 v11, v64
    .line 330: if-eqz v37, :cond_357
    .line 332: invoke-static {v8, v11}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 335: move-result v37
    .line 336: if-eqz v37, :cond_339
    .line 338: goto :goto_357
    .line 339: move-object/from16 v41, v2
    .line 341: move-object/from16 v37, v11
    .line 343: move-wide/from16 v39, v14
    .line 345: move-object/from16 v11, v16
    .line 347: move-wide/from16 v14, v21
    .line 349: move-object/from16 v2, v26
    .line 351: move-wide/from16 v21, v0
    .line 353: move-object/from16 v1, v67
    .line 355: goto/16 :goto_540
    .line 357: move-object/from16 v37, v11
    .line 359: move-wide/from16 v39, v14
    .line 361: move-object/from16 v11, v16
    .line 363: move-object/from16 v14, v35
    .line 365: if-eqz v16, :cond_379
    .line 367: invoke-static {v11, v14}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 370: move-result v15
    .line 371: if-eqz v15, :cond_374
    .line 373: goto :goto_379
    .line 374: move-object/from16 v41, v2
    .line 376: move-object/from16 v35, v14
    .line 378: goto :goto_347
    .line 379: move-object/from16 v35, v14
    .line 381: move-object/from16 v15, v17
    .line 383: move-object/from16 v14, v33
    .line 385: if-eqz v17, :cond_401
    .line 387: invoke-static {v15, v14}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 390: move-result v16
    .line 391: if-eqz v16, :cond_394
    .line 393: goto :goto_401
    .line 394: move-object/from16 v41, v2
    .line 396: move-object/from16 v33, v14
    .line 398: move-object/from16 v17, v15
    .line 400: goto :goto_347
    .line 401: move-object/from16 v41, v2
    .line 403: move-object/from16 v33, v14
    .line 405: move-object/from16 v14, v18
    .line 407: move-object/from16 v2, v32
    .line 409: if-eqz v18, :cond_423
    .line 411: invoke-static {v14, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 414: move-result v16
    .line 415: if-eqz v16, :cond_418
    .line 417: goto :goto_423
    .line 418: move-object/from16 v32, v2
    .line 420: move-object/from16 v18, v14
    .line 422: goto :goto_398
    .line 423: move-object/from16 v32, v2
    .line 425: move-object/from16 v18, v14
    .line 427: move-object/from16 v2, v26
    .line 429: move-object/from16 v14, v31
    .line 431: if-eqz v26, :cond_447
    .line 433: invoke-static {v2, v14}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 436: move-result v16
    .line 437: if-eqz v16, :cond_440
    .line 439: goto :goto_447
    .line 440: move-object/from16 v31, v14
    .line 442: move-object/from16 v17, v15
    .line 444: move-wide/from16 v14, v21
    .line 446: goto :goto_351
    .line 447: sget-wide v16, Lk0/q;->g:J
    .line 449: cmp-long v16, v21, v16
    .line 451: move-object/from16 v31, v14
    .line 453: move-object/from16 v17, v15
    .line 455: move-wide/from16 v14, v21
    .line 457: move-wide/from16 v21, v0
    .line 459: move-wide/from16 v0, v29
    .line 461: if-eqz v16, :cond_473
    .line 463: invoke-static {v14, v15, v0, v1}, Lk0/q;->d(JJ)Z
    .line 466: move-result v16
    .line 467: if-eqz v16, :cond_470
    .line 469: goto :goto_473
    .line 470: move-wide/from16 v29, v0
    .line 472: goto :goto_353
    .line 473: move-wide/from16 v29, v0
    .line 475: move-object/from16 v0, v23
    .line 477: move-object/from16 v1, v28
    .line 479: if-eqz v23, :cond_494
    .line 481: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 484: move-result v16
    .line 485: if-eqz v16, :cond_488
    .line 487: goto :goto_494
    .line 488: move-object/from16 v23, v0
    .line 490: move-object/from16 v28, v1
    .line 492: goto/16 :goto_353
    .line 494: move-object/from16 v23, v0
    .line 496: move-object/from16 v28, v1
    .line 498: move-object/from16 v0, v25
    .line 500: move-object/from16 v1, v27
    .line 502: if-eqz v27, :cond_517
    .line 504: invoke-static {v1, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 507: move-result v16
    .line 508: if-eqz v16, :cond_511
    .line 510: goto :goto_517
    .line 511: move-object/from16 v25, v0
    .line 513: move-object/from16 v27, v1
    .line 515: goto/16 :goto_353
    .line 517: if-eqz v67, :cond_536
    .line 519: move-object/from16 v25, v0
    .line 521: move-object/from16 v27, v1
    .line 523: move-object/from16 v0, v24
    .line 525: move-object/from16 v1, v67
    .line 527: invoke-static {v1, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 530: move-result v16
    .line 531: if-nez v16, :cond_536
    .line 533: move-object/from16 v24, v0
    .line 535: goto :goto_540
    .line 536: move-object/from16 v0, v66
    .line 538: goto/16 :goto_769
    .line 540: sget-object v0, Lq1/p;->a:Lq1/p;
    .line 542: if-eqz v5, :cond_553
    .line 544: move-object/from16 v67, v1
    .line 546: move/from16 v1, v34
    .line 548: invoke-static {v1, v5}, Lq1/o;->a(FLk0/m;)Lq1/q;
    .line 551: move-result-object v1
    .line 552: goto :goto_568
    .line 553: move-object/from16 v67, v1
    .line 555: sget-wide v44, Lk0/q;->g:J
    .line 557: cmp-long v1, v3, v44
    .line 559: if-eqz v1, :cond_567
    .line 561: new-instance v1, Lq1/c;
    .line 563: invoke-direct {v1, v3, v4}, Lq1/c;-><init>(J)V
    .line 566: goto :goto_568
    .line 567: move-object v1, v0
    .line 568: invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 571: instance-of v3, v1, Lq1/b;
    .line 573: if-eqz v3, :cond_616
    .line 575: instance-of v4, v13, Lq1/b;
    .line 577: if-eqz v4, :cond_616
    .line 579: new-instance v0, Lq1/b;
    .line 581: move-object v3, v1
    .line 582: check-cast v3, Lq1/b;
    .line 584: invoke-interface {v1}, Lq1/q;->a()F
    .line 587: move-result v1
    .line 588: invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z
    .line 591: move-result v4
    .line 592: if-eqz v4, :cond_608
    .line 594: invoke-interface {v13}, Lq1/q;->a()F
    .line 597: move-result v1
    .line 598: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 601: move-result-object v1
    .line 602: check-cast v1, Ljava/lang/Number;
    .line 604: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 607: move-result v1
    .line 608: iget-object v3, v3, Lq1/b;->a:Lk0/j0;
    .line 610: invoke-direct {v0, v3, v1}, Lq1/b;-><init>(Lk0/j0;F)V
    .line 613: move-object/from16 v45, v0
    .line 615: goto :goto_645
    .line 616: if-eqz v3, :cond_625
    .line 618: instance-of v4, v13, Lq1/b;
    .line 620: if-nez v4, :cond_625
    .line 622: move-object/from16 v45, v1
    .line 624: goto :goto_645
    .line 625: if-nez v3, :cond_634
    .line 627: instance-of v3, v13, Lq1/b;
    .line 629: if-eqz v3, :cond_634
    .line 631: move-object/from16 v45, v13
    .line 633: goto :goto_645
    .line 634: invoke-static {v1, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 637: move-result v0
    .line 638: if-nez v0, :cond_642
    .line 640: move-object v13, v1
    .line 641: goto :goto_631
    .line 642: check-cast v13, Lq1/q;
    .line 644: goto :goto_631
    .line 645: if-nez v12, :cond_650
    .line 647: move-object/from16 v51, v19
    .line 649: goto :goto_652
    .line 650: move-object/from16 v51, v12
    .line 652: invoke-static {v6, v7}, Ld2/c;->d0(J)Z
    .line 655: move-result v0
    .line 656: if-nez v0, :cond_661
    .line 658: move-wide/from16 v46, v6
    .line 660: goto :goto_663
    .line 661: move-wide/from16 v46, v42
    .line 663: if-nez v9, :cond_668
    .line 665: move-object/from16 v48, v36
    .line 667: goto :goto_670
    .line 668: move-object/from16 v48, v9
    .line 670: if-nez v10, :cond_675
    .line 672: move-object/from16 v49, v20
    .line 674: goto :goto_677
    .line 675: move-object/from16 v49, v10
    .line 677: if-nez v8, :cond_682
    .line 679: move-object/from16 v50, v37
    .line 681: goto :goto_684
    .line 682: move-object/from16 v50, v8
    .line 684: if-nez v11, :cond_689
    .line 686: move-object/from16 v52, v35
    .line 688: goto :goto_691
    .line 689: move-object/from16 v52, v11
    .line 691: invoke-static/range {v21 .. v22}, Ld2/c;->d0(J)Z
    .line 694: move-result v0
    .line 695: if-nez v0, :cond_700
    .line 697: move-wide/from16 v53, v21
    .line 699: goto :goto_702
    .line 700: move-wide/from16 v53, v39
    .line 702: if-nez v17, :cond_707
    .line 704: move-object/from16 v55, v33
    .line 706: goto :goto_709
    .line 707: move-object/from16 v55, v17
    .line 709: if-nez v18, :cond_714
    .line 711: move-object/from16 v56, v32
    .line 713: goto :goto_716
    .line 714: move-object/from16 v56, v18
    .line 716: if-nez v2, :cond_721
    .line 718: move-object/from16 v57, v31
    .line 720: goto :goto_723
    .line 721: move-object/from16 v57, v2
    .line 723: sget-wide v0, Lk0/q;->g:J
    .line 725: cmp-long v0, v14, v0
    .line 727: if-eqz v0, :cond_732
    .line 729: move-wide/from16 v58, v14
    .line 731: goto :goto_734
    .line 732: move-wide/from16 v58, v29
    .line 734: if-nez v41, :cond_739
    .line 736: move-object/from16 v60, v38
    .line 738: goto :goto_741
    .line 739: move-object/from16 v60, v41
    .line 741: if-nez v23, :cond_746
    .line 743: move-object/from16 v61, v28
    .line 745: goto :goto_748
    .line 746: move-object/from16 v61, v23
    .line 748: if-nez v25, :cond_753
    .line 750: move-object/from16 v62, v27
    .line 752: goto :goto_755
    .line 753: move-object/from16 v62, v25
    .line 755: if-nez v67, :cond_760
    .line 757: move-object/from16 v63, v24
    .line 759: goto :goto_762
    .line 760: move-object/from16 v63, v67
    .line 762: new-instance v0, Lf1/w;
    .line 764: move-object/from16 v44, v0
    .line 766: invoke-direct/range {v44 .. v63}, Lf1/w;-><init>(Lq1/q;JLk1/e0;Lk1/a0;Lk1/b0;Lk1/s;Ljava/lang/String;JLq1/a;Lq1/r;Lm1/d;JLq1/m;Lk0/k0;Lf1/r;Lm0/h;)V
    .line 769: return-object v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 0: const/4 v0, 1
    .line 1: if-ne v3, v4, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v4, Lf1/w;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v4, Lf1/w;
    .line 12: invoke-virtual {v3, v4}, Lf1/w;->a(Lf1/w;)Z
    .line 15: move-result v1
    .line 16: if-eqz v1, :cond_25
    .line 18: invoke-virtual {v3, v4}, Lf1/w;->b(Lf1/w;)Z
    .line 21: move-result v4
    .line 22: if-eqz v4, :cond_25
    .line 24: goto :goto_26
    .line 25: move v0, v2
    .line 26: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 8

    .line 0: iget-object v0, v7, Lf1/w;->a:Lq1/q;
    .line 2: invoke-interface {v0}, Lq1/q;->b()J
    .line 5: move-result-wide v1
    .line 6: sget v3, Lk0/q;->h:I
    .line 8: invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I
    .line 11: move-result v1
    .line 12: const/16 v2, 31
    .line 14: mul-int/2addr v1, v2
    .line 15: invoke-interface {v0}, Lq1/q;->c()Lk0/m;
    .line 18: move-result-object v3
    .line 19: const/4 v4, 0
    .line 20: if-eqz v3, :cond_27
    .line 22: invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I
    .line 25: move-result v3
    .line 26: goto :goto_28
    .line 27: move v3, v4
    .line 28: add-int/2addr v1, v3
    .line 29: mul-int/2addr v1, v2
    .line 30: invoke-interface {v0}, Lq1/q;->a()F
    .line 33: move-result v0
    .line 34: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 37: move-result v0
    .line 38: add-int/2addr v0, v1
    .line 39: mul-int/2addr v0, v2
    .line 40: sget-object v1, Lr1/k;->b:[Lr1/l;
    .line 42: iget-wide v5, v7, Lf1/w;->b:J
    .line 44: invoke-static {v5, v6, v0, v2}, Lai/onnxruntime/b;->d(JII)I
    .line 47: move-result v0
    .line 48: iget-object v1, v7, Lf1/w;->c:Lk1/e0;
    .line 50: if-eqz v1, :cond_55
    .line 52: iget v1, v1, Lk1/e0;->i:I
    .line 54: goto :goto_56
    .line 55: move v1, v4
    .line 56: add-int/2addr v0, v1
    .line 57: mul-int/2addr v0, v2
    .line 58: iget-object v1, v7, Lf1/w;->d:Lk1/a0;
    .line 60: if-eqz v1, :cond_69
    .line 62: iget v1, v1, Lk1/a0;->a:I
    .line 64: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 67: move-result v1
    .line 68: goto :goto_70
    .line 69: move v1, v4
    .line 70: add-int/2addr v0, v1
    .line 71: mul-int/2addr v0, v2
    .line 72: iget-object v1, v7, Lf1/w;->e:Lk1/b0;
    .line 74: if-eqz v1, :cond_83
    .line 76: iget v1, v1, Lk1/b0;->a:I
    .line 78: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 81: move-result v1
    .line 82: goto :goto_84
    .line 83: move v1, v4
    .line 84: add-int/2addr v0, v1
    .line 85: mul-int/2addr v0, v2
    .line 86: iget-object v1, v7, Lf1/w;->f:Lk1/s;
    .line 88: if-eqz v1, :cond_95
    .line 90: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 93: move-result v1
    .line 94: goto :goto_96
    .line 95: move v1, v4
    .line 96: add-int/2addr v0, v1
    .line 97: mul-int/2addr v0, v2
    .line 98: iget-object v1, v7, Lf1/w;->g:Ljava/lang/String;
    .line 100: if-eqz v1, :cond_107
    .line 102: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 105: move-result v1
    .line 106: goto :goto_108
    .line 107: move v1, v4
    .line 108: add-int/2addr v0, v1
    .line 109: mul-int/2addr v0, v2
    .line 110: iget-wide v5, v7, Lf1/w;->h:J
    .line 112: invoke-static {v5, v6, v0, v2}, Lai/onnxruntime/b;->d(JII)I
    .line 115: move-result v0
    .line 116: iget-object v1, v7, Lf1/w;->i:Lq1/a;
    .line 118: if-eqz v1, :cond_127
    .line 120: iget v1, v1, Lq1/a;->a:F
    .line 122: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 125: move-result v1
    .line 126: goto :goto_128
    .line 127: move v1, v4
    .line 128: add-int/2addr v0, v1
    .line 129: mul-int/2addr v0, v2
    .line 130: iget-object v1, v7, Lf1/w;->j:Lq1/r;
    .line 132: if-eqz v1, :cond_139
    .line 134: invoke-virtual {v1}, Lq1/r;->hashCode()I
    .line 137: move-result v1
    .line 138: goto :goto_140
    .line 139: move v1, v4
    .line 140: add-int/2addr v0, v1
    .line 141: mul-int/2addr v0, v2
    .line 142: iget-object v1, v7, Lf1/w;->k:Lm1/d;
    .line 144: if-eqz v1, :cond_153
    .line 146: iget-object v1, v1, Lm1/d;->i:Ljava/util/List;
    .line 148: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 151: move-result v1
    .line 152: goto :goto_154
    .line 153: move v1, v4
    .line 154: add-int/2addr v0, v1
    .line 155: mul-int/2addr v0, v2
    .line 156: iget-wide v5, v7, Lf1/w;->l:J
    .line 158: invoke-static {v5, v6, v0, v2}, Lai/onnxruntime/b;->d(JII)I
    .line 161: move-result v0
    .line 162: iget-object v1, v7, Lf1/w;->m:Lq1/m;
    .line 164: if-eqz v1, :cond_169
    .line 166: iget v1, v1, Lq1/m;->a:I
    .line 168: goto :goto_170
    .line 169: move v1, v4
    .line 170: add-int/2addr v0, v1
    .line 171: mul-int/2addr v0, v2
    .line 172: iget-object v1, v7, Lf1/w;->n:Lk0/k0;
    .line 174: if-eqz v1, :cond_181
    .line 176: invoke-virtual {v1}, Lk0/k0;->hashCode()I
    .line 179: move-result v1
    .line 180: goto :goto_182
    .line 181: move v1, v4
    .line 182: add-int/2addr v0, v1
    .line 183: mul-int/2addr v0, v2
    .line 184: iget-object v1, v7, Lf1/w;->o:Lf1/r;
    .line 186: if-eqz v1, :cond_193
    .line 188: invoke-virtual {v1}, Lf1/r;->hashCode()I
    .line 191: move-result v1
    .line 192: goto :goto_194
    .line 193: move v1, v4
    .line 194: add-int/2addr v0, v1
    .line 195: mul-int/2addr v0, v2
    .line 196: iget-object v1, v7, Lf1/w;->p:Lm0/h;
    .line 198: if-eqz v1, :cond_204
    .line 200: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 203: move-result v4
    .line 204: add-int/2addr v0, v4
    .line 205: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "SpanStyle(color="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v4, Lf1/w;->a:Lq1/q;
    .line 9: invoke-interface {v1}, Lq1/q;->b()J
    .line 12: move-result-wide v2
    .line 13: invoke-static {v2, v3}, Lk0/q;->j(J)Ljava/lang/String;
    .line 16: move-result-object v2
    .line 17: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 20: const-string v2, ", brush="
    .line 22: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 25: invoke-interface {v1}, Lq1/q;->c()Lk0/m;
    .line 28: move-result-object v2
    .line 29: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: const-string v2, ", alpha="
    .line 34: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-interface {v1}, Lq1/q;->a()F
    .line 40: move-result v1
    .line 41: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 44: const-string v1, ", fontSize="
    .line 46: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 49: iget-wide v1, v4, Lf1/w;->b:J
    .line 51: invoke-static {v1, v2}, Lr1/k;->d(J)Ljava/lang/String;
    .line 54: move-result-object v1
    .line 55: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 58: const-string v1, ", fontWeight="
    .line 60: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 63: iget-object v1, v4, Lf1/w;->c:Lk1/e0;
    .line 65: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 68: const-string v1, ", fontStyle="
    .line 70: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 73: iget-object v1, v4, Lf1/w;->d:Lk1/a0;
    .line 75: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 78: const-string v1, ", fontSynthesis="
    .line 80: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 83: iget-object v1, v4, Lf1/w;->e:Lk1/b0;
    .line 85: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 88: const-string v1, ", fontFamily="
    .line 90: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 93: iget-object v1, v4, Lf1/w;->f:Lk1/s;
    .line 95: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 98: const-string v1, ", fontFeatureSettings="
    .line 100: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 103: iget-object v1, v4, Lf1/w;->g:Ljava/lang/String;
    .line 105: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 108: const-string v1, ", letterSpacing="
    .line 110: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 113: iget-wide v1, v4, Lf1/w;->h:J
    .line 115: invoke-static {v1, v2}, Lr1/k;->d(J)Ljava/lang/String;
    .line 118: move-result-object v1
    .line 119: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 122: const-string v1, ", baselineShift="
    .line 124: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 127: iget-object v1, v4, Lf1/w;->i:Lq1/a;
    .line 129: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 132: const-string v1, ", textGeometricTransform="
    .line 134: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 137: iget-object v1, v4, Lf1/w;->j:Lq1/r;
    .line 139: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 142: const-string v1, ", localeList="
    .line 144: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 147: iget-object v1, v4, Lf1/w;->k:Lm1/d;
    .line 149: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 152: const-string v1, ", background="
    .line 154: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 157: iget-wide v1, v4, Lf1/w;->l:J
    .line 159: const-string v3, ", textDecoration="
    .line 161: invoke-static {v1, v2, v0, v3}, Lai/onnxruntime/b;->s(JLjava/lang/StringBuilder;Ljava/lang/String;)V
    .line 164: iget-object v1, v4, Lf1/w;->m:Lq1/m;
    .line 166: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 169: const-string v1, ", shadow="
    .line 171: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 174: iget-object v1, v4, Lf1/w;->n:Lk0/k0;
    .line 176: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 179: const-string v1, ", platformStyle="
    .line 181: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 184: iget-object v1, v4, Lf1/w;->o:Lf1/r;
    .line 186: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 189: const-string v1, ", drawStyle="
    .line 191: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 194: iget-object v1, v4, Lf1/w;->p:Lm0/h;
    .line 196: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 199: const/16 v1, 41
    .line 201: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 204: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 207: move-result-object v0
    .line 208: return-object v0
.end method

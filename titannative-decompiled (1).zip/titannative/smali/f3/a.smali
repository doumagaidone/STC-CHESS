.class public abstract interface Lf3/a;
.super Ljava/lang/Object;
.source "SourceFile"

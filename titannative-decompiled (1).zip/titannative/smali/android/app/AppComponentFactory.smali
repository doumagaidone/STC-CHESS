.class public synthetic Landroid/app/AppComponentFactory;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/lang/NoClassDefFoundError;
    .line 2: invoke-direct {v0}, Ljava/lang/NoClassDefFoundError;-><init>()V
    .line 5: throw v0
.end method

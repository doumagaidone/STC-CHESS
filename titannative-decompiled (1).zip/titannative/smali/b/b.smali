.class public abstract interface Lb/b;
.super Ljava/lang/Object;
.source "SourceFile"

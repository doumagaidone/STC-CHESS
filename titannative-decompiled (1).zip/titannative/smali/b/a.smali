.class public final Lb/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/concurrent/CopyOnWriteArraySet;
.field public volatile b:Landroid/content/Context;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;
    .line 5: invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V
    .line 8: iput-object v0, v1, Lb/a;->a:Ljava/util/concurrent/CopyOnWriteArraySet;
    .line 10: return-void
.end method

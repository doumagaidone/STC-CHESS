.class public final Le2/p;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final d:Ljava/util/ArrayList;

.field public a:Ljava/util/WeakHashMap;
.field public b:Landroid/util/SparseArray;
.field public c:Ljava/lang/ref/WeakReference;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 5: sput-object v0, Le2/p;->d:Ljava/util/ArrayList;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Landroid/view/View;)Landroid/view/View;
    .registers 6

    .line 0: iget-object v0, v4, Le2/p;->a:Ljava/util/WeakHashMap;
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_69
    .line 5: invoke-virtual {v0, v5}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z
    .line 8: move-result v0
    .line 9: if-nez v0, :cond_12
    .line 11: goto :goto_69
    .line 12: instance-of v0, v5, Landroid/view/ViewGroup;
    .line 14: if-eqz v0, :cond_41
    .line 16: move-object v0, v5
    .line 17: check-cast v0, Landroid/view/ViewGroup;
    .line 19: invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I
    .line 22: move-result v2
    .line 23: add-int/lit8 v2, v2, -1
    .line 25: if-ltz v2, :cond_41
    .line 27: invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    .line 30: move-result-object v3
    .line 31: invoke-virtual {v4, v3}, Le2/p;->a(Landroid/view/View;)Landroid/view/View;
    .line 34: move-result-object v3
    .line 35: if-eqz v3, :cond_38
    .line 37: return-object v3
    .line 38: add-int/lit8 v2, v2, -1
    .line 40: goto :goto_25
    .line 41: const v0, 0x7f06004c
    .line 44: invoke-virtual {v5, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 47: move-result-object v5
    .line 48: check-cast v5, Ljava/util/ArrayList;
    .line 50: if-eqz v5, :cond_69
    .line 52: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 55: move-result v0
    .line 56: add-int/lit8 v0, v0, -1
    .line 58: if-gez v0, :cond_61
    .line 60: goto :goto_69
    .line 61: invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 64: move-result-object v5
    .line 65: invoke-static {v5}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 68: throw v1
    .line 69: return-object v1
.end method

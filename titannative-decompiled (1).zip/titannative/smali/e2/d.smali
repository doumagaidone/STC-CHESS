.class public abstract interface Le2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract superDispatchKeyEvent(Landroid/view/KeyEvent;)Z
.end method

.class public abstract interface Le2/i;
.super Ljava/lang/Object;
.source "SourceFile"

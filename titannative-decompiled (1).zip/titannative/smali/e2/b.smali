.class public abstract Le2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/View$AccessibilityDelegate;Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View$AccessibilityDelegate;->getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static b(Landroid/view/View$AccessibilityDelegate;Landroid/view/View;ILandroid/os/Bundle;)Z
    .registers 4

    .line 0: invoke-virtual {v0, v1, v2, v3}, Landroid/view/View$AccessibilityDelegate;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .line 3: move-result v0
    .line 4: return v0
.end method

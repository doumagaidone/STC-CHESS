.class public abstract Le2/m;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/View;Le2/o;)V
    .registers 4

    .line 0: const v0, 0x7f06004c
    .line 3: invoke-virtual {v2, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 6: move-result-object v1
    .line 7: check-cast v1, Lf/k;
    .line 9: if-nez v1, :cond_19
    .line 11: new-instance v1, Lf/k;
    .line 13: invoke-direct {v1}, Lf/k;-><init>()V
    .line 16: invoke-virtual {v2, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 19: invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    .line 22: new-instance v0, Le2/l;
    .line 24: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 27: invoke-virtual {v1, v3, v0}, Lf/k;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 30: invoke-virtual {v2, v0}, Landroid/view/View;->addOnUnhandledKeyEventListener(Landroid/view/View$OnUnhandledKeyEventListener;)V
    .line 33: return-void
.end method

# direct methods
.method public static b(Landroid/view/View;)Ljava/lang/CharSequence;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->getAccessibilityPaneTitle()Ljava/lang/CharSequence;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static c(Landroid/view/View;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->isAccessibilityHeading()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static d(Landroid/view/View;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->isScreenReaderFocusable()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static e(Landroid/view/View;Le2/o;)V
    .registers 4

    .line 0: const v0, 0x7f06004c
    .line 3: invoke-virtual {v2, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 6: move-result-object v0
    .line 7: check-cast v0, Lf/k;
    .line 9: if-nez v0, :cond_12
    .line 11: return-void
    .line 12: const/4 v1, 0
    .line 13: invoke-virtual {v0, v3, v1}, Lf/k;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 16: move-result-object v3
    .line 17: check-cast v3, Landroid/view/View$OnUnhandledKeyEventListener;
    .line 19: if-eqz v3, :cond_24
    .line 21: invoke-virtual {v2, v3}, Landroid/view/View;->removeOnUnhandledKeyEventListener(Landroid/view/View$OnUnhandledKeyEventListener;)V
    .line 24: return-void
.end method

# direct methods
.method public static f(Landroid/view/View;I)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->requireViewById(I)Landroid/view/View;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static g(Landroid/view/View;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setAccessibilityHeading(Z)V
    .line 3: return-void
.end method

# direct methods
.method public static h(Landroid/view/View;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setAccessibilityPaneTitle(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

# direct methods
.method public static i(Landroid/view/View;Landroid/view/autofill/AutofillId;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setAutofillId(Landroid/view/autofill/AutofillId;)V
    .line 3: return-void
.end method

# direct methods
.method public static j(Landroid/view/View;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setScreenReaderFocusable(Z)V
    .line 3: return-void
.end method

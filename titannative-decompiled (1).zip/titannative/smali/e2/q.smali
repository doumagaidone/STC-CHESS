.class public abstract Le2/q;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:I

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 2: const/4 v1, 1
    .line 3: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    .line 6: new-instance v0, Ljava/util/WeakHashMap;
    .line 8: invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V
    .line 11: return-void
.end method

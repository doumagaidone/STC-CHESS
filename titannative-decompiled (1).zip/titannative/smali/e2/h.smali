.class public final Le2/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/Runnable;
.field public final b:Ljava/util/concurrent/CopyOnWriteArrayList;
.field public final c:Ljava/util/HashMap;

# direct methods
.method public constructor <init>(Landroidx/activity/d;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;
    .line 5: invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V
    .line 8: iput-object v0, v1, Le2/h;->b:Ljava/util/concurrent/CopyOnWriteArrayList;
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: iput-object v0, v1, Le2/h;->c:Ljava/util/HashMap;
    .line 17: iput-object v2, v1, Le2/h;->a:Ljava/lang/Runnable;
    .line 19: return-void
.end method

# virtual methods
.method public final a()V
    .registers 5

    .line 0: iget-object v0, v4, Le2/h;->b:Ljava/util/concurrent/CopyOnWriteArrayList;
    .line 2: const/4 v1, 0
    .line 3: invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z
    .line 6: iget-object v0, v4, Le2/h;->c:Ljava/util/HashMap;
    .line 8: invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 11: move-result-object v0
    .line 12: check-cast v0, Le2/g;
    .line 14: if-eqz v0, :cond_25
    .line 16: iget-object v2, v0, Le2/g;->a:Landroidx/lifecycle/o;
    .line 18: iget-object v3, v0, Le2/g;->b:Landroidx/lifecycle/r;
    .line 20: invoke-virtual {v2, v3}, Landroidx/lifecycle/o;->b(Landroidx/lifecycle/s;)V
    .line 23: iput-object v1, v0, Le2/g;->b:Landroidx/lifecycle/r;
    .line 25: iget-object v0, v4, Le2/h;->a:Ljava/lang/Runnable;
    .line 27: invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    .line 30: return-void
.end method

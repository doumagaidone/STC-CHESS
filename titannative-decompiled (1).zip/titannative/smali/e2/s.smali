.class public abstract Le2/s;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/lang/reflect/Method;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 25
    .line 4: if-ne v0, v1, :cond_27
    .line 6: const-class v0, Landroid/view/ViewConfiguration;
    .line 8: const-string v1, "getScaledScrollFactor"
    .line 10: const/4 v2, 0
    .line 11: new-array v2, v2, [Ljava/lang/Class;
    .line 13: invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 16: move-result-object v0
    .line 17: sput-object v0, Le2/s;->a:Ljava/lang/reflect/Method;
    .line 19: goto :goto_27
    .line 20: const-string v0, "ViewConfigCompat"
    .line 22: const-string v1, "Could not find method getScaledScrollFactor() on ViewConfiguration"
    .line 24: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 27: return-void
.end method

# direct methods
.method public static a(Landroid/view/ViewConfiguration;Landroid/content/Context;)F
    .registers 5

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 25
    .line 4: if-lt v0, v1, :cond_32
    .line 6: sget-object v0, Le2/s;->a:Ljava/lang/reflect/Method;
    .line 8: if-eqz v0, :cond_32
    .line 10: const/4 v1, 0
    .line 11: new-array v1, v1, [Ljava/lang/Object;
    .line 13: invoke-virtual {v0, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 16: move-result-object v3
    .line 17: check-cast v3, Ljava/lang/Integer;
    .line 19: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    .line 22: move-result v3
    .line 23: int-to-float v3, v3
    .line 24: return v3
    .line 25: const-string v3, "ViewConfigCompat"
    .line 27: const-string v0, "Could not find method getScaledScrollFactor() on ViewConfiguration"
    .line 29: invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 32: new-instance v3, Landroid/util/TypedValue;
    .line 34: invoke-direct {v3}, Landroid/util/TypedValue;-><init>()V
    .line 37: invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;
    .line 40: move-result-object v0
    .line 41: const v1, 0x101004d
    .line 44: const/4 v2, 1
    .line 45: invoke-virtual {v0, v1, v3, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z
    .line 48: move-result v0
    .line 49: if-eqz v0, :cond_64
    .line 51: invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 54: move-result-object v4
    .line 55: invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    .line 58: move-result-object v4
    .line 59: invoke-virtual {v3, v4}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F
    .line 62: move-result v3
    .line 63: return v3
    .line 64: const/4 v3, 0
    .line 65: return v3
.end method

.class public abstract Le2/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final c:Landroid/view/View$AccessibilityDelegate;

.field public final a:Landroid/view/View$AccessibilityDelegate;
.field public final b:Le2/a;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroid/view/View$AccessibilityDelegate;
    .line 2: invoke-direct {v0}, Landroid/view/View$AccessibilityDelegate;-><init>()V
    .line 5: sput-object v0, Le2/c;->c:Landroid/view/View$AccessibilityDelegate;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: sget-object v0, Le2/c;->c:Landroid/view/View$AccessibilityDelegate;
    .line 2: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 5: iput-object v0, v1, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 7: new-instance v0, Le2/a;
    .line 9: invoke-direct {v0, v1}, Le2/a;-><init>(Le2/c;)V
    .line 12: iput-object v0, v1, Le2/c;->b:Le2/a;
    .line 14: return-void
.end method

# virtual methods
.method public abstract a(Landroid/view/View;)Lb1/a;
.end method

.class public final synthetic Le2/l;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/View$OnUnhandledKeyEventListener;

# virtual methods
.method public final onUnhandledKeyEvent(Landroid/view/View;Landroid/view/KeyEvent;)Z
    .registers 3

    .line 0: const/4 v1, 0
    .line 1: throw v1
.end method

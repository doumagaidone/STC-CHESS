.class public final Le2/a;
.super Landroid/view/View$AccessibilityDelegate;
.source "SourceFile"

.field public final a:Le2/c;

# direct methods
.method public constructor <init>(Le2/c;)V
    .registers 2

    .line 0: invoke-direct {v0}, Landroid/view/View$AccessibilityDelegate;-><init>()V
    .line 3: iput-object v1, v0, Le2/a;->a:Le2/c;
    .line 5: return-void
.end method

# virtual methods
.method public final dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 4

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 4: invoke-virtual {v0, v2, v3}, Landroid/view/View$AccessibilityDelegate;->dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .line 7: move-result v2
    .line 8: return v2
.end method

# virtual methods
.method public final getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .registers 3

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: invoke-virtual {v0, v2}, Le2/c;->a(Landroid/view/View;)Lb1/a;
    .line 5: move-result-object v2
    .line 6: if-eqz v2, :cond_13
    .line 8: iget-object v2, v2, Lb1/a;->a:Ljava/lang/Object;
    .line 10: check-cast v2, Landroid/view/accessibility/AccessibilityNodeProvider;
    .line 12: goto :goto_14
    .line 13: const/4 v2, 0
    .line 14: return-object v2
.end method

# virtual methods
.method public final onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 4: invoke-virtual {v0, v2, v3}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .line 7: return-void
.end method

# virtual methods
.method public final onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 20

    .line 0: move-object/from16 v0, v18
    .line 2: move-object/from16 v1, v19
    .line 4: new-instance v2, Lf2/k;
    .line 6: invoke-direct {v2, v1}, Lf2/k;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .line 9: sget v3, Le2/q;->a:I
    .line 11: sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 13: const-class v4, Ljava/lang/Boolean;
    .line 15: const/4 v5, 0
    .line 16: const/16 v6, 28
    .line 18: if-lt v3, v6, :cond_29
    .line 20: invoke-static/range {v18 .. v18}, Le2/m;->d(Landroid/view/View;)Z
    .line 23: move-result v3
    .line 24: invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 27: move-result-object v3
    .line 28: goto :goto_44
    .line 29: const v3, 0x7f060048
    .line 32: invoke-virtual {v0, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 35: move-result-object v3
    .line 36: invoke-virtual {v4, v3}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 39: move-result v7
    .line 40: if-eqz v7, :cond_43
    .line 42: goto :goto_44
    .line 43: move-object v3, v5
    .line 44: check-cast v3, Ljava/lang/Boolean;
    .line 46: const/4 v7, 0
    .line 47: const/4 v8, 1
    .line 48: if-eqz v3, :cond_58
    .line 50: invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z
    .line 53: move-result v3
    .line 54: if-eqz v3, :cond_58
    .line 56: move v3, v8
    .line 57: goto :goto_59
    .line 58: move v3, v7
    .line 59: sget v9, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 61: const-string v10, "androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY"
    .line 63: if-lt v9, v6, :cond_69
    .line 65: invoke-static {v1, v3}, Landroidx/compose/ui/platform/r2;->i(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .line 68: goto :goto_85
    .line 69: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 72: move-result-object v11
    .line 73: if-eqz v11, :cond_85
    .line 75: invoke-virtual {v11, v10, v7}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 78: move-result v12
    .line 79: and-int/lit8 v12, v12, -2
    .line 81: or-int/2addr v3, v12
    .line 82: invoke-virtual {v11, v10, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 85: sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 87: if-lt v3, v6, :cond_98
    .line 89: invoke-static/range {v18 .. v18}, Le2/m;->c(Landroid/view/View;)Z
    .line 92: move-result v3
    .line 93: invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 96: move-result-object v3
    .line 97: goto :goto_113
    .line 98: const v3, 0x7f060043
    .line 101: invoke-virtual {v0, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 104: move-result-object v3
    .line 105: invoke-virtual {v4, v3}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 108: move-result v4
    .line 109: if-eqz v4, :cond_112
    .line 111: goto :goto_113
    .line 112: move-object v3, v5
    .line 113: check-cast v3, Ljava/lang/Boolean;
    .line 115: if-eqz v3, :cond_124
    .line 117: invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z
    .line 120: move-result v3
    .line 121: if-eqz v3, :cond_124
    .line 123: goto :goto_125
    .line 124: move v8, v7
    .line 125: if-lt v9, v6, :cond_131
    .line 127: invoke-static {v1, v8}, Landroidx/compose/ui/platform/r2;->m(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .line 130: goto :goto_152
    .line 131: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 134: move-result-object v3
    .line 135: if-eqz v3, :cond_152
    .line 137: invoke-virtual {v3, v10, v7}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 140: move-result v4
    .line 141: and-int/lit8 v4, v4, -3
    .line 143: if-eqz v8, :cond_147
    .line 145: const/4 v8, 2
    .line 146: goto :goto_148
    .line 147: move v8, v7
    .line 148: or-int/2addr v4, v8
    .line 149: invoke-virtual {v3, v10, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 152: const-class v3, Ljava/lang/CharSequence;
    .line 154: if-lt v9, v6, :cond_161
    .line 156: invoke-static/range {v18 .. v18}, Le2/m;->b(Landroid/view/View;)Ljava/lang/CharSequence;
    .line 159: move-result-object v4
    .line 160: goto :goto_176
    .line 161: const v4, 0x7f060044
    .line 164: invoke-virtual {v0, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 167: move-result-object v4
    .line 168: invoke-virtual {v3, v4}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 171: move-result v8
    .line 172: if-eqz v8, :cond_175
    .line 174: goto :goto_176
    .line 175: move-object v4, v5
    .line 176: check-cast v4, Ljava/lang/CharSequence;
    .line 178: if-lt v9, v6, :cond_184
    .line 180: invoke-static {v1, v4}, Landroidx/compose/ui/platform/r2;->h(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .line 183: goto :goto_193
    .line 184: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 187: move-result-object v6
    .line 188: const-string v8, "androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY"
    .line 190: invoke-virtual {v6, v8, v4}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 193: sget v4, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 195: const/16 v6, 30
    .line 197: if-lt v4, v6, :cond_204
    .line 199: invoke-static/range {v18 .. v18}, Le2/n;->b(Landroid/view/View;)Ljava/lang/CharSequence;
    .line 202: move-result-object v3
    .line 203: goto :goto_220
    .line 204: const v4, 0x7f060049
    .line 207: invoke-virtual {v0, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 210: move-result-object v4
    .line 211: invoke-virtual {v3, v4}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 214: move-result v3
    .line 215: if-eqz v3, :cond_219
    .line 217: move-object v3, v4
    .line 218: goto :goto_220
    .line 219: move-object v3, v5
    .line 220: check-cast v3, Ljava/lang/CharSequence;
    .line 222: if-lt v9, v6, :cond_230
    .line 224: invoke-static {v1, v3}, Lf2/g;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .line 227: move-object/from16 v3, v17
    .line 229: goto :goto_240
    .line 230: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 233: move-result-object v4
    .line 234: const-string v6, "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"
    .line 236: invoke-virtual {v4, v6, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 239: goto :goto_227
    .line 240: iget-object v4, v3, Le2/a;->a:Le2/c;
    .line 242: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 245: iget-object v4, v4, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 247: invoke-virtual {v4, v0, v1}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .line 250: invoke-virtual/range {v19 .. v19}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;
    .line 253: move-result-object v4
    .line 254: const/16 v6, 26
    .line 256: if-ge v9, v6, :cond_533
    .line 258: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 261: move-result-object v6
    .line 262: const-string v8, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY"
    .line 264: invoke-virtual {v6, v8}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V
    .line 267: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 270: move-result-object v6
    .line 271: const-string v9, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY"
    .line 273: invoke-virtual {v6, v9}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V
    .line 276: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 279: move-result-object v6
    .line 280: const-string v10, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY"
    .line 282: invoke-virtual {v6, v10}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V
    .line 285: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 288: move-result-object v6
    .line 289: const-string v11, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY"
    .line 291: invoke-virtual {v6, v11}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V
    .line 294: const v6, 0x7f060042
    .line 297: invoke-virtual {v0, v6}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 300: move-result-object v12
    .line 301: check-cast v12, Landroid/util/SparseArray;
    .line 303: if-eqz v12, :cond_362
    .line 305: new-instance v13, Ljava/util/ArrayList;
    .line 307: invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V
    .line 310: move v14, v7
    .line 311: invoke-virtual {v12}, Landroid/util/SparseArray;->size()I
    .line 314: move-result v15
    .line 315: if-ge v14, v15, :cond_339
    .line 317: invoke-virtual {v12, v14}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;
    .line 320: move-result-object v15
    .line 321: check-cast v15, Ljava/lang/ref/WeakReference;
    .line 323: invoke-virtual {v15}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 326: move-result-object v15
    .line 327: if-nez v15, :cond_336
    .line 329: invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 332: move-result-object v15
    .line 333: invoke-virtual {v13, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 336: add-int/lit8 v14, v14, 1
    .line 338: goto :goto_311
    .line 339: move v14, v7
    .line 340: invoke-virtual {v13}, Ljava/util/ArrayList;->size()I
    .line 343: move-result v15
    .line 344: if-ge v14, v15, :cond_362
    .line 346: invoke-virtual {v13, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 349: move-result-object v15
    .line 350: check-cast v15, Ljava/lang/Integer;
    .line 352: invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I
    .line 355: move-result v15
    .line 356: invoke-virtual {v12, v15}, Landroid/util/SparseArray;->remove(I)V
    .line 359: add-int/lit8 v14, v14, 1
    .line 361: goto :goto_340
    .line 362: instance-of v12, v4, Landroid/text/Spanned;
    .line 364: if-eqz v12, :cond_381
    .line 366: move-object v5, v4
    .line 367: check-cast v5, Landroid/text/Spanned;
    .line 369: invoke-interface {v4}, Ljava/lang/CharSequence;->length()I
    .line 372: move-result v12
    .line 373: const-class v13, Landroid/text/style/ClickableSpan;
    .line 375: invoke-interface {v5, v7, v12, v13}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .line 378: move-result-object v5
    .line 379: check-cast v5, [Landroid/text/style/ClickableSpan;
    .line 381: if-eqz v5, :cond_533
    .line 383: array-length v12, v5
    .line 384: if-lez v12, :cond_533
    .line 386: invoke-static/range {v19 .. v19}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 389: move-result-object v1
    .line 390: const-string v12, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY"
    .line 392: const/high16 v13, 0x7f06
    .line 394: invoke-virtual {v1, v12, v13}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 397: invoke-virtual {v0, v6}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 400: move-result-object v1
    .line 401: check-cast v1, Landroid/util/SparseArray;
    .line 403: if-nez v1, :cond_413
    .line 405: new-instance v1, Landroid/util/SparseArray;
    .line 407: invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V
    .line 410: invoke-virtual {v0, v6, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 413: move v6, v7
    .line 414: array-length v12, v5
    .line 415: if-ge v6, v12, :cond_533
    .line 417: aget-object v12, v5, v6
    .line 419: move v13, v7
    .line 420: invoke-virtual {v1}, Landroid/util/SparseArray;->size()I
    .line 423: move-result v14
    .line 424: if-ge v13, v14, :cond_452
    .line 426: invoke-virtual {v1, v13}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;
    .line 429: move-result-object v14
    .line 430: check-cast v14, Ljava/lang/ref/WeakReference;
    .line 432: invoke-virtual {v14}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 435: move-result-object v14
    .line 436: check-cast v14, Landroid/text/style/ClickableSpan;
    .line 438: invoke-virtual {v12, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 441: move-result v14
    .line 442: if-eqz v14, :cond_449
    .line 444: invoke-virtual {v1, v13}, Landroid/util/SparseArray;->keyAt(I)I
    .line 447: move-result v12
    .line 448: goto :goto_458
    .line 449: add-int/lit8 v13, v13, 1
    .line 451: goto :goto_420
    .line 452: sget v12, Lf2/k;->d:I
    .line 454: add-int/lit8 v13, v12, 1
    .line 456: sput v13, Lf2/k;->d:I
    .line 458: new-instance v13, Ljava/lang/ref/WeakReference;
    .line 460: aget-object v14, v5, v6
    .line 462: invoke-direct {v13, v14}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 465: invoke-virtual {v1, v12, v13}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    .line 468: aget-object v13, v5, v6
    .line 470: move-object v14, v4
    .line 471: check-cast v14, Landroid/text/Spanned;
    .line 473: invoke-virtual {v2, v8}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 476: move-result-object v15
    .line 477: invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I
    .line 480: move-result v16
    .line 481: invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 484: move-result-object v7
    .line 485: invoke-interface {v15, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 488: invoke-virtual {v2, v9}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 491: move-result-object v7
    .line 492: invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I
    .line 495: move-result v15
    .line 496: invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 499: move-result-object v15
    .line 500: invoke-interface {v7, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 503: invoke-virtual {v2, v10}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 506: move-result-object v7
    .line 507: invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I
    .line 510: move-result v13
    .line 511: invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 514: move-result-object v13
    .line 515: invoke-interface {v7, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 518: invoke-virtual {v2, v11}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 521: move-result-object v7
    .line 522: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 525: move-result-object v12
    .line 526: invoke-interface {v7, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 529: add-int/lit8 v6, v6, 1
    .line 531: const/4 v7, 0
    .line 532: goto :goto_414
    .line 533: const v1, 0x7f060041
    .line 536: invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 539: move-result-object v0
    .line 540: check-cast v0, Ljava/util/List;
    .line 542: if-nez v0, :cond_548
    .line 544: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    .line 547: move-result-object v0
    .line 548: const/4 v7, 0
    .line 549: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 552: move-result v1
    .line 553: if-ge v7, v1, :cond_567
    .line 555: invoke-interface {v0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 558: move-result-object v1
    .line 559: check-cast v1, Lf2/e;
    .line 561: invoke-virtual {v2, v1}, Lf2/k;->a(Lf2/e;)V
    .line 564: add-int/lit8 v7, v7, 1
    .line 566: goto :goto_549
    .line 567: return-void
.end method

# virtual methods
.method public final onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 4: invoke-virtual {v0, v2, v3}, Landroid/view/View$AccessibilityDelegate;->onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .line 7: return-void
.end method

# virtual methods
.method public final onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 5

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 4: invoke-virtual {v0, v2, v3, v4}, Landroid/view/View$AccessibilityDelegate;->onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .line 7: move-result v2
    .line 8: return v2
.end method

# virtual methods
.method public final performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .registers 9

    .line 0: iget-object v0, v5, Le2/a;->a:Le2/c;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: const v1, 0x7f060041
    .line 8: invoke-virtual {v6, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 11: move-result-object v1
    .line 12: check-cast v1, Ljava/util/List;
    .line 14: if-nez v1, :cond_20
    .line 16: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    .line 19: move-result-object v1
    .line 20: const/4 v2, 0
    .line 21: move v3, v2
    .line 22: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 25: move-result v4
    .line 26: if-ge v3, v4, :cond_48
    .line 28: invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v4
    .line 32: check-cast v4, Lf2/e;
    .line 34: iget-object v4, v4, Lf2/e;->a:Ljava/lang/Object;
    .line 36: check-cast v4, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 38: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getId()I
    .line 41: move-result v4
    .line 42: if-ne v4, v7, :cond_45
    .line 44: goto :goto_48
    .line 45: add-int/lit8 v3, v3, 1
    .line 47: goto :goto_22
    .line 48: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 50: invoke-static {v0, v6, v7, v8}, Le2/b;->b(Landroid/view/View$AccessibilityDelegate;Landroid/view/View;ILandroid/os/Bundle;)Z
    .line 53: move-result v0
    .line 54: if-nez v0, :cond_148
    .line 56: const/high16 v1, 0x7f06
    .line 58: if-ne v7, v1, :cond_148
    .line 60: if-eqz v8, :cond_148
    .line 62: const-string v7, "ACCESSIBILITY_CLICKABLE_SPAN_ID"
    .line 64: const/4 v0, -1
    .line 65: invoke-virtual {v8, v7, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 68: move-result v7
    .line 69: const v8, 0x7f060042
    .line 72: invoke-virtual {v6, v8}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 75: move-result-object v8
    .line 76: check-cast v8, Landroid/util/SparseArray;
    .line 78: if-eqz v8, :cond_147
    .line 80: invoke-virtual {v8, v7}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;
    .line 83: move-result-object v7
    .line 84: check-cast v7, Ljava/lang/ref/WeakReference;
    .line 86: if-eqz v7, :cond_147
    .line 88: invoke-virtual {v7}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 91: move-result-object v7
    .line 92: check-cast v7, Landroid/text/style/ClickableSpan;
    .line 94: if-eqz v7, :cond_147
    .line 96: invoke-virtual {v6}, Landroid/view/View;->createAccessibilityNodeInfo()Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 99: move-result-object v8
    .line 100: invoke-virtual {v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;
    .line 103: move-result-object v8
    .line 104: instance-of v0, v8, Landroid/text/Spanned;
    .line 106: if-eqz v0, :cond_124
    .line 108: move-object v0, v8
    .line 109: check-cast v0, Landroid/text/Spanned;
    .line 111: invoke-interface {v8}, Ljava/lang/CharSequence;->length()I
    .line 114: move-result v8
    .line 115: const-class v1, Landroid/text/style/ClickableSpan;
    .line 117: invoke-interface {v0, v2, v8, v1}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .line 120: move-result-object v8
    .line 121: check-cast v8, [Landroid/text/style/ClickableSpan;
    .line 123: goto :goto_125
    .line 124: const/4 v8, 0
    .line 125: move v0, v2
    .line 126: if-eqz v8, :cond_147
    .line 128: array-length v1, v8
    .line 129: if-ge v0, v1, :cond_147
    .line 131: aget-object v1, v8, v0
    .line 133: invoke-virtual {v7, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 136: move-result v1
    .line 137: if-eqz v1, :cond_144
    .line 139: invoke-virtual {v7, v6}, Landroid/text/style/ClickableSpan;->onClick(Landroid/view/View;)V
    .line 142: const/4 v2, 1
    .line 143: goto :goto_147
    .line 144: add-int/lit8 v0, v0, 1
    .line 146: goto :goto_126
    .line 147: move v0, v2
    .line 148: return v0
.end method

# virtual methods
.method public final sendAccessibilityEvent(Landroid/view/View;I)V
    .registers 4

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 4: invoke-virtual {v0, v2, v3}, Landroid/view/View$AccessibilityDelegate;->sendAccessibilityEvent(Landroid/view/View;I)V
    .line 7: return-void
.end method

# virtual methods
.method public final sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .line 0: iget-object v0, v1, Le2/a;->a:Le2/c;
    .line 2: iget-object v0, v0, Le2/c;->a:Landroid/view/View$AccessibilityDelegate;
    .line 4: invoke-virtual {v0, v2, v3}, Landroid/view/View$AccessibilityDelegate;->sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .line 7: return-void
.end method

.class public abstract interface Le2/o;
.super Ljava/lang/Object;
.source "SourceFile"

.class public abstract Le2/r;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/ViewConfiguration;)F
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledHorizontalScrollFactor()F
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static b(Landroid/view/ViewConfiguration;)F
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledVerticalScrollFactor()F
    .line 3: move-result v0
    .line 4: return v0
.end method

.class public abstract Le2/n;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/View;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->getImportantForContentCapture()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static b(Landroid/view/View;)Ljava/lang/CharSequence;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->getStateDescription()Ljava/lang/CharSequence;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static c(Landroid/view/View;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/View;->isImportantForContentCapture()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static d(Landroid/view/View;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setImportantForContentCapture(I)V
    .line 3: return-void
.end method

# direct methods
.method public static e(Landroid/view/View;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->setStateDescription(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

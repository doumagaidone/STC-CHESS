.class public final Le2/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroidx/lifecycle/o;
.field public b:Landroidx/lifecycle/r;

# direct methods
.method public constructor <init>(Landroidx/lifecycle/o;Landroidx/lifecycle/r;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Le2/g;->a:Landroidx/lifecycle/o;
    .line 5: iput-object v2, v0, Le2/g;->b:Landroidx/lifecycle/r;
    .line 7: invoke-virtual {v1, v2}, Landroidx/lifecycle/o;->a(Landroidx/lifecycle/s;)V
    .line 10: return-void
.end method

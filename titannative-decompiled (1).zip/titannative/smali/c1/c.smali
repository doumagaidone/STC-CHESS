.class public final Lc1/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/util/HashMap;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Lc1/c;->a:Ljava/util/HashMap;
    .line 10: return-void
.end method

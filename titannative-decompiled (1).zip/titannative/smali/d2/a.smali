.class public abstract interface Ld2/a;
.super Ljava/lang/Object;
.source "SourceFile"

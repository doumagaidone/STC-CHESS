.class public abstract Ld2/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static a:J
.field public static b:Ljava/lang/reflect/Method;
.field public static c:Lorg/json/JSONObject;
.field public static final synthetic d:I
.field public static e:Lo0/f;
.field public static final f:I
.field public static final g:I
.field public static final h:I

# direct methods
.method public static final A0(Lw2/j;)Z
    .registers 3

    .line 0: sget-object v0, Ln3/v;->j:Ln3/v;
    .line 2: invoke-interface {v2, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 5: move-result-object v2
    .line 6: check-cast v2, Ln3/x0;
    .line 8: const/4 v0, 0
    .line 9: if-eqz v2, :cond_19
    .line 11: invoke-interface {v2}, Ln3/x0;->b()Z
    .line 14: move-result v2
    .line 15: const/4 v1, 1
    .line 16: if-ne v2, v1, :cond_19
    .line 18: move v0, v1
    .line 19: return v0
.end method

# direct methods
.method public static A1(Ljava/io/ByteArrayOutputStream;JI)V
    .registers 10

    .line 0: new-array v0, v9, [B
    .line 2: const/4 v1, 0
    .line 3: if-ge v1, v9, :cond_19
    .line 5: mul-int/lit8 v2, v1, 8
    .line 7: shr-long v2, v7, v2
    .line 9: const-wide/16 v4, 255
    .line 11: and-long/2addr v2, v4
    .line 12: long-to-int v2, v2
    .line 13: int-to-byte v2, v2
    .line 14: aput-byte v2, v0, v1
    .line 16: add-int/lit8 v1, v1, 1
    .line 18: goto :goto_3
    .line 19: invoke-virtual {v6, v0}, Ljava/io/OutputStream;->write([B)V
    .line 22: return-void
.end method

# direct methods
.method public static B(FF)D
    .registers 6

    .line 0: invoke-static {v4}, Ljava/lang/Float;->isInfinite(F)Z
    .line 3: move-result v0
    .line 4: const-wide/high16 v1, 0x3ff0
    .line 6: if-nez v0, :cond_74
    .line 8: invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z
    .line 11: move-result v0
    .line 12: if-nez v0, :cond_74
    .line 14: invoke-static {v5}, Ljava/lang/Float;->isInfinite(F)Z
    .line 17: move-result v0
    .line 18: if-nez v0, :cond_74
    .line 20: invoke-static {v5}, Ljava/lang/Float;->isNaN(F)Z
    .line 23: move-result v0
    .line 24: if-nez v0, :cond_74
    .line 26: const/4 v0, 0
    .line 27: cmpg-float v0, v5, v0
    .line 29: if-gtz v0, :cond_32
    .line 31: goto :goto_74
    .line 32: div-float/2addr v4, v5
    .line 33: const v5, 0x3e99999a
    .line 36: cmpl-float v5, v4, v5
    .line 38: if-ltz v5, :cond_41
    .line 40: goto :goto_74
    .line 41: const v5, 0x3d4ccccd
    .line 44: cmpg-float v5, v4, v5
    .line 46: if-gtz v5, :cond_54
    .line 48: const-wide v1, 0x3ff6666666666666
    .line 53: goto :goto_74
    .line 54: const/4 v5, 1
    .line 55: int-to-double v0, v5
    .line 56: const-wide v2, 0x3fd3333333333333
    .line 61: float-to-double v4, v4
    .line 62: sub-double/2addr v2, v4
    .line 63: const-wide/high16 v4, 0x3fd0
    .line 65: div-double/2addr v2, v4
    .line 66: const-wide v4, 0x3fd999999999999a
    .line 71: mul-double/2addr v2, v4
    .line 72: add-double v1, v2, v0
    .line 74: return-wide v1
.end method

# direct methods
.method public static final B0(I)Z
    .registers 3

    .line 0: const/4 v0, 1
    .line 1: if-eq v2, v0, :cond_8
    .line 3: const/4 v1, 2
    .line 4: if-ne v2, v1, :cond_7
    .line 6: goto :goto_8
    .line 7: const/4 v0, 0
    .line 8: return v0
.end method

# direct methods
.method public static B1(Ljava/io/ByteArrayOutputStream;I)V
    .registers 4

    .line 0: int-to-long v0, v3
    .line 1: const/4 v3, 2
    .line 2: invoke-static {v2, v0, v1, v3}, Ld2/b;->A1(Ljava/io/ByteArrayOutputStream;JI)V
    .line 5: return-void
.end method

# direct methods
.method public static C(Ljava/io/Closeable;)V
    .registers 1

    .line 0: if-eqz v0, :cond_5
    .line 2: invoke-interface {v0}, Ljava/io/Closeable;->close()V
    .line 5: return-void
.end method

# direct methods
.method public static C0()Z
    .registers 7

    .line 0: sget-object v0, Ld2/b;->b:Ljava/lang/reflect/Method;
    .line 2: if-nez v0, :cond_9
    .line 4: invoke-static {}, Lk0/j;->i()Z
    .line 7: move-result v0
    .line 8: return v0
    .line 9: const-class v0, Landroid/os/Trace;
    .line 11: const/4 v1, 0
    .line 12: sget-object v2, Ld2/b;->b:Ljava/lang/reflect/Method;
    .line 14: const/4 v3, 1
    .line 15: const/4 v4, 0
    .line 16: if-nez v2, :cond_47
    .line 18: const-string v2, "TRACE_TAG_APP"
    .line 20: invoke-virtual {v0, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    .line 23: move-result-object v2
    .line 24: invoke-virtual {v2, v4}, Ljava/lang/reflect/Field;->getLong(Ljava/lang/Object;)J
    .line 27: move-result-wide v5
    .line 28: sput-wide v5, Ld2/b;->a:J
    .line 30: const-string v2, "isTagEnabled"
    .line 32: new-array v5, v3, [Ljava/lang/Class;
    .line 34: sget-object v6, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 36: aput-object v6, v5, v1
    .line 38: invoke-virtual {v0, v2, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 41: move-result-object v0
    .line 42: sput-object v0, Ld2/b;->b:Ljava/lang/reflect/Method;
    .line 44: goto :goto_47
    .line 45: move-exception v0
    .line 46: goto :goto_70
    .line 47: sget-object v0, Ld2/b;->b:Ljava/lang/reflect/Method;
    .line 49: new-array v2, v3, [Ljava/lang/Object;
    .line 51: sget-wide v5, Ld2/b;->a:J
    .line 53: invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 56: move-result-object v3
    .line 57: aput-object v3, v2, v1
    .line 59: invoke-virtual {v0, v4, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 62: move-result-object v0
    .line 63: check-cast v0, Ljava/lang/Boolean;
    .line 65: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 68: move-result v1
    .line 69: goto :goto_98
    .line 70: instance-of v2, v0, Ljava/lang/reflect/InvocationTargetException;
    .line 72: if-eqz v2, :cond_91
    .line 74: invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;
    .line 77: move-result-object v0
    .line 78: instance-of v1, v0, Ljava/lang/RuntimeException;
    .line 80: if-eqz v1, :cond_85
    .line 82: check-cast v0, Ljava/lang/RuntimeException;
    .line 84: throw v0
    .line 85: new-instance v1, Ljava/lang/RuntimeException;
    .line 87: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 90: throw v1
    .line 91: const-string v2, "Unable to call isTagEnabled via reflection"
    .line 93: const-string v3, "Trace"
    .line 95: invoke-static {v3, v2, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 98: return v1
.end method

# direct methods
.method public static D(FF)F
    .registers 3

    .line 0: cmpg-float v0, v1, v2
    .line 2: if-gez v0, :cond_5
    .line 4: move v1, v2
    .line 5: return v1
.end method

# direct methods
.method public static final D0(Lj0/e;)Z
    .registers 7

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-wide v0, v6, Lj0/e;->e:J
    .line 7: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 10: move-result v2
    .line 11: invoke-static {v0, v1}, Lj0/a;->c(J)F
    .line 14: move-result v3
    .line 15: cmpg-float v2, v2, v3
    .line 17: if-nez v2, :cond_99
    .line 19: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 22: move-result v2
    .line 23: iget-wide v3, v6, Lj0/e;->f:J
    .line 25: invoke-static {v3, v4}, Lj0/a;->b(J)F
    .line 28: move-result v5
    .line 29: cmpg-float v2, v2, v5
    .line 31: if-nez v2, :cond_99
    .line 33: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 36: move-result v2
    .line 37: invoke-static {v3, v4}, Lj0/a;->c(J)F
    .line 40: move-result v3
    .line 41: cmpg-float v2, v2, v3
    .line 43: if-nez v2, :cond_99
    .line 45: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 48: move-result v2
    .line 49: iget-wide v3, v6, Lj0/e;->g:J
    .line 51: invoke-static {v3, v4}, Lj0/a;->b(J)F
    .line 54: move-result v5
    .line 55: cmpg-float v2, v2, v5
    .line 57: if-nez v2, :cond_99
    .line 59: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 62: move-result v2
    .line 63: invoke-static {v3, v4}, Lj0/a;->c(J)F
    .line 66: move-result v3
    .line 67: cmpg-float v2, v2, v3
    .line 69: if-nez v2, :cond_99
    .line 71: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 74: move-result v2
    .line 75: iget-wide v3, v6, Lj0/e;->h:J
    .line 77: invoke-static {v3, v4}, Lj0/a;->b(J)F
    .line 80: move-result v6
    .line 81: cmpg-float v6, v2, v6
    .line 83: if-nez v6, :cond_99
    .line 85: invoke-static {v0, v1}, Lj0/a;->b(J)F
    .line 88: move-result v6
    .line 89: invoke-static {v3, v4}, Lj0/a;->c(J)F
    .line 92: move-result v0
    .line 93: cmpg-float v6, v6, v0
    .line 95: if-nez v6, :cond_99
    .line 97: const/4 v6, 1
    .line 98: goto :goto_100
    .line 99: const/4 v6, 0
    .line 100: return v6
.end method

# direct methods
.method public static E(DDD)D
    .registers 7

    .line 0: cmpl-double v0, v3, v5
    .line 2: if-gtz v0, :cond_15
    .line 4: cmpg-double v0, v1, v3
    .line 6: if-gez v0, :cond_9
    .line 8: return-wide v3
    .line 9: cmpl-double v3, v1, v5
    .line 11: if-lez v3, :cond_14
    .line 13: return-wide v5
    .line 14: return-wide v1
    .line 15: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 17: new-instance v2, Ljava/lang/StringBuilder;
    .line 19: const-string v0, "Cannot coerce value to an empty range: maximum "
    .line 21: invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 24: invoke-virtual {v2, v5, v6}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 27: const-string v5, " is less than minimum "
    .line 29: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 35: const/16 v3, 46
    .line 37: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 40: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 43: move-result-object v2
    .line 44: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 47: throw v1
.end method

# direct methods
.method public static E0(Ln3/z;Ln3/u;ILd3/e;I)Ln3/o1;
    .registers 7

    .line 0: and-int/lit8 v0, v6, 1
    .line 2: if-eqz v0, :cond_6
    .line 4: sget-object v3, Lw2/k;->i:Lw2/k;
    .line 6: const/4 v0, 2
    .line 7: and-int/2addr v6, v0
    .line 8: const/4 v1, 1
    .line 9: if-eqz v6, :cond_12
    .line 11: move v4, v1
    .line 12: invoke-interface {v2}, Ln3/z;->getCoroutineContext()Lw2/j;
    .line 15: move-result-object v2
    .line 16: invoke-static {v2, v3, v1}, Ld2/b;->i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .line 19: move-result-object v2
    .line 20: sget-object v3, Ln3/h0;->a:Lkotlinx/coroutines/scheduling/d;
    .line 22: if-eq v2, v3, :cond_36
    .line 24: sget-object v6, Lw2/f;->i:Lw2/f;
    .line 26: invoke-interface {v2, v6}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 29: move-result-object v6
    .line 30: if-nez v6, :cond_36
    .line 32: invoke-interface {v2, v3}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 35: move-result-object v2
    .line 36: if-eqz v4, :cond_55
    .line 38: if-ne v4, v0, :cond_46
    .line 40: new-instance v3, Ln3/h1;
    .line 42: invoke-direct {v3, v2, v5}, Ln3/h1;-><init>(Lw2/j;Ld3/e;)V
    .line 45: goto :goto_51
    .line 46: new-instance v3, Ln3/o1;
    .line 48: invoke-direct {v3, v2, v1}, Ln3/a;-><init>(Lw2/j;Z)V
    .line 51: invoke-virtual {v3, v4, v3, v5}, Ln3/a;->b0(ILn3/a;Ld3/e;)V
    .line 54: return-object v3
    .line 55: const/4 v2, 0
    .line 56: throw v2
.end method

# direct methods
.method public static F(FFF)F
    .registers 5

    .line 0: cmpl-float v0, v3, v4
    .line 2: if-gtz v0, :cond_15
    .line 4: cmpg-float v0, v2, v3
    .line 6: if-gez v0, :cond_9
    .line 8: return v3
    .line 9: cmpl-float v3, v2, v4
    .line 11: if-lez v3, :cond_14
    .line 13: return v4
    .line 14: return v2
    .line 15: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 17: new-instance v0, Ljava/lang/StringBuilder;
    .line 19: const-string v1, "Cannot coerce value to an empty range: maximum "
    .line 21: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 24: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 27: const-string v4, " is less than minimum "
    .line 29: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 35: const/16 v3, 46
    .line 37: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 40: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 43: move-result-object v3
    .line 44: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 47: throw v2
.end method

# direct methods
.method public static F0(Ld3/a;)Ls2/b;
    .registers 3

    .line 0: sget-object v0, Ls2/j;->a:Ls2/j;
    .line 2: new-instance v1, Ls2/l;
    .line 4: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 7: iput-object v2, v1, Ls2/l;->i:Ld3/a;
    .line 9: iput-object v0, v1, Ls2/l;->j:Ljava/lang/Object;
    .line 11: return-object v1
.end method

# direct methods
.method public static G(III)I
    .registers 5

    .line 0: if-gt v3, v4, :cond_9
    .line 2: if-ge v2, v3, :cond_5
    .line 4: return v3
    .line 5: if-le v2, v4, :cond_8
    .line 7: return v4
    .line 8: return v2
    .line 9: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 11: new-instance v0, Ljava/lang/StringBuilder;
    .line 13: const-string v1, "Cannot coerce value to an empty range: maximum "
    .line 15: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 18: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 21: const-string v4, " is less than minimum "
    .line 23: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 29: const/16 v3, 46
    .line 31: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 34: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 37: move-result-object v3
    .line 38: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 41: throw v2
.end method

# direct methods
.method public static final G0(FFF)F
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: int-to-float v0, v0
    .line 2: sub-float/2addr v0, v3
    .line 3: mul-float/2addr v0, v1
    .line 4: mul-float/2addr v3, v2
    .line 5: add-float/2addr v3, v0
    .line 6: return v3
.end method

# direct methods
.method public static H(JJ)J
    .registers 7

    .line 0: const-wide/16 v0, 0
    .line 2: cmp-long v2, v0, v5
    .line 4: if-gtz v2, :cond_17
    .line 6: cmp-long v2, v3, v0
    .line 8: if-gez v2, :cond_11
    .line 10: return-wide v0
    .line 11: cmp-long v0, v3, v5
    .line 13: if-lez v0, :cond_16
    .line 15: return-wide v5
    .line 16: return-wide v3
    .line 17: new-instance v3, Ljava/lang/IllegalArgumentException;
    .line 19: new-instance v4, Ljava/lang/StringBuilder;
    .line 21: const-string v0, "Cannot coerce value to an empty range: maximum "
    .line 23: invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 26: invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 29: const-string v5, " is less than minimum 0."
    .line 31: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 34: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 37: move-result-object v4
    .line 38: invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 41: throw v3
.end method

# direct methods
.method public static H0(Ljava/lang/Object;)Ljava/util/List;
    .registers 2

    .line 0: invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;
    .line 3: move-result-object v1
    .line 4: const-string v0, "singletonList(element)"
    .line 6: invoke-static {v1, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: return-object v1
.end method

# direct methods
.method public static I(Ljava/lang/Comparable;Lj3/a;)Ljava/lang/Comparable;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "range"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-virtual {v3}, Lj3/a;->a()Z
    .line 13: move-result v0
    .line 14: if-nez v0, :cond_70
    .line 16: iget v0, v3, Lj3/a;->a:F
    .line 18: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 21: move-result-object v1
    .line 22: invoke-static {v2, v1}, Lj3/a;->b(Ljava/lang/Comparable;Ljava/lang/Comparable;)Z
    .line 25: move-result v1
    .line 26: if-eqz v1, :cond_43
    .line 28: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 31: move-result-object v1
    .line 32: invoke-static {v1, v2}, Lj3/a;->b(Ljava/lang/Comparable;Ljava/lang/Comparable;)Z
    .line 35: move-result v1
    .line 36: if-nez v1, :cond_43
    .line 38: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 41: move-result-object v2
    .line 42: goto :goto_69
    .line 43: iget v3, v3, Lj3/a;->b:F
    .line 45: invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 48: move-result-object v0
    .line 49: invoke-static {v0, v2}, Lj3/a;->b(Ljava/lang/Comparable;Ljava/lang/Comparable;)Z
    .line 52: move-result v0
    .line 53: if-eqz v0, :cond_69
    .line 55: invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 58: move-result-object v0
    .line 59: invoke-static {v2, v0}, Lj3/a;->b(Ljava/lang/Comparable;Ljava/lang/Comparable;)Z
    .line 62: move-result v0
    .line 63: if-nez v0, :cond_69
    .line 65: invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 68: move-result-object v2
    .line 69: return-object v2
    .line 70: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 72: new-instance v0, Ljava/lang/StringBuilder;
    .line 74: const-string v1, "Cannot coerce value to an empty range: "
    .line 76: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 79: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 82: const/16 v3, 46
    .line 84: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 87: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 90: move-result-object v3
    .line 91: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 94: throw v2
.end method

# direct methods
.method public static varargs I0([Ljava/lang/Object;)Ljava/util/List;
    .registers 2

    .line 0: const-string v0, "elements"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: array-length v0, v1
    .line 6: if-lez v0, :cond_13
    .line 8: invoke-static {v1}, Lt2/k;->J0([Ljava/lang/Object;)Ljava/util/List;
    .line 11: move-result-object v1
    .line 12: goto :goto_15
    .line 13: sget-object v1, Lt2/r;->i:Lt2/r;
    .line 15: return-object v1
.end method

# direct methods
.method public static J(II)I
    .registers 2

    .line 0: if-ge v0, v1, :cond_4
    .line 2: const/4 v0, -1
    .line 3: goto :goto_9
    .line 4: if-ne v0, v1, :cond_8
    .line 6: const/4 v0, 0
    .line 7: goto :goto_9
    .line 8: const/4 v0, 1
    .line 9: return v0
.end method

# direct methods
.method public static J0(Lw2/h;Lw2/i;)Lw2/j;
    .registers 3

    .line 0: const-string v0, "key"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v1}, Lw2/h;->getKey()Lw2/i;
    .line 8: move-result-object v0
    .line 9: invoke-static {v0, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 12: move-result v2
    .line 13: if-eqz v2, :cond_17
    .line 15: sget-object v1, Lw2/k;->i:Lw2/k;
    .line 17: return-object v1
.end method

# direct methods
.method public static K([B)[B
    .registers 4

    .line 0: new-instance v0, Ljava/util/zip/Deflater;
    .line 2: const/4 v1, 1
    .line 3: invoke-direct {v0, v1}, Ljava/util/zip/Deflater;-><init>(I)V
    .line 6: new-instance v1, Ljava/io/ByteArrayOutputStream;
    .line 8: invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V
    .line 11: new-instance v2, Ljava/util/zip/DeflaterOutputStream;
    .line 13: invoke-direct {v2, v1, v0}, Ljava/util/zip/DeflaterOutputStream;-><init>(Ljava/io/OutputStream;Ljava/util/zip/Deflater;)V
    .line 16: invoke-virtual {v2, v3}, Ljava/io/OutputStream;->write([B)V
    .line 19: invoke-virtual {v2}, Ljava/util/zip/DeflaterOutputStream;->close()V
    .line 22: invoke-virtual {v0}, Ljava/util/zip/Deflater;->end()V
    .line 25: invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    .line 28: move-result-object v3
    .line 29: return-object v3
    .line 30: move-exception v3
    .line 31: goto :goto_42
    .line 32: move-exception v3
    .line 33: invoke-virtual {v2}, Ljava/util/zip/DeflaterOutputStream;->close()V
    .line 36: goto :goto_41
    .line 37: move-exception v1
    .line 38: invoke-virtual {v3, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V
    .line 41: throw v3
    .line 42: invoke-virtual {v0}, Ljava/util/zip/Deflater;->end()V
    .line 45: throw v3
.end method

# direct methods
.method public static K0(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;
    .registers 10

    .line 0: invoke-virtual {v8}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    .line 3: move-result-object v8
    .line 4: const/4 v0, 0
    .line 5: const-string v1, "r"
    .line 7: invoke-static {v8, v9, v1, v0}, Ly1/j;->a(Landroid/content/ContentResolver;Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    .line 10: move-result-object v8
    .line 11: if-nez v8, :cond_19
    .line 13: if-eqz v8, :cond_18
    .line 15: invoke-virtual {v8}, Landroid/os/ParcelFileDescriptor;->close()V
    .line 18: return-object v0
    .line 19: new-instance v9, Ljava/io/FileInputStream;
    .line 21: invoke-virtual {v8}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;
    .line 24: move-result-object v1
    .line 25: invoke-direct {v9, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    .line 28: invoke-virtual {v9}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;
    .line 31: move-result-object v2
    .line 32: invoke-virtual {v2}, Ljava/nio/channels/FileChannel;->size()J
    .line 35: move-result-wide v6
    .line 36: sget-object v3, Ljava/nio/channels/FileChannel$MapMode;->READ_ONLY:Ljava/nio/channels/FileChannel$MapMode;
    .line 38: const-wide/16 v4, 0
    .line 40: invoke-virtual/range {v2 .. v7}, Ljava/nio/channels/FileChannel;->map(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    .line 43: move-result-object v1
    .line 44: invoke-virtual {v9}, Ljava/io/FileInputStream;->close()V
    .line 47: invoke-virtual {v8}, Landroid/os/ParcelFileDescriptor;->close()V
    .line 50: return-object v1
    .line 51: move-exception v9
    .line 52: goto :goto_63
    .line 53: move-exception v1
    .line 54: invoke-virtual {v9}, Ljava/io/FileInputStream;->close()V
    .line 57: goto :goto_62
    .line 58: move-exception v9
    .line 59: invoke-virtual {v1, v9}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V
    .line 62: throw v1
    .line 63: invoke-virtual {v8}, Landroid/os/ParcelFileDescriptor;->close()V
    .line 66: goto :goto_71
    .line 67: move-exception v8
    .line 68: invoke-virtual {v9, v8}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V
    .line 71: throw v9
    .line 72: return-object v0
.end method

# direct methods
.method public static final L(Lh/r;)Lh/r;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v4}, Ld2/b;->M0(Lh/r;)Lh/r;
    .line 8: move-result-object v0
    .line 9: invoke-virtual {v0}, Lh/r;->b()I
    .line 12: move-result v1
    .line 13: const/4 v2, 0
    .line 14: if-ge v2, v1, :cond_26
    .line 16: invoke-virtual {v4, v2}, Lh/r;->a(I)F
    .line 19: move-result v3
    .line 20: invoke-virtual {v0, v3, v2}, Lh/r;->e(FI)V
    .line 23: add-int/lit8 v2, v2, 1
    .line 25: goto :goto_14
    .line 26: return-object v0
.end method

# direct methods
.method public static varargs L0([Ljava/lang/Object;)Ljava/util/ArrayList;
    .registers 4

    .line 0: const-string v0, "elements"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: array-length v0, v3
    .line 6: if-nez v0, :cond_14
    .line 8: new-instance v3, Ljava/util/ArrayList;
    .line 10: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    .line 13: goto :goto_26
    .line 14: new-instance v0, Ljava/util/ArrayList;
    .line 16: new-instance v1, Lt2/i;
    .line 18: const/4 v2, 1
    .line 19: invoke-direct {v1, v3, v2}, Lt2/i;-><init>([Ljava/lang/Object;Z)V
    .line 22: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 25: move-object v3, v0
    .line 26: return-object v3
.end method

# direct methods
.method public static final M(Ljava/io/InputStream;Ljava/io/OutputStream;I)J
    .registers 8

    .line 0: new-array v7, v7, [B
    .line 2: invoke-virtual {v5, v7}, Ljava/io/InputStream;->read([B)I
    .line 5: move-result v0
    .line 6: const-wide/16 v1, 0
    .line 8: if-ltz v0, :cond_21
    .line 10: const/4 v3, 0
    .line 11: invoke-virtual {v6, v7, v3, v0}, Ljava/io/OutputStream;->write([BII)V
    .line 14: int-to-long v3, v0
    .line 15: add-long/2addr v1, v3
    .line 16: invoke-virtual {v5, v7}, Ljava/io/InputStream;->read([B)I
    .line 19: move-result v0
    .line 20: goto :goto_8
    .line 21: return-wide v1
.end method

# direct methods
.method public static final M0(Lh/r;)Lh/r;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v1}, Lh/r;->c()Lh/r;
    .line 8: move-result-object v1
    .line 9: const-string v0, "null cannot be cast to non-null type T of androidx.compose.animation.core.AnimationVectorsKt.newInstance"
    .line 11: invoke-static {v1, v0}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: return-object v1
.end method

# direct methods
.method public static N(Ljava/io/File;Landroid/content/res/Resources;I)Z
    .registers 3

    .line 0: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->openRawResource(I)Ljava/io/InputStream;
    .line 3: move-result-object v1
    .line 4: invoke-static {v0, v1}, Ld2/b;->O(Ljava/io/File;Ljava/io/InputStream;)Z
    .line 7: move-result v0
    .line 8: invoke-static {v1}, Ld2/b;->C(Ljava/io/Closeable;)V
    .line 11: return v0
    .line 12: move-exception v0
    .line 13: goto :goto_16
    .line 14: move-exception v0
    .line 15: const/4 v1, 0
    .line 16: invoke-static {v1}, Ld2/b;->C(Ljava/io/Closeable;)V
    .line 19: throw v0
.end method

# direct methods
.method public static N0(Landroid/widget/EdgeEffect;F)V
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 7: const/16 v1, 31
    .line 9: const/4 v2, 0
    .line 10: if-lt v0, v1, :cond_18
    .line 12: sget-object v0, Li/n;->a:Li/n;
    .line 14: invoke-virtual {v0, v3, v4, v2}, Li/n;->c(Landroid/widget/EdgeEffect;FF)F
    .line 17: return-void
    .line 18: invoke-virtual {v3, v4, v2}, Landroid/widget/EdgeEffect;->onPull(FF)V
    .line 21: return-void
.end method

# direct methods
.method public static O(Ljava/io/File;Ljava/io/InputStream;)Z
    .registers 7

    .line 0: invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskWrites()Landroid/os/StrictMode$ThreadPolicy;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: const/4 v2, 0
    .line 6: new-instance v3, Ljava/io/FileOutputStream;
    .line 8: invoke-direct {v3, v5, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V
    .line 11: const/16 v5, 1024
    .line 13: new-array v5, v5, [B
    .line 15: invoke-virtual {v6, v5}, Ljava/io/InputStream;->read([B)I
    .line 18: move-result v2
    .line 19: const/4 v4, -1
    .line 20: if-eq v2, v4, :cond_32
    .line 22: invoke-virtual {v3, v5, v1, v2}, Ljava/io/FileOutputStream;->write([BII)V
    .line 25: goto :goto_15
    .line 26: move-exception v5
    .line 27: move-object v2, v3
    .line 28: goto :goto_76
    .line 29: move-exception v5
    .line 30: move-object v2, v3
    .line 31: goto :goto_43
    .line 32: invoke-static {v3}, Ld2/b;->C(Ljava/io/Closeable;)V
    .line 35: invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V
    .line 38: const/4 v5, 1
    .line 39: return v5
    .line 40: move-exception v5
    .line 41: goto :goto_76
    .line 42: move-exception v5
    .line 43: const-string v6, "TypefaceCompatUtil"
    .line 45: new-instance v3, Ljava/lang/StringBuilder;
    .line 47: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 50: const-string v4, "Error copying resource contents to temp file: "
    .line 52: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 55: invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    .line 58: move-result-object v5
    .line 59: invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 62: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 65: move-result-object v5
    .line 66: invoke-static {v6, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    .line 69: invoke-static {v2}, Ld2/b;->C(Ljava/io/Closeable;)V
    .line 72: invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V
    .line 75: return v1
    .line 76: invoke-static {v2}, Ld2/b;->C(Ljava/io/Closeable;)V
    .line 79: invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V
    .line 82: throw v5
.end method

# direct methods
.method public static O0(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
    .registers 13

    .line 0: const-string v0, "moves"
    .line 2: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 8: move-result v0
    .line 9: sget-object v1, Lt2/r;->i:Lt2/r;
    .line 11: const/4 v2, 3
    .line 12: if-ne v0, v2, :cond_310
    .line 14: invoke-static {v12}, Lt2/p;->I1(Ljava/lang/Iterable;)Ljava/util/List;
    .line 17: move-result-object v0
    .line 18: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 21: move-result v0
    .line 22: if-eq v0, v2, :cond_26
    .line 24: goto/16 :goto_310
    .line 26: invoke-static {v12}, Lt2/p;->e2(Ljava/lang/Iterable;)Ljava/util/Set;
    .line 29: move-result-object v0
    .line 30: new-instance v2, Ljava/util/HashMap;
    .line 32: invoke-direct {v2}, Ljava/util/HashMap;-><init>()V
    .line 35: invoke-static {v11}, Lm3/j;->T1(Ljava/lang/CharSequence;)Ll3/g;
    .line 38: move-result-object v11
    .line 39: invoke-virtual {v11}, Ll3/g;->iterator()Ljava/util/Iterator;
    .line 42: move-result-object v11
    .line 43: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 46: move-result v3
    .line 47: const/4 v4, 1
    .line 48: const/4 v5, 0
    .line 49: if-eqz v3, :cond_179
    .line 51: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 54: move-result-object v3
    .line 55: check-cast v3, Ljava/lang/String;
    .line 57: const-string v6, "info "
    .line 59: invoke-static {v3, v6, v5}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 62: move-result v6
    .line 63: if-eqz v6, :cond_43
    .line 65: const-string v6, " pv "
    .line 67: invoke-static {v3, v6, v5}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 70: move-result v6
    .line 71: if-nez v6, :cond_74
    .line 73: goto :goto_43
    .line 74: new-array v6, v4, [C
    .line 76: const/16 v7, 32
    .line 78: aput-char v7, v6, v5
    .line 80: invoke-static {v3, v6}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 83: move-result-object v6
    .line 84: const-string v7, "pv"
    .line 86: invoke-interface {v6, v7}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I
    .line 89: move-result v7
    .line 90: add-int/2addr v7, v4
    .line 91: invoke-static {v7, v6}, Lt2/p;->M1(ILjava/util/List;)Ljava/lang/Object;
    .line 94: move-result-object v7
    .line 95: check-cast v7, Ljava/lang/String;
    .line 97: if-nez v7, :cond_100
    .line 99: goto :goto_43
    .line 100: invoke-interface {v0, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 103: move-result v8
    .line 104: if-eqz v8, :cond_43
    .line 106: invoke-static {v3}, Ld2/c;->o0(Ljava/lang/String;)Ljava/lang/Integer;
    .line 109: move-result-object v3
    .line 110: if-eqz v3, :cond_43
    .line 112: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    .line 115: move-result v3
    .line 116: const-string v8, "depth"
    .line 118: invoke-interface {v6, v8}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I
    .line 121: move-result v8
    .line 122: add-int/2addr v8, v4
    .line 123: invoke-static {v8, v6}, Lt2/p;->M1(ILjava/util/List;)Ljava/lang/Object;
    .line 126: move-result-object v4
    .line 127: check-cast v4, Ljava/lang/String;
    .line 129: if-eqz v4, :cond_141
    .line 131: invoke-static {v4}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 134: move-result-object v4
    .line 135: if-eqz v4, :cond_141
    .line 137: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    .line 140: move-result v5
    .line 141: invoke-virtual {v2, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 144: move-result-object v4
    .line 145: check-cast v4, Ls2/e;
    .line 147: if-eqz v4, :cond_158
    .line 149: iget-object v4, v4, Ls2/e;->i:Ljava/lang/Object;
    .line 151: check-cast v4, Ljava/lang/Number;
    .line 153: invoke-virtual {v4}, Ljava/lang/Number;->intValue()I
    .line 156: move-result v4
    .line 157: goto :goto_159
    .line 158: const/4 v4, -1
    .line 159: if-lt v5, v4, :cond_43
    .line 161: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 164: move-result-object v4
    .line 165: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 168: move-result-object v3
    .line 169: new-instance v5, Ls2/e;
    .line 171: invoke-direct {v5, v4, v3}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 174: invoke-virtual {v2, v7, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 177: goto/16 :goto_43
    .line 179: invoke-virtual {v2}, Ljava/util/HashMap;->keySet()Ljava/util/Set;
    .line 182: move-result-object v11
    .line 183: invoke-static {v11, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 186: move-result v11
    .line 187: if-nez v11, :cond_190
    .line 189: return-object v1
    .line 190: new-instance v11, Lt2/v;
    .line 192: new-instance v0, Lt2/o;
    .line 194: invoke-direct {v0, v5, v12}, Lt2/o;-><init>(ILjava/lang/Object;)V
    .line 197: invoke-direct {v11, v0}, Lt2/v;-><init>(Lt2/o;)V
    .line 200: new-instance v12, Landroidx/compose/ui/platform/g0;
    .line 202: const/4 v0, 2
    .line 203: invoke-direct {v12, v0, v2}, Landroidx/compose/ui/platform/g0;-><init>(ILjava/lang/Object;)V
    .line 206: new-instance v0, Landroidx/compose/ui/platform/g0;
    .line 208: invoke-direct {v0, v4, v12}, Landroidx/compose/ui/platform/g0;-><init>(ILjava/lang/Object;)V
    .line 211: invoke-static {v11, v0}, Lt2/p;->W1(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;
    .line 214: move-result-object v11
    .line 215: new-instance v12, Ljava/util/ArrayList;
    .line 217: invoke-static {v11}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 220: move-result v0
    .line 221: invoke-direct {v12, v0}, Ljava/util/ArrayList;-><init>(I)V
    .line 224: invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 227: move-result-object v11
    .line 228: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 231: move-result v0
    .line 232: if-eqz v0, :cond_309
    .line 234: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 237: move-result-object v0
    .line 238: add-int/lit8 v1, v5, 1
    .line 240: if-ltz v5, :cond_304
    .line 242: check-cast v0, Lt2/u;
    .line 244: new-instance v3, Lcom/titanchess/accessibility/o1;
    .line 246: iget-object v0, v0, Lt2/u;->b:Ljava/lang/Object;
    .line 248: move-object v4, v0
    .line 249: check-cast v4, Ljava/lang/String;
    .line 251: invoke-static {v0, v2}, Lt2/k;->T0(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;
    .line 254: move-result-object v0
    .line 255: check-cast v0, Ls2/e;
    .line 257: iget-object v0, v0, Ls2/e;->j:Ljava/lang/Object;
    .line 259: check-cast v0, Ljava/lang/Number;
    .line 261: invoke-virtual {v0}, Ljava/lang/Number;->intValue()I
    .line 264: move-result v0
    .line 265: const/16 v5, -1000
    .line 267: const/16 v6, 1000
    .line 269: invoke-static {v0, v5, v6}, Ld2/b;->G(III)I
    .line 272: move-result v0
    .line 273: const-wide v5, 0xbf6e29e1a5ccd8b6
    .line 278: int-to-double v7, v0
    .line 279: mul-double/2addr v7, v5
    .line 280: invoke-static {v7, v8}, Ljava/lang/Math;->exp(D)D
    .line 283: move-result-wide v5
    .line 284: const-wide/high16 v7, 0x3ff0
    .line 286: add-double/2addr v5, v7
    .line 287: const-wide/high16 v9, 0x4000
    .line 289: div-double/2addr v9, v5
    .line 290: sub-double/2addr v9, v7
    .line 291: const-wide/high16 v5, 0x3fe0
    .line 293: mul-double/2addr v9, v5
    .line 294: add-double/2addr v9, v5
    .line 295: double-to-float v0, v9
    .line 296: invoke-direct {v3, v4, v1, v0}, Lcom/titanchess/accessibility/o1;-><init>(Ljava/lang/String;IF)V
    .line 299: invoke-virtual {v12, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 302: move v5, v1
    .line 303: goto :goto_228
    .line 304: invoke-static {}, Ld2/b;->g1()V
    .line 307: const/4 v11, 0
    .line 308: throw v11
    .line 309: return-object v12
    .line 310: return-object v1
.end method

# direct methods
.method public static final P(Ld3/e;Lw2/e;)Ljava/lang/Object;
    .registers 4

    .line 0: new-instance v0, Lkotlinx/coroutines/internal/s;
    .line 2: invoke-interface {v3}, Lw2/e;->n()Lw2/j;
    .line 5: move-result-object v1
    .line 6: invoke-direct {v0, v3, v1}, Lkotlinx/coroutines/internal/s;-><init>(Lw2/e;Lw2/j;)V
    .line 9: invoke-static {v0, v0, v2}, Lkotlinx/coroutines/flow/c0;->j(Lkotlinx/coroutines/internal/s;Lkotlinx/coroutines/internal/s;Ld3/e;)Ljava/lang/Object;
    .line 12: move-result-object v2
    .line 13: return-object v2
.end method

# direct methods
.method public static final P0(Ljava/lang/String;)Z
    .registers 2

    .line 0: const-string v0, "method"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "GET"
    .line 7: invoke-static {v1, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 10: move-result v0
    .line 11: if-nez v0, :cond_23
    .line 13: const-string v0, "HEAD"
    .line 15: invoke-static {v1, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 18: move-result v1
    .line 19: if-nez v1, :cond_23
    .line 21: const/4 v1, 1
    .line 22: goto :goto_24
    .line 23: const/4 v1, 0
    .line 24: return v1
.end method

# direct methods
.method public static Q(Landroid/content/Context;)Landroid/widget/EdgeEffect;
    .registers 3

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 7: const/16 v1, 31
    .line 9: if-lt v0, v1, :cond_19
    .line 11: sget-object v0, Li/n;->a:Li/n;
    .line 13: const/4 v1, 0
    .line 14: invoke-virtual {v0, v2, v1}, Li/n;->a(Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/widget/EdgeEffect;
    .line 17: move-result-object v2
    .line 18: goto :goto_25
    .line 19: new-instance v0, Li/x0;
    .line 21: invoke-direct {v0, v2}, Li/x0;-><init>(Landroid/content/Context;)V
    .line 24: move-object v2, v0
    .line 25: return-object v2
.end method

# direct methods
.method public static Q0(Ljava/nio/MappedByteBuffer;)Li2/b;
    .registers 13

    .line 0: invoke-virtual {v12}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;
    .line 3: move-result-object v12
    .line 4: new-instance v0, Lu/d;
    .line 6: invoke-direct {v0, v12}, Lu/d;-><init>(Ljava/nio/ByteBuffer;)V
    .line 9: const/4 v1, 4
    .line 10: invoke-virtual {v0, v1}, Lu/d;->s(I)V
    .line 13: iget-object v2, v0, Lu/d;->b:Ljava/lang/Object;
    .line 15: check-cast v2, Ljava/nio/ByteBuffer;
    .line 17: invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getShort()S
    .line 20: move-result v2
    .line 21: const v3, 0xffff
    .line 24: and-int/2addr v2, v3
    .line 25: const/16 v3, 100
    .line 27: const-string v4, "Cannot read metadata."
    .line 29: if-gt v2, v3, :cond_185
    .line 31: const/4 v3, 6
    .line 32: invoke-virtual {v0, v3}, Lu/d;->s(I)V
    .line 35: const/4 v3, 0
    .line 36: move v5, v3
    .line 37: const-wide/16 v6, -1
    .line 39: if-ge v5, v2, :cond_68
    .line 41: iget-object v8, v0, Lu/d;->b:Ljava/lang/Object;
    .line 43: check-cast v8, Ljava/nio/ByteBuffer;
    .line 45: invoke-virtual {v8}, Ljava/nio/ByteBuffer;->getInt()I
    .line 48: move-result v8
    .line 49: invoke-virtual {v0, v1}, Lu/d;->s(I)V
    .line 52: invoke-virtual {v0}, Lu/d;->q()J
    .line 55: move-result-wide v9
    .line 56: invoke-virtual {v0, v1}, Lu/d;->s(I)V
    .line 59: const v11, 0x6d657461
    .line 62: if-ne v11, v8, :cond_65
    .line 64: goto :goto_69
    .line 65: add-int/lit8 v5, v5, 1
    .line 67: goto :goto_37
    .line 68: move-wide v9, v6
    .line 69: cmp-long v1, v9, v6
    .line 71: if-eqz v1, :cond_179
    .line 73: iget-object v1, v0, Lu/d;->b:Ljava/lang/Object;
    .line 75: check-cast v1, Ljava/nio/ByteBuffer;
    .line 77: invoke-virtual {v1}, Ljava/nio/Buffer;->position()I
    .line 80: move-result v1
    .line 81: int-to-long v1, v1
    .line 82: sub-long v1, v9, v1
    .line 84: long-to-int v1, v1
    .line 85: invoke-virtual {v0, v1}, Lu/d;->s(I)V
    .line 88: const/16 v1, 12
    .line 90: invoke-virtual {v0, v1}, Lu/d;->s(I)V
    .line 93: invoke-virtual {v0}, Lu/d;->q()J
    .line 96: move-result-wide v1
    .line 97: int-to-long v5, v3
    .line 98: cmp-long v5, v5, v1
    .line 100: if-gez v5, :cond_179
    .line 102: iget-object v5, v0, Lu/d;->b:Ljava/lang/Object;
    .line 104: check-cast v5, Ljava/nio/ByteBuffer;
    .line 106: invoke-virtual {v5}, Ljava/nio/ByteBuffer;->getInt()I
    .line 109: move-result v5
    .line 110: invoke-virtual {v0}, Lu/d;->q()J
    .line 113: move-result-wide v6
    .line 114: invoke-virtual {v0}, Lu/d;->q()J
    .line 117: const v8, 0x456d6a69
    .line 120: if-eq v8, v5, :cond_131
    .line 122: const v8, 0x656d6a69
    .line 125: if-ne v8, v5, :cond_128
    .line 127: goto :goto_131
    .line 128: add-int/lit8 v3, v3, 1
    .line 130: goto :goto_97
    .line 131: add-long/2addr v6, v9
    .line 132: long-to-int v0, v6
    .line 133: invoke-virtual {v12, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;
    .line 136: new-instance v0, Li2/b;
    .line 138: invoke-direct {v0}, Li2/c;-><init>()V
    .line 141: sget-object v1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;
    .line 143: invoke-virtual {v12, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    .line 146: invoke-virtual {v12}, Ljava/nio/Buffer;->position()I
    .line 149: move-result v1
    .line 150: invoke-virtual {v12, v1}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 153: move-result v1
    .line 154: invoke-virtual {v12}, Ljava/nio/Buffer;->position()I
    .line 157: move-result v2
    .line 158: add-int/2addr v2, v1
    .line 159: iput-object v12, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 161: iput v2, v0, Li2/c;->a:I
    .line 163: invoke-virtual {v12, v2}, Ljava/nio/ByteBuffer;->getInt(I)I
    .line 166: move-result v12
    .line 167: sub-int/2addr v2, v12
    .line 168: iput v2, v0, Li2/c;->c:I
    .line 170: iget-object v12, v0, Li2/c;->b:Ljava/nio/ByteBuffer;
    .line 172: invoke-virtual {v12, v2}, Ljava/nio/ByteBuffer;->getShort(I)S
    .line 175: move-result v12
    .line 176: iput v12, v0, Li2/c;->d:I
    .line 178: return-object v0
    .line 179: new-instance v12, Ljava/io/IOException;
    .line 181: invoke-direct {v12, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 184: throw v12
    .line 185: new-instance v12, Ljava/io/IOException;
    .line 187: invoke-direct {v12, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 190: throw v12
.end method

# direct methods
.method public static R(Landroid/content/Context;)Landroidx/emoji2/text/v;
    .registers 9

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 28
    .line 4: if-lt v0, v1, :cond_12
    .line 6: new-instance v0, Landroidx/emoji2/text/d;
    .line 8: invoke-direct {v0}, Landroidx/emoji2/text/c;-><init>()V
    .line 11: goto :goto_17
    .line 12: new-instance v0, Landroidx/emoji2/text/c;
    .line 14: invoke-direct {v0}, Landroidx/emoji2/text/c;-><init>()V
    .line 17: invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 20: move-result-object v1
    .line 21: const-string v2, "Package manager required to locate emoji font provider"
    .line 23: invoke-static {v1, v2}, Ld2/c;->s(Ljava/lang/Object;Ljava/lang/String;)V
    .line 26: new-instance v2, Landroid/content/Intent;
    .line 28: const-string v3, "androidx.content.action.LOAD_EMOJI_FONT"
    .line 30: invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    .line 33: const/4 v3, 0
    .line 34: invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->queryIntentContentProviders(Landroid/content/Intent;I)Ljava/util/List;
    .line 37: move-result-object v2
    .line 38: invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 41: move-result-object v2
    .line 42: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 45: move-result v4
    .line 46: const/4 v5, 0
    .line 47: if-eqz v4, :cond_70
    .line 49: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 52: move-result-object v4
    .line 53: check-cast v4, Landroid/content/pm/ResolveInfo;
    .line 55: iget-object v4, v4, Landroid/content/pm/ResolveInfo;->providerInfo:Landroid/content/pm/ProviderInfo;
    .line 57: if-eqz v4, :cond_42
    .line 59: iget-object v6, v4, Landroid/content/pm/ProviderInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;
    .line 61: if-eqz v6, :cond_42
    .line 63: iget v6, v6, Landroid/content/pm/ApplicationInfo;->flags:I
    .line 65: const/4 v7, 1
    .line 66: and-int/2addr v6, v7
    .line 67: if-ne v6, v7, :cond_42
    .line 69: goto :goto_71
    .line 70: move-object v4, v5
    .line 71: if-nez v4, :cond_75
    .line 73: move-object v1, v5
    .line 74: goto :goto_122
    .line 75: iget-object v2, v4, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;
    .line 77: iget-object v4, v4, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;
    .line 79: invoke-virtual {v0, v1, v4}, Lz3/b;->u(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
    .line 82: move-result-object v0
    .line 83: new-instance v1, Ljava/util/ArrayList;
    .line 85: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 88: array-length v6, v0
    .line 89: if-ge v3, v6, :cond_103
    .line 91: aget-object v7, v0, v3
    .line 93: invoke-virtual {v7}, Landroid/content/pm/Signature;->toByteArray()[B
    .line 96: move-result-object v7
    .line 97: invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 100: add-int/lit8 v3, v3, 1
    .line 102: goto :goto_89
    .line 103: invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;
    .line 106: move-result-object v0
    .line 107: new-instance v1, Lb2/e;
    .line 109: const-string v3, "emojicompat-emoji-font"
    .line 111: invoke-direct {v1, v2, v4, v3, v0}, Lb2/e;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .line 114: goto :goto_122
    .line 115: move-exception v0
    .line 116: const-string v1, "emoji2.text.DefaultEmojiConfig"
    .line 118: invoke-static {v1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 121: goto :goto_73
    .line 122: if-nez v1, :cond_125
    .line 124: goto :goto_135
    .line 125: new-instance v5, Landroidx/emoji2/text/v;
    .line 127: new-instance v0, Landroidx/emoji2/text/u;
    .line 129: invoke-direct {v0, v8, v1}, Landroidx/emoji2/text/u;-><init>(Landroid/content/Context;Lb2/e;)V
    .line 132: invoke-direct {v5, v0}, Landroidx/emoji2/text/h;-><init>(Landroidx/emoji2/text/j;)V
    .line 135: return-object v5
.end method

# direct methods
.method public static R0(Ljava/io/InputStream;I)[B
    .registers 5

    .line 0: new-array v0, v4, [B
    .line 2: const/4 v1, 0
    .line 3: if-ge v1, v4, :cond_27
    .line 5: sub-int v2, v4, v1
    .line 7: invoke-virtual {v3, v0, v1, v2}, Ljava/io/InputStream;->read([BII)I
    .line 10: move-result v2
    .line 11: if-ltz v2, :cond_15
    .line 13: add-int/2addr v1, v2
    .line 14: goto :goto_3
    .line 15: const-string v3, "Not enough bytes to read: "
    .line 17: invoke-static {v3, v4}, Lai/onnxruntime/b;->f(Ljava/lang/String;I)Ljava/lang/String;
    .line 20: move-result-object v3
    .line 21: new-instance v4, Ljava/lang/IllegalStateException;
    .line 23: invoke-direct {v4, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 26: throw v4
    .line 27: return-object v0
.end method

# direct methods
.method public static S(Landroid/os/Looper;)Landroid/os/Handler;
    .registers 8

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 28
    .line 4: if-lt v0, v1, :cond_11
    .line 6: invoke-static {v7}, Ld/d;->a(Landroid/os/Looper;)Landroid/os/Handler;
    .line 9: move-result-object v7
    .line 10: return-object v7
    .line 11: const-class v0, Landroid/os/Handler;
    .line 13: const/4 v1, 3
    .line 14: new-array v2, v1, [Ljava/lang/Class;
    .line 16: const-class v3, Landroid/os/Looper;
    .line 18: const/4 v4, 0
    .line 19: aput-object v3, v2, v4
    .line 21: const-class v3, Landroid/os/Handler$Callback;
    .line 23: const/4 v5, 1
    .line 24: aput-object v3, v2, v5
    .line 26: sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 28: const/4 v6, 2
    .line 29: aput-object v3, v2, v6
    .line 31: invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .line 34: move-result-object v0
    .line 35: new-array v1, v1, [Ljava/lang/Object;
    .line 37: aput-object v7, v1, v4
    .line 39: const/4 v2, 0
    .line 40: aput-object v2, v1, v5
    .line 42: sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 44: aput-object v2, v1, v6
    .line 46: invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    .line 49: move-result-object v0
    .line 50: check-cast v0, Landroid/os/Handler;
    .line 52: return-object v0
    .line 53: move-exception v7
    .line 54: goto :goto_61
    .line 55: move-exception v0
    .line 56: goto :goto_85
    .line 57: move-exception v0
    .line 58: goto :goto_85
    .line 59: move-exception v0
    .line 60: goto :goto_85
    .line 61: invoke-virtual {v7}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 64: move-result-object v7
    .line 65: instance-of v0, v7, Ljava/lang/RuntimeException;
    .line 67: if-nez v0, :cond_82
    .line 69: instance-of v0, v7, Ljava/lang/Error;
    .line 71: if-eqz v0, :cond_76
    .line 73: check-cast v7, Ljava/lang/Error;
    .line 75: throw v7
    .line 76: new-instance v0, Ljava/lang/RuntimeException;
    .line 78: invoke-direct {v0, v7}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 81: throw v0
    .line 82: check-cast v7, Ljava/lang/RuntimeException;
    .line 84: throw v7
    .line 85: const-string v1, "HandlerCompat"
    .line 87: const-string v2, "Unable to invoke Handler(Looper, Callback, boolean) constructor"
    .line 89: invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 92: new-instance v0, Landroid/os/Handler;
    .line 94: invoke-direct {v0, v7}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    .line 97: return-object v0
.end method

# direct methods
.method public static S0(Ljava/io/File;)[B
    .registers 10

    .line 0: new-instance v0, Ljava/io/FileInputStream;
    .line 2: invoke-direct {v0, v9}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    .line 5: invoke-virtual {v9}, Ljava/io/File;->length()J
    .line 8: move-result-wide v1
    .line 9: const-wide/32 v3, 0x7fffffff
    .line 12: cmp-long v3, v1, v3
    .line 14: const-string v4, "File "
    .line 16: if-gtz v3, :cond_129
    .line 18: long-to-int v1, v1
    .line 19: new-array v2, v1, [B
    .line 21: const/4 v3, 0
    .line 22: move v5, v1
    .line 23: move v6, v3
    .line 24: if-lez v5, :cond_38
    .line 26: invoke-virtual {v0, v2, v6, v5}, Ljava/io/FileInputStream;->read([BII)I
    .line 29: move-result v7
    .line 30: if-ltz v7, :cond_38
    .line 32: sub-int/2addr v5, v7
    .line 33: add-int/2addr v6, v7
    .line 34: goto :goto_24
    .line 35: move-exception v9
    .line 36: goto/16 :goto_160
    .line 38: const-string v7, "copyOf(this, newSize)"
    .line 40: if-lez v5, :cond_50
    .line 42: invoke-static {v2, v6}, Ljava/util/Arrays;->copyOf([BI)[B
    .line 45: move-result-object v2
    .line 46: invoke-static {v2, v7}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 49: goto :goto_98
    .line 50: invoke-virtual {v0}, Ljava/io/FileInputStream;->read()I
    .line 53: move-result v5
    .line 54: const/4 v6, -1
    .line 55: if-ne v5, v6, :cond_58
    .line 57: goto :goto_98
    .line 58: new-instance v6, Lc3/a;
    .line 60: const/16 v8, 8193
    .line 62: invoke-direct {v6, v8}, Ljava/io/ByteArrayOutputStream;-><init>(I)V
    .line 65: invoke-virtual {v6, v5}, Ljava/io/OutputStream;->write(I)V
    .line 68: const/16 v5, 8192
    .line 70: invoke-static {v0, v6, v5}, Ld2/b;->M(Ljava/io/InputStream;Ljava/io/OutputStream;I)J
    .line 73: invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->size()I
    .line 76: move-result v5
    .line 77: add-int/2addr v5, v1
    .line 78: if-ltz v5, :cond_103
    .line 80: invoke-virtual {v6}, Lc3/a;->a()[B
    .line 83: move-result-object v9
    .line 84: invoke-static {v2, v5}, Ljava/util/Arrays;->copyOf([BI)[B
    .line 87: move-result-object v2
    .line 88: invoke-static {v2, v7}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 91: invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->size()I
    .line 94: move-result v4
    .line 95: invoke-static {v1, v3, v4, v9, v2}, Lt2/k;->K0(III[B[B)V
    .line 98: const/4 v9, 0
    .line 99: invoke-static {v0, v9}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 102: return-object v2
    .line 103: new-instance v1, Ljava/lang/OutOfMemoryError;
    .line 105: new-instance v2, Ljava/lang/StringBuilder;
    .line 107: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    .line 110: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 113: invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 116: const-string v9, " is too big to fit in memory."
    .line 118: invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 121: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 124: move-result-object v9
    .line 125: invoke-direct {v1, v9}, Ljava/lang/OutOfMemoryError;-><init>(Ljava/lang/String;)V
    .line 128: throw v1
    .line 129: new-instance v3, Ljava/lang/OutOfMemoryError;
    .line 131: new-instance v5, Ljava/lang/StringBuilder;
    .line 133: invoke-direct {v5, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 136: invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 139: const-string v9, " is too big ("
    .line 141: invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 144: invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 147: const-string v9, " bytes) to fit in memory."
    .line 149: invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 152: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 155: move-result-object v9
    .line 156: invoke-direct {v3, v9}, Ljava/lang/OutOfMemoryError;-><init>(Ljava/lang/String;)V
    .line 159: throw v3
    .line 160: throw v9
    .line 161: move-exception v1
    .line 162: invoke-static {v0, v9}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 165: throw v1
.end method

# direct methods
.method public static T(Ljava/lang/Object;Lw2/e;Ld3/e;)Lw2/e;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "completion"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: instance-of v0, v4, Ly2/a;
    .line 12: if-eqz v0, :cond_21
    .line 14: check-cast v4, Ly2/a;
    .line 16: invoke-virtual {v4, v2, v3}, Ly2/a;->b(Ljava/lang/Object;Lw2/e;)Lw2/e;
    .line 19: move-result-object v2
    .line 20: goto :goto_42
    .line 21: invoke-interface {v3}, Lw2/e;->n()Lw2/j;
    .line 24: move-result-object v0
    .line 25: sget-object v1, Lw2/k;->i:Lw2/k;
    .line 27: if-ne v0, v1, :cond_36
    .line 29: new-instance v0, Lx2/b;
    .line 31: invoke-direct {v0, v2, v3, v4}, Lx2/b;-><init>(Ljava/lang/Object;Lw2/e;Ld3/e;)V
    .line 34: move-object v2, v0
    .line 35: goto :goto_42
    .line 36: new-instance v1, Lx2/c;
    .line 38: invoke-direct {v1, v3, v0, v4, v2}, Lx2/c;-><init>(Lw2/e;Lw2/j;Ld3/e;Ljava/lang/Object;)V
    .line 41: move-object v2, v1
    .line 42: return-object v2
.end method

# direct methods
.method public static final T0(Ljava/io/InputStream;)[B
    .registers 4

    .line 0: new-instance v0, Ljava/io/ByteArrayOutputStream;
    .line 2: invoke-virtual {v3}, Ljava/io/InputStream;->available()I
    .line 5: move-result v1
    .line 6: const/16 v2, 8192
    .line 8: invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I
    .line 11: move-result v1
    .line 12: invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V
    .line 15: invoke-static {v3, v0, v2}, Ld2/b;->M(Ljava/io/InputStream;Ljava/io/OutputStream;I)J
    .line 18: invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    .line 21: move-result-object v3
    .line 22: const-string v0, "buffer.toByteArray()"
    .line 24: invoke-static {v3, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 27: return-object v3
.end method

# direct methods
.method public static final U(Lh/n1;Lh/q1;Ljava/lang/String;Lu/l;)Lh/h1;
    .registers 8

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "typeConverter"
    .line 7: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: check-cast v7, Lu/b0;
    .line 12: const v0, 0x99d490e0
    .line 15: invoke-virtual {v7, v0}, Lu/b0;->d0(I)V
    .line 18: const v0, 0x44faf204
    .line 21: invoke-virtual {v7, v0}, Lu/b0;->d0(I)V
    .line 24: invoke-virtual {v7, v4}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 27: move-result v0
    .line 28: invoke-virtual {v7}, Lu/b0;->I()Ljava/lang/Object;
    .line 31: move-result-object v1
    .line 32: if-nez v0, :cond_38
    .line 34: sget-object v0, Lu/k;->i:Landroidx/activity/b;
    .line 36: if-ne v1, v0, :cond_46
    .line 38: new-instance v1, Lh/h1;
    .line 40: invoke-direct {v1, v4, v5, v6}, Lh/h1;-><init>(Lh/n1;Lh/q1;Ljava/lang/String;)V
    .line 43: invoke-virtual {v7, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 46: const/4 v5, 0
    .line 47: invoke-virtual {v7, v5}, Lu/b0;->t(Z)V
    .line 50: check-cast v1, Lh/h1;
    .line 52: new-instance v6, Lh/z0;
    .line 54: const/4 v0, 3
    .line 55: invoke-direct {v6, v4, v0, v1}, Lh/z0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 58: invoke-static {v1, v6, v7}, Lu/c0;->a(Ljava/lang/Object;Ld3/c;Lu/l;)V
    .line 61: invoke-virtual {v4}, Lh/n1;->d()Z
    .line 64: move-result v4
    .line 65: if-eqz v4, :cond_120
    .line 67: iget-object v4, v1, Lh/h1;->c:Lu/s1;
    .line 69: invoke-virtual {v4}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 72: move-result-object v4
    .line 73: check-cast v4, Lh/g1;
    .line 75: if-eqz v4, :cond_120
    .line 77: iget-object v6, v4, Lh/g1;->k:Ld3/c;
    .line 79: iget-object v0, v1, Lh/h1;->d:Lh/n1;
    .line 81: invoke-virtual {v0}, Lh/n1;->c()Lh/i1;
    .line 84: move-result-object v2
    .line 85: iget-object v2, v2, Lh/i1;->a:Ljava/lang/Object;
    .line 87: invoke-interface {v6, v2}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 90: move-result-object v6
    .line 91: iget-object v2, v4, Lh/g1;->k:Ld3/c;
    .line 93: invoke-virtual {v0}, Lh/n1;->c()Lh/i1;
    .line 96: move-result-object v3
    .line 97: iget-object v3, v3, Lh/i1;->b:Ljava/lang/Object;
    .line 99: invoke-interface {v2, v3}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 102: move-result-object v2
    .line 103: iget-object v3, v4, Lh/g1;->j:Ld3/c;
    .line 105: invoke-virtual {v0}, Lh/n1;->c()Lh/i1;
    .line 108: move-result-object v0
    .line 109: invoke-interface {v3, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 112: move-result-object v0
    .line 113: check-cast v0, Lh/b0;
    .line 115: iget-object v4, v4, Lh/g1;->i:Lh/j1;
    .line 117: invoke-virtual {v4, v6, v2, v0}, Lh/j1;->f(Ljava/lang/Object;Ljava/lang/Object;Lh/b0;)V
    .line 120: invoke-virtual {v7, v5}, Lu/b0;->t(Z)V
    .line 123: return-object v1
.end method

# direct methods
.method public static U0(Ljava/io/FileInputStream;II)[B
    .registers 11

    .line 0: new-instance v0, Ljava/util/zip/Inflater;
    .line 2: invoke-direct {v0}, Ljava/util/zip/Inflater;-><init>()V
    .line 5: new-array v1, v10, [B
    .line 7: const/16 v2, 2048
    .line 9: new-array v2, v2, [B
    .line 11: const/4 v3, 0
    .line 12: move v4, v3
    .line 13: move v5, v4
    .line 14: invoke-virtual {v0}, Ljava/util/zip/Inflater;->finished()Z
    .line 17: move-result v6
    .line 18: if-nez v6, :cond_87
    .line 20: invoke-virtual {v0}, Ljava/util/zip/Inflater;->needsDictionary()Z
    .line 23: move-result v6
    .line 24: if-nez v6, :cond_87
    .line 26: if-ge v4, v9, :cond_87
    .line 28: invoke-virtual {v8, v2}, Ljava/io/InputStream;->read([B)I
    .line 31: move-result v6
    .line 32: if-ltz v6, :cond_59
    .line 34: invoke-virtual {v0, v2, v3, v6}, Ljava/util/zip/Inflater;->setInput([BII)V
    .line 37: sub-int v7, v10, v5
    .line 39: invoke-virtual {v0, v1, v5, v7}, Ljava/util/zip/Inflater;->inflate([BII)I
    .line 42: move-result v7
    .line 43: add-int/2addr v5, v7
    .line 44: add-int/2addr v4, v6
    .line 45: goto :goto_14
    .line 46: move-exception v8
    .line 47: goto :goto_138
    .line 48: move-exception v8
    .line 49: invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    .line 52: move-result-object v8
    .line 53: new-instance v9, Ljava/lang/IllegalStateException;
    .line 55: invoke-direct {v9, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 58: throw v9
    .line 59: new-instance v8, Ljava/lang/StringBuilder;
    .line 61: invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V
    .line 64: const-string v10, "Invalid zip data. Stream ended after $totalBytesRead bytes. Expected "
    .line 66: invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 69: invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 72: const-string v9, " bytes"
    .line 74: invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 80: move-result-object v8
    .line 81: new-instance v9, Ljava/lang/IllegalStateException;
    .line 83: invoke-direct {v9, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 86: throw v9
    .line 87: if-ne v4, v9, :cond_107
    .line 89: invoke-virtual {v0}, Ljava/util/zip/Inflater;->finished()Z
    .line 92: move-result v8
    .line 93: if-eqz v8, :cond_99
    .line 95: invoke-virtual {v0}, Ljava/util/zip/Inflater;->end()V
    .line 98: return-object v1
    .line 99: const-string v8, "Inflater did not finish"
    .line 101: new-instance v9, Ljava/lang/IllegalStateException;
    .line 103: invoke-direct {v9, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 106: throw v9
    .line 107: new-instance v8, Ljava/lang/StringBuilder;
    .line 109: invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V
    .line 112: const-string v10, "Didn't read enough bytes during decompression. expected="
    .line 114: invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 117: invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 120: const-string v9, " actual="
    .line 122: invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 125: invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 128: invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 131: move-result-object v8
    .line 132: new-instance v9, Ljava/lang/IllegalStateException;
    .line 134: invoke-direct {v9, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 137: throw v9
    .line 138: invoke-virtual {v0}, Ljava/util/zip/Inflater;->end()V
    .line 141: throw v8
.end method

# direct methods
.method public static final V(Lh/n1;Ljava/lang/Object;Ljava/lang/Object;Lh/b0;Lh/q1;Ljava/lang/String;Lu/l;)Lh/j1;
    .registers 16

    .line 0: const-string v0, "animationSpec"
    .line 2: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "typeConverter"
    .line 7: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "label"
    .line 12: invoke-static {v14, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: check-cast v15, Lu/b0;
    .line 17: const v0, 0xedd4cc32
    .line 20: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 23: const v0, 0x44faf204
    .line 26: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 29: invoke-virtual {v15, v9}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 32: move-result v0
    .line 33: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 36: move-result-object v1
    .line 37: sget-object v2, Lu/k;->i:Landroidx/activity/b;
    .line 39: if-nez v0, :cond_43
    .line 41: if-ne v1, v2, :cond_68
    .line 43: new-instance v1, Lh/j1;
    .line 45: iget-object v0, v13, Lh/q1;->a:Ld3/c;
    .line 47: invoke-interface {v0, v11}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 50: move-result-object v0
    .line 51: check-cast v0, Lh/r;
    .line 53: invoke-static {v0}, Ld2/b;->M0(Lh/r;)Lh/r;
    .line 56: move-result-object v6
    .line 57: move-object v3, v1
    .line 58: move-object v4, v9
    .line 59: move-object v5, v10
    .line 60: move-object v7, v13
    .line 61: move-object v8, v14
    .line 62: invoke-direct/range {v3 .. v8}, Lh/j1;-><init>(Lh/n1;Ljava/lang/Object;Lh/r;Lh/q1;Ljava/lang/String;)V
    .line 65: invoke-virtual {v15, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 68: const/4 v13, 0
    .line 69: invoke-virtual {v15, v13}, Lu/b0;->t(Z)V
    .line 72: check-cast v1, Lh/j1;
    .line 74: invoke-virtual {v9}, Lh/n1;->d()Z
    .line 77: move-result v14
    .line 78: if-eqz v14, :cond_84
    .line 80: invoke-virtual {v1, v10, v11, v12}, Lh/j1;->f(Ljava/lang/Object;Ljava/lang/Object;Lh/b0;)V
    .line 83: goto :goto_87
    .line 84: invoke-virtual {v1, v11, v12}, Lh/j1;->g(Ljava/lang/Object;Lh/b0;)V
    .line 87: const v10, 0x1e7b2b64
    .line 90: invoke-virtual {v15, v10}, Lu/b0;->d0(I)V
    .line 93: invoke-virtual {v15, v9}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 96: move-result v10
    .line 97: invoke-virtual {v15, v1}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 100: move-result v11
    .line 101: or-int/2addr v10, v11
    .line 102: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 105: move-result-object v11
    .line 106: if-nez v10, :cond_110
    .line 108: if-ne v11, v2, :cond_119
    .line 110: new-instance v11, Lh/z0;
    .line 112: const/4 v10, 4
    .line 113: invoke-direct {v11, v9, v10, v1}, Lh/z0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 116: invoke-virtual {v15, v11}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 119: invoke-virtual {v15, v13}, Lu/b0;->t(Z)V
    .line 122: check-cast v11, Ld3/c;
    .line 124: invoke-static {v1, v11, v15}, Lu/c0;->a(Ljava/lang/Object;Ld3/c;Lu/l;)V
    .line 127: invoke-virtual {v15, v13}, Lu/b0;->t(Z)V
    .line 130: return-object v1
.end method

# direct methods
.method public static V0(Ljava/io/InputStream;I)J
    .registers 8

    .line 0: invoke-static {v6, v7}, Ld2/b;->R0(Ljava/io/InputStream;I)[B
    .line 3: move-result-object v6
    .line 4: const-wide/16 v0, 0
    .line 6: const/4 v2, 0
    .line 7: if-ge v2, v7, :cond_21
    .line 9: aget-byte v3, v6, v2
    .line 11: and-int/lit16 v3, v3, 255
    .line 13: int-to-long v3, v3
    .line 14: mul-int/lit8 v5, v2, 8
    .line 16: shl-long/2addr v3, v5
    .line 17: add-long/2addr v0, v3
    .line 18: add-int/lit8 v2, v2, 1
    .line 20: goto :goto_7
    .line 21: return-wide v0
.end method

# direct methods
.method public static W(Ljava/io/File;)Z
    .registers 7

    .line 0: invoke-virtual {v6}, Ljava/io/File;->isDirectory()Z
    .line 3: move-result v0
    .line 4: const/4 v1, 1
    .line 5: if-eqz v0, :cond_37
    .line 7: invoke-virtual {v6}, Ljava/io/File;->listFiles()[Ljava/io/File;
    .line 10: move-result-object v6
    .line 11: const/4 v0, 0
    .line 12: if-nez v6, :cond_15
    .line 14: return v0
    .line 15: array-length v2, v6
    .line 16: move v3, v0
    .line 17: move v4, v1
    .line 18: if-ge v3, v2, :cond_36
    .line 20: aget-object v5, v6, v3
    .line 22: invoke-static {v5}, Ld2/b;->W(Ljava/io/File;)Z
    .line 25: move-result v5
    .line 26: if-eqz v5, :cond_32
    .line 28: if-eqz v4, :cond_32
    .line 30: move v4, v1
    .line 31: goto :goto_33
    .line 32: move v4, v0
    .line 33: add-int/lit8 v3, v3, 1
    .line 35: goto :goto_18
    .line 36: return v4
    .line 37: invoke-virtual {v6}, Ljava/io/File;->delete()Z
    .line 40: return v1
.end method

# direct methods
.method public static final W0(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0: instance-of v0, v1, Ln3/p;
    .line 2: if-eqz v0, :cond_12
    .line 4: check-cast v1, Ln3/p;
    .line 6: iget-object v1, v1, Ln3/p;->a:Ljava/lang/Throwable;
    .line 8: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 11: move-result-object v1
    .line 12: return-object v1
.end method

# direct methods
.method public static final X(Lh/l;JFLh/i;Lh/n;Ld3/c;)V
    .registers 9

    .line 0: const/4 v0, 0
    .line 1: cmpg-float v0, v5, v0
    .line 3: if-nez v0, :cond_10
    .line 5: invoke-interface {v6}, Lh/i;->f()J
    .line 8: move-result-wide v0
    .line 9: goto :goto_17
    .line 10: iget-wide v0, v2, Lh/l;->c:J
    .line 12: sub-long v0, v3, v0
    .line 14: long-to-float v0, v0
    .line 15: div-float/2addr v0, v5
    .line 16: float-to-long v0, v0
    .line 17: iput-wide v3, v2, Lh/l;->g:J
    .line 19: invoke-interface {v6, v0, v1}, Lh/i;->d(J)Ljava/lang/Object;
    .line 22: move-result-object v3
    .line 23: iget-object v4, v2, Lh/l;->e:Lu/s1;
    .line 25: invoke-virtual {v4, v3}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 28: invoke-interface {v6, v0, v1}, Lh/i;->e(J)Lh/r;
    .line 31: move-result-object v3
    .line 32: const-string v4, "<set-?>"
    .line 34: invoke-static {v3, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: iput-object v3, v2, Lh/l;->f:Lh/r;
    .line 39: invoke-interface {v6, v0, v1}, Lh/i;->c(J)Z
    .line 42: move-result v3
    .line 43: if-eqz v3, :cond_56
    .line 45: iget-wide v3, v2, Lh/l;->g:J
    .line 47: iput-wide v3, v2, Lh/l;->h:J
    .line 49: iget-object v3, v2, Lh/l;->i:Lu/s1;
    .line 51: sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 53: invoke-virtual {v3, v4}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 56: invoke-static {v2, v7}, Ld2/b;->t1(Lh/l;Lh/n;)V
    .line 59: invoke-interface {v8, v2}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 62: return-void
.end method

# direct methods
.method public static final X0(Lo0/f;Lu/l;)Lo0/n0;
    .registers 15

    .line 0: const-string v0, "image"
    .line 2: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: check-cast v14, Lu/b0;
    .line 7: const v0, 0x544566b0
    .line 10: invoke-virtual {v14, v0}, Lu/b0;->d0(I)V
    .line 13: iget-object v2, v13, Lo0/f;->a:Ljava/lang/String;
    .line 15: new-instance v0, Lo0/o0;
    .line 17: const/4 v8, 0
    .line 18: invoke-direct {v0, v8, v13}, Lo0/o0;-><init>(ILjava/lang/Object;)V
    .line 21: const v1, 0x6fa7e78e
    .line 24: invoke-static {v14, v1, v0}, Ln3/a0;->A(Lu/l;ILe3/h;)Lb0/c;
    .line 27: move-result-object v5
    .line 28: const v0, 0x3fb166c2
    .line 31: invoke-virtual {v14, v0}, Lu/b0;->d0(I)V
    .line 34: sget-object v0, Landroidx/compose/ui/platform/i1;->e:Lu/j3;
    .line 36: invoke-virtual {v14, v0}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 39: move-result-object v0
    .line 40: check-cast v0, Lr1/b;
    .line 42: iget v1, v13, Lo0/f;->b:F
    .line 44: invoke-interface {v0, v1}, Lr1/b;->r0(F)F
    .line 47: move-result v1
    .line 48: iget v3, v13, Lo0/f;->c:F
    .line 50: invoke-interface {v0, v3}, Lr1/b;->r0(F)F
    .line 53: move-result v0
    .line 54: iget v3, v13, Lo0/f;->d:F
    .line 56: invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z
    .line 59: move-result v4
    .line 60: if-eqz v4, :cond_63
    .line 62: move v3, v1
    .line 63: iget v4, v13, Lo0/f;->e:F
    .line 65: invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z
    .line 68: move-result v6
    .line 69: if-eqz v6, :cond_72
    .line 71: move v4, v0
    .line 72: new-instance v6, Lk0/q;
    .line 74: iget-wide v9, v13, Lo0/f;->g:J
    .line 76: invoke-direct {v6, v9, v10}, Lk0/q;-><init>(J)V
    .line 79: new-instance v7, Lk0/i;
    .line 81: iget v11, v13, Lo0/f;->h:I
    .line 83: invoke-direct {v7, v11}, Lk0/i;-><init>(I)V
    .line 86: const v12, 0x1e7b2b64
    .line 89: invoke-virtual {v14, v12}, Lu/b0;->d0(I)V
    .line 92: invoke-virtual {v14, v6}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 95: move-result v6
    .line 96: invoke-virtual {v14, v7}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 99: move-result v7
    .line 100: or-int/2addr v6, v7
    .line 101: invoke-virtual {v14}, Lu/b0;->I()Ljava/lang/Object;
    .line 104: move-result-object v7
    .line 105: sget-object v12, Lu/k;->i:Landroidx/activity/b;
    .line 107: if-nez v6, :cond_111
    .line 109: if-ne v7, v12, :cond_156
    .line 111: sget-wide v6, Lk0/q;->g:J
    .line 113: invoke-static {v9, v10, v6, v7}, Lk0/q;->d(JJ)Z
    .line 116: move-result v6
    .line 117: if-nez v6, :cond_151
    .line 119: sget v6, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 121: const/16 v7, 29
    .line 123: if-lt v6, v7, :cond_132
    .line 125: sget-object v6, Lk0/k;->a:Lk0/k;
    .line 127: invoke-virtual {v6, v9, v10, v11}, Lk0/k;->a(JI)Landroid/graphics/BlendModeColorFilter;
    .line 130: move-result-object v6
    .line 131: goto :goto_145
    .line 132: new-instance v6, Landroid/graphics/PorterDuffColorFilter;
    .line 134: invoke-static {v9, v10}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 137: move-result v7
    .line 138: invoke-static {v11}, Landroidx/compose/ui/graphics/a;->v(I)Landroid/graphics/PorterDuff$Mode;
    .line 141: move-result-object v9
    .line 142: invoke-direct {v6, v7, v9}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V
    .line 145: new-instance v7, Lk0/r;
    .line 147: invoke-direct {v7, v6}, Lk0/r;-><init>(Landroid/graphics/ColorFilter;)V
    .line 150: goto :goto_153
    .line 151: const/4 v6, 0
    .line 152: move-object v7, v6
    .line 153: invoke-virtual {v14, v7}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 156: invoke-virtual {v14, v8}, Lu/b0;->t(Z)V
    .line 159: check-cast v7, Lk0/r;
    .line 161: const v6, 0xe2a708a4
    .line 164: invoke-virtual {v14, v6}, Lu/b0;->d0(I)V
    .line 167: invoke-virtual {v14}, Lu/b0;->I()Ljava/lang/Object;
    .line 170: move-result-object v6
    .line 171: if-ne v6, v12, :cond_181
    .line 173: new-instance v6, Lo0/n0;
    .line 175: invoke-direct {v6}, Lo0/n0;-><init>()V
    .line 178: invoke-virtual {v14, v6}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 181: invoke-virtual {v14, v8}, Lu/b0;->t(Z)V
    .line 184: move-object v9, v6
    .line 185: check-cast v9, Lo0/n0;
    .line 187: invoke-static {v1, v0}, Ld2/c;->f(FF)J
    .line 190: move-result-wide v0
    .line 191: iget-object v6, v9, Lo0/n0;->e:Lu/s1;
    .line 193: new-instance v10, Lj0/f;
    .line 195: invoke-direct {v10, v0, v1}, Lj0/f;-><init>(J)V
    .line 198: invoke-virtual {v6, v10}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 201: iget-boolean v13, v13, Lo0/f;->i:Z
    .line 203: invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 206: move-result-object v13
    .line 207: iget-object v0, v9, Lo0/n0;->f:Lu/s1;
    .line 209: invoke-virtual {v0, v13}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 212: iget-object v13, v9, Lo0/n0;->g:Lo0/e0;
    .line 214: iget-object v13, v13, Lo0/e0;->f:Lu/s1;
    .line 216: invoke-virtual {v13, v7}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 219: const v7, 0x8c00
    .line 222: move-object v1, v9
    .line 223: move-object v6, v14
    .line 224: invoke-virtual/range {v1 .. v7}, Lo0/n0;->e(Ljava/lang/String;FFLd3/g;Lu/l;I)V
    .line 227: invoke-virtual {v14, v8}, Lu/b0;->t(Z)V
    .line 230: invoke-virtual {v14, v8}, Lu/b0;->t(Z)V
    .line 233: return-object v9
.end method

# direct methods
.method public static final Y(Lf1/i;Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;I)V
    .registers 20

    .line 0: move-object v0, v12
    .line 1: iget-object v0, v0, Lf1/i;->h:Ljava/util/ArrayList;
    .line 3: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 6: move-result v1
    .line 7: const/4 v2, 0
    .line 8: if-ge v2, v1, :cond_46
    .line 10: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 13: move-result-object v3
    .line 14: check-cast v3, Lf1/l;
    .line 16: iget-object v4, v3, Lf1/l;->a:Lf1/a;
    .line 18: move-object v5, v13
    .line 19: move-object v6, v14
    .line 20: move v7, v15
    .line 21: move-object/from16 v8, v16
    .line 23: move-object/from16 v9, v17
    .line 25: move-object/from16 v10, v18
    .line 27: move/from16 v11, v19
    .line 29: invoke-virtual/range {v4 .. v11}, Lf1/a;->f(Lk0/o;Lk0/m;FLk0/k0;Lq1/m;Lm0/h;I)V
    .line 32: iget-object v3, v3, Lf1/l;->a:Lf1/a;
    .line 34: invoke-virtual {v3}, Lf1/a;->b()F
    .line 37: move-result v3
    .line 38: const/4 v4, 0
    .line 39: move-object v5, v13
    .line 40: invoke-interface {v13, v4, v3}, Lk0/o;->r(FF)V
    .line 43: add-int/lit8 v2, v2, 1
    .line 45: goto :goto_8
    .line 46: return-void
.end method

# direct methods
.method public static final Y0(Ln3/g0;Lw2/e;Z)V
    .registers 6

    .line 0: invoke-virtual {v3}, Ln3/g0;->h()Ljava/lang/Object;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v3, v0}, Ln3/g0;->d(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 7: move-result-object v1
    .line 8: if-eqz v1, :cond_15
    .line 10: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 13: move-result-object v3
    .line 14: goto :goto_19
    .line 15: invoke-virtual {v3, v0}, Ln3/g0;->e(Ljava/lang/Object;)Ljava/lang/Object;
    .line 18: move-result-object v3
    .line 19: if-eqz v5, :cond_75
    .line 21: check-cast v4, Lkotlinx/coroutines/internal/e;
    .line 23: iget-object v5, v4, Lkotlinx/coroutines/internal/e;->m:Lw2/e;
    .line 25: invoke-interface {v5}, Lw2/e;->n()Lw2/j;
    .line 28: move-result-object v0
    .line 29: iget-object v1, v4, Lkotlinx/coroutines/internal/e;->o:Ljava/lang/Object;
    .line 31: invoke-static {v0, v1}, Lkotlinx/coroutines/internal/b;->d(Lw2/j;Ljava/lang/Object;)Ljava/lang/Object;
    .line 34: move-result-object v1
    .line 35: sget-object v2, Lkotlinx/coroutines/internal/b;->e:Lkotlinx/coroutines/internal/u;
    .line 37: if-eq v1, v2, :cond_44
    .line 39: invoke-static {v5, v0, v1}, Ld2/b;->v1(Lw2/e;Lw2/j;Ljava/lang/Object;)Ln3/w1;
    .line 42: move-result-object v5
    .line 43: goto :goto_45
    .line 44: const/4 v5, 0
    .line 45: iget-object v4, v4, Lkotlinx/coroutines/internal/e;->m:Lw2/e;
    .line 47: invoke-interface {v4, v3}, Lw2/e;->c(Ljava/lang/Object;)V
    .line 50: if-eqz v5, :cond_58
    .line 52: invoke-virtual {v5}, Ln3/w1;->c0()Z
    .line 55: move-result v3
    .line 56: if-eqz v3, :cond_78
    .line 58: invoke-static {v0, v1}, Lkotlinx/coroutines/internal/b;->a(Lw2/j;Ljava/lang/Object;)V
    .line 61: goto :goto_78
    .line 62: move-exception v3
    .line 63: if-eqz v5, :cond_71
    .line 65: invoke-virtual {v5}, Ln3/w1;->c0()Z
    .line 68: move-result v4
    .line 69: if-eqz v4, :cond_74
    .line 71: invoke-static {v0, v1}, Lkotlinx/coroutines/internal/b;->a(Lw2/j;Ljava/lang/Object;)V
    .line 74: throw v3
    .line 75: invoke-interface {v4, v3}, Lw2/e;->c(Ljava/lang/Object;)V
    .line 78: return-void
.end method

# direct methods
.method public static final Z(Lkotlinx/coroutines/flow/f;Lp3/x;ZLw2/e;)Ljava/lang/Object;
    .registers 10

    .line 0: instance-of v0, v9, Lkotlinx/coroutines/flow/h;
    .line 2: if-eqz v0, :cond_19
    .line 4: move-object v0, v9
    .line 5: check-cast v0, Lkotlinx/coroutines/flow/h;
    .line 7: iget v1, v0, Lkotlinx/coroutines/flow/h;->p:I
    .line 9: const/high16 v2, 0x8000
    .line 11: and-int v3, v1, v2
    .line 13: if-eqz v3, :cond_19
    .line 15: sub-int/2addr v1, v2
    .line 16: iput v1, v0, Lkotlinx/coroutines/flow/h;->p:I
    .line 18: goto :goto_24
    .line 19: new-instance v0, Lkotlinx/coroutines/flow/h;
    .line 21: invoke-direct {v0, v9}, Ly2/c;-><init>(Lw2/e;)V
    .line 24: iget-object v9, v0, Lkotlinx/coroutines/flow/h;->o:Ljava/lang/Object;
    .line 26: sget-object v1, Lx2/a;->i:Lx2/a;
    .line 28: iget v2, v0, Lkotlinx/coroutines/flow/h;->p:I
    .line 30: const/4 v3, 2
    .line 31: const/4 v4, 1
    .line 32: if-eqz v2, :cond_76
    .line 34: if-eq v2, v4, :cond_62
    .line 36: if-ne v2, v3, :cond_54
    .line 38: iget-boolean v6, v0, Lkotlinx/coroutines/flow/h;->n:Z
    .line 40: iget-object v7, v0, Lkotlinx/coroutines/flow/h;->m:Lp3/a0;
    .line 42: iget-object v8, v0, Lkotlinx/coroutines/flow/h;->l:Lkotlinx/coroutines/flow/f;
    .line 44: invoke-static {v9}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 47: move-object v5, v8
    .line 48: move v8, v6
    .line 49: move-object v6, v5
    .line 50: goto :goto_79
    .line 51: move-exception v8
    .line 52: goto/16 :goto_186
    .line 54: new-instance v6, Ljava/lang/IllegalStateException;
    .line 56: const-string v7, "call to 'resume' before 'invoke' with coroutine"
    .line 58: invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 61: throw v6
    .line 62: iget-boolean v6, v0, Lkotlinx/coroutines/flow/h;->n:Z
    .line 64: iget-object v7, v0, Lkotlinx/coroutines/flow/h;->m:Lp3/a0;
    .line 66: iget-object v8, v0, Lkotlinx/coroutines/flow/h;->l:Lkotlinx/coroutines/flow/f;
    .line 68: invoke-static {v9}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 71: check-cast v9, Lp3/r;
    .line 73: iget-object v9, v9, Lp3/r;->a:Ljava/lang/Object;
    .line 75: goto :goto_97
    .line 76: invoke-static {v9}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 79: iput-object v6, v0, Lkotlinx/coroutines/flow/h;->l:Lkotlinx/coroutines/flow/f;
    .line 81: iput-object v7, v0, Lkotlinx/coroutines/flow/h;->m:Lp3/a0;
    .line 83: iput-boolean v8, v0, Lkotlinx/coroutines/flow/h;->n:Z
    .line 85: iput v4, v0, Lkotlinx/coroutines/flow/h;->p:I
    .line 87: invoke-interface {v7, v0}, Lp3/a0;->e(Lw2/e;)Ljava/lang/Object;
    .line 90: move-result-object v9
    .line 91: if-ne v9, v1, :cond_94
    .line 93: return-object v1
    .line 94: move v5, v8
    .line 95: move-object v8, v6
    .line 96: move v6, v5
    .line 97: instance-of v2, v9, Lp3/p;
    .line 99: if-eqz v2, :cond_127
    .line 101: instance-of v8, v9, Lp3/p;
    .line 103: const/4 v0, 0
    .line 104: if-eqz v8, :cond_109
    .line 106: check-cast v9, Lp3/p;
    .line 108: goto :goto_110
    .line 109: move-object v9, v0
    .line 110: if-eqz v9, :cond_115
    .line 112: iget-object v8, v9, Lp3/p;->a:Ljava/lang/Throwable;
    .line 114: goto :goto_116
    .line 115: move-object v8, v0
    .line 116: if-nez v8, :cond_126
    .line 118: if-eqz v6, :cond_123
    .line 120: invoke-static {v7, v0}, Ld2/b;->s(Lp3/a0;Ljava/lang/Throwable;)V
    .line 123: sget-object v6, Ls2/k;->a:Ls2/k;
    .line 125: return-object v6
    .line 126: throw v8
    .line 127: instance-of v2, v9, Lp3/q;
    .line 129: if-nez v2, :cond_146
    .line 131: iput-object v8, v0, Lkotlinx/coroutines/flow/h;->l:Lkotlinx/coroutines/flow/f;
    .line 133: iput-object v7, v0, Lkotlinx/coroutines/flow/h;->m:Lp3/a0;
    .line 135: iput-boolean v6, v0, Lkotlinx/coroutines/flow/h;->n:Z
    .line 137: iput v3, v0, Lkotlinx/coroutines/flow/h;->p:I
    .line 139: invoke-interface {v8, v9, v0}, Lkotlinx/coroutines/flow/f;->d(Ljava/lang/Object;Lw2/e;)Ljava/lang/Object;
    .line 142: move-result-object v9
    .line 143: if-ne v9, v1, :cond_47
    .line 145: return-object v1
    .line 146: instance-of v8, v9, Lp3/p;
    .line 148: if-eqz v8, :cond_158
    .line 150: move-object v8, v9
    .line 151: check-cast v8, Lp3/p;
    .line 153: iget-object v8, v8, Lp3/p;->a:Ljava/lang/Throwable;
    .line 155: if-eqz v8, :cond_158
    .line 157: throw v8
    .line 158: new-instance v8, Ljava/lang/IllegalStateException;
    .line 160: new-instance v0, Ljava/lang/StringBuilder;
    .line 162: const-string v1, "Trying to call 'getOrThrow' on a failed channel result: "
    .line 164: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 167: invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 170: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 173: move-result-object v9
    .line 174: invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 177: move-result-object v9
    .line 178: invoke-direct {v8, v9}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 181: throw v8
    .line 182: move-exception v6
    .line 183: move v5, v8
    .line 184: move-object v8, v6
    .line 185: move v6, v5
    .line 186: throw v8
    .line 187: move-exception v9
    .line 188: if-eqz v6, :cond_193
    .line 190: invoke-static {v7, v8}, Ld2/b;->s(Lp3/a0;Ljava/lang/Throwable;)V
    .line 193: throw v9
.end method

# direct methods
.method public static Z0(D)I
    .registers 4

    .line 0: invoke-static {v2, v3}, Ljava/lang/Double;->isNaN(D)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_34
    .line 6: const-wide v0, 0x41dfffffffc00
    .line 11: cmpl-double v0, v2, v0
    .line 13: if-lez v0, :cond_19
    .line 15: const v2, 0x7fffffff
    .line 18: goto :goto_33
    .line 19: const-wide/high16 v0, 0xc1e0
    .line 21: cmpg-double v0, v2, v0
    .line 23: if-gez v0, :cond_28
    .line 25: const/high16 v2, 0x8000
    .line 27: goto :goto_33
    .line 28: invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J
    .line 31: move-result-wide v2
    .line 32: long-to-int v2, v2
    .line 33: return v2
    .line 34: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 36: const-string v3, "Cannot round NaN value."
    .line 38: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 41: throw v2
.end method

# direct methods
.method public static a(F)Lh/d;
    .registers 5

    .line 0: new-instance v0, Lh/d;
    .line 2: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 5: move-result-object v4
    .line 6: sget-object v1, Lh/r1;->a:Lh/q1;
    .line 8: const v2, 0x3c23d70a
    .line 11: invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 14: move-result-object v2
    .line 15: const/16 v3, 8
    .line 17: invoke-direct {v0, v4, v1, v2, v3}, Lh/d;-><init>(Ljava/lang/Object;Lh/q1;Ljava/lang/Object;I)V
    .line 20: return-object v0
.end method

# direct methods
.method public static final a0(Lw2/j;)V
    .registers 2

    .line 0: sget-object v0, Ln3/v;->j:Ln3/v;
    .line 2: invoke-interface {v1, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Ln3/x0;
    .line 8: if-eqz v1, :cond_24
    .line 10: invoke-interface {v1}, Ln3/x0;->b()Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_17
    .line 16: goto :goto_24
    .line 17: check-cast v1, Ln3/g1;
    .line 19: invoke-virtual {v1}, Ln3/g1;->B()Ljava/util/concurrent/CancellationException;
    .line 22: move-result-object v1
    .line 23: throw v1
    .line 24: return-void
.end method

# direct methods
.method public static a1(F)I
    .registers 2

    .line 0: invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_11
    .line 6: invoke-static {v1}, Ljava/lang/Math;->round(F)I
    .line 9: move-result v1
    .line 10: return v1
    .line 11: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 13: const-string v0, "Cannot round NaN value."
    .line 15: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 18: throw v1
.end method

# direct methods
.method public static b(ILp3/m;I)Lp3/h;
    .registers 7

    .line 0: and-int/lit8 v0, v6, 1
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: move v4, v1
    .line 6: and-int/lit8 v6, v6, 2
    .line 8: sget-object v0, Lp3/m;->i:Lp3/m;
    .line 10: if-eqz v6, :cond_13
    .line 12: move-object v5, v0
    .line 13: const/4 v6, -2
    .line 14: const/4 v2, 1
    .line 15: const/4 v3, 0
    .line 16: if-eq v4, v6, :cond_87
    .line 18: const/4 v6, -1
    .line 19: if-eq v4, v6, :cond_67
    .line 21: if-eqz v4, :cond_53
    .line 23: const v6, 0x7fffffff
    .line 26: if-eq v4, v6, :cond_47
    .line 28: if-ne v4, v2, :cond_40
    .line 30: sget-object v6, Lp3/m;->j:Lp3/m;
    .line 32: if-ne v5, v6, :cond_40
    .line 34: new-instance v4, Lp3/v;
    .line 36: invoke-direct {v4, v3}, Lp3/v;-><init>(Ld3/c;)V
    .line 39: goto :goto_101
    .line 40: new-instance v6, Lp3/l;
    .line 42: invoke-direct {v6, v4, v5, v3}, Lp3/l;-><init>(ILp3/m;Ld3/c;)V
    .line 45: move-object v4, v6
    .line 46: goto :goto_101
    .line 47: new-instance v4, Lp3/w;
    .line 49: invoke-direct {v4, v1, v3}, Lp3/w;-><init>(ILd3/c;)V
    .line 52: goto :goto_101
    .line 53: if-ne v5, v0, :cond_61
    .line 55: new-instance v4, Lp3/w;
    .line 57: invoke-direct {v4, v2, v3}, Lp3/w;-><init>(ILd3/c;)V
    .line 60: goto :goto_101
    .line 61: new-instance v4, Lp3/l;
    .line 63: invoke-direct {v4, v2, v5, v3}, Lp3/l;-><init>(ILp3/m;Ld3/c;)V
    .line 66: goto :goto_101
    .line 67: if-ne v5, v0, :cond_75
    .line 69: new-instance v4, Lp3/v;
    .line 71: invoke-direct {v4, v3}, Lp3/v;-><init>(Ld3/c;)V
    .line 74: goto :goto_101
    .line 75: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 77: const-string v5, "CONFLATED capacity cannot be used with non-default onBufferOverflow"
    .line 79: invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 82: move-result-object v5
    .line 83: invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 86: throw v4
    .line 87: new-instance v4, Lp3/l;
    .line 89: if-ne v5, v0, :cond_98
    .line 91: sget-object v6, Lp3/o;->c:Lp3/n;
    .line 93: invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 96: sget v2, Lp3/n;->b:I
    .line 98: invoke-direct {v4, v2, v5, v3}, Lp3/l;-><init>(ILp3/m;Ld3/c;)V
    .line 101: return-object v4
.end method

# direct methods
.method public static final b0(II)Z
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 1
    .line 3: goto :goto_5
    .line 4: const/4 v0, 0
    .line 5: return v0
.end method

# direct methods
.method public static final b1(Ln3/i1;Ld3/e;)Ljava/lang/Object;
    .registers 8

    .line 0: invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;
    .line 3: move-result-object v0
    .line 4: sget-object v1, Lw2/f;->i:Lw2/f;
    .line 6: invoke-virtual {v6, v1}, Ln3/u;->I(Lw2/i;)Lw2/h;
    .line 9: move-result-object v2
    .line 10: check-cast v2, Lw2/g;
    .line 12: sget-object v3, Lw2/k;->i:Lw2/k;
    .line 14: const/4 v4, 1
    .line 15: if-nez v2, :cond_44
    .line 17: invoke-static {}, Ln3/r1;->a()Ln3/r0;
    .line 20: move-result-object v2
    .line 21: invoke-static {v6, v2}, Ld2/c;->p0(Lw2/j;Lw2/j;)Lw2/j;
    .line 24: move-result-object v6
    .line 25: invoke-static {v3, v6, v4}, Ld2/b;->i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .line 28: move-result-object v6
    .line 29: sget-object v3, Ln3/h0;->a:Lkotlinx/coroutines/scheduling/d;
    .line 31: if-eq v6, v3, :cond_76
    .line 33: invoke-interface {v6, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 36: move-result-object v1
    .line 37: if-nez v1, :cond_76
    .line 39: invoke-interface {v6, v3}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 42: move-result-object v6
    .line 43: goto :goto_76
    .line 44: instance-of v5, v2, Ln3/r0;
    .line 46: if-eqz v5, :cond_50
    .line 48: check-cast v2, Ln3/r0;
    .line 50: sget-object v2, Ln3/r1;->a:Ljava/lang/ThreadLocal;
    .line 52: invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    .line 55: move-result-object v2
    .line 56: check-cast v2, Ln3/r0;
    .line 58: invoke-static {v3, v6, v4}, Ld2/b;->i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .line 61: move-result-object v6
    .line 62: sget-object v3, Ln3/h0;->a:Lkotlinx/coroutines/scheduling/d;
    .line 64: if-eq v6, v3, :cond_76
    .line 66: invoke-interface {v6, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 69: move-result-object v1
    .line 70: if-nez v1, :cond_76
    .line 72: invoke-interface {v6, v3}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 75: move-result-object v6
    .line 76: new-instance v1, Ln3/d;
    .line 78: invoke-direct {v1, v6, v0, v2}, Ln3/d;-><init>(Lw2/j;Ljava/lang/Thread;Ln3/r0;)V
    .line 81: invoke-virtual {v1, v4, v1, v7}, Ln3/a;->b0(ILn3/a;Ld3/e;)V
    .line 84: const/4 v6, 0
    .line 85: iget-object v7, v1, Ln3/d;->l:Ln3/r0;
    .line 87: if-eqz v7, :cond_94
    .line 89: sget v0, Ln3/r0;->n:I
    .line 91: invoke-virtual {v7, v6}, Ln3/r0;->S(Z)V
    .line 94: invoke-static {}, Ljava/lang/Thread;->interrupted()Z
    .line 97: move-result v0
    .line 98: if-nez v0, :cond_157
    .line 100: if-eqz v7, :cond_109
    .line 102: invoke-virtual {v7}, Ln3/r0;->U()J
    .line 105: move-result-wide v2
    .line 106: goto :goto_114
    .line 107: move-exception v0
    .line 108: goto :goto_166
    .line 109: const-wide v2, 0x7fffffffffffffff
    .line 114: invoke-virtual {v1}, Ln3/g1;->H()Ljava/lang/Object;
    .line 117: move-result-object v0
    .line 118: instance-of v0, v0, Ln3/u0;
    .line 120: xor-int/2addr v0, v4
    .line 121: if-nez v0, :cond_127
    .line 123: invoke-static {v1, v2, v3}, Ljava/util/concurrent/locks/LockSupport;->parkNanos(Ljava/lang/Object;J)V
    .line 126: goto :goto_94
    .line 127: if-eqz v7, :cond_134
    .line 129: sget v0, Ln3/r0;->n:I
    .line 131: invoke-virtual {v7, v6}, Ln3/r0;->P(Z)V
    .line 134: invoke-virtual {v1}, Ln3/g1;->H()Ljava/lang/Object;
    .line 137: move-result-object v6
    .line 138: invoke-static {v6}, Ln3/a0;->T(Ljava/lang/Object;)Ljava/lang/Object;
    .line 141: move-result-object v6
    .line 142: instance-of v7, v6, Ln3/p;
    .line 144: if-eqz v7, :cond_150
    .line 146: move-object v7, v6
    .line 147: check-cast v7, Ln3/p;
    .line 149: goto :goto_151
    .line 150: const/4 v7, 0
    .line 151: if-nez v7, :cond_154
    .line 153: return-object v6
    .line 154: iget-object v6, v7, Ln3/p;->a:Ljava/lang/Throwable;
    .line 156: throw v6
    .line 157: new-instance v0, Ljava/lang/InterruptedException;
    .line 159: invoke-direct {v0}, Ljava/lang/InterruptedException;-><init>()V
    .line 162: invoke-virtual {v1, v0}, Ln3/g1;->r(Ljava/lang/Object;)Z
    .line 165: throw v0
    .line 166: if-eqz v7, :cond_173
    .line 168: sget v1, Ln3/r0;->n:I
    .line 170: invoke-virtual {v7, v6}, Ln3/r0;->P(Z)V
    .line 173: throw v0
.end method

# direct methods
.method public static final c(Lw2/j;)Lkotlinx/coroutines/internal/d;
    .registers 4

    .line 0: new-instance v0, Lkotlinx/coroutines/internal/d;
    .line 2: sget-object v1, Ln3/v;->j:Ln3/v;
    .line 4: invoke-interface {v3, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 7: move-result-object v1
    .line 8: if-eqz v1, :cond_11
    .line 10: goto :goto_21
    .line 11: new-instance v1, Ln3/a1;
    .line 13: const/4 v2, 0
    .line 14: invoke-direct {v1, v2}, Ln3/a1;-><init>(Ln3/x0;)V
    .line 17: invoke-interface {v3, v1}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 20: move-result-object v3
    .line 21: invoke-direct {v0, v3}, Lkotlinx/coroutines/internal/d;-><init>(Lw2/j;)V
    .line 24: return-object v0
.end method

# direct methods
.method public static final c0(II)Z
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 1
    .line 3: goto :goto_5
    .line 4: const/4 v0, 0
    .line 5: return v0
.end method

# direct methods
.method public static c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .registers 7

    .line 0: invoke-virtual {v6}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;
    .line 3: move-result-object v0
    .line 4: array-length v1, v0
    .line 5: const/4 v2, -1
    .line 6: const/4 v3, 0
    .line 7: if-ge v3, v1, :cond_25
    .line 9: aget-object v4, v0, v3
    .line 11: invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;
    .line 14: move-result-object v4
    .line 15: invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 18: move-result v4
    .line 19: if-eqz v4, :cond_22
    .line 21: move v2, v3
    .line 22: add-int/lit8 v3, v3, 1
    .line 24: goto :goto_7
    .line 25: add-int/lit8 v2, v2, 1
    .line 27: invoke-static {v0, v2, v1}, Ljava/util/Arrays;->copyOfRange([Ljava/lang/Object;II)[Ljava/lang/Object;
    .line 30: move-result-object v5
    .line 31: check-cast v5, [Ljava/lang/StackTraceElement;
    .line 33: invoke-virtual {v6, v5}, Ljava/lang/Throwable;->setStackTrace([Ljava/lang/StackTraceElement;)V
    .line 36: return-void
.end method

# direct methods
.method public static final d(Landroid/content/Context;)Lr1/c;
    .registers 3

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 8: move-result-object v0
    .line 9: invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    .line 12: move-result-object v0
    .line 13: iget v0, v0, Landroid/util/DisplayMetrics;->density:F
    .line 15: invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 18: move-result-object v2
    .line 19: invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    .line 22: move-result-object v2
    .line 23: iget v2, v2, Landroid/content/res/Configuration;->fontScale:F
    .line 25: new-instance v1, Lr1/c;
    .line 27: invoke-direct {v1, v0, v2}, Lr1/c;-><init>(FF)V
    .line 30: return-object v1
.end method

# direct methods
.method public static final d0(II)Z
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 1
    .line 3: goto :goto_5
    .line 4: const/4 v0, 0
    .line 5: return v0
.end method

# direct methods
.method public static final d1(Ln3/t1;Lk1/h;)Ljava/lang/Object;
    .registers 6

    .line 0: iget-object v0, v4, Lkotlinx/coroutines/internal/s;->k:Lw2/e;
    .line 2: invoke-interface {v0}, Lw2/e;->n()Lw2/j;
    .line 5: move-result-object v0
    .line 6: sget-object v1, Lw2/f;->i:Lw2/f;
    .line 8: invoke-interface {v0, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 11: move-result-object v0
    .line 12: instance-of v1, v0, Ln3/d0;
    .line 14: if-eqz v1, :cond_19
    .line 16: check-cast v0, Ln3/d0;
    .line 18: goto :goto_20
    .line 19: const/4 v0, 0
    .line 20: if-nez v0, :cond_24
    .line 22: sget-object v0, Ln3/c0;->a:Ln3/d0;
    .line 24: iget-wide v1, v4, Ln3/t1;->l:J
    .line 26: iget-object v3, v4, Ln3/a;->j:Lw2/j;
    .line 28: invoke-interface {v0, v1, v2, v4, v3}, Ln3/d0;->h(JLjava/lang/Runnable;Lw2/j;)Ln3/i0;
    .line 31: move-result-object v0
    .line 32: new-instance v1, Ln3/k0;
    .line 34: const/4 v2, 0
    .line 35: invoke-direct {v1, v2, v0}, Ln3/k0;-><init>(ILjava/lang/Object;)V
    .line 38: const/4 v0, 1
    .line 39: invoke-virtual {v4, v2, v0, v1}, Ln3/g1;->M(ZZLd3/c;)Ln3/i0;
    .line 42: const/4 v0, 2
    .line 43: invoke-static {v0, v5}, Ld2/c;->n(ILjava/lang/Object;)V
    .line 46: invoke-virtual {v5, v4, v4}, Lk1/h;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 49: move-result-object v5
    .line 50: goto :goto_58
    .line 51: move-exception v5
    .line 52: new-instance v0, Ln3/p;
    .line 54: invoke-direct {v0, v5, v2}, Ln3/p;-><init>(Ljava/lang/Throwable;Z)V
    .line 57: move-object v5, v0
    .line 58: sget-object v0, Lx2/a;->i:Lx2/a;
    .line 60: if-ne v5, v0, :cond_63
    .line 62: goto :goto_107
    .line 63: invoke-virtual {v4, v5}, Ln3/g1;->P(Ljava/lang/Object;)Ljava/lang/Object;
    .line 66: move-result-object v1
    .line 67: sget-object v2, Ln3/a0;->e:Lkotlinx/coroutines/internal/u;
    .line 69: if-ne v1, v2, :cond_72
    .line 71: goto :goto_107
    .line 72: instance-of v0, v1, Ln3/p;
    .line 74: if-eqz v0, :cond_102
    .line 76: check-cast v1, Ln3/p;
    .line 78: iget-object v0, v1, Ln3/p;->a:Ljava/lang/Throwable;
    .line 80: instance-of v1, v0, Ln3/s1;
    .line 82: if-eqz v1, :cond_101
    .line 84: move-object v1, v0
    .line 85: check-cast v1, Ln3/s1;
    .line 87: iget-object v1, v1, Ln3/s1;->i:Ln3/x0;
    .line 89: if-ne v1, v4, :cond_101
    .line 91: instance-of v4, v5, Ln3/p;
    .line 93: if-nez v4, :cond_96
    .line 95: goto :goto_106
    .line 96: check-cast v5, Ln3/p;
    .line 98: iget-object v4, v5, Ln3/p;->a:Ljava/lang/Throwable;
    .line 100: throw v4
    .line 101: throw v0
    .line 102: invoke-static {v1}, Ln3/a0;->T(Ljava/lang/Object;)Ljava/lang/Object;
    .line 105: move-result-object v5
    .line 106: move-object v0, v5
    .line 107: return-object v0
.end method

# direct methods
.method public static final e(FF)J
    .registers 6

    .line 0: invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v4
    .line 4: int-to-long v0, v4
    .line 5: invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 8: move-result v4
    .line 9: int-to-long v4, v4
    .line 10: const/16 v2, 32
    .line 12: shl-long/2addr v0, v2
    .line 13: const-wide v2, 0x00ffffffff
    .line 18: and-long/2addr v4, v2
    .line 19: or-long/2addr v4, v0
    .line 20: sget v0, Lr1/e;->c:I
    .line 22: return-wide v4
.end method

# direct methods
.method public static e0(Ljava/util/ArrayList;Ljava/lang/String;Lk1/t;I)Ljava/lang/String;
    .registers 12

    .line 0: and-int/lit8 v0, v11, 1
    .line 2: if-eqz v0, :cond_6
    .line 4: const-string v9, ", "
    .line 6: and-int/lit8 v0, v11, 2
    .line 8: const/4 v1, 0
    .line 9: const-string v2, ""
    .line 11: if-eqz v0, :cond_15
    .line 13: move-object v0, v2
    .line 14: goto :goto_16
    .line 15: move-object v0, v1
    .line 16: and-int/lit8 v3, v11, 4
    .line 18: if-eqz v3, :cond_21
    .line 20: goto :goto_22
    .line 21: move-object v2, v1
    .line 22: and-int/lit8 v3, v11, 8
    .line 24: const/4 v4, 0
    .line 25: if-eqz v3, :cond_29
    .line 27: const/4 v3, -1
    .line 28: goto :goto_30
    .line 29: move v3, v4
    .line 30: and-int/lit8 v5, v11, 16
    .line 32: if-eqz v5, :cond_37
    .line 34: const-string v5, "..."
    .line 36: goto :goto_38
    .line 37: move-object v5, v1
    .line 38: and-int/lit8 v11, v11, 32
    .line 40: if-eqz v11, :cond_43
    .line 42: move-object v10, v1
    .line 43: const-string v11, "<this>"
    .line 45: invoke-static {v8, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 48: const-string v11, "separator"
    .line 50: invoke-static {v9, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 53: const-string v11, "prefix"
    .line 55: invoke-static {v0, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 58: const-string v11, "postfix"
    .line 60: invoke-static {v2, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 63: const-string v11, "truncated"
    .line 65: invoke-static {v5, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 68: new-instance v11, Ljava/lang/StringBuilder;
    .line 70: invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V
    .line 73: invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 76: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 79: move-result v0
    .line 80: move v1, v4
    .line 81: if-ge v4, v0, :cond_148
    .line 83: invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 86: move-result-object v6
    .line 87: add-int/lit8 v1, v1, 1
    .line 89: const/4 v7, 1
    .line 90: if-le v1, v7, :cond_95
    .line 92: invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 95: if-ltz v3, :cond_99
    .line 97: if-gt v1, v3, :cond_148
    .line 99: if-eqz v10, :cond_111
    .line 101: invoke-virtual {v10, v6}, Lk1/t;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 104: move-result-object v6
    .line 105: check-cast v6, Ljava/lang/CharSequence;
    .line 107: invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 110: goto :goto_145
    .line 111: if-nez v6, :cond_114
    .line 113: goto :goto_118
    .line 114: instance-of v7, v6, Ljava/lang/CharSequence;
    .line 116: if-eqz v7, :cond_124
    .line 118: check-cast v6, Ljava/lang/CharSequence;
    .line 120: invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 123: goto :goto_145
    .line 124: instance-of v7, v6, Ljava/lang/Character;
    .line 126: if-eqz v7, :cond_138
    .line 128: check-cast v6, Ljava/lang/Character;
    .line 130: invoke-virtual {v6}, Ljava/lang/Character;->charValue()C
    .line 133: move-result v6
    .line 134: invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;
    .line 137: goto :goto_145
    .line 138: invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    .line 141: move-result-object v6
    .line 142: invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 145: add-int/lit8 v4, v4, 1
    .line 147: goto :goto_81
    .line 148: if-ltz v3, :cond_155
    .line 150: if-le v1, v3, :cond_155
    .line 152: invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 155: invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 158: invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 161: move-result-object v8
    .line 162: const-string v9, "fastJoinTo(StringBuilder…form)\n        .toString()"
    .line 164: invoke-static {v8, v9}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 167: return-object v8
.end method

# direct methods
.method public static e1(FLjava/lang/Object;I)Lh/y0;
    .registers 5

    .line 0: and-int/lit8 v0, v4, 1
    .line 2: if-eqz v0, :cond_7
    .line 4: const/high16 v0, 0x3f80
    .line 6: goto :goto_8
    .line 7: const/4 v0, 0
    .line 8: and-int/lit8 v1, v4, 2
    .line 10: if-eqz v1, :cond_15
    .line 12: const v2, 0x44bb8000
    .line 15: and-int/lit8 v4, v4, 4
    .line 17: if-eqz v4, :cond_20
    .line 19: const/4 v3, 0
    .line 20: new-instance v4, Lh/y0;
    .line 22: invoke-direct {v4, v0, v2, v3}, Lh/y0;-><init>(FFLjava/lang/Object;)V
    .line 25: return-object v4
.end method

# direct methods
.method public static final f(FF)J
    .registers 6

    .line 0: invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v4
    .line 4: int-to-long v0, v4
    .line 5: invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 8: move-result v4
    .line 9: int-to-long v4, v4
    .line 10: const/16 v2, 32
    .line 12: shl-long/2addr v0, v2
    .line 13: const-wide v2, 0x00ffffffff
    .line 18: and-long/2addr v4, v2
    .line 19: or-long/2addr v4, v0
    .line 20: sget v0, Lr1/f;->d:I
    .line 22: return-wide v4
.end method

# direct methods
.method public static final f0(ILjava/util/ArrayList;)I
    .registers 9

    .line 0: const-string v0, "paragraphInfoList"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 8: move-result v0
    .line 9: const/4 v1, 1
    .line 10: sub-int/2addr v0, v1
    .line 11: const/4 v2, 0
    .line 12: move v3, v2
    .line 13: if-gt v3, v0, :cond_47
    .line 15: add-int v4, v3, v0
    .line 17: ushr-int/2addr v4, v1
    .line 18: invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 21: move-result-object v5
    .line 22: check-cast v5, Lf1/l;
    .line 24: iget v6, v5, Lf1/l;->b:I
    .line 26: if-le v6, v7, :cond_30
    .line 28: move v5, v1
    .line 29: goto :goto_37
    .line 30: iget v5, v5, Lf1/l;->c:I
    .line 32: if-gt v5, v7, :cond_36
    .line 34: const/4 v5, -1
    .line 35: goto :goto_37
    .line 36: move v5, v2
    .line 37: if-gez v5, :cond_42
    .line 39: add-int/lit8 v3, v4, 1
    .line 41: goto :goto_13
    .line 42: if-lez v5, :cond_49
    .line 44: add-int/lit8 v0, v4, -1
    .line 46: goto :goto_13
    .line 47: add-int/2addr v3, v1
    .line 48: neg-int v4, v3
    .line 49: return v4
.end method

# direct methods
.method public static f1(Lj3/d;I)Lj3/b;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: if-lez v4, :cond_9
    .line 7: const/4 v0, 1
    .line 8: goto :goto_10
    .line 9: const/4 v0, 0
    .line 10: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 13: move-result-object v1
    .line 14: const-string v2, "step"
    .line 16: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 19: if-eqz v0, :cond_37
    .line 21: iget v0, v3, Lj3/b;->k:I
    .line 23: if-lez v0, :cond_26
    .line 25: goto :goto_27
    .line 26: neg-int v4, v4
    .line 27: new-instance v0, Lj3/b;
    .line 29: iget v1, v3, Lj3/b;->i:I
    .line 31: iget v3, v3, Lj3/b;->j:I
    .line 33: invoke-direct {v0, v1, v3, v4}, Lj3/b;-><init>(III)V
    .line 36: return-object v0
    .line 37: new-instance v3, Ljava/lang/IllegalArgumentException;
    .line 39: new-instance v4, Ljava/lang/StringBuilder;
    .line 41: const-string v0, "Step must be positive, was: "
    .line 43: invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 46: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 49: const/16 v0, 46
    .line 51: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 54: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 57: move-result-object v4
    .line 58: invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 61: throw v3
.end method

# direct methods
.method public static final g(II)J
    .registers 6

    .line 0: int-to-long v0, v4
    .line 1: const/16 v4, 32
    .line 3: shl-long/2addr v0, v4
    .line 4: int-to-long v4, v5
    .line 5: const-wide v2, 0x00ffffffff
    .line 10: and-long/2addr v4, v2
    .line 11: or-long/2addr v4, v0
    .line 12: return-wide v4
.end method

# direct methods
.method public static final g0(ILjava/util/ArrayList;)I
    .registers 9

    .line 0: const-string v0, "paragraphInfoList"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 8: move-result v0
    .line 9: const/4 v1, 1
    .line 10: sub-int/2addr v0, v1
    .line 11: const/4 v2, 0
    .line 12: move v3, v2
    .line 13: if-gt v3, v0, :cond_47
    .line 15: add-int v4, v3, v0
    .line 17: ushr-int/2addr v4, v1
    .line 18: invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 21: move-result-object v5
    .line 22: check-cast v5, Lf1/l;
    .line 24: iget v6, v5, Lf1/l;->d:I
    .line 26: if-le v6, v7, :cond_30
    .line 28: move v5, v1
    .line 29: goto :goto_37
    .line 30: iget v5, v5, Lf1/l;->e:I
    .line 32: if-gt v5, v7, :cond_36
    .line 34: const/4 v5, -1
    .line 35: goto :goto_37
    .line 36: move v5, v2
    .line 37: if-gez v5, :cond_42
    .line 39: add-int/lit8 v3, v4, 1
    .line 41: goto :goto_13
    .line 42: if-lez v5, :cond_49
    .line 44: add-int/lit8 v0, v4, -1
    .line 46: goto :goto_13
    .line 47: add-int/2addr v3, v1
    .line 48: neg-int v4, v3
    .line 49: return v4
.end method

# direct methods
.method public static g1()V
    .registers 2

    .line 0: new-instance v0, Ljava/lang/ArithmeticException;
    .line 2: const-string v1, "Index overflow has happened."
    .line 4: invoke-direct {v0, v1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# direct methods
.method public static final h(Lo0/j0;Ljava/util/Map;Lu/l;II)V
    .registers 27

    .line 0: move-object/from16 v1, v22
    .line 2: const-string v0, "group"
    .line 4: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: move-object/from16 v0, v24
    .line 9: check-cast v0, Lu/b0;
    .line 11: const v2, 0xe567d85f
    .line 14: invoke-virtual {v0, v2}, Lu/b0;->e0(I)Lu/b0;
    .line 17: and-int/lit8 v2, v26, 1
    .line 19: const/4 v3, 2
    .line 20: if-eqz v2, :cond_25
    .line 22: or-int/lit8 v2, v25, 6
    .line 24: goto :goto_43
    .line 25: and-int/lit8 v2, v25, 14
    .line 27: if-nez v2, :cond_41
    .line 29: invoke-virtual {v0, v1}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 32: move-result v2
    .line 33: if-eqz v2, :cond_37
    .line 35: const/4 v2, 4
    .line 36: goto :goto_38
    .line 37: move v2, v3
    .line 38: or-int v2, v25, v2
    .line 40: goto :goto_43
    .line 41: move/from16 v2, v25
    .line 43: and-int/lit8 v4, v26, 2
    .line 45: if-eqz v4, :cond_49
    .line 47: or-int/lit8 v2, v2, 16
    .line 49: if-ne v4, v3, :cond_71
    .line 51: and-int/lit8 v2, v2, 91
    .line 53: const/16 v3, 18
    .line 55: if-ne v2, v3, :cond_71
    .line 57: invoke-virtual {v0}, Lu/b0;->F()Z
    .line 60: move-result v2
    .line 61: if-nez v2, :cond_64
    .line 63: goto :goto_71
    .line 64: invoke-virtual {v0}, Lu/b0;->Y()V
    .line 67: move-object/from16 v2, v23
    .line 69: goto/16 :goto_384
    .line 71: if-eqz v4, :cond_77
    .line 73: sget-object v2, Lt2/s;->i:Lt2/s;
    .line 75: move-object v14, v2
    .line 76: goto :goto_79
    .line 77: move-object/from16 v14, v23
    .line 79: iget-object v2, v1, Lo0/j0;->r:Ljava/util/List;
    .line 81: invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 84: move-result-object v20
    .line 85: invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z
    .line 88: move-result v2
    .line 89: if-eqz v2, :cond_382
    .line 91: invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 94: move-result-object v2
    .line 95: check-cast v2, Lo0/l0;
    .line 97: instance-of v3, v2, Lo0/p0;
    .line 99: if-eqz v3, :cond_232
    .line 101: const v3, 0xec8d4659
    .line 104: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 107: check-cast v2, Lo0/p0;
    .line 109: iget-object v3, v2, Lo0/p0;->i:Ljava/lang/String;
    .line 111: invoke-interface {v14, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 114: move-result-object v3
    .line 115: check-cast v3, Lo0/i0;
    .line 117: iget-object v3, v2, Lo0/p0;->j:Ljava/util/List;
    .line 119: iget v4, v2, Lo0/p0;->k:I
    .line 121: iget-object v5, v2, Lo0/p0;->i:Ljava/lang/String;
    .line 123: iget-object v6, v2, Lo0/p0;->l:Lk0/m;
    .line 125: iget v7, v2, Lo0/p0;->m:F
    .line 127: invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 130: move-result-object v7
    .line 131: invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F
    .line 134: move-result v7
    .line 135: iget-object v8, v2, Lo0/p0;->n:Lk0/m;
    .line 137: iget v9, v2, Lo0/p0;->o:F
    .line 139: invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 142: move-result-object v9
    .line 143: invoke-virtual {v9}, Ljava/lang/Number;->floatValue()F
    .line 146: move-result v9
    .line 147: iget v10, v2, Lo0/p0;->p:F
    .line 149: invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 152: move-result-object v10
    .line 153: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 156: move-result v10
    .line 157: iget v11, v2, Lo0/p0;->q:I
    .line 159: iget v12, v2, Lo0/p0;->r:I
    .line 161: iget v15, v2, Lo0/p0;->s:F
    .line 163: iget v13, v2, Lo0/p0;->t:F
    .line 165: invoke-static {v13}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 168: move-result-object v13
    .line 169: invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F
    .line 172: move-result v13
    .line 173: iget v1, v2, Lo0/p0;->u:F
    .line 175: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 178: move-result-object v1
    .line 179: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 182: move-result v1
    .line 183: iget v2, v2, Lo0/p0;->v:F
    .line 185: invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 188: move-result-object v2
    .line 189: invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F
    .line 192: move-result v2
    .line 193: move/from16 v16, v15
    .line 195: move v15, v2
    .line 196: const/16 v17, 8
    .line 198: const/16 v18, 0
    .line 200: const/16 v19, 0
    .line 202: move-object v2, v3
    .line 203: move v3, v4
    .line 204: move-object v4, v5
    .line 205: move-object v5, v6
    .line 206: move v6, v7
    .line 207: move-object v7, v8
    .line 208: move v8, v9
    .line 209: move v9, v10
    .line 210: move v10, v11
    .line 211: move v11, v12
    .line 212: move/from16 v12, v16
    .line 214: move-object/from16 v21, v14
    .line 216: move v14, v1
    .line 217: move-object/from16 v16, v0
    .line 219: invoke-static/range {v2 .. v19}, Ll0/j;->c(Ljava/util/List;ILjava/lang/String;Lk0/m;FLk0/m;FFIIFFFFLu/l;III)V
    .line 222: const/4 v1, 0
    .line 223: invoke-virtual {v0, v1}, Lu/b0;->t(Z)V
    .line 226: move-object/from16 v1, v22
    .line 228: move-object/from16 v14, v21
    .line 230: goto/16 :goto_85
    .line 232: move-object/from16 v21, v14
    .line 234: const/4 v1, 0
    .line 235: instance-of v3, v2, Lo0/j0;
    .line 237: if-eqz v3, :cond_370
    .line 239: const v3, 0xec8d4d9b
    .line 242: invoke-virtual {v0, v3}, Lu/b0;->d0(I)V
    .line 245: move-object v3, v2
    .line 246: check-cast v3, Lo0/j0;
    .line 248: iget-object v4, v3, Lo0/j0;->i:Ljava/lang/String;
    .line 250: move-object/from16 v15, v21
    .line 252: invoke-interface {v15, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 255: move-result-object v4
    .line 256: check-cast v4, Lo0/i0;
    .line 258: iget-object v4, v3, Lo0/j0;->i:Ljava/lang/String;
    .line 260: iget v5, v3, Lo0/j0;->j:F
    .line 262: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 265: move-result-object v5
    .line 266: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 269: move-result v5
    .line 270: iget v6, v3, Lo0/j0;->m:F
    .line 272: invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 275: move-result-object v6
    .line 276: invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F
    .line 279: move-result v6
    .line 280: iget v7, v3, Lo0/j0;->n:F
    .line 282: invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 285: move-result-object v7
    .line 286: invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F
    .line 289: move-result v7
    .line 290: iget v8, v3, Lo0/j0;->o:F
    .line 292: invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 295: move-result-object v8
    .line 296: invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F
    .line 299: move-result v8
    .line 300: iget v9, v3, Lo0/j0;->p:F
    .line 302: invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 305: move-result-object v9
    .line 306: invoke-virtual {v9}, Ljava/lang/Number;->floatValue()F
    .line 309: move-result v9
    .line 310: iget v10, v3, Lo0/j0;->k:F
    .line 312: invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 315: move-result-object v10
    .line 316: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 319: move-result v10
    .line 320: iget v11, v3, Lo0/j0;->l:F
    .line 322: invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 325: move-result-object v11
    .line 326: invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F
    .line 329: move-result v11
    .line 330: iget-object v12, v3, Lo0/j0;->q:Ljava/util/List;
    .line 332: new-instance v3, Lj/b0;
    .line 334: const/4 v13, 3
    .line 335: invoke-direct {v3, v2, v13, v15}, Lj/b0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 338: const v2, 0x566df4ae
    .line 341: invoke-static {v0, v2, v3}, Ln3/a0;->A(Lu/l;ILe3/h;)Lb0/c;
    .line 344: move-result-object v13
    .line 345: const/high16 v14, 0x3800
    .line 347: const/16 v16, 0
    .line 349: move-object v2, v4
    .line 350: move v3, v5
    .line 351: move v4, v10
    .line 352: move v5, v11
    .line 353: move-object v10, v12
    .line 354: move-object v11, v13
    .line 355: move-object v12, v0
    .line 356: move v13, v14
    .line 357: move/from16 v14, v16
    .line 359: invoke-static/range {v2 .. v14}, Ll0/j;->a(Ljava/lang/String;FFFFFFFLjava/util/List;Ld3/e;Lu/l;II)V
    .line 362: invoke-virtual {v0, v1}, Lu/b0;->t(Z)V
    .line 365: move-object/from16 v1, v22
    .line 367: move-object v14, v15
    .line 368: goto/16 :goto_85
    .line 370: move-object/from16 v15, v21
    .line 372: const v2, 0xec8d5359
    .line 375: invoke-virtual {v0, v2}, Lu/b0;->d0(I)V
    .line 378: invoke-virtual {v0, v1}, Lu/b0;->t(Z)V
    .line 381: goto :goto_365
    .line 382: move-object v15, v14
    .line 383: move-object v2, v15
    .line 384: invoke-virtual {v0}, Lu/b0;->x()Lu/c2;
    .line 387: move-result-object v6
    .line 388: if-nez v6, :cond_391
    .line 390: goto :goto_406
    .line 391: new-instance v7, Lq/u;
    .line 393: const/4 v5, 1
    .line 394: move-object v0, v7
    .line 395: move-object/from16 v1, v22
    .line 397: move/from16 v3, v25
    .line 399: move/from16 v4, v26
    .line 401: invoke-direct/range {v0 .. v5}, Lq/u;-><init>(Ljava/lang/Object;Ljava/lang/Object;III)V
    .line 404: iput-object v7, v6, Lu/c2;->d:Ld3/e;
    .line 406: return-void
.end method

# direct methods
.method public static final h0(Ljava/util/ArrayList;F)I
    .registers 9

    .line 0: const-string v0, "paragraphInfoList"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    .line 8: move-result v0
    .line 9: const/4 v1, 1
    .line 10: sub-int/2addr v0, v1
    .line 11: const/4 v2, 0
    .line 12: move v3, v2
    .line 13: if-gt v3, v0, :cond_51
    .line 15: add-int v4, v3, v0
    .line 17: ushr-int/2addr v4, v1
    .line 18: invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 21: move-result-object v5
    .line 22: check-cast v5, Lf1/l;
    .line 24: iget v6, v5, Lf1/l;->f:F
    .line 26: cmpl-float v6, v6, v8
    .line 28: if-lez v6, :cond_32
    .line 30: move v5, v1
    .line 31: goto :goto_41
    .line 32: iget v5, v5, Lf1/l;->g:F
    .line 34: cmpg-float v5, v5, v8
    .line 36: if-gtz v5, :cond_40
    .line 38: const/4 v5, -1
    .line 39: goto :goto_41
    .line 40: move v5, v2
    .line 41: if-gez v5, :cond_46
    .line 43: add-int/lit8 v3, v4, 1
    .line 45: goto :goto_13
    .line 46: if-lez v5, :cond_53
    .line 48: add-int/lit8 v0, v4, -1
    .line 50: goto :goto_13
    .line 51: add-int/2addr v3, v1
    .line 52: neg-int v4, v3
    .line 53: return v4
.end method

# direct methods
.method public static h1(Ljava/lang/String;)V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "lateinit property "
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 10: const-string v2, " has not been initialized"
    .line 12: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 15: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 18: move-result-object v2
    .line 19: new-instance v0, Lkotlinx/coroutines/internal/z;
    .line 21: invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 24: const-class v2, Ld2/b;
    .line 26: invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 29: move-result-object v2
    .line 30: invoke-static {v2, v0}, Ld2/b;->c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .line 33: throw v0
.end method

# direct methods
.method public static i(Ljava/util/LinkedList;Lp2/n;Lp2/o;Lp2/o;)V
    .registers 6

    .line 0: sget-object v0, Lp2/n;->i:Lp2/n;
    .line 2: invoke-virtual {v0, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_61
    .line 8: sget-object v0, Lp2/m;->p:Lp2/m;
    .line 10: invoke-virtual {v4}, Lp2/o;->d()Lp2/m;
    .line 13: move-result-object v1
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 17: move-result v0
    .line 18: if-eqz v0, :cond_61
    .line 20: new-instance v3, Lr2/a;
    .line 22: sget-object v0, Lp2/k;->p:Lp2/k;
    .line 24: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 27: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 30: new-instance v3, Lr2/a;
    .line 32: sget-object v0, Lp2/k;->o:Lp2/k;
    .line 34: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 37: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 40: new-instance v3, Lr2/a;
    .line 42: sget-object v0, Lp2/k;->n:Lp2/k;
    .line 44: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 47: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 50: new-instance v3, Lr2/a;
    .line 52: sget-object v0, Lp2/k;->m:Lp2/k;
    .line 54: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 57: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 60: goto :goto_132
    .line 61: sget-object v0, Lp2/n;->j:Lp2/n;
    .line 63: invoke-virtual {v0, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 66: move-result v3
    .line 67: if-eqz v3, :cond_122
    .line 69: sget-object v3, Lp2/m;->i:Lp2/m;
    .line 71: invoke-virtual {v4}, Lp2/o;->d()Lp2/m;
    .line 74: move-result-object v0
    .line 75: invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 78: move-result v3
    .line 79: if-eqz v3, :cond_122
    .line 81: new-instance v3, Lr2/a;
    .line 83: sget-object v0, Lp2/k;->v:Lp2/k;
    .line 85: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 88: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 91: new-instance v3, Lr2/a;
    .line 93: sget-object v0, Lp2/k;->u:Lp2/k;
    .line 95: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 98: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 101: new-instance v3, Lr2/a;
    .line 103: sget-object v0, Lp2/k;->t:Lp2/k;
    .line 105: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 108: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 111: new-instance v3, Lr2/a;
    .line 113: sget-object v0, Lp2/k;->s:Lp2/k;
    .line 115: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 118: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 121: goto :goto_132
    .line 122: new-instance v3, Lr2/a;
    .line 124: sget-object v0, Lp2/k;->x:Lp2/k;
    .line 126: invoke-direct {v3, v5, v4, v0}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 129: invoke-virtual {v2, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 132: return-void
.end method

# direct methods
.method public static final i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .registers 7

    .line 0: sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 2: sget-object v1, Ln3/r;->l:Ln3/r;
    .line 4: invoke-interface {v4, v0, v1}, Lw2/j;->i(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 7: move-result-object v2
    .line 8: check-cast v2, Ljava/lang/Boolean;
    .line 10: invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z
    .line 13: move-result v2
    .line 14: invoke-interface {v5, v0, v1}, Lw2/j;->i(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 17: move-result-object v0
    .line 18: check-cast v0, Ljava/lang/Boolean;
    .line 20: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 23: move-result v0
    .line 24: if-nez v2, :cond_33
    .line 26: if-nez v0, :cond_33
    .line 28: invoke-interface {v4, v5}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 31: move-result-object v4
    .line 32: return-object v4
    .line 33: new-instance v1, Le3/s;
    .line 35: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 38: iput-object v5, v1, Le3/s;->i:Ljava/lang/Object;
    .line 40: sget-object v5, Lw2/k;->i:Lw2/k;
    .line 42: new-instance v2, Lm3/i;
    .line 44: const/4 v3, 2
    .line 45: invoke-direct {v2, v3, v1, v6}, Lm3/i;-><init>(ILjava/lang/Object;Z)V
    .line 48: invoke-interface {v4, v5, v2}, Lw2/j;->i(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 51: move-result-object v4
    .line 52: check-cast v4, Lw2/j;
    .line 54: if-eqz v0, :cond_68
    .line 56: iget-object v6, v1, Le3/s;->i:Ljava/lang/Object;
    .line 58: check-cast v6, Lw2/j;
    .line 60: sget-object v0, Ln3/r;->k:Ln3/r;
    .line 62: invoke-interface {v6, v5, v0}, Lw2/j;->i(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 65: move-result-object v5
    .line 66: iput-object v5, v1, Le3/s;->i:Ljava/lang/Object;
    .line 68: iget-object v5, v1, Le3/s;->i:Ljava/lang/Object;
    .line 70: check-cast v5, Lw2/j;
    .line 72: invoke-interface {v4, v5}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 75: move-result-object v4
    .line 76: return-object v4
.end method

# direct methods
.method public static final i1(Ll1/e0;)Landroid/view/inputmethod/ExtractedText;
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Landroid/view/inputmethod/ExtractedText;
    .line 7: invoke-direct {v0}, Landroid/view/inputmethod/ExtractedText;-><init>()V
    .line 10: iget-object v1, v4, Ll1/e0;->a:Lf1/e;
    .line 12: iget-object v2, v1, Lf1/e;->a:Ljava/lang/String;
    .line 14: iput-object v2, v0, Landroid/view/inputmethod/ExtractedText;->text:Ljava/lang/CharSequence;
    .line 16: const/4 v3, 0
    .line 17: iput v3, v0, Landroid/view/inputmethod/ExtractedText;->startOffset:I
    .line 19: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 22: move-result v2
    .line 23: iput v2, v0, Landroid/view/inputmethod/ExtractedText;->partialEndOffset:I
    .line 25: const/4 v2, -1
    .line 26: iput v2, v0, Landroid/view/inputmethod/ExtractedText;->partialStartOffset:I
    .line 28: iget-wide v2, v4, Ll1/e0;->b:J
    .line 30: invoke-static {v2, v3}, Lf1/a0;->d(J)I
    .line 33: move-result v4
    .line 34: iput v4, v0, Landroid/view/inputmethod/ExtractedText;->selectionStart:I
    .line 36: invoke-static {v2, v3}, Lf1/a0;->c(J)I
    .line 39: move-result v4
    .line 40: iput v4, v0, Landroid/view/inputmethod/ExtractedText;->selectionEnd:I
    .line 42: const/16 v4, 10
    .line 44: iget-object v1, v1, Lf1/e;->a:Ljava/lang/String;
    .line 46: invoke-static {v1, v4}, Lm3/j;->H1(Ljava/lang/CharSequence;C)Z
    .line 49: move-result v4
    .line 50: xor-int/lit8 v4, v4, 1
    .line 52: iput v4, v0, Landroid/view/inputmethod/ExtractedText;->flags:I
    .line 54: return-object v0
.end method

# direct methods
.method public static j(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "exception"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: if-eq v2, v3, :cond_40
    .line 12: sget-object v0, La3/a;->a:Ljava/lang/Integer;
    .line 14: if-eqz v0, :cond_37
    .line 16: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    .line 19: move-result v0
    .line 20: const/16 v1, 19
    .line 22: if-lt v0, v1, :cond_25
    .line 24: goto :goto_37
    .line 25: sget-object v0, Lz2/a;->a:Ljava/lang/reflect/Method;
    .line 27: if-eqz v0, :cond_40
    .line 29: filled-new-array {v3}, [Ljava/lang/Object;
    .line 32: move-result-object v3
    .line 33: invoke-virtual {v0, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 36: goto :goto_40
    .line 37: invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V
    .line 40: return-void
.end method

# direct methods
.method public static j0(Lp2/e;)Ljava/util/LinkedList;
    .registers 3

    .line 0: invoke-static {v2}, Ld2/b;->k0(Lp2/e;)Ljava/util/LinkedList;
    .line 3: move-result-object v0
    .line 4: new-instance v1, Lr2/b;
    .line 6: invoke-direct {v1, v2}, Lr2/b;-><init>(Lp2/e;)V
    .line 9: invoke-interface {v0, v1}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z
    .line 12: return-object v0
    .line 13: move-exception v2
    .line 14: new-instance v0, Lkotlinx/coroutines/internal/z;
    .line 16: const-string v1, "Couldn't generate Legal moves: "
    .line 18: invoke-direct {v0, v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 21: throw v0
.end method

# direct methods
.method public static final j1(J)J
    .registers 5

    .line 0: const/16 v0, 32
    .line 2: shr-long v0, v3, v0
    .line 4: long-to-int v0, v0
    .line 5: int-to-float v0, v0
    .line 6: const-wide v1, 0x00ffffffff
    .line 11: and-long/2addr v3, v1
    .line 12: long-to-int v3, v3
    .line 13: int-to-float v3, v3
    .line 14: invoke-static {v0, v3}, Ld2/c;->f(FF)J
    .line 17: move-result-wide v3
    .line 18: return-wide v3
.end method

# direct methods
.method public static k0(Lp2/e;)Ljava/util/LinkedList;
    .registers 20

    .line 0: move-object/from16 v0, v19
    .line 2: new-instance v1, Ljava/util/LinkedList;
    .line 4: invoke-direct {v1}, Ljava/util/LinkedList;-><init>()V
    .line 7: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 9: sget-object v3, Lp2/l;->j:Lp2/l;
    .line 11: invoke-static {v2, v3}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 14: move-result-object v3
    .line 15: invoke-virtual {v0, v3}, Lp2/e;->c(Lp2/k;)J
    .line 18: move-result-wide v3
    .line 19: const-wide/16 v5, 0
    .line 21: cmp-long v7, v3, v5
    .line 23: iget-object v8, v0, Lp2/e;->l:[J
    .line 25: const/16 v9, 8
    .line 27: if-eqz v7, :cond_137
    .line 29: sget-object v7, Lp2/a;->a:[J
    .line 31: invoke-static {v3, v4}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 34: move-result v7
    .line 35: invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 38: move-result-object v3
    .line 39: invoke-static {v3}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 42: move-result-wide v3
    .line 43: invoke-static {v7}, Lp2/o;->e(I)Lp2/o;
    .line 46: move-result-object v7
    .line 47: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 50: move-result-wide v10
    .line 51: iget-object v12, v0, Lp2/e;->q:Lp2/o;
    .line 53: sget-object v13, Lp2/n;->i:Lp2/n;
    .line 55: invoke-virtual {v2, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 58: move-result v14
    .line 59: if-eqz v14, :cond_70
    .line 61: sget-object v14, Lp2/a;->i:[J
    .line 63: invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I
    .line 66: move-result v15
    .line 67: aget-wide v15, v14, v15
    .line 69: goto :goto_78
    .line 70: sget-object v14, Lp2/a;->j:[J
    .line 72: invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I
    .line 75: move-result v15
    .line 76: aget-wide v15, v14, v15
    .line 78: sget-object v14, Lp2/o;->u0:Lp2/o;
    .line 80: invoke-virtual {v12, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 83: move-result v14
    .line 84: if-nez v14, :cond_102
    .line 86: invoke-virtual {v12}, Lp2/o;->b()J
    .line 89: move-result-wide v17
    .line 90: invoke-virtual {v2, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 93: move-result v12
    .line 94: if-eqz v12, :cond_99
    .line 96: shl-long v12, v17, v9
    .line 98: goto :goto_101
    .line 99: shr-long v12, v17, v9
    .line 101: or-long/2addr v10, v12
    .line 102: and-long v9, v15, v10
    .line 104: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 107: move-result v11
    .line 108: aget-wide v11, v8, v11
    .line 110: not-long v11, v11
    .line 111: and-long v8, v9, v11
    .line 113: cmp-long v10, v8, v5
    .line 115: if-eqz v10, :cond_19
    .line 117: invoke-static {v8, v9}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 120: move-result v10
    .line 121: invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 124: move-result-object v8
    .line 125: invoke-static {v8}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 128: move-result-wide v8
    .line 129: invoke-static {v10}, Lp2/o;->e(I)Lp2/o;
    .line 132: move-result-object v10
    .line 133: invoke-static {v1, v2, v10, v7}, Ld2/b;->i(Ljava/util/LinkedList;Lp2/n;Lp2/o;Lp2/o;)V
    .line 136: goto :goto_113
    .line 137: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 139: sget-object v3, Lp2/l;->j:Lp2/l;
    .line 141: invoke-static {v2, v3}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 144: move-result-object v3
    .line 145: invoke-virtual {v0, v3}, Lp2/e;->c(Lp2/k;)J
    .line 148: move-result-wide v3
    .line 149: cmp-long v7, v3, v5
    .line 151: if-eqz v7, :cond_311
    .line 153: sget-object v7, Lp2/a;->a:[J
    .line 155: invoke-static {v3, v4}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 158: move-result v7
    .line 159: invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 162: move-result-object v3
    .line 163: invoke-static {v3}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 166: move-result-wide v3
    .line 167: invoke-static {v7}, Lp2/o;->e(I)Lp2/o;
    .line 170: move-result-object v7
    .line 171: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 174: move-result-wide v10
    .line 175: sget-object v12, Lp2/n;->i:Lp2/n;
    .line 177: invoke-virtual {v2, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 180: move-result v13
    .line 181: if-eqz v13, :cond_192
    .line 183: sget-object v13, Lp2/a;->k:[J
    .line 185: invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I
    .line 188: move-result v14
    .line 189: aget-wide v14, v13, v14
    .line 191: goto :goto_200
    .line 192: sget-object v13, Lp2/a;->l:[J
    .line 194: invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I
    .line 197: move-result v14
    .line 198: aget-wide v14, v13, v14
    .line 200: invoke-virtual {v7}, Lp2/o;->d()Lp2/m;
    .line 203: move-result-object v13
    .line 204: sget-object v5, Lp2/m;->j:Lp2/m;
    .line 206: invoke-virtual {v13, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 209: move-result v5
    .line 210: const/16 v6, 16
    .line 212: if-eqz v5, :cond_240
    .line 214: invoke-virtual {v2, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 217: move-result v5
    .line 218: if-eqz v5, :cond_240
    .line 220: invoke-virtual {v7}, Lp2/o;->b()J
    .line 223: move-result-wide v12
    .line 224: shl-long/2addr v12, v9
    .line 225: and-long/2addr v12, v10
    .line 226: const-wide/16 v16, 0
    .line 228: cmp-long v5, v12, v16
    .line 230: if-eqz v5, :cond_279
    .line 232: invoke-virtual {v7}, Lp2/o;->b()J
    .line 235: move-result-wide v12
    .line 236: shl-long v5, v12, v6
    .line 238: or-long/2addr v10, v5
    .line 239: goto :goto_279
    .line 240: invoke-virtual {v7}, Lp2/o;->d()Lp2/m;
    .line 243: move-result-object v5
    .line 244: sget-object v12, Lp2/m;->o:Lp2/m;
    .line 246: invoke-virtual {v5, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 249: move-result v5
    .line 250: if-eqz v5, :cond_279
    .line 252: sget-object v5, Lp2/n;->j:Lp2/n;
    .line 254: invoke-virtual {v2, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 257: move-result v5
    .line 258: if-eqz v5, :cond_279
    .line 260: invoke-virtual {v7}, Lp2/o;->b()J
    .line 263: move-result-wide v12
    .line 264: shr-long/2addr v12, v9
    .line 265: and-long/2addr v12, v10
    .line 266: const-wide/16 v16, 0
    .line 268: cmp-long v5, v12, v16
    .line 270: if-eqz v5, :cond_279
    .line 272: invoke-virtual {v7}, Lp2/o;->b()J
    .line 275: move-result-wide v12
    .line 276: shr-long v5, v12, v6
    .line 278: goto :goto_238
    .line 279: not-long v5, v10
    .line 280: and-long/2addr v5, v14
    .line 281: const-wide/16 v10, 0
    .line 283: cmp-long v12, v5, v10
    .line 285: if-eqz v12, :cond_307
    .line 287: invoke-static {v5, v6}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 290: move-result v10
    .line 291: invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 294: move-result-object v5
    .line 295: invoke-static {v5}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 298: move-result-wide v5
    .line 299: invoke-static {v10}, Lp2/o;->e(I)Lp2/o;
    .line 302: move-result-object v10
    .line 303: invoke-static {v1, v2, v10, v7}, Ld2/b;->i(Ljava/util/LinkedList;Lp2/n;Lp2/o;Lp2/o;)V
    .line 306: goto :goto_281
    .line 307: const-wide/16 v5, 0
    .line 309: goto/16 :goto_149
    .line 311: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 313: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 316: move-result v2
    .line 317: aget-wide v2, v8, v2
    .line 319: not-long v2, v2
    .line 320: iget-object v4, v0, Lp2/e;->p:Lp2/n;
    .line 322: sget-object v5, Lp2/l;->k:Lp2/l;
    .line 324: invoke-static {v4, v5}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 327: move-result-object v4
    .line 328: invoke-virtual {v0, v4}, Lp2/e;->c(Lp2/k;)J
    .line 331: move-result-wide v4
    .line 332: const-wide/16 v6, 0
    .line 334: cmp-long v9, v4, v6
    .line 336: if-eqz v9, :cond_398
    .line 338: sget-object v6, Lp2/a;->a:[J
    .line 340: invoke-static {v4, v5}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 343: move-result v6
    .line 344: invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 347: move-result-object v4
    .line 348: invoke-static {v4}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 351: move-result-wide v4
    .line 352: invoke-static {v6}, Lp2/o;->e(I)Lp2/o;
    .line 355: move-result-object v6
    .line 356: sget-object v7, Lp2/a;->h:[J
    .line 358: invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I
    .line 361: move-result v9
    .line 362: aget-wide v9, v7, v9
    .line 364: and-long/2addr v9, v2
    .line 365: const-wide/16 v11, 0
    .line 367: cmp-long v7, v9, v11
    .line 369: if-eqz v7, :cond_332
    .line 371: invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 374: move-result v7
    .line 375: invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 378: move-result-object v9
    .line 379: invoke-static {v9}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 382: move-result-wide v9
    .line 383: invoke-static {v7}, Lp2/o;->e(I)Lp2/o;
    .line 386: move-result-object v7
    .line 387: new-instance v11, Lr2/a;
    .line 389: sget-object v12, Lp2/k;->x:Lp2/k;
    .line 391: invoke-direct {v11, v6, v7, v12}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 394: invoke-virtual {v1, v11}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 397: goto :goto_365
    .line 398: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 400: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 403: move-result v2
    .line 404: aget-wide v2, v8, v2
    .line 406: not-long v2, v2
    .line 407: iget-object v4, v0, Lp2/e;->p:Lp2/n;
    .line 409: sget-object v5, Lp2/l;->l:Lp2/l;
    .line 411: invoke-static {v4, v5}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 414: move-result-object v4
    .line 415: invoke-virtual {v0, v4}, Lp2/e;->c(Lp2/k;)J
    .line 418: move-result-wide v4
    .line 419: const-wide/16 v6, 0
    .line 421: cmp-long v9, v4, v6
    .line 423: if-eqz v9, :cond_485
    .line 425: sget-object v6, Lp2/a;->a:[J
    .line 427: invoke-static {v4, v5}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 430: move-result v6
    .line 431: invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 434: move-result-object v4
    .line 435: invoke-static {v4}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 438: move-result-wide v4
    .line 439: invoke-static {v6}, Lp2/o;->e(I)Lp2/o;
    .line 442: move-result-object v6
    .line 443: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 446: move-result-wide v9
    .line 447: invoke-static {v9, v10, v6}, Lp2/a;->b(JLp2/o;)J
    .line 450: move-result-wide v9
    .line 451: and-long/2addr v9, v2
    .line 452: const-wide/16 v11, 0
    .line 454: cmp-long v7, v9, v11
    .line 456: if-eqz v7, :cond_419
    .line 458: invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 461: move-result v7
    .line 462: invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 465: move-result-object v9
    .line 466: invoke-static {v9}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 469: move-result-wide v9
    .line 470: invoke-static {v7}, Lp2/o;->e(I)Lp2/o;
    .line 473: move-result-object v7
    .line 474: new-instance v11, Lr2/a;
    .line 476: sget-object v12, Lp2/k;->x:Lp2/k;
    .line 478: invoke-direct {v11, v6, v7, v12}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 481: invoke-virtual {v1, v11}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 484: goto :goto_452
    .line 485: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 487: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 490: move-result v2
    .line 491: aget-wide v2, v8, v2
    .line 493: not-long v2, v2
    .line 494: iget-object v4, v0, Lp2/e;->p:Lp2/n;
    .line 496: sget-object v5, Lp2/l;->m:Lp2/l;
    .line 498: invoke-static {v4, v5}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 501: move-result-object v4
    .line 502: invoke-virtual {v0, v4}, Lp2/e;->c(Lp2/k;)J
    .line 505: move-result-wide v4
    .line 506: const-wide/16 v6, 0
    .line 508: cmp-long v9, v4, v6
    .line 510: if-eqz v9, :cond_572
    .line 512: sget-object v6, Lp2/a;->a:[J
    .line 514: invoke-static {v4, v5}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 517: move-result v6
    .line 518: invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 521: move-result-object v4
    .line 522: invoke-static {v4}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 525: move-result-wide v4
    .line 526: invoke-static {v6}, Lp2/o;->e(I)Lp2/o;
    .line 529: move-result-object v6
    .line 530: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 533: move-result-wide v9
    .line 534: invoke-static {v9, v10, v6}, Lp2/a;->d(JLp2/o;)J
    .line 537: move-result-wide v9
    .line 538: and-long/2addr v9, v2
    .line 539: const-wide/16 v11, 0
    .line 541: cmp-long v7, v9, v11
    .line 543: if-eqz v7, :cond_506
    .line 545: invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 548: move-result v7
    .line 549: invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 552: move-result-object v9
    .line 553: invoke-static {v9}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 556: move-result-wide v9
    .line 557: invoke-static {v7}, Lp2/o;->e(I)Lp2/o;
    .line 560: move-result-object v7
    .line 561: new-instance v11, Lr2/a;
    .line 563: sget-object v12, Lp2/k;->x:Lp2/k;
    .line 565: invoke-direct {v11, v6, v7, v12}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 568: invoke-virtual {v1, v11}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 571: goto :goto_539
    .line 572: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 574: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 577: move-result v2
    .line 578: aget-wide v2, v8, v2
    .line 580: not-long v2, v2
    .line 581: iget-object v4, v0, Lp2/e;->p:Lp2/n;
    .line 583: sget-object v5, Lp2/l;->n:Lp2/l;
    .line 585: invoke-static {v4, v5}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 588: move-result-object v4
    .line 589: invoke-virtual {v0, v4}, Lp2/e;->c(Lp2/k;)J
    .line 592: move-result-wide v4
    .line 593: const-wide/16 v6, 0
    .line 595: cmp-long v9, v4, v6
    .line 597: if-eqz v9, :cond_664
    .line 599: sget-object v6, Lp2/a;->a:[J
    .line 601: invoke-static {v4, v5}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 604: move-result v6
    .line 605: invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 608: move-result-object v4
    .line 609: invoke-static {v4}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 612: move-result-wide v4
    .line 613: invoke-static {v6}, Lp2/o;->e(I)Lp2/o;
    .line 616: move-result-object v6
    .line 617: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 620: move-result-wide v9
    .line 621: invoke-static {v9, v10, v6}, Lp2/a;->d(JLp2/o;)J
    .line 624: move-result-wide v11
    .line 625: invoke-static {v9, v10, v6}, Lp2/a;->b(JLp2/o;)J
    .line 628: move-result-wide v9
    .line 629: or-long/2addr v9, v11
    .line 630: and-long/2addr v9, v2
    .line 631: const-wide/16 v11, 0
    .line 633: cmp-long v7, v9, v11
    .line 635: if-eqz v7, :cond_593
    .line 637: invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 640: move-result v7
    .line 641: invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 644: move-result-object v9
    .line 645: invoke-static {v9}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 648: move-result-wide v9
    .line 649: invoke-static {v7}, Lp2/o;->e(I)Lp2/o;
    .line 652: move-result-object v7
    .line 653: new-instance v11, Lr2/a;
    .line 655: sget-object v12, Lp2/k;->x:Lp2/k;
    .line 657: invoke-direct {v11, v6, v7, v12}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 660: invoke-virtual {v1, v11}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 663: goto :goto_631
    .line 664: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 666: invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I
    .line 669: move-result v2
    .line 670: aget-wide v2, v8, v2
    .line 672: not-long v2, v2
    .line 673: iget-object v4, v0, Lp2/e;->p:Lp2/n;
    .line 675: sget-object v5, Lp2/l;->o:Lp2/l;
    .line 677: invoke-static {v4, v5}, Lp2/k;->a(Lp2/n;Lp2/l;)Lp2/k;
    .line 680: move-result-object v4
    .line 681: invoke-virtual {v0, v4}, Lp2/e;->c(Lp2/k;)J
    .line 684: move-result-wide v4
    .line 685: const-wide/16 v6, 0
    .line 687: cmp-long v8, v4, v6
    .line 689: if-eqz v8, :cond_752
    .line 691: sget-object v6, Lp2/a;->a:[J
    .line 693: invoke-static {v4, v5}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 696: move-result v6
    .line 697: invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 700: move-result-object v4
    .line 701: invoke-static {v4}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 704: move-result-wide v4
    .line 705: invoke-static {v6}, Lp2/o;->e(I)Lp2/o;
    .line 708: move-result-object v6
    .line 709: sget-object v7, Lp2/a;->m:[J
    .line 711: invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I
    .line 714: move-result v8
    .line 715: aget-wide v8, v7, v8
    .line 717: and-long v7, v8, v2
    .line 719: const-wide/16 v9, 0
    .line 721: cmp-long v11, v7, v9
    .line 723: if-eqz v11, :cond_685
    .line 725: invoke-static {v7, v8}, Ljava/lang/Long;->numberOfTrailingZeros(J)I
    .line 728: move-result v9
    .line 729: invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 732: move-result-object v7
    .line 733: invoke-static {v7}, Lp2/a;->a(Ljava/lang/Long;)J
    .line 736: move-result-wide v7
    .line 737: invoke-static {v9}, Lp2/o;->e(I)Lp2/o;
    .line 740: move-result-object v9
    .line 741: new-instance v10, Lr2/a;
    .line 743: sget-object v11, Lp2/k;->x:Lp2/k;
    .line 745: invoke-direct {v10, v6, v9, v11}, Lr2/a;-><init>(Lp2/o;Lp2/o;Lp2/k;)V
    .line 748: invoke-virtual {v1, v10}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 751: goto :goto_719
    .line 752: iget-object v2, v0, Lp2/e;->p:Lp2/n;
    .line 754: invoke-virtual {v0, v2}, Lp2/e;->g(Lp2/n;)Lp2/o;
    .line 757: move-result-object v3
    .line 758: iget-object v4, v0, Lp2/e;->p:Lp2/n;
    .line 760: invoke-virtual {v4}, Lp2/n;->a()Lp2/n;
    .line 763: move-result-object v4
    .line 764: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 767: move-result-wide v5
    .line 768: invoke-virtual {v0, v5, v6, v4, v3}, Lp2/e;->r(JLp2/n;Lp2/o;)J
    .line 771: move-result-wide v3
    .line 772: const-wide/16 v5, 0
    .line 774: cmp-long v3, v3, v5
    .line 776: if-eqz v3, :cond_780
    .line 778: goto/16 :goto_952
    .line 780: invoke-virtual {v0, v2}, Lp2/e;->d(Lp2/n;)Lp2/g;
    .line 783: move-result-object v3
    .line 784: sget-object v4, Lp2/g;->k:Lp2/g;
    .line 786: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 789: move-result v3
    .line 790: iget-object v5, v0, Lp2/e;->u:Lq2/a;
    .line 792: if-nez v3, :cond_806
    .line 794: invoke-virtual {v0, v2}, Lp2/e;->d(Lp2/n;)Lp2/g;
    .line 797: move-result-object v3
    .line 798: sget-object v6, Lp2/g;->i:Lp2/g;
    .line 800: invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 803: move-result v3
    .line 804: if-eqz v3, :cond_868
    .line 806: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 809: move-result-wide v6
    .line 810: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 813: sget-object v3, Lp2/n;->i:Lp2/n;
    .line 815: invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 818: move-result v8
    .line 819: if-eqz v8, :cond_824
    .line 821: iget-wide v8, v5, Lq2/a;->m:J
    .line 823: goto :goto_826
    .line 824: iget-wide v8, v5, Lq2/a;->o:J
    .line 826: and-long/2addr v6, v8
    .line 827: const-wide/16 v8, 0
    .line 829: cmp-long v6, v6, v8
    .line 831: if-nez v6, :cond_868
    .line 833: invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 836: move-result v6
    .line 837: if-eqz v6, :cond_842
    .line 839: iget-object v6, v5, Lq2/a;->i:Ljava/util/List;
    .line 841: goto :goto_844
    .line 842: iget-object v6, v5, Lq2/a;->k:Ljava/util/List;
    .line 844: invoke-virtual {v2}, Lp2/n;->a()Lp2/n;
    .line 847: move-result-object v7
    .line 848: invoke-virtual {v0, v6, v7}, Lp2/e;->m(Ljava/util/List;Lp2/n;)Z
    .line 851: move-result v6
    .line 852: if-nez v6, :cond_868
    .line 854: invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 857: move-result v3
    .line 858: if-eqz v3, :cond_863
    .line 860: iget-object v3, v5, Lq2/a;->a:Lr2/a;
    .line 862: goto :goto_865
    .line 863: iget-object v3, v5, Lq2/a;->c:Lr2/a;
    .line 865: invoke-virtual {v1, v3}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 868: invoke-virtual {v0, v2}, Lp2/e;->d(Lp2/n;)Lp2/g;
    .line 871: move-result-object v3
    .line 872: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 875: move-result v3
    .line 876: if-nez v3, :cond_890
    .line 878: invoke-virtual {v0, v2}, Lp2/e;->d(Lp2/n;)Lp2/g;
    .line 881: move-result-object v3
    .line 882: sget-object v4, Lp2/g;->j:Lp2/g;
    .line 884: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 887: move-result v3
    .line 888: if-eqz v3, :cond_952
    .line 890: invoke-virtual/range {v19 .. v19}, Lp2/e;->b()J
    .line 893: move-result-wide v3
    .line 894: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 897: sget-object v6, Lp2/n;->i:Lp2/n;
    .line 899: invoke-virtual {v6, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 902: move-result v7
    .line 903: if-eqz v7, :cond_908
    .line 905: iget-wide v7, v5, Lq2/a;->n:J
    .line 907: goto :goto_910
    .line 908: iget-wide v7, v5, Lq2/a;->p:J
    .line 910: and-long/2addr v3, v7
    .line 911: const-wide/16 v7, 0
    .line 913: cmp-long v3, v3, v7
    .line 915: if-nez v3, :cond_952
    .line 917: invoke-virtual {v6, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 920: move-result v3
    .line 921: if-eqz v3, :cond_926
    .line 923: iget-object v3, v5, Lq2/a;->j:Ljava/util/List;
    .line 925: goto :goto_928
    .line 926: iget-object v3, v5, Lq2/a;->l:Ljava/util/List;
    .line 928: invoke-virtual {v2}, Lp2/n;->a()Lp2/n;
    .line 931: move-result-object v4
    .line 932: invoke-virtual {v0, v3, v4}, Lp2/e;->m(Ljava/util/List;Lp2/n;)Z
    .line 935: move-result v0
    .line 936: if-nez v0, :cond_952
    .line 938: invoke-virtual {v6, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 941: move-result v0
    .line 942: if-eqz v0, :cond_947
    .line 944: iget-object v0, v5, Lq2/a;->b:Lr2/a;
    .line 946: goto :goto_949
    .line 947: iget-object v0, v5, Lq2/a;->d:Lr2/a;
    .line 949: invoke-virtual {v1, v0}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z
    .line 952: return-object v1
.end method

# direct methods
.method public static k1(I)Ljava/lang/String;
    .registers 3

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v2, v0}, Ld2/b;->b0(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: const-string v2, "Blocking"
    .line 9: goto :goto_49
    .line 10: const/4 v0, 1
    .line 11: invoke-static {v2, v0}, Ld2/b;->b0(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: const-string v2, "Optional"
    .line 19: goto :goto_49
    .line 20: const/4 v0, 2
    .line 21: invoke-static {v2, v0}, Ld2/b;->b0(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_30
    .line 27: const-string v2, "Async"
    .line 29: goto :goto_49
    .line 30: new-instance v0, Ljava/lang/StringBuilder;
    .line 32: const-string v1, "Invalid(value="
    .line 34: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 37: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 40: const/16 v2, 41
    .line 42: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 45: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 48: move-result-object v2
    .line 49: return-object v2
.end method

# direct methods
.method public static final l(Lh/n;Lh/i;JLd3/c;Lw2/e;)Ljava/lang/Object;
    .registers 32

    .line 0: move-object/from16 v9, v26
    .line 2: move-object/from16 v0, v27
    .line 4: move-object/from16 v1, v31
    .line 6: instance-of v2, v1, Lh/a1;
    .line 8: if-eqz v2, :cond_26
    .line 10: move-object v2, v1
    .line 11: check-cast v2, Lh/a1;
    .line 13: iget v3, v2, Lh/a1;->q:I
    .line 15: const/high16 v4, 0x8000
    .line 17: and-int v5, v3, v4
    .line 19: if-eqz v5, :cond_26
    .line 21: sub-int/2addr v3, v4
    .line 22: iput v3, v2, Lh/a1;->q:I
    .line 24: move-object v10, v2
    .line 25: goto :goto_32
    .line 26: new-instance v2, Lh/a1;
    .line 28: invoke-direct {v2, v1}, Ly2/c;-><init>(Lw2/e;)V
    .line 31: goto :goto_24
    .line 32: iget-object v1, v10, Lh/a1;->p:Ljava/lang/Object;
    .line 34: sget-object v11, Lx2/a;->i:Lx2/a;
    .line 36: iget v2, v10, Lh/a1;->q:I
    .line 38: sget-object v12, Landroidx/compose/ui/platform/r1;->i:Landroidx/compose/ui/platform/r1;
    .line 40: const/4 v13, 1
    .line 41: const/4 v14, 2
    .line 42: if-eqz v2, :cond_91
    .line 44: if-eq v2, v13, :cond_76
    .line 46: if-ne v2, v14, :cond_68
    .line 48: iget-object v2, v10, Lh/a1;->o:Le3/s;
    .line 50: iget-object v0, v10, Lh/a1;->n:Ld3/c;
    .line 52: iget-object v3, v10, Lh/a1;->m:Lh/i;
    .line 54: iget-object v4, v10, Lh/a1;->l:Lh/n;
    .line 56: invoke-static {v1}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 59: move-object v8, v0
    .line 60: move-object v0, v3
    .line 61: move v5, v14
    .line 62: goto/16 :goto_264
    .line 64: move-exception v0
    .line 65: move-object v9, v4
    .line 66: goto/16 :goto_376
    .line 68: new-instance v0, Ljava/lang/IllegalStateException;
    .line 70: const-string v1, "call to 'resume' before 'invoke' with coroutine"
    .line 72: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 75: throw v0
    .line 76: iget-object v2, v10, Lh/a1;->o:Le3/s;
    .line 78: iget-object v0, v10, Lh/a1;->n:Ld3/c;
    .line 80: iget-object v3, v10, Lh/a1;->m:Lh/i;
    .line 82: iget-object v4, v10, Lh/a1;->l:Lh/n;
    .line 84: invoke-static {v1}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 87: move-object v8, v0
    .line 88: move-object v0, v3
    .line 89: goto/16 :goto_264
    .line 91: invoke-static {v1}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 94: const-wide/16 v1, 0
    .line 96: invoke-interface {v0, v1, v2}, Lh/i;->d(J)Ljava/lang/Object;
    .line 99: move-result-object v16
    .line 100: invoke-interface {v0, v1, v2}, Lh/i;->e(J)Lh/r;
    .line 103: move-result-object v18
    .line 104: new-instance v15, Le3/s;
    .line 106: invoke-direct {v15}, Ljava/lang/Object;-><init>()V
    .line 109: const-wide/high16 v1, 0x8000
    .line 111: cmp-long v1, v28, v1
    .line 113: iget-object v8, v10, Ly2/c;->j:Lw2/j;
    .line 115: if-nez v1, :cond_210
    .line 117: invoke-static {v8}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 120: invoke-static {v8}, Ld2/b;->n0(Lw2/j;)F
    .line 123: move-result v7
    .line 124: new-instance v6, Lh/d1;
    .line 126: move-object v1, v6
    .line 127: move-object v2, v15
    .line 128: move-object/from16 v3, v16
    .line 130: move-object/from16 v4, v27
    .line 132: move-object/from16 v5, v18
    .line 134: move-object v14, v6
    .line 135: move-object/from16 v6, v26
    .line 137: move-object/from16 v25, v8
    .line 139: move-object/from16 v8, v30
    .line 141: invoke-direct/range {v1 .. v8}, Lh/d1;-><init>(Le3/s;Ljava/lang/Object;Lh/i;Lh/r;Lh/n;FLd3/c;)V
    .line 144: iput-object v9, v10, Lh/a1;->l:Lh/n;
    .line 146: iput-object v0, v10, Lh/a1;->m:Lh/i;
    .line 148: move-object/from16 v8, v30
    .line 150: iput-object v8, v10, Lh/a1;->n:Ld3/c;
    .line 152: iput-object v15, v10, Lh/a1;->o:Le3/s;
    .line 154: iput v13, v10, Lh/a1;->q:I
    .line 156: invoke-interface/range {v27 .. v27}, Lh/i;->a()Z
    .line 159: move-result v1
    .line 160: if-eqz v1, :cond_186
    .line 162: invoke-virtual {v10}, Ly2/c;->n()Lw2/j;
    .line 165: move-result-object v1
    .line 166: invoke-interface {v1, v12}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 169: move-result-object v1
    .line 170: invoke-static {v1}, Lh/j;->c(Lw2/h;)V
    .line 173: invoke-virtual {v10}, Ly2/c;->n()Lw2/j;
    .line 176: move-result-object v1
    .line 177: invoke-static {v1}, Le3/g;->u(Lw2/j;)Lu/g1;
    .line 180: move-result-object v1
    .line 181: invoke-interface {v1, v14, v10}, Lu/g1;->t(Ld3/c;Lw2/e;)Ljava/lang/Object;
    .line 184: move-result-object v1
    .line 185: goto :goto_202
    .line 186: new-instance v1, Lg/t;
    .line 188: invoke-direct {v1, v13, v14}, Lg/t;-><init>(ILd3/c;)V
    .line 191: invoke-static/range {v25 .. v25}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 194: invoke-static/range {v25 .. v25}, Le3/g;->u(Lw2/j;)Lu/g1;
    .line 197: move-result-object v2
    .line 198: invoke-interface {v2, v1, v10}, Lu/g1;->t(Ld3/c;Lw2/e;)Ljava/lang/Object;
    .line 201: move-result-object v1
    .line 202: if-ne v1, v11, :cond_262
    .line 204: return-object v11
    .line 205: move-object v2, v15
    .line 206: goto/16 :goto_376
    .line 208: move-exception v0
    .line 209: goto :goto_205
    .line 210: move-object/from16 v25, v8
    .line 212: move-object/from16 v8, v30
    .line 214: new-instance v14, Lh/l;
    .line 216: invoke-interface/range {v27 .. v27}, Lh/i;->g()Lh/q1;
    .line 219: move-result-object v17
    .line 220: invoke-interface/range {v27 .. v27}, Lh/i;->b()Ljava/lang/Object;
    .line 223: move-result-object v21
    .line 224: new-instance v1, Lh/c1;
    .line 226: invoke-direct {v1, v9, v13}, Lh/c1;-><init>(Lh/n;I)V
    .line 229: move-object v7, v15
    .line 230: move-object v15, v14
    .line 231: move-wide/from16 v19, v28
    .line 233: move-wide/from16 v22, v28
    .line 235: move-object/from16 v24, v1
    .line 237: invoke-direct/range {v15 .. v24}, Lh/l;-><init>(Ljava/lang/Object;Lh/q1;Lh/r;JLjava/lang/Object;JLh/c1;)V
    .line 240: invoke-static/range {v25 .. v25}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 243: invoke-static/range {v25 .. v25}, Ld2/b;->n0(Lw2/j;)F
    .line 246: move-result v4
    .line 247: move-object v1, v14
    .line 248: move-wide/from16 v2, v28
    .line 250: move-object/from16 v5, v27
    .line 252: move-object/from16 v6, v26
    .line 254: move-object v15, v7
    .line 255: move-object/from16 v7, v30
    .line 257: invoke-static/range {v1 .. v7}, Ld2/b;->X(Lh/l;JFLh/i;Lh/n;Ld3/c;)V
    .line 260: iput-object v14, v15, Le3/s;->i:Ljava/lang/Object;
    .line 262: move-object v4, v9
    .line 263: move-object v2, v15
    .line 264: iget-object v1, v10, Ly2/c;->j:Lw2/j;
    .line 266: iget-object v3, v2, Le3/s;->i:Ljava/lang/Object;
    .line 268: invoke-static {v3}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 271: check-cast v3, Lh/l;
    .line 273: iget-object v3, v3, Lh/l;->i:Lu/s1;
    .line 275: invoke-virtual {v3}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 278: move-result-object v3
    .line 279: check-cast v3, Ljava/lang/Boolean;
    .line 281: invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z
    .line 284: move-result v3
    .line 285: if-eqz v3, :cond_369
    .line 287: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 290: invoke-static {v1}, Ld2/b;->n0(Lw2/j;)F
    .line 293: move-result v18
    .line 294: new-instance v3, Lh/e1;
    .line 296: move-object/from16 v16, v3
    .line 298: move-object/from16 v17, v2
    .line 300: move-object/from16 v19, v0
    .line 302: move-object/from16 v20, v4
    .line 304: move-object/from16 v21, v8
    .line 306: invoke-direct/range {v16 .. v21}, Lh/e1;-><init>(Le3/s;FLh/i;Lh/n;Ld3/c;)V
    .line 309: iput-object v4, v10, Lh/a1;->l:Lh/n;
    .line 311: iput-object v0, v10, Lh/a1;->m:Lh/i;
    .line 313: iput-object v8, v10, Lh/a1;->n:Ld3/c;
    .line 315: iput-object v2, v10, Lh/a1;->o:Le3/s;
    .line 317: const/4 v5, 2
    .line 318: iput v5, v10, Lh/a1;->q:I
    .line 320: invoke-interface {v0}, Lh/i;->a()Z
    .line 323: move-result v6
    .line 324: if-eqz v6, :cond_350
    .line 326: invoke-virtual {v10}, Ly2/c;->n()Lw2/j;
    .line 329: move-result-object v1
    .line 330: invoke-interface {v1, v12}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 333: move-result-object v1
    .line 334: invoke-static {v1}, Lh/j;->c(Lw2/h;)V
    .line 337: invoke-virtual {v10}, Ly2/c;->n()Lw2/j;
    .line 340: move-result-object v1
    .line 341: invoke-static {v1}, Le3/g;->u(Lw2/j;)Lu/g1;
    .line 344: move-result-object v1
    .line 345: invoke-interface {v1, v3, v10}, Lu/g1;->t(Ld3/c;Lw2/e;)Ljava/lang/Object;
    .line 348: move-result-object v1
    .line 349: goto :goto_366
    .line 350: new-instance v6, Lg/t;
    .line 352: invoke-direct {v6, v13, v3}, Lg/t;-><init>(ILd3/c;)V
    .line 355: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 358: invoke-static {v1}, Le3/g;->u(Lw2/j;)Lu/g1;
    .line 361: move-result-object v1
    .line 362: invoke-interface {v1, v6, v10}, Lu/g1;->t(Ld3/c;Lw2/e;)Ljava/lang/Object;
    .line 365: move-result-object v1
    .line 366: if-ne v1, v11, :cond_264
    .line 368: return-object v11
    .line 369: sget-object v0, Ls2/k;->a:Ls2/k;
    .line 371: return-object v0
    .line 372: move-exception v0
    .line 373: move-object v15, v7
    .line 374: goto/16 :goto_205
    .line 376: iget-object v1, v2, Le3/s;->i:Ljava/lang/Object;
    .line 378: check-cast v1, Lh/l;
    .line 380: if-nez v1, :cond_383
    .line 382: goto :goto_390
    .line 383: iget-object v1, v1, Lh/l;->i:Lu/s1;
    .line 385: sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 387: invoke-virtual {v1, v3}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 390: iget-object v1, v2, Le3/s;->i:Ljava/lang/Object;
    .line 392: check-cast v1, Lh/l;
    .line 394: if-eqz v1, :cond_407
    .line 396: iget-wide v1, v1, Lh/l;->g:J
    .line 398: iget-wide v3, v9, Lh/n;->l:J
    .line 400: cmp-long v1, v1, v3
    .line 402: if-nez v1, :cond_407
    .line 404: const/4 v1, 0
    .line 405: iput-boolean v1, v9, Lh/n;->n:Z
    .line 407: throw v0
.end method

# direct methods
.method public static l0(Lw2/h;Lw2/i;)Lw2/h;
    .registers 3

    .line 0: const-string v0, "key"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v1}, Lw2/h;->getKey()Lw2/i;
    .line 8: move-result-object v0
    .line 9: invoke-static {v0, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 12: move-result v2
    .line 13: if-eqz v2, :cond_16
    .line 15: goto :goto_17
    .line 16: const/4 v1, 0
    .line 17: return-object v1
.end method

# direct methods
.method public static l1(I)Ljava/lang/String;
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: const-string v1, "Text"
    .line 9: goto :goto_94
    .line 10: const/4 v0, 2
    .line 11: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: const-string v1, "Ascii"
    .line 19: goto :goto_94
    .line 20: const/4 v0, 3
    .line 21: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_30
    .line 27: const-string v1, "Number"
    .line 29: goto :goto_94
    .line 30: const/4 v0, 4
    .line 31: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 34: move-result v0
    .line 35: if-eqz v0, :cond_40
    .line 37: const-string v1, "Phone"
    .line 39: goto :goto_94
    .line 40: const/4 v0, 5
    .line 41: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 44: move-result v0
    .line 45: if-eqz v0, :cond_50
    .line 47: const-string v1, "Uri"
    .line 49: goto :goto_94
    .line 50: const/4 v0, 6
    .line 51: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 54: move-result v0
    .line 55: if-eqz v0, :cond_60
    .line 57: const-string v1, "Email"
    .line 59: goto :goto_94
    .line 60: const/4 v0, 7
    .line 61: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 64: move-result v0
    .line 65: if-eqz v0, :cond_70
    .line 67: const-string v1, "Password"
    .line 69: goto :goto_94
    .line 70: const/16 v0, 8
    .line 72: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 75: move-result v0
    .line 76: if-eqz v0, :cond_81
    .line 78: const-string v1, "NumberPassword"
    .line 80: goto :goto_94
    .line 81: const/16 v0, 9
    .line 83: invoke-static {v1, v0}, Ld2/b;->c0(II)Z
    .line 86: move-result v1
    .line 87: if-eqz v1, :cond_92
    .line 89: const-string v1, "Decimal"
    .line 91: goto :goto_94
    .line 92: const-string v1, "Invalid"
    .line 94: return-object v1
.end method

# direct methods
.method public static m(Ljava/lang/StringBuilder;Ljava/lang/Object;Ld3/c;)V
    .registers 3

    .line 0: if-eqz v2, :cond_12
    .line 2: invoke-interface {v2, v1}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Ljava/lang/CharSequence;
    .line 8: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 11: goto :goto_46
    .line 12: if-nez v1, :cond_15
    .line 14: goto :goto_19
    .line 15: instance-of v2, v1, Ljava/lang/CharSequence;
    .line 17: if-eqz v2, :cond_25
    .line 19: check-cast v1, Ljava/lang/CharSequence;
    .line 21: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 24: goto :goto_46
    .line 25: instance-of v2, v1, Ljava/lang/Character;
    .line 27: if-eqz v2, :cond_39
    .line 29: check-cast v1, Ljava/lang/Character;
    .line 31: invoke-virtual {v1}, Ljava/lang/Character;->charValue()C
    .line 34: move-result v1
    .line 35: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;
    .line 38: goto :goto_46
    .line 39: invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    .line 42: move-result-object v1
    .line 43: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 46: return-void
.end method

# direct methods
.method public static m0(Landroid/widget/EdgeEffect;)F
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 7: const/16 v1, 31
    .line 9: if-lt v0, v1, :cond_18
    .line 11: sget-object v0, Li/n;->a:Li/n;
    .line 13: invoke-virtual {v0, v2}, Li/n;->b(Landroid/widget/EdgeEffect;)F
    .line 16: move-result v2
    .line 17: goto :goto_19
    .line 18: const/4 v2, 0
    .line 19: return v2
.end method

# direct methods
.method public static m1(Le4/g;[B)V
    .registers 9

    .line 0: const-string v0, "cursor"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "key"
    .line 7: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: array-length v0, v8
    .line 11: const/4 v1, 0
    .line 12: iget-object v2, v7, Le4/g;->m:[B
    .line 14: iget v3, v7, Le4/g;->n:I
    .line 16: iget v4, v7, Le4/g;->o:I
    .line 18: if-eqz v2, :cond_36
    .line 20: if-ge v3, v4, :cond_36
    .line 22: rem-int/2addr v1, v0
    .line 23: aget-byte v5, v2, v3
    .line 25: aget-byte v6, v8, v1
    .line 27: xor-int/2addr v5, v6
    .line 28: int-to-byte v5, v5
    .line 29: aput-byte v5, v2, v3
    .line 31: add-int/lit8 v3, v3, 1
    .line 33: add-int/lit8 v1, v1, 1
    .line 35: goto :goto_20
    .line 36: iget-wide v2, v7, Le4/g;->l:J
    .line 38: iget-object v4, v7, Le4/g;->i:Le4/h;
    .line 40: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 43: iget-wide v4, v4, Le4/h;->j:J
    .line 45: cmp-long v2, v2, v4
    .line 47: if-eqz v2, :cond_76
    .line 49: iget-wide v2, v7, Le4/g;->l:J
    .line 51: const-wide/16 v4, -1
    .line 53: cmp-long v4, v2, v4
    .line 55: if-nez v4, :cond_64
    .line 57: const-wide/16 v2, 0
    .line 59: invoke-virtual {v7, v2, v3}, Le4/g;->b(J)I
    .line 62: move-result v2
    .line 63: goto :goto_72
    .line 64: iget v4, v7, Le4/g;->o:I
    .line 66: iget v5, v7, Le4/g;->n:I
    .line 68: sub-int/2addr v4, v5
    .line 69: int-to-long v4, v4
    .line 70: add-long/2addr v2, v4
    .line 71: goto :goto_59
    .line 72: const/4 v3, -1
    .line 73: if-ne v2, v3, :cond_12
    .line 75: return-void
    .line 76: new-instance v7, Ljava/lang/IllegalStateException;
    .line 78: const-string v8, "no more bytes"
    .line 80: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 83: move-result-object v8
    .line 84: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 87: throw v7
.end method

# direct methods
.method public static n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 2

    .line 0: if-nez v0, :cond_8
    .line 2: if-nez v1, :cond_6
    .line 4: const/4 v0, 1
    .line 5: goto :goto_12
    .line 6: const/4 v0, 0
    .line 7: goto :goto_12
    .line 8: invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 11: move-result v0
    .line 12: return v0
.end method

# direct methods
.method public static final n0(Lw2/j;)F
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Lf0/a;->r:Lf0/a;
    .line 7: invoke-interface {v1, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 10: move-result-object v1
    .line 11: check-cast v1, Lf0/q;
    .line 13: if-eqz v1, :cond_20
    .line 15: invoke-interface {v1}, Lf0/q;->k()F
    .line 18: move-result v1
    .line 19: goto :goto_22
    .line 20: const/high16 v1, 0x3f80
    .line 22: const/4 v0, 0
    .line 23: cmpl-float v0, v1, v0
    .line 25: if-ltz v0, :cond_28
    .line 27: return v1
    .line 28: new-instance v1, Ljava/lang/IllegalStateException;
    .line 30: const-string v0, "Check failed."
    .line 32: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 35: move-result-object v0
    .line 36: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 39: throw v1
.end method

# direct methods
.method public static n1(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v9}, Lm3/j;->T1(Ljava/lang/CharSequence;)Ll3/g;
    .line 8: move-result-object v1
    .line 9: invoke-static {v1}, Ll3/j;->I1(Ll3/h;)Ljava/util/List;
    .line 12: move-result-object v1
    .line 13: new-instance v2, Ljava/util/ArrayList;
    .line 15: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 18: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 21: move-result-object v3
    .line 22: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 25: move-result v4
    .line 26: if-eqz v4, :cond_47
    .line 28: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 31: move-result-object v4
    .line 32: move-object v5, v4
    .line 33: check-cast v5, Ljava/lang/String;
    .line 35: invoke-static {v5}, Lm3/j;->R1(Ljava/lang/CharSequence;)Z
    .line 38: move-result v5
    .line 39: xor-int/lit8 v5, v5, 1
    .line 41: if-eqz v5, :cond_22
    .line 43: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 46: goto :goto_22
    .line 47: new-instance v3, Ljava/util/ArrayList;
    .line 49: invoke-static {v2}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 52: move-result v4
    .line 53: invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 56: invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 59: move-result-object v2
    .line 60: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 63: move-result v4
    .line 64: const/4 v5, 0
    .line 65: if-eqz v4, :cond_111
    .line 67: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 70: move-result-object v4
    .line 71: check-cast v4, Ljava/lang/String;
    .line 73: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 76: move-result v6
    .line 77: const/4 v7, -1
    .line 78: if-ge v5, v6, :cond_96
    .line 80: invoke-virtual {v4, v5}, Ljava/lang/String;->charAt(I)C
    .line 83: move-result v8
    .line 84: invoke-static {v8}, Ld2/c;->e0(C)Z
    .line 87: move-result v8
    .line 88: xor-int/lit8 v8, v8, 1
    .line 90: if-eqz v8, :cond_93
    .line 92: goto :goto_97
    .line 93: add-int/lit8 v5, v5, 1
    .line 95: goto :goto_77
    .line 96: move v5, v7
    .line 97: if-ne v5, v7, :cond_103
    .line 99: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 102: move-result v5
    .line 103: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 106: move-result-object v4
    .line 107: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 110: goto :goto_60
    .line 111: invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 114: move-result-object v2
    .line 115: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 118: move-result v3
    .line 119: const/4 v4, 0
    .line 120: if-nez v3, :cond_124
    .line 122: move-object v3, v4
    .line 123: goto :goto_150
    .line 124: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 127: move-result-object v3
    .line 128: check-cast v3, Ljava/lang/Comparable;
    .line 130: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 133: move-result v6
    .line 134: if-eqz v6, :cond_150
    .line 136: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 139: move-result-object v6
    .line 140: check-cast v6, Ljava/lang/Comparable;
    .line 142: invoke-interface {v3, v6}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I
    .line 145: move-result v7
    .line 146: if-lez v7, :cond_130
    .line 148: move-object v3, v6
    .line 149: goto :goto_130
    .line 150: check-cast v3, Ljava/lang/Integer;
    .line 152: if-eqz v3, :cond_159
    .line 154: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    .line 157: move-result v2
    .line 158: goto :goto_160
    .line 159: move v2, v5
    .line 160: invoke-virtual {v9}, Ljava/lang/String;->length()I
    .line 163: move-result v9
    .line 164: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 167: invoke-static {v1}, Ld2/b;->r0(Ljava/util/List;)I
    .line 170: move-result v3
    .line 171: new-instance v6, Ljava/util/ArrayList;
    .line 173: invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V
    .line 176: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 179: move-result-object v1
    .line 180: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 183: move-result v7
    .line 184: if-eqz v7, :cond_259
    .line 186: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 189: move-result-object v7
    .line 190: add-int/lit8 v8, v5, 1
    .line 192: if-ltz v5, :cond_255
    .line 194: check-cast v7, Ljava/lang/String;
    .line 196: if-eqz v5, :cond_200
    .line 198: if-ne v5, v3, :cond_208
    .line 200: invoke-static {v7}, Lm3/j;->R1(Ljava/lang/CharSequence;)Z
    .line 203: move-result v5
    .line 204: if-eqz v5, :cond_208
    .line 206: move-object v5, v4
    .line 207: goto :goto_230
    .line 208: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 211: if-ltz v2, :cond_237
    .line 213: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 216: move-result v5
    .line 217: if-le v2, v5, :cond_220
    .line 219: goto :goto_221
    .line 220: move v5, v2
    .line 221: invoke-virtual {v7, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 224: move-result-object v5
    .line 225: const-string v7, "this as java.lang.String).substring(startIndex)"
    .line 227: invoke-static {v5, v7}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 230: if-eqz v5, :cond_235
    .line 232: invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 235: move v5, v8
    .line 236: goto :goto_180
    .line 237: const-string v9, "Requested character count "
    .line 239: const-string v0, " is less than zero."
    .line 241: invoke-static {v9, v2, v0}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 244: move-result-object v9
    .line 245: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 247: invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 250: move-result-object v9
    .line 251: invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 254: throw v0
    .line 255: invoke-static {}, Ld2/b;->g1()V
    .line 258: throw v4
    .line 259: new-instance v0, Ljava/lang/StringBuilder;
    .line 261: invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(I)V
    .line 264: const/16 v9, 124
    .line 266: invoke-static {v6, v0, v4, v9}, Lt2/p;->O1(Ljava/lang/Iterable;Ljava/lang/StringBuilder;Li/t;I)V
    .line 269: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 272: move-result-object v9
    .line 273: const-string v0, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()"
    .line 275: invoke-static {v9, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 278: return-object v9
.end method

# direct methods
.method public static varargs o([Ljava/lang/Object;)Ljava/util/ArrayList;
    .registers 4

    .line 0: array-length v0, v3
    .line 1: if-nez v0, :cond_9
    .line 3: new-instance v3, Ljava/util/ArrayList;
    .line 5: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    .line 8: goto :goto_21
    .line 9: new-instance v0, Ljava/util/ArrayList;
    .line 11: new-instance v1, Lt2/i;
    .line 13: const/4 v2, 1
    .line 14: invoke-direct {v1, v3, v2}, Lt2/i;-><init>([Ljava/lang/Object;Z)V
    .line 17: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 20: move-object v3, v0
    .line 21: return-object v3
.end method

# direct methods
.method public static o0()Ljava/util/Set;
    .registers 4

    .line 0: const-string v0, "android.text.EmojiConsistency"
    .line 2: invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    .line 5: move-result-object v0
    .line 6: const-string v1, "getEmojiConsistencySet"
    .line 8: const/4 v2, 0
    .line 9: new-array v3, v2, [Ljava/lang/Class;
    .line 11: invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 14: move-result-object v0
    .line 15: new-array v1, v2, [Ljava/lang/Object;
    .line 17: const/4 v2, 0
    .line 18: invoke-virtual {v0, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 21: move-result-object v0
    .line 22: if-nez v0, :cond_29
    .line 24: invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;
    .line 27: move-result-object v0
    .line 28: return-object v0
    .line 29: check-cast v0, Ljava/util/Set;
    .line 31: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 34: move-result-object v1
    .line 35: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 38: move-result v2
    .line 39: if-eqz v2, :cond_53
    .line 41: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 44: move-result-object v2
    .line 45: instance-of v2, v2, [I
    .line 47: if-nez v2, :cond_35
    .line 49: invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;
    .line 52: move-result-object v0
    .line 53: return-object v0
    .line 54: invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;
    .line 57: move-result-object v0
    .line 58: return-object v0
.end method

# direct methods
.method public static o1(Ljava/lang/String;)Ljava/lang/String;
    .registers 14

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "|"
    .line 7: invoke-static {v0}, Lm3/j;->R1(Ljava/lang/CharSequence;)Z
    .line 10: move-result v1
    .line 11: const/4 v2, 1
    .line 12: xor-int/2addr v1, v2
    .line 13: if-eqz v1, :cond_151
    .line 15: invoke-static {v13}, Lm3/j;->T1(Ljava/lang/CharSequence;)Ll3/g;
    .line 18: move-result-object v1
    .line 19: invoke-static {v1}, Ll3/j;->I1(Ll3/h;)Ljava/util/List;
    .line 22: move-result-object v1
    .line 23: invoke-virtual {v13}, Ljava/lang/String;->length()I
    .line 26: move-result v13
    .line 27: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 30: invoke-static {v1}, Ld2/b;->r0(Ljava/util/List;)I
    .line 33: move-result v3
    .line 34: new-instance v4, Ljava/util/ArrayList;
    .line 36: invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V
    .line 39: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 42: move-result-object v1
    .line 43: const/4 v5, 0
    .line 44: move v6, v5
    .line 45: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 48: move-result v7
    .line 49: const/4 v8, 0
    .line 50: if-eqz v7, :cond_131
    .line 52: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 55: move-result-object v7
    .line 56: add-int/lit8 v9, v6, 1
    .line 58: if-ltz v6, :cond_127
    .line 60: check-cast v7, Ljava/lang/String;
    .line 62: if-eqz v6, :cond_66
    .line 64: if-ne v6, v3, :cond_73
    .line 66: invoke-static {v7}, Lm3/j;->R1(Ljava/lang/CharSequence;)Z
    .line 69: move-result v6
    .line 70: if-eqz v6, :cond_73
    .line 72: goto :goto_120
    .line 73: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 76: move-result v6
    .line 77: move v10, v5
    .line 78: const/4 v11, -1
    .line 79: if-ge v10, v6, :cond_96
    .line 81: invoke-virtual {v7, v10}, Ljava/lang/String;->charAt(I)C
    .line 84: move-result v12
    .line 85: invoke-static {v12}, Ld2/c;->e0(C)Z
    .line 88: move-result v12
    .line 89: xor-int/2addr v12, v2
    .line 90: if-eqz v12, :cond_93
    .line 92: goto :goto_97
    .line 93: add-int/lit8 v10, v10, 1
    .line 95: goto :goto_78
    .line 96: move v10, v11
    .line 97: if-ne v10, v11, :cond_100
    .line 99: goto :goto_116
    .line 100: invoke-static {v7, v0, v10, v5}, Lm3/j;->f2(Ljava/lang/String;Ljava/lang/String;IZ)Z
    .line 103: move-result v6
    .line 104: if-eqz v6, :cond_116
    .line 106: add-int/2addr v10, v2
    .line 107: invoke-virtual {v7, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 110: move-result-object v8
    .line 111: const-string v6, "this as java.lang.String).substring(startIndex)"
    .line 113: invoke-static {v8, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 116: if-eqz v8, :cond_119
    .line 118: goto :goto_120
    .line 119: move-object v8, v7
    .line 120: if-eqz v8, :cond_125
    .line 122: invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 125: move v6, v9
    .line 126: goto :goto_45
    .line 127: invoke-static {}, Ld2/b;->g1()V
    .line 130: throw v8
    .line 131: new-instance v0, Ljava/lang/StringBuilder;
    .line 133: invoke-direct {v0, v13}, Ljava/lang/StringBuilder;-><init>(I)V
    .line 136: const/16 v13, 124
    .line 138: invoke-static {v4, v0, v8, v13}, Lt2/p;->O1(Ljava/lang/Iterable;Ljava/lang/StringBuilder;Li/t;I)V
    .line 141: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 144: move-result-object v13
    .line 145: const-string v0, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()"
    .line 147: invoke-static {v13, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 150: return-object v13
    .line 151: new-instance v13, Ljava/lang/IllegalArgumentException;
    .line 153: const-string v0, "marginPrefix must be non-blank string."
    .line 155: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 158: move-result-object v0
    .line 159: invoke-direct {v13, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 162: throw v13
.end method

# direct methods
.method public static p(Ljava/util/ArrayList;Ljava/lang/Comparable;)I
    .registers 6

    .line 0: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    .line 3: move-result v0
    .line 4: const-string v1, "<this>"
    .line 6: invoke-static {v4, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    .line 12: move-result v1
    .line 13: const/4 v2, 0
    .line 14: const-string v3, ")."
    .line 16: if-ltz v0, :cond_83
    .line 18: if-gt v0, v1, :cond_52
    .line 20: add-int/lit8 v0, v0, -1
    .line 22: if-gt v2, v0, :cond_48
    .line 24: add-int v1, v2, v0
    .line 26: ushr-int/lit8 v1, v1, 1
    .line 28: invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v3
    .line 32: check-cast v3, Ljava/lang/Comparable;
    .line 34: invoke-static {v3, v5}, Ld2/c;->x(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .line 37: move-result v3
    .line 38: if-gez v3, :cond_43
    .line 40: add-int/lit8 v2, v1, 1
    .line 42: goto :goto_22
    .line 43: if-lez v3, :cond_51
    .line 45: add-int/lit8 v0, v1, -1
    .line 47: goto :goto_22
    .line 48: add-int/lit8 v2, v2, 1
    .line 50: neg-int v1, v2
    .line 51: return v1
    .line 52: new-instance v4, Ljava/lang/IndexOutOfBoundsException;
    .line 54: new-instance v5, Ljava/lang/StringBuilder;
    .line 56: const-string v2, "toIndex ("
    .line 58: invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 61: invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 64: const-string v0, ") is greater than size ("
    .line 66: invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 69: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 72: invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 75: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 78: move-result-object v5
    .line 79: invoke-direct {v4, v5}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 82: throw v4
    .line 83: new-instance v4, Ljava/lang/IllegalArgumentException;
    .line 85: new-instance v5, Ljava/lang/StringBuilder;
    .line 87: const-string v1, "fromIndex ("
    .line 89: invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 92: invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 95: const-string v1, ") is greater than toIndex ("
    .line 97: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 100: invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 103: invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 106: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 109: move-result-object v5
    .line 110: invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 113: throw v4
.end method

# direct methods
.method public static final p0(Lk3/b;)Ljava/lang/Class;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: check-cast v2, Le3/c;
    .line 7: invoke-interface {v2}, Le3/c;->a()Ljava/lang/Class;
    .line 10: move-result-object v2
    .line 11: invoke-virtual {v2}, Ljava/lang/Class;->isPrimitive()Z
    .line 14: move-result v0
    .line 15: if-nez v0, :cond_18
    .line 17: return-object v2
    .line 18: invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 21: move-result-object v0
    .line 22: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 25: move-result v1
    .line 26: sparse-switch v1, :data_142
    .line 29: goto/16 :goto_140
    .line 31: const-string v1, "short"
    .line 33: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 36: move-result v0
    .line 37: if-nez v0, :cond_41
    .line 39: goto/16 :goto_140
    .line 41: const-class v2, Ljava/lang/Short;
    .line 43: goto/16 :goto_140
    .line 45: const-string v1, "float"
    .line 47: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 50: move-result v0
    .line 51: if-nez v0, :cond_54
    .line 53: goto :goto_140
    .line 54: const-class v2, Ljava/lang/Float;
    .line 56: goto :goto_140
    .line 57: const-string v1, "boolean"
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 62: move-result v0
    .line 63: if-nez v0, :cond_66
    .line 65: goto :goto_140
    .line 66: const-class v2, Ljava/lang/Boolean;
    .line 68: goto :goto_140
    .line 69: const-string v1, "void"
    .line 71: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 74: move-result v0
    .line 75: if-nez v0, :cond_78
    .line 77: goto :goto_140
    .line 78: const-class v2, Ljava/lang/Void;
    .line 80: goto :goto_140
    .line 81: const-string v1, "long"
    .line 83: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 86: move-result v0
    .line 87: if-nez v0, :cond_90
    .line 89: goto :goto_140
    .line 90: const-class v2, Ljava/lang/Long;
    .line 92: goto :goto_140
    .line 93: const-string v1, "char"
    .line 95: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 98: move-result v0
    .line 99: if-nez v0, :cond_102
    .line 101: goto :goto_140
    .line 102: const-class v2, Ljava/lang/Character;
    .line 104: goto :goto_140
    .line 105: const-string v1, "byte"
    .line 107: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 110: move-result v0
    .line 111: if-nez v0, :cond_114
    .line 113: goto :goto_140
    .line 114: const-class v2, Ljava/lang/Byte;
    .line 116: goto :goto_140
    .line 117: const-string v1, "int"
    .line 119: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 122: move-result v0
    .line 123: if-nez v0, :cond_126
    .line 125: goto :goto_140
    .line 126: const-class v2, Ljava/lang/Integer;
    .line 128: goto :goto_140
    .line 129: const-string v1, "double"
    .line 131: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 134: move-result v0
    .line 135: if-nez v0, :cond_138
    .line 137: goto :goto_140
    .line 138: const-class v2, Ljava/lang/Double;
    .line 140: return-object v2
    .line 141: nop
    .line 142: nop
    .line 143: move-object/16 v31697, v45303
    .line 146: 0xef ; unknown opcode
    .line 147: move v0, v0
    .line 148: move-object/from16 v97, v46
    .line 150: iget-byte v3, v9, Lai/onnxruntime/OnnxJavaType;->BOOL:Lai/onnxruntime/OnnxJavaType;
    .line 152: not-int v6, v12
    .line 153: if-eq v0, v0, :cond_21037
    .line 155: if-le v0, v0, :cond_27843
    .line 157: div-int/lit8 v3, v92, 34
    .line 159: add-int/lit16 v5, v0, -31620
    .line 161: long-to-float v6, v0
    .line 162: sput v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 164: iput-object v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 166: aput-byte v0, v0, v0
    .line 168: 0x43 ; unknown opcode
    .line 169: nop
    .line 170: if-le v0, v0, :cond_170
    .line 172: packed-switch v0, :data_2031788
    .line 175: nop
    .line 176: const/16 v0, 0
    .line 178: move-wide/from16 v0, v0
.end method

# direct methods
.method public static p1(IILh/y;I)Lh/p1;
    .registers 5

    .line 0: and-int/lit8 v0, v4, 1
    .line 2: if-eqz v0, :cond_6
    .line 4: const/16 v1, 300
    .line 6: and-int/lit8 v0, v4, 2
    .line 8: if-eqz v0, :cond_11
    .line 10: const/4 v2, 0
    .line 11: and-int/lit8 v4, v4, 4
    .line 13: if-eqz v4, :cond_17
    .line 15: sget-object v3, Lh/a0;->a:Lh/u;
    .line 17: const-string v4, "easing"
    .line 19: invoke-static {v3, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: new-instance v4, Lh/p1;
    .line 24: invoke-direct {v4, v1, v2, v3}, Lh/p1;-><init>(IILh/y;)V
    .line 27: return-object v4
.end method

# direct methods
.method public static q(ILjava/lang/String;)Lorg/json/JSONObject;
    .registers 7

    .line 0: sget-object v0, Ld2/b;->c:Lorg/json/JSONObject;
    .line 2: if-eqz v0, :cond_40
    .line 4: int-to-double v1, v5
    .line 5: const-wide/high16 v3, 0x4059
    .line 7: div-double/2addr v1, v3
    .line 8: invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J
    .line 11: move-result-wide v1
    .line 12: const/16 v5, 100
    .line 14: int-to-long v3, v5
    .line 15: mul-long/2addr v1, v3
    .line 16: long-to-int v5, v1
    .line 17: const/16 v1, 800
    .line 19: const/16 v2, 2800
    .line 21: invoke-static {v5, v1, v2}, Ld2/b;->G(III)I
    .line 24: move-result v5
    .line 25: invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 28: move-result-object v5
    .line 29: invoke-virtual {v0, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 32: move-result-object v5
    .line 33: if-eqz v5, :cond_40
    .line 35: invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 38: move-result-object v5
    .line 39: goto :goto_41
    .line 40: const/4 v5, 0
    .line 41: return-object v5
.end method

# direct methods
.method public static final q0(Lw2/j;)Ln3/x0;
    .registers 4

    .line 0: sget-object v0, Ln3/v;->j:Ln3/v;
    .line 2: invoke-interface {v3, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ln3/x0;
    .line 8: if-eqz v0, :cond_11
    .line 10: return-object v0
    .line 11: new-instance v0, Ljava/lang/IllegalStateException;
    .line 13: new-instance v1, Ljava/lang/StringBuilder;
    .line 15: const-string v2, "Current context doesn't contain Job in it: "
    .line 17: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 20: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 23: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 26: move-result-object v3
    .line 27: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 30: move-result-object v3
    .line 31: invoke-direct {v0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 34: throw v0
.end method

# direct methods
.method public static final q1(J)D
    .registers 6

    .line 0: const/16 v0, 11
    .line 2: ushr-long v0, v4, v0
    .line 4: long-to-double v0, v0
    .line 5: const/16 v2, 2048
    .line 7: int-to-double v2, v2
    .line 8: mul-double/2addr v0, v2
    .line 9: const-wide/16 v2, 2047
    .line 11: and-long/2addr v4, v2
    .line 12: long-to-double v4, v4
    .line 13: add-double/2addr v0, v4
    .line 14: return-wide v0
.end method

# direct methods
.method public static final r(Ln3/z;Lh/t0;)V
    .registers 4

    .line 0: invoke-interface {v2}, Ln3/z;->getCoroutineContext()Lw2/j;
    .line 3: move-result-object v0
    .line 4: sget-object v1, Ln3/v;->j:Ln3/v;
    .line 6: invoke-interface {v0, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 9: move-result-object v0
    .line 10: check-cast v0, Ln3/x0;
    .line 12: if-eqz v0, :cond_18
    .line 14: invoke-interface {v0, v3}, Ln3/x0;->a(Ljava/util/concurrent/CancellationException;)V
    .line 17: return-void
    .line 18: new-instance v3, Ljava/lang/IllegalStateException;
    .line 20: new-instance v0, Ljava/lang/StringBuilder;
    .line 22: const-string v1, "Scope cannot be cancelled because it does not have a job: "
    .line 24: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 27: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 33: move-result-object v2
    .line 34: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 37: move-result-object v2
    .line 38: invoke-direct {v3, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 41: throw v3
.end method

# direct methods
.method public static r0(Ljava/util/List;)I
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 8: move-result v1
    .line 9: add-int/lit8 v1, v1, -1
    .line 11: return v1
.end method

# direct methods
.method public static r1(II)Lj3/d;
    .registers 4

    .line 0: const/high16 v0, 0x8000
    .line 2: if-gt v3, v0, :cond_9
    .line 4: sget-object v2, Lj3/d;->l:Lj3/d;
    .line 6: sget-object v2, Lj3/d;->l:Lj3/d;
    .line 8: return-object v2
    .line 9: new-instance v0, Lj3/d;
    .line 11: const/4 v1, 1
    .line 12: sub-int/2addr v3, v1
    .line 13: invoke-direct {v0, v2, v3, v1}, Lj3/b;-><init>(III)V
    .line 16: return-object v0
.end method

# direct methods
.method public static final s(Lp3/a0;Ljava/lang/Throwable;)V
    .registers 4

    .line 0: const/4 v0, 0
    .line 1: if-eqz v3, :cond_22
    .line 3: instance-of v1, v3, Ljava/util/concurrent/CancellationException;
    .line 5: if-eqz v1, :cond_10
    .line 7: move-object v0, v3
    .line 8: check-cast v0, Ljava/util/concurrent/CancellationException;
    .line 10: if-nez v0, :cond_22
    .line 12: new-instance v0, Ljava/util/concurrent/CancellationException;
    .line 14: const-string v1, "Channel was consumed, consumer had failed"
    .line 16: invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V
    .line 19: invoke-virtual {v0, v3}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    .line 22: invoke-interface {v2, v0}, Lp3/a0;->a(Ljava/util/concurrent/CancellationException;)V
    .line 25: return-void
.end method

# direct methods
.method public static final s0(Lw2/e;)Ln3/h;
    .registers 3

    .line 0: instance-of v0, v2, Lkotlinx/coroutines/internal/e;
    .line 2: if-nez v0, :cond_11
    .line 4: new-instance v0, Ln3/h;
    .line 6: const/4 v1, 1
    .line 7: invoke-direct {v0, v1, v2}, Ln3/h;-><init>(ILw2/e;)V
    .line 10: return-object v0
    .line 11: move-object v0, v2
    .line 12: check-cast v0, Lkotlinx/coroutines/internal/e;
    .line 14: invoke-virtual {v0}, Lkotlinx/coroutines/internal/e;->i()Ln3/h;
    .line 17: move-result-object v0
    .line 18: if-eqz v0, :cond_32
    .line 20: invoke-virtual {v0}, Ln3/h;->x()Z
    .line 23: move-result v1
    .line 24: if-eqz v1, :cond_27
    .line 26: goto :goto_28
    .line 27: const/4 v0, 0
    .line 28: if-nez v0, :cond_31
    .line 30: goto :goto_32
    .line 31: return-object v0
    .line 32: new-instance v0, Ln3/h;
    .line 34: const/4 v1, 2
    .line 35: invoke-direct {v0, v1, v2}, Ln3/h;-><init>(ILw2/e;)V
    .line 38: return-object v0
.end method

# direct methods
.method public static final s1(JJ)J
    .registers 8

    .line 0: invoke-static {v4, v5}, Lf1/a0;->d(J)I
    .line 3: move-result v0
    .line 4: invoke-static {v4, v5}, Lf1/a0;->c(J)I
    .line 7: move-result v1
    .line 8: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 11: move-result v2
    .line 12: invoke-static {v4, v5}, Lf1/a0;->c(J)I
    .line 15: move-result v3
    .line 16: if-ge v2, v3, :cond_115
    .line 18: invoke-static {v4, v5}, Lf1/a0;->d(J)I
    .line 21: move-result v2
    .line 22: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 25: move-result v3
    .line 26: if-ge v2, v3, :cond_115
    .line 28: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 31: move-result v2
    .line 32: invoke-static {v4, v5}, Lf1/a0;->d(J)I
    .line 35: move-result v3
    .line 36: if-gt v2, v3, :cond_54
    .line 38: invoke-static {v4, v5}, Lf1/a0;->c(J)I
    .line 41: move-result v2
    .line 42: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 45: move-result v3
    .line 46: if-gt v2, v3, :cond_54
    .line 48: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 51: move-result v0
    .line 52: move v1, v0
    .line 53: goto :goto_140
    .line 54: invoke-static {v4, v5}, Lf1/a0;->d(J)I
    .line 57: move-result v2
    .line 58: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 61: move-result v3
    .line 62: if-gt v2, v3, :cond_85
    .line 64: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 67: move-result v2
    .line 68: invoke-static {v4, v5}, Lf1/a0;->c(J)I
    .line 71: move-result v4
    .line 72: if-gt v2, v4, :cond_85
    .line 74: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 77: move-result v4
    .line 78: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 81: move-result v5
    .line 82: sub-int/2addr v4, v5
    .line 83: sub-int/2addr v1, v4
    .line 84: goto :goto_140
    .line 85: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 88: move-result v4
    .line 89: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 92: move-result v5
    .line 93: if-ge v0, v5, :cond_110
    .line 95: if-gt v4, v0, :cond_110
    .line 97: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 100: move-result v0
    .line 101: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 104: move-result v4
    .line 105: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 108: move-result v5
    .line 109: goto :goto_82
    .line 110: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 113: move-result v1
    .line 114: goto :goto_140
    .line 115: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 118: move-result v4
    .line 119: if-le v1, v4, :cond_140
    .line 121: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 124: move-result v4
    .line 125: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 128: move-result v5
    .line 129: sub-int/2addr v4, v5
    .line 130: sub-int/2addr v0, v4
    .line 131: invoke-static {v6, v7}, Lf1/a0;->c(J)I
    .line 134: move-result v4
    .line 135: invoke-static {v6, v7}, Lf1/a0;->d(J)I
    .line 138: move-result v5
    .line 139: goto :goto_82
    .line 140: invoke-static {v0, v1}, Ld2/c;->g(II)J
    .line 143: move-result-wide v4
    .line 144: return-wide v4
.end method

# direct methods
.method public static final t(II)V
    .registers 5

    .line 0: if-ltz v3, :cond_5
    .line 2: if-ge v3, v4, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    .line 7: const-string v1, "index: "
    .line 9: const-string v2, ", size: "
    .line 11: invoke-static {v1, v3, v2, v4}, Lai/onnxruntime/b;->h(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;
    .line 14: move-result-object v3
    .line 15: invoke-direct {v0, v3}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 18: throw v0
.end method

# direct methods
.method public static final t0(III)I
    .registers 4

    .line 0: if-lez v3, :cond_24
    .line 2: if-lt v1, v2, :cond_5
    .line 4: goto :goto_48
    .line 5: rem-int v0, v2, v3
    .line 7: if-ltz v0, :cond_10
    .line 9: goto :goto_11
    .line 10: add-int/2addr v0, v3
    .line 11: rem-int/2addr v1, v3
    .line 12: if-ltz v1, :cond_15
    .line 14: goto :goto_16
    .line 15: add-int/2addr v1, v3
    .line 16: sub-int/2addr v0, v1
    .line 17: rem-int/2addr v0, v3
    .line 18: if-ltz v0, :cond_21
    .line 20: goto :goto_22
    .line 21: add-int/2addr v0, v3
    .line 22: sub-int/2addr v2, v0
    .line 23: goto :goto_48
    .line 24: if-gez v3, :cond_49
    .line 26: if-gt v1, v2, :cond_29
    .line 28: goto :goto_48
    .line 29: neg-int v3, v3
    .line 30: rem-int/2addr v1, v3
    .line 31: if-ltz v1, :cond_34
    .line 33: goto :goto_35
    .line 34: add-int/2addr v1, v3
    .line 35: rem-int v0, v2, v3
    .line 37: if-ltz v0, :cond_40
    .line 39: goto :goto_41
    .line 40: add-int/2addr v0, v3
    .line 41: sub-int/2addr v1, v0
    .line 42: rem-int/2addr v1, v3
    .line 43: if-ltz v1, :cond_46
    .line 45: goto :goto_47
    .line 46: add-int/2addr v1, v3
    .line 47: add-int/2addr v2, v1
    .line 48: return v2
    .line 49: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 51: const-string v2, "Step is zero."
    .line 53: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 56: throw v1
.end method

# direct methods
.method public static final t1(Lh/l;Lh/n;)V
    .registers 7

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v1, "state"
    .line 7: invoke-static {v6, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: iget-object v1, v5, Lh/l;->e:Lu/s1;
    .line 12: invoke-virtual {v1}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 15: move-result-object v1
    .line 16: iget-object v2, v6, Lh/n;->j:Lu/s1;
    .line 18: invoke-virtual {v2, v1}, Lu/e3;->setValue(Ljava/lang/Object;)V
    .line 21: iget-object v1, v6, Lh/n;->k:Lh/r;
    .line 23: iget-object v2, v5, Lh/l;->f:Lh/r;
    .line 25: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 28: const-string v0, "source"
    .line 30: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 33: invoke-virtual {v1}, Lh/r;->b()I
    .line 36: move-result v0
    .line 37: const/4 v3, 0
    .line 38: if-ge v3, v0, :cond_50
    .line 40: invoke-virtual {v2, v3}, Lh/r;->a(I)F
    .line 43: move-result v4
    .line 44: invoke-virtual {v1, v4, v3}, Lh/r;->e(FI)V
    .line 47: add-int/lit8 v3, v3, 1
    .line 49: goto :goto_38
    .line 50: iget-wide v0, v5, Lh/l;->h:J
    .line 52: iput-wide v0, v6, Lh/n;->m:J
    .line 54: iget-wide v0, v5, Lh/l;->g:J
    .line 56: iput-wide v0, v6, Lh/n;->l:J
    .line 58: iget-object v5, v5, Lh/l;->i:Lu/s1;
    .line 60: invoke-virtual {v5}, Lu/e3;->getValue()Ljava/lang/Object;
    .line 63: move-result-object v5
    .line 64: check-cast v5, Ljava/lang/Boolean;
    .line 66: invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z
    .line 69: move-result v5
    .line 70: iput-boolean v5, v6, Lh/n;->n:Z
    .line 72: return-void
.end method

# direct methods
.method public static u(Ljava/lang/Object;)V
    .registers 2

    .line 0: if-eqz v1, :cond_3
    .line 2: return-void
    .line 3: new-instance v1, Ljava/lang/NullPointerException;
    .line 5: invoke-direct {v1}, Ljava/lang/NullPointerException;-><init>()V
    .line 8: const-class v0, Ld2/b;
    .line 10: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 13: move-result-object v0
    .line 14: invoke-static {v0, v1}, Ld2/b;->c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .line 17: throw v1
.end method

# direct methods
.method public static u0(Landroid/content/Context;)Ljava/io/File;
    .registers 6

    .line 0: invoke-virtual {v5}, Landroid/content/Context;->getCacheDir()Ljava/io/File;
    .line 3: move-result-object v5
    .line 4: const/4 v0, 0
    .line 5: if-nez v5, :cond_8
    .line 7: return-object v0
    .line 8: new-instance v1, Ljava/lang/StringBuilder;
    .line 10: const-string v2, ".font"
    .line 12: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 15: invoke-static {}, Landroid/os/Process;->myPid()I
    .line 18: move-result v2
    .line 19: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v2, "-"
    .line 24: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-static {}, Landroid/os/Process;->myTid()I
    .line 30: move-result v3
    .line 31: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 34: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 40: move-result-object v1
    .line 41: const/4 v2, 0
    .line 42: const/16 v3, 100
    .line 44: if-ge v2, v3, :cond_76
    .line 46: new-instance v3, Ljava/io/File;
    .line 48: new-instance v4, Ljava/lang/StringBuilder;
    .line 50: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    .line 53: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 56: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 59: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 62: move-result-object v4
    .line 63: invoke-direct {v3, v5, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 66: invoke-virtual {v3}, Ljava/io/File;->createNewFile()Z
    .line 69: move-result v4
    .line 70: if-eqz v4, :cond_73
    .line 72: return-object v3
    .line 73: add-int/lit8 v2, v2, 1
    .line 75: goto :goto_42
    .line 76: return-object v0
.end method

# direct methods
.method public static final u1(Ljava/lang/Object;Ljava/lang/String;Lu/l;I)Lh/n1;
    .registers 7

    .line 0: check-cast v5, Lu/b0;
    .line 2: const v0, 0x78f2a0ad
    .line 5: invoke-virtual {v5, v0}, Lu/b0;->d0(I)V
    .line 8: const v0, 0xe2a708a4
    .line 11: invoke-virtual {v5, v0}, Lu/b0;->d0(I)V
    .line 14: invoke-virtual {v5}, Lu/b0;->I()Ljava/lang/Object;
    .line 17: move-result-object v0
    .line 18: sget-object v1, Lu/k;->i:Landroidx/activity/b;
    .line 20: if-ne v0, v1, :cond_35
    .line 22: new-instance v0, Lh/n1;
    .line 24: new-instance v2, Lh/s0;
    .line 26: invoke-direct {v2, v3}, Lh/s0;-><init>(Ljava/lang/Object;)V
    .line 29: invoke-direct {v0, v2, v4}, Lh/n1;-><init>(Lh/s0;Ljava/lang/String;)V
    .line 32: invoke-virtual {v5, v0}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 35: const/4 v4, 0
    .line 36: invoke-virtual {v5, v4}, Lu/b0;->t(Z)V
    .line 39: check-cast v0, Lh/n1;
    .line 41: and-int/lit8 v2, v6, 8
    .line 43: or-int/lit8 v2, v2, 48
    .line 45: and-int/lit8 v6, v6, 14
    .line 47: or-int/2addr v6, v2
    .line 48: invoke-virtual {v0, v3, v5, v6}, Lh/n1;->a(Ljava/lang/Object;Lu/l;I)V
    .line 51: const v3, 0x44faf204
    .line 54: invoke-virtual {v5, v3}, Lu/b0;->d0(I)V
    .line 57: invoke-virtual {v5, v0}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 60: move-result v3
    .line 61: invoke-virtual {v5}, Lu/b0;->I()Ljava/lang/Object;
    .line 64: move-result-object v6
    .line 65: if-nez v3, :cond_69
    .line 67: if-ne v6, v1, :cond_78
    .line 69: new-instance v6, Lg/n;
    .line 71: const/4 v3, 3
    .line 72: invoke-direct {v6, v3, v0}, Lg/n;-><init>(ILjava/lang/Object;)V
    .line 75: invoke-virtual {v5, v6}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 78: invoke-virtual {v5, v4}, Lu/b0;->t(Z)V
    .line 81: check-cast v6, Ld3/c;
    .line 83: invoke-static {v0, v6, v5}, Lu/c0;->a(Ljava/lang/Object;Ld3/c;Lu/l;)V
    .line 86: invoke-virtual {v5, v4}, Lu/b0;->t(Z)V
    .line 89: return-object v0
.end method

# direct methods
.method public static v(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 2

    .line 0: if-eqz v0, :cond_3
    .line 2: return-void
    .line 3: new-instance v0, Ljava/lang/NullPointerException;
    .line 5: invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 8: const-class v1, Ld2/b;
    .line 10: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 13: move-result-object v1
    .line 14: invoke-static {v1, v0}, Ld2/b;->c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .line 17: throw v0
.end method

# direct methods
.method public static v0(Ljava/lang/String;)J
    .registers 10

    .line 0: invoke-virtual {v9}, Ljava/lang/String;->length()I
    .line 3: move-result v0
    .line 4: int-to-long v0, v0
    .line 5: const-wide/32 v2, 0x6a09e667
    .line 8: xor-long/2addr v0, v2
    .line 9: const-wide v2, 0x00ffffffff
    .line 14: and-long/2addr v0, v2
    .line 15: invoke-virtual {v9}, Ljava/lang/String;->length()I
    .line 18: move-result v4
    .line 19: const/4 v5, 0
    .line 20: if-ge v5, v4, :cond_48
    .line 22: invoke-virtual {v9, v5}, Ljava/lang/String;->charAt(I)C
    .line 25: move-result v6
    .line 26: int-to-long v6, v6
    .line 27: xor-long/2addr v0, v6
    .line 28: and-long/2addr v0, v2
    .line 29: const-wide v6, 0x00cc9e2d51
    .line 34: mul-long/2addr v0, v6
    .line 35: and-long/2addr v0, v2
    .line 36: const/16 v6, 13
    .line 38: shl-long v6, v0, v6
    .line 40: const/16 v8, 19
    .line 42: ushr-long/2addr v0, v8
    .line 43: or-long/2addr v0, v6
    .line 44: and-long/2addr v0, v2
    .line 45: add-int/lit8 v5, v5, 1
    .line 47: goto :goto_20
    .line 48: and-long/2addr v0, v2
    .line 49: return-wide v0
.end method

# direct methods
.method public static final v1(Lw2/e;Lw2/j;Ljava/lang/Object;)Ln3/w1;
    .registers 5

    .line 0: instance-of v0, v2, Ly2/d;
    .line 2: const/4 v1, 0
    .line 3: if-nez v0, :cond_6
    .line 5: return-object v1
    .line 6: sget-object v0, Ln3/x1;->i:Ln3/x1;
    .line 8: invoke-interface {v3, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 11: move-result-object v0
    .line 12: if-eqz v0, :cond_47
    .line 14: check-cast v2, Ly2/d;
    .line 16: instance-of v0, v2, Ln3/f0;
    .line 18: if-eqz v0, :cond_21
    .line 20: goto :goto_35
    .line 21: invoke-interface {v2}, Ly2/d;->f()Ly2/d;
    .line 24: move-result-object v2
    .line 25: if-nez v2, :cond_28
    .line 27: goto :goto_35
    .line 28: instance-of v0, v2, Ln3/w1;
    .line 30: if-eqz v0, :cond_16
    .line 32: move-object v1, v2
    .line 33: check-cast v1, Ln3/w1;
    .line 35: if-eqz v1, :cond_47
    .line 37: new-instance v2, Ls2/e;
    .line 39: invoke-direct {v2, v3, v4}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 42: iget-object v3, v1, Ln3/w1;->l:Ljava/lang/ThreadLocal;
    .line 44: invoke-virtual {v3, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    .line 47: return-object v1
.end method

# direct methods
.method public static w(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 3

    .line 0: if-eqz v1, :cond_3
    .line 2: return-void
    .line 3: new-instance v1, Ljava/lang/NullPointerException;
    .line 5: const-string v0, " must not be null"
    .line 7: invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 10: move-result-object v2
    .line 11: invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 14: const-class v2, Ld2/b;
    .line 16: invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 19: move-result-object v2
    .line 20: invoke-static {v2, v1}, Ld2/b;->c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .line 23: throw v1
.end method

# direct methods
.method public static w0(Lh/x;II)Lh/g0;
    .registers 5

    .line 0: and-int/lit8 v0, v4, 2
    .line 2: if-eqz v0, :cond_5
    .line 4: const/4 v3, 1
    .line 5: and-int/lit8 v4, v4, 4
    .line 7: if-eqz v4, :cond_12
    .line 9: const/4 v4, 0
    .line 10: int-to-long v0, v4
    .line 11: goto :goto_14
    .line 12: const-wide/16 v0, 0
    .line 14: const-string v4, "repeatMode"
    .line 16: invoke-static {v3, v4}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 19: new-instance v4, Lh/g0;
    .line 21: invoke-direct {v4, v2, v3, v0, v1}, Lh/g0;-><init>(Lh/x;IJ)V
    .line 24: return-object v4
.end method

# direct methods
.method public static final w1(Lw2/h;Ld3/e;Lw2/e;)Ljava/lang/Object;
    .registers 7

    .line 0: invoke-interface {v6}, Lw2/e;->n()Lw2/j;
    .line 3: move-result-object v0
    .line 4: sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 6: sget-object v2, Ln3/r;->l:Ln3/r;
    .line 8: invoke-interface {v4, v1, v2}, Lw2/j;->i(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 11: move-result-object v1
    .line 12: check-cast v1, Ljava/lang/Boolean;
    .line 14: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    .line 17: move-result v1
    .line 18: if-nez v1, :cond_25
    .line 20: invoke-interface {v0, v4}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 23: move-result-object v4
    .line 24: goto :goto_30
    .line 25: const/4 v1, 0
    .line 26: invoke-static {v0, v4, v1}, Ld2/b;->i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .line 29: move-result-object v4
    .line 30: invoke-static {v4}, Ld2/b;->a0(Lw2/j;)V
    .line 33: if-ne v4, v0, :cond_45
    .line 35: new-instance v0, Lkotlinx/coroutines/internal/s;
    .line 37: invoke-direct {v0, v6, v4}, Lkotlinx/coroutines/internal/s;-><init>(Lw2/e;Lw2/j;)V
    .line 40: invoke-static {v0, v0, v5}, Lkotlinx/coroutines/flow/c0;->j(Lkotlinx/coroutines/internal/s;Lkotlinx/coroutines/internal/s;Ld3/e;)Ljava/lang/Object;
    .line 43: move-result-object v4
    .line 44: goto :goto_147
    .line 45: sget-object v1, Lw2/f;->i:Lw2/f;
    .line 47: invoke-interface {v4, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 50: move-result-object v2
    .line 51: invoke-interface {v0, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 54: move-result-object v0
    .line 55: invoke-static {v2, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 58: move-result v0
    .line 59: if-eqz v0, :cond_135
    .line 61: new-instance v0, Ln3/w1;
    .line 63: sget-object v2, Ln3/x1;->i:Ln3/x1;
    .line 65: invoke-interface {v4, v2}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 68: move-result-object v3
    .line 69: if-nez v3, :cond_76
    .line 71: invoke-interface {v4, v2}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 74: move-result-object v2
    .line 75: goto :goto_77
    .line 76: move-object v2, v4
    .line 77: invoke-direct {v0, v6, v2}, Lkotlinx/coroutines/internal/s;-><init>(Lw2/e;Lw2/j;)V
    .line 80: new-instance v2, Ljava/lang/ThreadLocal;
    .line 82: invoke-direct {v2}, Ljava/lang/ThreadLocal;-><init>()V
    .line 85: iput-object v2, v0, Ln3/w1;->l:Ljava/lang/ThreadLocal;
    .line 87: invoke-interface {v6}, Lw2/e;->n()Lw2/j;
    .line 90: move-result-object v6
    .line 91: invoke-interface {v6, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 94: move-result-object v6
    .line 95: instance-of v6, v6, Ln3/u;
    .line 97: const/4 v1, 0
    .line 98: if-nez v6, :cond_117
    .line 100: invoke-static {v4, v1}, Lkotlinx/coroutines/internal/b;->d(Lw2/j;Ljava/lang/Object;)Ljava/lang/Object;
    .line 103: move-result-object v6
    .line 104: invoke-static {v4, v6}, Lkotlinx/coroutines/internal/b;->a(Lw2/j;Ljava/lang/Object;)V
    .line 107: new-instance v2, Ls2/e;
    .line 109: invoke-direct {v2, v4, v6}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 112: iget-object v6, v0, Ln3/w1;->l:Ljava/lang/ThreadLocal;
    .line 114: invoke-virtual {v6, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    .line 117: invoke-static {v4, v1}, Lkotlinx/coroutines/internal/b;->d(Lw2/j;Ljava/lang/Object;)Ljava/lang/Object;
    .line 120: move-result-object v6
    .line 121: invoke-static {v0, v0, v5}, Lkotlinx/coroutines/flow/c0;->j(Lkotlinx/coroutines/internal/s;Lkotlinx/coroutines/internal/s;Ld3/e;)Ljava/lang/Object;
    .line 124: move-result-object v5
    .line 125: invoke-static {v4, v6}, Lkotlinx/coroutines/internal/b;->a(Lw2/j;Ljava/lang/Object;)V
    .line 128: move-object v4, v5
    .line 129: goto :goto_147
    .line 130: move-exception v5
    .line 131: invoke-static {v4, v6}, Lkotlinx/coroutines/internal/b;->a(Lw2/j;Ljava/lang/Object;)V
    .line 134: throw v5
    .line 135: new-instance v0, Ln3/f0;
    .line 137: invoke-direct {v0, v6, v4}, Ln3/f0;-><init>(Lw2/e;Lw2/j;)V
    .line 140: invoke-static {v5, v0, v0}, Lkotlinx/coroutines/flow/c0;->i(Ld3/e;Ln3/a;Ln3/a;)V
    .line 143: invoke-virtual {v0}, Ln3/f0;->c0()Ljava/lang/Object;
    .line 146: move-result-object v4
    .line 147: return-object v4
.end method

# direct methods
.method public static x(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 7

    .line 0: if-nez v5, :cond_100
    .line 2: new-instance v5, Ljava/lang/NullPointerException;
    .line 4: invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;
    .line 7: move-result-object v0
    .line 8: invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;
    .line 11: move-result-object v0
    .line 12: const-class v1, Ld2/b;
    .line 14: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 17: move-result-object v2
    .line 18: const/4 v3, 0
    .line 19: aget-object v4, v0, v3
    .line 21: invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;
    .line 24: move-result-object v4
    .line 25: invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 28: move-result v4
    .line 29: if-nez v4, :cond_34
    .line 31: add-int/lit8 v3, v3, 1
    .line 33: goto :goto_19
    .line 34: aget-object v4, v0, v3
    .line 36: invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;
    .line 39: move-result-object v4
    .line 40: invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 43: move-result v4
    .line 44: if-eqz v4, :cond_49
    .line 46: add-int/lit8 v3, v3, 1
    .line 48: goto :goto_34
    .line 49: aget-object v0, v0, v3
    .line 51: invoke-virtual {v0}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;
    .line 54: move-result-object v2
    .line 55: invoke-virtual {v0}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;
    .line 58: move-result-object v0
    .line 59: new-instance v3, Ljava/lang/StringBuilder;
    .line 61: const-string v4, "Parameter specified as non-null is null: method "
    .line 63: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 66: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 69: const-string v2, "."
    .line 71: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 74: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: const-string v0, ", parameter "
    .line 79: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 82: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 85: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 88: move-result-object v6
    .line 89: invoke-direct {v5, v6}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 92: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 95: move-result-object v6
    .line 96: invoke-static {v6, v5}, Ld2/b;->c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .line 99: throw v5
    .line 100: return-void
.end method

# direct methods
.method public static x0(Lw2/e;)Lw2/e;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: instance-of v0, v2, Ly2/c;
    .line 7: if-eqz v0, :cond_13
    .line 9: move-object v0, v2
    .line 10: check-cast v0, Ly2/c;
    .line 12: goto :goto_14
    .line 13: const/4 v0, 0
    .line 14: if-eqz v0, :cond_46
    .line 16: iget-object v2, v0, Ly2/c;->k:Lw2/e;
    .line 18: if-nez v2, :cond_46
    .line 20: invoke-virtual {v0}, Ly2/c;->n()Lw2/j;
    .line 23: move-result-object v2
    .line 24: sget-object v1, Lw2/f;->i:Lw2/f;
    .line 26: invoke-interface {v2, v1}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 29: move-result-object v2
    .line 30: check-cast v2, Lw2/g;
    .line 32: if-eqz v2, :cond_42
    .line 34: check-cast v2, Ln3/u;
    .line 36: new-instance v1, Lkotlinx/coroutines/internal/e;
    .line 38: invoke-direct {v1, v2, v0}, Lkotlinx/coroutines/internal/e;-><init>(Ln3/u;Ly2/c;)V
    .line 41: goto :goto_43
    .line 42: move-object v1, v0
    .line 43: iput-object v1, v0, Ly2/c;->k:Lw2/e;
    .line 45: move-object v2, v1
    .line 46: return-object v2
.end method

# direct methods
.method public static final x1(JLk1/h;Lw2/e;)Ljava/lang/Object;
    .registers 11

    .line 0: instance-of v0, v10, Ln3/u1;
    .line 2: if-eqz v0, :cond_19
    .line 4: move-object v0, v10
    .line 5: check-cast v0, Ln3/u1;
    .line 7: iget v1, v0, Ln3/u1;->n:I
    .line 9: const/high16 v2, 0x8000
    .line 11: and-int v3, v1, v2
    .line 13: if-eqz v3, :cond_19
    .line 15: sub-int/2addr v1, v2
    .line 16: iput v1, v0, Ln3/u1;->n:I
    .line 18: goto :goto_24
    .line 19: new-instance v0, Ln3/u1;
    .line 21: invoke-direct {v0, v10}, Ly2/c;-><init>(Lw2/e;)V
    .line 24: iget-object v10, v0, Ln3/u1;->m:Ljava/lang/Object;
    .line 26: sget-object v1, Lx2/a;->i:Lx2/a;
    .line 28: iget v2, v0, Ln3/u1;->n:I
    .line 30: const/4 v3, 0
    .line 31: const/4 v4, 1
    .line 32: if-eqz v2, :cond_52
    .line 34: if-ne v2, v4, :cond_44
    .line 36: iget-object v7, v0, Ln3/u1;->l:Le3/s;
    .line 38: invoke-static {v10}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 41: goto :goto_88
    .line 42: move-exception v8
    .line 43: goto :goto_93
    .line 44: new-instance v7, Ljava/lang/IllegalStateException;
    .line 46: const-string v8, "call to 'resume' before 'invoke' with coroutine"
    .line 48: invoke-direct {v7, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 51: throw v7
    .line 52: invoke-static {v10}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 55: const-wide/16 v5, 0
    .line 57: cmp-long v10, v7, v5
    .line 59: if-gtz v10, :cond_62
    .line 61: return-object v3
    .line 62: new-instance v10, Le3/s;
    .line 64: invoke-direct {v10}, Ljava/lang/Object;-><init>()V
    .line 67: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 70: iput-object v10, v0, Ln3/u1;->l:Le3/s;
    .line 72: iput v4, v0, Ln3/u1;->n:I
    .line 74: new-instance v2, Ln3/t1;
    .line 76: invoke-direct {v2, v7, v8, v0}, Ln3/t1;-><init>(JLn3/u1;)V
    .line 79: iput-object v2, v10, Le3/s;->i:Ljava/lang/Object;
    .line 81: invoke-static {v2, v9}, Ld2/b;->d1(Ln3/t1;Lk1/h;)Ljava/lang/Object;
    .line 84: move-result-object v10
    .line 85: if-ne v10, v1, :cond_88
    .line 87: return-object v1
    .line 88: return-object v10
    .line 89: move-object v7, v10
    .line 90: goto :goto_93
    .line 91: move-exception v8
    .line 92: goto :goto_89
    .line 93: iget-object v9, v8, Ln3/s1;->i:Ln3/x0;
    .line 95: iget-object v7, v7, Le3/s;->i:Ljava/lang/Object;
    .line 97: if-ne v9, v7, :cond_100
    .line 99: return-object v3
    .line 100: throw v8
.end method

# direct methods
.method public static final y(II)V
    .registers 5

    .line 0: if-ltz v3, :cond_5
    .line 2: if-gt v3, v4, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    .line 7: const-string v1, "index: "
    .line 9: const-string v2, ", size: "
    .line 11: invoke-static {v1, v3, v2, v4}, Lai/onnxruntime/b;->h(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;
    .line 14: move-result-object v3
    .line 15: invoke-direct {v0, v3}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 18: throw v0
.end method

# direct methods
.method public static synthetic y0(Ln3/x0;ZLn3/b1;I)Ln3/i0;
    .registers 6

    .line 0: and-int/lit8 v0, v5, 1
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: move v3, v1
    .line 6: and-int/lit8 v5, v5, 2
    .line 8: if-eqz v5, :cond_11
    .line 10: const/4 v1, 1
    .line 11: check-cast v2, Ln3/g1;
    .line 13: invoke-virtual {v2, v3, v1, v4}, Ln3/g1;->M(ZZLd3/c;)Ln3/i0;
    .line 16: move-result-object v2
    .line 17: return-object v2
.end method

# direct methods
.method public static y1(Ljava/io/File;[B)V
    .registers 3

    .line 0: new-instance v0, Ljava/io/FileOutputStream;
    .line 2: invoke-direct {v0, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    .line 5: invoke-virtual {v0, v2}, Ljava/io/FileOutputStream;->write([B)V
    .line 8: const/4 v1, 0
    .line 9: invoke-static {v0, v1}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 12: return-void
    .line 13: move-exception v1
    .line 14: throw v1
    .line 15: move-exception v2
    .line 16: invoke-static {v0, v1}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 19: throw v2
.end method

# direct methods
.method public static final z(III)V
    .registers 6

    .line 0: const-string v0, "fromIndex: "
    .line 2: if-ltz v3, :cond_21
    .line 4: if-gt v4, v5, :cond_21
    .line 6: if-gt v3, v4, :cond_9
    .line 8: return-void
    .line 9: new-instance v5, Ljava/lang/IllegalArgumentException;
    .line 11: const-string v1, " > toIndex: "
    .line 13: invoke-static {v0, v3, v1, v4}, Lai/onnxruntime/b;->h(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;
    .line 16: move-result-object v3
    .line 17: invoke-direct {v5, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 20: throw v5
    .line 21: new-instance v1, Ljava/lang/IndexOutOfBoundsException;
    .line 23: new-instance v2, Ljava/lang/StringBuilder;
    .line 25: invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 28: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 31: const-string v3, ", toIndex: "
    .line 33: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 36: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 39: const-string v3, ", size: "
    .line 41: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 44: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v3
    .line 51: invoke-direct {v1, v3}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 54: throw v1
.end method

# direct methods
.method public static final z0(Ln3/z;)Z
    .registers 2

    .line 0: invoke-interface {v1}, Ln3/z;->getCoroutineContext()Lw2/j;
    .line 3: move-result-object v1
    .line 4: sget-object v0, Ln3/v;->j:Ln3/v;
    .line 6: invoke-interface {v1, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 9: move-result-object v1
    .line 10: check-cast v1, Ln3/x0;
    .line 12: if-eqz v1, :cond_19
    .line 14: invoke-interface {v1}, Ln3/x0;->b()Z
    .line 17: move-result v1
    .line 18: goto :goto_20
    .line 19: const/4 v1, 1
    .line 20: return v1
.end method

# direct methods
.method public static z1(Ljava/io/File;Ljava/lang/String;)V
    .registers 4

    .line 0: sget-object v0, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 2: const-string v1, "charset"
    .line 4: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: invoke-virtual {v3, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B
    .line 10: move-result-object v3
    .line 11: const-string v0, "this as java.lang.String).getBytes(charset)"
    .line 13: invoke-static {v3, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: invoke-static {v2, v3}, Ld2/b;->y1(Ljava/io/File;[B)V
    .line 19: return-void
.end method

# virtual methods
.method public abstract A(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
.end method

# virtual methods
.method public abstract k(ILr1/j;Lx0/l0;)I
.end method

.class public abstract Ld2/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final A:I
.field public static final B:I
.field public static final C:I
.field public static final D:I
.field public static final E:I
.field public static final F:I
.field public static final G:I
.field public static final H:I
.field public static a:Z
.field public static b:Ljava/lang/reflect/Method;
.field public static c:Lk0/y;
.field public static d:Lk0/o;
.field public static e:Lm0/c;
.field public static final f:I
.field public static final g:I
.field public static final h:I
.field public static final i:I
.field public static final j:I
.field public static final k:I
.field public static final l:I
.field public static final m:I
.field public static final n:I
.field public static final o:I
.field public static final p:I
.field public static final q:I
.field public static final r:I
.field public static final s:I
.field public static final t:I
.field public static final u:I
.field public static final v:I
.field public static final w:I
.field public static final x:I
.field public static final y:I
.field public static final z:I

# direct methods
.method public static final A(JJ)J
    .registers 7

    .line 0: const/16 v0, 32
    .line 2: shr-long v0, v5, v0
    .line 4: long-to-int v0, v0
    .line 5: invoke-static {v3, v4}, Lr1/a;->j(J)I
    .line 8: move-result v1
    .line 9: invoke-static {v3, v4}, Lr1/a;->h(J)I
    .line 12: move-result v2
    .line 13: invoke-static {v0, v1, v2}, Ld2/b;->G(III)I
    .line 16: move-result v0
    .line 17: const-wide v1, 0x00ffffffff
    .line 22: and-long/2addr v5, v1
    .line 23: long-to-int v5, v5
    .line 24: invoke-static {v3, v4}, Lr1/a;->i(J)I
    .line 27: move-result v6
    .line 28: invoke-static {v3, v4}, Lr1/a;->g(J)I
    .line 31: move-result v3
    .line 32: invoke-static {v5, v6, v3}, Ld2/b;->G(III)I
    .line 35: move-result v3
    .line 36: invoke-static {v0, v3}, Ld2/b;->g(II)J
    .line 39: move-result-wide v3
    .line 40: return-wide v3
.end method

# direct methods
.method public static A0(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V
    .registers 6

    .line 0: iget-object v0, v2, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;
    .line 2: if-nez v0, :cond_11
    .line 4: new-instance v0, Landroid/os/Bundle;
    .line 6: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    .line 9: iput-object v0, v2, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;
    .line 11: if-eqz v3, :cond_19
    .line 13: new-instance v0, Landroid/text/SpannableStringBuilder;
    .line 15: invoke-direct {v0, v3}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V
    .line 18: goto :goto_20
    .line 19: const/4 v0, 0
    .line 20: iget-object v3, v2, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;
    .line 22: const-string v1, "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT"
    .line 24: invoke-virtual {v3, v1, v0}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V
    .line 27: iget-object v3, v2, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;
    .line 29: const-string v0, "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD"
    .line 31: invoke-virtual {v3, v0, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 34: iget-object v2, v2, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;
    .line 36: const-string v3, "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END"
    .line 38: invoke-virtual {v2, v3, v5}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 41: return-void
.end method

# direct methods
.method public static final B(JI)I
    .registers 4

    .line 0: invoke-static {v1, v2}, Lr1/a;->i(J)I
    .line 3: move-result v0
    .line 4: invoke-static {v1, v2}, Lr1/a;->g(J)I
    .line 7: move-result v1
    .line 8: invoke-static {v3, v0, v1}, Ld2/b;->G(III)I
    .line 11: move-result v1
    .line 12: return v1
.end method

# direct methods
.method public static B0(Landroid/content/res/XmlResourceParser;)V
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: if-lez v0, :cond_20
    .line 3: invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 6: move-result v1
    .line 7: const/4 v2, 2
    .line 8: if-eq v1, v2, :cond_17
    .line 10: const/4 v2, 3
    .line 11: if-eq v1, v2, :cond_14
    .line 13: goto :goto_1
    .line 14: add-int/lit8 v0, v0, -1
    .line 16: goto :goto_1
    .line 17: add-int/lit8 v0, v0, 1
    .line 19: goto :goto_1
    .line 20: return-void
.end method

# direct methods
.method public static final C(JI)I
    .registers 4

    .line 0: invoke-static {v1, v2}, Lr1/a;->j(J)I
    .line 3: move-result v0
    .line 4: invoke-static {v1, v2}, Lr1/a;->h(J)I
    .line 7: move-result v1
    .line 8: invoke-static {v3, v0, v1}, Ld2/b;->G(III)I
    .line 11: move-result v1
    .line 12: return v1
.end method

# direct methods
.method public static final C0(Lkotlinx/coroutines/flow/g;Lkotlinx/coroutines/internal/d;Lkotlinx/coroutines/flow/m0;Ljava/lang/Float;)Lkotlinx/coroutines/flow/y;
    .registers 14

    .line 0: sget-object v0, Lp3/o;->c:Lp3/n;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: sget v0, Lp3/n;->b:I
    .line 7: const/4 v1, 1
    .line 8: if-ge v1, v0, :cond_11
    .line 10: goto :goto_12
    .line 11: move v0, v1
    .line 12: sub-int/2addr v0, v1
    .line 13: instance-of v2, v10, Lq3/g;
    .line 15: sget-object v3, Lp3/m;->i:Lp3/m;
    .line 17: if-eqz v2, :cond_56
    .line 19: move-object v2, v10
    .line 20: check-cast v2, Lq3/g;
    .line 22: invoke-virtual {v2}, Lq3/g;->f()Lkotlinx/coroutines/flow/e;
    .line 25: move-result-object v4
    .line 26: if-eqz v4, :cond_56
    .line 28: new-instance v10, Lv/f;
    .line 30: const/4 v5, -3
    .line 31: iget-object v6, v2, Lq3/g;->k:Lp3/m;
    .line 33: iget v7, v2, Lq3/g;->j:I
    .line 35: if-eq v7, v5, :cond_44
    .line 37: const/4 v5, -2
    .line 38: if-eq v7, v5, :cond_44
    .line 40: if-eqz v7, :cond_44
    .line 42: move v0, v7
    .line 43: goto :goto_50
    .line 44: const/4 v5, 0
    .line 45: if-ne v6, v3, :cond_49
    .line 47: if-nez v7, :cond_50
    .line 49: move v0, v5
    .line 50: iget-object v2, v2, Lq3/g;->i:Lw2/j;
    .line 52: invoke-direct {v10, v0, v2, v6, v4}, Lv/f;-><init>(ILw2/j;Lp3/m;Lkotlinx/coroutines/flow/e;)V
    .line 55: goto :goto_64
    .line 56: new-instance v2, Lv/f;
    .line 58: sget-object v4, Lw2/k;->i:Lw2/k;
    .line 60: invoke-direct {v2, v0, v4, v3, v10}, Lv/f;-><init>(ILw2/j;Lp3/m;Lkotlinx/coroutines/flow/e;)V
    .line 63: move-object v10, v2
    .line 64: new-instance v0, Lkotlinx/coroutines/flow/p0;
    .line 66: if-nez v13, :cond_71
    .line 68: sget-object v2, Lq3/c;->b:Lkotlinx/coroutines/internal/u;
    .line 70: goto :goto_72
    .line 71: move-object v2, v13
    .line 72: invoke-direct {v0, v2}, Lkotlinx/coroutines/flow/p0;-><init>(Ljava/lang/Object;)V
    .line 75: iget-object v2, v10, Lv/f;->d:Ljava/lang/Object;
    .line 77: move-object v8, v2
    .line 78: check-cast v8, Lw2/j;
    .line 80: iget-object v10, v10, Lv/f;->b:Ljava/lang/Object;
    .line 82: move-object v4, v10
    .line 83: check-cast v4, Lkotlinx/coroutines/flow/e;
    .line 85: sget-object v10, Lkotlinx/coroutines/flow/f0;->a:Lkotlinx/coroutines/flow/h0;
    .line 87: invoke-static {v12, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 90: move-result v10
    .line 91: if-eqz v10, :cond_95
    .line 93: move v10, v1
    .line 94: goto :goto_96
    .line 95: const/4 v10, 4
    .line 96: new-instance v9, Lkotlinx/coroutines/flow/v;
    .line 98: const/4 v7, 0
    .line 99: move-object v2, v9
    .line 100: move-object v3, v12
    .line 101: move-object v5, v0
    .line 102: move-object v6, v13
    .line 103: invoke-direct/range {v2 .. v7}, Lkotlinx/coroutines/flow/v;-><init>(Lkotlinx/coroutines/flow/g0;Lkotlinx/coroutines/flow/e;Lkotlinx/coroutines/flow/x;Ljava/lang/Object;Lw2/e;)V
    .line 106: invoke-virtual {v11}, Lkotlinx/coroutines/internal/d;->getCoroutineContext()Lw2/j;
    .line 109: move-result-object v11
    .line 110: invoke-static {v11, v8, v1}, Ld2/b;->i0(Lw2/j;Lw2/j;Z)Lw2/j;
    .line 113: move-result-object v11
    .line 114: sget-object v12, Ln3/h0;->a:Lkotlinx/coroutines/scheduling/d;
    .line 116: if-eq v11, v12, :cond_130
    .line 118: sget-object v13, Lw2/f;->i:Lw2/f;
    .line 120: invoke-interface {v11, v13}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 123: move-result-object v13
    .line 124: if-nez v13, :cond_130
    .line 126: invoke-interface {v11, v12}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 129: move-result-object v11
    .line 130: if-eqz v10, :cond_155
    .line 132: const/4 v12, 2
    .line 133: if-ne v10, v12, :cond_141
    .line 135: new-instance v12, Ln3/h1;
    .line 137: invoke-direct {v12, v11, v9}, Ln3/h1;-><init>(Lw2/j;Ld3/e;)V
    .line 140: goto :goto_146
    .line 141: new-instance v12, Ln3/o1;
    .line 143: invoke-direct {v12, v11, v1}, Ln3/a;-><init>(Lw2/j;Z)V
    .line 146: invoke-virtual {v12, v10, v12, v9}, Ln3/a;->b0(ILn3/a;Ld3/e;)V
    .line 149: new-instance v10, Lkotlinx/coroutines/flow/y;
    .line 151: invoke-direct {v10, v0}, Lkotlinx/coroutines/flow/y;-><init>(Lkotlinx/coroutines/flow/p0;)V
    .line 154: return-object v10
    .line 155: const/4 v10, 0
    .line 156: throw v10
.end method

# direct methods
.method public static final D0(ILjava/lang/Object;Lk1/q;Lk1/e0;I)Ljava/lang/Object;
    .registers 12

    .line 0: const-string v0, "typeface"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "font"
    .line 7: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "requestedWeight"
    .line 12: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: instance-of v0, v8, Landroid/graphics/Typeface;
    .line 17: if-nez v0, :cond_20
    .line 19: return-object v8
    .line 20: const/4 v0, 1
    .line 21: invoke-static {v7, v0}, Lk1/b0;->a(II)Z
    .line 24: move-result v1
    .line 25: const/4 v2, 2
    .line 26: const/4 v3, 0
    .line 27: if-nez v1, :cond_35
    .line 29: invoke-static {v7, v2}, Lk1/b0;->a(II)Z
    .line 32: move-result v1
    .line 33: if-eqz v1, :cond_62
    .line 35: move-object v1, v9
    .line 36: check-cast v1, Lk1/k0;
    .line 38: iget-object v1, v1, Lk1/k0;->b:Lk1/e0;
    .line 40: invoke-static {v1, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 43: move-result v4
    .line 44: if-nez v4, :cond_62
    .line 46: sget-object v4, Lk1/e0;->l:Lk1/e0;
    .line 48: invoke-virtual {v10, v4}, Lk1/e0;->a(Lk1/e0;)I
    .line 51: move-result v5
    .line 52: if-ltz v5, :cond_62
    .line 54: invoke-virtual {v1, v4}, Lk1/e0;->a(Lk1/e0;)I
    .line 57: move-result v1
    .line 58: if-gez v1, :cond_62
    .line 60: move v1, v0
    .line 61: goto :goto_63
    .line 62: move v1, v3
    .line 63: invoke-static {v7, v0}, Lk1/b0;->a(II)Z
    .line 66: move-result v4
    .line 67: const/4 v5, 3
    .line 68: if-nez v4, :cond_76
    .line 70: invoke-static {v7, v5}, Lk1/b0;->a(II)Z
    .line 73: move-result v7
    .line 74: if-eqz v7, :cond_89
    .line 76: move-object v7, v9
    .line 77: check-cast v7, Lk1/k0;
    .line 79: iget v7, v7, Lk1/k0;->c:I
    .line 81: invoke-static {v11, v7}, Lk1/a0;->a(II)Z
    .line 84: move-result v7
    .line 85: if-nez v7, :cond_89
    .line 87: move v7, v0
    .line 88: goto :goto_90
    .line 89: move v7, v3
    .line 90: if-nez v7, :cond_95
    .line 92: if-nez v1, :cond_95
    .line 94: return-object v8
    .line 95: sget v4, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 97: const/16 v6, 28
    .line 99: if-ge v4, v6, :cond_133
    .line 101: if-eqz v7, :cond_111
    .line 103: invoke-static {v11, v0}, Lk1/a0;->a(II)Z
    .line 106: move-result v7
    .line 107: if-eqz v7, :cond_111
    .line 109: move v7, v0
    .line 110: goto :goto_112
    .line 111: move v7, v3
    .line 112: if-eqz v7, :cond_118
    .line 114: if-eqz v1, :cond_118
    .line 116: move v0, v5
    .line 117: goto :goto_126
    .line 118: if-eqz v1, :cond_121
    .line 120: goto :goto_126
    .line 121: if-eqz v7, :cond_125
    .line 123: move v0, v2
    .line 124: goto :goto_126
    .line 125: move v0, v3
    .line 126: check-cast v8, Landroid/graphics/Typeface;
    .line 128: invoke-static {v8, v0}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;
    .line 131: move-result-object v7
    .line 132: goto :goto_168
    .line 133: if-eqz v1, :cond_138
    .line 135: iget v10, v10, Lk1/e0;->i:I
    .line 137: goto :goto_145
    .line 138: move-object v10, v9
    .line 139: check-cast v10, Lk1/k0;
    .line 141: iget-object v10, v10, Lk1/k0;->b:Lk1/e0;
    .line 143: iget v10, v10, Lk1/e0;->i:I
    .line 145: if-eqz v7, :cond_152
    .line 147: invoke-static {v11, v0}, Lk1/a0;->a(II)Z
    .line 150: move-result v7
    .line 151: goto :goto_160
    .line 152: check-cast v9, Lk1/k0;
    .line 154: iget v7, v9, Lk1/k0;->c:I
    .line 156: invoke-static {v7, v0}, Lk1/a0;->a(II)Z
    .line 159: move-result v7
    .line 160: sget-object v9, Lk1/o0;->a:Lk1/o0;
    .line 162: check-cast v8, Landroid/graphics/Typeface;
    .line 164: invoke-virtual {v9, v8, v10, v7}, Lk1/o0;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;
    .line 167: move-result-object v7
    .line 168: const-string v8, "if (Build.VERSION.SDK_IN…ht, finalFontStyle)\n    }"
    .line 170: invoke-static {v7, v8}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 173: return-object v7
.end method

# direct methods
.method public static final E(II)V
    .registers 5

    .line 0: if-gt v3, v4, :cond_3
    .line 2: return-void
    .line 3: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    .line 5: new-instance v1, Ljava/lang/StringBuilder;
    .line 7: const-string v2, "toIndex ("
    .line 9: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 12: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 15: const-string v3, ") is greater than size ("
    .line 17: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 20: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 23: const-string v3, ")."
    .line 25: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 28: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 31: move-result-object v3
    .line 32: invoke-direct {v0, v3}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    .line 35: throw v0
.end method

# direct methods
.method public static E0(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 3

    .line 0: if-nez v1, :cond_5
    .line 2: const-string v1, "null"
    .line 4: goto :goto_13
    .line 5: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 8: move-result-object v1
    .line 9: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 12: move-result-object v1
    .line 13: new-instance v0, Ljava/lang/StringBuilder;
    .line 15: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 18: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 21: const-string v1, " cannot be cast to "
    .line 23: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 29: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 32: move-result-object v1
    .line 33: new-instance v2, Ljava/lang/ClassCastException;
    .line 35: invoke-direct {v2, v1}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V
    .line 38: const-class v1, Ld2/c;
    .line 40: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 43: move-result-object v1
    .line 44: invoke-static {v1, v2}, Ld2/b;->c1(Ljava/lang/String;Ljava/lang/RuntimeException;)V
    .line 47: throw v2
.end method

# direct methods
.method public static F(I)D
    .registers 7

    .line 0: const/16 v0, -1000
    .line 2: const/16 v1, 1000
    .line 4: invoke-static {v6, v0, v1}, Ld2/b;->G(III)I
    .line 7: move-result v6
    .line 8: const-wide v0, 0xbf6e29e1a5ccd8b6
    .line 13: int-to-double v2, v6
    .line 14: mul-double/2addr v2, v0
    .line 15: invoke-static {v2, v3}, Ljava/lang/Math;->exp(D)D
    .line 18: move-result-wide v0
    .line 19: const-wide/high16 v2, 0x3ff0
    .line 21: add-double/2addr v0, v2
    .line 22: const-wide/high16 v4, 0x4000
    .line 24: div-double/2addr v4, v0
    .line 25: sub-double/2addr v4, v2
    .line 26: const-wide/high16 v0, 0x3fe0
    .line 28: mul-double/2addr v4, v0
    .line 29: add-double/2addr v4, v0
    .line 30: return-wide v4
.end method

# direct methods
.method public static final F0(Ljava/lang/Object;)V
    .registers 2

    .line 0: instance-of v0, v1, Ls2/f;
    .line 2: if-nez v0, :cond_5
    .line 4: return-void
    .line 5: check-cast v1, Ls2/f;
    .line 7: iget-object v1, v1, Ls2/f;->i:Ljava/lang/Throwable;
    .line 9: throw v1
.end method

# direct methods
.method public static final G(Ljava/lang/Throwable;)Ls2/f;
    .registers 2

    .line 0: const-string v0, "exception"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Ls2/f;
    .line 7: invoke-direct {v0, v1}, Ls2/f;-><init>(Ljava/lang/Throwable;)V
    .line 10: return-object v0
.end method

# direct methods
.method public static G0(I)Ljava/lang/String;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-static {v1, v0}, Ld2/c;->N(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: const-string v1, "None"
    .line 9: goto :goto_42
    .line 10: const/4 v0, 1
    .line 11: invoke-static {v1, v0}, Ld2/c;->N(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: const-string v1, "Characters"
    .line 19: goto :goto_42
    .line 20: const/4 v0, 2
    .line 21: invoke-static {v1, v0}, Ld2/c;->N(II)Z
    .line 24: move-result v0
    .line 25: if-eqz v0, :cond_30
    .line 27: const-string v1, "Words"
    .line 29: goto :goto_42
    .line 30: const/4 v0, 3
    .line 31: invoke-static {v1, v0}, Ld2/c;->N(II)Z
    .line 34: move-result v1
    .line 35: if-eqz v1, :cond_40
    .line 37: const-string v1, "Sentences"
    .line 39: goto :goto_42
    .line 40: const-string v1, "Invalid"
    .line 42: return-object v1
.end method

# direct methods
.method public static final H(Landroid/content/Context;)Lk1/u;
    .registers 5

    .line 0: new-instance v0, Lk1/u;
    .line 2: new-instance v1, Lk1/b;
    .line 4: invoke-direct {v1, v4}, Lk1/b;-><init>(Landroid/content/Context;)V
    .line 7: sget v2, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 9: const/16 v3, 31
    .line 11: if-lt v2, v3, :cond_26
    .line 13: invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 16: move-result-object v4
    .line 17: invoke-virtual {v4}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    .line 20: move-result-object v4
    .line 21: invoke-static {v4}, Landroidx/compose/ui/platform/m;->a(Landroid/content/res/Configuration;)I
    .line 24: move-result v4
    .line 25: goto :goto_27
    .line 26: const/4 v4, 0
    .line 27: new-instance v2, Lk1/d;
    .line 29: invoke-direct {v2, v4}, Lk1/d;-><init>(I)V
    .line 32: invoke-direct {v0, v1, v2}, Lk1/u;-><init>(Lk1/b;Lk1/d;)V
    .line 35: return-object v0
.end method

# direct methods
.method public static H0(I)Ljava/lang/String;
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: invoke-static {v1, v0}, Ld2/c;->O(II)Z
    .line 4: move-result v0
    .line 5: if-eqz v0, :cond_10
    .line 7: const-string v1, "Clip"
    .line 9: goto :goto_32
    .line 10: const/4 v0, 2
    .line 11: invoke-static {v1, v0}, Ld2/c;->O(II)Z
    .line 14: move-result v0
    .line 15: if-eqz v0, :cond_20
    .line 17: const-string v1, "Ellipsis"
    .line 19: goto :goto_32
    .line 20: const/4 v0, 3
    .line 21: invoke-static {v1, v0}, Ld2/c;->O(II)Z
    .line 24: move-result v1
    .line 25: if-eqz v1, :cond_30
    .line 27: const-string v1, "Visible"
    .line 29: goto :goto_32
    .line 30: const-string v1, "Invalid"
    .line 32: return-object v1
.end method

# direct methods
.method public static final I(JLw2/e;)Ljava/lang/Object;
    .registers 7

    .line 0: const-wide/16 v0, 0
    .line 2: cmp-long v0, v4, v0
    .line 4: sget-object v1, Ls2/k;->a:Ls2/k;
    .line 6: if-gtz v0, :cond_9
    .line 8: return-object v1
    .line 9: new-instance v0, Ln3/h;
    .line 11: invoke-static {v6}, Ld2/b;->x0(Lw2/e;)Lw2/e;
    .line 14: move-result-object v6
    .line 15: const/4 v2, 1
    .line 16: invoke-direct {v0, v2, v6}, Ln3/h;-><init>(ILw2/e;)V
    .line 19: invoke-virtual {v0}, Ln3/h;->q()V
    .line 22: const-wide v2, 0x7fffffffffffffff
    .line 27: cmp-long v6, v4, v2
    .line 29: if-gez v6, :cond_54
    .line 31: sget-object v6, Lw2/f;->i:Lw2/f;
    .line 33: iget-object v2, v0, Ln3/h;->m:Lw2/j;
    .line 35: invoke-interface {v2, v6}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 38: move-result-object v6
    .line 39: instance-of v2, v6, Ln3/d0;
    .line 41: if-eqz v2, :cond_46
    .line 43: check-cast v6, Ln3/d0;
    .line 45: goto :goto_47
    .line 46: const/4 v6, 0
    .line 47: if-nez v6, :cond_51
    .line 49: sget-object v6, Ln3/c0;->a:Ln3/d0;
    .line 51: invoke-interface {v6, v4, v5, v0}, Ln3/d0;->r(JLn3/h;)V
    .line 54: invoke-virtual {v0}, Ln3/h;->p()Ljava/lang/Object;
    .line 57: move-result-object v4
    .line 58: sget-object v5, Lx2/a;->i:Lx2/a;
    .line 60: if-ne v4, v5, :cond_63
    .line 62: return-object v4
    .line 63: return-object v1
.end method

# direct methods
.method public static final I0(Lk1/e;)Ljava/lang/Object;
    .registers 9

    .line 0: iget-object v0, v8, Ly2/c;->j:Lw2/j;
    .line 2: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 5: invoke-static {v0}, Ld2/b;->a0(Lw2/j;)V
    .line 8: invoke-static {v8}, Ld2/b;->x0(Lw2/e;)Lw2/e;
    .line 11: move-result-object v8
    .line 12: instance-of v1, v8, Lkotlinx/coroutines/internal/e;
    .line 14: const/4 v2, 0
    .line 15: if-eqz v1, :cond_20
    .line 17: check-cast v8, Lkotlinx/coroutines/internal/e;
    .line 19: goto :goto_21
    .line 20: move-object v8, v2
    .line 21: sget-object v1, Ls2/k;->a:Ls2/k;
    .line 23: sget-object v3, Lx2/a;->i:Lx2/a;
    .line 25: if-nez v8, :cond_29
    .line 27: move-object v8, v1
    .line 28: goto :goto_124
    .line 29: iget-object v4, v8, Lkotlinx/coroutines/internal/e;->l:Ln3/u;
    .line 31: invoke-virtual {v4}, Ln3/u;->O()Z
    .line 34: move-result v5
    .line 35: const/4 v6, 1
    .line 36: if-eqz v5, :cond_46
    .line 38: iput-object v1, v8, Lkotlinx/coroutines/internal/e;->n:Ljava/lang/Object;
    .line 40: iput v6, v8, Ln3/g0;->k:I
    .line 42: invoke-virtual {v4, v0, v8}, Ln3/u;->N(Lw2/j;Ljava/lang/Runnable;)V
    .line 45: goto :goto_96
    .line 46: new-instance v5, Ln3/y1;
    .line 48: sget-object v7, Ln3/y1;->k:Ln3/v;
    .line 50: invoke-direct {v5, v7}, Lw2/a;-><init>(Lw2/i;)V
    .line 53: invoke-interface {v0, v5}, Lw2/j;->g(Lw2/j;)Lw2/j;
    .line 56: move-result-object v0
    .line 57: iput-object v1, v8, Lkotlinx/coroutines/internal/e;->n:Ljava/lang/Object;
    .line 59: iput v6, v8, Ln3/g0;->k:I
    .line 61: invoke-virtual {v4, v0, v8}, Ln3/u;->N(Lw2/j;Ljava/lang/Runnable;)V
    .line 64: iget-boolean v0, v5, Ln3/y1;->j:Z
    .line 66: if-eqz v0, :cond_96
    .line 68: invoke-static {}, Ln3/r1;->a()Ln3/r0;
    .line 71: move-result-object v0
    .line 72: iget-object v4, v0, Ln3/r0;->m:Lkotlinx/coroutines/internal/a;
    .line 74: if-eqz v4, :cond_27
    .line 76: iget v5, v4, Lkotlinx/coroutines/internal/a;->a:I
    .line 78: iget v4, v4, Lkotlinx/coroutines/internal/a;->b:I
    .line 80: if-ne v5, v4, :cond_83
    .line 82: goto :goto_27
    .line 83: invoke-virtual {v0}, Ln3/r0;->T()Z
    .line 86: move-result v4
    .line 87: if-eqz v4, :cond_98
    .line 89: iput-object v1, v8, Lkotlinx/coroutines/internal/e;->n:Ljava/lang/Object;
    .line 91: iput v6, v8, Ln3/g0;->k:I
    .line 93: invoke-virtual {v0, v8}, Ln3/r0;->Q(Ln3/g0;)V
    .line 96: move-object v8, v3
    .line 97: goto :goto_124
    .line 98: invoke-virtual {v0, v6}, Ln3/r0;->S(Z)V
    .line 101: invoke-virtual {v8}, Ln3/g0;->run()V
    .line 104: invoke-virtual {v0}, Ln3/r0;->V()Z
    .line 107: move-result v4
    .line 108: if-nez v4, :cond_104
    .line 110: invoke-virtual {v0, v6}, Ln3/r0;->P(Z)V
    .line 113: goto :goto_27
    .line 114: move-exception v4
    .line 115: invoke-virtual {v8, v4, v2}, Ln3/g0;->g(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .line 118: goto :goto_110
    .line 119: move-exception v8
    .line 120: invoke-virtual {v0, v6}, Ln3/r0;->P(Z)V
    .line 123: throw v8
    .line 124: if-ne v8, v3, :cond_127
    .line 126: return-object v8
    .line 127: return-object v1
.end method

# direct methods
.method public static J(Landroid/view/View;Landroid/view/KeyEvent;)Z
    .registers 7

    .line 0: sget v0, Le2/q;->a:I
    .line 2: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 4: const/16 v1, 28
    .line 6: const/4 v2, 0
    .line 7: if-lt v0, v1, :cond_11
    .line 9: goto/16 :goto_155
    .line 11: sget-object v0, Le2/p;->d:Ljava/util/ArrayList;
    .line 13: const v0, 0x7f06004b
    .line 16: invoke-virtual {v5, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 19: move-result-object v1
    .line 20: check-cast v1, Le2/p;
    .line 22: const/4 v3, 0
    .line 23: if-nez v1, :cond_39
    .line 25: new-instance v1, Le2/p;
    .line 27: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 30: iput-object v3, v1, Le2/p;->a:Ljava/util/WeakHashMap;
    .line 32: iput-object v3, v1, Le2/p;->b:Landroid/util/SparseArray;
    .line 34: iput-object v3, v1, Le2/p;->c:Ljava/lang/ref/WeakReference;
    .line 36: invoke-virtual {v5, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 39: iget-object v5, v1, Le2/p;->c:Ljava/lang/ref/WeakReference;
    .line 41: if-eqz v5, :cond_50
    .line 43: invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 46: move-result-object v5
    .line 47: if-ne v5, v6, :cond_50
    .line 49: goto :goto_155
    .line 50: new-instance v5, Ljava/lang/ref/WeakReference;
    .line 52: invoke-direct {v5, v6}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 55: iput-object v5, v1, Le2/p;->c:Ljava/lang/ref/WeakReference;
    .line 57: iget-object v5, v1, Le2/p;->b:Landroid/util/SparseArray;
    .line 59: if-nez v5, :cond_68
    .line 61: new-instance v5, Landroid/util/SparseArray;
    .line 63: invoke-direct {v5}, Landroid/util/SparseArray;-><init>()V
    .line 66: iput-object v5, v1, Le2/p;->b:Landroid/util/SparseArray;
    .line 68: iget-object v5, v1, Le2/p;->b:Landroid/util/SparseArray;
    .line 70: invoke-virtual {v6}, Landroid/view/KeyEvent;->getAction()I
    .line 73: move-result v0
    .line 74: const/4 v1, 1
    .line 75: if-ne v0, v1, :cond_97
    .line 77: invoke-virtual {v6}, Landroid/view/KeyEvent;->getKeyCode()I
    .line 80: move-result v0
    .line 81: invoke-virtual {v5, v0}, Landroid/util/SparseArray;->indexOfKey(I)I
    .line 84: move-result v0
    .line 85: if-ltz v0, :cond_97
    .line 87: invoke-virtual {v5, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;
    .line 90: move-result-object v4
    .line 91: check-cast v4, Ljava/lang/ref/WeakReference;
    .line 93: invoke-virtual {v5, v0}, Landroid/util/SparseArray;->removeAt(I)V
    .line 96: goto :goto_98
    .line 97: move-object v4, v3
    .line 98: if-nez v4, :cond_111
    .line 100: invoke-virtual {v6}, Landroid/view/KeyEvent;->getKeyCode()I
    .line 103: move-result v6
    .line 104: invoke-virtual {v5, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;
    .line 107: move-result-object v5
    .line 108: move-object v4, v5
    .line 109: check-cast v4, Ljava/lang/ref/WeakReference;
    .line 111: if-eqz v4, :cond_155
    .line 113: invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 116: move-result-object v5
    .line 117: check-cast v5, Landroid/view/View;
    .line 119: if-eqz v5, :cond_154
    .line 121: invoke-static {v5}, Le2/k;->b(Landroid/view/View;)Z
    .line 124: move-result v6
    .line 125: if-eqz v6, :cond_154
    .line 127: const v6, 0x7f06004c
    .line 130: invoke-virtual {v5, v6}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 133: move-result-object v5
    .line 134: check-cast v5, Ljava/util/ArrayList;
    .line 136: if-eqz v5, :cond_154
    .line 138: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 141: move-result v6
    .line 142: sub-int/2addr v6, v1
    .line 143: if-gez v6, :cond_146
    .line 145: goto :goto_154
    .line 146: invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 149: move-result-object v5
    .line 150: invoke-static {v5}, Lai/onnxruntime/b;->u(Ljava/lang/Object;)V
    .line 153: throw v3
    .line 154: move v2, v1
    .line 155: return v2
.end method

# direct methods
.method public static final K(Lkotlinx/coroutines/flow/e;)Lkotlinx/coroutines/flow/e;
    .registers 5

    .line 0: instance-of v0, v4, Lkotlinx/coroutines/flow/n0;
    .line 2: if-eqz v0, :cond_5
    .line 4: goto :goto_31
    .line 5: sget-object v0, Lkotlinx/coroutines/flow/k;->j:Lkotlinx/coroutines/flow/k;
    .line 7: sget-object v1, Lkotlinx/coroutines/flow/j;->j:Lkotlinx/coroutines/flow/j;
    .line 9: instance-of v2, v4, Lkotlinx/coroutines/flow/d;
    .line 11: if-eqz v2, :cond_25
    .line 13: move-object v2, v4
    .line 14: check-cast v2, Lkotlinx/coroutines/flow/d;
    .line 16: iget-object v3, v2, Lkotlinx/coroutines/flow/d;->j:Ld3/c;
    .line 18: if-ne v3, v0, :cond_25
    .line 20: iget-object v0, v2, Lkotlinx/coroutines/flow/d;->k:Ld3/e;
    .line 22: if-ne v0, v1, :cond_25
    .line 24: goto :goto_31
    .line 25: new-instance v0, Lkotlinx/coroutines/flow/d;
    .line 27: invoke-direct {v0, v4}, Lkotlinx/coroutines/flow/d;-><init>(Lkotlinx/coroutines/flow/e;)V
    .line 30: move-object v4, v0
    .line 31: return-object v4
.end method

# direct methods
.method public static final L([F[F)F
    .registers 7

    .line 0: array-length v0, v5
    .line 1: const/4 v1, 0
    .line 2: const/4 v2, 0
    .line 3: if-ge v2, v0, :cond_14
    .line 5: aget v3, v5, v2
    .line 7: aget v4, v6, v2
    .line 9: mul-float/2addr v3, v4
    .line 10: add-float/2addr v1, v3
    .line 11: add-int/lit8 v2, v2, 1
    .line 13: goto :goto_3
    .line 14: return v1
.end method

# direct methods
.method public static final M(CCZ)Z
    .registers 5

    .line 0: const/4 v0, 1
    .line 1: if-ne v2, v3, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-nez v4, :cond_8
    .line 7: return v1
    .line 8: invoke-static {v2}, Ljava/lang/Character;->toUpperCase(C)C
    .line 11: move-result v2
    .line 12: invoke-static {v3}, Ljava/lang/Character;->toUpperCase(C)C
    .line 15: move-result v3
    .line 16: if-eq v2, v3, :cond_30
    .line 18: invoke-static {v2}, Ljava/lang/Character;->toLowerCase(C)C
    .line 21: move-result v2
    .line 22: invoke-static {v3}, Ljava/lang/Character;->toLowerCase(C)C
    .line 25: move-result v3
    .line 26: if-ne v2, v3, :cond_29
    .line 28: goto :goto_30
    .line 29: move v0, v1
    .line 30: return v0
.end method

# direct methods
.method public static final N(II)Z
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 1
    .line 3: goto :goto_5
    .line 4: const/4 v0, 0
    .line 5: return v0
.end method

# direct methods
.method public static final O(II)Z
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 1
    .line 3: goto :goto_5
    .line 4: const/4 v0, 0
    .line 5: return v0
.end method

# direct methods
.method public static P(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    .registers 9

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Ljava/lang/StringBuilder;
    .line 7: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 10: const-string v1, ""
    .line 12: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 15: invoke-interface {v7}, Ljava/util/List;->size()I
    .line 18: move-result v2
    .line 19: const/4 v3, 0
    .line 20: move v4, v3
    .line 21: if-ge v3, v2, :cond_71
    .line 23: invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 26: move-result-object v5
    .line 27: const/4 v6, 1
    .line 28: add-int/2addr v4, v6
    .line 29: if-le v4, v6, :cond_34
    .line 31: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 34: if-nez v5, :cond_37
    .line 36: goto :goto_41
    .line 37: instance-of v6, v5, Ljava/lang/CharSequence;
    .line 39: if-eqz v6, :cond_47
    .line 41: check-cast v5, Ljava/lang/CharSequence;
    .line 43: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 46: goto :goto_68
    .line 47: instance-of v6, v5, Ljava/lang/Character;
    .line 49: if-eqz v6, :cond_61
    .line 51: check-cast v5, Ljava/lang/Character;
    .line 53: invoke-virtual {v5}, Ljava/lang/Character;->charValue()C
    .line 56: move-result v5
    .line 57: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;
    .line 60: goto :goto_68
    .line 61: invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    .line 64: move-result-object v5
    .line 65: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 68: add-int/lit8 v3, v3, 1
    .line 70: goto :goto_21
    .line 71: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    .line 74: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 77: move-result-object v7
    .line 78: const-string v8, "fastJoinTo(StringBuilder…form)\n        .toString()"
    .line 80: invoke-static {v7, v8}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 83: return-object v7
.end method

# direct methods
.method public static final Q(Lkotlinx/coroutines/flow/e;Ld3/e;Lw2/e;)Ljava/lang/Object;
    .registers 8

    .line 0: instance-of v0, v7, Lkotlinx/coroutines/flow/s;
    .line 2: if-eqz v0, :cond_19
    .line 4: move-object v0, v7
    .line 5: check-cast v0, Lkotlinx/coroutines/flow/s;
    .line 7: iget v1, v0, Lkotlinx/coroutines/flow/s;->p:I
    .line 9: const/high16 v2, 0x8000
    .line 11: and-int v3, v1, v2
    .line 13: if-eqz v3, :cond_19
    .line 15: sub-int/2addr v1, v2
    .line 16: iput v1, v0, Lkotlinx/coroutines/flow/s;->p:I
    .line 18: goto :goto_24
    .line 19: new-instance v0, Lkotlinx/coroutines/flow/s;
    .line 21: invoke-direct {v0, v7}, Ly2/c;-><init>(Lw2/e;)V
    .line 24: iget-object v7, v0, Lkotlinx/coroutines/flow/s;->o:Ljava/lang/Object;
    .line 26: sget-object v1, Lx2/a;->i:Lx2/a;
    .line 28: iget v2, v0, Lkotlinx/coroutines/flow/s;->p:I
    .line 30: sget-object v3, Lq3/c;->b:Lkotlinx/coroutines/internal/u;
    .line 32: const/4 v4, 1
    .line 33: if-eqz v2, :cond_57
    .line 35: if-ne v2, v4, :cond_49
    .line 37: iget-object v5, v0, Lkotlinx/coroutines/flow/s;->n:Lkotlinx/coroutines/flow/r;
    .line 39: iget-object v6, v0, Lkotlinx/coroutines/flow/s;->m:Le3/s;
    .line 41: iget-object v0, v0, Lkotlinx/coroutines/flow/s;->l:Ld3/e;
    .line 43: invoke-static {v7}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 46: goto :goto_99
    .line 47: move-exception v7
    .line 48: goto :goto_95
    .line 49: new-instance v5, Ljava/lang/IllegalStateException;
    .line 51: const-string v6, "call to 'resume' before 'invoke' with coroutine"
    .line 53: invoke-direct {v5, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 56: throw v5
    .line 57: invoke-static {v7}, Ld2/c;->F0(Ljava/lang/Object;)V
    .line 60: new-instance v7, Le3/s;
    .line 62: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 65: iput-object v3, v7, Le3/s;->i:Ljava/lang/Object;
    .line 67: new-instance v2, Lkotlinx/coroutines/flow/r;
    .line 69: invoke-direct {v2, v6, v7}, Lkotlinx/coroutines/flow/r;-><init>(Ld3/e;Le3/s;)V
    .line 72: iput-object v6, v0, Lkotlinx/coroutines/flow/s;->l:Ld3/e;
    .line 74: iput-object v7, v0, Lkotlinx/coroutines/flow/s;->m:Le3/s;
    .line 76: iput-object v2, v0, Lkotlinx/coroutines/flow/s;->n:Lkotlinx/coroutines/flow/r;
    .line 78: iput v4, v0, Lkotlinx/coroutines/flow/s;->p:I
    .line 80: invoke-interface {v5, v2, v0}, Lkotlinx/coroutines/flow/e;->b(Lkotlinx/coroutines/flow/f;Lw2/e;)Ljava/lang/Object;
    .line 83: move-result-object v5
    .line 84: if-ne v5, v1, :cond_87
    .line 86: goto :goto_103
    .line 87: move-object v0, v6
    .line 88: move-object v6, v7
    .line 89: goto :goto_99
    .line 90: move-exception v5
    .line 91: move-object v0, v6
    .line 92: move-object v6, v7
    .line 93: move-object v7, v5
    .line 94: move-object v5, v2
    .line 95: iget-object v1, v7, Lq3/a;->i:Lkotlinx/coroutines/flow/f;
    .line 97: if-ne v1, v5, :cond_124
    .line 99: iget-object v1, v6, Le3/s;->i:Ljava/lang/Object;
    .line 101: if-eq v1, v3, :cond_104
    .line 103: return-object v1
    .line 104: new-instance v5, Ljava/util/NoSuchElementException;
    .line 106: new-instance v6, Ljava/lang/StringBuilder;
    .line 108: const-string v7, "Expected at least one element matching the predicate "
    .line 110: invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 113: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 116: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 119: move-result-object v6
    .line 120: invoke-direct {v5, v6}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V
    .line 123: throw v5
    .line 124: throw v7
.end method

# direct methods
.method public static final R(Landroid/view/View;)Landroidx/lifecycle/t;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Landroidx/lifecycle/i0;->l:Landroidx/lifecycle/i0;
    .line 7: invoke-static {v1, v0}, Lc3/d;->E1(Ljava/lang/Object;Ld3/c;)Ll3/h;
    .line 10: move-result-object v1
    .line 11: sget-object v0, Landroidx/lifecycle/i0;->m:Landroidx/lifecycle/i0;
    .line 13: invoke-static {v1, v0}, Ll3/j;->G1(Ll3/h;Ld3/c;)Ll3/f;
    .line 16: move-result-object v1
    .line 17: invoke-static {v1}, Ll3/j;->F1(Ll3/f;)Ljava/lang/Object;
    .line 20: move-result-object v1
    .line 21: check-cast v1, Landroidx/lifecycle/t;
    .line 23: return-object v1
.end method

# direct methods
.method public static final S(Landroid/view/View;)Ll2/f;
    .registers 2

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Ll2/g;->k:Ll2/g;
    .line 7: invoke-static {v1, v0}, Lc3/d;->E1(Ljava/lang/Object;Ld3/c;)Ll3/h;
    .line 10: move-result-object v1
    .line 11: sget-object v0, Ll2/g;->l:Ll2/g;
    .line 13: invoke-static {v1, v0}, Ll3/j;->G1(Ll3/h;Ld3/c;)Ll3/f;
    .line 16: move-result-object v1
    .line 17: invoke-static {v1}, Ll3/j;->F1(Ll3/f;)Ljava/lang/Object;
    .line 20: move-result-object v1
    .line 21: check-cast v1, Ll2/f;
    .line 23: return-object v1
.end method

# direct methods
.method public static final U(Lk1/e0;I)I
    .registers 4

    .line 0: const-string v0, "fontWeight"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Lk1/e0;->l:Lk1/e0;
    .line 7: invoke-virtual {v2, v0}, Lk1/e0;->a(Lk1/e0;)I
    .line 10: move-result v2
    .line 11: const/4 v0, 0
    .line 12: const/4 v1, 1
    .line 13: if-ltz v2, :cond_17
    .line 15: move v2, v1
    .line 16: goto :goto_18
    .line 17: move v2, v0
    .line 18: invoke-static {v3, v1}, Lk1/a0;->a(II)Z
    .line 21: move-result v3
    .line 22: if-eqz v3, :cond_28
    .line 24: if-eqz v2, :cond_28
    .line 26: const/4 v0, 3
    .line 27: goto :goto_35
    .line 28: if-eqz v2, :cond_32
    .line 30: move v0, v1
    .line 31: goto :goto_35
    .line 32: if-eqz v3, :cond_35
    .line 34: const/4 v0, 2
    .line 35: return v0
.end method

# direct methods
.method public static final V(J)J
    .registers 4

    .line 0: invoke-static {v2, v3}, Lj0/f;->d(J)F
    .line 3: move-result v0
    .line 4: const/high16 v1, 0x4000
    .line 6: div-float/2addr v0, v1
    .line 7: invoke-static {v2, v3}, Lj0/f;->b(J)F
    .line 10: move-result v2
    .line 11: div-float/2addr v2, v1
    .line 12: invoke-static {v0, v2}, Ln3/a0;->g(FF)J
    .line 15: move-result-wide v2
    .line 16: return-wide v2
.end method

# direct methods
.method public static final W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .registers 3

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "key"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: iget-object v1, v1, Ld1/i;->i:Ljava/util/LinkedHashMap;
    .line 12: invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 15: move-result-object v1
    .line 16: if-nez v1, :cond_19
    .line 18: const/4 v1, 0
    .line 19: return-object v1
.end method

# direct methods
.method public static final X(Landroid/view/View;)Lh2/a;
    .registers 3

    .line 0: const v0, 0x7f06003d
    .line 3: invoke-virtual {v2, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 6: move-result-object v1
    .line 7: check-cast v1, Lh2/a;
    .line 9: if-nez v1, :cond_19
    .line 11: new-instance v1, Lh2/a;
    .line 13: invoke-direct {v1}, Lh2/a;-><init>()V
    .line 16: invoke-virtual {v2, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 19: return-object v1
.end method

# direct methods
.method public static final Y(D)J
    .registers 4

    .line 0: const-wide v0, 0x0100
    .line 5: double-to-float v2, v2
    .line 6: invoke-static {v2, v0, v1}, Ld2/c;->m0(FJ)J
    .line 9: move-result-wide v2
    .line 10: return-wide v2
.end method

# direct methods
.method public static final Z(I)J
    .registers 3

    .line 0: const-wide v0, 0x0100
    .line 5: int-to-float v2, v2
    .line 6: invoke-static {v2, v0, v1}, Ld2/c;->m0(FJ)J
    .line 9: move-result-wide v0
    .line 10: return-wide v0
.end method

# direct methods
.method public static final a(IIII)J
    .registers 5

    .line 0: const/16 v0, 41
    .line 2: if-lt v2, v1, :cond_87
    .line 4: if-lt v4, v3, :cond_52
    .line 6: if-ltz v1, :cond_15
    .line 8: if-ltz v3, :cond_15
    .line 10: invoke-static {v1, v2, v3, v4}, Lz3/b;->o(IIII)J
    .line 13: move-result-wide v1
    .line 14: return-wide v1
    .line 15: new-instance v2, Ljava/lang/StringBuilder;
    .line 17: const-string v4, "minWidth("
    .line 19: invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 22: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 25: const-string v1, ") and minHeight("
    .line 27: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 33: const-string v1, ") must be >= 0"
    .line 35: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 38: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 41: move-result-object v1
    .line 42: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 44: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 47: move-result-object v1
    .line 48: invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 51: throw v2
    .line 52: new-instance v1, Ljava/lang/StringBuilder;
    .line 54: const-string v2, "maxHeight("
    .line 56: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 59: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 62: const-string v2, ") must be >= than minHeight("
    .line 64: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 70: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 73: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 76: move-result-object v1
    .line 77: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 79: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 82: move-result-object v1
    .line 83: invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 86: throw v2
    .line 87: new-instance v3, Ljava/lang/StringBuilder;
    .line 89: const-string v4, "maxWidth("
    .line 91: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 94: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 97: const-string v2, ") must be >= than minWidth("
    .line 99: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 102: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 105: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 108: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 111: move-result-object v1
    .line 112: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 114: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 117: move-result-object v1
    .line 118: invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 121: throw v2
.end method

# direct methods
.method public static final a0(Lw2/j;Ljava/lang/Throwable;)V
    .registers 5

    .line 0: sget-object v0, Ln3/v;->i:Ln3/v;
    .line 2: invoke-interface {v3, v0}, Lw2/j;->I(Lw2/i;)Lw2/h;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ln3/w;
    .line 8: if-eqz v0, :cond_16
    .line 10: invoke-interface {v0, v3, v4}, Ln3/w;->x(Lw2/j;Ljava/lang/Throwable;)V
    .line 13: return-void
    .line 14: move-exception v0
    .line 15: goto :goto_20
    .line 16: invoke-static {v3, v4}, Ln3/x;->a(Lw2/j;Ljava/lang/Throwable;)V
    .line 19: return-void
    .line 20: if-ne v4, v0, :cond_23
    .line 22: goto :goto_34
    .line 23: new-instance v1, Ljava/lang/RuntimeException;
    .line 25: const-string v2, "Exception while trying to handle coroutine exception"
    .line 27: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 30: invoke-static {v1, v4}, Ld2/b;->j(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .line 33: move-object v4, v1
    .line 34: invoke-static {v3, v4}, Ln3/x;->a(Lw2/j;Ljava/lang/Throwable;)V
    .line 37: return-void
.end method

# direct methods
.method public static synthetic b(III)J
    .registers 5

    .line 0: and-int/lit8 v0, v4, 2
    .line 2: const v1, 0x7fffffff
    .line 5: if-eqz v0, :cond_8
    .line 7: move v2, v1
    .line 8: and-int/lit8 v4, v4, 8
    .line 10: if-eqz v4, :cond_13
    .line 12: move v3, v1
    .line 13: const/4 v4, 0
    .line 14: invoke-static {v4, v2, v4, v3}, Ld2/c;->a(IIII)J
    .line 17: move-result-wide v2
    .line 18: return-wide v2
.end method

# direct methods
.method public static final b0(Ld1/n;)Z
    .registers 3

    .line 0: invoke-virtual {v2}, Ld1/n;->h()Ld1/i;
    .line 3: move-result-object v0
    .line 4: sget-object v1, Ld1/q;->f:Ld1/t;
    .line 6: invoke-static {v0, v1}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 9: move-result-object v0
    .line 10: if-nez v0, :cond_27
    .line 12: invoke-virtual {v2}, Ld1/n;->h()Ld1/i;
    .line 15: move-result-object v2
    .line 16: sget-object v0, Ld1/q;->e:Ld1/t;
    .line 18: invoke-static {v2, v0}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 21: move-result-object v2
    .line 22: if-eqz v2, :cond_25
    .line 24: goto :goto_27
    .line 25: const/4 v2, 0
    .line 26: goto :goto_28
    .line 27: const/4 v2, 1
    .line 28: return v2
.end method

# direct methods
.method public static c(I)Lk1/k0;
    .registers 8

    .line 0: sget-object v2, Lk1/e0;->m:Lk1/e0;
    .line 2: const/4 v3, 0
    .line 3: const/4 v5, 0
    .line 4: const-string v0, "weight"
    .line 6: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: new-instance v6, Lk1/k0;
    .line 11: new-instance v4, Lk1/d0;
    .line 13: const/4 v0, 0
    .line 14: new-array v0, v0, [Lk1/c0;
    .line 16: invoke-direct {v4, v0}, Lk1/d0;-><init>([Lk1/c0;)V
    .line 19: move-object v0, v6
    .line 20: move v1, v7
    .line 21: invoke-direct/range {v0 .. v5}, Lk1/k0;-><init>(ILk1/e0;ILk1/d0;I)V
    .line 24: return-object v6
.end method

# direct methods
.method public static c0(Landroid/content/Context;Ljava/io/File;)V
    .registers 8

    .line 0: const-string v0, "ctx"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "apk"
    .line 7: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 13: move-result-object v0
    .line 14: new-instance v1, Ljava/lang/StringBuilder;
    .line 16: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 19: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v0, ".fileprovider"
    .line 24: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 30: move-result-object v0
    .line 31: invoke-static {v6, v0}, Landroidx/core/content/FileProvider;->b(Landroid/content/Context;Ljava/lang/String;)Lw1/c;
    .line 34: move-result-object v0
    .line 35: invoke-virtual {v7}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;
    .line 38: move-result-object v7
    .line 39: iget-object v1, v0, Lw1/c;->b:Ljava/util/HashMap;
    .line 41: invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;
    .line 44: move-result-object v1
    .line 45: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 48: move-result-object v1
    .line 49: const/4 v2, 0
    .line 50: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 53: move-result v3
    .line 54: if-eqz v3, :cond_102
    .line 56: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 59: move-result-object v3
    .line 60: check-cast v3, Ljava/util/Map$Entry;
    .line 62: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 65: move-result-object v4
    .line 66: check-cast v4, Ljava/io/File;
    .line 68: invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;
    .line 71: move-result-object v4
    .line 72: invoke-virtual {v7, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 75: move-result v5
    .line 76: if-eqz v5, :cond_50
    .line 78: if-eqz v2, :cond_100
    .line 80: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 83: move-result v4
    .line 84: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 87: move-result-object v5
    .line 88: check-cast v5, Ljava/io/File;
    .line 90: invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;
    .line 93: move-result-object v5
    .line 94: invoke-virtual {v5}, Ljava/lang/String;->length()I
    .line 97: move-result v5
    .line 98: if-le v4, v5, :cond_50
    .line 100: move-object v2, v3
    .line 101: goto :goto_50
    .line 102: if-eqz v2, :cond_227
    .line 104: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 107: move-result-object v1
    .line 108: check-cast v1, Ljava/io/File;
    .line 110: invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;
    .line 113: move-result-object v1
    .line 114: const-string v3, "/"
    .line 116: invoke-virtual {v1, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z
    .line 119: move-result v4
    .line 120: if-eqz v4, :cond_131
    .line 122: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 125: move-result v1
    .line 126: invoke-virtual {v7, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 129: move-result-object v7
    .line 130: goto :goto_141
    .line 131: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 134: move-result v1
    .line 135: add-int/lit8 v1, v1, 1
    .line 137: invoke-virtual {v7, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 140: move-result-object v7
    .line 141: new-instance v1, Ljava/lang/StringBuilder;
    .line 143: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 146: invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 149: move-result-object v2
    .line 150: check-cast v2, Ljava/lang/String;
    .line 152: invoke-static {v2}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;
    .line 155: move-result-object v2
    .line 156: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 159: const/16 v2, 47
    .line 161: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 164: invoke-static {v7, v3}, Landroid/net/Uri;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 167: move-result-object v7
    .line 168: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 171: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 174: move-result-object v7
    .line 175: new-instance v1, Landroid/net/Uri$Builder;
    .line 177: invoke-direct {v1}, Landroid/net/Uri$Builder;-><init>()V
    .line 180: const-string v2, "content"
    .line 182: invoke-virtual {v1, v2}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 185: move-result-object v1
    .line 186: iget-object v0, v0, Lw1/c;->a:Ljava/lang/String;
    .line 188: invoke-virtual {v1, v0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 191: move-result-object v0
    .line 192: invoke-virtual {v0, v7}, Landroid/net/Uri$Builder;->encodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;
    .line 195: move-result-object v7
    .line 196: invoke-virtual {v7}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
    .line 199: move-result-object v7
    .line 200: const-string v0, "getUriForFile(...)"
    .line 202: invoke-static {v7, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 205: new-instance v0, Landroid/content/Intent;
    .line 207: const-string v1, "android.intent.action.VIEW"
    .line 209: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    .line 212: const-string v1, "application/vnd.android.package-archive"
    .line 214: invoke-virtual {v0, v7, v1}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;
    .line 217: const v7, 0x10000001
    .line 220: invoke-virtual {v0, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    .line 223: invoke-virtual {v6, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    .line 226: return-void
    .line 227: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 229: new-instance v0, Ljava/lang/StringBuilder;
    .line 231: const-string v1, "Failed to find configured root that contains "
    .line 233: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 236: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 239: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 242: move-result-object v7
    .line 243: invoke-direct {v6, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 246: throw v6
    .line 247: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 249: new-instance v0, Ljava/lang/StringBuilder;
    .line 251: const-string v1, "Failed to resolve canonical path for "
    .line 253: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 256: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 259: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 262: move-result-object v7
    .line 263: invoke-direct {v6, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 266: throw v6
.end method

# direct methods
.method public static final d(II)J
    .registers 6

    .line 0: int-to-long v0, v4
    .line 1: const/16 v4, 32
    .line 3: shl-long/2addr v0, v4
    .line 4: int-to-long v4, v5
    .line 5: const-wide v2, 0x00ffffffff
    .line 10: and-long/2addr v4, v2
    .line 11: or-long/2addr v4, v0
    .line 12: sget v0, Lr1/g;->c:I
    .line 14: return-wide v4
.end method

# direct methods
.method public static final d0(J)Z
    .registers 4

    .line 0: sget-object v0, Lr1/k;->b:[Lr1/l;
    .line 2: const-wide v0, 0x0ff00
    .line 7: and-long/2addr v2, v0
    .line 8: const-wide/16 v0, 0
    .line 10: cmp-long v2, v2, v0
    .line 12: if-nez v2, :cond_16
    .line 14: const/4 v2, 1
    .line 15: goto :goto_17
    .line 16: const/4 v2, 0
    .line 17: return v2
.end method

# direct methods
.method public static final e(Lf1/b0;Lk1/r;Lr1/b;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)Ln1/c;
    .registers 14

    .line 0: const-string v0, "text"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "spanStyles"
    .line 7: invoke-static {v12, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "placeholders"
    .line 12: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: const-string v0, "density"
    .line 17: invoke-static {v10, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 20: const-string v0, "fontFamilyResolver"
    .line 22: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: new-instance v0, Ln1/c;
    .line 27: move-object v1, v0
    .line 28: move-object v2, v8
    .line 29: move-object v3, v9
    .line 30: move-object v4, v10
    .line 31: move-object v5, v11
    .line 32: move-object v6, v12
    .line 33: move-object v7, v13
    .line 34: invoke-direct/range {v1 .. v7}, Ln1/c;-><init>(Lf1/b0;Lk1/r;Lr1/b;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V
    .line 37: return-object v0
.end method

# direct methods
.method public static final e0(C)Z
    .registers 2

    .line 0: invoke-static {v1}, Ljava/lang/Character;->isWhitespace(C)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_15
    .line 6: invoke-static {v1}, Ljava/lang/Character;->isSpaceChar(C)Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_13
    .line 12: goto :goto_15
    .line 13: const/4 v1, 0
    .line 14: goto :goto_16
    .line 15: const/4 v1, 1
    .line 16: return v1
.end method

# direct methods
.method public static final f(FF)J
    .registers 6

    .line 0: invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v4
    .line 4: int-to-long v0, v4
    .line 5: invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 8: move-result v4
    .line 9: int-to-long v4, v4
    .line 10: const/16 v2, 32
    .line 12: shl-long/2addr v0, v2
    .line 13: const-wide v2, 0x00ffffffff
    .line 18: and-long/2addr v4, v2
    .line 19: or-long/2addr v4, v0
    .line 20: sget v0, Lj0/f;->d:I
    .line 22: return-wide v4
.end method

# direct methods
.method public static f0(I)I
    .registers 2

    .line 0: if-gez v1, :cond_3
    .line 2: goto :goto_25
    .line 3: const/4 v0, 3
    .line 4: if-ge v1, v0, :cond_9
    .line 6: add-int/lit8 v1, v1, 1
    .line 8: goto :goto_25
    .line 9: const/high16 v0, 0x4000
    .line 11: if-ge v1, v0, :cond_22
    .line 13: int-to-float v1, v1
    .line 14: const/high16 v0, 0x3f40
    .line 16: div-float/2addr v1, v0
    .line 17: const/high16 v0, 0x3f80
    .line 19: add-float/2addr v1, v0
    .line 20: float-to-int v1, v1
    .line 21: goto :goto_25
    .line 22: const v1, 0x7fffffff
    .line 25: return v1
.end method

# direct methods
.method public static final g(II)J
    .registers 6

    .line 0: const/16 v0, 93
    .line 2: const-string v1, ", end: "
    .line 4: if-ltz v4, :cond_56
    .line 6: if-ltz v5, :cond_23
    .line 8: int-to-long v0, v4
    .line 9: const/16 v4, 32
    .line 11: shl-long/2addr v0, v4
    .line 12: int-to-long v4, v5
    .line 13: const-wide v2, 0x00ffffffff
    .line 18: and-long/2addr v4, v2
    .line 19: or-long/2addr v4, v0
    .line 20: sget v0, Lf1/a0;->c:I
    .line 22: return-wide v4
    .line 23: new-instance v2, Ljava/lang/StringBuilder;
    .line 25: const-string v3, "end cannot be negative. [start: "
    .line 27: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 30: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 33: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 36: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 42: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 45: move-result-object v4
    .line 46: new-instance v5, Ljava/lang/IllegalArgumentException;
    .line 48: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 51: move-result-object v4
    .line 52: invoke-direct {v5, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 55: throw v5
    .line 56: new-instance v2, Ljava/lang/StringBuilder;
    .line 58: const-string v3, "start cannot be negative. [start: "
    .line 60: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 63: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 66: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 69: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 72: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 75: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 78: move-result-object v4
    .line 79: new-instance v5, Ljava/lang/IllegalArgumentException;
    .line 81: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 84: move-result-object v4
    .line 85: invoke-direct {v5, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 88: throw v5
.end method

# direct methods
.method public static g0(Ls2/e;)Ljava/util/Map;
    .registers 2

    .line 0: const-string v0, "pair"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v0, v1, Ls2/e;->i:Ljava/lang/Object;
    .line 7: iget-object v1, v1, Ls2/e;->j:Ljava/lang/Object;
    .line 9: invoke-static {v0, v1}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;
    .line 12: move-result-object v1
    .line 13: const-string v0, "singletonMap(pair.first, pair.second)"
    .line 15: invoke-static {v1, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 18: return-object v1
.end method

# direct methods
.method public static final h(Ld3/a;Lu/l;I)V
    .registers 73

    .line 0: move-object/from16 v8, v70
    .line 2: move/from16 v9, v72
    .line 4: const-string v0, "onDone"
    .line 6: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: move-object/from16 v15, v71
    .line 11: check-cast v15, Lu/b0;
    .line 13: const v0, 0x7cd96c5f
    .line 16: invoke-virtual {v15, v0}, Lu/b0;->e0(I)Lu/b0;
    .line 19: and-int/lit8 v0, v9, 14
    .line 21: const/4 v11, 2
    .line 22: if-nez v0, :cond_35
    .line 24: invoke-virtual {v15, v8}, Lu/b0;->h(Ljava/lang/Object;)Z
    .line 27: move-result v0
    .line 28: if-eqz v0, :cond_32
    .line 30: const/4 v0, 4
    .line 31: goto :goto_33
    .line 32: move v0, v11
    .line 33: or-int/2addr v0, v9
    .line 34: goto :goto_36
    .line 35: move v0, v9
    .line 36: const/16 v12, 11
    .line 38: and-int/2addr v0, v12
    .line 39: if-ne v0, v11, :cond_55
    .line 41: invoke-virtual {v15}, Lu/b0;->F()Z
    .line 44: move-result v0
    .line 45: if-nez v0, :cond_48
    .line 47: goto :goto_55
    .line 48: invoke-virtual {v15}, Lu/b0;->Y()V
    .line 51: move-object v5, v15
    .line 52: const/4 v3, 1
    .line 53: goto/16 :goto_2099
    .line 55: const/16 v0, 30
    .line 57: int-to-float v13, v0
    .line 58: const v0, 0xe2a708a4
    .line 61: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 64: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 67: move-result-object v1
    .line 68: sget-object v7, Lu/k;->i:Landroidx/activity/b;
    .line 70: if-ne v1, v7, :cond_81
    .line 72: const/high16 v1, 0xbf80
    .line 74: invoke-static {v1}, Ld2/b;->a(F)Lh/d;
    .line 77: move-result-object v1
    .line 78: invoke-virtual {v15, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 81: const/4 v6, 0
    .line 82: invoke-virtual {v15, v6}, Lu/b0;->t(Z)V
    .line 85: move-object/from16 v16, v1
    .line 87: check-cast v16, Lh/d;
    .line 89: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 92: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 95: move-result-object v1
    .line 96: if-ne v1, v7, :cond_107
    .line 98: const/high16 v1, 0x4000
    .line 100: invoke-static {v1}, Ld2/b;->a(F)Lh/d;
    .line 103: move-result-object v1
    .line 104: invoke-virtual {v15, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 107: invoke-virtual {v15, v6}, Lu/b0;->t(Z)V
    .line 110: move-object/from16 v17, v1
    .line 112: check-cast v17, Lh/d;
    .line 114: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 117: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 120: move-result-object v1
    .line 121: const/4 v5, 0
    .line 122: if-ne v1, v7, :cond_131
    .line 124: invoke-static {v5}, Ld2/b;->a(F)Lh/d;
    .line 127: move-result-object v1
    .line 128: invoke-virtual {v15, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 131: invoke-virtual {v15, v6}, Lu/b0;->t(Z)V
    .line 134: move-object/from16 v18, v1
    .line 136: check-cast v18, Lh/d;
    .line 138: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 141: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 144: move-result-object v1
    .line 145: if-ne v1, v7, :cond_154
    .line 147: invoke-static {v5}, Ld2/b;->a(F)Lh/d;
    .line 150: move-result-object v1
    .line 151: invoke-virtual {v15, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 154: invoke-virtual {v15, v6}, Lu/b0;->t(Z)V
    .line 157: move-object/from16 v20, v1
    .line 159: check-cast v20, Lh/d;
    .line 161: sget-object v4, Ls2/k;->a:Ls2/k;
    .line 163: new-instance v3, Lcom/titanchess/accessibility/g2;
    .line 165: const/16 v19, 0
    .line 167: move-object v1, v3
    .line 168: move-object/from16 v2, v17
    .line 170: move-object v12, v3
    .line 171: move-object/from16 v3, v16
    .line 173: move-object v10, v4
    .line 174: move-object/from16 v4, v20
    .line 176: move-object/from16 v5, v70
    .line 178: move v11, v6
    .line 179: move-object/from16 v6, v18
    .line 181: move-object v14, v7
    .line 182: move-object/from16 v7, v19
    .line 184: invoke-direct/range {v1 .. v7}, Lcom/titanchess/accessibility/g2;-><init>(Lh/d;Lh/d;Lh/d;Ld3/a;Lh/d;Lw2/e;)V
    .line 187: invoke-static {v10, v12, v15}, Lu/c0;->b(Ljava/lang/Object;Ld3/e;Lu/l;)V
    .line 190: sget-object v1, Lf0/m;->c:Lf0/m;
    .line 192: invoke-static {}, Landroidx/compose/foundation/layout/c;->b()Lf0/p;
    .line 195: move-result-object v2
    .line 196: sget-wide v3, Lk0/q;->c:J
    .line 198: sget-object v5, Lk0/g0;->a:Lk0/f0;
    .line 200: invoke-static {v2, v3, v4, v5}, Landroidx/compose/foundation/a;->d(Lf0/p;JLk0/l0;)Lf0/p;
    .line 203: move-result-object v2
    .line 204: sget-object v3, Lf0/a;->j:Lf0/g;
    .line 206: const v4, 0x2bb5b5d7
    .line 209: invoke-virtual {v15, v4}, Lu/b0;->d0(I)V
    .line 212: invoke-static {v3, v11, v15}, Ll/r;->c(Lf0/g;ZLu/l;)Lx0/y;
    .line 215: move-result-object v3
    .line 216: const v4, 0xb1164626
    .line 219: invoke-virtual {v15, v4}, Lu/b0;->d0(I)V
    .line 222: iget v5, v15, Lu/b0;->N:I
    .line 224: invoke-virtual {v15}, Lu/b0;->o()Lu/x1;
    .line 227: move-result-object v6
    .line 228: sget-object v7, Lz0/m;->g:Lz0/l;
    .line 230: invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 233: sget-object v7, Lz0/l;->b:Lz0/k;
    .line 235: invoke-static {v2}, Landroidx/compose/ui/layout/a;->j(Lf0/p;)Lb0/c;
    .line 238: move-result-object v2
    .line 239: iget-object v10, v15, Lu/b0;->a:Lu/c;
    .line 241: instance-of v10, v10, Lu/c;
    .line 243: if-eqz v10, :cond_2129
    .line 245: invoke-virtual {v15}, Lu/b0;->f0()V
    .line 248: iget-boolean v12, v15, Lu/b0;->M:Z
    .line 250: if-eqz v12, :cond_256
    .line 252: invoke-virtual {v15, v7}, Lu/b0;->n(Ld3/a;)V
    .line 255: goto :goto_259
    .line 256: invoke-virtual {v15}, Lu/b0;->r0()V
    .line 259: sget-object v12, Lz0/l;->f:Lz0/j;
    .line 261: invoke-static {v15, v3, v12}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 264: sget-object v3, Lz0/l;->e:Lz0/j;
    .line 266: invoke-static {v15, v6, v3}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 269: sget-object v6, Lz0/l;->i:Lz0/j;
    .line 271: iget-boolean v0, v15, Lu/b0;->M:Z
    .line 273: if-nez v0, :cond_289
    .line 275: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 278: move-result-object v0
    .line 279: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 282: move-result-object v4
    .line 283: invoke-static {v0, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 286: move-result v0
    .line 287: if-nez v0, :cond_292
    .line 289: invoke-static {v5, v15, v5, v6}, Lai/onnxruntime/b;->r(ILu/b0;ILz0/j;)V
    .line 292: new-instance v0, Lu/r2;
    .line 294: invoke-direct {v0, v15}, Lu/r2;-><init>(Lu/l;)V
    .line 297: const v4, 0x7ab4aae9
    .line 300: invoke-static {v11, v2, v0, v15, v4}, Lai/onnxruntime/b;->o(ILb0/c;Lu/r2;Lu/b0;I)V
    .line 303: sget-object v0, Lf0/a;->p:Lf0/e;
    .line 305: const v2, 0xe32f0e82
    .line 308: invoke-virtual {v15, v2}, Lu/b0;->d0(I)V
    .line 311: sget-object v2, Ll/j;->b:Ll/c;
    .line 313: invoke-static {v2, v0, v15}, Ll/u;->a(Ll/h;Lf0/e;Lu/l;)Lx0/y;
    .line 316: move-result-object v0
    .line 317: const v2, 0xb1164626
    .line 320: invoke-virtual {v15, v2}, Lu/b0;->d0(I)V
    .line 323: iget v2, v15, Lu/b0;->N:I
    .line 325: invoke-virtual {v15}, Lu/b0;->o()Lu/x1;
    .line 328: move-result-object v5
    .line 329: invoke-static {v1}, Landroidx/compose/ui/layout/a;->j(Lf0/p;)Lb0/c;
    .line 332: move-result-object v4
    .line 333: if-eqz v10, :cond_2124
    .line 335: invoke-virtual {v15}, Lu/b0;->f0()V
    .line 338: iget-boolean v10, v15, Lu/b0;->M:Z
    .line 340: if-eqz v10, :cond_346
    .line 342: invoke-virtual {v15, v7}, Lu/b0;->n(Ld3/a;)V
    .line 345: goto :goto_349
    .line 346: invoke-virtual {v15}, Lu/b0;->r0()V
    .line 349: invoke-static {v15, v0, v12}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 352: invoke-static {v15, v5, v3}, Ln3/a0;->R(Lu/l;Ljava/lang/Object;Ld3/e;)V
    .line 355: iget-boolean v0, v15, Lu/b0;->M:Z
    .line 357: if-nez v0, :cond_373
    .line 359: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 362: move-result-object v0
    .line 363: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 366: move-result-object v3
    .line 367: invoke-static {v0, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 370: move-result v0
    .line 371: if-nez v0, :cond_376
    .line 373: invoke-static {v2, v15, v2, v6}, Lai/onnxruntime/b;->r(ILu/b0;ILz0/j;)V
    .line 376: new-instance v0, Lu/r2;
    .line 378: invoke-direct {v0, v15}, Lu/r2;-><init>(Lu/l;)V
    .line 381: const v2, 0x7ab4aae9
    .line 384: invoke-static {v11, v4, v0, v15, v2}, Lai/onnxruntime/b;->o(ILb0/c;Lu/r2;Lu/b0;I)V
    .line 387: const v0, 0x1c403a8f
    .line 390: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 393: sget-object v0, Landroidx/compose/ui/platform/p0;->b:Lu/j3;
    .line 395: invoke-virtual {v15, v0}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 398: move-result-object v2
    .line 399: check-cast v2, Landroid/content/Context;
    .line 401: sget-object v3, Landroidx/compose/ui/platform/p0;->a:Lu/w0;
    .line 403: invoke-virtual {v15, v3}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 406: invoke-virtual {v15, v0}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 409: move-result-object v0
    .line 410: check-cast v0, Landroid/content/Context;
    .line 412: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 415: move-result-object v3
    .line 416: const-string v0, "LocalContext.current.resources"
    .line 418: invoke-static {v3, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 421: const v0, 0xe2a708a4
    .line 424: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 427: invoke-virtual {v15}, Lu/b0;->I()Ljava/lang/Object;
    .line 430: move-result-object v0
    .line 431: if-ne v0, v14, :cond_441
    .line 433: new-instance v0, Landroid/util/TypedValue;
    .line 435: invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V
    .line 438: invoke-virtual {v15, v0}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 441: invoke-virtual {v15, v11}, Lu/b0;->t(Z)V
    .line 444: check-cast v0, Landroid/util/TypedValue;
    .line 446: const v4, 0x7f040006
    .line 449: const/4 v5, 1
    .line 450: invoke-virtual {v3, v4, v0, v5}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V
    .line 453: iget-object v6, v0, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;
    .line 455: const-string v10, "Only VectorDrawables and rasterized asset types are supported ex. PNG, JPG"
    .line 457: if-eqz v6, :cond_1790
    .line 459: const-string v12, ".xml"
    .line 461: invoke-static {v6, v12}, Lm3/j;->I1(Ljava/lang/CharSequence;Ljava/lang/String;)Z
    .line 464: move-result v12
    .line 465: if-ne v12, v5, :cond_1790
    .line 467: const v5, 0xd3fef711
    .line 470: invoke-virtual {v15, v5}, Lu/b0;->d0(I)V
    .line 473: invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;
    .line 476: move-result-object v2
    .line 477: const-string v5, "context.theme"
    .line 479: invoke-static {v2, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 482: iget v5, v0, Landroid/util/TypedValue;->changingConfigurations:I
    .line 484: const v0, 0x14d7d89
    .line 487: invoke-virtual {v15, v0}, Lu/b0;->d0(I)V
    .line 490: sget-object v0, Landroidx/compose/ui/platform/p0;->c:Lu/j3;
    .line 492: invoke-virtual {v15, v0}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 495: move-result-object v0
    .line 496: check-cast v0, Lc1/c;
    .line 498: new-instance v6, Lc1/b;
    .line 500: invoke-direct {v6, v2}, Lc1/b;-><init>(Landroid/content/res/Resources$Theme;)V
    .line 503: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 506: iget-object v12, v0, Lc1/c;->a:Ljava/util/HashMap;
    .line 508: invoke-virtual {v12, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 511: move-result-object v0
    .line 512: check-cast v0, Ljava/lang/ref/WeakReference;
    .line 514: if-eqz v0, :cond_523
    .line 516: invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    .line 519: move-result-object v0
    .line 520: check-cast v0, Lc1/a;
    .line 522: goto :goto_524
    .line 523: const/4 v0, 0
    .line 524: if-nez v0, :cond_1763
    .line 526: invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;
    .line 529: move-result-object v4
    .line 530: const-string v0, "res.getXml(id)"
    .line 532: invoke-static {v4, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 535: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 538: move-result v0
    .line 539: const/4 v14, 2
    .line 540: if-eq v0, v14, :cond_550
    .line 542: const/4 v7, 1
    .line 543: if-eq v0, v7, :cond_550
    .line 545: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 548: move-result v0
    .line 549: goto :goto_540
    .line 550: if-ne v0, v14, :cond_1755
    .line 552: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    .line 555: move-result-object v0
    .line 556: const-string v7, "vector"
    .line 558: invoke-static {v0, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 561: move-result v0
    .line 562: if-eqz v0, :cond_1749
    .line 564: invoke-static {v4}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    .line 567: move-result-object v7
    .line 568: new-instance v10, Lp0/a;
    .line 570: invoke-direct {v10, v4}, Lp0/a;-><init>(Landroid/content/res/XmlResourceParser;)V
    .line 573: const-string v0, "attrs"
    .line 575: invoke-static {v7, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 578: sget-object v0, Lp0/b;->a:[I
    .line 580: invoke-virtual {v10, v3, v2, v7, v0}, Lp0/a;->d(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    .line 583: move-result-object v14
    .line 584: const-string v0, "autoMirrored"
    .line 586: invoke-static {v4, v0}, Ll0/j;->t(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z
    .line 589: move-result v0
    .line 590: const/4 v11, 5
    .line 591: if-nez v0, :cond_596
    .line 593: const/16 v44, 0
    .line 595: goto :goto_603
    .line 596: const/4 v8, 0
    .line 597: invoke-virtual {v14, v11, v8}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z
    .line 600: move-result v0
    .line 601: move/from16 v44, v0
    .line 603: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 606: move-result v0
    .line 607: invoke-virtual {v10, v0}, Lp0/a;->e(I)V
    .line 610: const-string v0, "viewportWidth"
    .line 612: const/4 v8, 7
    .line 613: const/4 v11, 0
    .line 614: invoke-virtual {v10, v14, v0, v8, v11}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 617: move-result v39
    .line 618: const-string v0, "viewportHeight"
    .line 620: const/16 v8, 8
    .line 622: invoke-virtual {v10, v14, v0, v8, v11}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 625: move-result v40
    .line 626: cmpg-float v0, v39, v11
    .line 628: if-lez v0, :cond_1722
    .line 630: cmpg-float v0, v40, v11
    .line 632: if-lez v0, :cond_1695
    .line 634: const/4 v8, 3
    .line 635: invoke-virtual {v14, v8, v11}, Landroid/content/res/TypedArray;->getDimension(IF)F
    .line 638: move-result v32
    .line 639: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 642: move-result v0
    .line 643: invoke-virtual {v10, v0}, Lp0/a;->e(I)V
    .line 646: const/4 v8, 2
    .line 647: invoke-virtual {v14, v8, v11}, Landroid/content/res/TypedArray;->getDimension(IF)F
    .line 650: move-result v34
    .line 651: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 654: move-result v0
    .line 655: invoke-virtual {v10, v0}, Lp0/a;->e(I)V
    .line 658: const/4 v11, 1
    .line 659: invoke-virtual {v14, v11}, Landroid/content/res/TypedArray;->hasValue(I)Z
    .line 662: move-result v0
    .line 663: if-eqz v0, :cond_792
    .line 665: new-instance v0, Landroid/util/TypedValue;
    .line 667: invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V
    .line 670: invoke-virtual {v14, v11, v0}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z
    .line 673: iget v0, v0, Landroid/util/TypedValue;->type:I
    .line 675: if-ne v0, v8, :cond_683
    .line 677: sget-wide v22, Lk0/q;->g:J
    .line 679: move-wide/from16 v41, v22
    .line 681: goto/16 :goto_795
    .line 683: const-string v0, "tint"
    .line 685: invoke-static {v4, v0}, Ll0/j;->t(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z
    .line 688: move-result v0
    .line 689: if-eqz v0, :cond_768
    .line 691: new-instance v0, Landroid/util/TypedValue;
    .line 693: invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V
    .line 696: invoke-virtual {v14, v11, v0}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z
    .line 699: iget v11, v0, Landroid/util/TypedValue;->type:I
    .line 701: if-eq v11, v8, :cond_748
    .line 703: const/16 v8, 28
    .line 705: if-lt v11, v8, :cond_718
    .line 707: const/16 v8, 31
    .line 709: if-gt v11, v8, :cond_718
    .line 711: iget v0, v0, Landroid/util/TypedValue;->data:I
    .line 713: invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;
    .line 716: move-result-object v0
    .line 717: goto :goto_769
    .line 718: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getResources()Landroid/content/res/Resources;
    .line 721: move-result-object v0
    .line 722: const/4 v8, 1
    .line 723: const/4 v11, 0
    .line 724: invoke-virtual {v14, v8, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I
    .line 727: move-result v9
    .line 728: sget-object v8, Lx1/c;->a:Ljava/lang/ThreadLocal;
    .line 730: invoke-virtual {v0, v9}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;
    .line 733: move-result-object v8
    .line 734: invoke-static {v0, v8, v2}, Lx1/c;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    .line 737: move-result-object v0
    .line 738: goto :goto_769
    .line 739: move-exception v0
    .line 740: const-string v8, "CSLCompat"
    .line 742: const-string v9, "Failed to inflate ColorStateList."
    .line 744: invoke-static {v8, v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 747: goto :goto_768
    .line 748: new-instance v1, Ljava/lang/UnsupportedOperationException;
    .line 750: new-instance v2, Ljava/lang/StringBuilder;
    .line 752: const-string v3, "Failed to resolve attribute at index 1: "
    .line 754: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 757: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 760: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 763: move-result-object v0
    .line 764: invoke-direct {v1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 767: throw v1
    .line 768: const/4 v0, 0
    .line 769: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 772: move-result v8
    .line 773: invoke-virtual {v10, v8}, Lp0/a;->e(I)V
    .line 776: if-eqz v0, :cond_789
    .line 778: invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I
    .line 781: move-result v0
    .line 782: invoke-static {v0}, Landroidx/compose/ui/graphics/a;->b(I)J
    .line 785: move-result-wide v8
    .line 786: move-wide/from16 v41, v8
    .line 788: goto :goto_795
    .line 789: sget-wide v8, Lk0/q;->g:J
    .line 791: goto :goto_786
    .line 792: sget-wide v8, Lk0/q;->g:J
    .line 794: goto :goto_786
    .line 795: const/4 v0, -1
    .line 796: const/4 v8, 6
    .line 797: invoke-virtual {v14, v8, v0}, Landroid/content/res/TypedArray;->getInt(II)I
    .line 800: move-result v9
    .line 801: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 804: move-result v8
    .line 805: invoke-virtual {v10, v8}, Lp0/a;->e(I)V
    .line 808: const/16 v11, 9
    .line 810: if-eq v9, v0, :cond_823
    .line 812: const/4 v8, 3
    .line 813: if-eq v9, v8, :cond_838
    .line 815: const/4 v8, 5
    .line 816: if-eq v9, v8, :cond_823
    .line 818: if-eq v9, v11, :cond_835
    .line 820: packed-switch v9, :data_2134
    .line 823: const/16 v43, 5
    .line 825: goto :goto_840
    .line 826: const/16 v43, 12
    .line 828: goto :goto_840
    .line 829: const/16 v43, 14
    .line 831: goto :goto_840
    .line 832: const/16 v43, 13
    .line 834: goto :goto_840
    .line 835: move/from16 v43, v11
    .line 837: goto :goto_840
    .line 838: const/16 v43, 3
    .line 840: invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    .line 843: move-result-object v8
    .line 844: iget v8, v8, Landroid/util/DisplayMetrics;->density:F
    .line 846: div-float v37, v32, v8
    .line 848: invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    .line 851: move-result-object v8
    .line 852: iget v8, v8, Landroid/util/DisplayMetrics;->density:F
    .line 854: div-float v38, v34, v8
    .line 856: invoke-virtual {v14}, Landroid/content/res/TypedArray;->recycle()V
    .line 859: new-instance v8, Lo0/e;
    .line 861: const/16 v36, 0
    .line 863: const/16 v45, 1
    .line 865: move-object/from16 v35, v8
    .line 867: invoke-direct/range {v35 .. v45}, Lo0/e;-><init>(Ljava/lang/String;FFFFJIZI)V
    .line 870: const/4 v9, 0
    .line 871: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I
    .line 874: move-result v14
    .line 875: const/4 v11, 1
    .line 876: if-eq v14, v11, :cond_1651
    .line 878: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I
    .line 881: move-result v14
    .line 882: if-ge v14, v11, :cond_910
    .line 884: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I
    .line 887: move-result v11
    .line 888: const/4 v14, 3
    .line 889: if-ne v11, v14, :cond_911
    .line 891: move-object/from16 v36, v1
    .line 893: move/from16 v52, v5
    .line 895: move-object/from16 v50, v6
    .line 897: move-object/from16 v54, v8
    .line 899: move-object/from16 v51, v12
    .line 901: move/from16 v35, v13
    .line 903: move-object/from16 v49, v15
    .line 905: const/4 v3, 1
    .line 906: const/high16 v15, 0x3f80
    .line 908: goto/16 :goto_1668
    .line 910: const/4 v14, 3
    .line 911: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I
    .line 914: move-result v11
    .line 915: iget-object v0, v8, Lo0/e;->i:Ljava/util/ArrayList;
    .line 917: move/from16 v35, v13
    .line 919: const-string v13, "group"
    .line 921: move-object/from16 v36, v1
    .line 923: const/4 v1, 2
    .line 924: if-eq v11, v1, :cond_1109
    .line 926: if-eq v11, v14, :cond_942
    .line 928: move-object v1, v3
    .line 929: move/from16 v52, v5
    .line 931: move-object/from16 v50, v6
    .line 933: move-object/from16 v54, v8
    .line 935: move-object/from16 v51, v12
    .line 937: move-object/from16 v49, v15
    .line 939: const/4 v3, 1
    .line 940: goto/16 :goto_1087
    .line 942: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    .line 945: move-result-object v1
    .line 946: invoke-static {v13, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 949: move-result v1
    .line 950: if-eqz v1, :cond_1096
    .line 952: add-int/lit8 v9, v9, 1
    .line 954: const/4 v1, 0
    .line 955: if-ge v1, v9, :cond_1074
    .line 957: invoke-virtual {v8}, Lo0/e;->c()V
    .line 960: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 963: move-result v11
    .line 964: const/4 v13, 1
    .line 965: sub-int/2addr v11, v13
    .line 966: invoke-virtual {v0, v11}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    .line 969: move-result-object v11
    .line 970: check-cast v11, Lo0/d;
    .line 972: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 975: move-result v14
    .line 976: sub-int/2addr v14, v13
    .line 977: invoke-virtual {v0, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 980: move-result-object v13
    .line 981: check-cast v13, Lo0/d;
    .line 983: iget-object v13, v13, Lo0/d;->j:Ljava/util/List;
    .line 985: new-instance v14, Lo0/j0;
    .line 987: move/from16 v48, v9
    .line 989: iget-object v9, v11, Lo0/d;->a:Ljava/lang/String;
    .line 991: move-object/from16 v49, v15
    .line 993: iget v15, v11, Lo0/d;->b:F
    .line 995: move-object/from16 v50, v6
    .line 997: iget v6, v11, Lo0/d;->c:F
    .line 999: move-object/from16 v51, v12
    .line 1001: iget v12, v11, Lo0/d;->d:F
    .line 1003: move/from16 v52, v5
    .line 1005: iget v5, v11, Lo0/d;->e:F
    .line 1007: move-object/from16 v53, v0
    .line 1009: iget v0, v11, Lo0/d;->f:F
    .line 1011: move-object/from16 v54, v8
    .line 1013: iget v8, v11, Lo0/d;->g:F
    .line 1015: move-object/from16 v55, v2
    .line 1017: iget v2, v11, Lo0/d;->h:F
    .line 1019: move-object/from16 v56, v3
    .line 1021: iget-object v3, v11, Lo0/d;->i:Ljava/util/List;
    .line 1023: iget-object v11, v11, Lo0/d;->j:Ljava/util/List;
    .line 1025: move-object/from16 v37, v14
    .line 1027: move-object/from16 v38, v9
    .line 1029: move/from16 v39, v15
    .line 1031: move/from16 v40, v6
    .line 1033: move/from16 v41, v12
    .line 1035: move/from16 v42, v5
    .line 1037: move/from16 v43, v0
    .line 1039: move/from16 v44, v8
    .line 1041: move/from16 v45, v2
    .line 1043: move-object/from16 v46, v3
    .line 1045: move-object/from16 v47, v11
    .line 1047: invoke-direct/range {v37 .. v47}, Lo0/j0;-><init>(Ljava/lang/String;FFFFFFFLjava/util/List;Ljava/util/List;)V
    .line 1050: invoke-interface {v13, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 1053: add-int/lit8 v1, v1, 1
    .line 1055: move/from16 v9, v48
    .line 1057: move-object/from16 v15, v49
    .line 1059: move-object/from16 v6, v50
    .line 1061: move-object/from16 v12, v51
    .line 1063: move/from16 v5, v52
    .line 1065: move-object/from16 v0, v53
    .line 1067: move-object/from16 v8, v54
    .line 1069: move-object/from16 v2, v55
    .line 1071: move-object/from16 v3, v56
    .line 1073: goto :goto_955
    .line 1074: move/from16 v52, v5
    .line 1076: move-object/from16 v50, v6
    .line 1078: move-object/from16 v54, v8
    .line 1080: move-object/from16 v51, v12
    .line 1082: move-object/from16 v49, v15
    .line 1084: move-object v1, v3
    .line 1085: const/4 v3, 1
    .line 1086: const/4 v9, 0
    .line 1087: const/16 v11, 13
    .line 1089: const/4 v12, -1
    .line 1090: const/16 v13, 9
    .line 1092: const/high16 v15, 0x3f80
    .line 1094: goto/16 :goto_1629
    .line 1096: move/from16 v52, v5
    .line 1098: move-object/from16 v50, v6
    .line 1100: move-object/from16 v54, v8
    .line 1102: move-object/from16 v51, v12
    .line 1104: move-object/from16 v49, v15
    .line 1106: move-object v1, v3
    .line 1107: goto/16 :goto_939
    .line 1109: move-object/from16 v53, v0
    .line 1111: move-object/from16 v55, v2
    .line 1113: move-object/from16 v56, v3
    .line 1115: move/from16 v52, v5
    .line 1117: move-object/from16 v50, v6
    .line 1119: move-object/from16 v54, v8
    .line 1121: move-object/from16 v51, v12
    .line 1123: move-object/from16 v49, v15
    .line 1125: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    .line 1128: move-result-object v0
    .line 1129: if-eqz v0, :cond_1159
    .line 1131: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 1134: move-result v1
    .line 1135: const v2, 0x9db17482
    .line 1138: const-string v3, ""
    .line 1140: if-eq v1, v2, :cond_1531
    .line 1142: const v2, 0x346425
    .line 1145: if-eq v1, v2, :cond_1282
    .line 1147: const v2, 0x5e0f67f
    .line 1150: if-eq v1, v2, :cond_1153
    .line 1152: goto :goto_1159
    .line 1153: invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 1156: move-result v0
    .line 1157: if-nez v0, :cond_1165
    .line 1159: move-object/from16 v2, v55
    .line 1161: move-object/from16 v1, v56
    .line 1163: goto/16 :goto_939
    .line 1165: sget-object v0, Lp0/b;->b:[I
    .line 1167: move-object/from16 v2, v55
    .line 1169: move-object/from16 v1, v56
    .line 1171: invoke-virtual {v10, v1, v2, v7, v0}, Lp0/a;->d(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    .line 1174: move-result-object v0
    .line 1175: const-string v5, "rotation"
    .line 1177: const/4 v6, 0
    .line 1178: const/4 v8, 5
    .line 1179: invoke-virtual {v10, v0, v5, v8, v6}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1182: move-result v39
    .line 1183: const/4 v5, 1
    .line 1184: invoke-virtual {v0, v5, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F
    .line 1187: move-result v40
    .line 1188: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1191: move-result v5
    .line 1192: invoke-virtual {v10, v5}, Lp0/a;->e(I)V
    .line 1195: const/4 v5, 2
    .line 1196: invoke-virtual {v0, v5, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F
    .line 1199: move-result v41
    .line 1200: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1203: move-result v5
    .line 1204: invoke-virtual {v10, v5}, Lp0/a;->e(I)V
    .line 1207: const-string v5, "scaleX"
    .line 1209: const/high16 v8, 0x3f80
    .line 1211: const/4 v11, 3
    .line 1212: invoke-virtual {v10, v0, v5, v11, v8}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1215: move-result v42
    .line 1216: const-string v5, "scaleY"
    .line 1218: const/4 v11, 4
    .line 1219: invoke-virtual {v10, v0, v5, v11, v8}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1222: move-result v43
    .line 1223: const-string v5, "translateX"
    .line 1225: const/4 v8, 6
    .line 1226: invoke-virtual {v10, v0, v5, v8, v6}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1229: move-result v44
    .line 1230: const-string v5, "translateY"
    .line 1232: const/4 v8, 7
    .line 1233: invoke-virtual {v10, v0, v5, v8, v6}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1236: move-result v45
    .line 1237: const/4 v5, 0
    .line 1238: invoke-virtual {v0, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 1241: move-result-object v6
    .line 1242: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1245: move-result v5
    .line 1246: invoke-virtual {v10, v5}, Lp0/a;->e(I)V
    .line 1249: if-nez v6, :cond_1254
    .line 1251: move-object/from16 v38, v3
    .line 1253: goto :goto_1256
    .line 1254: move-object/from16 v38, v6
    .line 1256: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    .line 1259: sget v0, Lo0/k0;->a:I
    .line 1261: sget-object v46, Lt2/r;->i:Lt2/r;
    .line 1263: invoke-virtual/range {v54 .. v54}, Lo0/e;->c()V
    .line 1266: new-instance v0, Lo0/d;
    .line 1268: const/16 v47, 512
    .line 1270: move-object/from16 v37, v0
    .line 1272: invoke-direct/range {v37 .. v47}, Lo0/d;-><init>(Ljava/lang/String;FFFFFFFLjava/util/List;I)V
    .line 1275: move-object/from16 v5, v53
    .line 1277: invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1280: goto/16 :goto_939
    .line 1282: move-object/from16 v5, v53
    .line 1284: move-object/from16 v2, v55
    .line 1286: move-object/from16 v1, v56
    .line 1288: const-string v6, "path"
    .line 1290: invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 1293: move-result v0
    .line 1294: if-nez v0, :cond_1298
    .line 1296: goto/16 :goto_939
    .line 1298: sget-object v0, Lp0/b;->c:[I
    .line 1300: invoke-virtual {v10, v1, v2, v7, v0}, Lp0/a;->d(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    .line 1303: move-result-object v0
    .line 1304: const-string v6, "pathData"
    .line 1306: invoke-static {v4, v6}, Ll0/j;->t(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z
    .line 1309: move-result v6
    .line 1310: if-eqz v6, :cond_1523
    .line 1312: const/4 v6, 0
    .line 1313: invoke-virtual {v0, v6}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 1316: move-result-object v8
    .line 1317: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1320: move-result v6
    .line 1321: invoke-virtual {v10, v6}, Lp0/a;->e(I)V
    .line 1324: if-nez v8, :cond_1330
    .line 1326: move-object/from16 v56, v3
    .line 1328: const/4 v3, 2
    .line 1329: goto :goto_1333
    .line 1330: move-object/from16 v56, v8
    .line 1332: goto :goto_1328
    .line 1333: invoke-virtual {v0, v3}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 1336: move-result-object v6
    .line 1337: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1340: move-result v3
    .line 1341: invoke-virtual {v10, v3}, Lp0/a;->e(I)V
    .line 1344: invoke-static {v6}, Lo0/k0;->a(Ljava/lang/String;)Ljava/util/List;
    .line 1347: move-result-object v57
    .line 1348: const-string v3, "fillColor"
    .line 1350: const/4 v6, 1
    .line 1351: invoke-virtual {v10, v0, v2, v3, v6}, Lp0/a;->a(Landroid/content/res/TypedArray;Landroid/content/res/Resources$Theme;Ljava/lang/String;I)Lv/b;
    .line 1354: move-result-object v3
    .line 1355: const-string v8, "fillAlpha"
    .line 1357: const/high16 v11, 0x3f80
    .line 1359: const/16 v12, 12
    .line 1361: invoke-virtual {v10, v0, v8, v12, v11}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1364: move-result v60
    .line 1365: const-string v8, "strokeLineCap"
    .line 1367: const/16 v11, 8
    .line 1369: const/4 v12, -1
    .line 1370: invoke-virtual {v10, v0, v8, v11, v12}, Lp0/a;->c(Landroid/content/res/TypedArray;Ljava/lang/String;II)I
    .line 1373: move-result v8
    .line 1374: if-eqz v8, :cond_1391
    .line 1376: if-eq v8, v6, :cond_1387
    .line 1378: const/4 v11, 2
    .line 1379: if-eq v8, v11, :cond_1384
    .line 1381: const/16 v64, 0
    .line 1383: goto :goto_1393
    .line 1384: move/from16 v64, v11
    .line 1386: goto :goto_1393
    .line 1387: const/4 v11, 2
    .line 1388: move/from16 v64, v6
    .line 1390: goto :goto_1393
    .line 1391: const/4 v11, 2
    .line 1392: goto :goto_1381
    .line 1393: const-string v8, "strokeLineJoin"
    .line 1395: const/16 v13, 9
    .line 1397: invoke-virtual {v10, v0, v8, v13, v12}, Lp0/a;->c(Landroid/content/res/TypedArray;Ljava/lang/String;II)I
    .line 1400: move-result v8
    .line 1401: if-eqz v8, :cond_1411
    .line 1403: if-eq v8, v6, :cond_1408
    .line 1405: move/from16 v65, v11
    .line 1407: goto :goto_1413
    .line 1408: const/16 v65, 1
    .line 1410: goto :goto_1413
    .line 1411: const/16 v65, 0
    .line 1413: const-string v6, "strokeMiterLimit"
    .line 1415: const/16 v8, 10
    .line 1417: const/high16 v15, 0x3f80
    .line 1419: invoke-virtual {v10, v0, v6, v8, v15}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1422: move-result v66
    .line 1423: const-string v6, "strokeColor"
    .line 1425: const/4 v8, 3
    .line 1426: invoke-virtual {v10, v0, v2, v6, v8}, Lp0/a;->a(Landroid/content/res/TypedArray;Landroid/content/res/Resources$Theme;Ljava/lang/String;I)Lv/b;
    .line 1429: move-result-object v6
    .line 1430: const-string v14, "strokeAlpha"
    .line 1432: const/16 v8, 11
    .line 1434: invoke-virtual {v10, v0, v14, v8, v15}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1437: move-result v62
    .line 1438: const-string v14, "strokeWidth"
    .line 1440: const/4 v8, 4
    .line 1441: invoke-virtual {v10, v0, v14, v8, v15}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1444: move-result v63
    .line 1445: const-string v14, "trimPathEnd"
    .line 1447: const/4 v8, 6
    .line 1448: invoke-virtual {v10, v0, v14, v8, v15}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1451: move-result v68
    .line 1452: const-string v14, "trimPathOffset"
    .line 1454: const/4 v8, 0
    .line 1455: const/4 v11, 7
    .line 1456: invoke-virtual {v10, v0, v14, v11, v8}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1459: move-result v69
    .line 1460: const-string v14, "trimPathStart"
    .line 1462: const/4 v11, 5
    .line 1463: invoke-virtual {v10, v0, v14, v11, v8}, Lp0/a;->b(Landroid/content/res/TypedArray;Ljava/lang/String;IF)F
    .line 1466: move-result v67
    .line 1467: const-string v14, "fillType"
    .line 1469: const/4 v8, 0
    .line 1470: const/16 v11, 13
    .line 1472: invoke-virtual {v10, v0, v14, v11, v8}, Lp0/a;->c(Landroid/content/res/TypedArray;Ljava/lang/String;II)I
    .line 1475: move-result v14
    .line 1476: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    .line 1479: invoke-static {v3}, Lp0/b;->a(Lv/b;)Lk0/m;
    .line 1482: move-result-object v59
    .line 1483: invoke-static {v6}, Lp0/b;->a(Lv/b;)Lk0/m;
    .line 1486: move-result-object v61
    .line 1487: if-nez v14, :cond_1492
    .line 1489: const/16 v58, 0
    .line 1491: goto :goto_1494
    .line 1492: const/16 v58, 1
    .line 1494: invoke-virtual/range {v54 .. v54}, Lo0/e;->c()V
    .line 1497: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 1500: move-result v0
    .line 1501: const/4 v3, 1
    .line 1502: sub-int/2addr v0, v3
    .line 1503: invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 1506: move-result-object v0
    .line 1507: check-cast v0, Lo0/d;
    .line 1509: iget-object v0, v0, Lo0/d;->j:Ljava/util/List;
    .line 1511: new-instance v3, Lo0/p0;
    .line 1513: move-object/from16 v55, v3
    .line 1515: invoke-direct/range {v55 .. v69}, Lo0/p0;-><init>(Ljava/lang/String;Ljava/util/List;ILk0/m;FLk0/m;FFIIFFFF)V
    .line 1518: invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 1521: const/4 v3, 1
    .line 1522: goto :goto_1629
    .line 1523: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 1525: const-string v1, "No path data available"
    .line 1527: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 1530: throw v0
    .line 1531: move-object/from16 v5, v53
    .line 1533: move-object/from16 v2, v55
    .line 1535: move-object/from16 v1, v56
    .line 1537: const/16 v11, 13
    .line 1539: const/4 v12, -1
    .line 1540: const/16 v13, 9
    .line 1542: const/high16 v15, 0x3f80
    .line 1544: const-string v6, "clip-path"
    .line 1546: invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 1549: move-result v0
    .line 1550: if-nez v0, :cond_1553
    .line 1552: goto :goto_1521
    .line 1553: sget-object v0, Lp0/b;->d:[I
    .line 1555: invoke-virtual {v10, v1, v2, v7, v0}, Lp0/a;->d(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    .line 1558: move-result-object v0
    .line 1559: const/4 v6, 0
    .line 1560: invoke-virtual {v0, v6}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 1563: move-result-object v8
    .line 1564: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1567: move-result v6
    .line 1568: invoke-virtual {v10, v6}, Lp0/a;->e(I)V
    .line 1571: if-nez v8, :cond_1577
    .line 1573: move-object/from16 v38, v3
    .line 1575: const/4 v3, 1
    .line 1576: goto :goto_1580
    .line 1577: move-object/from16 v38, v8
    .line 1579: goto :goto_1575
    .line 1580: invoke-virtual {v0, v3}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 1583: move-result-object v6
    .line 1584: invoke-virtual {v0}, Landroid/content/res/TypedArray;->getChangingConfigurations()I
    .line 1587: move-result v8
    .line 1588: invoke-virtual {v10, v8}, Lp0/a;->e(I)V
    .line 1591: invoke-static {v6}, Lo0/k0;->a(Ljava/lang/String;)Ljava/util/List;
    .line 1594: move-result-object v46
    .line 1595: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    .line 1598: const/16 v39, 0
    .line 1600: const/16 v40, 0
    .line 1602: const/16 v41, 0
    .line 1604: const/high16 v42, 0x3f80
    .line 1606: const/high16 v43, 0x3f80
    .line 1608: const/16 v44, 0
    .line 1610: const/16 v45, 0
    .line 1612: invoke-virtual/range {v54 .. v54}, Lo0/e;->c()V
    .line 1615: new-instance v0, Lo0/d;
    .line 1617: const/16 v47, 512
    .line 1619: move-object/from16 v37, v0
    .line 1621: invoke-direct/range {v37 .. v47}, Lo0/d;-><init>(Ljava/lang/String;FFFFFFFLjava/util/List;I)V
    .line 1624: invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1627: add-int/lit8 v9, v9, 1
    .line 1629: invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 1632: move-object v3, v1
    .line 1633: move v0, v12
    .line 1634: move v11, v13
    .line 1635: move/from16 v13, v35
    .line 1637: move-object/from16 v1, v36
    .line 1639: move-object/from16 v15, v49
    .line 1641: move-object/from16 v6, v50
    .line 1643: move-object/from16 v12, v51
    .line 1645: move/from16 v5, v52
    .line 1647: move-object/from16 v8, v54
    .line 1649: goto/16 :goto_871
    .line 1651: move-object/from16 v36, v1
    .line 1653: move/from16 v52, v5
    .line 1655: move-object/from16 v50, v6
    .line 1657: move-object/from16 v54, v8
    .line 1659: move v3, v11
    .line 1660: move-object/from16 v51, v12
    .line 1662: move/from16 v35, v13
    .line 1664: move-object/from16 v49, v15
    .line 1666: goto/16 :goto_906
    .line 1668: new-instance v0, Lc1/a;
    .line 1670: invoke-virtual/range {v54 .. v54}, Lo0/e;->b()Lo0/f;
    .line 1673: move-result-object v1
    .line 1674: move/from16 v2, v52
    .line 1676: invoke-direct {v0, v1, v2}, Lc1/a;-><init>(Lo0/f;I)V
    .line 1679: new-instance v1, Ljava/lang/ref/WeakReference;
    .line 1681: invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 1684: move-object/from16 v2, v50
    .line 1686: move-object/from16 v4, v51
    .line 1688: invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 1691: move-object/from16 v5, v49
    .line 1693: const/4 v1, 0
    .line 1694: goto :goto_1775
    .line 1695: new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;
    .line 1697: new-instance v1, Ljava/lang/StringBuilder;
    .line 1699: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 1702: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;
    .line 1705: move-result-object v2
    .line 1706: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1709: const-string v2, "<VectorGraphic> tag requires viewportHeight > 0"
    .line 1711: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1714: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 1717: move-result-object v1
    .line 1718: invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V
    .line 1721: throw v0
    .line 1722: new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;
    .line 1724: new-instance v1, Ljava/lang/StringBuilder;
    .line 1726: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 1729: invoke-virtual {v14}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;
    .line 1732: move-result-object v2
    .line 1733: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1736: const-string v2, "<VectorGraphic> tag requires viewportWidth > 0"
    .line 1738: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1741: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 1744: move-result-object v1
    .line 1745: invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V
    .line 1748: throw v0
    .line 1749: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 1751: invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 1754: throw v0
    .line 1755: new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;
    .line 1757: const-string v1, "No start tag found"
    .line 1759: invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V
    .line 1762: throw v0
    .line 1763: move-object/from16 v36, v1
    .line 1765: move/from16 v35, v13
    .line 1767: move-object/from16 v49, v15
    .line 1769: const/4 v3, 1
    .line 1770: const/high16 v15, 0x3f80
    .line 1772: move v1, v11
    .line 1773: move-object/from16 v5, v49
    .line 1775: invoke-virtual {v5, v1}, Lu/b0;->t(Z)V
    .line 1778: iget-object v0, v0, Lc1/a;->a:Lo0/f;
    .line 1780: invoke-static {v0, v5}, Ld2/b;->X0(Lo0/f;Lu/l;)Lo0/n0;
    .line 1783: move-result-object v0
    .line 1784: invoke-virtual {v5, v1}, Lu/b0;->t(Z)V
    .line 1787: move-object v10, v0
    .line 1788: const/4 v1, 0
    .line 1789: goto :goto_1888
    .line 1790: move-object/from16 v36, v1
    .line 1792: move-object v1, v3
    .line 1793: move v3, v5
    .line 1794: move/from16 v35, v13
    .line 1796: move-object v5, v15
    .line 1797: const/high16 v15, 0x3f80
    .line 1799: const v0, 0xd3fef7ac
    .line 1802: invoke-virtual {v5, v0}, Lu/b0;->d0(I)V
    .line 1805: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 1808: move-result-object v0
    .line 1809: invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;
    .line 1812: move-result-object v2
    .line 1813: const v7, 0x607fb4c4
    .line 1816: invoke-virtual {v5, v7}, Lu/b0;->d0(I)V
    .line 1819: invoke-virtual {v5, v6}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 1822: move-result v6
    .line 1823: invoke-virtual {v5, v0}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 1826: move-result v0
    .line 1827: or-int/2addr v0, v6
    .line 1828: invoke-virtual {v5, v2}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 1831: move-result v2
    .line 1832: or-int/2addr v0, v2
    .line 1833: invoke-virtual {v5}, Lu/b0;->I()Ljava/lang/Object;
    .line 1836: move-result-object v2
    .line 1837: if-nez v0, :cond_1841
    .line 1839: if-ne v2, v14, :cond_1843
    .line 1841: const/4 v2, 0
    .line 1842: goto :goto_1845
    .line 1843: const/4 v1, 0
    .line 1844: goto :goto_1874
    .line 1845: invoke-virtual {v1, v4, v2}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .line 1848: move-result-object v0
    .line 1849: const-string v1, "null cannot be cast to non-null type android.graphics.drawable.BitmapDrawable"
    .line 1851: invoke-static {v0, v1}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1854: check-cast v0, Landroid/graphics/drawable/BitmapDrawable;
    .line 1856: invoke-virtual {v0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;
    .line 1859: move-result-object v0
    .line 1860: const-string v1, "res.getDrawable(id, null…as BitmapDrawable).bitmap"
    .line 1862: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1865: new-instance v2, Lk0/c;
    .line 1867: invoke-direct {v2, v0}, Lk0/c;-><init>(Landroid/graphics/Bitmap;)V
    .line 1870: invoke-virtual {v5, v2}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 1873: goto :goto_1843
    .line 1874: invoke-virtual {v5, v1}, Lu/b0;->t(Z)V
    .line 1877: check-cast v2, Lk0/y;
    .line 1879: new-instance v0, Ln0/a;
    .line 1881: invoke-direct {v0, v2}, Ln0/a;-><init>(Lk0/y;)V
    .line 1884: invoke-virtual {v5, v1}, Lu/b0;->t(Z)V
    .line 1887: move-object v10, v0
    .line 1888: invoke-virtual {v5, v1}, Lu/b0;->t(Z)V
    .line 1891: const/4 v11, 0
    .line 1892: const/16 v0, 120
    .line 1894: int-to-float v0, v0
    .line 1895: move-object/from16 v2, v36
    .line 1897: invoke-static {v2, v0}, Landroidx/compose/foundation/layout/c;->i(Lf0/p;F)Lf0/p;
    .line 1900: move-result-object v0
    .line 1901: invoke-virtual/range {v16 .. v16}, Lh/d;->c()Ljava/lang/Object;
    .line 1904: move-result-object v4
    .line 1905: check-cast v4, Ljava/lang/Number;
    .line 1907: invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F
    .line 1910: move-result v4
    .line 1911: mul-float v4, v4, v35
    .line 1913: invoke-virtual/range {v17 .. v17}, Lh/d;->c()Ljava/lang/Object;
    .line 1916: move-result-object v6
    .line 1917: check-cast v6, Ljava/lang/Number;
    .line 1919: invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F
    .line 1922: move-result v6
    .line 1923: mul-float v6, v6, v35
    .line 1925: const/16 v7, 14
    .line 1927: int-to-float v7, v7
    .line 1928: invoke-virtual/range {v18 .. v18}, Lh/d;->c()Ljava/lang/Object;
    .line 1931: move-result-object v8
    .line 1932: check-cast v8, Ljava/lang/Number;
    .line 1934: invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F
    .line 1937: move-result v8
    .line 1938: mul-float/2addr v8, v7
    .line 1939: sub-float/2addr v6, v8
    .line 1940: invoke-static {v0, v4, v6}, Landroidx/compose/foundation/layout/a;->g(Lf0/p;FF)Lf0/p;
    .line 1943: move-result-object v12
    .line 1944: const/4 v13, 0
    .line 1945: const/4 v14, 0
    .line 1946: const/4 v0, 0
    .line 1947: const/16 v16, 0
    .line 1949: const/16 v18, 56
    .line 1951: const/16 v19, 120
    .line 1953: move v4, v15
    .line 1954: const/4 v6, 6
    .line 1955: move v15, v0
    .line 1956: move-object/from16 v17, v5
    .line 1958: invoke-static/range {v10 .. v19}, Landroidx/compose/foundation/a;->b(Ln0/b;Ljava/lang/String;Lf0/p;Lf0/d;Lx0/h;FLk0/r;Lu/l;II)V
    .line 1961: new-array v0, v3, [Lk1/q;
    .line 1963: const v7, 0x7f050001
    .line 1966: invoke-static {v7}, Ld2/c;->c(I)Lk1/k0;
    .line 1969: move-result-object v7
    .line 1970: aput-object v7, v0, v1
    .line 1972: new-instance v7, Lk1/w;
    .line 1974: invoke-static {v0}, Lt2/k;->J0([Ljava/lang/Object;)Ljava/util/List;
    .line 1977: move-result-object v0
    .line 1978: invoke-direct {v7, v0}, Lk1/w;-><init>(Ljava/util/List;)V
    .line 1981: const-wide v8, 0x00ffff7db4
    .line 1986: invoke-static {v8, v9}, Landroidx/compose/ui/graphics/a;->c(J)J
    .line 1989: move-result-wide v12
    .line 1990: const/16 v0, 20
    .line 1992: invoke-static {v0}, Ld2/c;->Z(I)J
    .line 1995: move-result-wide v14
    .line 1996: sget-object v17, Lk1/e0;->o:Lk1/e0;
    .line 1998: invoke-static {v6}, Ld2/c;->Z(I)J
    .line 2001: move-result-wide v8
    .line 2002: invoke-virtual/range {v20 .. v20}, Lh/d;->c()Ljava/lang/Object;
    .line 2005: move-result-object v0
    .line 2006: check-cast v0, Ljava/lang/Number;
    .line 2008: invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F
    .line 2011: move-result v0
    .line 2012: invoke-static {v2, v0}, Landroidx/compose/ui/draw/a;->a(Lf0/p;F)Lf0/p;
    .line 2015: move-result-object v0
    .line 2016: const/16 v2, 8
    .line 2018: int-to-float v2, v2
    .line 2019: invoke-virtual/range {v20 .. v20}, Lh/d;->c()Ljava/lang/Object;
    .line 2022: move-result-object v6
    .line 2023: check-cast v6, Ljava/lang/Number;
    .line 2025: invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F
    .line 2028: move-result v6
    .line 2029: sub-float v10, v4, v6
    .line 2031: mul-float/2addr v10, v2
    .line 2032: int-to-float v2, v1
    .line 2033: invoke-static {v0, v2, v10}, Landroidx/compose/foundation/layout/a;->g(Lf0/p;FF)Lf0/p;
    .line 2036: move-result-object v18
    .line 2037: const/16 v19, 0
    .line 2039: const/16 v2, 12
    .line 2041: int-to-float v0, v2
    .line 2042: const/16 v21, 0
    .line 2044: const/16 v22, 0
    .line 2046: const/16 v23, 13
    .line 2048: move/from16 v20, v0
    .line 2050: invoke-static/range {v18 .. v23}, Landroidx/compose/foundation/layout/a;->m(Lf0/p;FFFFI)Lf0/p;
    .line 2053: move-result-object v11
    .line 2054: const-string v10, "TITANNATIVE"
    .line 2056: const/16 v16, 0
    .line 2058: const/16 v21, 0
    .line 2060: const/16 v22, 0
    .line 2062: const-wide/16 v23, 0
    .line 2064: const/16 v25, 0
    .line 2066: const/16 v26, 0
    .line 2068: const/16 v27, 0
    .line 2070: const/16 v28, 0
    .line 2072: const/16 v29, 0
    .line 2074: const/16 v30, 0
    .line 2076: const v32, 0xc30d86
    .line 2079: const/16 v33, 0
    .line 2081: const v34, 0x1ff10
    .line 2084: move-object/from16 v18, v7
    .line 2086: move-wide/from16 v19, v8
    .line 2088: move-object/from16 v31, v5
    .line 2090: invoke-static/range {v10 .. v34}, Landroidx/compose/material3/o3;->b(Ljava/lang/String;Lf0/p;JJLk1/a0;Lk1/e0;Lk1/s;JLq1/m;Lq1/l;JIZIILd3/c;Lf1/b0;Lu/l;III)V
    .line 2093: invoke-static {v5, v1, v3, v1, v1}, Lai/onnxruntime/b;->v(Lu/b0;ZZZZ)V
    .line 2096: invoke-static {v5, v1, v3, v1, v1}, Lai/onnxruntime/b;->v(Lu/b0;ZZZZ)V
    .line 2099: invoke-virtual {v5}, Lu/b0;->x()Lu/c2;
    .line 2102: move-result-object v0
    .line 2103: if-nez v0, :cond_2106
    .line 2105: goto :goto_2117
    .line 2106: new-instance v1, Lcom/titanchess/accessibility/h0;
    .line 2108: move-object/from16 v2, v70
    .line 2110: move/from16 v4, v72
    .line 2112: invoke-direct {v1, v4, v3, v2}, Lcom/titanchess/accessibility/h0;-><init>(IILd3/a;)V
    .line 2115: iput-object v1, v0, Lu/c2;->d:Ld3/e;
    .line 2117: return-void
    .line 2118: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 2120: invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 2123: throw v0
    .line 2124: invoke-static {}, Lo/g1;->t()V
    .line 2127: const/4 v1, 0
    .line 2128: throw v1
    .line 2129: const/4 v1, 0
    .line 2130: invoke-static {}, Lo/g1;->t()V
    .line 2133: throw v1
    .line 2134: nop
    .line 2135: move/16 v14, v0
    .line 2138: move-result-object v0
    .line 2139: nop
    .line 2140: move-object/16 v0, v6
    .line 2143: nop
.end method

# direct methods
.method public static final h0(Lu/l;Lf0/p;)Lf0/p;
    .registers 6

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "modifier"
    .line 7: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: sget-object v0, Lf0/k;->j:Lf0/k;
    .line 12: invoke-interface {v5, v0}, Lf0/p;->d(Ld3/c;)Z
    .line 15: move-result v0
    .line 16: if-eqz v0, :cond_19
    .line 18: return-object v5
    .line 19: move-object v0, v4
    .line 20: check-cast v0, Lu/b0;
    .line 22: const v1, 0x48ae8da7
    .line 25: invoke-virtual {v0, v1}, Lu/b0;->d0(I)V
    .line 28: sget-object v1, Lf0/m;->c:Lf0/m;
    .line 30: new-instance v2, Ll/v0;
    .line 32: const/4 v3, 4
    .line 33: invoke-direct {v2, v3, v4}, Ll/v0;-><init>(ILjava/lang/Object;)V
    .line 36: invoke-interface {v5, v1, v2}, Lf0/p;->a(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 39: move-result-object v4
    .line 40: check-cast v4, Lf0/p;
    .line 42: const/4 v5, 0
    .line 43: invoke-virtual {v0, v5}, Lu/b0;->t(Z)V
    .line 46: return-object v4
.end method

# direct methods
.method public static final i(Lf1/b0;)Z
    .registers 3

    .line 0: iget-object v2, v2, Lf1/b0;->c:Lf1/s;
    .line 2: if-eqz v2, :cond_16
    .line 4: iget-object v2, v2, Lf1/s;->b:Lf1/q;
    .line 6: if-eqz v2, :cond_16
    .line 8: new-instance v0, Lf1/h;
    .line 10: iget v2, v2, Lf1/q;->b:I
    .line 12: invoke-direct {v0, v2}, Lf1/h;-><init>(I)V
    .line 15: goto :goto_17
    .line 16: const/4 v0, 0
    .line 17: const/4 v2, 0
    .line 18: const/4 v1, 1
    .line 19: if-nez v0, :cond_22
    .line 21: goto :goto_27
    .line 22: iget v0, v0, Lf1/h;->a:I
    .line 24: if-ne v0, v1, :cond_27
    .line 26: move v2, v1
    .line 27: xor-int/2addr v2, v1
    .line 28: return v2
.end method

# direct methods
.method public static final i0(JII)J
    .registers 8

    .line 0: invoke-static {v4, v5}, Lr1/a;->j(J)I
    .line 3: move-result v0
    .line 4: add-int/2addr v0, v6
    .line 5: const/4 v1, 0
    .line 6: if-gez v0, :cond_9
    .line 8: move v0, v1
    .line 9: invoke-static {v4, v5}, Lr1/a;->h(J)I
    .line 12: move-result v2
    .line 13: const v3, 0x7fffffff
    .line 16: if-ne v2, v3, :cond_19
    .line 18: goto :goto_23
    .line 19: add-int/2addr v2, v6
    .line 20: if-gez v2, :cond_23
    .line 22: move v2, v1
    .line 23: invoke-static {v4, v5}, Lr1/a;->i(J)I
    .line 26: move-result v6
    .line 27: add-int/2addr v6, v7
    .line 28: if-gez v6, :cond_31
    .line 30: move v6, v1
    .line 31: invoke-static {v4, v5}, Lr1/a;->g(J)I
    .line 34: move-result v4
    .line 35: if-ne v4, v3, :cond_38
    .line 37: goto :goto_44
    .line 38: add-int/2addr v4, v7
    .line 39: if-gez v4, :cond_42
    .line 41: goto :goto_43
    .line 42: move v1, v4
    .line 43: move v4, v1
    .line 44: invoke-static {v0, v2, v6, v4}, Ld2/c;->a(IIII)J
    .line 47: move-result-wide v4
    .line 48: return-wide v4
.end method

# direct methods
.method public static final j(Landroid/content/Context;Lk1/k0;)Landroid/graphics/Typeface;
    .registers 4

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 26
    .line 4: if-lt v0, v1, :cond_13
    .line 6: sget-object v0, Lk1/l0;->a:Lk1/l0;
    .line 8: invoke-virtual {v0, v2, v3}, Lk1/l0;->a(Landroid/content/Context;Lk1/k0;)Landroid/graphics/Typeface;
    .line 11: move-result-object v2
    .line 12: goto :goto_22
    .line 13: iget v3, v3, Lk1/k0;->a:I
    .line 15: invoke-static {v2, v3}, Lx1/i;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;
    .line 18: move-result-object v2
    .line 19: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 22: return-object v2
.end method

# direct methods
.method public static synthetic j0(JIII)J
    .registers 7

    .line 0: and-int/lit8 v0, v6, 1
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: move v4, v1
    .line 6: and-int/lit8 v6, v6, 2
    .line 8: if-eqz v6, :cond_11
    .line 10: move v5, v1
    .line 11: invoke-static {v2, v3, v4, v5}, Ld2/c;->i0(JII)J
    .line 14: move-result-wide v2
    .line 15: return-wide v2
.end method

# direct methods
.method public static final k(Lv0/c;Lu0/z;)V
    .registers 15

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "event"
    .line 7: invoke-static {v14, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {v14}, Ll0/j;->g(Lu0/z;)Z
    .line 13: move-result v0
    .line 14: const/4 v1, 0
    .line 15: iget-object v2, v13, Lv0/c;->b:Lv0/b;
    .line 17: iget-object v3, v13, Lv0/c;->a:Lv0/b;
    .line 19: iget-wide v4, v14, Lu0/z;->c:J
    .line 21: if-eqz v0, :cond_40
    .line 23: iput-wide v4, v13, Lv0/c;->c:J
    .line 25: iget-object v0, v3, Lv0/b;->d:[Lv0/a;
    .line 27: const/4 v6, 0
    .line 28: invoke-static {v0, v6}, Lt2/k;->S0([Ljava/lang/Object;Lkotlinx/coroutines/internal/u;)V
    .line 31: iput v1, v3, Lv0/b;->e:I
    .line 33: iget-object v0, v2, Lv0/b;->d:[Lv0/a;
    .line 35: invoke-static {v0, v6}, Lt2/k;->S0([Ljava/lang/Object;Lkotlinx/coroutines/internal/u;)V
    .line 38: iput v1, v2, Lv0/b;->e:I
    .line 40: iget-object v0, v14, Lu0/z;->k:Ljava/util/List;
    .line 42: if-nez v0, :cond_46
    .line 44: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 46: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 49: move-result v6
    .line 50: iget-wide v7, v14, Lu0/z;->g:J
    .line 52: if-ge v1, v6, :cond_95
    .line 54: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 57: move-result-object v9
    .line 58: check-cast v9, Lu0/d;
    .line 60: iget-wide v10, v9, Lu0/d;->b:J
    .line 62: invoke-static {v10, v11, v7, v8}, Lj0/c;->e(JJ)J
    .line 65: move-result-wide v7
    .line 66: iget-wide v10, v13, Lv0/c;->c:J
    .line 68: invoke-static {v10, v11, v7, v8}, Lj0/c;->f(JJ)J
    .line 71: move-result-wide v7
    .line 72: iput-wide v7, v13, Lv0/c;->c:J
    .line 74: invoke-static {v7, v8}, Lj0/c;->c(J)F
    .line 77: move-result v10
    .line 78: iget-wide v11, v9, Lu0/d;->a:J
    .line 80: invoke-virtual {v3, v10, v11, v12}, Lv0/b;->a(FJ)V
    .line 83: invoke-static {v7, v8}, Lj0/c;->d(J)F
    .line 86: move-result v7
    .line 87: invoke-virtual {v2, v7, v11, v12}, Lv0/b;->a(FJ)V
    .line 90: add-int/lit8 v1, v1, 1
    .line 92: iget-wide v7, v9, Lu0/d;->b:J
    .line 94: goto :goto_52
    .line 95: invoke-static {v4, v5, v7, v8}, Lj0/c;->e(JJ)J
    .line 98: move-result-wide v0
    .line 99: iget-wide v4, v13, Lv0/c;->c:J
    .line 101: invoke-static {v4, v5, v0, v1}, Lj0/c;->f(JJ)J
    .line 104: move-result-wide v0
    .line 105: iput-wide v0, v13, Lv0/c;->c:J
    .line 107: invoke-static {v0, v1}, Lj0/c;->c(J)F
    .line 110: move-result v13
    .line 111: iget-wide v4, v14, Lu0/z;->b:J
    .line 113: invoke-virtual {v3, v13, v4, v5}, Lv0/b;->a(FJ)V
    .line 116: invoke-static {v0, v1}, Lj0/c;->d(J)F
    .line 119: move-result v13
    .line 120: invoke-virtual {v2, v13, v4, v5}, Lv0/b;->a(FJ)V
    .line 123: return-void
.end method

# direct methods
.method public static l(Ljava/util/LinkedHashSet;)Ljava/util/Collection;
    .registers 2

    .line 0: instance-of v0, v1, Lf3/a;
    .line 2: if-eqz v0, :cond_16
    .line 4: instance-of v0, v1, Lf3/b;
    .line 6: if-eqz v0, :cond_9
    .line 8: goto :goto_16
    .line 9: const-string v0, "kotlin.collections.MutableCollection"
    .line 11: invoke-static {v1, v0}, Ld2/c;->E0(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: const/4 v1, 0
    .line 15: throw v1
    .line 16: return-object v1
.end method

# direct methods
.method public static m(Ljava/util/AbstractMap;)Ljava/util/Map;
    .registers 2

    .line 0: instance-of v0, v1, Lf3/a;
    .line 2: if-eqz v0, :cond_16
    .line 4: instance-of v0, v1, Lf3/d;
    .line 6: if-eqz v0, :cond_9
    .line 8: goto :goto_16
    .line 9: const-string v0, "kotlin.collections.MutableMap"
    .line 11: invoke-static {v1, v0}, Ld2/c;->E0(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: const/4 v1, 0
    .line 15: throw v1
    .line 16: return-object v1
.end method

# direct methods
.method public static final m0(FJ)J
    .registers 7

    .line 0: invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I
    .line 3: move-result v4
    .line 4: int-to-long v0, v4
    .line 5: const-wide v2, 0x00ffffffff
    .line 10: and-long/2addr v0, v2
    .line 11: or-long v4, v5, v0
    .line 13: sget-object v6, Lr1/k;->b:[Lr1/l;
    .line 15: return-wide v4
.end method

# direct methods
.method public static n(ILjava/lang/Object;)V
    .registers 4

    .line 0: if-eqz v3, :cond_160
    .line 2: instance-of v0, v3, Ls2/a;
    .line 4: if-eqz v0, :cond_141
    .line 6: instance-of v0, v3, Le3/e;
    .line 8: if-eqz v0, :cond_19
    .line 10: move-object v0, v3
    .line 11: check-cast v0, Le3/e;
    .line 13: invoke-interface {v0}, Le3/e;->W()I
    .line 16: move-result v0
    .line 17: goto/16 :goto_138
    .line 19: instance-of v0, v3, Ld3/a;
    .line 21: if-eqz v0, :cond_26
    .line 23: const/4 v0, 0
    .line 24: goto/16 :goto_138
    .line 26: instance-of v0, v3, Ld3/c;
    .line 28: if-eqz v0, :cond_33
    .line 30: const/4 v0, 1
    .line 31: goto/16 :goto_138
    .line 33: instance-of v0, v3, Ld3/e;
    .line 35: if-eqz v0, :cond_40
    .line 37: const/4 v0, 2
    .line 38: goto/16 :goto_138
    .line 40: instance-of v0, v3, Ld3/f;
    .line 42: if-eqz v0, :cond_47
    .line 44: const/4 v0, 3
    .line 45: goto/16 :goto_138
    .line 47: instance-of v0, v3, Ld3/g;
    .line 49: if-eqz v0, :cond_54
    .line 51: const/4 v0, 4
    .line 52: goto/16 :goto_138
    .line 54: instance-of v0, v3, Ld3/h;
    .line 56: if-eqz v0, :cond_60
    .line 58: const/4 v0, 5
    .line 59: goto :goto_138
    .line 60: instance-of v0, v3, Lb0/a;
    .line 62: if-eqz v0, :cond_66
    .line 64: const/4 v0, 6
    .line 65: goto :goto_138
    .line 66: instance-of v1, v3, Ld3/i;
    .line 68: if-eqz v1, :cond_72
    .line 70: const/4 v0, 7
    .line 71: goto :goto_138
    .line 72: if-eqz v0, :cond_77
    .line 74: const/16 v0, 8
    .line 76: goto :goto_138
    .line 77: if-eqz v0, :cond_82
    .line 79: const/16 v0, 9
    .line 81: goto :goto_138
    .line 82: if-eqz v0, :cond_87
    .line 84: const/16 v0, 10
    .line 86: goto :goto_138
    .line 87: if-eqz v0, :cond_92
    .line 89: const/16 v0, 11
    .line 91: goto :goto_138
    .line 92: if-eqz v0, :cond_97
    .line 94: const/16 v0, 13
    .line 96: goto :goto_138
    .line 97: if-eqz v0, :cond_102
    .line 99: const/16 v0, 14
    .line 101: goto :goto_138
    .line 102: if-eqz v0, :cond_107
    .line 104: const/16 v0, 15
    .line 106: goto :goto_138
    .line 107: if-eqz v0, :cond_112
    .line 109: const/16 v0, 16
    .line 111: goto :goto_138
    .line 112: if-eqz v0, :cond_117
    .line 114: const/16 v0, 17
    .line 116: goto :goto_138
    .line 117: if-eqz v0, :cond_122
    .line 119: const/16 v0, 18
    .line 121: goto :goto_138
    .line 122: if-eqz v0, :cond_127
    .line 124: const/16 v0, 19
    .line 126: goto :goto_138
    .line 127: if-eqz v0, :cond_132
    .line 129: const/16 v0, 20
    .line 131: goto :goto_138
    .line 132: if-eqz v0, :cond_137
    .line 134: const/16 v0, 21
    .line 136: goto :goto_138
    .line 137: const/4 v0, -1
    .line 138: if-ne v0, v2, :cond_141
    .line 140: goto :goto_160
    .line 141: new-instance v0, Ljava/lang/StringBuilder;
    .line 143: const-string v1, "kotlin.jvm.functions.Function"
    .line 145: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 148: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 151: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 154: move-result-object v2
    .line 155: invoke-static {v3, v2}, Ld2/c;->E0(Ljava/lang/Object;Ljava/lang/String;)V
    .line 158: const/4 v2, 0
    .line 159: throw v2
    .line 160: return-void
.end method

# direct methods
.method public static n0(Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources;)Lx1/e;
    .registers 25

    .line 0: move-object/from16 v0, v24
    .line 2: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 5: move-result v1
    .line 6: const/4 v2, 1
    .line 7: const/4 v3, 2
    .line 8: if-eq v1, v3, :cond_13
    .line 10: if-eq v1, v2, :cond_13
    .line 12: goto :goto_2
    .line 13: if-ne v1, v3, :cond_289
    .line 15: const/4 v1, 0
    .line 16: const-string v4, "font-family"
    .line 18: move-object/from16 v5, v23
    .line 20: invoke-interface {v5, v3, v1, v4}, Lorg/xmlpull/v1/XmlPullParser;->require(ILjava/lang/String;Ljava/lang/String;)V
    .line 23: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    .line 26: move-result-object v6
    .line 27: invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 30: move-result v4
    .line 31: if-eqz v4, :cond_284
    .line 33: invoke-static/range {v23 .. v23}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    .line 36: move-result-object v4
    .line 37: sget-object v6, Lu1/a;->b:[I
    .line 39: invoke-virtual {v0, v4, v6}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    .line 42: move-result-object v4
    .line 43: const/4 v6, 0
    .line 44: invoke-virtual {v4, v6}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 47: move-result-object v7
    .line 48: const/4 v8, 4
    .line 49: invoke-virtual {v4, v8}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 52: move-result-object v9
    .line 53: const/4 v10, 5
    .line 54: invoke-virtual {v4, v10}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 57: move-result-object v11
    .line 58: invoke-virtual {v4, v2, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I
    .line 61: move-result v12
    .line 62: invoke-virtual {v4, v3, v2}, Landroid/content/res/TypedArray;->getInteger(II)I
    .line 65: move-result v13
    .line 66: const/4 v14, 3
    .line 67: const/16 v15, 500
    .line 69: invoke-virtual {v4, v14, v15}, Landroid/content/res/TypedArray;->getInteger(II)I
    .line 72: move-result v15
    .line 73: const/4 v1, 6
    .line 74: invoke-virtual {v4, v1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 77: move-result-object v8
    .line 78: invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V
    .line 81: if-eqz v7, :cond_113
    .line 83: if-eqz v9, :cond_113
    .line 85: if-eqz v11, :cond_113
    .line 87: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 90: move-result v1
    .line 91: if-eq v1, v14, :cond_97
    .line 93: invoke-static/range {v23 .. v23}, Ld2/c;->B0(Landroid/content/res/XmlResourceParser;)V
    .line 96: goto :goto_87
    .line 97: invoke-static {v0, v12}, Ld2/c;->t0(Landroid/content/res/Resources;I)Ljava/util/List;
    .line 100: move-result-object v0
    .line 101: new-instance v1, Lx1/h;
    .line 103: new-instance v2, Lb2/e;
    .line 105: invoke-direct {v2, v7, v9, v11, v0}, Lb2/e;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .line 108: invoke-direct {v1, v2, v13, v15, v8}, Lx1/h;-><init>(Lb2/e;IILjava/lang/String;)V
    .line 111: goto/16 :goto_288
    .line 113: new-instance v4, Ljava/util/ArrayList;
    .line 115: invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V
    .line 118: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 121: move-result v7
    .line 122: if-eq v7, v14, :cond_263
    .line 124: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I
    .line 127: move-result v7
    .line 128: if-eq v7, v3, :cond_131
    .line 130: goto :goto_118
    .line 131: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    .line 134: move-result-object v7
    .line 135: const-string v8, "font"
    .line 137: invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 140: move-result v7
    .line 141: if-eqz v7, :cond_258
    .line 143: invoke-static/range {v23 .. v23}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    .line 146: move-result-object v7
    .line 147: sget-object v8, Lu1/a;->c:[I
    .line 149: invoke-virtual {v0, v7, v8}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    .line 152: move-result-object v7
    .line 153: const/16 v8, 8
    .line 155: invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->hasValue(I)Z
    .line 158: move-result v9
    .line 159: if-eqz v9, :cond_162
    .line 161: goto :goto_163
    .line 162: move v8, v2
    .line 163: const/16 v9, 400
    .line 165: invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getInt(II)I
    .line 168: move-result v17
    .line 169: invoke-virtual {v7, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z
    .line 172: move-result v8
    .line 173: if-eqz v8, :cond_177
    .line 175: move v8, v1
    .line 176: goto :goto_178
    .line 177: move v8, v3
    .line 178: invoke-virtual {v7, v8, v6}, Landroid/content/res/TypedArray;->getInt(II)I
    .line 181: move-result v8
    .line 182: if-ne v2, v8, :cond_187
    .line 184: move/from16 v22, v2
    .line 186: goto :goto_189
    .line 187: move/from16 v22, v6
    .line 189: const/16 v8, 9
    .line 191: invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->hasValue(I)Z
    .line 194: move-result v9
    .line 195: if-eqz v9, :cond_198
    .line 197: goto :goto_199
    .line 198: move v8, v14
    .line 199: const/4 v9, 7
    .line 200: invoke-virtual {v7, v9}, Landroid/content/res/TypedArray;->hasValue(I)Z
    .line 203: move-result v11
    .line 204: if-eqz v11, :cond_207
    .line 206: goto :goto_208
    .line 207: const/4 v9, 4
    .line 208: invoke-virtual {v7, v9}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 211: move-result-object v21
    .line 212: invoke-virtual {v7, v8, v6}, Landroid/content/res/TypedArray;->getInt(II)I
    .line 215: move-result v18
    .line 216: invoke-virtual {v7, v10}, Landroid/content/res/TypedArray;->hasValue(I)Z
    .line 219: move-result v8
    .line 220: if-eqz v8, :cond_224
    .line 222: move v8, v10
    .line 223: goto :goto_225
    .line 224: move v8, v6
    .line 225: invoke-virtual {v7, v8, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I
    .line 228: move-result v19
    .line 229: invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    .line 232: move-result-object v20
    .line 233: invoke-virtual {v7}, Landroid/content/res/TypedArray;->recycle()V
    .line 236: invoke-interface/range {v23 .. v23}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    .line 239: move-result v7
    .line 240: if-eq v7, v14, :cond_246
    .line 242: invoke-static/range {v23 .. v23}, Ld2/c;->B0(Landroid/content/res/XmlResourceParser;)V
    .line 245: goto :goto_236
    .line 246: new-instance v7, Lx1/g;
    .line 248: move-object/from16 v16, v7
    .line 250: invoke-direct/range {v16 .. v22}, Lx1/g;-><init>(IIILjava/lang/String;Ljava/lang/String;Z)V
    .line 253: invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 256: goto/16 :goto_118
    .line 258: invoke-static/range {v23 .. v23}, Ld2/c;->B0(Landroid/content/res/XmlResourceParser;)V
    .line 261: goto/16 :goto_118
    .line 263: invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z
    .line 266: move-result v0
    .line 267: if-eqz v0, :cond_270
    .line 269: goto :goto_287
    .line 270: new-instance v1, Lx1/f;
    .line 272: new-array v0, v6, [Lx1/g;
    .line 274: invoke-virtual {v4, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 277: move-result-object v0
    .line 278: check-cast v0, [Lx1/g;
    .line 280: invoke-direct {v1, v0}, Lx1/f;-><init>([Lx1/g;)V
    .line 283: goto :goto_288
    .line 284: invoke-static/range {v23 .. v23}, Ld2/c;->B0(Landroid/content/res/XmlResourceParser;)V
    .line 287: const/4 v1, 0
    .line 288: return-object v1
    .line 289: new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;
    .line 291: const-string v1, "No start tag found"
    .line 293: invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V
    .line 296: throw v0
.end method

# direct methods
.method public static final o(Ljava/util/ArrayList;)Z
    .registers 12

    .line 0: invoke-virtual {v11}, Ljava/util/ArrayList;->size()I
    .line 3: move-result v0
    .line 4: const/4 v1, 2
    .line 5: const/4 v2, 1
    .line 6: if-ge v0, v1, :cond_9
    .line 8: return v2
    .line 9: invoke-virtual {v11}, Ljava/util/ArrayList;->size()I
    .line 12: move-result v0
    .line 13: const/4 v1, 0
    .line 14: if-eqz v0, :cond_122
    .line 16: invoke-virtual {v11}, Ljava/util/ArrayList;->size()I
    .line 19: move-result v0
    .line 20: if-ne v0, v2, :cond_23
    .line 22: goto :goto_122
    .line 23: new-instance v0, Ljava/util/ArrayList;
    .line 25: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 28: invoke-virtual {v11, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 31: move-result-object v3
    .line 32: invoke-static {v11}, Ld2/b;->r0(Ljava/util/List;)I
    .line 35: move-result v4
    .line 36: move v5, v1
    .line 37: if-ge v5, v4, :cond_124
    .line 39: add-int/lit8 v5, v5, 1
    .line 41: invoke-virtual {v11, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 44: move-result-object v6
    .line 45: move-object v7, v6
    .line 46: check-cast v7, Ld1/n;
    .line 48: check-cast v3, Ld1/n;
    .line 50: invoke-virtual {v3}, Ld1/n;->e()Lj0/d;
    .line 53: move-result-object v8
    .line 54: invoke-virtual {v8}, Lj0/d;->a()J
    .line 57: move-result-wide v8
    .line 58: invoke-static {v8, v9}, Lj0/c;->c(J)F
    .line 61: move-result v8
    .line 62: invoke-virtual {v7}, Ld1/n;->e()Lj0/d;
    .line 65: move-result-object v9
    .line 66: invoke-virtual {v9}, Lj0/d;->a()J
    .line 69: move-result-wide v9
    .line 70: invoke-static {v9, v10}, Lj0/c;->c(J)F
    .line 73: move-result v9
    .line 74: sub-float/2addr v8, v9
    .line 75: invoke-static {v8}, Ljava/lang/Math;->abs(F)F
    .line 78: move-result v8
    .line 79: invoke-virtual {v3}, Ld1/n;->e()Lj0/d;
    .line 82: move-result-object v3
    .line 83: invoke-virtual {v3}, Lj0/d;->a()J
    .line 86: move-result-wide v9
    .line 87: invoke-static {v9, v10}, Lj0/c;->d(J)F
    .line 90: move-result v3
    .line 91: invoke-virtual {v7}, Ld1/n;->e()Lj0/d;
    .line 94: move-result-object v7
    .line 95: invoke-virtual {v7}, Lj0/d;->a()J
    .line 98: move-result-wide v9
    .line 99: invoke-static {v9, v10}, Lj0/c;->d(J)F
    .line 102: move-result v7
    .line 103: sub-float/2addr v3, v7
    .line 104: invoke-static {v3}, Ljava/lang/Math;->abs(F)F
    .line 107: move-result v3
    .line 108: invoke-static {v8, v3}, Ln3/a0;->g(FF)J
    .line 111: move-result-wide v7
    .line 112: new-instance v3, Lj0/c;
    .line 114: invoke-direct {v3, v7, v8}, Lj0/c;-><init>(J)V
    .line 117: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 120: move-object v3, v6
    .line 121: goto :goto_37
    .line 122: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 124: invoke-interface {v0}, Ljava/util/Collection;->size()I
    .line 127: move-result v11
    .line 128: if-ne v11, v2, :cond_139
    .line 130: invoke-static {v0}, Lt2/p;->K1(Ljava/util/List;)Ljava/lang/Object;
    .line 133: move-result-object v11
    .line 134: check-cast v11, Lj0/c;
    .line 136: iget-wide v3, v11, Lj0/c;->a:J
    .line 138: goto :goto_186
    .line 139: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    .line 142: move-result v11
    .line 143: if-nez v11, :cond_201
    .line 145: invoke-static {v0}, Lt2/p;->K1(Ljava/util/List;)Ljava/lang/Object;
    .line 148: move-result-object v11
    .line 149: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 152: move-result v3
    .line 153: if-gt v2, v3, :cond_182
    .line 155: move v4, v2
    .line 156: invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 159: move-result-object v5
    .line 160: check-cast v5, Lj0/c;
    .line 162: iget-wide v5, v5, Lj0/c;->a:J
    .line 164: check-cast v11, Lj0/c;
    .line 166: iget-wide v7, v11, Lj0/c;->a:J
    .line 168: invoke-static {v7, v8, v5, v6}, Lj0/c;->f(JJ)J
    .line 171: move-result-wide v5
    .line 172: new-instance v11, Lj0/c;
    .line 174: invoke-direct {v11, v5, v6}, Lj0/c;-><init>(J)V
    .line 177: if-eq v4, v3, :cond_182
    .line 179: add-int/lit8 v4, v4, 1
    .line 181: goto :goto_156
    .line 182: check-cast v11, Lj0/c;
    .line 184: iget-wide v3, v11, Lj0/c;->a:J
    .line 186: invoke-static {v3, v4}, Lj0/c;->c(J)F
    .line 189: move-result v11
    .line 190: invoke-static {v3, v4}, Lj0/c;->d(J)F
    .line 193: move-result v0
    .line 194: cmpg-float v11, v0, v11
    .line 196: if-gez v11, :cond_199
    .line 198: goto :goto_200
    .line 199: move v2, v1
    .line 200: return v2
    .line 201: new-instance v11, Ljava/lang/UnsupportedOperationException;
    .line 203: const-string v0, "Empty collection can't be reduced."
    .line 205: invoke-direct {v11, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 208: throw v11
.end method

# direct methods
.method public static o0(Ljava/lang/String;)Ljava/lang/Integer;
    .registers 6

    .line 0: invoke-static {v5}, Lm3/j;->T1(Ljava/lang/CharSequence;)Ll3/g;
    .line 3: move-result-object v5
    .line 4: invoke-virtual {v5}, Ll3/g;->iterator()Ljava/util/Iterator;
    .line 7: move-result-object v5
    .line 8: const/4 v0, 0
    .line 9: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 12: move-result v1
    .line 13: if-eqz v1, :cond_121
    .line 15: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 18: move-result-object v1
    .line 19: check-cast v1, Ljava/lang/String;
    .line 21: const-string v2, "info"
    .line 23: const/4 v3, 0
    .line 24: invoke-static {v1, v2, v3}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 27: move-result v2
    .line 28: if-eqz v2, :cond_9
    .line 30: const/4 v2, 1
    .line 31: new-array v2, v2, [C
    .line 33: const/16 v4, 32
    .line 35: aput-char v4, v2, v3
    .line 37: invoke-static {v1, v2}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 40: move-result-object v1
    .line 41: const-string v2, "score"
    .line 43: invoke-interface {v1, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I
    .line 46: move-result v2
    .line 47: if-ltz v2, :cond_9
    .line 49: add-int/lit8 v3, v2, 2
    .line 51: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 54: move-result v4
    .line 55: if-lt v3, v4, :cond_58
    .line 57: goto :goto_9
    .line 58: add-int/lit8 v2, v2, 1
    .line 60: invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 63: move-result-object v2
    .line 64: check-cast v2, Ljava/lang/String;
    .line 66: invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 69: move-result-object v1
    .line 70: check-cast v1, Ljava/lang/String;
    .line 72: invoke-static {v1}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 75: move-result-object v1
    .line 76: if-eqz v1, :cond_9
    .line 78: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    .line 81: move-result v1
    .line 82: const-string v3, "cp"
    .line 84: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 87: move-result v3
    .line 88: if-eqz v3, :cond_95
    .line 90: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 93: move-result-object v0
    .line 94: goto :goto_9
    .line 95: const-string v3, "mate"
    .line 97: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 100: move-result v2
    .line 101: if-eqz v2, :cond_9
    .line 103: if-lez v1, :cond_108
    .line 105: rsub-int v0, v1, 30000
    .line 107: goto :goto_116
    .line 108: if-gez v1, :cond_114
    .line 110: add-int/lit16 v1, v1, 30000
    .line 112: neg-int v0, v1
    .line 113: goto :goto_116
    .line 114: const/16 v0, -30000
    .line 116: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 119: move-result-object v0
    .line 120: goto :goto_9
    .line 121: return-object v0
.end method

# direct methods
.method public static p0(Lw2/j;Lw2/j;)Lw2/j;
    .registers 3

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Lw2/k;->i:Lw2/k;
    .line 7: if-ne v2, v0, :cond_10
    .line 9: goto :goto_18
    .line 10: sget-object v0, Lw2/c;->l:Lw2/c;
    .line 12: invoke-interface {v2, v1, v0}, Lw2/j;->i(Ljava/lang/Object;Ld3/e;)Ljava/lang/Object;
    .line 15: move-result-object v1
    .line 16: check-cast v1, Lw2/j;
    .line 18: return-object v1
.end method

# direct methods
.method public static final q0([F[FI[F)V
    .registers 22

    .line 0: move-object/from16 v0, v18
    .line 2: move-object/from16 v1, v19
    .line 4: move/from16 v2, v20
    .line 6: move-object/from16 v3, v21
    .line 8: const-string v4, "x"
    .line 10: invoke-static {v0, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 13: const-string v4, "y"
    .line 15: invoke-static {v1, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 18: const-string v4, "coefficients"
    .line 20: invoke-static {v3, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 23: if-eqz v2, :cond_253
    .line 25: const/4 v4, 2
    .line 26: if-lt v4, v2, :cond_30
    .line 28: add-int/lit8 v4, v2, -1
    .line 30: add-int/lit8 v5, v4, 1
    .line 32: new-array v6, v5, [[F
    .line 34: const/4 v7, 0
    .line 35: move v8, v7
    .line 36: if-ge v8, v5, :cond_45
    .line 38: new-array v9, v2, [F
    .line 40: aput-object v9, v6, v8
    .line 42: add-int/lit8 v8, v8, 1
    .line 44: goto :goto_36
    .line 45: move v8, v7
    .line 46: const/high16 v9, 0x3f80
    .line 48: if-ge v8, v2, :cond_76
    .line 50: aget-object v10, v6, v7
    .line 52: aput v9, v10, v8
    .line 54: const/4 v9, 1
    .line 55: if-ge v9, v5, :cond_73
    .line 57: add-int/lit8 v10, v9, -1
    .line 59: aget-object v10, v6, v10
    .line 61: aget v10, v10, v8
    .line 63: aget v11, v0, v8
    .line 65: mul-float/2addr v10, v11
    .line 66: aget-object v11, v6, v9
    .line 68: aput v10, v11, v8
    .line 70: add-int/lit8 v9, v9, 1
    .line 72: goto :goto_55
    .line 73: add-int/lit8 v8, v8, 1
    .line 75: goto :goto_46
    .line 76: new-array v0, v5, [[F
    .line 78: move v8, v7
    .line 79: if-ge v8, v5, :cond_88
    .line 81: new-array v10, v2, [F
    .line 83: aput-object v10, v0, v8
    .line 85: add-int/lit8 v8, v8, 1
    .line 87: goto :goto_79
    .line 88: new-array v8, v5, [[F
    .line 90: move v10, v7
    .line 91: if-ge v10, v5, :cond_100
    .line 93: new-array v11, v5, [F
    .line 95: aput-object v11, v8, v10
    .line 97: add-int/lit8 v10, v10, 1
    .line 99: goto :goto_91
    .line 100: move v10, v7
    .line 101: if-ge v10, v5, :cond_206
    .line 103: aget-object v11, v0, v10
    .line 105: aget-object v12, v6, v10
    .line 107: move v13, v7
    .line 108: if-ge v13, v2, :cond_117
    .line 110: aget v14, v12, v13
    .line 112: aput v14, v11, v13
    .line 114: add-int/lit8 v13, v13, 1
    .line 116: goto :goto_108
    .line 117: move v12, v7
    .line 118: if-ge v12, v10, :cond_145
    .line 120: aget-object v13, v0, v12
    .line 122: invoke-static {v11, v13}, Ld2/c;->L([F[F)F
    .line 125: move-result v14
    .line 126: move v15, v7
    .line 127: if-ge v15, v2, :cond_142
    .line 129: aget v16, v11, v15
    .line 131: aget v17, v13, v15
    .line 133: mul-float v17, v17, v14
    .line 135: sub-float v16, v16, v17
    .line 137: aput v16, v11, v15
    .line 139: add-int/lit8 v15, v15, 1
    .line 141: goto :goto_127
    .line 142: add-int/lit8 v12, v12, 1
    .line 144: goto :goto_118
    .line 145: invoke-static {v11, v11}, Ld2/c;->L([F[F)F
    .line 148: move-result v12
    .line 149: float-to-double v12, v12
    .line 150: invoke-static {v12, v13}, Ljava/lang/Math;->sqrt(D)D
    .line 153: move-result-wide v12
    .line 154: double-to-float v12, v12
    .line 155: const v13, 0x358637bd
    .line 158: cmpg-float v13, v12, v13
    .line 160: if-ltz v13, :cond_198
    .line 162: div-float v12, v9, v12
    .line 164: move v13, v7
    .line 165: if-ge v13, v2, :cond_175
    .line 167: aget v14, v11, v13
    .line 169: mul-float/2addr v14, v12
    .line 170: aput v14, v11, v13
    .line 172: add-int/lit8 v13, v13, 1
    .line 174: goto :goto_165
    .line 175: aget-object v12, v8, v10
    .line 177: move v13, v7
    .line 178: if-ge v13, v5, :cond_195
    .line 180: if-ge v13, v10, :cond_184
    .line 182: const/4 v14, 0
    .line 183: goto :goto_190
    .line 184: aget-object v14, v6, v13
    .line 186: invoke-static {v11, v14}, Ld2/c;->L([F[F)F
    .line 189: move-result v14
    .line 190: aput v14, v12, v13
    .line 192: add-int/lit8 v13, v13, 1
    .line 194: goto :goto_178
    .line 195: add-int/lit8 v10, v10, 1
    .line 197: goto :goto_101
    .line 198: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 200: const-string v1, "Vectors are linearly dependent or zero so no solution. TODO(shepshapard), actually determine what this means"
    .line 202: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 205: throw v0
    .line 206: move v2, v4
    .line 207: const/4 v5, -1
    .line 208: if-ge v5, v2, :cond_252
    .line 210: aget-object v5, v0, v2
    .line 212: invoke-static {v5, v1}, Ld2/c;->L([F[F)F
    .line 215: move-result v5
    .line 216: aput v5, v3, v2
    .line 218: add-int/lit8 v5, v2, 1
    .line 220: if-gt v5, v4, :cond_240
    .line 222: move v6, v4
    .line 223: aget v7, v3, v2
    .line 225: aget-object v9, v8, v2
    .line 227: aget v9, v9, v6
    .line 229: aget v10, v3, v6
    .line 231: mul-float/2addr v9, v10
    .line 232: sub-float/2addr v7, v9
    .line 233: aput v7, v3, v2
    .line 235: if-eq v6, v5, :cond_240
    .line 237: add-int/lit8 v6, v6, -1
    .line 239: goto :goto_223
    .line 240: aget v5, v3, v2
    .line 242: aget-object v6, v8, v2
    .line 244: aget v6, v6, v2
    .line 246: div-float/2addr v5, v6
    .line 247: aput v5, v3, v2
    .line 249: add-int/lit8 v2, v2, -1
    .line 251: goto :goto_207
    .line 252: return-void
    .line 253: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 255: const-string v1, "At least one point must be provided"
    .line 257: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 260: throw v0
.end method

# direct methods
.method public static s(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 2

    .line 0: if-eqz v0, :cond_3
    .line 2: return-void
    .line 3: new-instance v0, Ljava/lang/NullPointerException;
    .line 5: invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
.end method

# direct methods
.method public static t(I)V
    .registers 7

    .line 0: new-instance v0, Lj3/d;
    .line 2: const/4 v1, 2
    .line 3: const/16 v2, 36
    .line 5: const/4 v3, 1
    .line 6: invoke-direct {v0, v1, v2, v3}, Lj3/b;-><init>(III)V
    .line 9: if-gt v1, v6, :cond_16
    .line 11: iget v0, v0, Lj3/b;->j:I
    .line 13: if-gt v6, v0, :cond_16
    .line 15: return-void
    .line 16: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 18: new-instance v4, Ljava/lang/StringBuilder;
    .line 20: const-string v5, "radix "
    .line 22: invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 25: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 28: const-string v6, " was not in valid range "
    .line 30: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 33: new-instance v6, Lj3/d;
    .line 35: invoke-direct {v6, v1, v2, v3}, Lj3/b;-><init>(III)V
    .line 38: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 41: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 44: move-result-object v6
    .line 45: invoke-direct {v0, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 48: throw v0
.end method

# direct methods
.method public static t0(Landroid/content/res/Resources;I)Ljava/util/List;
    .registers 10

    .line 0: if-nez v9, :cond_7
    .line 2: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    .line 5: move-result-object v8
    .line 6: return-object v8
    .line 7: invoke-virtual {v8, v9}, Landroid/content/res/Resources;->obtainTypedArray(I)Landroid/content/res/TypedArray;
    .line 10: move-result-object v0
    .line 11: invoke-virtual {v0}, Landroid/content/res/TypedArray;->length()I
    .line 14: move-result v1
    .line 15: if-nez v1, :cond_27
    .line 17: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    .line 20: move-result-object v8
    .line 21: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    .line 24: return-object v8
    .line 25: move-exception v8
    .line 26: goto :goto_116
    .line 27: new-instance v1, Ljava/util/ArrayList;
    .line 29: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 32: const/4 v2, 0
    .line 33: invoke-static {v0, v2}, Lx1/d;->a(Landroid/content/res/TypedArray;I)I
    .line 36: move-result v3
    .line 37: const/4 v4, 1
    .line 38: if-ne v3, v4, :cond_84
    .line 40: move v9, v2
    .line 41: invoke-virtual {v0}, Landroid/content/res/TypedArray;->length()I
    .line 44: move-result v3
    .line 45: if-ge v9, v3, :cond_112
    .line 47: invoke-virtual {v0, v9, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I
    .line 50: move-result v3
    .line 51: if-eqz v3, :cond_81
    .line 53: invoke-virtual {v8, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;
    .line 56: move-result-object v3
    .line 57: new-instance v4, Ljava/util/ArrayList;
    .line 59: invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V
    .line 62: array-length v5, v3
    .line 63: move v6, v2
    .line 64: if-ge v6, v5, :cond_78
    .line 66: aget-object v7, v3, v6
    .line 68: invoke-static {v7, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B
    .line 71: move-result-object v7
    .line 72: invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 75: add-int/lit8 v6, v6, 1
    .line 77: goto :goto_64
    .line 78: invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 81: add-int/lit8 v9, v9, 1
    .line 83: goto :goto_41
    .line 84: invoke-virtual {v8, v9}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;
    .line 87: move-result-object v8
    .line 88: new-instance v9, Ljava/util/ArrayList;
    .line 90: invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V
    .line 93: array-length v3, v8
    .line 94: move v4, v2
    .line 95: if-ge v4, v3, :cond_109
    .line 97: aget-object v5, v8, v4
    .line 99: invoke-static {v5, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B
    .line 102: move-result-object v5
    .line 103: invoke-virtual {v9, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 106: add-int/lit8 v4, v4, 1
    .line 108: goto :goto_95
    .line 109: invoke-virtual {v1, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 112: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    .line 115: return-object v1
    .line 116: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    .line 119: throw v8
.end method

# direct methods
.method public static u(IIZ)Lcom/titanchess/accessibility/k;
    .registers 11

    .line 0: if-eqz v10, :cond_5
    .line 2: sget-object v8, Lcom/titanchess/accessibility/k;->k:Lcom/titanchess/accessibility/k;
    .line 4: return-object v8
    .line 5: invoke-static {v8}, Ld2/c;->F(I)D
    .line 8: move-result-wide v0
    .line 9: invoke-static {v9}, Ld2/c;->F(I)D
    .line 12: move-result-wide v8
    .line 13: sub-double v2, v0, v8
    .line 15: const-wide/16 v4, 0
    .line 17: const-wide/high16 v6, 0x3ff0
    .line 19: invoke-static/range {v2 .. v7}, Ld2/b;->E(DDD)D
    .line 22: move-result-wide v8
    .line 23: const-wide v0, 0x3f947ae147ae147b
    .line 28: cmpg-double v10, v8, v0
    .line 30: if-gez v10, :cond_35
    .line 32: sget-object v8, Lcom/titanchess/accessibility/k;->l:Lcom/titanchess/accessibility/k;
    .line 34: goto :goto_73
    .line 35: const-wide v0, 0x3fa999999999999a
    .line 40: cmpg-double v10, v8, v0
    .line 42: if-gez v10, :cond_47
    .line 44: sget-object v8, Lcom/titanchess/accessibility/k;->m:Lcom/titanchess/accessibility/k;
    .line 46: goto :goto_73
    .line 47: const-wide v0, 0x3fb999999999999a
    .line 52: cmpg-double v10, v8, v0
    .line 54: if-gez v10, :cond_59
    .line 56: sget-object v8, Lcom/titanchess/accessibility/k;->n:Lcom/titanchess/accessibility/k;
    .line 58: goto :goto_73
    .line 59: const-wide v0, 0x3fc999999999999a
    .line 64: cmpg-double v8, v8, v0
    .line 66: if-gez v8, :cond_71
    .line 68: sget-object v8, Lcom/titanchess/accessibility/k;->o:Lcom/titanchess/accessibility/k;
    .line 70: goto :goto_73
    .line 71: sget-object v8, Lcom/titanchess/accessibility/k;->p:Lcom/titanchess/accessibility/k;
    .line 73: return-object v8
.end method

# direct methods
.method public static final u0([Ljava/lang/Object;Lc0/l;Ld3/a;Lu/l;I)Ljava/lang/Object;
    .registers 14

    .line 0: const-string v0, "init"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: check-cast v12, Lu/b0;
    .line 7: const v0, 0x1a56bfab
    .line 10: invoke-virtual {v12, v0}, Lu/b0;->d0(I)V
    .line 13: and-int/lit8 v13, v13, 2
    .line 15: if-eqz v13, :cond_24
    .line 17: sget-object v10, Lc0/m;->a:Lc0/l;
    .line 19: const-string v13, "null cannot be cast to non-null type androidx.compose.runtime.saveable.Saver<T of androidx.compose.runtime.saveable.SaverKt.autoSaver, kotlin.Any>"
    .line 21: invoke-static {v10, v13}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 24: const v13, 0x3f24a645
    .line 27: invoke-virtual {v12, v13}, Lu/b0;->d0(I)V
    .line 30: iget v13, v12, Lu/b0;->N:I
    .line 32: const/16 v0, 36
    .line 34: invoke-static {v0}, Ld2/c;->t(I)V
    .line 37: invoke-static {v13, v0}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;
    .line 40: move-result-object v13
    .line 41: const-string v0, "toString(this, checkRadix(radix))"
    .line 43: invoke-static {v13, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 46: const/4 v0, 0
    .line 47: invoke-virtual {v12, v0}, Lu/b0;->t(Z)V
    .line 50: const-string v1, "null cannot be cast to non-null type androidx.compose.runtime.saveable.Saver<T of androidx.compose.runtime.saveable.RememberSaveableKt.rememberSaveable, kotlin.Any>"
    .line 52: invoke-static {v10, v1}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 55: sget-object v1, Lc0/i;->a:Lu/j3;
    .line 57: invoke-virtual {v12, v1}, Lu/b0;->l(Lu/z1;)Ljava/lang/Object;
    .line 60: move-result-object v1
    .line 61: move-object v7, v1
    .line 62: check-cast v7, Lc0/e;
    .line 64: array-length v1, v9
    .line 65: invoke-static {v9, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 68: move-result-object v9
    .line 69: const v1, 0xde219177
    .line 72: invoke-virtual {v12, v1}, Lu/b0;->d0(I)V
    .line 75: array-length v1, v9
    .line 76: move v2, v0
    .line 77: move v3, v2
    .line 78: if-ge v2, v1, :cond_90
    .line 80: aget-object v4, v9, v2
    .line 82: invoke-virtual {v12, v4}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 85: move-result v4
    .line 86: or-int/2addr v3, v4
    .line 87: add-int/lit8 v2, v2, 1
    .line 89: goto :goto_78
    .line 90: invoke-virtual {v12}, Lu/b0;->I()Ljava/lang/Object;
    .line 93: move-result-object v9
    .line 94: sget-object v8, Lu/k;->i:Landroidx/activity/b;
    .line 96: if-nez v3, :cond_100
    .line 98: if-ne v9, v8, :cond_125
    .line 100: if-eqz v7, :cond_115
    .line 102: invoke-interface {v7, v13}, Lc0/e;->a(Ljava/lang/String;)Ljava/lang/Object;
    .line 105: move-result-object v9
    .line 106: if-eqz v9, :cond_115
    .line 108: iget-object v1, v10, Lc0/l;->b:Ld3/c;
    .line 110: invoke-interface {v1, v9}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 113: move-result-object v9
    .line 114: goto :goto_116
    .line 115: const/4 v9, 0
    .line 116: if-nez v9, :cond_122
    .line 118: invoke-interface {v11}, Ld3/a;->s()Ljava/lang/Object;
    .line 121: move-result-object v9
    .line 122: invoke-virtual {v12, v9}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 125: invoke-virtual {v12, v0}, Lu/b0;->t(Z)V
    .line 128: if-eqz v7, :cond_190
    .line 130: invoke-static {v10, v12}, Le3/g;->z(Ljava/lang/Object;Lu/l;)Lu/l1;
    .line 133: move-result-object v4
    .line 134: invoke-static {v9, v12}, Le3/g;->z(Ljava/lang/Object;Lu/l;)Lu/l1;
    .line 137: move-result-object v5
    .line 138: new-instance v10, Lh/a;
    .line 140: const/4 v6, 4
    .line 141: move-object v1, v10
    .line 142: move-object v2, v7
    .line 143: move-object v3, v13
    .line 144: invoke-direct/range {v1 .. v6}, Lh/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .line 147: const v11, 0x552e4d01
    .line 150: invoke-virtual {v12, v11}, Lu/b0;->d0(I)V
    .line 153: const v11, 0x1e7b2b64
    .line 156: invoke-virtual {v12, v11}, Lu/b0;->d0(I)V
    .line 159: invoke-virtual {v12, v7}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 162: move-result v11
    .line 163: invoke-virtual {v12, v13}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 166: move-result v13
    .line 167: or-int/2addr v11, v13
    .line 168: invoke-virtual {v12}, Lu/b0;->I()Ljava/lang/Object;
    .line 171: move-result-object v13
    .line 172: if-nez v11, :cond_176
    .line 174: if-ne v13, v8, :cond_184
    .line 176: new-instance v11, Lu/t0;
    .line 178: invoke-direct {v11, v10}, Lu/t0;-><init>(Ld3/c;)V
    .line 181: invoke-virtual {v12, v11}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 184: invoke-virtual {v12, v0}, Lu/b0;->t(Z)V
    .line 187: invoke-virtual {v12, v0}, Lu/b0;->t(Z)V
    .line 190: invoke-virtual {v12, v0}, Lu/b0;->t(Z)V
    .line 193: return-object v9
.end method

# direct methods
.method public static final v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .registers 2

    .line 0: if-eqz v0, :cond_16
    .line 2: if-nez v1, :cond_8
    .line 4: invoke-interface {v0}, Ljava/io/Closeable;->close()V
    .line 7: goto :goto_16
    .line 8: invoke-interface {v0}, Ljava/io/Closeable;->close()V
    .line 11: goto :goto_16
    .line 12: move-exception v0
    .line 13: invoke-static {v1, v0}, Ld2/b;->j(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .line 16: return-void
.end method

# direct methods
.method public static final v0(JFLr1/b;)F
    .registers 8

    .line 0: invoke-static {v4, v5}, Lr1/k;->b(J)J
    .line 3: move-result-wide v0
    .line 4: const-wide v2, 0x0100
    .line 9: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 12: move-result v2
    .line 13: if-eqz v2, :cond_20
    .line 15: invoke-interface {v7, v4, v5}, Lr1/b;->j(J)F
    .line 18: move-result v4
    .line 19: goto :goto_39
    .line 20: const-wide v2, 0x0200
    .line 25: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 28: move-result v7
    .line 29: if-eqz v7, :cond_37
    .line 31: invoke-static {v4, v5}, Lr1/k;->c(J)F
    .line 34: move-result v4
    .line 35: mul-float/2addr v4, v6
    .line 36: goto :goto_39
    .line 37: const/high16 v4, 0x7fc0
    .line 39: return v4
.end method

# direct methods
.method public static varargs w([Ld3/c;)Lv2/a;
    .registers 2

    .line 0: array-length v0, v1
    .line 1: if-lez v0, :cond_9
    .line 3: new-instance v0, Lv2/a;
    .line 5: invoke-direct {v0, v1}, Lv2/a;-><init>([Ld3/c;)V
    .line 8: return-object v0
    .line 9: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 11: const-string v0, "Failed requirement."
    .line 13: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 16: move-result-object v0
    .line 17: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 20: throw v1
.end method

# direct methods
.method public static final w0(Landroid/text/Spannable;JII)V
    .registers 7

    .line 0: sget-wide v0, Lk0/q;->g:J
    .line 2: cmp-long v0, v3, v0
    .line 4: if-eqz v0, :cond_18
    .line 6: new-instance v0, Landroid/text/style/ForegroundColorSpan;
    .line 8: invoke-static {v3, v4}, Landroidx/compose/ui/graphics/a;->t(J)I
    .line 11: move-result v3
    .line 12: invoke-direct {v0, v3}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V
    .line 15: invoke-static {v2, v0, v5, v6}, Ld2/c;->z0(Landroid/text/Spannable;Ljava/lang/Object;II)V
    .line 18: return-void
.end method

# direct methods
.method public static x(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 0
    .line 3: return v0
    .line 4: if-nez v0, :cond_8
    .line 6: const/4 v0, -1
    .line 7: return v0
    .line 8: if-nez v1, :cond_12
    .line 10: const/4 v0, 1
    .line 11: return v0
    .line 12: invoke-interface {v0, v1}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I
    .line 15: move-result v0
    .line 16: return v0
.end method

# direct methods
.method public static final x0(Landroid/text/Spannable;JLr1/b;II)V
    .registers 10

    .line 0: const-string v0, "density"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-static {v5, v6}, Lr1/k;->b(J)J
    .line 8: move-result-wide v0
    .line 9: const-wide v2, 0x0100
    .line 14: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 17: move-result v2
    .line 18: if-eqz v2, :cond_38
    .line 20: new-instance v0, Landroid/text/style/AbsoluteSizeSpan;
    .line 22: invoke-interface {v7, v5, v6}, Lr1/b;->j(J)F
    .line 25: move-result v5
    .line 26: invoke-static {v5}, Ld2/b;->a1(F)I
    .line 29: move-result v5
    .line 30: const/4 v6, 0
    .line 31: invoke-direct {v0, v5, v6}, Landroid/text/style/AbsoluteSizeSpan;-><init>(IZ)V
    .line 34: invoke-static {v4, v0, v8, v9}, Ld2/c;->z0(Landroid/text/Spannable;Ljava/lang/Object;II)V
    .line 37: goto :goto_61
    .line 38: const-wide v2, 0x0200
    .line 43: invoke-static {v0, v1, v2, v3}, Lr1/l;->a(JJ)Z
    .line 46: move-result v7
    .line 47: if-eqz v7, :cond_61
    .line 49: new-instance v7, Landroid/text/style/RelativeSizeSpan;
    .line 51: invoke-static {v5, v6}, Lr1/k;->c(J)F
    .line 54: move-result v5
    .line 55: invoke-direct {v7, v5}, Landroid/text/style/RelativeSizeSpan;-><init>(F)V
    .line 58: invoke-static {v4, v7, v8, v9}, Ld2/c;->z0(Landroid/text/Spannable;Ljava/lang/Object;II)V
    .line 61: return-void
.end method

# direct methods
.method public static final y(Lf0/p;Ld3/c;Ld3/f;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "inspectorInfo"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Lf0/j;
    .line 12: invoke-direct {v0, v2, v3}, Lf0/j;-><init>(Ld3/c;Ld3/f;)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method

# direct methods
.method public static final y0(Landroid/graphics/Typeface;Lk1/d0;Landroid/content/Context;)Landroid/graphics/Typeface;
    .registers 6

    .line 0: const-string v0, "variationSettings"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 7: const/16 v1, 26
    .line 9: if-lt v0, v1, :cond_71
    .line 11: sget-object v0, Lk1/n0;->a:Ljava/lang/ThreadLocal;
    .line 13: const/4 v0, 0
    .line 14: if-nez v3, :cond_18
    .line 16: move-object v3, v0
    .line 17: goto :goto_71
    .line 18: iget-object v4, v4, Lk1/d0;->a:Ljava/util/ArrayList;
    .line 20: invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z
    .line 23: move-result v1
    .line 24: if-eqz v1, :cond_27
    .line 26: goto :goto_71
    .line 27: sget-object v1, Lk1/n0;->a:Ljava/lang/ThreadLocal;
    .line 29: invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    .line 32: move-result-object v2
    .line 33: check-cast v2, Landroid/graphics/Paint;
    .line 35: if-nez v2, :cond_45
    .line 37: new-instance v2, Landroid/graphics/Paint;
    .line 39: invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V
    .line 42: invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    .line 45: invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 48: invoke-static {v5}, Ld2/b;->d(Landroid/content/Context;)Lr1/c;
    .line 51: move-result-object v3
    .line 52: new-instance v5, Lk1/t;
    .line 54: const/4 v1, 1
    .line 55: invoke-direct {v5, v1, v3}, Lk1/t;-><init>(ILjava/lang/Object;)V
    .line 58: const/16 v3, 31
    .line 60: invoke-static {v4, v0, v5, v3}, Ld2/b;->e0(Ljava/util/ArrayList;Ljava/lang/String;Lk1/t;I)Ljava/lang/String;
    .line 63: move-result-object v3
    .line 64: invoke-static {v2, v3}, Lk0/s;->m(Landroid/graphics/Paint;Ljava/lang/String;)V
    .line 67: invoke-virtual {v2}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;
    .line 70: move-result-object v3
    .line 71: return-object v3
.end method

# direct methods
.method public static final z(Ljava/util/ArrayList;Z)Ljava/lang/Double;
    .registers 13

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 5: invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 8: move-result-object v11
    .line 9: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 12: move-result v1
    .line 13: if-eqz v1, :cond_30
    .line 15: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 18: move-result-object v1
    .line 19: move-object v2, v1
    .line 20: check-cast v2, Lcom/titanchess/accessibility/v;
    .line 22: iget-boolean v2, v2, Lcom/titanchess/accessibility/v;->c:Z
    .line 24: if-ne v2, v12, :cond_9
    .line 26: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 29: goto :goto_9
    .line 30: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    .line 33: move-result v11
    .line 34: if-eqz v11, :cond_38
    .line 36: const/4 v11, 0
    .line 37: return-object v11
    .line 38: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 41: move-result-object v11
    .line 42: const-wide/16 v1, 0
    .line 44: move-wide v3, v1
    .line 45: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 48: move-result v12
    .line 49: if-eqz v12, :cond_61
    .line 51: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 54: move-result-object v12
    .line 55: check-cast v12, Lcom/titanchess/accessibility/v;
    .line 57: iget-wide v5, v12, Lcom/titanchess/accessibility/v;->b:D
    .line 59: add-double/2addr v3, v5
    .line 60: goto :goto_45
    .line 61: cmpl-double v11, v3, v1
    .line 63: if-lez v11, :cond_91
    .line 65: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 68: move-result-object v11
    .line 69: move-wide v5, v1
    .line 70: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 73: move-result v12
    .line 74: if-eqz v12, :cond_89
    .line 76: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 79: move-result-object v12
    .line 80: check-cast v12, Lcom/titanchess/accessibility/v;
    .line 82: iget-wide v7, v12, Lcom/titanchess/accessibility/v;->a:D
    .line 84: iget-wide v9, v12, Lcom/titanchess/accessibility/v;->b:D
    .line 86: mul-double/2addr v7, v9
    .line 87: add-double/2addr v5, v7
    .line 88: goto :goto_70
    .line 89: div-double/2addr v5, v3
    .line 90: goto :goto_130
    .line 91: new-instance v11, Ljava/util/ArrayList;
    .line 93: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 96: move-result v12
    .line 97: invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V
    .line 100: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 103: move-result-object v12
    .line 104: invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z
    .line 107: move-result v3
    .line 108: if-eqz v3, :cond_126
    .line 110: invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 113: move-result-object v3
    .line 114: check-cast v3, Lcom/titanchess/accessibility/v;
    .line 116: iget-wide v3, v3, Lcom/titanchess/accessibility/v;->a:D
    .line 118: invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 121: move-result-object v3
    .line 122: invoke-virtual {v11, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 125: goto :goto_104
    .line 126: invoke-static {v11}, Lt2/p;->H1(Ljava/util/List;)D
    .line 129: move-result-wide v5
    .line 130: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 133: move-result v11
    .line 134: int-to-double v11, v11
    .line 135: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 138: move-result-object v0
    .line 139: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 142: move-result v3
    .line 143: if-eqz v3, :cond_168
    .line 145: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 148: move-result-object v3
    .line 149: check-cast v3, Lcom/titanchess/accessibility/v;
    .line 151: iget-wide v3, v3, Lcom/titanchess/accessibility/v;->a:D
    .line 153: const-wide v7, 0x3f847ae147ae147b
    .line 158: cmpg-double v9, v3, v7
    .line 160: if-gez v9, :cond_163
    .line 162: move-wide v3, v7
    .line 163: const-wide/high16 v7, 0x3ff0
    .line 165: div-double/2addr v7, v3
    .line 166: add-double/2addr v1, v7
    .line 167: goto :goto_139
    .line 168: div-double/2addr v11, v1
    .line 169: add-double/2addr v11, v5
    .line 170: const-wide/high16 v0, 0x4000
    .line 172: div-double/2addr v11, v0
    .line 173: invoke-static {v11, v12}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 176: move-result-object v11
    .line 177: return-object v11
.end method

# direct methods
.method public static final z0(Landroid/text/Spannable;Ljava/lang/Object;II)V
    .registers 5

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "span"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const/16 v0, 33
    .line 12: invoke-interface {v1, v2, v3, v4, v0}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V
    .line 15: return-void
.end method

# virtual methods
.method public abstract D(Ly0/c;)Z
.end method

# virtual methods
.method public abstract T(Ly0/i;)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract k0(Ljava/lang/Throwable;)V
.end method

# virtual methods
.method public abstract l0(Landroidx/emoji2/text/x;)V
.end method

# virtual methods
.method public abstract p(Lt1/g;Lt1/c;)Z
.end method

# virtual methods
.method public abstract q(Lt1/g;Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

# virtual methods
.method public abstract r(Lt1/g;Lt1/f;Lt1/f;)Z
.end method

# virtual methods
.method public abstract r0(Lt1/f;Lt1/f;)V
.end method

# virtual methods
.method public abstract s0(Lt1/f;Ljava/lang/Thread;)V
.end method

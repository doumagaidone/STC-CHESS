.class public abstract Lb0/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lb0/g;

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: new-instance v0, Lb0/g;
    .line 2: const/4 v1, 0
    .line 3: new-array v2, v1, [J
    .line 5: new-array v3, v1, [Ljava/lang/Object;
    .line 7: invoke-direct {v0, v1, v2, v3}, Lb0/g;-><init>(I[J[Ljava/lang/Object;)V
    .line 10: sput-object v0, Lb0/h;->a:Lb0/g;
    .line 12: return-void
.end method

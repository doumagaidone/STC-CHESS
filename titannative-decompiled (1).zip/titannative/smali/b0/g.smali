.class public final Lb0/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:[J
.field public final c:[Ljava/lang/Object;

# direct methods
.method public constructor <init>(I[J[Ljava/lang/Object;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lb0/g;->a:I
    .line 5: iput-object v2, v0, Lb0/g;->b:[J
    .line 7: iput-object v3, v0, Lb0/g;->c:[Ljava/lang/Object;
    .line 9: return-void
.end method

# virtual methods
.method public final a(J)I
    .registers 11

    .line 0: iget v0, v8, Lb0/g;->a:I
    .line 2: add-int/lit8 v0, v0, -1
    .line 4: const/4 v1, -1
    .line 5: if-eq v0, v1, :cond_53
    .line 7: iget-object v2, v8, Lb0/g;->b:[J
    .line 9: const/4 v3, 0
    .line 10: if-eqz v0, :cond_40
    .line 12: if-gt v3, v0, :cond_36
    .line 14: add-int v1, v3, v0
    .line 16: ushr-int/lit8 v1, v1, 1
    .line 18: aget-wide v4, v2, v1
    .line 20: sub-long/2addr v4, v9
    .line 21: const-wide/16 v6, 0
    .line 23: cmp-long v4, v4, v6
    .line 25: if-gez v4, :cond_30
    .line 27: add-int/lit8 v3, v1, 1
    .line 29: goto :goto_12
    .line 30: if-lez v4, :cond_35
    .line 32: add-int/lit8 v0, v1, -1
    .line 34: goto :goto_12
    .line 35: return v1
    .line 36: add-int/lit8 v3, v3, 1
    .line 38: neg-int v9, v3
    .line 39: return v9
    .line 40: aget-wide v4, v2, v3
    .line 42: cmp-long v0, v4, v9
    .line 44: if-nez v0, :cond_48
    .line 46: move v1, v3
    .line 47: goto :goto_53
    .line 48: cmp-long v9, v4, v9
    .line 50: if-lez v9, :cond_53
    .line 52: const/4 v1, -2
    .line 53: return v1
.end method

# virtual methods
.method public final b(JLjava/lang/Object;)Lb0/g;
    .registers 18

    .line 0: move-object v0, v14
    .line 1: iget-object v1, v0, Lb0/g;->c:[Ljava/lang/Object;
    .line 3: array-length v2, v1
    .line 4: const/4 v3, 0
    .line 5: move v4, v3
    .line 6: move v5, v4
    .line 7: if-ge v4, v2, :cond_18
    .line 9: aget-object v6, v1, v4
    .line 11: if-eqz v6, :cond_15
    .line 13: add-int/lit8 v5, v5, 1
    .line 15: add-int/lit8 v4, v4, 1
    .line 17: goto :goto_7
    .line 18: add-int/lit8 v2, v5, 1
    .line 20: new-array v4, v2, [J
    .line 22: new-array v6, v2, [Ljava/lang/Object;
    .line 24: const/4 v7, 1
    .line 25: if-le v2, v7, :cond_86
    .line 27: move v7, v3
    .line 28: iget-object v8, v0, Lb0/g;->b:[J
    .line 30: iget v9, v0, Lb0/g;->a:I
    .line 32: if-ge v3, v2, :cond_62
    .line 34: if-ge v7, v9, :cond_62
    .line 36: aget-wide v10, v8, v7
    .line 38: aget-object v12, v1, v7
    .line 40: cmp-long v13, v10, v15
    .line 42: if-lez v13, :cond_51
    .line 44: aput-wide v15, v4, v3
    .line 46: aput-object v17, v6, v3
    .line 48: add-int/lit8 v3, v3, 1
    .line 50: goto :goto_62
    .line 51: if-eqz v12, :cond_59
    .line 53: aput-wide v10, v4, v3
    .line 55: aput-object v12, v6, v3
    .line 57: add-int/lit8 v3, v3, 1
    .line 59: add-int/lit8 v7, v7, 1
    .line 61: goto :goto_28
    .line 62: if-ne v7, v9, :cond_69
    .line 64: aput-wide v15, v4, v5
    .line 66: aput-object v17, v6, v5
    .line 68: goto :goto_90
    .line 69: if-ge v3, v2, :cond_90
    .line 71: aget-wide v9, v8, v7
    .line 73: aget-object v5, v1, v7
    .line 75: if-eqz v5, :cond_83
    .line 77: aput-wide v9, v4, v3
    .line 79: aput-object v5, v6, v3
    .line 81: add-int/lit8 v3, v3, 1
    .line 83: add-int/lit8 v7, v7, 1
    .line 85: goto :goto_69
    .line 86: aput-wide v15, v4, v3
    .line 88: aput-object v17, v6, v3
    .line 90: new-instance v1, Lb0/g;
    .line 92: invoke-direct {v1, v2, v4, v6}, Lb0/g;-><init>(I[J[Ljava/lang/Object;)V
    .line 95: return-object v1
.end method

.class public abstract Ld/d;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/os/Looper;)Landroid/os/Handler;
    .registers 1

    .line 0: invoke-static {v0}, Landroid/os/Handler;->createAsync(Landroid/os/Looper;)Landroid/os/Handler;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

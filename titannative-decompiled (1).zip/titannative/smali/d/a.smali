.class public final synthetic Ld/a;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/concurrent/Executor;

.field public final synthetic i:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Ld/a;->i:I
    .line 5: return-void
.end method

# virtual methods
.method public final execute(Ljava/lang/Runnable;)V
    .registers 3

    .line 0: iget v0, v1, Ld/a;->i:I
    .line 2: invoke-interface {v2}, Ljava/lang/Runnable;->run()V
    .line 5: return-void
.end method

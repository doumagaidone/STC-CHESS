.class public final Ld/c;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/util/concurrent/ThreadFactory;

.field public final a:Ljava/util/concurrent/atomic/AtomicInteger;

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 5: const/4 v1, 0
    .line 6: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    .line 9: iput-object v0, v2, Ld/c;->a:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 11: return-void
.end method

# virtual methods
.method public final newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/Thread;
    .line 2: invoke-direct {v0, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V
    .line 5: new-instance v3, Ljava/lang/StringBuilder;
    .line 7: const-string v1, "arch_disk_io_"
    .line 9: invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 12: iget-object v1, v2, Ld/c;->a:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 14: invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I
    .line 17: move-result v1
    .line 18: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 21: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 24: move-result-object v3
    .line 25: invoke-virtual {v0, v3}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V
    .line 28: return-object v0
.end method

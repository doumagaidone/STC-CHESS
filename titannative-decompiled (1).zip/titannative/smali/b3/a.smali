.class public abstract Lb3/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/lang/Integer;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: const/4 v0, 0
    .line 1: const-string v1, "android.os.Build$VERSION"
    .line 3: invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    .line 6: move-result-object v1
    .line 7: const-string v2, "SDK_INT"
    .line 9: invoke-virtual {v1, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    .line 12: move-result-object v1
    .line 13: invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 16: move-result-object v1
    .line 17: instance-of v2, v1, Ljava/lang/Integer;
    .line 19: if-eqz v2, :cond_24
    .line 21: check-cast v1, Ljava/lang/Integer;
    .line 23: goto :goto_25
    .line 24: move-object v1, v0
    .line 25: if-eqz v1, :cond_34
    .line 27: invoke-virtual {v1}, Ljava/lang/Number;->intValue()I
    .line 30: move-result v2
    .line 31: if-lez v2, :cond_34
    .line 33: move-object v0, v1
    .line 34: sput-object v0, Lb3/a;->a:Ljava/lang/Integer;
    .line 36: return-void
.end method

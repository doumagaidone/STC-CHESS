.class public final Lg/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F

# direct methods
.method public constructor <init>(FF)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lg/a;->a:F
    .line 5: iput v2, v0, Lg/a;->b:F
    .line 7: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lg/a;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lg/a;
    .line 12: iget v1, v5, Lg/a;->a:F
    .line 14: iget v3, v4, Lg/a;->a:F
    .line 16: invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lg/a;->b:F
    .line 25: iget v5, v5, Lg/a;->b:F
    .line 27: invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I
    .line 30: move-result v5
    .line 31: if-eqz v5, :cond_34
    .line 33: return v2
    .line 34: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget v0, v2, Lg/a;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget v1, v2, Lg/a;->b:F
    .line 10: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "FlingResult(distanceCoefficient="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Lg/a;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", velocityCoefficient="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v3, Lg/a;->b:F
    .line 19: const/16 v2, 41
    .line 21: invoke-static {v0, v1, v2}, Lai/onnxruntime/b;->i(Ljava/lang/StringBuilder;FC)Ljava/lang/String;
    .line 24: move-result-object v0
    .line 25: return-object v0
.end method

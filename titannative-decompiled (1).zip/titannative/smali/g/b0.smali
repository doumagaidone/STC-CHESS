.class public final Lg/b0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F
.field public final c:J

# direct methods
.method public constructor <init>(FFJ)V
    .registers 5

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lg/b0;->a:F
    .line 5: iput v2, v0, Lg/b0;->b:F
    .line 7: iput-wide v3, v0, Lg/b0;->c:J
    .line 9: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lg/b0;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lg/b0;
    .line 12: iget v1, v8, Lg/b0;->a:F
    .line 14: iget v3, v7, Lg/b0;->a:F
    .line 16: invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v7, Lg/b0;->b:F
    .line 25: iget v3, v8, Lg/b0;->b:F
    .line 27: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 30: move-result v1
    .line 31: if-eqz v1, :cond_34
    .line 33: return v2
    .line 34: iget-wide v3, v7, Lg/b0;->c:J
    .line 36: iget-wide v5, v8, Lg/b0;->c:J
    .line 38: cmp-long v8, v3, v5
    .line 40: if-eqz v8, :cond_43
    .line 42: return v2
    .line 43: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget v0, v3, Lg/b0;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lg/b0;->b:F
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 14: move-result v0
    .line 15: iget-wide v1, v3, Lg/b0;->c:J
    .line 17: invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I
    .line 20: move-result v1
    .line 21: add-int/2addr v1, v0
    .line 22: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "FlingInfo(initialVelocity="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Lg/b0;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", distance="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v3, Lg/b0;->b:F
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", duration="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-wide v1, v3, Lg/b0;->c:J
    .line 29: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 32: const/16 v1, 41
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 40: move-result-object v0
    .line 41: return-object v0
.end method

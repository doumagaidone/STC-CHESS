.class public abstract Lg/l0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:F

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: invoke-static {}, Landroid/view/ViewConfiguration;->getScrollFriction()F
    .line 3: move-result v0
    .line 4: sput v0, Lg/l0;->a:F
    .line 6: return-void
.end method

.class public abstract Lg/f0;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method static constructor <clinit>()V
    .registers 0

    .line 0: return-void
.end method

# direct methods
.method public static final a(JLh/p1;Lu/l;)Lu/i3;
    .registers 14

    .line 0: check-cast v13, Lu/b0;
    .line 2: const v0, 0xe510911c
    .line 5: invoke-virtual {v13, v0}, Lu/b0;->d0(I)V
    .line 8: const-string v4, "ColorAnimation"
    .line 10: const/4 v5, 0
    .line 11: invoke-static {v10, v11}, Lk0/q;->g(J)Ll0/d;
    .line 14: move-result-object v0
    .line 15: const v1, 0x44faf204
    .line 18: invoke-virtual {v13, v1}, Lu/b0;->d0(I)V
    .line 21: invoke-virtual {v13, v0}, Lu/b0;->f(Ljava/lang/Object;)Z
    .line 24: move-result v0
    .line 25: invoke-virtual {v13}, Lu/b0;->I()Ljava/lang/Object;
    .line 28: move-result-object v1
    .line 29: if-nez v0, :cond_35
    .line 31: sget-object v0, Lu/k;->i:Landroidx/activity/b;
    .line 33: if-ne v1, v0, :cond_51
    .line 35: sget-object v0, Lg/j;->m:Lg/j;
    .line 37: invoke-static {v10, v11}, Lk0/q;->g(J)Ll0/d;
    .line 40: move-result-object v1
    .line 41: invoke-virtual {v0, v1}, Lg/j;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 44: move-result-object v0
    .line 45: move-object v1, v0
    .line 46: check-cast v1, Lh/q1;
    .line 48: invoke-virtual {v13, v1}, Lu/b0;->p0(Ljava/lang/Object;)V
    .line 51: const/4 v9, 0
    .line 52: invoke-virtual {v13, v9}, Lu/b0;->t(Z)V
    .line 55: check-cast v1, Lh/q1;
    .line 57: new-instance v0, Lk0/q;
    .line 59: invoke-direct {v0, v10, v11}, Lk0/q;-><init>(J)V
    .line 62: const/4 v3, 0
    .line 63: const/16 v7, 576
    .line 65: const/16 v8, 8
    .line 67: move-object v2, v12
    .line 68: move-object v6, v13
    .line 69: invoke-static/range {v0 .. v8}, Lh/h;->a(Ljava/lang/Object;Lh/q1;Lh/m;Ljava/lang/Float;Ljava/lang/String;Ld3/c;Lu/l;II)Lu/i3;
    .line 72: move-result-object v10
    .line 73: invoke-virtual {v13, v9}, Lu/b0;->t(Z)V
    .line 76: return-object v10
.end method

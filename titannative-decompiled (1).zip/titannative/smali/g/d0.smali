.class public abstract Lg/d0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:F

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: const-wide v0, 0x3fe8f5c28f5c28f6
    .line 5: invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D
    .line 8: move-result-wide v0
    .line 9: const-wide v2, 0x3feccccccccccccd
    .line 14: invoke-static {v2, v3}, Ljava/lang/Math;->log(D)D
    .line 17: move-result-wide v2
    .line 18: div-double/2addr v0, v2
    .line 19: double-to-float v0, v0
    .line 20: sput v0, Lg/d0;->a:F
    .line 22: return-void
.end method

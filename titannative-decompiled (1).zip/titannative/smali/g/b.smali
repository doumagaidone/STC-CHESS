.class public abstract Lg/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:[F

# direct methods
.method static constructor <clinit>()V
    .registers 20

    .line 0: const/16 v0, 101
    .line 2: new-array v1, v0, [F
    .line 4: sput-object v1, Lg/b;->a:[F
    .line 6: new-array v0, v0, [F
    .line 8: const/4 v2, 0
    .line 9: const/4 v3, 0
    .line 10: move v4, v3
    .line 11: move v3, v2
    .line 12: const/16 v5, 100
    .line 14: const/high16 v6, 0x3f80
    .line 16: if-ge v4, v5, :cond_146
    .line 18: int-to-float v7, v4
    .line 19: int-to-float v5, v5
    .line 20: div-float/2addr v7, v5
    .line 21: move v5, v6
    .line 22: sub-float v8, v5, v2
    .line 24: const/high16 v9, 0x4000
    .line 26: div-float/2addr v8, v9
    .line 27: add-float/2addr v8, v2
    .line 28: const/high16 v10, 0x4040
    .line 30: mul-float v11, v8, v10
    .line 32: sub-float v12, v6, v8
    .line 34: mul-float/2addr v11, v12
    .line 35: const v13, 0x3e333333
    .line 38: mul-float v14, v12, v13
    .line 40: const v15, 0x3eb33334
    .line 43: mul-float v16, v8, v15
    .line 45: add-float v16, v16, v14
    .line 47: mul-float v16, v16, v11
    .line 49: mul-float v14, v8, v8
    .line 51: mul-float/2addr v14, v8
    .line 52: add-float v16, v16, v14
    .line 54: sub-float v17, v16, v7
    .line 56: invoke-static/range {v17 .. v17}, Ljava/lang/Math;->abs(F)F
    .line 59: move-result v15
    .line 60: float-to-double v9, v15
    .line 61: const-wide v18, 0x3ee4f8b588e368f1
    .line 66: cmpg-double v9, v9, v18
    .line 68: if-ltz v9, :cond_78
    .line 70: cmpl-float v9, v16, v7
    .line 72: if-lez v9, :cond_76
    .line 74: move v5, v8
    .line 75: goto :goto_22
    .line 76: move v2, v8
    .line 77: goto :goto_22
    .line 78: const/high16 v5, 0x3f00
    .line 80: mul-float/2addr v12, v5
    .line 81: add-float/2addr v12, v8
    .line 82: mul-float/2addr v12, v11
    .line 83: add-float/2addr v12, v14
    .line 84: aput v12, v1, v4
    .line 86: move v8, v6
    .line 87: sub-float v9, v8, v3
    .line 89: const/high16 v10, 0x4000
    .line 91: div-float/2addr v9, v10
    .line 92: add-float/2addr v9, v3
    .line 93: const/high16 v11, 0x4040
    .line 95: mul-float v12, v9, v11
    .line 97: sub-float v14, v6, v9
    .line 99: mul-float/2addr v12, v14
    .line 100: mul-float v15, v14, v5
    .line 102: add-float/2addr v15, v9
    .line 103: mul-float/2addr v15, v12
    .line 104: mul-float v16, v9, v9
    .line 106: mul-float v16, v16, v9
    .line 108: add-float v15, v15, v16
    .line 110: sub-float v17, v15, v7
    .line 112: invoke-static/range {v17 .. v17}, Ljava/lang/Math;->abs(F)F
    .line 115: move-result v5
    .line 116: float-to-double v10, v5
    .line 117: cmpg-double v5, v10, v18
    .line 119: if-ltz v5, :cond_131
    .line 121: cmpl-float v5, v15, v7
    .line 123: if-lez v5, :cond_129
    .line 125: move v8, v9
    .line 126: const/high16 v5, 0x3f00
    .line 128: goto :goto_87
    .line 129: move v3, v9
    .line 130: goto :goto_126
    .line 131: mul-float/2addr v14, v13
    .line 132: const v5, 0x3eb33334
    .line 135: mul-float/2addr v9, v5
    .line 136: add-float/2addr v9, v14
    .line 137: mul-float/2addr v9, v12
    .line 138: add-float v9, v9, v16
    .line 140: aput v9, v0, v4
    .line 142: add-int/lit8 v4, v4, 1
    .line 144: goto/16 :goto_12
    .line 146: aput v6, v0, v5
    .line 148: aput v6, v1, v5
    .line 150: return-void
.end method

# direct methods
.method public static a(F)Lg/a;
    .registers 6

    .line 0: const/16 v0, 100
    .line 2: int-to-float v1, v0
    .line 3: mul-float v2, v1, v5
    .line 5: float-to-int v2, v2
    .line 6: if-ge v2, v0, :cond_27
    .line 8: int-to-float v0, v2
    .line 9: div-float/2addr v0, v1
    .line 10: add-int/lit8 v3, v2, 1
    .line 12: int-to-float v4, v3
    .line 13: div-float/2addr v4, v1
    .line 14: sget-object v1, Lg/b;->a:[F
    .line 16: aget v2, v1, v2
    .line 18: aget v1, v1, v3
    .line 20: sub-float/2addr v1, v2
    .line 21: sub-float/2addr v4, v0
    .line 22: div-float/2addr v1, v4
    .line 23: sub-float/2addr v5, v0
    .line 24: mul-float/2addr v5, v1
    .line 25: add-float/2addr v5, v2
    .line 26: goto :goto_30
    .line 27: const/high16 v5, 0x3f80
    .line 29: const/4 v1, 0
    .line 30: new-instance v0, Lg/a;
    .line 32: invoke-direct {v0, v5, v1}, Lg/a;-><init>(FF)V
    .line 35: return-object v0
.end method

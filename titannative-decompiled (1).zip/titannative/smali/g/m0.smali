.class public final Lg/m0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lg/a0;
.field public final b:Lg/g0;
.field public final c:Lg/m;

# direct methods
.method public constructor <init>(Lg/a0;Lg/g0;Lg/m;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lg/m0;->a:Lg/a0;
    .line 5: iput-object v2, v0, Lg/m0;->b:Lg/g0;
    .line 7: iput-object v3, v0, Lg/m0;->c:Lg/m;
    .line 9: return-void
.end method

# direct methods
.method public synthetic constructor <init>(Lg/a0;Lg/g0;Lg/m;I)V
    .registers 7

    .line 0: and-int/lit8 v0, v6, 1
    .line 2: const/4 v1, 0
    .line 3: if-eqz v0, :cond_6
    .line 5: move-object v3, v1
    .line 6: and-int/lit8 v0, v6, 2
    .line 8: if-eqz v0, :cond_11
    .line 10: move-object v4, v1
    .line 11: and-int/lit8 v6, v6, 4
    .line 13: if-eqz v6, :cond_16
    .line 15: move-object v5, v1
    .line 16: invoke-direct {v2, v3, v4, v5}, Lg/m0;-><init>(Lg/a0;Lg/g0;Lg/m;)V
    .line 19: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lg/m0;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lg/m0;
    .line 12: iget-object v1, v5, Lg/m0;->a:Lg/a0;
    .line 14: iget-object v3, v4, Lg/m0;->a:Lg/a0;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Lg/m0;->b:Lg/g0;
    .line 25: iget-object v3, v5, Lg/m0;->b:Lg/g0;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Lg/m0;->c:Lg/m;
    .line 36: iget-object v5, v5, Lg/m0;->c:Lg/m;
    .line 38: invoke-static {v1, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v5
    .line 42: if-nez v5, :cond_45
    .line 44: return v2
    .line 45: const/4 v5, 0
    .line 46: invoke-static {v5, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 49: move-result v5
    .line 50: if-nez v5, :cond_53
    .line 52: return v2
    .line 53: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: const/4 v0, 0
    .line 1: iget-object v1, v3, Lg/m0;->a:Lg/a0;
    .line 3: if-nez v1, :cond_7
    .line 5: move v1, v0
    .line 6: goto :goto_11
    .line 7: invoke-virtual {v1}, Lg/a0;->hashCode()I
    .line 10: move-result v1
    .line 11: mul-int/lit8 v1, v1, 31
    .line 13: iget-object v2, v3, Lg/m0;->b:Lg/g0;
    .line 15: if-nez v2, :cond_19
    .line 17: move v2, v0
    .line 18: goto :goto_23
    .line 19: invoke-virtual {v2}, Lg/g0;->hashCode()I
    .line 22: move-result v2
    .line 23: add-int/2addr v1, v2
    .line 24: mul-int/lit8 v1, v1, 31
    .line 26: iget-object v2, v3, Lg/m0;->c:Lg/m;
    .line 28: if-nez v2, :cond_31
    .line 30: goto :goto_35
    .line 31: invoke-virtual {v2}, Lg/m;->hashCode()I
    .line 34: move-result v0
    .line 35: add-int/2addr v1, v0
    .line 36: mul-int/lit8 v1, v1, 31
    .line 38: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "TransitionData(fade="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lg/m0;->a:Lg/a0;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", slide="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Lg/m0;->b:Lg/g0;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", changeSize="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Lg/m0;->c:Lg/m;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", scale=null)"
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 40: move-result-object v0
    .line 41: return-object v0
.end method

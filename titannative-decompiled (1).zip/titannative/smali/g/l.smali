.class public final Lg/l;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lu/s1;

# direct methods
.method public constructor <init>(Lh/n1;)V
    .registers 4

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v3, Lr1/i;
    .line 5: const-wide/16 v0, 0
    .line 7: invoke-direct {v3, v0, v1}, Lr1/i;-><init>(J)V
    .line 10: sget-object v0, Lu/l3;->a:Lu/l3;
    .line 12: invoke-static {v3, v0}, Le3/g;->w(Ljava/lang/Object;Lu/f3;)Lu/s1;
    .line 15: move-result-object v3
    .line 16: iput-object v3, v2, Lg/l;->a:Lu/s1;
    .line 18: return-void
.end method

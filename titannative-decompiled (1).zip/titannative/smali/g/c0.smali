.class public final Lg/c0;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F

# direct methods
.method public constructor <init>(FLr1/b;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lg/c0;->a:F
    .line 5: invoke-interface {v2}, Lr1/b;->getDensity()F
    .line 8: move-result v1
    .line 9: sget v2, Lg/d0;->a:F
    .line 11: const v2, 0x43c10b3d
    .line 14: mul-float/2addr v1, v2
    .line 15: const/high16 v2, 0x4320
    .line 17: mul-float/2addr v1, v2
    .line 18: const v2, 0x3f570a3d
    .line 21: mul-float/2addr v1, v2
    .line 22: iput v1, v0, Lg/c0;->b:F
    .line 24: return-void
.end method

# virtual methods
.method public final a(F)Lg/b0;
    .registers 11

    .line 0: invoke-virtual {v9, v10}, Lg/c0;->b(F)D
    .line 3: move-result-wide v0
    .line 4: sget v2, Lg/d0;->a:F
    .line 6: float-to-double v2, v2
    .line 7: const-wide/high16 v4, 0x3ff0
    .line 9: sub-double v4, v2, v4
    .line 11: new-instance v6, Lg/b0;
    .line 13: iget v7, v9, Lg/c0;->a:F
    .line 15: iget v8, v9, Lg/c0;->b:F
    .line 17: mul-float/2addr v7, v8
    .line 18: float-to-double v7, v7
    .line 19: div-double/2addr v2, v4
    .line 20: mul-double/2addr v2, v0
    .line 21: invoke-static {v2, v3}, Ljava/lang/Math;->exp(D)D
    .line 24: move-result-wide v2
    .line 25: mul-double/2addr v2, v7
    .line 26: double-to-float v2, v2
    .line 27: div-double/2addr v0, v4
    .line 28: invoke-static {v0, v1}, Ljava/lang/Math;->exp(D)D
    .line 31: move-result-wide v0
    .line 32: const-wide v3, 0x408f400000
    .line 37: mul-double/2addr v0, v3
    .line 38: double-to-long v0, v0
    .line 39: invoke-direct {v6, v10, v2, v0, v1}, Lg/b0;-><init>(FFJ)V
    .line 42: return-object v6
.end method

# virtual methods
.method public final b(F)D
    .registers 7

    .line 0: sget-object v0, Lg/b;->a:[F
    .line 2: iget v0, v5, Lg/c0;->a:F
    .line 4: iget v1, v5, Lg/c0;->b:F
    .line 6: mul-float/2addr v0, v1
    .line 7: const v1, 0x3eb33333
    .line 10: invoke-static {v6}, Ljava/lang/Math;->abs(F)F
    .line 13: move-result v6
    .line 14: mul-float/2addr v6, v1
    .line 15: float-to-double v1, v6
    .line 16: float-to-double v3, v0
    .line 17: div-double/2addr v1, v3
    .line 18: invoke-static {v1, v2}, Ljava/lang/Math;->log(D)D
    .line 21: move-result-wide v0
    .line 22: return-wide v0
.end method

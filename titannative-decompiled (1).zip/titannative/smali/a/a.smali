.class public abstract La/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Landroid/view/ViewGroup$LayoutParams;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Landroid/view/ViewGroup$LayoutParams;
    .line 2: const/4 v1, -2
    .line 3: invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V
    .line 6: sput-object v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 8: return-void
.end method

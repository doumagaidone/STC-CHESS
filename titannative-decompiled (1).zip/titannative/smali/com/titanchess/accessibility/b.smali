.class public final Lcom/titanchess/accessibility/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F
.field public final c:F
.field public final d:F
.field public final e:I
.field public final f:F
.field public final g:F
.field public final h:Z

# direct methods
.method public constructor <init>(FFFFIFFZ)V
    .registers 9

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lcom/titanchess/accessibility/b;->a:F
    .line 5: iput v2, v0, Lcom/titanchess/accessibility/b;->b:F
    .line 7: iput v3, v0, Lcom/titanchess/accessibility/b;->c:F
    .line 9: iput v4, v0, Lcom/titanchess/accessibility/b;->d:F
    .line 11: iput v5, v0, Lcom/titanchess/accessibility/b;->e:I
    .line 13: iput v6, v0, Lcom/titanchess/accessibility/b;->f:F
    .line 15: iput v7, v0, Lcom/titanchess/accessibility/b;->g:F
    .line 17: iput-boolean v8, v0, Lcom/titanchess/accessibility/b;->h:Z
    .line 19: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/b;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/b;
    .line 12: iget v1, v5, Lcom/titanchess/accessibility/b;->a:F
    .line 14: iget v3, v4, Lcom/titanchess/accessibility/b;->a:F
    .line 16: invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lcom/titanchess/accessibility/b;->b:F
    .line 25: iget v3, v5, Lcom/titanchess/accessibility/b;->b:F
    .line 27: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 30: move-result v1
    .line 31: if-eqz v1, :cond_34
    .line 33: return v2
    .line 34: iget v1, v4, Lcom/titanchess/accessibility/b;->c:F
    .line 36: iget v3, v5, Lcom/titanchess/accessibility/b;->c:F
    .line 38: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 41: move-result v1
    .line 42: if-eqz v1, :cond_45
    .line 44: return v2
    .line 45: iget v1, v4, Lcom/titanchess/accessibility/b;->d:F
    .line 47: iget v3, v5, Lcom/titanchess/accessibility/b;->d:F
    .line 49: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 52: move-result v1
    .line 53: if-eqz v1, :cond_56
    .line 55: return v2
    .line 56: iget v1, v4, Lcom/titanchess/accessibility/b;->e:I
    .line 58: iget v3, v5, Lcom/titanchess/accessibility/b;->e:I
    .line 60: if-eq v1, v3, :cond_63
    .line 62: return v2
    .line 63: iget v1, v4, Lcom/titanchess/accessibility/b;->f:F
    .line 65: iget v3, v5, Lcom/titanchess/accessibility/b;->f:F
    .line 67: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 70: move-result v1
    .line 71: if-eqz v1, :cond_74
    .line 73: return v2
    .line 74: iget v1, v4, Lcom/titanchess/accessibility/b;->g:F
    .line 76: iget v3, v5, Lcom/titanchess/accessibility/b;->g:F
    .line 78: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 81: move-result v1
    .line 82: if-eqz v1, :cond_85
    .line 84: return v2
    .line 85: iget-boolean v1, v4, Lcom/titanchess/accessibility/b;->h:Z
    .line 87: iget-boolean v5, v5, Lcom/titanchess/accessibility/b;->h:Z
    .line 89: if-eq v1, v5, :cond_92
    .line 91: return v2
    .line 92: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget v0, v3, Lcom/titanchess/accessibility/b;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lcom/titanchess/accessibility/b;->b:F
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 14: move-result v0
    .line 15: iget v2, v3, Lcom/titanchess/accessibility/b;->c:F
    .line 17: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 20: move-result v0
    .line 21: iget v2, v3, Lcom/titanchess/accessibility/b;->d:F
    .line 23: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 26: move-result v0
    .line 27: iget v2, v3, Lcom/titanchess/accessibility/b;->e:I
    .line 29: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 32: move-result v0
    .line 33: iget v2, v3, Lcom/titanchess/accessibility/b;->f:F
    .line 35: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 38: move-result v0
    .line 39: iget v2, v3, Lcom/titanchess/accessibility/b;->g:F
    .line 41: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 44: move-result v0
    .line 45: iget-boolean v1, v3, Lcom/titanchess/accessibility/b;->h:Z
    .line 47: if-eqz v1, :cond_50
    .line 49: const/4 v1, 1
    .line 50: add-int/2addr v0, v1
    .line 51: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Arrow(fx="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v2, Lcom/titanchess/accessibility/b;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", fy="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lcom/titanchess/accessibility/b;->b:F
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", tx="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v2, Lcom/titanchess/accessibility/b;->c:F
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", ty="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v2, Lcom/titanchess/accessibility/b;->d:F
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", rank="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget v1, v2, Lcom/titanchess/accessibility/b;->e:I
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", prob="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget v1, v2, Lcom/titanchess/accessibility/b;->f:F
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ", sqPx="
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget v1, v2, Lcom/titanchess/accessibility/b;->g:F
    .line 69: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 72: const-string v1, ", single="
    .line 74: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: iget-boolean v1, v2, Lcom/titanchess/accessibility/b;->h:Z
    .line 79: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 82: const-string v1, ")"
    .line 84: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 87: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 90: move-result-object v0
    .line 91: return-object v0
.end method

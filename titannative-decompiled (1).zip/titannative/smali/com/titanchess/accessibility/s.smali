.class public final Lcom/titanchess/accessibility/s;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroid/content/Context;
.field public final b:Landroid/view/WindowManager;
.field public final c:Landroid/content/SharedPreferences;
.field public final d:Landroid/util/DisplayMetrics;
.field public e:Landroid/widget/FrameLayout;
.field public f:Landroid/view/WindowManager$LayoutParams;
.field public g:Z
.field public final h:F
.field public i:Z
.field public j:Landroid/widget/TextView;
.field public final k:Lcom/titanchess/accessibility/l;
.field public final l:I
.field public final m:I
.field public final n:I
.field public final o:I
.field public final p:I
.field public final q:I
.field public final r:I
.field public final s:Ls2/h;
.field public final t:Ls2/h;

# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 5

    .line 0: const-string v0, "ctx"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v4, v3, Lcom/titanchess/accessibility/s;->a:Landroid/content/Context;
    .line 10: const-string v0, "window"
    .line 12: invoke-virtual {v4, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    .line 15: move-result-object v0
    .line 16: const-string v1, "null cannot be cast to non-null type android.view.WindowManager"
    .line 18: invoke-static {v0, v1}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 21: check-cast v0, Landroid/view/WindowManager;
    .line 23: iput-object v0, v3, Lcom/titanchess/accessibility/s;->b:Landroid/view/WindowManager;
    .line 25: const-string v0, "titan"
    .line 27: const/4 v1, 0
    .line 28: invoke-virtual {v4, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 31: move-result-object v0
    .line 32: iput-object v0, v3, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 34: invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    .line 37: move-result-object v4
    .line 38: invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    .line 41: move-result-object v4
    .line 42: iput-object v4, v3, Lcom/titanchess/accessibility/s;->d:Landroid/util/DisplayMetrics;
    .line 44: const-string v4, "float_expanded"
    .line 46: invoke-interface {v0, v4, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 49: move-result v4
    .line 50: iput-boolean v4, v3, Lcom/titanchess/accessibility/s;->g:Z
    .line 52: const-string v4, "float_scale"
    .line 54: const v2, 0x3f51eb85
    .line 57: invoke-interface {v0, v4, v2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F
    .line 60: move-result v4
    .line 61: iput v4, v3, Lcom/titanchess/accessibility/s;->h:F
    .line 63: new-instance v4, Lcom/titanchess/accessibility/l;
    .line 65: invoke-direct {v4, v1, v3}, Lcom/titanchess/accessibility/l;-><init>(ILjava/lang/Object;)V
    .line 68: iput-object v4, v3, Lcom/titanchess/accessibility/s;->k:Lcom/titanchess/accessibility/l;
    .line 70: const v4, 0xfcfdf6e6
    .line 73: iput v4, v3, Lcom/titanchess/accessibility/s;->l:I
    .line 75: const v4, 0xff2a2438
    .line 78: iput v4, v3, Lcom/titanchess/accessibility/s;->m:I
    .line 80: const v4, 0xff6b6478
    .line 83: iput v4, v3, Lcom/titanchess/accessibility/s;->n:I
    .line 85: const v4, 0xffff4d9d
    .line 88: iput v4, v3, Lcom/titanchess/accessibility/s;->o:I
    .line 90: const/16 v4, -16338
    .line 92: iput v4, v3, Lcom/titanchess/accessibility/s;->p:I
    .line 94: const v4, 0x22ff4d9d
    .line 97: iput v4, v3, Lcom/titanchess/accessibility/s;->q:I
    .line 99: const v4, 0x33ffc02e
    .line 102: iput v4, v3, Lcom/titanchess/accessibility/s;->r:I
    .line 104: new-instance v4, Lcom/titanchess/accessibility/p;
    .line 106: const/4 v0, 2
    .line 107: invoke-direct {v4, v3, v0}, Lcom/titanchess/accessibility/p;-><init>(Lcom/titanchess/accessibility/s;I)V
    .line 110: new-instance v0, Ls2/h;
    .line 112: invoke-direct {v0, v4}, Ls2/h;-><init>(Ld3/a;)V
    .line 115: iput-object v0, v3, Lcom/titanchess/accessibility/s;->s:Ls2/h;
    .line 117: new-instance v4, Lcom/titanchess/accessibility/p;
    .line 119: const/4 v0, 3
    .line 120: invoke-direct {v4, v3, v0}, Lcom/titanchess/accessibility/p;-><init>(Lcom/titanchess/accessibility/s;I)V
    .line 123: new-instance v0, Ls2/h;
    .line 125: invoke-direct {v0, v4}, Ls2/h;-><init>(Ld3/a;)V
    .line 128: iput-object v0, v3, Lcom/titanchess/accessibility/s;->t:Ls2/h;
    .line 130: return-void
.end method

# direct methods
.method public static final a(ILandroid/widget/TextView;Lcom/titanchess/accessibility/s;)V
    .registers 6

    .line 0: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: sget-object v0, Lcom/titanchess/accessibility/MainActivity;->Companion:Lcom/titanchess/accessibility/a0;
    .line 5: const-string v1, "A"
    .line 7: const-string v2, "model"
    .line 9: iget-object v5, v5, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 11: invoke-interface {v5, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 14: move-result-object v1
    .line 15: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 18: invoke-static {v1}, Lcom/titanchess/accessibility/a0;->a(Ljava/lang/String;)Ls2/e;
    .line 21: move-result-object v0
    .line 22: iget-object v1, v0, Ls2/e;->i:Ljava/lang/Object;
    .line 24: check-cast v1, Ljava/lang/Number;
    .line 26: invoke-virtual {v1}, Ljava/lang/Number;->intValue()I
    .line 29: move-result v1
    .line 30: iget-object v0, v0, Ls2/e;->j:Ljava/lang/Object;
    .line 32: check-cast v0, Ljava/lang/Number;
    .line 34: invoke-virtual {v0}, Ljava/lang/Number;->intValue()I
    .line 37: move-result v0
    .line 38: invoke-static {v3, v1, v0}, Ld2/b;->G(III)I
    .line 41: move-result v3
    .line 42: invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 45: move-result-object v5
    .line 46: const-string v0, "elo"
    .line 48: invoke-interface {v5, v0, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    .line 51: move-result-object v5
    .line 52: invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 55: invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 58: move-result-object v3
    .line 59: invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 62: return-void
.end method

# virtual methods
.method public final b(Landroid/view/View;Ld3/a;Ld3/a;)V
    .registers 15

    .line 0: new-instance v1, Le3/p;
    .line 2: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 5: new-instance v2, Le3/p;
    .line 7: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 10: new-instance v3, Le3/q;
    .line 12: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 15: new-instance v5, Le3/q;
    .line 17: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 20: new-instance v6, Le3/o;
    .line 22: invoke-direct {v6}, Ljava/lang/Object;-><init>()V
    .line 25: new-instance v7, Le3/o;
    .line 27: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 30: new-instance v9, Landroidx/emoji2/text/l;
    .line 32: const/4 v0, 1
    .line 33: invoke-direct {v9, v6, v7, v14, v0}, Landroidx/emoji2/text/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .line 36: new-instance v14, Lcom/titanchess/accessibility/n;
    .line 38: move-object v0, v14
    .line 39: move-object v4, v11
    .line 40: move-object v8, v12
    .line 41: move-object v10, v13
    .line 42: invoke-direct/range {v0 .. v10}, Lcom/titanchess/accessibility/n;-><init>(Le3/p;Le3/p;Le3/q;Lcom/titanchess/accessibility/s;Le3/q;Le3/o;Le3/o;Landroid/view/View;Landroidx/emoji2/text/l;Ld3/a;)V
    .line 45: invoke-virtual {v12, v14}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V
    .line 48: return-void
.end method

# virtual methods
.method public final c(F)I
    .registers 3

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/s;->d:Landroid/util/DisplayMetrics;
    .line 2: iget v0, v0, Landroid/util/DisplayMetrics;->density:F
    .line 4: mul-float/2addr v2, v0
    .line 5: iget v0, v1, Lcom/titanchess/accessibility/s;->h:F
    .line 7: mul-float/2addr v2, v0
    .line 8: invoke-static {v2}, Ld2/b;->a1(F)I
    .line 11: move-result v2
    .line 12: return v2
.end method

# virtual methods
.method public final d()V
    .registers 3

    .line 0: iget-object v0, v2, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 2: if-eqz v0, :cond_14
    .line 4: iget-object v1, v2, Lcom/titanchess/accessibility/s;->b:Landroid/view/WindowManager;
    .line 6: invoke-interface {v1, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    .line 9: goto :goto_14
    .line 10: move-exception v0
    .line 11: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 14: const/4 v0, 0
    .line 15: iput-object v0, v2, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 17: iput-object v0, v2, Lcom/titanchess/accessibility/s;->j:Landroid/widget/TextView;
    .line 19: iget-boolean v0, v2, Lcom/titanchess/accessibility/s;->i:Z
    .line 21: if-eqz v0, :cond_30
    .line 23: iget-object v0, v2, Lcom/titanchess/accessibility/s;->k:Lcom/titanchess/accessibility/l;
    .line 25: iget-object v1, v2, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 27: invoke-interface {v1, v0}, Landroid/content/SharedPreferences;->unregisterOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V
    .line 30: const/4 v0, 0
    .line 31: iput-boolean v0, v2, Lcom/titanchess/accessibility/s;->i:Z
    .line 33: return-void
.end method

# virtual methods
.method public final e(Ljava/lang/String;)Landroid/widget/TextView;
    .registers 5

    .line 0: new-instance v0, Landroid/widget/TextView;
    .line 2: iget-object v1, v3, Lcom/titanchess/accessibility/s;->a:Landroid/content/Context;
    .line 4: invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    .line 7: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 10: iget v4, v3, Lcom/titanchess/accessibility/s;->n:I
    .line 12: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextColor(I)V
    .line 15: iget v4, v3, Lcom/titanchess/accessibility/s;->h:F
    .line 17: const/high16 v1, 0x4110
    .line 19: mul-float/2addr v4, v1
    .line 20: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextSize(F)V
    .line 23: iget-object v4, v3, Lcom/titanchess/accessibility/s;->t:Ls2/h;
    .line 25: invoke-virtual {v4}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 28: move-result-object v4
    .line 29: check-cast v4, Landroid/graphics/Typeface;
    .line 31: if-eqz v4, :cond_36
    .line 33: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    .line 36: const v4, 0x3e19999a
    .line 39: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setLetterSpacing(F)V
    .line 42: invoke-virtual {v3, v1}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 45: move-result v4
    .line 46: const/high16 v1, 0x3f80
    .line 48: invoke-virtual {v3, v1}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 51: move-result v1
    .line 52: const/4 v2, 0
    .line 53: invoke-virtual {v0, v2, v4, v2, v1}, Landroid/widget/TextView;->setPadding(IIII)V
    .line 56: return-object v0
.end method

# virtual methods
.method public final f(FII)Landroid/graphics/drawable/GradientDrawable;
    .registers 6

    .line 0: new-instance v0, Landroid/graphics/drawable/GradientDrawable;
    .line 2: invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V
    .line 5: const/4 v1, 0
    .line 6: invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V
    .line 9: invoke-virtual {v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V
    .line 12: invoke-virtual {v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V
    .line 15: const/high16 v3, 0x3f80
    .line 17: iget-object v4, v2, Lcom/titanchess/accessibility/s;->d:Landroid/util/DisplayMetrics;
    .line 19: const/4 v1, 1
    .line 20: invoke-static {v1, v3, v4}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F
    .line 23: move-result v3
    .line 24: invoke-static {v3}, Ld2/b;->a1(F)I
    .line 27: move-result v3
    .line 28: invoke-virtual {v0, v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V
    .line 31: return-object v0
.end method

# virtual methods
.method public final g()V
    .registers 19

    .line 0: move-object/from16 v1, v18
    .line 2: iget-object v0, v1, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 4: if-nez v0, :cond_7
    .line 6: return-void
    .line 7: const/4 v2, 0
    .line 8: iput-object v2, v1, Lcom/titanchess/accessibility/s;->j:Landroid/widget/TextView;
    .line 10: invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V
    .line 13: iget-boolean v3, v1, Lcom/titanchess/accessibility/s;->g:Z
    .line 15: const/4 v4, 1
    .line 16: iget-object v5, v1, Lcom/titanchess/accessibility/s;->a:Landroid/content/Context;
    .line 18: iget-object v6, v1, Lcom/titanchess/accessibility/s;->d:Landroid/util/DisplayMetrics;
    .line 20: const/4 v7, 0
    .line 21: if-eqz v3, :cond_619
    .line 23: new-instance v3, Landroid/widget/LinearLayout;
    .line 25: invoke-direct {v3, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    .line 28: invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V
    .line 31: const/high16 v8, 0x4160
    .line 33: invoke-virtual {v1, v8}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 36: move-result v8
    .line 37: int-to-float v8, v8
    .line 38: new-instance v9, Landroid/graphics/drawable/GradientDrawable;
    .line 40: invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V
    .line 43: invoke-virtual {v9, v7}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V
    .line 46: invoke-virtual {v9, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V
    .line 49: iget v8, v1, Lcom/titanchess/accessibility/s;->l:I
    .line 51: invoke-virtual {v9, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V
    .line 54: const/high16 v8, 0x3f80
    .line 56: invoke-static {v4, v8, v6}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F
    .line 59: move-result v10
    .line 60: invoke-static {v10}, Ld2/b;->a1(F)I
    .line 63: move-result v10
    .line 64: const v11, 0x33ff4d9d
    .line 67: invoke-virtual {v9, v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V
    .line 70: invoke-virtual {v3, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    .line 73: const/high16 v9, 0x4140
    .line 75: invoke-virtual {v1, v9}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 78: move-result v10
    .line 79: const/high16 v11, 0x4120
    .line 81: invoke-virtual {v1, v11}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 84: move-result v11
    .line 85: invoke-virtual {v1, v9}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 88: move-result v12
    .line 89: invoke-virtual {v1, v9}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 92: move-result v9
    .line 93: invoke-virtual {v3, v10, v11, v12, v9}, Landroid/view/View;->setPadding(IIII)V
    .line 96: new-instance v9, Landroid/widget/FrameLayout$LayoutParams;
    .line 98: const/high16 v10, 0x431e
    .line 100: invoke-virtual {v1, v10}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 103: move-result v10
    .line 104: const/4 v11, -2
    .line 105: invoke-direct {v9, v10, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    .line 108: invoke-virtual {v3, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 111: new-instance v9, Landroid/widget/LinearLayout;
    .line 113: invoke-direct {v9, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    .line 116: invoke-virtual {v9, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V
    .line 119: const/16 v10, 16
    .line 121: invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setGravity(I)V
    .line 124: new-instance v12, Landroid/widget/TextView;
    .line 126: invoke-direct {v12, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    .line 129: iget-object v13, v1, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 131: const-string v14, "model"
    .line 133: const-string v15, "A"
    .line 135: invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 138: move-result-object v2
    .line 139: const-string v10, "B"
    .line 141: invoke-static {v2, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 144: move-result v10
    .line 145: if-eqz v10, :cond_150
    .line 147: const-string v2, "MIMIC"
    .line 149: goto :goto_163
    .line 150: const-string v10, "C"
    .line 152: invoke-static {v2, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 155: move-result v2
    .line 156: if-eqz v2, :cond_161
    .line 158: const-string v2, "STOCKFISH"
    .line 160: goto :goto_163
    .line 161: const-string v2, "ORION"
    .line 163: invoke-virtual {v12, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 166: iget v2, v1, Lcom/titanchess/accessibility/s;->m:I
    .line 168: invoke-virtual {v12, v2}, Landroid/widget/TextView;->setTextColor(I)V
    .line 171: iget v10, v1, Lcom/titanchess/accessibility/s;->h:F
    .line 173: const/high16 v16, 0x4150
    .line 175: mul-float v4, v10, v16
    .line 177: invoke-virtual {v12, v4}, Landroid/widget/TextView;->setTextSize(F)V
    .line 180: iget-object v7, v1, Lcom/titanchess/accessibility/s;->s:Ls2/h;
    .line 182: invoke-virtual {v7}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 185: move-result-object v7
    .line 186: check-cast v7, Landroid/graphics/Typeface;
    .line 188: if-eqz v7, :cond_193
    .line 190: invoke-virtual {v12, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    .line 193: const v7, 0x3e6147ae
    .line 196: invoke-virtual {v12, v7}, Landroid/widget/TextView;->setLetterSpacing(F)V
    .line 199: new-instance v7, Landroid/widget/LinearLayout$LayoutParams;
    .line 201: move-object/from16 v17, v6
    .line 203: const/4 v6, 0
    .line 204: invoke-direct {v7, v6, v11, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V
    .line 207: invoke-virtual {v12, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 210: new-instance v6, Landroid/widget/TextView;
    .line 212: invoke-direct {v6, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    .line 215: const-string v7, "✕"
    .line 217: invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 220: const/4 v7, -1
    .line 221: invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V
    .line 224: invoke-virtual {v6, v4}, Landroid/widget/TextView;->setTextSize(F)V
    .line 227: sget-object v11, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;
    .line 229: invoke-virtual {v6, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    .line 232: const/16 v11, 17
    .line 234: invoke-virtual {v6, v11}, Landroid/widget/TextView;->setGravity(I)V
    .line 237: const/high16 v11, 0x41d0
    .line 239: invoke-virtual {v1, v11}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 242: move-result v11
    .line 243: new-instance v7, Landroid/widget/LinearLayout$LayoutParams;
    .line 245: invoke-direct {v7, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V
    .line 248: invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 251: new-instance v7, Landroid/graphics/drawable/GradientDrawable;
    .line 253: invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V
    .line 256: const/4 v11, 1
    .line 257: invoke-virtual {v7, v11}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V
    .line 260: iget v11, v1, Lcom/titanchess/accessibility/s;->o:I
    .line 262: invoke-virtual {v7, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V
    .line 265: invoke-virtual {v6, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    .line 268: new-instance v7, Lcom/titanchess/accessibility/m;
    .line 270: const/4 v8, 0
    .line 271: invoke-direct {v7, v8, v1}, Lcom/titanchess/accessibility/m;-><init>(ILjava/lang/Object;)V
    .line 274: invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    .line 277: invoke-virtual {v9, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 280: invoke-virtual {v9, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 283: sget-object v6, Lcom/titanchess/accessibility/q;->j:Lcom/titanchess/accessibility/q;
    .line 285: sget-object v7, Lcom/titanchess/accessibility/q;->k:Lcom/titanchess/accessibility/q;
    .line 287: invoke-virtual {v1, v9, v6, v7}, Lcom/titanchess/accessibility/s;->b(Landroid/view/View;Ld3/a;Ld3/a;)V
    .line 290: invoke-virtual {v3, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 293: new-instance v6, Landroid/view/View;
    .line 295: invoke-direct {v6, v5}, Landroid/view/View;-><init>(Landroid/content/Context;)V
    .line 298: const v7, 0x1a2a2438
    .line 301: invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V
    .line 304: new-instance v7, Landroid/widget/LinearLayout$LayoutParams;
    .line 306: const/high16 v8, 0x3f80
    .line 308: invoke-virtual {v1, v8}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 311: move-result v9
    .line 312: const/4 v8, -1
    .line 313: invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V
    .line 316: const/high16 v8, 0x40c0
    .line 318: invoke-virtual {v1, v8}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 321: move-result v8
    .line 322: iput v8, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I
    .line 324: invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 327: invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 330: const-string v6, "ELO"
    .line 332: invoke-virtual {v1, v6}, Lcom/titanchess/accessibility/s;->e(Ljava/lang/String;)Landroid/widget/TextView;
    .line 335: move-result-object v6
    .line 336: invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 339: sget-object v6, Lcom/titanchess/accessibility/MainActivity;->Companion:Lcom/titanchess/accessibility/a0;
    .line 341: invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 344: move-result-object v7
    .line 345: invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 348: invoke-static {v7}, Lcom/titanchess/accessibility/a0;->a(Ljava/lang/String;)Ls2/e;
    .line 351: move-result-object v6
    .line 352: iget-object v7, v6, Ls2/e;->i:Ljava/lang/Object;
    .line 354: check-cast v7, Ljava/lang/Number;
    .line 356: invoke-virtual {v7}, Ljava/lang/Number;->intValue()I
    .line 359: move-result v7
    .line 360: iget-object v6, v6, Ls2/e;->j:Ljava/lang/Object;
    .line 362: check-cast v6, Ljava/lang/Number;
    .line 364: invoke-virtual {v6}, Ljava/lang/Number;->intValue()I
    .line 367: move-result v6
    .line 368: const-string v8, "elo"
    .line 370: const/16 v9, 1500
    .line 372: invoke-interface {v13, v8, v9}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 375: move-result v8
    .line 376: invoke-static {v8, v7, v6}, Ld2/b;->G(III)I
    .line 379: move-result v6
    .line 380: new-instance v7, Landroid/widget/TextView;
    .line 382: invoke-direct {v7, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    .line 385: invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 388: move-result-object v6
    .line 389: invoke-virtual {v7, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 392: invoke-virtual {v7, v2}, Landroid/widget/TextView;->setTextColor(I)V
    .line 395: const/high16 v6, 0x4188
    .line 397: mul-float/2addr v10, v6
    .line 398: invoke-virtual {v7, v10}, Landroid/widget/TextView;->setTextSize(F)V
    .line 401: const/16 v6, 17
    .line 403: invoke-virtual {v7, v6}, Landroid/widget/TextView;->setGravity(I)V
    .line 406: iget-object v6, v1, Lcom/titanchess/accessibility/s;->t:Ls2/h;
    .line 408: invoke-virtual {v6}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 411: move-result-object v8
    .line 412: check-cast v8, Landroid/graphics/Typeface;
    .line 414: if-eqz v8, :cond_419
    .line 416: invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    .line 419: const/4 v8, 0
    .line 420: invoke-virtual {v7, v8}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V
    .line 423: new-instance v9, Landroid/widget/LinearLayout$LayoutParams;
    .line 425: const/high16 v10, 0x4218
    .line 427: invoke-virtual {v1, v10}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 430: move-result v10
    .line 431: const/high16 v12, 0x3f80
    .line 433: invoke-direct {v9, v8, v10, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V
    .line 436: invoke-virtual {v7, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 439: iput-object v7, v1, Lcom/titanchess/accessibility/s;->j:Landroid/widget/TextView;
    .line 441: new-instance v9, Landroid/widget/LinearLayout;
    .line 443: invoke-direct {v9, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    .line 446: invoke-virtual {v9, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V
    .line 449: const/16 v10, 16
    .line 451: invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setGravity(I)V
    .line 454: const/high16 v10, 0x4040
    .line 456: invoke-virtual {v1, v10}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 459: move-result v10
    .line 460: invoke-virtual {v9, v8, v10, v8, v8}, Landroid/view/View;->setPadding(IIII)V
    .line 463: new-instance v10, Lcom/titanchess/accessibility/r;
    .line 465: invoke-direct {v10, v8, v7, v1}, Lcom/titanchess/accessibility/r;-><init>(ILandroid/widget/TextView;Lcom/titanchess/accessibility/s;)V
    .line 468: const-string v8, "−"
    .line 470: invoke-virtual {v1, v8, v10}, Lcom/titanchess/accessibility/s;->i(Ljava/lang/String;Lcom/titanchess/accessibility/r;)Landroid/widget/TextView;
    .line 473: move-result-object v8
    .line 474: invoke-virtual {v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 477: invoke-virtual {v9, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 480: new-instance v8, Lcom/titanchess/accessibility/r;
    .line 482: const/4 v10, 1
    .line 483: invoke-direct {v8, v10, v7, v1}, Lcom/titanchess/accessibility/r;-><init>(ILandroid/widget/TextView;Lcom/titanchess/accessibility/s;)V
    .line 486: const-string v7, "+"
    .line 488: invoke-virtual {v1, v7, v8}, Lcom/titanchess/accessibility/s;->i(Ljava/lang/String;Lcom/titanchess/accessibility/r;)Landroid/widget/TextView;
    .line 491: move-result-object v7
    .line 492: invoke-virtual {v9, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 495: invoke-virtual {v3, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 498: const-string v7, "ARROW"
    .line 500: invoke-virtual {v1, v7}, Lcom/titanchess/accessibility/s;->e(Ljava/lang/String;)Landroid/widget/TextView;
    .line 503: move-result-object v7
    .line 504: invoke-virtual {v3, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 507: const-string v7, "arrow_on"
    .line 509: invoke-interface {v13, v7, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 512: move-result v7
    .line 513: new-instance v8, Landroid/widget/TextView;
    .line 515: invoke-direct {v8, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    .line 518: if-eqz v7, :cond_523
    .line 520: const-string v5, "ON"
    .line 522: goto :goto_525
    .line 523: const-string v5, "OFF"
    .line 525: invoke-virtual {v8, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 528: if-eqz v7, :cond_531
    .line 530: goto :goto_532
    .line 531: move v2, v11
    .line 532: invoke-virtual {v8, v2}, Landroid/widget/TextView;->setTextColor(I)V
    .line 535: invoke-virtual {v8, v4}, Landroid/widget/TextView;->setTextSize(F)V
    .line 538: const/16 v2, 17
    .line 540: invoke-virtual {v8, v2}, Landroid/widget/TextView;->setGravity(I)V
    .line 543: invoke-virtual {v6}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 546: move-result-object v2
    .line 547: check-cast v2, Landroid/graphics/Typeface;
    .line 549: if-eqz v2, :cond_554
    .line 551: invoke-virtual {v8, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    .line 554: const/high16 v2, 0x40e0
    .line 556: invoke-virtual {v1, v2}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 559: move-result v4
    .line 560: invoke-virtual {v1, v2}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 563: move-result v2
    .line 564: const/4 v5, 0
    .line 565: invoke-virtual {v8, v5, v4, v5, v2}, Landroid/widget/TextView;->setPadding(IIII)V
    .line 568: const/high16 v2, 0x4110
    .line 570: invoke-virtual {v1, v2}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 573: move-result v2
    .line 574: int-to-float v2, v2
    .line 575: if-eqz v7, :cond_580
    .line 577: iget v4, v1, Lcom/titanchess/accessibility/s;->r:I
    .line 579: goto :goto_582
    .line 580: iget v4, v1, Lcom/titanchess/accessibility/s;->q:I
    .line 582: if-eqz v7, :cond_586
    .line 584: iget v11, v1, Lcom/titanchess/accessibility/s;->p:I
    .line 586: invoke-virtual {v1, v2, v4, v11}, Lcom/titanchess/accessibility/s;->f(FII)Landroid/graphics/drawable/GradientDrawable;
    .line 589: move-result-object v2
    .line 590: invoke-virtual {v8, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    .line 593: new-instance v2, Landroid/widget/LinearLayout$LayoutParams;
    .line 595: const/4 v4, -2
    .line 596: const/4 v5, -1
    .line 597: invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V
    .line 600: invoke-virtual {v8, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 603: new-instance v2, Lcom/titanchess/accessibility/o;
    .line 605: invoke-direct {v2, v1, v8}, Lcom/titanchess/accessibility/o;-><init>(Lcom/titanchess/accessibility/s;Landroid/widget/TextView;)V
    .line 608: invoke-virtual {v8, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    .line 611: invoke-virtual {v3, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 614: invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 617: const/4 v4, 0
    .line 618: goto :goto_664
    .line 619: move-object/from16 v17, v6
    .line 621: const/high16 v2, 0x4238
    .line 623: invoke-virtual {v1, v2}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 626: move-result v2
    .line 627: new-instance v3, Landroid/widget/ImageView;
    .line 629: invoke-direct {v3, v5}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V
    .line 632: const v4, 0x7f040017
    .line 635: invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setImageResource(I)V
    .line 638: new-instance v4, Landroid/widget/FrameLayout$LayoutParams;
    .line 640: invoke-direct {v4, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    .line 643: invoke-virtual {v3, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 646: new-instance v2, Lcom/titanchess/accessibility/p;
    .line 648: const/4 v4, 0
    .line 649: invoke-direct {v2, v1, v4}, Lcom/titanchess/accessibility/p;-><init>(Lcom/titanchess/accessibility/s;I)V
    .line 652: new-instance v5, Lcom/titanchess/accessibility/p;
    .line 654: const/4 v6, 1
    .line 655: invoke-direct {v5, v1, v6}, Lcom/titanchess/accessibility/p;-><init>(Lcom/titanchess/accessibility/s;I)V
    .line 658: invoke-virtual {v1, v3, v2, v5}, Lcom/titanchess/accessibility/s;->b(Landroid/view/View;Ld3/a;Ld3/a;)V
    .line 661: invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    .line 664: invoke-virtual {v0, v4, v4}, Landroid/view/View;->measure(II)V
    .line 667: invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I
    .line 670: move-result v2
    .line 671: const/high16 v3, 0x4230
    .line 673: invoke-virtual {v1, v3}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 676: move-result v4
    .line 677: if-ge v2, v4, :cond_680
    .line 679: move v2, v4
    .line 680: invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I
    .line 683: move-result v4
    .line 684: invoke-virtual {v1, v3}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 687: move-result v3
    .line 688: if-ge v4, v3, :cond_691
    .line 690: move v4, v3
    .line 691: iget-object v3, v1, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 693: const-string v5, "lp"
    .line 695: if-eqz v3, :cond_763
    .line 697: iget v6, v3, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 699: move-object/from16 v7, v17
    .line 701: iget v8, v7, Landroid/util/DisplayMetrics;->widthPixels:I
    .line 703: sub-int v2, v8, v2
    .line 705: if-gez v2, :cond_710
    .line 707: const/4 v2, 0
    .line 708: const/4 v8, 0
    .line 709: goto :goto_712
    .line 710: move v8, v2
    .line 711: const/4 v2, 0
    .line 712: invoke-static {v6, v2, v8}, Ld2/b;->G(III)I
    .line 715: move-result v6
    .line 716: iput v6, v3, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 718: iget-object v3, v1, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 720: if-eqz v3, :cond_758
    .line 722: iget v6, v3, Landroid/view/WindowManager$LayoutParams;->y:I
    .line 724: iget v7, v7, Landroid/util/DisplayMetrics;->heightPixels:I
    .line 726: sub-int v4, v7, v4
    .line 728: if-gez v4, :cond_731
    .line 730: move v4, v2
    .line 731: invoke-static {v6, v2, v4}, Ld2/b;->G(III)I
    .line 734: move-result v2
    .line 735: iput v2, v3, Landroid/view/WindowManager$LayoutParams;->y:I
    .line 737: iget-object v2, v1, Lcom/titanchess/accessibility/s;->b:Landroid/view/WindowManager;
    .line 739: iget-object v3, v1, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 741: if-eqz v3, :cond_749
    .line 743: invoke-interface {v2, v0, v3}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 746: goto :goto_757
    .line 747: move-exception v0
    .line 748: goto :goto_754
    .line 749: invoke-static {v5}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 752: const/4 v0, 0
    .line 753: throw v0
    .line 754: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 757: return-void
    .line 758: invoke-static {v5}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 761: const/4 v0, 0
    .line 762: throw v0
    .line 763: const/4 v0, 0
    .line 764: invoke-static {v5}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 767: throw v0
.end method

# virtual methods
.method public final h()V
    .registers 10

    .line 0: iget-object v0, v9, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 2: if-eqz v0, :cond_5
    .line 4: return-void
    .line 5: iget-object v0, v9, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 7: const-string v1, "float_hidden"
    .line 9: const/4 v2, 0
    .line 10: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 13: move-result v1
    .line 14: if-eqz v1, :cond_17
    .line 16: return-void
    .line 17: const-string v1, "float_expanded"
    .line 19: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 22: move-result v1
    .line 23: iput-boolean v1, v9, Lcom/titanchess/accessibility/s;->g:Z
    .line 25: new-instance v1, Landroid/widget/FrameLayout;
    .line 27: iget-object v2, v9, Lcom/titanchess/accessibility/s;->a:Landroid/content/Context;
    .line 29: invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    .line 32: new-instance v2, Landroid/view/WindowManager$LayoutParams;
    .line 34: const/4 v4, -2
    .line 35: const/4 v5, -2
    .line 36: const/16 v6, 2032
    .line 38: const/16 v7, 520
    .line 40: const/4 v8, -3
    .line 41: move-object v3, v2
    .line 42: invoke-direct/range {v3 .. v8}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V
    .line 45: const v3, 0x800033
    .line 48: iput v3, v2, Landroid/view/WindowManager$LayoutParams;->gravity:I
    .line 50: iget-object v3, v9, Lcom/titanchess/accessibility/s;->d:Landroid/util/DisplayMetrics;
    .line 52: iget v3, v3, Landroid/util/DisplayMetrics;->widthPixels:I
    .line 54: const/high16 v4, 0x4260
    .line 56: invoke-virtual {v9, v4}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 59: move-result v4
    .line 60: sub-int/2addr v3, v4
    .line 61: const-string v4, "float_x"
    .line 63: invoke-interface {v0, v4, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 66: move-result v3
    .line 67: iput v3, v2, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 69: const/high16 v3, 0x42f0
    .line 71: invoke-virtual {v9, v3}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 74: move-result v3
    .line 75: const-string v4, "float_y"
    .line 77: invoke-interface {v0, v4, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 80: move-result v3
    .line 81: iput v3, v2, Landroid/view/WindowManager$LayoutParams;->y:I
    .line 83: iput-object v2, v9, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 85: iput-object v1, v9, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 87: iget-object v3, v9, Lcom/titanchess/accessibility/s;->b:Landroid/view/WindowManager;
    .line 89: invoke-interface {v3, v1, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 92: iget-object v1, v9, Lcom/titanchess/accessibility/s;->k:Lcom/titanchess/accessibility/l;
    .line 94: invoke-interface {v0, v1}, Landroid/content/SharedPreferences;->registerOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V
    .line 97: const/4 v0, 1
    .line 98: iput-boolean v0, v9, Lcom/titanchess/accessibility/s;->i:Z
    .line 100: invoke-virtual {v9}, Lcom/titanchess/accessibility/s;->g()V
    .line 103: return-void
.end method

# virtual methods
.method public final i(Ljava/lang/String;Lcom/titanchess/accessibility/r;)Landroid/widget/TextView;
    .registers 6

    .line 0: new-instance v0, Landroid/widget/TextView;
    .line 2: iget-object v1, v3, Lcom/titanchess/accessibility/s;->a:Landroid/content/Context;
    .line 4: invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    .line 7: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 10: iget v4, v3, Lcom/titanchess/accessibility/s;->m:I
    .line 12: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextColor(I)V
    .line 15: const/high16 v4, 0x4190
    .line 17: iget v1, v3, Lcom/titanchess/accessibility/s;->h:F
    .line 19: mul-float/2addr v1, v4
    .line 20: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V
    .line 23: const/16 v4, 17
    .line 25: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setGravity(I)V
    .line 28: iget-object v4, v3, Lcom/titanchess/accessibility/s;->s:Ls2/h;
    .line 30: invoke-virtual {v4}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 33: move-result-object v4
    .line 34: check-cast v4, Landroid/graphics/Typeface;
    .line 36: if-eqz v4, :cond_41
    .line 38: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    .line 41: const/high16 v4, 0x4228
    .line 43: invoke-virtual {v3, v4}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 46: move-result v4
    .line 47: const/high16 v1, 0x4218
    .line 49: invoke-virtual {v3, v1}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 52: move-result v1
    .line 53: new-instance v2, Landroid/widget/LinearLayout$LayoutParams;
    .line 55: invoke-direct {v2, v4, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V
    .line 58: invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    .line 61: const/high16 v4, 0x4110
    .line 63: invoke-virtual {v3, v4}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 66: move-result v4
    .line 67: int-to-float v4, v4
    .line 68: iget v1, v3, Lcom/titanchess/accessibility/s;->r:I
    .line 70: iget v2, v3, Lcom/titanchess/accessibility/s;->p:I
    .line 72: invoke-virtual {v3, v4, v1, v2}, Lcom/titanchess/accessibility/s;->f(FII)Landroid/graphics/drawable/GradientDrawable;
    .line 75: move-result-object v4
    .line 76: invoke-virtual {v0, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    .line 79: new-instance v4, Lcom/titanchess/accessibility/m;
    .line 81: const/4 v1, 1
    .line 82: invoke-direct {v4, v1, v5}, Lcom/titanchess/accessibility/m;-><init>(ILjava/lang/Object;)V
    .line 85: invoke-virtual {v0, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    .line 88: return-object v0
.end method

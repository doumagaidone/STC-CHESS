.class public final Lcom/titanchess/accessibility/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F
.field public final c:Ljava/lang/String;
.field public final d:F

# direct methods
.method public constructor <init>(FFLjava/lang/String;F)V
    .registers 6

    .line 0: const-string v0, "icon"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput v2, v1, Lcom/titanchess/accessibility/c;->a:F
    .line 10: iput v3, v1, Lcom/titanchess/accessibility/c;->b:F
    .line 12: iput-object v4, v1, Lcom/titanchess/accessibility/c;->c:Ljava/lang/String;
    .line 14: iput v5, v1, Lcom/titanchess/accessibility/c;->d:F
    .line 16: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/c;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/c;
    .line 12: iget v1, v5, Lcom/titanchess/accessibility/c;->a:F
    .line 14: iget v3, v4, Lcom/titanchess/accessibility/c;->a:F
    .line 16: invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lcom/titanchess/accessibility/c;->b:F
    .line 25: iget v3, v5, Lcom/titanchess/accessibility/c;->b:F
    .line 27: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 30: move-result v1
    .line 31: if-eqz v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Lcom/titanchess/accessibility/c;->c:Ljava/lang/String;
    .line 36: iget-object v3, v5, Lcom/titanchess/accessibility/c;->c:Ljava/lang/String;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget v1, v4, Lcom/titanchess/accessibility/c;->d:F
    .line 47: iget v5, v5, Lcom/titanchess/accessibility/c;->d:F
    .line 49: invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I
    .line 52: move-result v5
    .line 53: if-eqz v5, :cond_56
    .line 55: return v2
    .line 56: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget v0, v3, Lcom/titanchess/accessibility/c;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lcom/titanchess/accessibility/c;->b:F
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 14: move-result v0
    .line 15: iget-object v2, v3, Lcom/titanchess/accessibility/c;->c:Ljava/lang/String;
    .line 17: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 20: move-result v2
    .line 21: add-int/2addr v2, v0
    .line 22: mul-int/2addr v2, v1
    .line 23: iget v0, v3, Lcom/titanchess/accessibility/c;->d:F
    .line 25: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 28: move-result v0
    .line 29: add-int/2addr v0, v2
    .line 30: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Badge(cx="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v2, Lcom/titanchess/accessibility/c;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", cy="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lcom/titanchess/accessibility/c;->b:F
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", icon="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Lcom/titanchess/accessibility/c;->c:Ljava/lang/String;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", sqPx="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v2, Lcom/titanchess/accessibility/c;->d:F
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ")"
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v0
    .line 51: return-object v0
.end method

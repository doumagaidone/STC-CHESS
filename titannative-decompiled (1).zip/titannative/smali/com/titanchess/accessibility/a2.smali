.class public final Lcom/titanchess/accessibility/a2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/util/List;
.field public final c:Lp2/n;
.field public final d:I
.field public final e:I
.field public final f:I
.field public final g:I

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/ArrayList;Lp2/n;IIII)V
    .registers 8

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 9: iput v4, v0, Lcom/titanchess/accessibility/a2;->d:I
    .line 11: iput v5, v0, Lcom/titanchess/accessibility/a2;->e:I
    .line 13: iput v6, v0, Lcom/titanchess/accessibility/a2;->f:I
    .line 15: iput v7, v0, Lcom/titanchess/accessibility/a2;->g:I
    .line 17: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/a2;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/a2;
    .line 12: iget-object v1, v5, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 14: iget-object v3, v4, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 25: iget-object v3, v5, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 36: iget-object v3, v5, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 38: if-eq v1, v3, :cond_41
    .line 40: return v2
    .line 41: iget v1, v4, Lcom/titanchess/accessibility/a2;->d:I
    .line 43: iget v3, v5, Lcom/titanchess/accessibility/a2;->d:I
    .line 45: if-eq v1, v3, :cond_48
    .line 47: return v2
    .line 48: iget v1, v4, Lcom/titanchess/accessibility/a2;->e:I
    .line 50: iget v3, v5, Lcom/titanchess/accessibility/a2;->e:I
    .line 52: if-eq v1, v3, :cond_55
    .line 54: return v2
    .line 55: iget v1, v4, Lcom/titanchess/accessibility/a2;->f:I
    .line 57: iget v3, v5, Lcom/titanchess/accessibility/a2;->f:I
    .line 59: if-eq v1, v3, :cond_62
    .line 61: return v2
    .line 62: iget v1, v4, Lcom/titanchess/accessibility/a2;->g:I
    .line 64: iget v5, v5, Lcom/titanchess/accessibility/a2;->g:I
    .line 66: if-eq v1, v5, :cond_69
    .line 68: return v2
    .line 69: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v3, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 11: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 14: move-result v2
    .line 15: add-int/2addr v2, v0
    .line 16: mul-int/2addr v2, v1
    .line 17: iget-object v0, v3, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 19: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 22: move-result v0
    .line 23: add-int/2addr v0, v2
    .line 24: mul-int/2addr v0, v1
    .line 25: iget v2, v3, Lcom/titanchess/accessibility/a2;->d:I
    .line 27: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 30: move-result v0
    .line 31: iget v2, v3, Lcom/titanchess/accessibility/a2;->e:I
    .line 33: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 36: move-result v0
    .line 37: iget v2, v3, Lcom/titanchess/accessibility/a2;->f:I
    .line 39: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 42: move-result v0
    .line 43: iget v1, v3, Lcom/titanchess/accessibility/a2;->g:I
    .line 45: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 48: move-result v1
    .line 49: add-int/2addr v1, v0
    .line 50: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Snap(fen="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", history="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", side="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", tcBase="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v2, Lcom/titanchess/accessibility/a2;->d:I
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", tcInc="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget v1, v2, Lcom/titanchess/accessibility/a2;->e:I
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", clkWhiteMs="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget v1, v2, Lcom/titanchess/accessibility/a2;->f:I
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ", clkBlackMs="
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget v1, v2, Lcom/titanchess/accessibility/a2;->g:I
    .line 69: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 72: const-string v1, ")"
    .line 74: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 80: move-result-object v0
    .line 81: return-object v0
.end method

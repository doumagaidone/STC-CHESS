.class public final Lcom/titanchess/accessibility/f;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/lang/String;
.field public final c:I
.field public final d:F

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;IF)V
    .registers 5

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 7: iput v3, v0, Lcom/titanchess/accessibility/f;->c:I
    .line 9: iput v4, v0, Lcom/titanchess/accessibility/f;->d:F
    .line 11: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/f;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/f;
    .line 12: iget-object v1, v5, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 14: iget-object v3, v4, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 25: iget-object v3, v5, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget v1, v4, Lcom/titanchess/accessibility/f;->c:I
    .line 36: iget v3, v5, Lcom/titanchess/accessibility/f;->c:I
    .line 38: if-eq v1, v3, :cond_41
    .line 40: return v2
    .line 41: iget v1, v4, Lcom/titanchess/accessibility/f;->d:F
    .line 43: iget v5, v5, Lcom/titanchess/accessibility/f;->d:F
    .line 45: invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I
    .line 48: move-result v5
    .line 49: if-eqz v5, :cond_52
    .line 51: return v2
    .line 52: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v3, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 11: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 14: move-result v2
    .line 15: add-int/2addr v2, v0
    .line 16: mul-int/2addr v2, v1
    .line 17: iget v0, v3, Lcom/titanchess/accessibility/f;->c:I
    .line 19: invoke-static {v0, v2, v1}, Lai/onnxruntime/b;->c(III)I
    .line 22: move-result v0
    .line 23: iget v1, v3, Lcom/titanchess/accessibility/f;->d:F
    .line 25: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 28: move-result v1
    .line 29: add-int/2addr v1, v0
    .line 30: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Ranked(from="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", to="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", rank="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v2, Lcom/titanchess/accessibility/f;->c:I
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", prob="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v2, Lcom/titanchess/accessibility/f;->d:F
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ")"
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v0
    .line 51: return-object v0
.end method

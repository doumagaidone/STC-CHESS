.class public final Lcom/titanchess/accessibility/w;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/lang/String;
.field public final c:Ljava/lang/String;
.field public final d:Ljava/lang/String;
.field public final e:Ljava/lang/String;
.field public final f:J

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .registers 8

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/w;->b:Ljava/lang/String;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/w;->c:Ljava/lang/String;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 11: iput-object v5, v0, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 13: iput-wide v6, v0, Lcom/titanchess/accessibility/w;->f:J
    .line 15: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/w;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/w;
    .line 12: iget-object v1, v8, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 14: iget-object v3, v7, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v7, Lcom/titanchess/accessibility/w;->b:Ljava/lang/String;
    .line 25: iget-object v3, v8, Lcom/titanchess/accessibility/w;->b:Ljava/lang/String;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v7, Lcom/titanchess/accessibility/w;->c:Ljava/lang/String;
    .line 36: iget-object v3, v8, Lcom/titanchess/accessibility/w;->c:Ljava/lang/String;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget-object v1, v7, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 47: iget-object v3, v8, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 49: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v1
    .line 53: if-nez v1, :cond_56
    .line 55: return v2
    .line 56: iget-object v1, v7, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 58: iget-object v3, v8, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 60: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 63: move-result v1
    .line 64: if-nez v1, :cond_67
    .line 66: return v2
    .line 67: iget-wide v3, v7, Lcom/titanchess/accessibility/w;->f:J
    .line 69: iget-wide v5, v8, Lcom/titanchess/accessibility/w;->f:J
    .line 71: cmp-long v8, v3, v5
    .line 73: if-eqz v8, :cond_76
    .line 75: return v2
    .line 76: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: const/4 v1, 0
    .line 9: iget-object v2, v3, Lcom/titanchess/accessibility/w;->b:Ljava/lang/String;
    .line 11: if-nez v2, :cond_15
    .line 13: move v2, v1
    .line 14: goto :goto_19
    .line 15: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 18: move-result v2
    .line 19: add-int/2addr v0, v2
    .line 20: mul-int/lit8 v0, v0, 31
    .line 22: iget-object v2, v3, Lcom/titanchess/accessibility/w;->c:Ljava/lang/String;
    .line 24: if-nez v2, :cond_28
    .line 26: move v2, v1
    .line 27: goto :goto_32
    .line 28: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 31: move-result v2
    .line 32: add-int/2addr v0, v2
    .line 33: mul-int/lit8 v0, v0, 31
    .line 35: iget-object v2, v3, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 37: if-nez v2, :cond_41
    .line 39: move v2, v1
    .line 40: goto :goto_45
    .line 41: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 44: move-result v2
    .line 45: add-int/2addr v0, v2
    .line 46: mul-int/lit8 v0, v0, 31
    .line 48: iget-object v2, v3, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 50: if-nez v2, :cond_53
    .line 52: goto :goto_57
    .line 53: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 56: move-result v1
    .line 57: add-int/2addr v0, v1
    .line 58: mul-int/lit8 v0, v0, 31
    .line 60: iget-wide v1, v3, Lcom/titanchess/accessibility/w;->f:J
    .line 62: invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I
    .line 65: move-result v1
    .line 66: add-int/2addr v1, v0
    .line 67: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Result(status="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", expires="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lcom/titanchess/accessibility/w;->b:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", products="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v3, Lcom/titanchess/accessibility/w;->c:Ljava/lang/String;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", msg="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v3, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", token="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-object v1, v3, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", tokenExp="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget-wide v1, v3, Lcom/titanchess/accessibility/w;->f:J
    .line 59: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ")"
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 70: move-result-object v0
    .line 71: return-object v0
.end method

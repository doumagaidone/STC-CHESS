.class public final synthetic Lcom/titanchess/accessibility/n;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/View$OnTouchListener;

.field public final synthetic a:Le3/p;
.field public final synthetic b:Le3/p;
.field public final synthetic c:Le3/q;
.field public final synthetic d:Lcom/titanchess/accessibility/s;
.field public final synthetic e:Le3/q;
.field public final synthetic f:Le3/o;
.field public final synthetic g:Le3/o;
.field public final synthetic h:Landroid/view/View;
.field public final synthetic i:Ljava/lang/Runnable;
.field public final synthetic j:Ld3/a;

# direct methods
.method public synthetic constructor <init>(Le3/p;Le3/p;Le3/q;Lcom/titanchess/accessibility/s;Le3/q;Le3/o;Le3/o;Landroid/view/View;Landroidx/emoji2/text/l;Ld3/a;)V
    .registers 11

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/n;->a:Le3/p;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/n;->b:Le3/p;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/n;->c:Le3/q;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/n;->d:Lcom/titanchess/accessibility/s;
    .line 11: iput-object v5, v0, Lcom/titanchess/accessibility/n;->e:Le3/q;
    .line 13: iput-object v6, v0, Lcom/titanchess/accessibility/n;->f:Le3/o;
    .line 15: iput-object v7, v0, Lcom/titanchess/accessibility/n;->g:Le3/o;
    .line 17: iput-object v8, v0, Lcom/titanchess/accessibility/n;->h:Landroid/view/View;
    .line 19: iput-object v9, v0, Lcom/titanchess/accessibility/n;->i:Ljava/lang/Runnable;
    .line 21: iput-object v10, v0, Lcom/titanchess/accessibility/n;->j:Ld3/a;
    .line 23: return-void
.end method

# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 19

    .line 0: move-object/from16 v1, v16
    .line 2: iget-object v0, v1, Lcom/titanchess/accessibility/n;->a:Le3/p;
    .line 4: const-string v2, "$downX"
    .line 6: invoke-static {v0, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: iget-object v2, v1, Lcom/titanchess/accessibility/n;->b:Le3/p;
    .line 11: const-string v3, "$downY"
    .line 13: invoke-static {v2, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: iget-object v3, v1, Lcom/titanchess/accessibility/n;->c:Le3/q;
    .line 18: const-string v4, "$startX"
    .line 20: invoke-static {v3, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 23: iget-object v4, v1, Lcom/titanchess/accessibility/n;->d:Lcom/titanchess/accessibility/s;
    .line 25: const-string v5, "this$0"
    .line 27: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 30: iget-object v5, v1, Lcom/titanchess/accessibility/n;->e:Le3/q;
    .line 32: const-string v6, "$startY"
    .line 34: invoke-static {v5, v6}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: iget-object v6, v1, Lcom/titanchess/accessibility/n;->f:Le3/o;
    .line 39: const-string v7, "$moved"
    .line 41: invoke-static {v6, v7}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 44: iget-object v7, v1, Lcom/titanchess/accessibility/n;->g:Le3/o;
    .line 46: const-string v8, "$longFired"
    .line 48: invoke-static {v7, v8}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 51: iget-object v8, v1, Lcom/titanchess/accessibility/n;->h:Landroid/view/View;
    .line 53: const-string v9, "$handle"
    .line 55: invoke-static {v8, v9}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 58: iget-object v9, v1, Lcom/titanchess/accessibility/n;->i:Ljava/lang/Runnable;
    .line 60: const-string v10, "$longPress"
    .line 62: invoke-static {v9, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 65: iget-object v10, v1, Lcom/titanchess/accessibility/n;->j:Ld3/a;
    .line 67: const-string v11, "$onTap"
    .line 69: invoke-static {v10, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 72: invoke-virtual/range {v18 .. v18}, Landroid/view/MotionEvent;->getAction()I
    .line 75: move-result v11
    .line 76: const/4 v12, 0
    .line 77: const/4 v14, 1
    .line 78: const-string v15, "lp"
    .line 80: if-eqz v11, :cond_294
    .line 82: iget-object v13, v4, Lcom/titanchess/accessibility/s;->b:Landroid/view/WindowManager;
    .line 84: if-eq v11, v14, :cond_185
    .line 86: const/4 v7, 2
    .line 87: if-eq v11, v7, :cond_92
    .line 89: const/4 v13, 0
    .line 90: goto/16 :goto_330
    .line 92: invoke-virtual/range {v18 .. v18}, Landroid/view/MotionEvent;->getRawX()F
    .line 95: move-result v7
    .line 96: iget v0, v0, Le3/p;->i:F
    .line 98: sub-float/2addr v7, v0
    .line 99: invoke-virtual/range {v18 .. v18}, Landroid/view/MotionEvent;->getRawY()F
    .line 102: move-result v0
    .line 103: iget v2, v2, Le3/p;->i:F
    .line 105: sub-float/2addr v0, v2
    .line 106: invoke-static {v7}, Ljava/lang/Math;->abs(F)F
    .line 109: move-result v2
    .line 110: const/high16 v10, 0x4100
    .line 112: cmpl-float v2, v2, v10
    .line 114: if-gtz v2, :cond_124
    .line 116: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    .line 119: move-result v2
    .line 120: cmpl-float v2, v2, v10
    .line 122: if-lez v2, :cond_129
    .line 124: iput-boolean v14, v6, Le3/o;->i:Z
    .line 126: invoke-virtual {v8, v9}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z
    .line 129: iget-object v2, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 131: if-eqz v2, :cond_181
    .line 133: iget v3, v3, Le3/q;->i:I
    .line 135: invoke-static {v7}, Ld2/b;->a1(F)I
    .line 138: move-result v6
    .line 139: add-int/2addr v6, v3
    .line 140: iput v6, v2, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 142: iget-object v2, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 144: if-eqz v2, :cond_177
    .line 146: iget v3, v5, Le3/q;->i:I
    .line 148: invoke-static {v0}, Ld2/b;->a1(F)I
    .line 151: move-result v0
    .line 152: add-int/2addr v0, v3
    .line 153: iput v0, v2, Landroid/view/WindowManager$LayoutParams;->y:I
    .line 155: iget-object v0, v4, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 157: iget-object v2, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 159: if-eqz v2, :cond_167
    .line 161: invoke-interface {v13, v0, v2}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 164: goto :goto_174
    .line 165: move-exception v0
    .line 166: goto :goto_171
    .line 167: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 170: throw v12
    .line 171: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 174: move v13, v14
    .line 175: goto/16 :goto_330
    .line 177: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 180: throw v12
    .line 181: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 184: throw v12
    .line 185: invoke-virtual {v8, v9}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z
    .line 188: iget-boolean v0, v7, Le3/o;->i:Z
    .line 190: if-nez v0, :cond_174
    .line 192: iget-boolean v0, v6, Le3/o;->i:Z
    .line 194: if-nez v0, :cond_200
    .line 196: invoke-interface {v10}, Ld3/a;->s()Ljava/lang/Object;
    .line 199: goto :goto_174
    .line 200: iget-object v0, v4, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 202: if-eqz v0, :cond_209
    .line 204: invoke-virtual {v0}, Landroid/view/View;->getWidth()I
    .line 207: move-result v0
    .line 208: goto :goto_215
    .line 209: const/high16 v0, 0x4230
    .line 211: invoke-virtual {v4, v0}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 214: move-result v0
    .line 215: iget-object v2, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 217: if-eqz v2, :cond_290
    .line 219: iget v3, v2, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 221: div-int/lit8 v5, v0, 2
    .line 223: add-int/2addr v5, v3
    .line 224: iget-object v3, v4, Lcom/titanchess/accessibility/s;->d:Landroid/util/DisplayMetrics;
    .line 226: iget v3, v3, Landroid/util/DisplayMetrics;->widthPixels:I
    .line 228: div-int/lit8 v6, v3, 2
    .line 230: if-ge v5, v6, :cond_234
    .line 232: const/4 v0, 0
    .line 233: goto :goto_236
    .line 234: sub-int v0, v3, v0
    .line 236: iput v0, v2, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 238: iget-object v0, v4, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 240: invoke-interface {v13, v0, v2}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 243: goto :goto_248
    .line 244: move-exception v0
    .line 245: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 248: iget-object v0, v4, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 250: invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 253: move-result-object v0
    .line 254: iget-object v2, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 256: if-eqz v2, :cond_286
    .line 258: iget v2, v2, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 260: const-string v3, "float_x"
    .line 262: invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    .line 265: move-result-object v0
    .line 266: iget-object v2, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 268: if-eqz v2, :cond_282
    .line 270: iget v2, v2, Landroid/view/WindowManager$LayoutParams;->y:I
    .line 272: const-string v3, "float_y"
    .line 274: invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    .line 277: move-result-object v0
    .line 278: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 281: goto :goto_174
    .line 282: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 285: throw v12
    .line 286: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 289: throw v12
    .line 290: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 293: throw v12
    .line 294: invoke-virtual/range {v18 .. v18}, Landroid/view/MotionEvent;->getRawX()F
    .line 297: move-result v10
    .line 298: iput v10, v0, Le3/p;->i:F
    .line 300: invoke-virtual/range {v18 .. v18}, Landroid/view/MotionEvent;->getRawY()F
    .line 303: move-result v0
    .line 304: iput v0, v2, Le3/p;->i:F
    .line 306: iget-object v0, v4, Lcom/titanchess/accessibility/s;->f:Landroid/view/WindowManager$LayoutParams;
    .line 308: if-eqz v0, :cond_331
    .line 310: iget v2, v0, Landroid/view/WindowManager$LayoutParams;->x:I
    .line 312: iput v2, v3, Le3/q;->i:I
    .line 314: iget v0, v0, Landroid/view/WindowManager$LayoutParams;->y:I
    .line 316: iput v0, v5, Le3/q;->i:I
    .line 318: const/4 v0, 0
    .line 319: iput-boolean v0, v6, Le3/o;->i:Z
    .line 321: iput-boolean v0, v7, Le3/o;->i:Z
    .line 323: const-wide/16 v2, 500
    .line 325: invoke-virtual {v8, v9, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z
    .line 328: goto/16 :goto_174
    .line 330: return v13
    .line 331: invoke-static {v15}, Ld2/b;->h1(Ljava/lang/String;)V
    .line 334: throw v12
.end method

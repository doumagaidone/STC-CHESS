.class public final Lcom/titanchess/accessibility/h2;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:Ljava/lang/String;
.field public final c:Ljava/lang/String;
.field public final d:Ljava/lang/String;
.field public final e:J

# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .registers 7

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lcom/titanchess/accessibility/h2;->a:I
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/h2;->b:Ljava/lang/String;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/h2;->c:Ljava/lang/String;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/h2;->d:Ljava/lang/String;
    .line 11: iput-wide v5, v0, Lcom/titanchess/accessibility/h2;->e:J
    .line 13: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/h2;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/h2;
    .line 12: iget v1, v8, Lcom/titanchess/accessibility/h2;->a:I
    .line 14: iget v3, v7, Lcom/titanchess/accessibility/h2;->a:I
    .line 16: if-eq v3, v1, :cond_19
    .line 18: return v2
    .line 19: iget-object v1, v7, Lcom/titanchess/accessibility/h2;->b:Ljava/lang/String;
    .line 21: iget-object v3, v8, Lcom/titanchess/accessibility/h2;->b:Ljava/lang/String;
    .line 23: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 26: move-result v1
    .line 27: if-nez v1, :cond_30
    .line 29: return v2
    .line 30: iget-object v1, v7, Lcom/titanchess/accessibility/h2;->c:Ljava/lang/String;
    .line 32: iget-object v3, v8, Lcom/titanchess/accessibility/h2;->c:Ljava/lang/String;
    .line 34: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 37: move-result v1
    .line 38: if-nez v1, :cond_41
    .line 40: return v2
    .line 41: iget-object v1, v7, Lcom/titanchess/accessibility/h2;->d:Ljava/lang/String;
    .line 43: iget-object v3, v8, Lcom/titanchess/accessibility/h2;->d:Ljava/lang/String;
    .line 45: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 48: move-result v1
    .line 49: if-nez v1, :cond_52
    .line 51: return v2
    .line 52: iget-wide v3, v7, Lcom/titanchess/accessibility/h2;->e:J
    .line 54: iget-wide v5, v8, Lcom/titanchess/accessibility/h2;->e:J
    .line 56: cmp-long v8, v3, v5
    .line 58: if-eqz v8, :cond_61
    .line 60: return v2
    .line 61: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 5

    .line 0: iget v0, v4, Lcom/titanchess/accessibility/h2;->a:I
    .line 2: invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v4, Lcom/titanchess/accessibility/h2;->b:Ljava/lang/String;
    .line 10: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget-object v0, v4, Lcom/titanchess/accessibility/h2;->c:Ljava/lang/String;
    .line 19: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 22: move-result v0
    .line 23: add-int/2addr v0, v1
    .line 24: mul-int/lit8 v0, v0, 31
    .line 26: iget-object v1, v4, Lcom/titanchess/accessibility/h2;->d:Ljava/lang/String;
    .line 28: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 31: move-result v1
    .line 32: add-int/2addr v1, v0
    .line 33: mul-int/lit8 v1, v1, 31
    .line 35: iget-wide v2, v4, Lcom/titanchess/accessibility/h2;->e:J
    .line 37: invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I
    .line 40: move-result v0
    .line 41: add-int/2addr v0, v1
    .line 42: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Update(versionCode="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Lcom/titanchess/accessibility/h2;->a:I
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", versionName="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lcom/titanchess/accessibility/h2;->b:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", apkUrl="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v3, Lcom/titanchess/accessibility/h2;->c:Ljava/lang/String;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", sha256="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v3, Lcom/titanchess/accessibility/h2;->d:Ljava/lang/String;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", size="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-wide v1, v3, Lcom/titanchess/accessibility/h2;->e:J
    .line 49: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ")"
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 60: move-result-object v0
    .line 61: return-object v0
.end method

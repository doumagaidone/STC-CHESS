.class public final Lcom/titanchess/accessibility/r1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:Ljava/lang/String;
.field public final c:J
.field public final d:I

# direct methods
.method public constructor <init>(IIJLjava/lang/String;)V
    .registers 7

    .line 0: const-string v0, "best"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput v2, v1, Lcom/titanchess/accessibility/r1;->a:I
    .line 10: iput-object v6, v1, Lcom/titanchess/accessibility/r1;->b:Ljava/lang/String;
    .line 12: iput-wide v4, v1, Lcom/titanchess/accessibility/r1;->c:J
    .line 14: iput v3, v1, Lcom/titanchess/accessibility/r1;->d:I
    .line 16: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/r1;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/r1;
    .line 12: iget v1, v8, Lcom/titanchess/accessibility/r1;->a:I
    .line 14: iget v3, v7, Lcom/titanchess/accessibility/r1;->a:I
    .line 16: if-eq v3, v1, :cond_19
    .line 18: return v2
    .line 19: iget-object v1, v7, Lcom/titanchess/accessibility/r1;->b:Ljava/lang/String;
    .line 21: iget-object v3, v8, Lcom/titanchess/accessibility/r1;->b:Ljava/lang/String;
    .line 23: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 26: move-result v1
    .line 27: if-nez v1, :cond_30
    .line 29: return v2
    .line 30: iget-wide v3, v7, Lcom/titanchess/accessibility/r1;->c:J
    .line 32: iget-wide v5, v8, Lcom/titanchess/accessibility/r1;->c:J
    .line 34: cmp-long v1, v3, v5
    .line 36: if-eqz v1, :cond_39
    .line 38: return v2
    .line 39: iget v1, v7, Lcom/titanchess/accessibility/r1;->d:I
    .line 41: iget v8, v8, Lcom/titanchess/accessibility/r1;->d:I
    .line 43: if-eq v1, v8, :cond_46
    .line 45: return v2
    .line 46: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 6

    .line 0: iget v0, v5, Lcom/titanchess/accessibility/r1;->a:I
    .line 2: invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v5, Lcom/titanchess/accessibility/r1;->b:Ljava/lang/String;
    .line 11: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 14: move-result v2
    .line 15: add-int/2addr v2, v0
    .line 16: mul-int/2addr v2, v1
    .line 17: iget-wide v3, v5, Lcom/titanchess/accessibility/r1;->c:J
    .line 19: invoke-static {v3, v4, v2, v1}, Lai/onnxruntime/b;->d(JII)I
    .line 22: move-result v0
    .line 23: iget v1, v5, Lcom/titanchess/accessibility/r1;->d:I
    .line 25: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 28: move-result v1
    .line 29: add-int/2addr v1, v0
    .line 30: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Probe(cp="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Lcom/titanchess/accessibility/r1;->a:I
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", best="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lcom/titanchess/accessibility/r1;->b:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", ms="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-wide v1, v3, Lcom/titanchess/accessibility/r1;->c:J
    .line 29: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", depth="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v3, Lcom/titanchess/accessibility/r1;->d:I
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ")"
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v0
    .line 51: return-object v0
.end method

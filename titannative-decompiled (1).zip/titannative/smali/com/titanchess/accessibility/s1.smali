.class public final Lcom/titanchess/accessibility/s1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public b:Ljava/lang/Process;
.field public c:Ljava/io/OutputStreamWriter;
.field public d:Ljava/io/BufferedReader;

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 4

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 8: new-instance v0, Ljava/io/File;
    .line 10: invoke-virtual {v3}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;
    .line 13: move-result-object v3
    .line 14: iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;
    .line 16: const-string v1, "libstockfish.so"
    .line 18: invoke-direct {v0, v3, v1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    .line 21: invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    .line 24: move-result-object v3
    .line 25: iput-object v3, v2, Lcom/titanchess/accessibility/s1;->a:Ljava/lang/String;
    .line 27: return-void
.end method

# virtual methods
.method public final declared-synchronized a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/titanchess/accessibility/q1;
    .registers 9

    .line 0: monitor-enter v5
    .line 1: const-string v0, "prevFen"
    .line 3: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 6: invoke-virtual {v5, v6}, Lcom/titanchess/accessibility/s1;->b(Ljava/lang/String;)Ls2/e;
    .line 9: move-result-object v6
    .line 10: const/4 v0, 0
    .line 11: if-nez v6, :cond_15
    .line 13: monitor-exit v5
    .line 14: return-object v0
    .line 15: iget-object v1, v6, Ls2/e;->i:Ljava/lang/Object;
    .line 17: check-cast v1, Ljava/lang/Number;
    .line 19: invoke-virtual {v1}, Ljava/lang/Number;->intValue()I
    .line 22: move-result v1
    .line 23: iget-object v6, v6, Ls2/e;->j:Ljava/lang/Object;
    .line 25: check-cast v6, Ljava/lang/String;
    .line 27: invoke-virtual {v5, v7}, Lcom/titanchess/accessibility/s1;->b(Ljava/lang/String;)Ls2/e;
    .line 30: move-result-object v2
    .line 31: if-nez v2, :cond_35
    .line 33: monitor-exit v5
    .line 34: return-object v0
    .line 35: iget-object v0, v2, Ls2/e;->i:Ljava/lang/Object;
    .line 37: check-cast v0, Ljava/lang/Number;
    .line 39: invoke-virtual {v0}, Ljava/lang/Number;->intValue()I
    .line 42: move-result v0
    .line 43: neg-int v2, v0
    .line 44: invoke-virtual {v8}, Ljava/lang/String;->length()I
    .line 47: move-result v3
    .line 48: const/4 v4, 0
    .line 49: if-lez v3, :cond_61
    .line 51: invoke-static {v8, v6}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 54: move-result v6
    .line 55: if-eqz v6, :cond_61
    .line 57: const/4 v6, 1
    .line 58: goto :goto_62
    .line 59: move-exception v6
    .line 60: goto :goto_83
    .line 61: move v6, v4
    .line 62: invoke-static {v1, v2, v6}, Ld2/c;->u(IIZ)Lcom/titanchess/accessibility/k;
    .line 65: move-result-object v6
    .line 66: const-string v8, " w "
    .line 68: invoke-static {v7, v8, v4}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 71: move-result v7
    .line 72: if-eqz v7, :cond_75
    .line 74: goto :goto_76
    .line 75: move v0, v2
    .line 76: new-instance v7, Lcom/titanchess/accessibility/q1;
    .line 78: invoke-direct {v7, v6, v0}, Lcom/titanchess/accessibility/q1;-><init>(Lcom/titanchess/accessibility/k;I)V
    .line 81: monitor-exit v5
    .line 82: return-object v7
    .line 83: monitor-exit v5
    .line 84: throw v6
.end method

# virtual methods
.method public final declared-synchronized b(Ljava/lang/String;)Ls2/e;
    .registers 8

    .line 0: const-string v0, "position fen "
    .line 2: monitor-enter v6
    .line 3: invoke-virtual {v6}, Lcom/titanchess/accessibility/s1;->e()Z
    .line 6: move-result v1
    .line 7: const/4 v2, 0
    .line 8: if-nez v1, :cond_12
    .line 10: monitor-exit v6
    .line 11: return-object v2
    .line 12: new-instance v1, Ljava/lang/StringBuilder;
    .line 14: invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 17: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 20: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 23: move-result-object v7
    .line 24: invoke-virtual {v6, v7}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 27: const-string v7, "go depth 10"
    .line 29: invoke-virtual {v6, v7}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 32: new-instance v7, Ljava/lang/StringBuilder;
    .line 34: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    .line 37: const-string v0, ""
    .line 39: iget-object v1, v6, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 41: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 44: invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    .line 47: move-result-object v3
    .line 48: if-nez v3, :cond_51
    .line 50: goto :goto_96
    .line 51: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 54: const/16 v4, 10
    .line 56: invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 59: const-string v4, "bestmove"
    .line 61: const/4 v5, 0
    .line 62: invoke-static {v3, v4, v5}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 65: move-result v4
    .line 66: if-eqz v4, :cond_44
    .line 68: const/4 v0, 1
    .line 69: new-array v1, v0, [C
    .line 71: const/16 v4, 32
    .line 73: aput-char v4, v1, v5
    .line 75: invoke-static {v3, v1}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 78: move-result-object v1
    .line 79: invoke-static {v1}, Ld2/b;->r0(Ljava/util/List;)I
    .line 82: move-result v3
    .line 83: if-gt v0, v3, :cond_92
    .line 85: invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 88: move-result-object v0
    .line 89: goto :goto_94
    .line 90: move-exception v7
    .line 91: goto :goto_127
    .line 92: const-string v0, ""
    .line 94: check-cast v0, Ljava/lang/String;
    .line 96: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 99: move-result-object v7
    .line 100: const-string v1, "toString(...)"
    .line 102: invoke-static {v7, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 105: invoke-static {v7}, Ld2/c;->o0(Ljava/lang/String;)Ljava/lang/Integer;
    .line 108: move-result-object v7
    .line 109: if-eqz v7, :cond_125
    .line 111: invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I
    .line 114: move-result v7
    .line 115: invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 118: move-result-object v7
    .line 119: new-instance v1, Ls2/e;
    .line 121: invoke-direct {v1, v7, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 124: goto :goto_131
    .line 125: move-object v1, v2
    .line 126: goto :goto_131
    .line 127: invoke-static {v7}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 130: move-result-object v1
    .line 131: invoke-static {v1}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 134: move-result-object v7
    .line 135: if-nez v7, :cond_139
    .line 137: move-object v2, v1
    .line 138: goto :goto_146
    .line 139: const-string v0, "TitanEval"
    .line 141: const-string v1, "eval fail"
    .line 143: invoke-static {v0, v1, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 146: check-cast v2, Ls2/e;
    .line 148: monitor-exit v6
    .line 149: return-object v2
    .line 150: move-exception v7
    .line 151: monitor-exit v6
    .line 152: throw v7
.end method

# virtual methods
.method public final declared-synchronized c(Ljava/lang/String;)Lcom/titanchess/accessibility/r1;
    .registers 15

    .line 0: const-string v0, "position fen "
    .line 2: monitor-enter v13
    .line 3: const-string v1, "fen"
    .line 5: invoke-static {v14, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 8: invoke-virtual {v13}, Lcom/titanchess/accessibility/s1;->e()Z
    .line 11: move-result v1
    .line 12: const/4 v2, 0
    .line 13: if-nez v1, :cond_17
    .line 15: monitor-exit v13
    .line 16: return-object v2
    .line 17: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 20: move-result-wide v3
    .line 21: invoke-virtual {v0, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 24: move-result-object v14
    .line 25: invoke-virtual {v13, v14}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 28: const-string v14, "go nodes 200000"
    .line 30: invoke-virtual {v13, v14}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 33: new-instance v14, Ljava/lang/StringBuilder;
    .line 35: invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V
    .line 38: const-string v0, ""
    .line 40: iget-object v1, v13, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 42: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 45: const/4 v5, 0
    .line 46: move v6, v5
    .line 47: invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    .line 50: move-result-object v7
    .line 51: if-nez v7, :cond_56
    .line 53: move-object v12, v0
    .line 54: move v9, v6
    .line 55: goto :goto_151
    .line 56: invoke-virtual {v14, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 59: const/16 v8, 10
    .line 61: invoke-virtual {v14, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 64: const-string v8, "info "
    .line 66: invoke-static {v7, v8, v5}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 69: move-result v8
    .line 70: const/16 v9, 32
    .line 72: const/4 v10, 1
    .line 73: if-eqz v8, :cond_119
    .line 75: const-string v8, " depth "
    .line 77: invoke-static {v7, v8, v5}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 80: move-result v8
    .line 81: if-eqz v8, :cond_119
    .line 83: new-array v8, v10, [C
    .line 85: aput-char v9, v8, v5
    .line 87: invoke-static {v7, v8}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 90: move-result-object v8
    .line 91: const-string v11, "depth"
    .line 93: invoke-interface {v8, v11}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I
    .line 96: move-result v11
    .line 97: add-int/2addr v11, v10
    .line 98: invoke-static {v11, v8}, Lt2/p;->M1(ILjava/util/List;)Ljava/lang/Object;
    .line 101: move-result-object v8
    .line 102: check-cast v8, Ljava/lang/String;
    .line 104: if-eqz v8, :cond_119
    .line 106: invoke-static {v8}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 109: move-result-object v8
    .line 110: if-eqz v8, :cond_119
    .line 112: invoke-virtual {v8}, Ljava/lang/Number;->intValue()I
    .line 115: move-result v6
    .line 116: goto :goto_119
    .line 117: move-exception v14
    .line 118: goto :goto_190
    .line 119: const-string v8, "bestmove"
    .line 121: invoke-static {v7, v8, v5}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 124: move-result v8
    .line 125: if-eqz v8, :cond_47
    .line 127: new-array v0, v10, [C
    .line 129: aput-char v9, v0, v5
    .line 131: invoke-static {v7, v0}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 134: move-result-object v0
    .line 135: invoke-static {v0}, Ld2/b;->r0(Ljava/util/List;)I
    .line 138: move-result v1
    .line 139: if-gt v10, v1, :cond_146
    .line 141: invoke-interface {v0, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 144: move-result-object v0
    .line 145: goto :goto_148
    .line 146: const-string v0, ""
    .line 148: check-cast v0, Ljava/lang/String;
    .line 150: goto :goto_53
    .line 151: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 154: move-result-wide v0
    .line 155: sub-long/2addr v0, v3
    .line 156: const v3, 0xf4240
    .line 159: int-to-long v3, v3
    .line 160: div-long v10, v0, v3
    .line 162: invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 165: move-result-object v14
    .line 166: const-string v0, "toString(...)"
    .line 168: invoke-static {v14, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 171: invoke-static {v14}, Ld2/c;->o0(Ljava/lang/String;)Ljava/lang/Integer;
    .line 174: move-result-object v14
    .line 175: if-eqz v14, :cond_188
    .line 177: invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I
    .line 180: move-result v8
    .line 181: new-instance v14, Lcom/titanchess/accessibility/r1;
    .line 183: move-object v7, v14
    .line 184: invoke-direct/range {v7 .. v12}, Lcom/titanchess/accessibility/r1;-><init>(IIJLjava/lang/String;)V
    .line 187: goto :goto_194
    .line 188: move-object v14, v2
    .line 189: goto :goto_194
    .line 190: invoke-static {v14}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 193: move-result-object v14
    .line 194: invoke-static {v14}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 197: move-result-object v0
    .line 198: if-nez v0, :cond_202
    .line 200: move-object v2, v14
    .line 201: goto :goto_209
    .line 202: const-string v14, "TitanEval"
    .line 204: const-string v1, "probe fail"
    .line 206: invoke-static {v14, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 209: check-cast v2, Lcom/titanchess/accessibility/r1;
    .line 211: monitor-exit v13
    .line 212: return-object v2
    .line 213: move-exception v14
    .line 214: monitor-exit v13
    .line 215: throw v14
.end method

# virtual methods
.method public final d(Ljava/lang/String;)V
    .registers 4

    .line 0: iget-object v0, v2, Lcom/titanchess/accessibility/s1;->c:Ljava/io/OutputStreamWriter;
    .line 2: if-eqz v0, :cond_27
    .line 4: new-instance v1, Ljava/lang/StringBuilder;
    .line 6: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 9: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v3, "\n"
    .line 14: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 20: move-result-object v3
    .line 21: invoke-virtual {v0, v3}, Ljava/io/Writer;->write(Ljava/lang/String;)V
    .line 24: invoke-virtual {v0}, Ljava/io/OutputStreamWriter;->flush()V
    .line 27: return-void
.end method

# virtual methods
.method public final declared-synchronized e()Z
    .registers 6

    .line 0: const-string v0, "binary missing: "
    .line 2: monitor-enter v5
    .line 3: iget-object v1, v5, Lcom/titanchess/accessibility/s1;->b:Ljava/lang/Process;
    .line 5: const/4 v2, 1
    .line 6: if-eqz v1, :cond_19
    .line 8: invoke-static {v1}, Lai/onnxruntime/a;->A(Ljava/lang/Process;)Z
    .line 11: move-result v1
    .line 12: if-ne v1, v2, :cond_19
    .line 14: monitor-exit v5
    .line 15: return v2
    .line 16: move-exception v0
    .line 17: goto/16 :goto_210
    .line 19: new-instance v1, Ljava/io/File;
    .line 21: iget-object v3, v5, Lcom/titanchess/accessibility/s1;->a:Ljava/lang/String;
    .line 23: invoke-direct {v1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    .line 26: invoke-virtual {v1}, Ljava/io/File;->exists()Z
    .line 29: move-result v1
    .line 30: const/4 v3, 0
    .line 31: if-nez v1, :cond_57
    .line 33: const-string v1, "TitanEval"
    .line 35: iget-object v2, v5, Lcom/titanchess/accessibility/s1;->a:Ljava/lang/String;
    .line 37: new-instance v4, Ljava/lang/StringBuilder;
    .line 39: invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 42: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 45: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 48: move-result-object v0
    .line 49: invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    .line 52: monitor-exit v5
    .line 53: return v3
    .line 54: move-exception v0
    .line 55: goto/16 :goto_182
    .line 57: new-instance v0, Ljava/lang/ProcessBuilder;
    .line 59: new-array v1, v2, [Ljava/lang/String;
    .line 61: iget-object v4, v5, Lcom/titanchess/accessibility/s1;->a:Ljava/lang/String;
    .line 63: aput-object v4, v1, v3
    .line 65: invoke-direct {v0, v1}, Ljava/lang/ProcessBuilder;-><init>([Ljava/lang/String;)V
    .line 68: invoke-virtual {v0, v2}, Ljava/lang/ProcessBuilder;->redirectErrorStream(Z)Ljava/lang/ProcessBuilder;
    .line 71: move-result-object v0
    .line 72: invoke-virtual {v0}, Ljava/lang/ProcessBuilder;->start()Ljava/lang/Process;
    .line 75: move-result-object v0
    .line 76: iput-object v0, v5, Lcom/titanchess/accessibility/s1;->b:Ljava/lang/Process;
    .line 78: new-instance v1, Ljava/io/OutputStreamWriter;
    .line 80: invoke-virtual {v0}, Ljava/lang/Process;->getOutputStream()Ljava/io/OutputStream;
    .line 83: move-result-object v2
    .line 84: invoke-direct {v1, v2}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;)V
    .line 87: iput-object v1, v5, Lcom/titanchess/accessibility/s1;->c:Ljava/io/OutputStreamWriter;
    .line 89: new-instance v1, Ljava/io/BufferedReader;
    .line 91: new-instance v2, Ljava/io/InputStreamReader;
    .line 93: invoke-virtual {v0}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;
    .line 96: move-result-object v0
    .line 97: invoke-direct {v2, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V
    .line 100: invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    .line 103: iput-object v1, v5, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 105: const-string v0, "uci"
    .line 107: invoke-virtual {v5, v0}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 110: const-string v0, "uciok"
    .line 112: iget-object v1, v5, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 114: if-nez v1, :cond_117
    .line 116: goto :goto_136
    .line 117: invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    .line 120: move-result-object v2
    .line 121: if-nez v2, :cond_124
    .line 123: goto :goto_136
    .line 124: invoke-static {v2, v0, v3}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 127: move-result v4
    .line 128: if-nez v4, :cond_136
    .line 130: invoke-static {v2, v0, v3}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 133: move-result v2
    .line 134: if-eqz v2, :cond_117
    .line 136: const-string v0, "setoption name Threads value 2"
    .line 138: invoke-virtual {v5, v0}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 141: const-string v0, "isready"
    .line 143: invoke-virtual {v5, v0}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 146: const-string v0, "readyok"
    .line 148: iget-object v1, v5, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 150: if-nez v1, :cond_153
    .line 152: goto :goto_172
    .line 153: invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    .line 156: move-result-object v2
    .line 157: if-nez v2, :cond_160
    .line 159: goto :goto_172
    .line 160: invoke-static {v2, v0, v3}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 163: move-result v4
    .line 164: if-nez v4, :cond_172
    .line 166: invoke-static {v2, v0, v3}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 169: move-result v2
    .line 170: if-eqz v2, :cond_153
    .line 172: const-string v0, "TitanEval"
    .line 174: const-string v1, "engine ready"
    .line 176: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 179: sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 181: goto :goto_186
    .line 182: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 185: move-result-object v0
    .line 186: invoke-static {v0}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 189: move-result-object v1
    .line 190: if-nez v1, :cond_193
    .line 192: goto :goto_202
    .line 193: const-string v0, "TitanEval"
    .line 195: const-string v2, "start fail"
    .line 197: invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 200: sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 202: check-cast v0, Ljava/lang/Boolean;
    .line 204: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 207: move-result v0
    .line 208: monitor-exit v5
    .line 209: return v0
    .line 210: monitor-exit v5
    .line 211: throw v0
.end method

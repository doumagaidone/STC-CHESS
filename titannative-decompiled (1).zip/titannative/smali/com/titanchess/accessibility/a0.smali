.class public final Lcom/titanchess/accessibility/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Ljava/lang/String;)Ls2/e;
    .registers 3

    .line 0: const-string v0, "B"
    .line 2: invoke-static {v2, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_26
    .line 8: const/16 v2, 1100
    .line 10: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 13: move-result-object v2
    .line 14: const/16 v0, 2600
    .line 16: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 19: move-result-object v0
    .line 20: new-instance v1, Ls2/e;
    .line 22: invoke-direct {v1, v2, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 25: goto :goto_69
    .line 26: const-string v0, "C"
    .line 28: invoke-static {v2, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 31: move-result v2
    .line 32: if-eqz v2, :cond_52
    .line 34: const/16 v2, 1000
    .line 36: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 39: move-result-object v2
    .line 40: const/16 v0, 1600
    .line 42: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 45: move-result-object v0
    .line 46: new-instance v1, Ls2/e;
    .line 48: invoke-direct {v1, v2, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 51: goto :goto_69
    .line 52: const/16 v2, 800
    .line 54: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 57: move-result-object v2
    .line 58: const/16 v0, 2800
    .line 60: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 63: move-result-object v0
    .line 64: new-instance v1, Ls2/e;
    .line 66: invoke-direct {v1, v2, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 69: return-object v1
.end method

# direct methods
.method public static b()Ljava/util/List;
    .registers 1

    .line 0: invoke-static {}, Lcom/titanchess/accessibility/MainActivity;->access$getMIMIC_BANDS$cp()Ljava/util/List;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

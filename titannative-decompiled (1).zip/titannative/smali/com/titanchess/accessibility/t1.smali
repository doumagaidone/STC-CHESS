.class public final enum Lcom/titanchess/accessibility/t1;
.super Ljava/lang/Enum;
.source "SourceFile"

.field public static final enum i:Lcom/titanchess/accessibility/t1;
.field public static final synthetic j:[Lcom/titanchess/accessibility/t1;

# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 0: new-instance v0, Lcom/titanchess/accessibility/t1;
    .line 2: const-string v1, "MODEL"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Lcom/titanchess/accessibility/t1;->i:Lcom/titanchess/accessibility/t1;
    .line 10: new-instance v1, Lcom/titanchess/accessibility/t1;
    .line 12: const-string v2, "ENGINE"
    .line 14: const/4 v3, 1
    .line 15: invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 18: new-instance v2, Lcom/titanchess/accessibility/t1;
    .line 20: const-string v3, "STATUS"
    .line 22: const/4 v4, 2
    .line 23: invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 26: new-instance v3, Lcom/titanchess/accessibility/t1;
    .line 28: const-string v4, "LICENSE"
    .line 30: const/4 v5, 3
    .line 31: invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 34: filled-new-array {v0, v1, v2, v3}, [Lcom/titanchess/accessibility/t1;
    .line 37: move-result-object v0
    .line 38: sput-object v0, Lcom/titanchess/accessibility/t1;->j:[Lcom/titanchess/accessibility/t1;
    .line 40: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lcom/titanchess/accessibility/t1;
    .registers 2

    .line 0: const-class v0, Lcom/titanchess/accessibility/t1;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lcom/titanchess/accessibility/t1;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lcom/titanchess/accessibility/t1;
    .registers 1

    .line 0: sget-object v0, Lcom/titanchess/accessibility/t1;->j:[Lcom/titanchess/accessibility/t1;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lcom/titanchess/accessibility/t1;
    .line 8: return-object v0
.end method

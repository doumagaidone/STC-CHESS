.class public final Lcom/titanchess/accessibility/c2;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"

.field public final synthetic a:Lcom/titanchess/accessibility/TitanAccessibilityService;

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: iput-object v1, v0, Lcom/titanchess/accessibility/c2;->a:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 2: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 15

    .line 0: if-eqz v14, :cond_227
    .line 2: const-string v13, "fen"
    .line 4: invoke-virtual {v14, v13}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    .line 7: move-result-object v1
    .line 8: if-nez v1, :cond_12
    .line 10: goto/16 :goto_227
    .line 12: const-string v13, "history"
    .line 14: invoke-virtual {v14, v13}, Landroid/content/Intent;->getStringArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 17: move-result-object v13
    .line 18: if-nez v13, :cond_25
    .line 20: new-instance v13, Ljava/util/ArrayList;
    .line 22: invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V
    .line 25: const-string v0, "side"
    .line 27: invoke-virtual {v14, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    .line 30: move-result-object v0
    .line 31: const-string v2, "BLACK"
    .line 33: invoke-static {v0, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 36: move-result v0
    .line 37: if-eqz v0, :cond_43
    .line 39: sget-object v0, Lp2/n;->j:Lp2/n;
    .line 41: move-object v8, v0
    .line 42: goto :goto_46
    .line 43: sget-object v0, Lp2/n;->i:Lp2/n;
    .line 45: goto :goto_41
    .line 46: new-instance v9, Lcom/titanchess/accessibility/a2;
    .line 48: const-string v0, "tcBase"
    .line 50: const/4 v10, -1
    .line 51: invoke-virtual {v14, v0, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    .line 54: move-result v4
    .line 55: const-string v0, "tcInc"
    .line 57: const/4 v11, 0
    .line 58: invoke-virtual {v14, v0, v11}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    .line 61: move-result v5
    .line 62: const-string v0, "clkWhiteMs"
    .line 64: invoke-virtual {v14, v0, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    .line 67: move-result v6
    .line 68: const-string v0, "clkBlackMs"
    .line 70: invoke-virtual {v14, v0, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    .line 73: move-result v7
    .line 74: move-object v0, v9
    .line 75: move-object v2, v13
    .line 76: move-object v3, v8
    .line 77: invoke-direct/range {v0 .. v7}, Lcom/titanchess/accessibility/a2;-><init>(Ljava/lang/String;Ljava/util/ArrayList;Lp2/n;IIII)V
    .line 80: iget-object v0, v12, Lcom/titanchess/accessibility/c2;->a:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 82: invoke-static {v0, v9}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$setSnap$p(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;)V
    .line 85: const-string v1, "src"
    .line 87: invoke-virtual {v14, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    .line 90: move-result-object v1
    .line 91: const-string v2, "vmSize"
    .line 93: invoke-virtual {v14, v2, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    .line 96: move-result v14
    .line 97: invoke-virtual {v13}, Ljava/util/ArrayList;->size()I
    .line 100: move-result v2
    .line 101: new-instance v3, Ljava/lang/StringBuilder;
    .line 103: const-string v4, "fen recv src="
    .line 105: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 108: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 111: const-string v1, " vmSize="
    .line 113: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 116: invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 119: const-string v14, " plies="
    .line 121: invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 124: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 127: const-string v14, " side="
    .line 129: invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 132: invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 135: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 138: move-result-object v14
    .line 139: const-string v1, "TitanA11y"
    .line 141: invoke-static {v1, v14}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 144: invoke-static {v0, v11}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$setRetryCount$p(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 147: invoke-virtual {v13}, Ljava/util/ArrayList;->size()I
    .line 150: move-result v13
    .line 151: const/4 v14, 1
    .line 152: if-gt v13, v14, :cond_203
    .line 154: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getOverlay$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Lcom/titanchess/accessibility/d;
    .line 157: move-result-object v13
    .line 158: if-eqz v13, :cond_163
    .line 160: invoke-virtual {v13}, Lcom/titanchess/accessibility/d;->a()V
    .line 163: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getOverlay$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Lcom/titanchess/accessibility/d;
    .line 166: move-result-object v13
    .line 167: const/4 v14, 0
    .line 168: if-eqz v13, :cond_180
    .line 170: iget-object v1, v13, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 172: if-nez v1, :cond_175
    .line 174: goto :goto_180
    .line 175: iput-object v14, v13, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 177: invoke-virtual {v13}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 180: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getOverlay$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Lcom/titanchess/accessibility/d;
    .line 183: move-result-object v13
    .line 184: if-eqz v13, :cond_196
    .line 186: iget-object v1, v13, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 188: if-nez v1, :cond_191
    .line 190: goto :goto_196
    .line 191: iput-object v14, v13, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 193: invoke-virtual {v13}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 196: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getAccCp$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Ljava/util/concurrent/ConcurrentHashMap;
    .line 199: move-result-object v13
    .line 200: invoke-virtual {v13}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V
    .line 203: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getBg$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Landroid/os/Handler;
    .line 206: move-result-object v13
    .line 207: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getDebounced$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Ljava/lang/Runnable;
    .line 210: move-result-object v14
    .line 211: invoke-virtual {v13, v14}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    .line 214: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getBg$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Landroid/os/Handler;
    .line 217: move-result-object v13
    .line 218: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getDebounced$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Ljava/lang/Runnable;
    .line 221: move-result-object v14
    .line 222: const-wide/16 v0, 20
    .line 224: invoke-virtual {v13, v14, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    .line 227: return-void
.end method

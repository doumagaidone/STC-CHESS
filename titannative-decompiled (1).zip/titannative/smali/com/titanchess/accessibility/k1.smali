.class public final Lcom/titanchess/accessibility/k1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final h:[Ls2/e;

.field public final a:Landroid/content/Context;
.field public final b:Lai/onnxruntime/OrtEnvironment;
.field public final c:Ljava/util/HashMap;
.field public final d:Ljava/util/LinkedHashMap;
.field public final e:Lcom/titanchess/accessibility/m1;
.field public f:Ljava/lang/String;
.field public g:Lcom/titanchess/accessibility/j1;

# direct methods
.method static constructor <clinit>()V
    .registers 14

    .line 0: const/16 v0, 1100
    .line 2: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 5: move-result-object v0
    .line 6: new-instance v1, Ls2/e;
    .line 8: const-string v2, "1100_1200"
    .line 10: invoke-direct {v1, v0, v2}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 13: const/16 v0, 1200
    .line 15: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 18: move-result-object v0
    .line 19: new-instance v2, Ls2/e;
    .line 21: const-string v3, "1200_1300"
    .line 23: invoke-direct {v2, v0, v3}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 26: const/16 v0, 1300
    .line 28: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 31: move-result-object v0
    .line 32: new-instance v3, Ls2/e;
    .line 34: const-string v4, "1300_1400"
    .line 36: invoke-direct {v3, v0, v4}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 39: const/16 v0, 1400
    .line 41: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 44: move-result-object v0
    .line 45: new-instance v4, Ls2/e;
    .line 47: const-string v5, "1400_1500"
    .line 49: invoke-direct {v4, v0, v5}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 52: const/16 v0, 1500
    .line 54: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 57: move-result-object v0
    .line 58: new-instance v5, Ls2/e;
    .line 60: const-string v6, "1500_1600"
    .line 62: invoke-direct {v5, v0, v6}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 65: const/16 v0, 1600
    .line 67: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 70: move-result-object v0
    .line 71: new-instance v6, Ls2/e;
    .line 73: const-string v7, "1600_1700"
    .line 75: invoke-direct {v6, v0, v7}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 78: const/16 v0, 1700
    .line 80: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 83: move-result-object v0
    .line 84: new-instance v7, Ls2/e;
    .line 86: const-string v8, "1700_1800"
    .line 88: invoke-direct {v7, v0, v8}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 91: const/16 v0, 1800
    .line 93: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 96: move-result-object v0
    .line 97: new-instance v8, Ls2/e;
    .line 99: const-string v9, "1800_1900"
    .line 101: invoke-direct {v8, v0, v9}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 104: const/16 v0, 1900
    .line 106: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 109: move-result-object v0
    .line 110: new-instance v9, Ls2/e;
    .line 112: const-string v10, "1900_2000"
    .line 114: invoke-direct {v9, v0, v10}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 117: const/16 v0, 2000
    .line 119: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 122: move-result-object v0
    .line 123: new-instance v10, Ls2/e;
    .line 125: const-string v11, "2000_2100"
    .line 127: invoke-direct {v10, v0, v11}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 130: const/16 v0, 2100
    .line 132: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 135: move-result-object v0
    .line 136: new-instance v11, Ls2/e;
    .line 138: const-string v12, "2100_2200"
    .line 140: invoke-direct {v11, v0, v12}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 143: const/16 v0, 2200
    .line 145: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 148: move-result-object v0
    .line 149: new-instance v12, Ls2/e;
    .line 151: const-string v13, "2200_3500"
    .line 153: invoke-direct {v12, v0, v13}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 156: filled-new-array/range {v1 .. v12}, [Ls2/e;
    .line 159: move-result-object v0
    .line 160: sput-object v0, Lcom/titanchess/accessibility/k1;->h:[Ls2/e;
    .line 162: return-void
.end method

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 7

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v6, v5, Lcom/titanchess/accessibility/k1;->a:Landroid/content/Context;
    .line 10: invoke-static {}, Lai/onnxruntime/OrtEnvironment;->getEnvironment()Lai/onnxruntime/OrtEnvironment;
    .line 13: move-result-object v6
    .line 14: iput-object v6, v5, Lcom/titanchess/accessibility/k1;->b:Lai/onnxruntime/OrtEnvironment;
    .line 16: new-instance v6, Ljava/util/HashMap;
    .line 18: invoke-direct {v6}, Ljava/util/HashMap;-><init>()V
    .line 21: const/4 v0, 0
    .line 22: move v1, v0
    .line 23: move v2, v1
    .line 24: const-string v3, "0123456789abcdefghpnrkqPBNRQKw."
    .line 26: invoke-virtual {v3}, Ljava/lang/String;->length()I
    .line 29: move-result v4
    .line 30: if-ge v1, v4, :cond_53
    .line 32: invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C
    .line 35: move-result v3
    .line 36: add-int/lit8 v4, v2, 1
    .line 38: invoke-static {v3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;
    .line 41: move-result-object v3
    .line 42: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 45: move-result-object v2
    .line 46: invoke-virtual {v6, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 49: add-int/lit8 v1, v1, 1
    .line 51: move v2, v4
    .line 52: goto :goto_24
    .line 53: iput-object v6, v5, Lcom/titanchess/accessibility/k1;->c:Ljava/util/HashMap;
    .line 55: iget-object v6, v5, Lcom/titanchess/accessibility/k1;->a:Landroid/content/Context;
    .line 57: invoke-virtual {v6}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 60: move-result-object v6
    .line 61: const-string v1, "mimic/actions.json"
    .line 63: invoke-virtual {v6, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 66: move-result-object v6
    .line 67: invoke-static {v6}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 70: invoke-static {v6}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 73: move-result-object v1
    .line 74: const/4 v2, 0
    .line 75: invoke-static {v6, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 78: new-instance v6, Ljava/lang/String;
    .line 80: sget-object v2, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 82: invoke-direct {v6, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 85: new-instance v1, Lorg/json/JSONArray;
    .line 87: invoke-direct {v1, v6}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V
    .line 90: invoke-virtual {v1}, Lorg/json/JSONArray;->length()I
    .line 93: move-result v6
    .line 94: new-instance v2, Ljava/util/ArrayList;
    .line 96: invoke-direct {v2, v6}, Ljava/util/ArrayList;-><init>(I)V
    .line 99: move v3, v0
    .line 100: if-ge v3, v6, :cond_112
    .line 102: invoke-virtual {v1, v3}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;
    .line 105: move-result-object v4
    .line 106: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 109: add-int/lit8 v3, v3, 1
    .line 111: goto :goto_100
    .line 112: new-instance v6, Lt2/v;
    .line 114: new-instance v1, Lt2/o;
    .line 116: invoke-direct {v1, v0, v2}, Lt2/o;-><init>(ILjava/lang/Object;)V
    .line 119: invoke-direct {v6, v1}, Lt2/v;-><init>(Lt2/o;)V
    .line 122: invoke-static {v6}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 125: move-result v0
    .line 126: invoke-static {v0}, Ld2/c;->f0(I)I
    .line 129: move-result v0
    .line 130: const/16 v1, 16
    .line 132: if-ge v0, v1, :cond_135
    .line 134: move v0, v1
    .line 135: new-instance v1, Ljava/util/LinkedHashMap;
    .line 137: invoke-direct {v1, v0}, Ljava/util/LinkedHashMap;-><init>(I)V
    .line 140: invoke-virtual {v6}, Lt2/v;->iterator()Ljava/util/Iterator;
    .line 143: move-result-object v6
    .line 144: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 147: move-result v0
    .line 148: if-eqz v0, :cond_170
    .line 150: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 153: move-result-object v0
    .line 154: check-cast v0, Lt2/u;
    .line 156: iget v2, v0, Lt2/u;->a:I
    .line 158: iget-object v0, v0, Lt2/u;->b:Ljava/lang/Object;
    .line 160: check-cast v0, Ljava/lang/String;
    .line 162: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 165: move-result-object v2
    .line 166: invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 169: goto :goto_144
    .line 170: iput-object v1, v5, Lcom/titanchess/accessibility/k1;->d:Ljava/util/LinkedHashMap;
    .line 172: new-instance v6, Lcom/titanchess/accessibility/m1;
    .line 174: iget-object v0, v5, Lcom/titanchess/accessibility/k1;->a:Landroid/content/Context;
    .line 176: invoke-direct {v6, v0}, Lcom/titanchess/accessibility/m1;-><init>(Landroid/content/Context;)V
    .line 179: iput-object v6, v5, Lcom/titanchess/accessibility/k1;->e:Lcom/titanchess/accessibility/m1;
    .line 181: return-void
    .line 182: move-exception v0
    .line 183: throw v0
    .line 184: move-exception v1
    .line 185: invoke-static {v6, v0}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 188: throw v1
.end method

# direct methods
.method public static final d(Lcom/titanchess/accessibility/k1;C)I
    .registers 4

    .line 0: iget-object v2, v2, Lcom/titanchess/accessibility/k1;->c:Ljava/util/HashMap;
    .line 2: invoke-static {v3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;
    .line 5: move-result-object v0
    .line 6: invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v2
    .line 10: check-cast v2, Ljava/lang/Integer;
    .line 12: if-eqz v2, :cond_19
    .line 14: invoke-virtual {v2}, Ljava/lang/Number;->intValue()I
    .line 17: move-result v2
    .line 18: return v2
    .line 19: new-instance v2, Ljava/lang/IllegalStateException;
    .line 21: new-instance v0, Ljava/lang/StringBuilder;
    .line 23: const-string v1, "bad fen char "
    .line 25: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 28: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 31: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 34: move-result-object v3
    .line 35: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 38: move-result-object v3
    .line 39: invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 42: throw v2
.end method

# virtual methods
.method public final declared-synchronized a(Ljava/lang/String;)Lcom/titanchess/accessibility/j1;
    .registers 14

    .line 0: const-string v0, "band loaded: "
    .line 2: monitor-enter v12
    .line 3: iget-object v1, v12, Lcom/titanchess/accessibility/k1;->g:Lcom/titanchess/accessibility/j1;
    .line 5: if-eqz v1, :cond_20
    .line 7: iget-object v2, v12, Lcom/titanchess/accessibility/k1;->f:Ljava/lang/String;
    .line 9: invoke-static {v2, v13}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 12: move-result v2
    .line 13: if-eqz v2, :cond_20
    .line 15: monitor-exit v12
    .line 16: return-object v1
    .line 17: move-exception v13
    .line 18: goto/16 :goto_158
    .line 20: iget-object v1, v12, Lcom/titanchess/accessibility/k1;->g:Lcom/titanchess/accessibility/j1;
    .line 22: if-eqz v1, :cond_34
    .line 24: iget-object v1, v1, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 26: invoke-virtual {v1}, Lai/onnxruntime/OrtSession;->close()V
    .line 29: goto :goto_34
    .line 30: move-exception v1
    .line 31: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 34: const/4 v1, 0
    .line 35: iput-object v1, v12, Lcom/titanchess/accessibility/k1;->g:Lcom/titanchess/accessibility/j1;
    .line 37: iput-object v1, v12, Lcom/titanchess/accessibility/k1;->f:Ljava/lang/String;
    .line 39: iget-object v2, v12, Lcom/titanchess/accessibility/k1;->e:Lcom/titanchess/accessibility/m1;
    .line 41: invoke-virtual {v2, v13, v1}, Lcom/titanchess/accessibility/m1;->b(Ljava/lang/String;Ld3/e;)Ls2/e;
    .line 44: move-result-object v1
    .line 45: iget-object v2, v1, Ls2/e;->i:Ljava/lang/Object;
    .line 47: check-cast v2, [B
    .line 49: iget-object v1, v1, Ls2/e;->j:Ljava/lang/Object;
    .line 51: check-cast v1, Ljava/lang/String;
    .line 53: iget-object v3, v12, Lcom/titanchess/accessibility/k1;->b:Lai/onnxruntime/OrtEnvironment;
    .line 55: new-instance v4, Lai/onnxruntime/OrtSession$SessionOptions;
    .line 57: invoke-direct {v4}, Lai/onnxruntime/OrtSession$SessionOptions;-><init>()V
    .line 60: const/4 v5, 4
    .line 61: invoke-virtual {v4, v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setIntraOpNumThreads(I)V
    .line 64: const-string v5, "intra_op_num_threads"
    .line 66: const-string v6, "4"
    .line 68: new-instance v7, Ls2/e;
    .line 70: invoke-direct {v7, v5, v6}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 73: invoke-static {v7}, Ld2/c;->g0(Ls2/e;)Ljava/util/Map;
    .line 76: move-result-object v5
    .line 77: invoke-virtual {v4, v5}, Lai/onnxruntime/OrtSession$SessionOptions;->addXnnpack(Ljava/util/Map;)V
    .line 80: sget-object v5, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->ALL_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 82: invoke-virtual {v4, v5}, Lai/onnxruntime/OrtSession$SessionOptions;->setOptimizationLevel(Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;)V
    .line 85: invoke-virtual {v3, v2, v4}, Lai/onnxruntime/OrtEnvironment;->createSession([BLai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .line 88: move-result-object v7
    .line 89: new-instance v2, Lorg/json/JSONObject;
    .line 91: invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    .line 94: const-string v1, "rating"
    .line 96: invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 99: move-result-object v1
    .line 100: const-string v3, "log_time"
    .line 102: invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 105: move-result-object v2
    .line 106: new-instance v3, Lcom/titanchess/accessibility/j1;
    .line 108: invoke-static {v7}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 111: const-string v4, "mean"
    .line 113: invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D
    .line 116: move-result-wide v4
    .line 117: double-to-float v8, v4
    .line 118: const-string v4, "std"
    .line 120: invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D
    .line 123: move-result-wide v4
    .line 124: double-to-float v9, v4
    .line 125: const-string v1, "mean"
    .line 127: invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D
    .line 130: move-result-wide v4
    .line 131: double-to-float v10, v4
    .line 132: const-string v1, "std"
    .line 134: invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D
    .line 137: move-result-wide v1
    .line 138: double-to-float v11, v1
    .line 139: move-object v6, v3
    .line 140: invoke-direct/range {v6 .. v11}, Lcom/titanchess/accessibility/j1;-><init>(Lai/onnxruntime/OrtSession;FFFF)V
    .line 143: iput-object v3, v12, Lcom/titanchess/accessibility/k1;->g:Lcom/titanchess/accessibility/j1;
    .line 145: iput-object v13, v12, Lcom/titanchess/accessibility/k1;->f:Ljava/lang/String;
    .line 147: const-string v1, "TitanMimic"
    .line 149: invoke-virtual {v0, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 152: move-result-object v13
    .line 153: invoke-static {v1, v13}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 156: monitor-exit v12
    .line 157: return-object v3
    .line 158: monitor-exit v12
    .line 159: throw v13
.end method

# virtual methods
.method public final declared-synchronized b(Ljava/lang/String;Ljava/util/List;IF)Ljava/util/List;
    .registers 25

    .line 0: move-object/from16 v1, v20
    .line 2: move-object/from16 v2, v21
    .line 4: move/from16 v0, v23
    .line 6: move/from16 v3, v24
    .line 8: monitor-enter v20
    .line 9: const-string v4, "fen"
    .line 11: invoke-static {v2, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: const-string v4, "history"
    .line 16: move-object/from16 v5, v22
    .line 18: invoke-static {v5, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 21: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 24: move-result-wide v6
    .line 25: const/16 v4, 2600
    .line 27: const/16 v8, 1100
    .line 29: invoke-static {v0, v8, v4}, Ld2/b;->G(III)I
    .line 32: move-result v9
    .line 33: sget-object v10, Lcom/titanchess/accessibility/k1;->h:[Ls2/e;
    .line 35: const/4 v12, 0
    .line 36: const/16 v13, 12
    .line 38: if-ge v12, v13, :cond_64
    .line 40: aget-object v14, v10, v12
    .line 42: iget-object v15, v14, Ls2/e;->i:Ljava/lang/Object;
    .line 44: check-cast v15, Ljava/lang/Number;
    .line 46: invoke-virtual {v15}, Ljava/lang/Number;->intValue()I
    .line 49: move-result v15
    .line 50: iget-object v14, v14, Ls2/e;->j:Ljava/lang/Object;
    .line 52: check-cast v14, Ljava/lang/String;
    .line 54: if-lt v9, v15, :cond_61
    .line 56: add-int/lit8 v15, v15, 100
    .line 58: if-ge v9, v15, :cond_61
    .line 60: goto :goto_73
    .line 61: add-int/lit8 v12, v12, 1
    .line 63: goto :goto_36
    .line 64: const/16 v9, 11
    .line 66: aget-object v9, v10, v9
    .line 68: iget-object v9, v9, Ls2/e;->j:Ljava/lang/Object;
    .line 70: move-object v14, v9
    .line 71: check-cast v14, Ljava/lang/String;
    .line 73: invoke-virtual {v1, v14}, Lcom/titanchess/accessibility/k1;->a(Ljava/lang/String;)Lcom/titanchess/accessibility/j1;
    .line 76: move-result-object v9
    .line 77: invoke-static/range {v22 .. v22}, Lt2/p;->Y1(Ljava/util/List;)Ljava/util/List;
    .line 80: move-result-object v10
    .line 81: new-instance v12, Ljava/util/ArrayList;
    .line 83: invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V
    .line 86: invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 89: move-result-object v10
    .line 90: invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z
    .line 93: move-result v14
    .line 94: const/4 v15, 0
    .line 95: if-eqz v14, :cond_132
    .line 97: invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 100: move-result-object v14
    .line 101: check-cast v14, Ljava/lang/String;
    .line 103: iget-object v11, v1, Lcom/titanchess/accessibility/k1;->d:Ljava/util/LinkedHashMap;
    .line 105: invoke-virtual {v11, v14}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 108: move-result-object v11
    .line 109: check-cast v11, Ljava/lang/Integer;
    .line 111: if-eqz v11, :cond_126
    .line 113: invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I
    .line 116: move-result v11
    .line 117: int-to-long v14, v11
    .line 118: invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 121: move-result-object v15
    .line 122: goto :goto_126
    .line 123: move-exception v0
    .line 124: goto/16 :goto_779
    .line 126: if-eqz v15, :cond_90
    .line 128: invoke-virtual {v12, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 131: goto :goto_90
    .line 132: new-array v10, v13, [J
    .line 134: const/4 v11, 0
    .line 135: if-ge v11, v13, :cond_144
    .line 137: const-wide/16 v16, 32
    .line 139: aput-wide v16, v10, v11
    .line 141: add-int/lit8 v11, v11, 1
    .line 143: goto :goto_135
    .line 144: invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 147: move-result-object v11
    .line 148: const/4 v14, 0
    .line 149: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 152: move-result v16
    .line 153: if-eqz v16, :cond_186
    .line 155: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 158: move-result-object v16
    .line 159: add-int/lit8 v17, v14, 1
    .line 161: if-ltz v14, :cond_182
    .line 163: check-cast v16, Ljava/lang/Number;
    .line 165: invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J
    .line 168: move-result-wide v18
    .line 169: invoke-virtual {v12}, Ljava/util/ArrayList;->size()I
    .line 172: move-result v16
    .line 173: rsub-int/lit8 v16, v16, 12
    .line 175: add-int v16, v16, v14
    .line 177: aput-wide v18, v10, v16
    .line 179: move/from16 v14, v17
    .line 181: goto :goto_149
    .line 182: invoke-static {}, Ld2/b;->g1()V
    .line 185: throw v15
    .line 186: invoke-virtual/range {v20 .. v21}, Lcom/titanchess/accessibility/k1;->c(Ljava/lang/String;)[J
    .line 189: move-result-object v11
    .line 190: invoke-static {v0, v8, v4}, Ld2/b;->G(III)I
    .line 193: move-result v0
    .line 194: int-to-float v0, v0
    .line 195: iget v4, v9, Lcom/titanchess/accessibility/j1;->b:F
    .line 197: sub-float/2addr v0, v4
    .line 198: iget v4, v9, Lcom/titanchess/accessibility/j1;->c:F
    .line 200: div-float/2addr v0, v4
    .line 201: const-wide/high16 v12, 0x3ff0
    .line 203: float-to-double v4, v3
    .line 204: add-double/2addr v4, v12
    .line 205: invoke-static {v4, v5}, Ljava/lang/Math;->log(D)D
    .line 208: move-result-wide v4
    .line 209: iget v8, v9, Lcom/titanchess/accessibility/j1;->d:F
    .line 211: float-to-double v12, v8
    .line 212: sub-double/2addr v4, v12
    .line 213: iget v8, v9, Lcom/titanchess/accessibility/j1;->e:F
    .line 215: float-to-double v12, v8
    .line 216: div-double/2addr v4, v12
    .line 217: const/4 v8, 4
    .line 218: new-array v8, v8, [Ls2/e;
    .line 220: const-string v12, "recent_moves"
    .line 222: iget-object v13, v1, Lcom/titanchess/accessibility/k1;->b:Lai/onnxruntime/OrtEnvironment;
    .line 224: invoke-static {v10}, Ljava/nio/LongBuffer;->wrap([J)Ljava/nio/LongBuffer;
    .line 227: move-result-object v10
    .line 228: const/4 v14, 2
    .line 229: new-array v15, v14, [J
    .line 231: fill-array-data v15, :data_782
    .line 234: invoke-static {v13, v10, v15}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/LongBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 237: move-result-object v10
    .line 238: new-instance v13, Ls2/e;
    .line 240: invoke-direct {v13, v12, v10}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 243: const/4 v10, 0
    .line 244: aput-object v13, v8, v10
    .line 246: const-string v10, "board"
    .line 248: iget-object v12, v1, Lcom/titanchess/accessibility/k1;->b:Lai/onnxruntime/OrtEnvironment;
    .line 250: invoke-static {v11}, Ljava/nio/LongBuffer;->wrap([J)Ljava/nio/LongBuffer;
    .line 253: move-result-object v11
    .line 254: new-array v13, v14, [J
    .line 256: fill-array-data v13, :data_794
    .line 259: invoke-static {v12, v11, v13}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/LongBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 262: move-result-object v11
    .line 263: new-instance v12, Ls2/e;
    .line 265: invoke-direct {v12, v10, v11}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 268: const/4 v10, 1
    .line 269: aput-object v12, v8, v10
    .line 271: const-string v11, "rating"
    .line 273: iget-object v12, v1, Lcom/titanchess/accessibility/k1;->b:Lai/onnxruntime/OrtEnvironment;
    .line 275: new-array v13, v10, [F
    .line 277: const/4 v15, 0
    .line 278: aput v0, v13, v15
    .line 280: invoke-static {v13}, Ljava/nio/FloatBuffer;->wrap([F)Ljava/nio/FloatBuffer;
    .line 283: move-result-object v0
    .line 284: new-array v13, v10, [J
    .line 286: const-wide/16 v17, 1
    .line 288: aput-wide v17, v13, v15
    .line 290: invoke-static {v12, v0, v13}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/FloatBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 293: move-result-object v0
    .line 294: new-instance v12, Ls2/e;
    .line 296: invoke-direct {v12, v11, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 299: aput-object v12, v8, v14
    .line 301: const-string v0, "clock"
    .line 303: iget-object v11, v1, Lcom/titanchess/accessibility/k1;->b:Lai/onnxruntime/OrtEnvironment;
    .line 305: new-array v12, v10, [F
    .line 307: double-to-float v4, v4
    .line 308: const/4 v5, 0
    .line 309: aput v4, v12, v5
    .line 311: invoke-static {v12}, Ljava/nio/FloatBuffer;->wrap([F)Ljava/nio/FloatBuffer;
    .line 314: move-result-object v4
    .line 315: new-array v10, v10, [J
    .line 317: aput-wide v17, v10, v5
    .line 319: invoke-static {v11, v4, v10}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/FloatBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 322: move-result-object v4
    .line 323: new-instance v5, Ls2/e;
    .line 325: invoke-direct {v5, v0, v4}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 328: const/4 v4, 3
    .line 329: aput-object v5, v8, v4
    .line 331: invoke-static {v8}, Lt2/k;->W0([Ls2/e;)Ljava/util/Map;
    .line 334: move-result-object v0
    .line 335: iget-object v5, v9, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 337: invoke-virtual {v5, v0}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .line 340: move-result-object v5
    .line 341: const-string v8, "logits"
    .line 343: invoke-virtual {v5, v8}, Lai/onnxruntime/OrtSession$Result;->get(Ljava/lang/String;)Ljava/util/Optional;
    .line 346: move-result-object v8
    .line 347: invoke-virtual {v8}, Ljava/util/Optional;->get()Ljava/lang/Object;
    .line 350: move-result-object v8
    .line 351: const-string v9, "null cannot be cast to non-null type ai.onnxruntime.OnnxTensor"
    .line 353: invoke-static {v8, v9}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 356: check-cast v8, Lai/onnxruntime/OnnxTensor;
    .line 358: invoke-virtual {v8}, Lai/onnxruntime/OnnxTensor;->getFloatBuffer()Ljava/nio/FloatBuffer;
    .line 361: move-result-object v8
    .line 362: invoke-virtual {v8}, Ljava/nio/Buffer;->remaining()I
    .line 365: move-result v9
    .line 366: new-array v9, v9, [F
    .line 368: invoke-virtual {v8, v9}, Ljava/nio/FloatBuffer;->get([F)Ljava/nio/FloatBuffer;
    .line 371: invoke-virtual {v5}, Lai/onnxruntime/OrtSession$Result;->close()V
    .line 374: invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 377: move-result-object v0
    .line 378: check-cast v0, Ljava/lang/Iterable;
    .line 380: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 383: move-result-object v5
    .line 384: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 387: move-result v0
    .line 388: if-eqz v0, :cond_406
    .line 390: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 393: move-result-object v0
    .line 394: check-cast v0, Lai/onnxruntime/OnnxTensor;
    .line 396: invoke-virtual {v0}, Lai/onnxruntime/OnnxTensor;->close()V
    .line 399: goto :goto_384
    .line 400: move-exception v0
    .line 401: move-object v8, v0
    .line 402: invoke-static {v8}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 405: goto :goto_384
    .line 406: new-instance v0, Lp2/e;
    .line 408: invoke-direct {v0}, Lp2/e;-><init>()V
    .line 411: invoke-virtual {v0, v2}, Lp2/e;->n(Ljava/lang/String;)V
    .line 414: invoke-static {v0}, Ld2/b;->j0(Lp2/e;)Ljava/util/LinkedList;
    .line 417: move-result-object v0
    .line 418: new-instance v2, Ljava/util/ArrayList;
    .line 420: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 423: move-result v5
    .line 424: invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V
    .line 427: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 430: move-result-object v0
    .line 431: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 434: move-result v5
    .line 435: if-eqz v5, :cond_451
    .line 437: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 440: move-result-object v5
    .line 441: check-cast v5, Lr2/a;
    .line 443: invoke-virtual {v5}, Lr2/a;->toString()Ljava/lang/String;
    .line 446: move-result-object v5
    .line 447: invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 450: goto :goto_431
    .line 451: invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z
    .line 454: move-result v0
    .line 455: if-eqz v0, :cond_461
    .line 457: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 459: monitor-exit v20
    .line 460: return-object v0
    .line 461: new-instance v0, Ljava/util/ArrayList;
    .line 463: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 466: invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 469: move-result-object v2
    .line 470: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 473: move-result v5
    .line 474: if-eqz v5, :cond_515
    .line 476: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 479: move-result-object v5
    .line 480: check-cast v5, Ljava/lang/String;
    .line 482: iget-object v8, v1, Lcom/titanchess/accessibility/k1;->d:Ljava/util/LinkedHashMap;
    .line 484: invoke-virtual {v8, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 487: move-result-object v8
    .line 488: check-cast v8, Ljava/lang/Integer;
    .line 490: if-eqz v8, :cond_508
    .line 492: invoke-virtual {v8}, Ljava/lang/Number;->intValue()I
    .line 495: move-result v8
    .line 496: aget v8, v9, v8
    .line 498: invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 501: move-result-object v8
    .line 502: new-instance v10, Ls2/e;
    .line 504: invoke-direct {v10, v5, v8}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 507: goto :goto_509
    .line 508: const/4 v10, 0
    .line 509: if-eqz v10, :cond_470
    .line 511: invoke-virtual {v0, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 514: goto :goto_470
    .line 515: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 518: move-result-object v2
    .line 519: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 522: move-result v5
    .line 523: if-eqz v5, :cond_773
    .line 525: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 528: move-result-object v5
    .line 529: check-cast v5, Ls2/e;
    .line 531: iget-object v5, v5, Ls2/e;->j:Ljava/lang/Object;
    .line 533: check-cast v5, Ljava/lang/Number;
    .line 535: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 538: move-result v5
    .line 539: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 542: move-result v8
    .line 543: if-eqz v8, :cond_564
    .line 545: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 548: move-result-object v8
    .line 549: check-cast v8, Ls2/e;
    .line 551: iget-object v8, v8, Ls2/e;->j:Ljava/lang/Object;
    .line 553: check-cast v8, Ljava/lang/Number;
    .line 555: invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F
    .line 558: move-result v8
    .line 559: invoke-static {v5, v8}, Ljava/lang/Math;->max(FF)F
    .line 562: move-result v5
    .line 563: goto :goto_539
    .line 564: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 567: move-result-object v2
    .line 568: const-wide/16 v8, 0
    .line 570: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 573: move-result v10
    .line 574: if-eqz v10, :cond_598
    .line 576: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 579: move-result-object v10
    .line 580: check-cast v10, Ls2/e;
    .line 582: iget-object v10, v10, Ls2/e;->j:Ljava/lang/Object;
    .line 584: check-cast v10, Ljava/lang/Number;
    .line 586: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 589: move-result v10
    .line 590: sub-float/2addr v10, v5
    .line 591: float-to-double v10, v10
    .line 592: invoke-static {v10, v11}, Ljava/lang/Math;->exp(D)D
    .line 595: move-result-wide v10
    .line 596: add-double/2addr v8, v10
    .line 597: goto :goto_570
    .line 598: new-instance v2, Ljava/util/ArrayList;
    .line 600: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 603: move-result v10
    .line 604: invoke-direct {v2, v10}, Ljava/util/ArrayList;-><init>(I)V
    .line 607: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 610: move-result-object v0
    .line 611: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 614: move-result v10
    .line 615: if-eqz v10, :cond_654
    .line 617: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 620: move-result-object v10
    .line 621: check-cast v10, Ls2/e;
    .line 623: iget-object v11, v10, Ls2/e;->i:Ljava/lang/Object;
    .line 625: iget-object v10, v10, Ls2/e;->j:Ljava/lang/Object;
    .line 627: check-cast v10, Ljava/lang/Number;
    .line 629: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 632: move-result v10
    .line 633: sub-float/2addr v10, v5
    .line 634: float-to-double v12, v10
    .line 635: invoke-static {v12, v13}, Ljava/lang/Math;->exp(D)D
    .line 638: move-result-wide v12
    .line 639: div-double/2addr v12, v8
    .line 640: double-to-float v10, v12
    .line 641: invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 644: move-result-object v10
    .line 645: new-instance v12, Ls2/e;
    .line 647: invoke-direct {v12, v11, v10}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 650: invoke-virtual {v2, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 653: goto :goto_611
    .line 654: new-instance v0, Lu/r;
    .line 656: const/4 v5, 6
    .line 657: invoke-direct {v0, v5}, Lu/r;-><init>(I)V
    .line 660: invoke-static {v2, v0}, Lt2/p;->W1(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;
    .line 663: move-result-object v0
    .line 664: invoke-static {v0, v4}, Lt2/p;->X1(Ljava/lang/Iterable;I)Ljava/util/List;
    .line 667: move-result-object v0
    .line 668: const-string v2, "TitanMimic"
    .line 670: iget-object v4, v1, Lcom/titanchess/accessibility/k1;->f:Ljava/lang/String;
    .line 672: invoke-interface/range {v22 .. v22}, Ljava/util/List;->size()I
    .line 675: move-result v5
    .line 676: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 679: move-result-wide v8
    .line 680: sub-long/2addr v8, v6
    .line 681: const v6, 0xf4240
    .line 684: int-to-long v6, v6
    .line 685: div-long/2addr v8, v6
    .line 686: new-instance v6, Ljava/util/ArrayList;
    .line 688: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 691: move-result v7
    .line 692: invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V
    .line 695: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 698: move-result-object v7
    .line 699: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 702: move-result v10
    .line 703: if-eqz v10, :cond_719
    .line 705: invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 708: move-result-object v10
    .line 709: check-cast v10, Ls2/e;
    .line 711: iget-object v10, v10, Ls2/e;->i:Ljava/lang/Object;
    .line 713: check-cast v10, Ljava/lang/String;
    .line 715: invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 718: goto :goto_699
    .line 719: new-instance v7, Ljava/lang/StringBuilder;
    .line 721: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    .line 724: const-string v10, "band="
    .line 726: invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 729: invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 732: const-string v4, " plies="
    .line 734: invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 737: invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 740: const-string v4, " clk="
    .line 742: invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 745: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 748: const-string v3, "s ms="
    .line 750: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 753: invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 756: const-string v3, " top="
    .line 758: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 761: invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 764: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 767: move-result-object v3
    .line 768: invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 771: monitor-exit v20
    .line 772: return-object v0
    .line 773: new-instance v0, Ljava/util/NoSuchElementException;
    .line 775: invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V
    .line 778: throw v0
    .line 779: monitor-exit v20
    .line 780: throw v0
    .line 781: nop
    .line 782: nop
    .line 783: move-object/from16 v0, v2
    .line 785: nop
    .line 786: move v0, v0
    .line 787: nop
    .line 788: nop
    .line 789: nop
    .line 790: move-result-object v0
    .line 791: nop
    .line 792: nop
    .line 793: nop
    .line 794: nop
    .line 795: move-object/from16 v0, v2
    .line 797: nop
    .line 798: move v0, v0
    .line 799: nop
    .line 800: nop
    .line 801: nop
    .line 802: aput-boolean v0, v0, v0
    .line 804: nop
    .line 805: nop
.end method

# virtual methods
.method public final c(Ljava/lang/String;)[J
    .registers 18

    .line 0: move-object/from16 v0, v16
    .line 2: const-string v1, " "
    .line 4: filled-new-array {v1}, [Ljava/lang/String;
    .line 7: move-result-object v1
    .line 8: move-object/from16 v2, v17
    .line 10: invoke-static {v2, v1}, Lm3/j;->e2(Ljava/lang/CharSequence;[Ljava/lang/String;)Ljava/util/List;
    .line 13: move-result-object v1
    .line 14: const/4 v2, 0
    .line 15: invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 18: move-result-object v3
    .line 19: check-cast v3, Ljava/lang/String;
    .line 21: const/4 v4, 1
    .line 22: invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 25: move-result-object v4
    .line 26: check-cast v4, Ljava/lang/String;
    .line 28: const/4 v5, 2
    .line 29: invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 32: move-result-object v6
    .line 33: check-cast v6, Ljava/lang/String;
    .line 35: const/4 v7, 3
    .line 36: invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 39: move-result-object v7
    .line 40: check-cast v7, Ljava/lang/String;
    .line 42: const/4 v8, 4
    .line 43: invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 46: move-result-object v9
    .line 47: check-cast v9, Ljava/lang/String;
    .line 49: const/4 v10, 5
    .line 50: invoke-interface {v1, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 53: move-result-object v1
    .line 54: check-cast v1, Ljava/lang/String;
    .line 56: new-instance v10, Ljava/util/ArrayList;
    .line 58: const/16 v11, 78
    .line 60: invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V
    .line 63: const/16 v12, 46
    .line 65: invoke-static {v0, v12}, Lcom/titanchess/accessibility/k1;->d(Lcom/titanchess/accessibility/k1;C)I
    .line 68: move-result v12
    .line 69: const-string v13, "/"
    .line 71: const-string v14, ""
    .line 73: invoke-static {v3, v13, v14}, Lm3/j;->a2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 76: move-result-object v3
    .line 77: new-instance v13, Ljava/lang/StringBuilder;
    .line 79: invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V
    .line 82: invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 85: invoke-virtual {v13, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 88: invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 91: move-result-object v3
    .line 92: invoke-virtual {v3}, Ljava/lang/String;->length()I
    .line 95: move-result v4
    .line 96: move v13, v2
    .line 97: if-ge v13, v4, :cond_142
    .line 99: invoke-virtual {v3, v13}, Ljava/lang/String;->charAt(I)C
    .line 102: move-result v14
    .line 103: const/16 v15, 49
    .line 105: if-gt v15, v14, :cond_127
    .line 107: const/16 v15, 57
    .line 109: if-ge v14, v15, :cond_127
    .line 111: add-int/lit8 v14, v14, -48
    .line 113: move v15, v2
    .line 114: if-ge v15, v14, :cond_138
    .line 116: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 119: move-result-object v2
    .line 120: invoke-virtual {v10, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 123: add-int/lit8 v15, v15, 1
    .line 125: const/4 v2, 0
    .line 126: goto :goto_114
    .line 127: invoke-static {v0, v14}, Lcom/titanchess/accessibility/k1;->d(Lcom/titanchess/accessibility/k1;C)I
    .line 130: move-result v2
    .line 131: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 134: move-result-object v2
    .line 135: invoke-virtual {v10, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 138: add-int/lit8 v13, v13, 1
    .line 140: const/4 v2, 0
    .line 141: goto :goto_97
    .line 142: const-string v2, "-"
    .line 144: invoke-static {v6, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 147: move-result v3
    .line 148: if-eqz v3, :cond_163
    .line 150: const/4 v3, 0
    .line 151: if-ge v3, v8, :cond_206
    .line 153: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 156: move-result-object v4
    .line 157: invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 160: add-int/lit8 v3, v3, 1
    .line 162: goto :goto_151
    .line 163: const/4 v3, 0
    .line 164: invoke-virtual {v6}, Ljava/lang/String;->length()I
    .line 167: move-result v4
    .line 168: if-ge v3, v4, :cond_188
    .line 170: invoke-virtual {v6, v3}, Ljava/lang/String;->charAt(I)C
    .line 173: move-result v4
    .line 174: invoke-static {v0, v4}, Lcom/titanchess/accessibility/k1;->d(Lcom/titanchess/accessibility/k1;C)I
    .line 177: move-result v4
    .line 178: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 181: move-result-object v4
    .line 182: invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 185: add-int/lit8 v3, v3, 1
    .line 187: goto :goto_164
    .line 188: invoke-virtual {v6}, Ljava/lang/String;->length()I
    .line 191: move-result v3
    .line 192: sub-int/2addr v8, v3
    .line 193: const/4 v3, 0
    .line 194: if-ge v3, v8, :cond_206
    .line 196: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 199: move-result-object v4
    .line 200: invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 203: add-int/lit8 v3, v3, 1
    .line 205: goto :goto_194
    .line 206: invoke-static {v7, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 209: move-result v2
    .line 210: if-eqz v2, :cond_225
    .line 212: const/4 v2, 0
    .line 213: if-ge v2, v5, :cond_250
    .line 215: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 218: move-result-object v3
    .line 219: invoke-virtual {v10, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 222: add-int/lit8 v2, v2, 1
    .line 224: goto :goto_213
    .line 225: const/4 v2, 0
    .line 226: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 229: move-result v3
    .line 230: if-ge v2, v3, :cond_250
    .line 232: invoke-virtual {v7, v2}, Ljava/lang/String;->charAt(I)C
    .line 235: move-result v3
    .line 236: invoke-static {v0, v3}, Lcom/titanchess/accessibility/k1;->d(Lcom/titanchess/accessibility/k1;C)I
    .line 239: move-result v3
    .line 240: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 243: move-result-object v3
    .line 244: invoke-virtual {v10, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 247: add-int/lit8 v2, v2, 1
    .line 249: goto :goto_226
    .line 250: invoke-static {v9}, Lm3/j;->U1(Ljava/lang/String;)Ljava/lang/String;
    .line 253: move-result-object v2
    .line 254: const/4 v3, 0
    .line 255: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 258: move-result v4
    .line 259: if-ge v3, v4, :cond_279
    .line 261: invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C
    .line 264: move-result v4
    .line 265: invoke-static {v0, v4}, Lcom/titanchess/accessibility/k1;->d(Lcom/titanchess/accessibility/k1;C)I
    .line 268: move-result v4
    .line 269: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 272: move-result-object v4
    .line 273: invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 276: add-int/lit8 v3, v3, 1
    .line 278: goto :goto_255
    .line 279: invoke-static {v1}, Lm3/j;->U1(Ljava/lang/String;)Ljava/lang/String;
    .line 282: move-result-object v1
    .line 283: const/4 v2, 0
    .line 284: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 287: move-result v3
    .line 288: if-ge v2, v3, :cond_308
    .line 290: invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C
    .line 293: move-result v3
    .line 294: invoke-static {v0, v3}, Lcom/titanchess/accessibility/k1;->d(Lcom/titanchess/accessibility/k1;C)I
    .line 297: move-result v3
    .line 298: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 301: move-result-object v3
    .line 302: invoke-virtual {v10, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 305: add-int/lit8 v2, v2, 1
    .line 307: goto :goto_284
    .line 308: const/16 v1, 31
    .line 310: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 313: move-result-object v1
    .line 314: invoke-virtual {v10, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 317: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    .line 320: move-result v1
    .line 321: if-ne v1, v11, :cond_345
    .line 323: new-array v1, v11, [J
    .line 325: const/4 v2, 0
    .line 326: if-ge v2, v11, :cond_344
    .line 328: invoke-virtual {v10, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 331: move-result-object v3
    .line 332: check-cast v3, Ljava/lang/Number;
    .line 334: invoke-virtual {v3}, Ljava/lang/Number;->intValue()I
    .line 337: move-result v3
    .line 338: int-to-long v3, v3
    .line 339: aput-wide v3, v1, v2
    .line 341: add-int/lit8 v2, v2, 1
    .line 343: goto :goto_326
    .line 344: return-object v1
    .line 345: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    .line 348: move-result v1
    .line 349: const-string v2, "fen token len "
    .line 351: invoke-static {v2, v1}, Lai/onnxruntime/b;->f(Ljava/lang/String;I)Ljava/lang/String;
    .line 354: move-result-object v1
    .line 355: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 357: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 360: move-result-object v1
    .line 361: invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 364: throw v2
.end method

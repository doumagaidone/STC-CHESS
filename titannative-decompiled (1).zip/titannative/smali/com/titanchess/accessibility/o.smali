.class public final synthetic Lcom/titanchess/accessibility/o;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/View$OnClickListener;

.field public final synthetic a:Lcom/titanchess/accessibility/s;
.field public final synthetic b:Landroid/widget/TextView;

# direct methods
.method public synthetic constructor <init>(Lcom/titanchess/accessibility/s;Landroid/widget/TextView;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/o;->a:Lcom/titanchess/accessibility/s;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/o;->b:Landroid/widget/TextView;
    .line 7: return-void
.end method

# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    .line 0: const-string v6, "this$0"
    .line 2: iget-object v0, v5, Lcom/titanchess/accessibility/o;->a:Lcom/titanchess/accessibility/s;
    .line 4: invoke-static {v0, v6}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: const-string v6, "$btn"
    .line 9: iget-object v1, v5, Lcom/titanchess/accessibility/o;->b:Landroid/widget/TextView;
    .line 11: invoke-static {v1, v6}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: iget-object v6, v0, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 16: const-string v2, "arrow_on"
    .line 18: const/4 v3, 1
    .line 19: invoke-interface {v6, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 22: move-result v4
    .line 23: xor-int/2addr v3, v4
    .line 24: invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 27: move-result-object v6
    .line 28: invoke-interface {v6, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    .line 31: move-result-object v6
    .line 32: invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 35: if-eqz v3, :cond_40
    .line 37: const-string v6, "ON"
    .line 39: goto :goto_42
    .line 40: const-string v6, "OFF"
    .line 42: invoke-virtual {v1, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 45: iget v6, v0, Lcom/titanchess/accessibility/s;->o:I
    .line 47: if-eqz v3, :cond_52
    .line 49: iget v2, v0, Lcom/titanchess/accessibility/s;->m:I
    .line 51: goto :goto_53
    .line 52: move v2, v6
    .line 53: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V
    .line 56: const/high16 v2, 0x4110
    .line 58: invoke-virtual {v0, v2}, Lcom/titanchess/accessibility/s;->c(F)I
    .line 61: move-result v2
    .line 62: int-to-float v2, v2
    .line 63: if-eqz v3, :cond_68
    .line 65: iget v4, v0, Lcom/titanchess/accessibility/s;->r:I
    .line 67: goto :goto_70
    .line 68: iget v4, v0, Lcom/titanchess/accessibility/s;->q:I
    .line 70: if-eqz v3, :cond_74
    .line 72: iget v6, v0, Lcom/titanchess/accessibility/s;->p:I
    .line 74: invoke-virtual {v0, v2, v4, v6}, Lcom/titanchess/accessibility/s;->f(FII)Landroid/graphics/drawable/GradientDrawable;
    .line 77: move-result-object v6
    .line 78: invoke-virtual {v1, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    .line 81: return-void
.end method

.class public final Lcom/titanchess/accessibility/t;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:I
.field public final c:D
.field public final d:I

# direct methods
.method public constructor <init>(Ljava/lang/String;IDI)V
    .registers 7

    .line 0: const-string v0, "move"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 10: iput v3, v1, Lcom/titanchess/accessibility/t;->b:I
    .line 12: iput-wide v4, v1, Lcom/titanchess/accessibility/t;->c:D
    .line 14: iput v6, v1, Lcom/titanchess/accessibility/t;->d:I
    .line 16: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/t;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/t;
    .line 12: iget-object v1, v8, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 14: iget-object v3, v7, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v7, Lcom/titanchess/accessibility/t;->b:I
    .line 25: iget v3, v8, Lcom/titanchess/accessibility/t;->b:I
    .line 27: if-eq v1, v3, :cond_30
    .line 29: return v2
    .line 30: iget-wide v3, v7, Lcom/titanchess/accessibility/t;->c:D
    .line 32: iget-wide v5, v8, Lcom/titanchess/accessibility/t;->c:D
    .line 34: invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I
    .line 37: move-result v1
    .line 38: if-eqz v1, :cond_41
    .line 40: return v2
    .line 41: iget v1, v7, Lcom/titanchess/accessibility/t;->d:I
    .line 43: iget v8, v8, Lcom/titanchess/accessibility/t;->d:I
    .line 45: if-eq v1, v8, :cond_48
    .line 47: return v2
    .line 48: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 5

    .line 0: iget-object v0, v4, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v4, Lcom/titanchess/accessibility/t;->b:I
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 14: move-result v0
    .line 15: iget-wide v2, v4, Lcom/titanchess/accessibility/t;->c:D
    .line 17: invoke-static {v2, v3}, Ljava/lang/Double;->hashCode(D)I
    .line 20: move-result v2
    .line 21: add-int/2addr v2, v0
    .line 22: mul-int/2addr v2, v1
    .line 23: iget v0, v4, Lcom/titanchess/accessibility/t;->d:I
    .line 25: invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I
    .line 28: move-result v0
    .line 29: add-int/2addr v0, v2
    .line 30: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Arrow(move="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", rank="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v3, Lcom/titanchess/accessibility/t;->b:I
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", prob="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-wide v1, v3, Lcom/titanchess/accessibility/t;->c:D
    .line 29: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", cpLoss="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v3, Lcom/titanchess/accessibility/t;->d:I
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ")"
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v0
    .line 51: return-object v0
.end method

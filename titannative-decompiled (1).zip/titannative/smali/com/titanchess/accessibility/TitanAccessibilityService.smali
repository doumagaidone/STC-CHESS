.class public final Lcom/titanchess/accessibility/TitanAccessibilityService;
.super Landroid/accessibilityservice/AccessibilityService;
.source "SourceFile"

.field public static final $stable:I
.field public static final ACTION_FLOAT_SYNC:Ljava/lang/String;
.field private static final ACTION_POSITION:Ljava/lang/String;
.field private static final CHESS_PKG:Ljava/lang/String;
.field private static final COORD_MIN_MS:J
.field public static final Companion:Lcom/titanchess/accessibility/z1;
.field private static final DEBOUNCE_MS:J
.field private static final INSTRUMENT:Z
.field private static final PROBE_NODES:I
.field private static final SQUARE:Lm3/f;
.field private static final TAG:Ljava/lang/String;

.field private final LIC_RECHECK_MS:J
.field private final accCp:Ljava/util/concurrent/ConcurrentHashMap;
.field private volatile avatarBottom:Ls2/e;
.field private volatile avatarTop:Ls2/e;
.field private final bg:Landroid/os/Handler;
.field private volatile boardPx:F
.field private final brain$delegate:Ls2/b;
.field private volatile busy:Z
.field private cBestStreak:I
.field private volatile cCalLoaded:Z
.field private cLastGameKey:Ljava/lang/String;
.field private volatile centers:Ljava/util/Map;
.field private final computeThread:Landroid/os/HandlerThread;
.field private final coordWorker:Ljava/util/concurrent/ExecutorService;
.field private volatile coordsReadyOnce:Z
.field private final debounced:Ljava/lang/Runnable;
.field private final evalWorker:Ljava/util/concurrent/ExecutorService;
.field private final fenReceiver:Lcom/titanchess/accessibility/c2;
.field private final floatSyncReceiver:Lcom/titanchess/accessibility/d2;
.field private floating:Lcom/titanchess/accessibility/s;
.field private volatile lastComputed:Ljava/lang/String;
.field private lastCoordMs:J
.field private volatile lastLicCheckMs:J
.field private final licWorker:Ljava/util/concurrent/ExecutorService;
.field private final main:Landroid/os/Handler;
.field private final mimic$delegate:Ls2/b;
.field private volatile mySide:Lp2/n;
.field private overlay:Lcom/titanchess/accessibility/d;
.field private volatile retryCount:I
.field private final sf$delegate:Ls2/b;
.field private volatile snap:Lcom/titanchess/accessibility/a2;
.field private final worker:Ljava/util/concurrent/ExecutorService;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Lcom/titanchess/accessibility/z1;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->Companion:Lcom/titanchess/accessibility/z1;
    .line 7: new-instance v0, Lm3/f;
    .line 9: const-string v1, "[a-h][1-8]"
    .line 11: invoke-direct {v0, v1}, Lm3/f;-><init>(Ljava/lang/String;)V
    .line 14: sput-object v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->SQUARE:Lm3/f;
    .line 16: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 5

    .line 0: invoke-direct {v4}, Landroid/accessibilityservice/AccessibilityService;-><init>()V
    .line 3: new-instance v0, Landroid/os/Handler;
    .line 5: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    .line 8: move-result-object v1
    .line 9: invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    .line 12: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 14: new-instance v0, Landroid/os/HandlerThread;
    .line 16: const-string v1, "titan-compute"
    .line 18: invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V
    .line 21: invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    .line 24: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->computeThread:Landroid/os/HandlerThread;
    .line 26: new-instance v1, Landroid/os/Handler;
    .line 28: invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;
    .line 31: move-result-object v0
    .line 32: invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    .line 35: iput-object v1, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 37: invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;
    .line 40: move-result-object v0
    .line 41: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->worker:Ljava/util/concurrent/ExecutorService;
    .line 43: invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;
    .line 46: move-result-object v0
    .line 47: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->coordWorker:Ljava/util/concurrent/ExecutorService;
    .line 49: invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;
    .line 52: move-result-object v0
    .line 53: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->evalWorker:Ljava/util/concurrent/ExecutorService;
    .line 55: new-instance v0, Lcom/titanchess/accessibility/b2;
    .line 57: const/4 v1, 0
    .line 58: invoke-direct {v0, v4, v1}, Lcom/titanchess/accessibility/b2;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 61: new-instance v2, Ls2/h;
    .line 63: invoke-direct {v2, v0}, Ls2/h;-><init>(Ld3/a;)V
    .line 66: iput-object v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->brain$delegate:Ls2/b;
    .line 68: new-instance v0, Lcom/titanchess/accessibility/b2;
    .line 70: const/4 v2, 1
    .line 71: invoke-direct {v0, v4, v2}, Lcom/titanchess/accessibility/b2;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 74: new-instance v2, Ls2/h;
    .line 76: invoke-direct {v2, v0}, Ls2/h;-><init>(Ld3/a;)V
    .line 79: iput-object v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->mimic$delegate:Ls2/b;
    .line 81: new-instance v0, Lcom/titanchess/accessibility/b2;
    .line 83: const/4 v2, 2
    .line 84: invoke-direct {v0, v4, v2}, Lcom/titanchess/accessibility/b2;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 87: new-instance v2, Ls2/h;
    .line 89: invoke-direct {v2, v0}, Ls2/h;-><init>(Ld3/a;)V
    .line 92: iput-object v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->sf$delegate:Ls2/b;
    .line 94: invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;
    .line 97: move-result-object v0
    .line 98: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->licWorker:Ljava/util/concurrent/ExecutorService;
    .line 100: const-wide/32 v2, 0x1b7740
    .line 103: iput-wide v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->LIC_RECHECK_MS:J
    .line 105: sget-object v0, Lt2/s;->i:Lt2/s;
    .line 107: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 109: sget-object v0, Lp2/n;->i:Lp2/n;
    .line 111: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->mySide:Lp2/n;
    .line 113: const-string v0, ""
    .line 115: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastComputed:Ljava/lang/String;
    .line 117: new-instance v2, Ljava/util/concurrent/ConcurrentHashMap;
    .line 119: invoke-direct {v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V
    .line 122: iput-object v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->accCp:Ljava/util/concurrent/ConcurrentHashMap;
    .line 124: new-instance v2, Lcom/titanchess/accessibility/v1;
    .line 126: invoke-direct {v2, v4, v1}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 129: iput-object v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 131: new-instance v1, Lcom/titanchess/accessibility/d2;
    .line 133: invoke-direct {v1, v4}, Lcom/titanchess/accessibility/d2;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 136: iput-object v1, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->floatSyncReceiver:Lcom/titanchess/accessibility/d2;
    .line 138: new-instance v1, Lcom/titanchess/accessibility/c2;
    .line 140: invoke-direct {v1, v4}, Lcom/titanchess/accessibility/c2;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 143: iput-object v1, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->fenReceiver:Lcom/titanchess/accessibility/c2;
    .line 145: iput-object v0, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->cLastGameKey:Ljava/lang/String;
    .line 147: return-void
.end method

# direct methods
.method public static synthetic a(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onServiceConnected$lambda$9(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method public static final synthetic access$getAccCp$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Ljava/util/concurrent/ConcurrentHashMap;
    .registers 1

    .line 0: iget-object v0, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->accCp:Ljava/util/concurrent/ConcurrentHashMap;
    .line 2: return-object v0
.end method

# direct methods
.method public static final synthetic access$getBg$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Landroid/os/Handler;
    .registers 1

    .line 0: iget-object v0, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 2: return-object v0
.end method

# direct methods
.method public static final synthetic access$getDebounced$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Ljava/lang/Runnable;
    .registers 1

    .line 0: iget-object v0, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 2: return-object v0
.end method

# direct methods
.method public static final synthetic access$getFloating$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Lcom/titanchess/accessibility/s;
    .registers 1

    .line 0: iget-object v0, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 2: return-object v0
.end method

# direct methods
.method public static final synthetic access$getMain$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Landroid/os/Handler;
    .registers 1

    .line 0: iget-object v0, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 2: return-object v0
.end method

# direct methods
.method public static final synthetic access$getOverlay$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Lcom/titanchess/accessibility/d;
    .registers 1

    .line 0: iget-object v0, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 2: return-object v0
.end method

# direct methods
.method public static final synthetic access$setRetryCount$p(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .registers 2

    .line 0: iput v1, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->retryCount:I
    .line 2: return-void
.end method

# direct methods
.method public static final synthetic access$setSnap$p(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;)V
    .registers 2

    .line 0: iput-object v1, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->snap:Lcom/titanchess/accessibility/a2;
    .line 2: return-void
.end method

# direct methods
.method public static synthetic b(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onServiceConnected$lambda$4(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method public static synthetic c(ZLcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: invoke-static {v0, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onAccessibilityEvent$lambda$14(ZLcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method private final compute()V
    .registers 12

    .line 0: iget-object v3, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->snap:Lcom/titanchess/accessibility/a2;
    .line 2: if-nez v3, :cond_5
    .line 4: return-void
    .line 5: iget-object v0, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 7: invoke-interface {v0}, Ljava/util/Map;->size()I
    .line 10: move-result v1
    .line 11: const/16 v2, 64
    .line 13: const-wide/16 v4, 20
    .line 15: if-eq v1, v2, :cond_64
    .line 17: iget v1, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->retryCount:I
    .line 19: add-int/lit8 v2, v1, 1
    .line 21: iput v2, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->retryCount:I
    .line 23: const/16 v2, 10
    .line 25: if-ge v1, v2, :cond_35
    .line 27: iget-object v0, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 29: iget-object v1, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 31: invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    .line 34: goto :goto_63
    .line 35: invoke-interface {v0}, Ljava/util/Map;->size()I
    .line 38: move-result v0
    .line 39: new-instance v1, Ljava/lang/StringBuilder;
    .line 41: const-string v2, "compute give-up: centers="
    .line 43: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 46: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 49: const-string v0, " (board not visible)"
    .line 51: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 54: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 57: move-result-object v0
    .line 58: const-string v1, "TitanA11y"
    .line 60: invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 63: return-void
    .line 64: iget-object v6, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->mySide:Lp2/n;
    .line 66: const-string v0, "titan"
    .line 68: const/4 v1, 0
    .line 69: invoke-virtual {v11, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 72: move-result-object v2
    .line 73: const-string v7, "arrow_on"
    .line 75: const/4 v8, 1
    .line 76: invoke-interface {v2, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 79: move-result v7
    .line 80: iget-object v2, v3, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 82: new-instance v9, Ljava/lang/StringBuilder;
    .line 84: invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V
    .line 87: invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 90: const-string v2, "|"
    .line 92: invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 95: invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 98: invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 101: move-result-object v2
    .line 102: iget-object v9, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastComputed:Ljava/lang/String;
    .line 104: invoke-static {v2, v9}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 107: move-result v9
    .line 108: if-eqz v9, :cond_111
    .line 110: return-void
    .line 111: iget-boolean v9, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->busy:Z
    .line 113: if-eqz v9, :cond_123
    .line 115: iget-object v0, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 117: iget-object v1, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 119: invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    .line 122: return-void
    .line 123: iput-object v2, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastComputed:Ljava/lang/String;
    .line 125: iput-boolean v8, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->busy:Z
    .line 127: iget-object v8, v3, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 129: invoke-virtual {v11, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 132: move-result-object v2
    .line 133: const-string v4, "elo"
    .line 135: const/16 v5, 1500
    .line 137: invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 140: move-result v5
    .line 141: invoke-virtual {v11, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 144: move-result-object v0
    .line 145: const-string v1, "model"
    .line 147: const-string v2, "A"
    .line 149: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 152: move-result-object v0
    .line 153: if-nez v0, :cond_156
    .line 155: goto :goto_157
    .line 156: move-object v2, v0
    .line 157: iget-object v9, v11, Lcom/titanchess/accessibility/TitanAccessibilityService;->worker:Ljava/util/concurrent/ExecutorService;
    .line 159: new-instance v10, Lcom/titanchess/accessibility/y1;
    .line 161: move-object v0, v10
    .line 162: move-object v1, v11
    .line 163: move-object v4, v6
    .line 164: move v6, v7
    .line 165: move-object v7, v8
    .line 166: invoke-direct/range {v0 .. v7}, Lcom/titanchess/accessibility/y1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;IZLjava/util/List;)V
    .line 169: invoke-interface {v9, v10}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 172: return-void
.end method

# direct methods
.method private static final compute$lambda$29(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;IZLjava/util/List;)V
    .registers 23

    .line 0: move-object/from16 v7, v16
    .line 2: move-object/from16 v0, v17
    .line 4: move-object/from16 v3, v18
    .line 6: move-object/from16 v4, v19
    .line 8: move-object/from16 v1, v22
    .line 10: const-string v8, "TitanA11y"
    .line 12: const-string v2, "drew "
    .line 14: const-string v5, "this$0"
    .line 16: invoke-static {v7, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 19: const-string v5, "$model"
    .line 21: invoke-static {v0, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 24: const-string v5, "$s"
    .line 26: invoke-static {v3, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 29: const-string v5, "$my"
    .line 31: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 34: const-string v5, "$badgeHist"
    .line 36: invoke-static {v1, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 39: const/4 v9, 0
    .line 40: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 43: move-result-wide v5
    .line 44: invoke-direct/range {v16 .. v20}, Lcom/titanchess/accessibility/TitanAccessibilityService;->computeArrows(Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;I)Ljava/util/List;
    .line 47: move-result-object v10
    .line 48: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 51: move-result-wide v11
    .line 52: sub-long/2addr v11, v5
    .line 53: long-to-double v5, v11
    .line 54: const-wide v11, 0x412e848000
    .line 59: div-double/2addr v5, v11
    .line 60: const/4 v11, 3
    .line 61: const/4 v12, 1
    .line 62: if-eqz v21, :cond_98
    .line 64: iget-object v13, v3, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 66: if-ne v13, v4, :cond_98
    .line 68: const-string v13, "A"
    .line 70: invoke-static {v0, v13}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 73: move-result v13
    .line 74: if-nez v13, :cond_88
    .line 76: const-string v13, "B"
    .line 78: invoke-static {v0, v13}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 81: move-result v13
    .line 82: if-eqz v13, :cond_98
    .line 84: goto :goto_88
    .line 85: move-exception v0
    .line 86: goto/16 :goto_277
    .line 88: if-eqz v10, :cond_98
    .line 90: invoke-interface {v10}, Ljava/util/List;->size()I
    .line 93: move-result v13
    .line 94: if-ne v13, v11, :cond_98
    .line 96: move v13, v12
    .line 97: goto :goto_99
    .line 98: move v13, v9
    .line 99: if-nez v13, :cond_111
    .line 101: iget-object v14, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->evalWorker:Ljava/util/concurrent/ExecutorService;
    .line 103: new-instance v15, Lcom/titanchess/accessibility/w1;
    .line 105: invoke-direct {v15, v7, v1, v9}, Lcom/titanchess/accessibility/w1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;I)V
    .line 108: invoke-interface {v14, v15}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 111: iget-object v1, v3, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 113: if-eq v1, v4, :cond_124
    .line 115: iget-object v0, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 117: if-eqz v0, :cond_274
    .line 119: invoke-virtual {v0}, Lcom/titanchess/accessibility/d;->a()V
    .line 122: goto/16 :goto_274
    .line 124: if-nez v21, :cond_135
    .line 126: iget-object v0, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 128: if-eqz v0, :cond_274
    .line 130: invoke-virtual {v0}, Lcom/titanchess/accessibility/d;->a()V
    .line 133: goto/16 :goto_274
    .line 135: if-eqz v10, :cond_274
    .line 137: iget-object v1, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->snap:Lcom/titanchess/accessibility/a2;
    .line 139: if-eqz v1, :cond_164
    .line 141: iget-object v14, v1, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 143: iget-object v15, v3, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 145: invoke-static {v14, v15}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 148: move-result v14
    .line 149: if-eqz v14, :cond_155
    .line 151: iget-object v1, v1, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 153: if-eq v1, v4, :cond_164
    .line 155: iget-object v0, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 157: if-eqz v0, :cond_274
    .line 159: invoke-virtual {v0}, Lcom/titanchess/accessibility/d;->a()V
    .line 162: goto/16 :goto_274
    .line 164: const-string v1, "titan"
    .line 166: invoke-virtual {v7, v1, v9}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 169: move-result-object v1
    .line 170: const-string v14, "arrow_count"
    .line 172: invoke-interface {v1, v14, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 175: move-result v1
    .line 176: invoke-static/range {v16 .. v16}, Lcom/titanchess/accessibility/e;->g(Landroid/content/Context;)Z
    .line 179: move-result v11
    .line 180: if-eqz v11, :cond_183
    .line 182: goto :goto_184
    .line 183: move v1, v12
    .line 184: if-ne v1, v12, :cond_190
    .line 186: if-nez v13, :cond_190
    .line 188: move v11, v12
    .line 189: goto :goto_191
    .line 190: move v11, v9
    .line 191: invoke-direct {v7, v10, v1, v11, v13}, Lcom/titanchess/accessibility/TitanAccessibilityService;->toOverlayArrows(Ljava/util/List;IZZ)Ljava/util/List;
    .line 194: move-result-object v1
    .line 195: iget-object v11, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 197: if-eqz v11, :cond_210
    .line 199: const-string v12, "list"
    .line 201: invoke-static {v1, v12}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 204: iput-object v1, v11, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 206: invoke-virtual {v11}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 209: goto :goto_220
    .line 210: iget-object v11, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 212: new-instance v14, Lcom/titanchess/accessibility/w1;
    .line 214: invoke-direct {v14, v7, v1, v12}, Lcom/titanchess/accessibility/w1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;I)V
    .line 217: invoke-virtual {v11, v14}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 220: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 223: move-result v1
    .line 224: double-to-int v6, v5
    .line 225: new-instance v5, Ljava/lang/StringBuilder;
    .line 227: invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 230: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 233: const-string v1, " in "
    .line 235: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 238: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 241: const-string v1, "ms my="
    .line 243: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 246: invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 249: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 252: move-result-object v1
    .line 253: invoke-static {v8, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 256: if-eqz v13, :cond_271
    .line 258: move-object/from16 v1, v16
    .line 260: move-object/from16 v2, v17
    .line 262: move-object/from16 v3, v18
    .line 264: move-object/from16 v4, v19
    .line 266: move-object v5, v10
    .line 267: invoke-direct/range {v1 .. v6}, Lcom/titanchess/accessibility/TitanAccessibilityService;->recolorWithStockfish(Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;Ljava/util/List;I)V
    .line 270: goto :goto_274
    .line 271: invoke-direct {v7, v3, v10, v6}, Lcom/titanchess/accessibility/TitanAccessibilityService;->writeStatus(Lcom/titanchess/accessibility/a2;Ljava/util/List;I)V
    .line 274: iput-boolean v9, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->busy:Z
    .line 276: goto :goto_283
    .line 277: const-string v1, "brain fail"
    .line 279: invoke-static {v8, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 282: goto :goto_274
    .line 283: return-void
    .line 284: move-exception v0
    .line 285: iput-boolean v9, v7, Lcom/titanchess/accessibility/TitanAccessibilityService;->busy:Z
    .line 287: throw v0
.end method

# direct methods
.method private static final compute$lambda$29$lambda$26(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .registers 3

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "$badgeHist"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v1, v2}, Lcom/titanchess/accessibility/TitanAccessibilityService;->gradeLastMove(Ljava/util/List;)V
    .line 13: return-void
.end method

# direct methods
.method private static final compute$lambda$29$lambda$28(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .registers 3

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "$drawn"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->ensureOverlay()Lcom/titanchess/accessibility/d;
    .line 13: move-result-object v1
    .line 14: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 17: iput-object v2, v1, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 19: invoke-virtual {v1}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 22: return-void
.end method

# direct methods
.method private final computeArrows(Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;I)Ljava/util/List;
    .registers 32

    .line 0: move-object/from16 v1, v27
    .line 2: move-object/from16 v0, v28
    .line 4: move-object/from16 v2, v29
    .line 6: move-object/from16 v3, v30
    .line 8: move/from16 v4, v31
    .line 10: const-string v5, "A"
    .line 12: invoke-static {v0, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 15: move-result v5
    .line 16: const/4 v6, 0
    .line 17: const/4 v7, 0
    .line 18: if-nez v5, :cond_28
    .line 20: const-string v5, "B"
    .line 22: invoke-static {v0, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 25: move-result v5
    .line 26: if-eqz v5, :cond_56
    .line 28: invoke-static/range {v27 .. v27}, Lcom/titanchess/accessibility/e;->g(Landroid/content/Context;)Z
    .line 31: move-result v5
    .line 32: if-nez v5, :cond_56
    .line 34: const-string v0, "titan"
    .line 36: invoke-virtual {v1, v0, v6}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 39: move-result-object v0
    .line 40: invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 43: move-result-object v0
    .line 44: const-string v2, "st_arrow"
    .line 46: const-string v3, "butuh lisensi aktif"
    .line 48: invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 51: move-result-object v0
    .line 52: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 55: return-object v7
    .line 56: const-string v5, "C"
    .line 58: invoke-static {v0, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 61: move-result v5
    .line 62: if-eqz v5, :cond_69
    .line 64: invoke-direct {v1, v2, v3, v4}, Lcom/titanchess/accessibility/TitanAccessibilityService;->computeStockfishC(Lcom/titanchess/accessibility/a2;Lp2/n;I)Ljava/util/List;
    .line 67: move-result-object v0
    .line 68: return-object v0
    .line 69: const-string v5, "B"
    .line 71: invoke-static {v0, v5}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 74: move-result v0
    .line 75: const/4 v5, 1
    .line 76: const/16 v9, 32
    .line 78: if-nez v0, :cond_1408
    .line 80: invoke-direct/range {v27 .. v27}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getBrain()Lcom/titanchess/accessibility/g;
    .line 83: move-result-object v11
    .line 84: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 86: iget-object v12, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 88: iget-object v13, v2, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 90: iget v14, v2, Lcom/titanchess/accessibility/a2;->d:I
    .line 92: iget v2, v2, Lcom/titanchess/accessibility/a2;->e:I
    .line 94: invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 97: const-string v15, "curFen"
    .line 99: invoke-static {v0, v15}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 102: const-string v15, "historyFens"
    .line 104: invoke-static {v12, v15}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 107: const-string v15, "sideToMove"
    .line 109: invoke-static {v13, v15}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 112: const-string v15, "mySide"
    .line 114: invoke-static {v3, v15}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 117: if-eq v13, v3, :cond_121
    .line 119: goto/16 :goto_1405
    .line 121: invoke-static {v0, v9}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 124: move-result-object v3
    .line 125: invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z
    .line 128: move-result v13
    .line 129: xor-int/2addr v13, v5
    .line 130: if-eqz v13, :cond_173
    .line 132: invoke-static {v12}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 135: move-result-object v13
    .line 136: check-cast v13, Ljava/lang/String;
    .line 138: invoke-static {v13, v9}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 141: move-result-object v13
    .line 142: invoke-static {v13, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 145: move-result v3
    .line 146: if-nez v3, :cond_173
    .line 148: const-string v0, "TitanBrain"
    .line 150: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 153: move-result v2
    .line 154: new-instance v3, Ljava/lang/StringBuilder;
    .line 156: const-string v4, "skip transient: histLast!=cur plies="
    .line 158: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 161: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 164: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 167: move-result-object v2
    .line 168: invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 171: goto/16 :goto_1405
    .line 173: if-gez v14, :cond_177
    .line 175: move v3, v4
    .line 176: goto :goto_191
    .line 177: mul-int/lit8 v3, v2, 40
    .line 179: add-int/2addr v3, v14
    .line 180: const/16 v13, 179
    .line 182: if-ge v3, v13, :cond_175
    .line 184: add-int/lit16 v3, v4, -400
    .line 186: const/16 v13, 800
    .line 188: if-ge v3, v13, :cond_191
    .line 190: move v3, v13
    .line 191: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 194: move-result-wide v15
    .line 195: invoke-interface {v12}, Ljava/util/List;->isEmpty()Z
    .line 198: move-result v13
    .line 199: iget-object v7, v11, Lcom/titanchess/accessibility/g;->b:Ljava/util/ArrayList;
    .line 201: if-eqz v13, :cond_215
    .line 203: invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V
    .line 206: new-instance v7, Ljava/util/ArrayList;
    .line 208: invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V
    .line 211: iput-object v7, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 213: goto/16 :goto_473
    .line 215: invoke-interface {v12, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 218: move-result-object v13
    .line 219: check-cast v13, Ljava/lang/String;
    .line 221: invoke-static {v13, v9}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 224: move-result-object v9
    .line 225: const-string v13, "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
    .line 227: invoke-static {v9, v13}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 230: move-result v9
    .line 231: if-eqz v9, :cond_268
    .line 233: iget-object v9, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 235: invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z
    .line 238: move-result v9
    .line 239: xor-int/2addr v9, v5
    .line 240: if-eqz v9, :cond_268
    .line 242: iget-object v9, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 244: invoke-virtual {v9, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 247: move-result-object v9
    .line 248: invoke-interface {v12, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 251: move-result-object v13
    .line 252: invoke-static {v9, v13}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 255: move-result v9
    .line 256: if-nez v9, :cond_268
    .line 258: invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V
    .line 261: new-instance v9, Ljava/util/ArrayList;
    .line 263: invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V
    .line 266: iput-object v9, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 268: iget-object v9, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 270: invoke-virtual {v9}, Ljava/util/ArrayList;->size()I
    .line 273: move-result v9
    .line 274: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 277: move-result v13
    .line 278: invoke-static {v9, v13}, Ljava/lang/Math;->min(II)I
    .line 281: move-result v9
    .line 282: move v13, v6
    .line 283: if-ge v13, v9, :cond_304
    .line 285: iget-object v8, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 287: invoke-virtual {v8, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 290: move-result-object v8
    .line 291: invoke-interface {v12, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 294: move-result-object v10
    .line 295: invoke-static {v8, v10}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 298: move-result v8
    .line 299: if-eqz v8, :cond_304
    .line 301: add-int/lit8 v13, v13, 1
    .line 303: goto :goto_283
    .line 304: iget-object v8, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 306: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 309: move-result v8
    .line 310: if-ge v13, v8, :cond_351
    .line 312: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    .line 315: move-result v8
    .line 316: add-int/lit8 v9, v13, -1
    .line 318: if-gez v9, :cond_321
    .line 320: move v9, v6
    .line 321: if-le v8, v9, :cond_332
    .line 323: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    .line 326: move-result v8
    .line 327: sub-int/2addr v8, v5
    .line 328: invoke-virtual {v7, v8}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    .line 331: goto :goto_312
    .line 332: iget-object v8, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 334: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 337: move-result v8
    .line 338: if-le v8, v13, :cond_351
    .line 340: iget-object v8, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 342: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 345: move-result v9
    .line 346: sub-int/2addr v9, v5
    .line 347: invoke-virtual {v8, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    .line 350: goto :goto_332
    .line 351: iget-object v8, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 353: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    .line 356: move-result v8
    .line 357: invoke-static {v5, v8}, Ljava/lang/Math;->max(II)I
    .line 360: move-result v8
    .line 361: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 364: move-result v9
    .line 365: if-ge v8, v9, :cond_466
    .line 367: add-int/lit8 v9, v8, -1
    .line 369: invoke-interface {v12, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 372: move-result-object v9
    .line 373: check-cast v9, Ljava/lang/String;
    .line 375: invoke-interface {v12, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 378: move-result-object v10
    .line 379: check-cast v10, Ljava/lang/String;
    .line 381: new-instance v13, Lp2/e;
    .line 383: invoke-direct {v13}, Lp2/e;-><init>()V
    .line 386: invoke-virtual {v13, v9}, Lp2/e;->n(Ljava/lang/String;)V
    .line 389: new-instance v9, Lp2/e;
    .line 391: invoke-direct {v9}, Lp2/e;-><init>()V
    .line 394: invoke-virtual {v9, v10}, Lp2/e;->n(Ljava/lang/String;)V
    .line 397: iget-wide v9, v9, Lp2/e;->x:J
    .line 399: invoke-static {v13}, Ld2/b;->j0(Lp2/e;)Ljava/util/LinkedList;
    .line 402: move-result-object v17
    .line 403: invoke-interface/range {v17 .. v17}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 406: move-result-object v17
    .line 407: invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z
    .line 410: move-result v18
    .line 411: if-eqz v18, :cond_450
    .line 413: invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 416: move-result-object v18
    .line 417: move-object/from16 v5, v18
    .line 419: check-cast v5, Lr2/a;
    .line 421: invoke-virtual {v13, v5}, Lp2/e;->a(Lr2/a;)V
    .line 424: move-object/from16 v29, v7
    .line 426: iget-wide v6, v13, Lp2/e;->x:J
    .line 428: cmp-long v6, v6, v9
    .line 430: if-nez v6, :cond_434
    .line 432: const/4 v6, 1
    .line 433: goto :goto_435
    .line 434: const/4 v6, 0
    .line 435: invoke-virtual {v13}, Lp2/e;->s()V
    .line 438: if-eqz v6, :cond_445
    .line 440: invoke-virtual {v5}, Lr2/a;->toString()Ljava/lang/String;
    .line 443: move-result-object v5
    .line 444: goto :goto_453
    .line 445: move-object/from16 v7, v29
    .line 447: const/4 v5, 1
    .line 448: const/4 v6, 0
    .line 449: goto :goto_407
    .line 450: move-object/from16 v29, v7
    .line 452: const/4 v5, 0
    .line 453: move-object/from16 v6, v29
    .line 455: if-eqz v5, :cond_460
    .line 457: invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 460: add-int/lit8 v8, v8, 1
    .line 462: move-object v7, v6
    .line 463: const/4 v5, 1
    .line 464: const/4 v6, 0
    .line 465: goto :goto_361
    .line 466: new-instance v5, Ljava/util/ArrayList;
    .line 468: invoke-direct {v5, v12}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 471: iput-object v5, v11, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 473: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 476: move-result-wide v5
    .line 477: sub-long/2addr v5, v15
    .line 478: const v7, 0xf4240
    .line 481: int-to-long v7, v7
    .line 482: div-long/2addr v5, v7
    .line 483: new-instance v9, Lp2/e;
    .line 485: invoke-direct {v9}, Lp2/e;-><init>()V
    .line 488: invoke-virtual {v9, v0}, Lp2/e;->n(Ljava/lang/String;)V
    .line 491: invoke-static {v9}, Ld2/b;->j0(Lp2/e;)Ljava/util/LinkedList;
    .line 494: move-result-object v0
    .line 495: new-instance v9, Ljava/util/ArrayList;
    .line 497: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 500: move-result v10
    .line 501: invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V
    .line 504: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 507: move-result-object v0
    .line 508: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 511: move-result v10
    .line 512: if-eqz v10, :cond_528
    .line 514: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 517: move-result-object v10
    .line 518: check-cast v10, Lr2/a;
    .line 520: invoke-virtual {v10}, Lr2/a;->toString()Ljava/lang/String;
    .line 523: move-result-object v10
    .line 524: invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 527: goto :goto_508
    .line 528: invoke-static {v9}, Lt2/p;->e2(Ljava/lang/Iterable;)Ljava/util/Set;
    .line 531: move-result-object v9
    .line 532: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 535: move-result-wide v12
    .line 536: iget-object v10, v11, Lcom/titanchess/accessibility/g;->a:Lcom/titanchess/accessibility/n1;
    .line 538: iget-object v0, v11, Lcom/titanchess/accessibility/g;->b:Ljava/util/ArrayList;
    .line 540: monitor-enter v10
    .line 541: const-string v15, "historyUci"
    .line 543: invoke-static {v0, v15}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 546: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 549: move-result-wide v15
    .line 550: invoke-virtual {v10, v3, v0}, Lcom/titanchess/accessibility/n1;->a(ILjava/util/List;)[J
    .line 553: move-result-object v1
    .line 554: iget-object v0, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 556: array-length v0, v0
    .line 557: move-wide/from16 v29, v5
    .line 559: array-length v5, v1
    .line 560: invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I
    .line 563: move-result v0
    .line 564: const/4 v5, 0
    .line 565: if-ge v5, v0, :cond_583
    .line 567: iget-object v6, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 569: aget-wide v19, v6, v5
    .line 571: aget-wide v21, v1, v5
    .line 573: cmp-long v6, v19, v21
    .line 575: if-nez v6, :cond_583
    .line 577: add-int/lit8 v5, v5, 1
    .line 579: goto :goto_565
    .line 580: move-exception v0
    .line 581: goto/16 :goto_1406
    .line 583: iget-object v0, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 585: array-length v0, v0
    .line 586: if-lt v5, v0, :cond_599
    .line 588: iget-object v0, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 590: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    .line 593: move-result v0
    .line 594: if-eqz v0, :cond_597
    .line 596: goto :goto_599
    .line 597: const/4 v0, 0
    .line 598: goto :goto_600
    .line 599: const/4 v0, 1
    .line 600: if-eqz v0, :cond_619
    .line 602: iget-object v5, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 604: invoke-static {v5}, Lcom/titanchess/accessibility/n1;->b(Ljava/util/Map;)V
    .line 607: invoke-virtual {v10}, Lcom/titanchess/accessibility/n1;->d()Ljava/util/LinkedHashMap;
    .line 610: move-result-object v5
    .line 611: iput-object v5, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 613: const/4 v5, 0
    .line 614: new-array v6, v5, [J
    .line 616: iput-object v6, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 618: const/4 v5, 0
    .line 619: array-length v6, v1
    .line 620: move/from16 v17, v3
    .line 622: array-length v3, v1
    .line 623: invoke-static {v6, v3}, Ld2/c;->E(II)V
    .line 626: invoke-static {v1, v5, v6}, Ljava/util/Arrays;->copyOfRange([JII)[J
    .line 629: move-result-object v3
    .line 630: const-string v6, "copyOfRange(this, fromIndex, toIndex)"
    .line 632: invoke-static {v3, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 635: const-string v6, "TitanBrain"
    .line 637: array-length v4, v1
    .line 638: move/from16 v19, v2
    .line 640: iget-object v2, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 642: array-length v2, v2
    .line 643: move/from16 v20, v14
    .line 645: array-length v14, v3
    .line 646: move-object/from16 v21, v11
    .line 648: new-instance v11, Ljava/lang/StringBuilder;
    .line 650: invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V
    .line 653: move-object/from16 v22, v9
    .line 655: const-string v9, "predict prefix="
    .line 657: invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 660: invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 663: const-string v4, " processed="
    .line 665: invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 668: invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 671: const-string v2, " common="
    .line 673: invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 676: invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 679: const-string v2, " delta="
    .line 681: invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 684: invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 687: const-string v2, " reprime="
    .line 689: invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 692: invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 695: invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 698: move-result-object v0
    .line 699: invoke-static {v6, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 702: array-length v0, v3
    .line 703: const/16 v2, 8
    .line 705: if-nez v0, :cond_741
    .line 707: array-length v0, v1
    .line 708: if-nez v0, :cond_717
    .line 710: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 712: monitor-exit v10
    .line 713: move-wide/from16 v25, v12
    .line 715: goto/16 :goto_1057
    .line 717: iget-object v0, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 719: invoke-static {v0}, Lcom/titanchess/accessibility/n1;->b(Ljava/util/Map;)V
    .line 722: invoke-virtual {v10}, Lcom/titanchess/accessibility/n1;->d()Ljava/util/LinkedHashMap;
    .line 725: move-result-object v0
    .line 726: iput-object v0, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 728: const/4 v3, 0
    .line 729: new-array v0, v3, [J
    .line 731: iput-object v0, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 733: invoke-virtual {v10, v1, v2}, Lcom/titanchess/accessibility/n1;->e([JI)Ljava/util/ArrayList;
    .line 736: move-result-object v0
    .line 737: iput-object v1, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 739: monitor-exit v10
    .line 740: goto :goto_713
    .line 741: array-length v0, v3
    .line 742: add-int/2addr v5, v0
    .line 743: new-array v0, v5, [J
    .line 745: const/4 v4, 0
    .line 746: const-wide/16 v23, 1
    .line 748: if-ge v4, v5, :cond_755
    .line 750: aput-wide v23, v0, v4
    .line 752: add-int/lit8 v4, v4, 1
    .line 754: goto :goto_746
    .line 755: new-instance v4, Ljava/util/HashMap;
    .line 757: iget-object v6, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 759: invoke-direct {v4, v6}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V
    .line 762: const-string v6, "input_ids"
    .line 764: iget-object v9, v10, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 766: invoke-static {v3}, Ljava/nio/LongBuffer;->wrap([J)Ljava/nio/LongBuffer;
    .line 769: move-result-object v11
    .line 770: const/4 v14, 2
    .line 771: new-array v2, v14, [J
    .line 773: const/4 v14, 0
    .line 774: aput-wide v23, v2, v14
    .line 776: array-length v14, v3
    .line 777: move-wide/from16 v25, v12
    .line 779: int-to-long v12, v14
    .line 780: const/4 v14, 1
    .line 781: aput-wide v12, v2, v14
    .line 783: invoke-static {v9, v11, v2}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/LongBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 786: move-result-object v2
    .line 787: const-string v9, "createTensor(...)"
    .line 789: invoke-static {v2, v9}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 792: invoke-virtual {v4, v6, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 795: const-string v2, "attention_mask"
    .line 797: iget-object v6, v10, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 799: invoke-static {v0}, Ljava/nio/LongBuffer;->wrap([J)Ljava/nio/LongBuffer;
    .line 802: move-result-object v0
    .line 803: const/4 v9, 2
    .line 804: new-array v11, v9, [J
    .line 806: const/4 v9, 0
    .line 807: aput-wide v23, v11, v9
    .line 809: int-to-long v12, v5
    .line 810: const/4 v5, 1
    .line 811: aput-wide v12, v11, v5
    .line 813: invoke-static {v6, v0, v11}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/LongBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 816: move-result-object v0
    .line 817: const-string v5, "createTensor(...)"
    .line 819: invoke-static {v0, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 822: invoke-virtual {v4, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 825: invoke-virtual {v10}, Lcom/titanchess/accessibility/n1;->f()Lai/onnxruntime/OrtSession;
    .line 828: move-result-object v0
    .line 829: invoke-virtual {v0, v4}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .line 832: move-result-object v0
    .line 833: new-instance v2, Ljava/util/HashMap;
    .line 835: iget-object v5, v10, Lcom/titanchess/accessibility/n1;->o:Ljava/util/ArrayList;
    .line 837: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 840: move-result v5
    .line 841: invoke-direct {v2, v5}, Ljava/util/HashMap;-><init>(I)V
    .line 844: iget-object v5, v10, Lcom/titanchess/accessibility/n1;->o:Ljava/util/ArrayList;
    .line 846: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 849: move-result v5
    .line 850: const/4 v6, 0
    .line 851: if-ge v6, v5, :cond_924
    .line 853: iget-object v9, v10, Lcom/titanchess/accessibility/n1;->p:Ljava/util/ArrayList;
    .line 855: invoke-virtual {v9, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 858: move-result-object v9
    .line 859: check-cast v9, Ljava/lang/String;
    .line 861: invoke-virtual {v0, v9}, Lai/onnxruntime/OrtSession$Result;->get(Ljava/lang/String;)Ljava/util/Optional;
    .line 864: move-result-object v9
    .line 865: invoke-virtual {v9}, Ljava/util/Optional;->get()Ljava/lang/Object;
    .line 868: move-result-object v9
    .line 869: const-string v11, "null cannot be cast to non-null type ai.onnxruntime.OnnxTensor"
    .line 871: invoke-static {v9, v11}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 874: check-cast v9, Lai/onnxruntime/OnnxTensor;
    .line 876: invoke-virtual {v9}, Lai/onnxruntime/OnnxTensorLike;->getInfo()Lai/onnxruntime/TensorInfo;
    .line 879: move-result-object v11
    .line 880: invoke-virtual {v11}, Lai/onnxruntime/TensorInfo;->getShape()[J
    .line 883: move-result-object v11
    .line 884: invoke-virtual {v9}, Lai/onnxruntime/OnnxTensor;->getFloatBuffer()Ljava/nio/FloatBuffer;
    .line 887: move-result-object v9
    .line 888: invoke-virtual {v9}, Ljava/nio/Buffer;->remaining()I
    .line 891: move-result v12
    .line 892: new-array v12, v12, [F
    .line 894: invoke-virtual {v9, v12}, Ljava/nio/FloatBuffer;->get([F)Ljava/nio/FloatBuffer;
    .line 897: iget-object v9, v10, Lcom/titanchess/accessibility/n1;->o:Ljava/util/ArrayList;
    .line 899: invoke-virtual {v9, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 902: move-result-object v9
    .line 903: iget-object v13, v10, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 905: invoke-static {v12}, Ljava/nio/FloatBuffer;->wrap([F)Ljava/nio/FloatBuffer;
    .line 908: move-result-object v12
    .line 909: invoke-static {v13, v12, v11}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/FloatBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 912: move-result-object v11
    .line 913: const-string v12, "createTensor(...)"
    .line 915: invoke-static {v11, v12}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 918: invoke-virtual {v2, v9, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 921: add-int/lit8 v6, v6, 1
    .line 923: goto :goto_851
    .line 924: const-string v5, "logits"
    .line 926: invoke-virtual {v0, v5}, Lai/onnxruntime/OrtSession$Result;->get(Ljava/lang/String;)Ljava/util/Optional;
    .line 929: move-result-object v5
    .line 930: invoke-virtual {v5}, Ljava/util/Optional;->get()Ljava/lang/Object;
    .line 933: move-result-object v5
    .line 934: const-string v6, "null cannot be cast to non-null type ai.onnxruntime.OnnxTensor"
    .line 936: invoke-static {v5, v6}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 939: check-cast v5, Lai/onnxruntime/OnnxTensor;
    .line 941: invoke-virtual {v5}, Lai/onnxruntime/OnnxTensor;->getFloatBuffer()Ljava/nio/FloatBuffer;
    .line 944: move-result-object v5
    .line 945: invoke-virtual {v5}, Ljava/nio/Buffer;->remaining()I
    .line 948: move-result v6
    .line 949: new-array v6, v6, [F
    .line 951: invoke-virtual {v5, v6}, Ljava/nio/FloatBuffer;->get([F)Ljava/nio/FloatBuffer;
    .line 954: invoke-virtual {v0}, Lai/onnxruntime/OrtSession$Result;->close()V
    .line 957: iget-object v0, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 959: invoke-static {v0}, Lcom/titanchess/accessibility/n1;->b(Ljava/util/Map;)V
    .line 962: const-string v0, "input_ids"
    .line 964: invoke-virtual {v4, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 967: move-result-object v0
    .line 968: const-string v5, "null cannot be cast to non-null type ai.onnxruntime.OnnxTensor"
    .line 970: invoke-static {v0, v5}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 973: check-cast v0, Lai/onnxruntime/OnnxTensor;
    .line 975: invoke-virtual {v0}, Lai/onnxruntime/OnnxTensor;->close()V
    .line 978: goto :goto_983
    .line 979: move-exception v0
    .line 980: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 983: const-string v0, "attention_mask"
    .line 985: invoke-virtual {v4, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 988: move-result-object v0
    .line 989: const-string v4, "null cannot be cast to non-null type ai.onnxruntime.OnnxTensor"
    .line 991: invoke-static {v0, v4}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 994: check-cast v0, Lai/onnxruntime/OnnxTensor;
    .line 996: invoke-virtual {v0}, Lai/onnxruntime/OnnxTensor;->close()V
    .line 999: goto :goto_1004
    .line 1000: move-exception v0
    .line 1001: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 1004: iput-object v2, v10, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 1006: iput-object v1, v10, Lcom/titanchess/accessibility/n1;->q:[J
    .line 1008: const/16 v1, 8
    .line 1010: invoke-virtual {v10, v1, v6}, Lcom/titanchess/accessibility/n1;->c(I[F)Ljava/util/ArrayList;
    .line 1013: move-result-object v0
    .line 1014: const-string v1, "TitanBrain"
    .line 1016: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 1019: move-result-wide v4
    .line 1020: sub-long/2addr v4, v15
    .line 1021: div-long/2addr v4, v7
    .line 1022: array-length v2, v3
    .line 1023: new-instance v3, Ljava/lang/StringBuilder;
    .line 1025: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 1028: const-string v6, "predict ms="
    .line 1030: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1033: invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 1036: const-string v4, " (cache-path delta="
    .line 1038: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1041: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1044: const-string v2, ")"
    .line 1046: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1049: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 1052: move-result-object v2
    .line 1053: invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 1056: monitor-exit v10
    .line 1057: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 1060: move-result-wide v1
    .line 1061: sub-long v1, v1, v25
    .line 1063: div-long/2addr v1, v7
    .line 1064: new-instance v3, Ljava/util/ArrayList;
    .line 1066: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    .line 1069: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1072: move-result-object v4
    .line 1073: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 1076: move-result v5
    .line 1077: if-eqz v5, :cond_1102
    .line 1079: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1082: move-result-object v5
    .line 1083: move-object v6, v5
    .line 1084: check-cast v6, Ls2/e;
    .line 1086: iget-object v6, v6, Ls2/e;->i:Ljava/lang/Object;
    .line 1088: move-object/from16 v7, v22
    .line 1090: invoke-interface {v7, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    .line 1093: move-result v6
    .line 1094: if-eqz v6, :cond_1099
    .line 1096: invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1099: move-object/from16 v22, v7
    .line 1101: goto :goto_1073
    .line 1102: move-object/from16 v7, v22
    .line 1104: const/4 v4, 3
    .line 1105: invoke-static {v3, v4}, Lt2/p;->X1(Ljava/lang/Iterable;I)Ljava/util/List;
    .line 1108: move-result-object v3
    .line 1109: new-instance v4, Ljava/util/ArrayList;
    .line 1111: invoke-static {v3}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1114: move-result v5
    .line 1115: invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V
    .line 1118: invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1121: move-result-object v3
    .line 1122: const/4 v5, 0
    .line 1123: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 1126: move-result v6
    .line 1127: if-eqz v6, :cond_1187
    .line 1129: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1132: move-result-object v6
    .line 1133: add-int/lit8 v8, v5, 1
    .line 1135: if-ltz v5, :cond_1182
    .line 1137: check-cast v6, Ls2/e;
    .line 1139: iget-object v5, v6, Ls2/e;->i:Ljava/lang/Object;
    .line 1141: check-cast v5, Ljava/lang/String;
    .line 1143: iget-object v6, v6, Ls2/e;->j:Ljava/lang/Object;
    .line 1145: check-cast v6, Ljava/lang/Number;
    .line 1147: invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F
    .line 1150: move-result v6
    .line 1151: new-instance v9, Lcom/titanchess/accessibility/f;
    .line 1153: const/4 v10, 0
    .line 1154: const/4 v11, 2
    .line 1155: invoke-virtual {v5, v10, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 1158: move-result-object v12
    .line 1159: const-string v10, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 1161: invoke-static {v12, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1164: const/4 v10, 4
    .line 1165: invoke-virtual {v5, v11, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 1168: move-result-object v5
    .line 1169: const-string v10, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 1171: invoke-static {v5, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1174: invoke-direct {v9, v12, v5, v8, v6}, Lcom/titanchess/accessibility/f;-><init>(Ljava/lang/String;Ljava/lang/String;IF)V
    .line 1177: invoke-virtual {v4, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1180: move v5, v8
    .line 1181: goto :goto_1123
    .line 1182: invoke-static {}, Ld2/b;->g1()V
    .line 1185: const/4 v1, 0
    .line 1186: throw v1
    .line 1187: const-string v3, "TitanBrain"
    .line 1189: move-object/from16 v5, v21
    .line 1191: iget-object v5, v5, Lcom/titanchess/accessibility/g;->b:Ljava/util/ArrayList;
    .line 1193: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    .line 1196: move-result v5
    .line 1197: new-instance v6, Ljava/util/ArrayList;
    .line 1199: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1202: move-result v8
    .line 1203: invoke-direct {v6, v8}, Ljava/util/ArrayList;-><init>(I)V
    .line 1206: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1209: move-result-object v0
    .line 1210: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 1213: move-result v8
    .line 1214: if-eqz v8, :cond_1230
    .line 1216: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1219: move-result-object v8
    .line 1220: check-cast v8, Ls2/e;
    .line 1222: iget-object v8, v8, Ls2/e;->i:Ljava/lang/Object;
    .line 1224: check-cast v8, Ljava/lang/String;
    .line 1226: invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1229: goto :goto_1210
    .line 1230: invoke-interface {v7}, Ljava/util/Set;->size()I
    .line 1233: move-result v0
    .line 1234: new-instance v7, Ljava/util/ArrayList;
    .line 1236: invoke-static {v4}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1239: move-result v8
    .line 1240: invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V
    .line 1243: invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 1246: move-result-object v8
    .line 1247: invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z
    .line 1250: move-result v9
    .line 1251: if-eqz v9, :cond_1297
    .line 1253: invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1256: move-result-object v9
    .line 1257: check-cast v9, Lcom/titanchess/accessibility/f;
    .line 1259: iget-object v10, v9, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 1261: iget-object v11, v9, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 1263: iget v9, v9, Lcom/titanchess/accessibility/f;->d:F
    .line 1265: const/16 v12, 100
    .line 1267: int-to-float v12, v12
    .line 1268: mul-float/2addr v9, v12
    .line 1269: float-to-int v9, v9
    .line 1270: new-instance v12, Ljava/lang/StringBuilder;
    .line 1272: invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V
    .line 1275: invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1278: invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1281: const-string v10, "@"
    .line 1283: invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1286: invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1289: invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 1292: move-result-object v9
    .line 1293: invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1296: goto :goto_1247
    .line 1297: new-instance v8, Ljava/lang/StringBuilder;
    .line 1299: const-string v9, "plies="
    .line 1301: invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 1304: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1307: const-string v5, " tc="
    .line 1309: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1312: move/from16 v5, v20
    .line 1314: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1317: const-string v5, "+"
    .line 1319: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1322: move/from16 v5, v19
    .line 1324: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1327: const-string v5, " elo="
    .line 1329: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1332: move/from16 v5, v31
    .line 1334: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1337: const-string v5, "->"
    .line 1339: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1342: move/from16 v5, v17
    .line 1344: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1347: const-string v5, " msHist="
    .line 1349: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1352: move-wide/from16 v9, v29
    .line 1354: invoke-virtual {v8, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 1357: const-string v5, " msModel="
    .line 1359: invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1362: invoke-virtual {v8, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 1365: const-string v1, " top="
    .line 1367: invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1370: invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 1373: const-string v1, " legal="
    .line 1375: invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1378: invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 1381: const-string v0, " arrows="
    .line 1383: invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 1386: invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 1389: invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 1392: move-result-object v0
    .line 1393: invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 1396: invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z
    .line 1399: move-result v0
    .line 1400: if-eqz v0, :cond_1404
    .line 1402: const/4 v7, 0
    .line 1403: goto :goto_1405
    .line 1404: move-object v7, v4
    .line 1405: return-object v7
    .line 1406: monitor-exit v10
    .line 1407: throw v0
    .line 1408: move v5, v4
    .line 1409: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 1411: if-eq v0, v3, :cond_1415
    .line 1413: const/4 v1, 0
    .line 1414: return-object v1
    .line 1415: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 1417: invoke-static {v0, v9}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 1420: move-result-object v0
    .line 1421: iget-object v1, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 1423: invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z
    .line 1426: move-result v1
    .line 1427: const/4 v3, 1
    .line 1428: xor-int/2addr v1, v3
    .line 1429: if-eqz v1, :cond_1451
    .line 1431: iget-object v1, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 1433: invoke-static {v1}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 1436: move-result-object v1
    .line 1437: check-cast v1, Ljava/lang/String;
    .line 1439: invoke-static {v1, v9}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 1442: move-result-object v1
    .line 1443: invoke-static {v1, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 1446: move-result v0
    .line 1447: if-nez v0, :cond_1451
    .line 1449: const/4 v1, 0
    .line 1450: return-object v1
    .line 1451: const/16 v0, 1100
    .line 1453: const/16 v1, 2600
    .line 1455: invoke-static {v5, v0, v1}, Ld2/b;->G(III)I
    .line 1458: move-result v0
    .line 1459: iget-object v1, v2, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 1461: sget-object v3, Lp2/n;->i:Lp2/n;
    .line 1463: if-ne v1, v3, :cond_1468
    .line 1465: iget v1, v2, Lcom/titanchess/accessibility/a2;->f:I
    .line 1467: goto :goto_1470
    .line 1468: iget v1, v2, Lcom/titanchess/accessibility/a2;->g:I
    .line 1470: if-lez v1, :cond_1477
    .line 1472: int-to-float v1, v1
    .line 1473: const/high16 v3, 0x447a
    .line 1475: div-float/2addr v1, v3
    .line 1476: goto :goto_1485
    .line 1477: iget v1, v2, Lcom/titanchess/accessibility/a2;->d:I
    .line 1479: if-lez v1, :cond_1483
    .line 1481: int-to-float v1, v1
    .line 1482: goto :goto_1485
    .line 1483: const/high16 v1, 0x4334
    .line 1485: iget-object v3, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 1487: move-object/from16 v4, v27
    .line 1489: invoke-direct {v4, v3}, Lcom/titanchess/accessibility/TitanAccessibilityService;->fensToUci(Ljava/util/List;)Ljava/util/List;
    .line 1492: move-result-object v3
    .line 1493: invoke-direct/range {v27 .. v27}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getMimic()Lcom/titanchess/accessibility/k1;
    .line 1496: move-result-object v5
    .line 1497: iget-object v2, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 1499: invoke-virtual {v5, v2, v3, v0, v1}, Lcom/titanchess/accessibility/k1;->b(Ljava/lang/String;Ljava/util/List;IF)Ljava/util/List;
    .line 1502: move-result-object v0
    .line 1503: new-instance v1, Ljava/util/ArrayList;
    .line 1505: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1508: move-result v2
    .line 1509: invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 1512: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1515: move-result-object v0
    .line 1516: const/4 v5, 0
    .line 1517: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 1520: move-result v2
    .line 1521: if-eqz v2, :cond_1581
    .line 1523: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1526: move-result-object v2
    .line 1527: add-int/lit8 v3, v5, 1
    .line 1529: if-ltz v5, :cond_1576
    .line 1531: check-cast v2, Ls2/e;
    .line 1533: iget-object v5, v2, Ls2/e;->i:Ljava/lang/Object;
    .line 1535: check-cast v5, Ljava/lang/String;
    .line 1537: iget-object v2, v2, Ls2/e;->j:Ljava/lang/Object;
    .line 1539: check-cast v2, Ljava/lang/Number;
    .line 1541: invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F
    .line 1544: move-result v2
    .line 1545: new-instance v6, Lcom/titanchess/accessibility/f;
    .line 1547: const/4 v7, 0
    .line 1548: const/4 v8, 2
    .line 1549: invoke-virtual {v5, v7, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 1552: move-result-object v9
    .line 1553: const-string v10, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 1555: invoke-static {v9, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1558: const/4 v10, 4
    .line 1559: invoke-virtual {v5, v8, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 1562: move-result-object v5
    .line 1563: const-string v11, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 1565: invoke-static {v5, v11}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1568: invoke-direct {v6, v9, v5, v3, v2}, Lcom/titanchess/accessibility/f;-><init>(Ljava/lang/String;Ljava/lang/String;IF)V
    .line 1571: invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1574: move v5, v3
    .line 1575: goto :goto_1517
    .line 1576: invoke-static {}, Ld2/b;->g1()V
    .line 1579: const/4 v2, 0
    .line 1580: throw v2
    .line 1581: const/4 v2, 0
    .line 1582: invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z
    .line 1585: move-result v0
    .line 1586: if-eqz v0, :cond_1590
    .line 1588: move-object v7, v2
    .line 1589: goto :goto_1591
    .line 1590: move-object v7, v1
    .line 1591: return-object v7
.end method

# direct methods
.method private final computeStockfishC(Lcom/titanchess/accessibility/a2;Lp2/n;I)Ljava/util/List;
    .registers 35

    .line 0: move-object/from16 v1, v31
    .line 2: move-object/from16 v2, v32
    .line 4: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 6: const/4 v3, 0
    .line 7: move-object/from16 v4, v33
    .line 9: if-eq v0, v4, :cond_12
    .line 11: return-object v3
    .line 12: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 14: const/16 v4, 32
    .line 16: invoke-static {v0, v4}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 19: move-result-object v0
    .line 20: iget-object v5, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 22: invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z
    .line 25: move-result v5
    .line 26: const/4 v6, 1
    .line 27: xor-int/2addr v5, v6
    .line 28: if-eqz v5, :cond_49
    .line 30: iget-object v5, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 32: invoke-static {v5}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 35: move-result-object v5
    .line 36: check-cast v5, Ljava/lang/String;
    .line 38: invoke-static {v5, v4}, Lm3/j;->l2(Ljava/lang/String;C)Ljava/lang/String;
    .line 41: move-result-object v5
    .line 42: invoke-static {v5, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 45: move-result v0
    .line 46: if-nez v0, :cond_49
    .line 48: return-object v3
    .line 49: invoke-direct/range {v31 .. v31}, Lcom/titanchess/accessibility/TitanAccessibilityService;->ensureForgeCal()V
    .line 52: const/16 v5, 1000
    .line 54: const/16 v0, 1600
    .line 56: move/from16 v7, v34
    .line 58: invoke-static {v7, v5, v0}, Ld2/b;->G(III)I
    .line 61: move-result v7
    .line 62: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 64: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 67: move-result v0
    .line 68: if-gt v0, v6, :cond_73
    .line 70: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 72: goto :goto_75
    .line 73: iget-object v0, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cLastGameKey:Ljava/lang/String;
    .line 75: iget-object v8, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cLastGameKey:Ljava/lang/String;
    .line 77: invoke-static {v0, v8}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 80: move-result v8
    .line 81: const/4 v9, 0
    .line 82: if-nez v8, :cond_96
    .line 84: iget-object v8, v2, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 86: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 89: move-result v8
    .line 90: if-gt v8, v6, :cond_96
    .line 92: iput v9, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cBestStreak:I
    .line 94: iput-object v0, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cLastGameKey:Ljava/lang/String;
    .line 96: invoke-direct/range {v31 .. v31}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 99: move-result-object v8
    .line 100: iget-object v0, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 102: const-string v10, "position fen "
    .line 104: monitor-enter v8
    .line 105: const-string v11, "fen"
    .line 107: invoke-static {v0, v11}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 110: invoke-virtual {v8}, Lcom/titanchess/accessibility/s1;->e()Z
    .line 113: move-result v11
    .line 114: const/4 v12, 4
    .line 115: if-nez v11, :cond_122
    .line 117: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 119: monitor-exit v8
    .line 120: goto/16 :goto_456
    .line 122: const-string v11, "setoption name MultiPV value 24"
    .line 124: invoke-virtual {v8, v11}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 127: invoke-virtual {v10, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 130: move-result-object v0
    .line 131: invoke-virtual {v8, v0}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 134: const-string v0, "go nodes 80000"
    .line 136: invoke-virtual {v8, v0}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 139: new-instance v0, Ljava/util/HashMap;
    .line 141: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 144: new-instance v10, Ljava/util/HashMap;
    .line 146: invoke-direct {v10}, Ljava/util/HashMap;-><init>()V
    .line 149: iget-object v11, v8, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 151: invoke-static {v11}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 154: invoke-virtual {v11}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    .line 157: move-result-object v13
    .line 158: if-nez v13, :cond_162
    .line 160: goto/16 :goto_293
    .line 162: const-string v14, "bestmove"
    .line 164: invoke-static {v13, v14, v9}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 167: move-result v14
    .line 168: if-nez v14, :cond_293
    .line 170: const-string v14, "info "
    .line 172: invoke-static {v13, v14, v9}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 175: move-result v14
    .line 176: if-eqz v14, :cond_154
    .line 178: const-string v14, " multipv "
    .line 180: invoke-static {v13, v14, v9}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 183: move-result v14
    .line 184: if-nez v14, :cond_187
    .line 186: goto :goto_154
    .line 187: new-array v14, v6, [C
    .line 189: aput-char v4, v14, v9
    .line 191: invoke-static {v13, v14}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 194: move-result-object v14
    .line 195: const-string v15, "multipv"
    .line 197: invoke-interface {v14, v15}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I
    .line 200: move-result v15
    .line 201: add-int/2addr v15, v6
    .line 202: invoke-static {v15, v14}, Lt2/p;->M1(ILjava/util/List;)Ljava/lang/Object;
    .line 205: move-result-object v15
    .line 206: check-cast v15, Ljava/lang/String;
    .line 208: if-eqz v15, :cond_287
    .line 210: invoke-static {v15}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 213: move-result-object v15
    .line 214: if-eqz v15, :cond_287
    .line 216: invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I
    .line 219: move-result v15
    .line 220: invoke-static {v13}, Ld2/c;->o0(Ljava/lang/String;)Ljava/lang/Integer;
    .line 223: move-result-object v13
    .line 224: if-eqz v13, :cond_154
    .line 226: invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I
    .line 229: move-result v13
    .line 230: const-string v4, "pv"
    .line 232: invoke-interface {v14, v4}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I
    .line 235: move-result v4
    .line 236: if-ltz v4, :cond_261
    .line 238: add-int/lit8 v4, v4, 1
    .line 240: if-ltz v4, :cond_256
    .line 242: invoke-static {v14}, Ld2/b;->r0(Ljava/util/List;)I
    .line 245: move-result v5
    .line 246: if-gt v4, v5, :cond_256
    .line 248: invoke-interface {v14, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 251: move-result-object v4
    .line 252: goto :goto_258
    .line 253: move-exception v0
    .line 254: goto/16 :goto_433
    .line 256: const-string v4, ""
    .line 258: check-cast v4, Ljava/lang/String;
    .line 260: goto :goto_263
    .line 261: const-string v4, ""
    .line 263: invoke-virtual {v4}, Ljava/lang/String;->length()I
    .line 266: move-result v5
    .line 267: if-lt v5, v12, :cond_287
    .line 269: invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 272: move-result-object v5
    .line 273: invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 276: move-result-object v13
    .line 277: invoke-virtual {v0, v5, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 280: invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 283: move-result-object v5
    .line 284: invoke-virtual {v10, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 287: const/16 v4, 32
    .line 289: const/16 v5, 1000
    .line 291: goto/16 :goto_154
    .line 293: const-string v4, "setoption name MultiPV value 1"
    .line 295: invoke-virtual {v8, v4}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 298: invoke-virtual {v0}, Ljava/util/HashMap;->isEmpty()Z
    .line 301: move-result v4
    .line 302: if-eqz v4, :cond_308
    .line 304: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 306: goto/16 :goto_437
    .line 308: invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 311: move-result-object v4
    .line 312: invoke-virtual {v0, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 315: move-result-object v4
    .line 316: check-cast v4, Ljava/lang/Integer;
    .line 318: if-nez v4, :cond_337
    .line 320: invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;
    .line 323: move-result-object v4
    .line 324: const-string v5, "<get-values>(...)"
    .line 326: invoke-static {v4, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 329: check-cast v4, Ljava/lang/Iterable;
    .line 331: invoke-static {v4}, Lt2/p;->S1(Ljava/lang/Iterable;)Ljava/lang/Comparable;
    .line 334: move-result-object v4
    .line 335: check-cast v4, Ljava/lang/Integer;
    .line 337: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 340: invoke-virtual {v4}, Ljava/lang/Number;->intValue()I
    .line 343: move-result v4
    .line 344: invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;
    .line 347: move-result-object v5
    .line 348: const-string v11, "<get-keys>(...)"
    .line 350: invoke-static {v5, v11}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 353: check-cast v5, Ljava/lang/Iterable;
    .line 355: invoke-static {v5}, Lt2/p;->V1(Ljava/lang/Iterable;)Ljava/util/List;
    .line 358: move-result-object v5
    .line 359: new-instance v11, Ljava/util/ArrayList;
    .line 361: invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V
    .line 364: invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 367: move-result-object v5
    .line 368: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 371: move-result v13
    .line 372: if-eqz v13, :cond_431
    .line 374: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 377: move-result-object v13
    .line 378: check-cast v13, Ljava/lang/Number;
    .line 380: invoke-virtual {v13}, Ljava/lang/Number;->intValue()I
    .line 383: move-result v13
    .line 384: invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 387: move-result-object v14
    .line 388: invoke-virtual {v0, v14}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 391: move-result-object v14
    .line 392: check-cast v14, Ljava/lang/Integer;
    .line 394: if-nez v14, :cond_398
    .line 396: move-object v15, v3
    .line 397: goto :goto_425
    .line 398: invoke-virtual {v14}, Ljava/lang/Number;->intValue()I
    .line 401: move-result v14
    .line 402: invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 405: move-result-object v13
    .line 406: invoke-virtual {v10, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 409: move-result-object v13
    .line 410: check-cast v13, Ljava/lang/String;
    .line 412: if-nez v13, :cond_415
    .line 414: goto :goto_396
    .line 415: new-instance v15, Lcom/titanchess/accessibility/p1;
    .line 417: sub-int v14, v4, v14
    .line 419: if-gez v14, :cond_422
    .line 421: move v14, v9
    .line 422: invoke-direct {v15, v14, v13}, Lcom/titanchess/accessibility/p1;-><init>(ILjava/lang/String;)V
    .line 425: if-eqz v15, :cond_368
    .line 427: invoke-virtual {v11, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 430: goto :goto_368
    .line 431: move-object v0, v11
    .line 432: goto :goto_437
    .line 433: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 436: move-result-object v0
    .line 437: invoke-static {v0}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 440: move-result-object v4
    .line 441: if-nez v4, :cond_444
    .line 443: goto :goto_453
    .line 444: const-string v0, "TitanEval"
    .line 446: const-string v5, "multiPv fail"
    .line 448: invoke-static {v0, v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 451: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 453: check-cast v0, Ljava/util/List;
    .line 455: monitor-exit v8
    .line 456: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    .line 459: move-result v4
    .line 460: if-eqz v4, :cond_463
    .line 462: return-object v3
    .line 463: iget-object v4, v2, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 465: sget-object v5, Lp2/n;->i:Lp2/n;
    .line 467: if-ne v4, v5, :cond_472
    .line 469: iget v4, v2, Lcom/titanchess/accessibility/a2;->f:I
    .line 471: goto :goto_474
    .line 472: iget v4, v2, Lcom/titanchess/accessibility/a2;->g:I
    .line 474: if-lez v4, :cond_481
    .line 476: int-to-float v4, v4
    .line 477: const/high16 v5, 0x447a
    .line 479: div-float/2addr v4, v5
    .line 480: goto :goto_489
    .line 481: iget v4, v2, Lcom/titanchess/accessibility/a2;->d:I
    .line 483: if-lez v4, :cond_487
    .line 485: int-to-float v4, v4
    .line 486: goto :goto_489
    .line 487: const/high16 v4, 0x4334
    .line 489: iget-object v5, v2, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 491: iget v2, v2, Lcom/titanchess/accessibility/a2;->d:I
    .line 493: if-lez v2, :cond_496
    .line 495: goto :goto_498
    .line 496: const/16 v2, 180
    .line 498: iget v8, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cBestStreak:I
    .line 500: const-string v10, "fen"
    .line 502: invoke-static {v5, v10}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 505: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    .line 508: move-result v10
    .line 509: if-eqz v10, :cond_516
    .line 511: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 513: move-object v2, v3
    .line 514: goto/16 :goto_1894
    .line 516: invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 519: move-result-object v10
    .line 520: const-string v13, "blitz5"
    .line 522: const-string v14, "blitz3"
    .line 524: const-string v15, "bullet"
    .line 526: const-string v3, "rapid10"
    .line 528: if-eqz v10, :cond_605
    .line 530: invoke-static {v10}, Lm3/j;->m2(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .line 533: move-result-object v10
    .line 534: invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 537: move-result-object v10
    .line 538: if-eqz v10, :cond_605
    .line 540: new-instance v12, Lm3/f;
    .line 542: const-string v11, "^(\\d+)"
    .line 544: invoke-direct {v12, v11}, Lm3/f;-><init>(Ljava/lang/String;)V
    .line 547: invoke-static {v12, v10}, Lm3/f;->a(Lm3/f;Ljava/lang/String;)Lm3/e;
    .line 550: move-result-object v10
    .line 551: if-eqz v10, :cond_580
    .line 553: iget-object v11, v10, Lm3/e;->b:Lm3/d;
    .line 555: if-nez v11, :cond_564
    .line 557: new-instance v11, Lm3/d;
    .line 559: invoke-direct {v11, v10}, Lm3/d;-><init>(Lm3/e;)V
    .line 562: iput-object v11, v10, Lm3/e;->b:Lm3/d;
    .line 564: iget-object v10, v10, Lm3/e;->b:Lm3/d;
    .line 566: invoke-static {v10}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 569: invoke-virtual {v10, v6}, Lm3/d;->get(I)Ljava/lang/Object;
    .line 572: move-result-object v10
    .line 573: check-cast v10, Ljava/lang/String;
    .line 575: invoke-static {v10}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 578: move-result-object v10
    .line 579: goto :goto_581
    .line 580: const/4 v10, 0
    .line 581: if-eqz v10, :cond_605
    .line 583: invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I
    .line 586: move-result v10
    .line 587: const/16 v11, 119
    .line 589: if-gt v10, v11, :cond_593
    .line 591: move-object v10, v15
    .line 592: goto :goto_606
    .line 593: const/16 v11, 239
    .line 595: if-gt v10, v11, :cond_599
    .line 597: move-object v10, v14
    .line 598: goto :goto_606
    .line 599: const/16 v11, 419
    .line 601: if-gt v10, v11, :cond_605
    .line 603: move-object v10, v13
    .line 604: goto :goto_606
    .line 605: move-object v10, v3
    .line 606: int-to-float v2, v2
    .line 607: invoke-static {v7, v10}, Ld2/b;->q(ILjava/lang/String;)Lorg/json/JSONObject;
    .line 610: move-result-object v11
    .line 611: const-wide/high16 v16, 0x3ff0
    .line 613: move-object v12, v10
    .line 614: if-eqz v11, :cond_930
    .line 616: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 619: move-result v9
    .line 620: if-le v9, v6, :cond_930
    .line 622: const-string v3, "target_cploss"
    .line 624: const-wide/16 v13, 0
    .line 626: invoke-virtual {v11, v3, v13, v14}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D
    .line 629: move-result-wide v18
    .line 630: mul-double v18, v18, v16
    .line 632: invoke-static {v4, v2}, Ld2/b;->B(FF)D
    .line 635: move-result-wide v13
    .line 636: mul-double v13, v13, v18
    .line 638: new-instance v3, Ljava/util/ArrayList;
    .line 640: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 643: move-result v9
    .line 644: invoke-direct {v3, v9}, Ljava/util/ArrayList;-><init>(I)V
    .line 647: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 650: move-result-object v9
    .line 651: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 654: move-result v11
    .line 655: if-eqz v11, :cond_673
    .line 657: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 660: move-result-object v11
    .line 661: check-cast v11, Lcom/titanchess/accessibility/p1;
    .line 663: iget v11, v11, Lcom/titanchess/accessibility/p1;->b:I
    .line 665: invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 668: move-result-object v11
    .line 669: invoke-virtual {v3, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 672: goto :goto_651
    .line 673: invoke-virtual {v3}, Ljava/util/ArrayList;->size()I
    .line 676: move-result v9
    .line 677: if-gt v9, v6, :cond_691
    .line 679: move-object/from16 v30, v0
    .line 681: move/from16 v19, v7
    .line 683: move/from16 v23, v8
    .line 685: move-object/from16 v28, v12
    .line 687: move-wide/from16 v7, v16
    .line 689: goto/16 :goto_924
    .line 691: invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 694: move-result-object v9
    .line 695: const/4 v11, 0
    .line 696: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 699: move-result v15
    .line 700: if-eqz v15, :cond_714
    .line 702: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 705: move-result-object v15
    .line 706: check-cast v15, Ljava/lang/Number;
    .line 708: invoke-virtual {v15}, Ljava/lang/Number;->intValue()I
    .line 711: move-result v15
    .line 712: add-int/2addr v11, v15
    .line 713: goto :goto_696
    .line 714: move/from16 v19, v7
    .line 716: int-to-double v6, v11
    .line 717: invoke-virtual {v3}, Ljava/util/ArrayList;->size()I
    .line 720: move-result v9
    .line 721: int-to-double v10, v9
    .line 722: div-double/2addr v6, v10
    .line 723: invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 726: move-result-object v9
    .line 727: const-wide/16 v10, 0
    .line 729: const-wide/16 v20, 0
    .line 731: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 734: move-result v15
    .line 735: if-eqz v15, :cond_773
    .line 737: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 740: move-result-object v15
    .line 741: check-cast v15, Ljava/lang/Number;
    .line 743: invoke-virtual {v15}, Ljava/lang/Number;->intValue()I
    .line 746: move-result v15
    .line 747: move-object/from16 v22, v9
    .line 749: neg-int v9, v15
    .line 750: move/from16 v23, v8
    .line 752: int-to-double v8, v9
    .line 753: div-double v8, v8, v16
    .line 755: invoke-static {v8, v9}, Ljava/lang/Math;->exp(D)D
    .line 758: move-result-wide v8
    .line 759: add-double/2addr v10, v8
    .line 760: move-wide/from16 v24, v10
    .line 762: int-to-double v10, v15
    .line 763: mul-double/2addr v8, v10
    .line 764: add-double v20, v8, v20
    .line 766: move-object/from16 v9, v22
    .line 768: move/from16 v8, v23
    .line 770: move-wide/from16 v10, v24
    .line 772: goto :goto_731
    .line 773: move/from16 v23, v8
    .line 775: const-wide/16 v8, 0
    .line 777: cmpl-double v15, v10, v8
    .line 779: if-lez v15, :cond_784
    .line 781: div-double v8, v20, v10
    .line 783: goto :goto_786
    .line 784: const-wide/16 v8, 0
    .line 786: cmpg-double v8, v13, v8
    .line 788: if-gtz v8, :cond_793
    .line 790: move-object/from16 v30, v0
    .line 792: goto :goto_685
    .line 793: cmpl-double v6, v13, v6
    .line 795: const-wide v7, 0x412e848000
    .line 800: if-ltz v6, :cond_808
    .line 802: move-object/from16 v30, v0
    .line 804: move-object/from16 v28, v12
    .line 806: goto/16 :goto_924
    .line 808: move-wide/from16 v9, v16
    .line 810: const/4 v6, 0
    .line 811: const/16 v11, 40
    .line 813: if-ge v6, v11, :cond_915
    .line 815: mul-double v20, v9, v7
    .line 817: invoke-static/range {v20 .. v21}, Ljava/lang/Math;->sqrt(D)D
    .line 820: move-result-wide v20
    .line 821: invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 824: move-result-object v11
    .line 825: const-wide/16 v24, 0
    .line 827: const-wide/16 v26, 0
    .line 829: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 832: move-result v15
    .line 833: if-eqz v15, :cond_878
    .line 835: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 838: move-result-object v15
    .line 839: check-cast v15, Ljava/lang/Number;
    .line 841: invoke-virtual {v15}, Ljava/lang/Number;->intValue()I
    .line 844: move-result v15
    .line 845: move-object/from16 v22, v3
    .line 847: neg-int v3, v15
    .line 848: move-object/from16 v29, v11
    .line 850: move-object/from16 v28, v12
    .line 852: int-to-double v11, v3
    .line 853: div-double v11, v11, v20
    .line 855: invoke-static {v11, v12}, Ljava/lang/Math;->exp(D)D
    .line 858: move-result-wide v11
    .line 859: add-double v24, v24, v11
    .line 861: move-object/from16 v30, v0
    .line 863: int-to-double v0, v15
    .line 864: mul-double/2addr v11, v0
    .line 865: add-double v26, v11, v26
    .line 867: move-object/from16 v1, v31
    .line 869: move-object/from16 v3, v22
    .line 871: move-object/from16 v12, v28
    .line 873: move-object/from16 v11, v29
    .line 875: move-object/from16 v0, v30
    .line 877: goto :goto_829
    .line 878: move-object/from16 v30, v0
    .line 880: move-object/from16 v22, v3
    .line 882: move-object/from16 v28, v12
    .line 884: const-wide/16 v0, 0
    .line 886: cmpl-double v3, v24, v0
    .line 888: if-lez v3, :cond_893
    .line 890: div-double v0, v26, v24
    .line 892: goto :goto_895
    .line 893: const-wide/16 v0, 0
    .line 895: cmpg-double v0, v0, v13
    .line 897: if-gez v0, :cond_902
    .line 899: move-wide/from16 v9, v20
    .line 901: goto :goto_904
    .line 902: move-wide/from16 v7, v20
    .line 904: add-int/lit8 v6, v6, 1
    .line 906: move-object/from16 v1, v31
    .line 908: move-object/from16 v3, v22
    .line 910: move-object/from16 v12, v28
    .line 912: move-object/from16 v0, v30
    .line 914: goto :goto_811
    .line 915: move-object/from16 v30, v0
    .line 917: move-object/from16 v28, v12
    .line 919: mul-double/2addr v9, v7
    .line 920: invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D
    .line 923: move-result-wide v7
    .line 924: move/from16 v1, v19
    .line 926: move-object/from16 v3, v28
    .line 928: goto/16 :goto_1046
    .line 930: move-object/from16 v30, v0
    .line 932: move/from16 v19, v7
    .line 934: move/from16 v23, v8
    .line 936: move-object/from16 v28, v12
    .line 938: const-wide/high16 v0, 0x3ff8
    .line 940: invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 943: move-result-object v0
    .line 944: new-instance v1, Ls2/e;
    .line 946: invoke-direct {v1, v15, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 949: const-wide v6, 0x3ff47ae147ae147b
    .line 954: invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 957: move-result-object v0
    .line 958: new-instance v6, Ls2/e;
    .line 960: invoke-direct {v6, v14, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 963: const-wide v7, 0x3ff1eb851eb851ec
    .line 968: invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 971: move-result-object v0
    .line 972: new-instance v7, Ls2/e;
    .line 974: invoke-direct {v7, v13, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 977: invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 980: move-result-object v0
    .line 981: new-instance v8, Ls2/e;
    .line 983: invoke-direct {v8, v3, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 986: filled-new-array {v1, v6, v7, v8}, [Ls2/e;
    .line 989: move-result-object v0
    .line 990: invoke-static {v0}, Lt2/k;->W0([Ls2/e;)Ljava/util/Map;
    .line 993: move-result-object v0
    .line 994: move/from16 v1, v19
    .line 996: const/16 v3, 2800
    .line 998: const/16 v6, 800
    .line 1000: invoke-static {v1, v6, v3}, Ld2/b;->G(III)I
    .line 1003: move-result v7
    .line 1004: rsub-int v9, v7, 2800
    .line 1006: int-to-double v6, v9
    .line 1007: const-wide v8, 0x4072200000
    .line 1012: mul-double/2addr v8, v6
    .line 1013: const/16 v3, 2000
    .line 1015: int-to-double v6, v3
    .line 1016: div-double/2addr v8, v6
    .line 1017: const-wide/high16 v6, 0x403e
    .line 1019: add-double/2addr v8, v6
    .line 1020: move-object/from16 v3, v28
    .line 1022: invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 1025: move-result-object v0
    .line 1026: check-cast v0, Ljava/lang/Double;
    .line 1028: if-eqz v0, :cond_1035
    .line 1030: invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D
    .line 1033: move-result-wide v6
    .line 1034: goto :goto_1037
    .line 1035: move-wide/from16 v6, v16
    .line 1037: mul-double/2addr v8, v6
    .line 1038: mul-double v8, v8, v16
    .line 1040: invoke-static {v4, v2}, Ld2/b;->B(FF)D
    .line 1043: move-result-wide v6
    .line 1044: mul-double v7, v6, v8
    .line 1046: invoke-interface/range {v30 .. v30}, Ljava/util/List;->isEmpty()Z
    .line 1049: move-result v0
    .line 1050: if-eqz v0, :cond_1058
    .line 1052: new-instance v0, Ljava/util/ArrayList;
    .line 1054: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 1057: goto :goto_1169
    .line 1058: new-instance v0, Ljava/util/ArrayList;
    .line 1060: invoke-static/range {v30 .. v30}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1063: move-result v6
    .line 1064: invoke-direct {v0, v6}, Ljava/util/ArrayList;-><init>(I)V
    .line 1067: invoke-interface/range {v30 .. v30}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1070: move-result-object v6
    .line 1071: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 1074: move-result v9
    .line 1075: if-eqz v9, :cond_1103
    .line 1077: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1080: move-result-object v9
    .line 1081: check-cast v9, Lcom/titanchess/accessibility/p1;
    .line 1083: new-instance v10, Lcom/titanchess/accessibility/u;
    .line 1085: iget-object v11, v9, Lcom/titanchess/accessibility/p1;->a:Ljava/lang/String;
    .line 1087: iget v9, v9, Lcom/titanchess/accessibility/p1;->b:I
    .line 1089: neg-int v12, v9
    .line 1090: int-to-double v12, v12
    .line 1091: div-double/2addr v12, v7
    .line 1092: invoke-static {v12, v13}, Ljava/lang/Math;->exp(D)D
    .line 1095: move-result-wide v12
    .line 1096: invoke-direct {v10, v11, v9, v12, v13}, Lcom/titanchess/accessibility/u;-><init>(Ljava/lang/String;ID)V
    .line 1099: invoke-virtual {v0, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1102: goto :goto_1071
    .line 1103: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 1106: move-result-object v6
    .line 1107: const-wide/16 v7, 0
    .line 1109: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 1112: move-result v9
    .line 1113: if-eqz v9, :cond_1125
    .line 1115: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1118: move-result-object v9
    .line 1119: check-cast v9, Lcom/titanchess/accessibility/u;
    .line 1121: iget-wide v9, v9, Lcom/titanchess/accessibility/u;->c:D
    .line 1123: add-double/2addr v7, v9
    .line 1124: goto :goto_1109
    .line 1125: const-wide/16 v9, 0
    .line 1127: cmpg-double v6, v7, v9
    .line 1129: if-nez v6, :cond_1133
    .line 1131: move-wide/from16 v7, v16
    .line 1133: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 1136: move-result-object v6
    .line 1137: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 1140: move-result v9
    .line 1141: if-eqz v9, :cond_1155
    .line 1143: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1146: move-result-object v9
    .line 1147: check-cast v9, Lcom/titanchess/accessibility/u;
    .line 1149: iget-wide v10, v9, Lcom/titanchess/accessibility/u;->c:D
    .line 1151: div-double/2addr v10, v7
    .line 1152: iput-wide v10, v9, Lcom/titanchess/accessibility/u;->c:D
    .line 1154: goto :goto_1137
    .line 1155: new-instance v6, Lu/r;
    .line 1157: const/4 v7, 5
    .line 1158: invoke-direct {v6, v7}, Lu/r;-><init>(I)V
    .line 1161: invoke-static {v0, v6}, Lt2/p;->W1(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;
    .line 1164: move-result-object v0
    .line 1165: invoke-static {v0}, Lt2/p;->c2(Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 1168: move-result-object v0
    .line 1169: invoke-static {v1, v3}, Ld2/b;->q(ILjava/lang/String;)Lorg/json/JSONObject;
    .line 1172: move-result-object v3
    .line 1173: const-string v6, " "
    .line 1175: const/4 v10, 3
    .line 1176: const/16 v11, 8
    .line 1178: if-eqz v3, :cond_1597
    .line 1180: filled-new-array {v6}, [Ljava/lang/String;
    .line 1183: move-result-object v6
    .line 1184: invoke-static {v5, v6}, Lm3/j;->e2(Ljava/lang/CharSequence;[Ljava/lang/String;)Ljava/util/List;
    .line 1187: move-result-object v6
    .line 1188: const/4 v12, 0
    .line 1189: invoke-interface {v6, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1192: move-result-object v6
    .line 1193: check-cast v6, Ljava/lang/String;
    .line 1195: invoke-virtual {v6}, Ljava/lang/String;->length()I
    .line 1198: move-result v12
    .line 1199: const/4 v13, 0
    .line 1200: const/4 v14, 0
    .line 1201: if-ge v13, v12, :cond_1220
    .line 1203: invoke-virtual {v6, v13}, Ljava/lang/String;->charAt(I)C
    .line 1206: move-result v15
    .line 1207: const-string v7, "nbrqNBRQ"
    .line 1209: invoke-static {v7, v15}, Lm3/j;->H1(Ljava/lang/CharSequence;C)Z
    .line 1212: move-result v7
    .line 1213: if-eqz v7, :cond_1217
    .line 1215: add-int/lit8 v14, v14, 1
    .line 1217: add-int/lit8 v13, v13, 1
    .line 1219: goto :goto_1201
    .line 1220: sub-int/2addr v14, v11
    .line 1221: int-to-double v6, v14
    .line 1222: const-wide/high16 v12, 0x4018
    .line 1224: div-double/2addr v6, v12
    .line 1225: const-wide/high16 v12, 0xbff0
    .line 1227: cmpg-double v14, v6, v12
    .line 1229: if-gez v14, :cond_1233
    .line 1231: move-wide v6, v12
    .line 1232: goto :goto_1239
    .line 1233: cmpl-double v12, v6, v16
    .line 1235: if-lez v12, :cond_1239
    .line 1237: move-wide/from16 v6, v16
    .line 1239: invoke-interface/range {v30 .. v30}, Ljava/util/List;->size()I
    .line 1242: move-result v12
    .line 1243: if-lt v12, v10, :cond_1338
    .line 1245: new-instance v12, Ljava/util/ArrayList;
    .line 1247: invoke-static/range {v30 .. v30}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1250: move-result v13
    .line 1251: invoke-direct {v12, v13}, Ljava/util/ArrayList;-><init>(I)V
    .line 1254: invoke-interface/range {v30 .. v30}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1257: move-result-object v13
    .line 1258: invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z
    .line 1261: move-result v14
    .line 1262: if-eqz v14, :cond_1280
    .line 1264: invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1267: move-result-object v14
    .line 1268: check-cast v14, Lcom/titanchess/accessibility/p1;
    .line 1270: iget v14, v14, Lcom/titanchess/accessibility/p1;->b:I
    .line 1272: invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 1275: move-result-object v14
    .line 1276: invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1279: goto :goto_1258
    .line 1280: invoke-static {v12}, Lt2/p;->V1(Ljava/lang/Iterable;)Ljava/util/List;
    .line 1283: move-result-object v12
    .line 1284: const/4 v13, 2
    .line 1285: invoke-interface {v12, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1288: move-result-object v14
    .line 1289: check-cast v14, Ljava/lang/Number;
    .line 1291: invoke-virtual {v14}, Ljava/lang/Number;->intValue()I
    .line 1294: move-result v13
    .line 1295: const/4 v14, 0
    .line 1296: invoke-interface {v12, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1299: move-result-object v12
    .line 1300: check-cast v12, Ljava/lang/Number;
    .line 1302: invoke-virtual {v12}, Ljava/lang/Number;->intValue()I
    .line 1305: move-result v12
    .line 1306: sub-int/2addr v13, v12
    .line 1307: int-to-double v12, v13
    .line 1308: const-wide v14, 0x4062c00000
    .line 1313: div-double/2addr v12, v14
    .line 1314: const-wide/16 v14, 0
    .line 1316: cmpg-double v20, v12, v14
    .line 1318: if-gez v20, :cond_1324
    .line 1320: const-wide/16 v12, 0
    .line 1322: const/4 v14, 2
    .line 1323: goto :goto_1331
    .line 1324: cmpl-double v14, v12, v16
    .line 1326: if-lez v14, :cond_1322
    .line 1328: move-wide/from16 v12, v16
    .line 1330: goto :goto_1322
    .line 1331: int-to-double v10, v14
    .line 1332: mul-double/2addr v12, v10
    .line 1333: const/4 v10, 1
    .line 1334: int-to-double v8, v10
    .line 1335: sub-double v8, v12, v8
    .line 1337: goto :goto_1342
    .line 1338: const/4 v10, 1
    .line 1339: const/4 v14, 2
    .line 1340: const-wide/16 v8, 0
    .line 1342: int-to-double v11, v10
    .line 1343: add-double/2addr v6, v8
    .line 1344: int-to-double v8, v14
    .line 1345: div-double/2addr v6, v8
    .line 1346: const-wide v8, 0x3fe3333333333333
    .line 1351: mul-double/2addr v6, v8
    .line 1352: add-double/2addr v6, v11
    .line 1353: const-wide v8, 0x3fd999999999999a
    .line 1358: cmpg-double v10, v6, v8
    .line 1360: if-gez v10, :cond_1364
    .line 1362: move-wide v6, v8
    .line 1363: goto :goto_1374
    .line 1364: const-wide v8, 0x3ffb333333333333
    .line 1369: cmpl-double v10, v6, v8
    .line 1371: if-lez v10, :cond_1374
    .line 1373: goto :goto_1362
    .line 1374: const-string v8, "blunder_rate"
    .line 1376: const-wide/16 v9, 0
    .line 1378: invoke-virtual {v3, v8, v9, v10}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D
    .line 1381: move-result-wide v11
    .line 1382: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 1385: move-result v3
    .line 1386: const/4 v8, 2
    .line 1387: if-lt v3, v8, :cond_1597
    .line 1389: cmpg-double v3, v11, v9
    .line 1391: if-gtz v3, :cond_1395
    .line 1393: goto/16 :goto_1597
    .line 1395: mul-double v11, v11, v16
    .line 1397: invoke-static {v4, v2}, Ld2/b;->B(FF)D
    .line 1400: move-result-wide v2
    .line 1401: mul-double/2addr v2, v11
    .line 1402: mul-double/2addr v2, v6
    .line 1403: mul-double v2, v2, v16
    .line 1405: const-wide v6, 0x3feccccccccccccd
    .line 1410: invoke-static {v6, v7, v2, v3}, Ljava/lang/Math;->min(DD)D
    .line 1413: move-result-wide v2
    .line 1414: invoke-static {v5}, Ld2/b;->v0(Ljava/lang/String;)J
    .line 1417: move-result-wide v6
    .line 1418: new-instance v4, Le3/r;
    .line 1420: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 1423: const-wide v8, 0x00ffffffff
    .line 1428: and-long/2addr v6, v8
    .line 1429: iput-wide v6, v4, Le3/r;->i:J
    .line 1431: new-instance v6, Lh/i0;
    .line 1433: const/16 v7, 27
    .line 1435: invoke-direct {v6, v7, v4}, Lh/i0;-><init>(ILjava/lang/Object;)V
    .line 1438: invoke-virtual {v6}, Lh/i0;->s()Ljava/lang/Object;
    .line 1441: move-result-object v4
    .line 1442: check-cast v4, Ljava/lang/Number;
    .line 1444: invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D
    .line 1447: move-result-wide v7
    .line 1448: cmpl-double v2, v7, v2
    .line 1450: if-ltz v2, :cond_1454
    .line 1452: goto/16 :goto_1597
    .line 1454: new-instance v2, Ljava/util/ArrayList;
    .line 1456: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 1459: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1462: move-result-object v3
    .line 1463: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 1466: move-result v4
    .line 1467: if-eqz v4, :cond_1486
    .line 1469: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1472: move-result-object v4
    .line 1473: move-object v7, v4
    .line 1474: check-cast v7, Lcom/titanchess/accessibility/u;
    .line 1476: iget v7, v7, Lcom/titanchess/accessibility/u;->b:I
    .line 1478: const/16 v8, 80
    .line 1480: if-lt v7, v8, :cond_1463
    .line 1482: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1485: goto :goto_1463
    .line 1486: invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z
    .line 1489: move-result v3
    .line 1490: if-eqz v3, :cond_1493
    .line 1492: goto :goto_1597
    .line 1493: invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 1496: move-result-object v3
    .line 1497: const/4 v4, 0
    .line 1498: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 1501: move-result v7
    .line 1502: if-eqz v7, :cond_1514
    .line 1504: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1507: move-result-object v7
    .line 1508: check-cast v7, Lcom/titanchess/accessibility/u;
    .line 1510: iget v7, v7, Lcom/titanchess/accessibility/u;->b:I
    .line 1512: add-int/2addr v4, v7
    .line 1513: goto :goto_1498
    .line 1514: int-to-double v3, v4
    .line 1515: invoke-virtual {v6}, Lh/i0;->s()Ljava/lang/Object;
    .line 1518: move-result-object v6
    .line 1519: check-cast v6, Ljava/lang/Number;
    .line 1521: invoke-virtual {v6}, Ljava/lang/Number;->doubleValue()D
    .line 1524: move-result-wide v6
    .line 1525: mul-double/2addr v6, v3
    .line 1526: invoke-static {v2}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 1529: move-result-object v3
    .line 1530: invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 1533: move-result-object v2
    .line 1534: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 1537: move-result v4
    .line 1538: if-eqz v4, :cond_1557
    .line 1540: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1543: move-result-object v4
    .line 1544: check-cast v4, Lcom/titanchess/accessibility/u;
    .line 1546: iget v8, v4, Lcom/titanchess/accessibility/u;->b:I
    .line 1548: int-to-double v8, v8
    .line 1549: sub-double/2addr v6, v8
    .line 1550: const-wide/16 v8, 0
    .line 1552: cmpg-double v10, v6, v8
    .line 1554: if-gtz v10, :cond_1534
    .line 1556: move-object v3, v4
    .line 1557: new-instance v2, Ljava/util/ArrayList;
    .line 1559: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 1562: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1565: move-result-object v0
    .line 1566: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 1569: move-result v4
    .line 1570: if-eqz v4, :cond_1585
    .line 1572: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1575: move-result-object v4
    .line 1576: move-object v6, v4
    .line 1577: check-cast v6, Lcom/titanchess/accessibility/u;
    .line 1579: if-eq v6, v3, :cond_1566
    .line 1581: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1584: goto :goto_1566
    .line 1585: invoke-static {v3}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 1588: move-result-object v0
    .line 1589: invoke-static {v2, v0}, Lt2/p;->U1(Ljava/util/List;Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 1592: move-result-object v0
    .line 1593: invoke-static {v0}, Lt2/p;->c2(Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 1596: move-result-object v0
    .line 1597: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 1600: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 1603: move-result v2
    .line 1604: const/4 v3, 2
    .line 1605: if-ge v2, v3, :cond_1610
    .line 1607: const/4 v1, 1
    .line 1608: goto/16 :goto_1819
    .line 1610: const/4 v2, 4
    .line 1611: int-to-double v3, v2
    .line 1612: const/16 v2, 2800
    .line 1614: const/16 v6, 800
    .line 1616: invoke-static {v1, v6, v2}, Ld2/b;->G(III)I
    .line 1619: move-result v1
    .line 1620: sub-int/2addr v1, v6
    .line 1621: int-to-double v1, v1
    .line 1622: const-wide v6, 0x409f400000
    .line 1627: div-double/2addr v1, v6
    .line 1628: const/16 v6, 8
    .line 1630: int-to-double v6, v6
    .line 1631: mul-double/2addr v1, v6
    .line 1632: add-double/2addr v1, v3
    .line 1633: const-wide/high16 v3, 0x4010
    .line 1635: cmpg-double v6, v1, v3
    .line 1637: if-gez v6, :cond_1641
    .line 1639: move-wide v1, v3
    .line 1640: goto :goto_1648
    .line 1641: const-wide/high16 v3, 0x4028
    .line 1643: cmpl-double v6, v1, v3
    .line 1645: if-lez v6, :cond_1648
    .line 1647: goto :goto_1639
    .line 1648: invoke-static {v1, v2}, Ld2/b;->Z0(D)I
    .line 1651: move-result v1
    .line 1652: move/from16 v2, v23
    .line 1654: if-ge v2, v1, :cond_1657
    .line 1656: goto :goto_1607
    .line 1657: const/4 v1, 0
    .line 1658: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1661: move-result-object v2
    .line 1662: check-cast v2, Lcom/titanchess/accessibility/u;
    .line 1664: iget v1, v2, Lcom/titanchess/accessibility/u;->b:I
    .line 1666: if-lez v1, :cond_1669
    .line 1668: goto :goto_1607
    .line 1669: new-instance v1, Ljava/util/ArrayList;
    .line 1671: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 1674: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1677: move-result-object v2
    .line 1678: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 1681: move-result v3
    .line 1682: if-eqz v3, :cond_1705
    .line 1684: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1687: move-result-object v3
    .line 1688: move-object v4, v3
    .line 1689: check-cast v4, Lcom/titanchess/accessibility/u;
    .line 1691: iget v4, v4, Lcom/titanchess/accessibility/u;->b:I
    .line 1693: const/16 v6, 15
    .line 1695: if-gt v6, v4, :cond_1678
    .line 1697: const/16 v6, 91
    .line 1699: if-ge v4, v6, :cond_1678
    .line 1701: invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1704: goto :goto_1678
    .line 1705: new-instance v2, Lu/r;
    .line 1707: const/4 v3, 3
    .line 1708: invoke-direct {v2, v3}, Lu/r;-><init>(I)V
    .line 1711: invoke-static {v1, v2}, Lt2/p;->W1(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;
    .line 1714: move-result-object v1
    .line 1715: invoke-interface {v1}, Ljava/util/List;->isEmpty()Z
    .line 1718: move-result v2
    .line 1719: if-eqz v2, :cond_1722
    .line 1721: goto :goto_1607
    .line 1722: invoke-static {v5}, Ld2/b;->v0(Ljava/lang/String;)J
    .line 1725: move-result-wide v2
    .line 1726: const-wide/16 v4, 22291
    .line 1728: xor-long/2addr v2, v4
    .line 1729: new-instance v4, Le3/r;
    .line 1731: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 1734: const-wide v5, 0x00ffffffff
    .line 1739: and-long/2addr v2, v5
    .line 1740: iput-wide v2, v4, Le3/r;->i:J
    .line 1742: new-instance v2, Lh/i0;
    .line 1744: const/16 v3, 27
    .line 1746: invoke-direct {v2, v3, v4}, Lh/i0;-><init>(ILjava/lang/Object;)V
    .line 1749: invoke-virtual {v2}, Lh/i0;->s()Ljava/lang/Object;
    .line 1752: move-result-object v2
    .line 1753: check-cast v2, Ljava/lang/Number;
    .line 1755: invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D
    .line 1758: move-result-wide v2
    .line 1759: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 1762: move-result v4
    .line 1763: const/4 v5, 2
    .line 1764: invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I
    .line 1767: move-result v4
    .line 1768: int-to-double v4, v4
    .line 1769: mul-double/2addr v2, v4
    .line 1770: double-to-int v2, v2
    .line 1771: invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1774: move-result-object v1
    .line 1775: check-cast v1, Lcom/titanchess/accessibility/u;
    .line 1777: new-instance v2, Ljava/util/ArrayList;
    .line 1779: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 1782: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1785: move-result-object v0
    .line 1786: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 1789: move-result v3
    .line 1790: if-eqz v3, :cond_1805
    .line 1792: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1795: move-result-object v3
    .line 1796: move-object v4, v3
    .line 1797: check-cast v4, Lcom/titanchess/accessibility/u;
    .line 1799: if-eq v4, v1, :cond_1786
    .line 1801: invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1804: goto :goto_1786
    .line 1805: invoke-static {v1}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 1808: move-result-object v0
    .line 1809: invoke-static {v2, v0}, Lt2/p;->U1(Ljava/util/List;Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 1812: move-result-object v0
    .line 1813: invoke-static {v0}, Lt2/p;->c2(Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 1816: move-result-object v0
    .line 1817: goto/16 :goto_1607
    .line 1819: invoke-static {v0, v1}, Lt2/p;->X1(Ljava/lang/Iterable;I)Ljava/util/List;
    .line 1822: move-result-object v0
    .line 1823: new-instance v1, Ljava/util/ArrayList;
    .line 1825: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1828: move-result v2
    .line 1829: invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 1832: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1835: move-result-object v0
    .line 1836: const/4 v2, 0
    .line 1837: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 1840: move-result v3
    .line 1841: if-eqz v3, :cond_1892
    .line 1843: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1846: move-result-object v3
    .line 1847: add-int/lit8 v10, v2, 1
    .line 1849: if-ltz v2, :cond_1887
    .line 1851: check-cast v3, Lcom/titanchess/accessibility/u;
    .line 1853: new-instance v2, Lcom/titanchess/accessibility/t;
    .line 1855: iget-object v5, v3, Lcom/titanchess/accessibility/u;->a:Ljava/lang/String;
    .line 1857: iget-wide v6, v3, Lcom/titanchess/accessibility/u;->c:D
    .line 1859: const/16 v11, 1000
    .line 1861: int-to-double v8, v11
    .line 1862: mul-double/2addr v6, v8
    .line 1863: invoke-static {v6, v7}, Ld2/b;->Z0(D)I
    .line 1866: move-result v4
    .line 1867: int-to-double v6, v4
    .line 1868: const-wide v8, 0x408f400000
    .line 1873: div-double v7, v6, v8
    .line 1875: iget v9, v3, Lcom/titanchess/accessibility/u;->b:I
    .line 1877: move-object v4, v2
    .line 1878: move v6, v10
    .line 1879: invoke-direct/range {v4 .. v9}, Lcom/titanchess/accessibility/t;-><init>(Ljava/lang/String;IDI)V
    .line 1882: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1885: move v2, v10
    .line 1886: goto :goto_1837
    .line 1887: invoke-static {}, Ld2/b;->g1()V
    .line 1890: const/4 v2, 0
    .line 1891: throw v2
    .line 1892: const/4 v2, 0
    .line 1893: move-object v0, v1
    .line 1894: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    .line 1897: move-result v1
    .line 1898: if-eqz v1, :cond_1901
    .line 1900: return-object v2
    .line 1901: invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z
    .line 1904: move-result v1
    .line 1905: const/4 v2, 1
    .line 1906: xor-int/2addr v1, v2
    .line 1907: if-eqz v1, :cond_1927
    .line 1909: const/4 v1, 0
    .line 1910: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 1913: move-result-object v3
    .line 1914: check-cast v3, Lcom/titanchess/accessibility/t;
    .line 1916: iget v1, v3, Lcom/titanchess/accessibility/t;->d:I
    .line 1918: if-nez v1, :cond_1927
    .line 1920: move-object/from16 v1, v31
    .line 1922: iget v3, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cBestStreak:I
    .line 1924: add-int/lit8 v12, v3, 1
    .line 1926: goto :goto_1930
    .line 1927: move-object/from16 v1, v31
    .line 1929: const/4 v12, 0
    .line 1930: iput v12, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->cBestStreak:I
    .line 1932: new-instance v2, Ljava/util/ArrayList;
    .line 1934: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 1937: move-result v3
    .line 1938: invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V
    .line 1941: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 1944: move-result-object v0
    .line 1945: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 1948: move-result v3
    .line 1949: if-eqz v3, :cond_1996
    .line 1951: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 1954: move-result-object v3
    .line 1955: check-cast v3, Lcom/titanchess/accessibility/t;
    .line 1957: new-instance v4, Lcom/titanchess/accessibility/f;
    .line 1959: iget-object v5, v3, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 1961: const/4 v6, 0
    .line 1962: const/4 v7, 2
    .line 1963: invoke-virtual {v5, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 1966: move-result-object v5
    .line 1967: const-string v8, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 1969: invoke-static {v5, v8}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1972: iget-object v8, v3, Lcom/titanchess/accessibility/t;->a:Ljava/lang/String;
    .line 1974: const/4 v9, 4
    .line 1975: invoke-virtual {v8, v7, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 1978: move-result-object v8
    .line 1979: const-string v10, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 1981: invoke-static {v8, v10}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 1984: iget v10, v3, Lcom/titanchess/accessibility/t;->b:I
    .line 1986: iget-wide v11, v3, Lcom/titanchess/accessibility/t;->c:D
    .line 1988: double-to-float v3, v11
    .line 1989: invoke-direct {v4, v5, v8, v10, v3}, Lcom/titanchess/accessibility/f;-><init>(Ljava/lang/String;Ljava/lang/String;IF)V
    .line 1992: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 1995: goto :goto_1945
    .line 1996: return-object v2
    .line 1997: move-exception v0
    .line 1998: monitor-exit v8
    .line 1999: throw v0
.end method

# direct methods
.method public static synthetic d(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onServiceConnected$lambda$10(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method private static final debounced$lambda$1(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->compute()V
    .line 8: return-void
.end method

# direct methods
.method public static synthetic e(Lcom/titanchess/accessibility/TitanAccessibilityService;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 2

    .line 0: invoke-static {v0, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onAccessibilityEvent$lambda$16(Lcom/titanchess/accessibility/TitanAccessibilityService;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .line 3: return-void
.end method

# direct methods
.method private final ensureForgeCal()V
    .registers 5

    .line 0: const-string v0, "TitanA11y"
    .line 2: iget-boolean v1, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->cCalLoaded:Z
    .line 4: if-eqz v1, :cond_7
    .line 6: return-void
    .line 7: invoke-virtual {v4}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 10: move-result-object v1
    .line 11: const-string v2, "forge_calibration.json"
    .line 13: invoke-virtual {v1, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 16: move-result-object v1
    .line 17: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 20: invoke-static {v1}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 23: move-result-object v2
    .line 24: const/4 v3, 0
    .line 25: invoke-static {v1, v3}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 28: sget-object v1, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 30: new-instance v3, Ljava/lang/String;
    .line 32: invoke-direct {v3, v2, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 35: new-instance v1, Lorg/json/JSONObject;
    .line 37: invoke-direct {v1, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    .line 40: const-string v2, "buckets"
    .line 42: invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 45: move-result-object v2
    .line 46: if-nez v2, :cond_49
    .line 48: goto :goto_50
    .line 49: move-object v1, v2
    .line 50: sput-object v1, Ld2/b;->c:Lorg/json/JSONObject;
    .line 52: const/4 v1, 1
    .line 53: iput-boolean v1, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->cCalLoaded:Z
    .line 55: const-string v1, "forge calibration loaded"
    .line 57: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 60: move-result v1
    .line 61: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 64: move-result-object v1
    .line 65: goto :goto_79
    .line 66: move-exception v1
    .line 67: goto :goto_75
    .line 68: move-exception v2
    .line 69: throw v2
    .line 70: move-exception v3
    .line 71: invoke-static {v1, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 74: throw v3
    .line 75: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 78: move-result-object v1
    .line 79: invoke-static {v1}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 82: move-result-object v1
    .line 83: if-eqz v1, :cond_90
    .line 85: const-string v2, "forge cal load fail"
    .line 87: invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 90: return-void
.end method

# direct methods
.method private final ensureOverlay()Lcom/titanchess/accessibility/d;
    .registers 10

    .line 0: iget-object v0, v9, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 2: if-eqz v0, :cond_5
    .line 4: return-object v0
    .line 5: const-string v0, "window"
    .line 7: invoke-virtual {v9, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    .line 10: move-result-object v0
    .line 11: const-string v1, "null cannot be cast to non-null type android.view.WindowManager"
    .line 13: invoke-static {v0, v1}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: check-cast v0, Landroid/view/WindowManager;
    .line 18: new-instance v1, Lcom/titanchess/accessibility/d;
    .line 20: invoke-direct {v1, v9}, Lcom/titanchess/accessibility/d;-><init>(Landroid/content/Context;)V
    .line 23: new-instance v8, Landroid/view/WindowManager$LayoutParams;
    .line 25: const/4 v3, -1
    .line 26: const/4 v4, -1
    .line 27: const/16 v5, 2032
    .line 29: const/16 v6, 792
    .line 31: const/4 v7, -3
    .line 32: move-object v2, v8
    .line 33: invoke-direct/range {v2 .. v7}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V
    .line 36: invoke-interface {v0, v1, v8}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .line 39: iput-object v1, v9, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 41: return-object v1
.end method

# direct methods
.method public static synthetic f(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced$lambda$1(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method private final fensToUci(Ljava/util/List;)Ljava/util/List;
    .registers 13

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 5: move-result v1
    .line 6: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    .line 9: invoke-interface {v12}, Ljava/util/List;->size()I
    .line 12: move-result v1
    .line 13: const/4 v2, 1
    .line 14: move v3, v2
    .line 15: if-ge v3, v1, :cond_112
    .line 17: new-instance v4, Lp2/e;
    .line 19: invoke-direct {v4}, Lp2/e;-><init>()V
    .line 22: add-int/lit8 v5, v3, -1
    .line 24: invoke-interface {v12, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 27: move-result-object v5
    .line 28: check-cast v5, Ljava/lang/String;
    .line 30: invoke-virtual {v4, v5}, Lp2/e;->n(Ljava/lang/String;)V
    .line 33: new-instance v5, Lp2/e;
    .line 35: invoke-direct {v5}, Lp2/e;-><init>()V
    .line 38: invoke-interface {v12, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 41: move-result-object v6
    .line 42: check-cast v6, Ljava/lang/String;
    .line 44: invoke-virtual {v5, v6}, Lp2/e;->n(Ljava/lang/String;)V
    .line 47: iget-wide v5, v5, Lp2/e;->x:J
    .line 49: invoke-static {v4}, Ld2/b;->j0(Lp2/e;)Ljava/util/LinkedList;
    .line 52: move-result-object v7
    .line 53: invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 56: move-result-object v7
    .line 57: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 60: move-result v8
    .line 61: if-eqz v8, :cond_109
    .line 63: invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 66: move-result-object v8
    .line 67: check-cast v8, Lr2/a;
    .line 69: invoke-virtual {v4, v8}, Lp2/e;->a(Lr2/a;)V
    .line 72: iget-wide v9, v4, Lp2/e;->x:J
    .line 74: cmp-long v9, v9, v5
    .line 76: if-nez v9, :cond_80
    .line 78: move v9, v2
    .line 79: goto :goto_81
    .line 80: const/4 v9, 0
    .line 81: invoke-virtual {v4}, Lp2/e;->s()V
    .line 84: if-eqz v9, :cond_57
    .line 86: invoke-virtual {v8}, Lr2/a;->toString()Ljava/lang/String;
    .line 89: move-result-object v4
    .line 90: const-string v5, "toString(...)"
    .line 92: invoke-static {v4, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 95: sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;
    .line 97: invoke-virtual {v4, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 100: move-result-object v4
    .line 101: const-string v5, "this as java.lang.String).toLowerCase(Locale.ROOT)"
    .line 103: invoke-static {v4, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 106: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 109: add-int/lit8 v3, v3, 1
    .line 111: goto :goto_15
    .line 112: return-object v0
.end method

# direct methods
.method private final findAvatars(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 6

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: const/4 v1, 2
    .line 3: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    .line 6: const-string v2, "com.chess:id/avatarImg"
    .line 8: invoke-virtual {v5, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;
    .line 11: move-result-object v5
    .line 12: if-nez v5, :cond_15
    .line 14: return-void
    .line 15: invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 18: move-result-object v5
    .line 19: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 22: move-result v2
    .line 23: if-eqz v2, :cond_49
    .line 25: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 28: move-result-object v2
    .line 29: check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 31: new-instance v3, Landroid/graphics/Rect;
    .line 33: invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V
    .line 36: invoke-virtual {v2, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V
    .line 39: invoke-virtual {v3}, Landroid/graphics/Rect;->width()I
    .line 42: move-result v2
    .line 43: if-lez v2, :cond_19
    .line 45: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 48: goto :goto_19
    .line 49: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 52: move-result v5
    .line 53: if-ge v5, v1, :cond_67
    .line 55: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    .line 58: move-result v5
    .line 59: if-eqz v5, :cond_66
    .line 61: const/4 v5, 0
    .line 62: iput-object v5, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->avatarTop:Ls2/e;
    .line 64: iput-object v5, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->avatarBottom:Ls2/e;
    .line 66: return-void
    .line 67: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 70: move-result v5
    .line 71: const/4 v1, 1
    .line 72: if-le v5, v1, :cond_83
    .line 74: new-instance v5, Lu/r;
    .line 76: const/4 v1, 7
    .line 77: invoke-direct {v5, v1}, Lu/r;-><init>(I)V
    .line 80: invoke-static {v0, v5}, Lt2/l;->F1(Ljava/util/List;Ljava/util/Comparator;)V
    .line 83: invoke-static {v0}, Lt2/p;->K1(Ljava/util/List;)Ljava/lang/Object;
    .line 86: move-result-object v5
    .line 87: check-cast v5, Landroid/graphics/Rect;
    .line 89: invoke-static {v0}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 92: move-result-object v0
    .line 93: check-cast v0, Landroid/graphics/Rect;
    .line 95: iget v1, v5, Landroid/graphics/Rect;->left:I
    .line 97: int-to-float v1, v1
    .line 98: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 101: move-result-object v1
    .line 102: iget v5, v5, Landroid/graphics/Rect;->top:I
    .line 104: int-to-float v5, v5
    .line 105: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 108: move-result-object v5
    .line 109: new-instance v2, Ls2/e;
    .line 111: invoke-direct {v2, v1, v5}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 114: iput-object v2, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->avatarTop:Ls2/e;
    .line 116: iget v5, v0, Landroid/graphics/Rect;->left:I
    .line 118: int-to-float v5, v5
    .line 119: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 122: move-result-object v5
    .line 123: iget v0, v0, Landroid/graphics/Rect;->top:I
    .line 125: int-to-float v0, v0
    .line 126: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 129: move-result-object v0
    .line 130: new-instance v1, Ls2/e;
    .line 132: invoke-direct {v1, v5, v0}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 135: iput-object v1, v4, Lcom/titanchess/accessibility/TitanAccessibilityService;->avatarBottom:Ls2/e;
    .line 137: return-void
.end method

# direct methods
.method private final findBoard(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .registers 5

    .line 0: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I
    .line 3: move-result v0
    .line 4: const/16 v1, 64
    .line 6: if-ne v0, v1, :cond_9
    .line 8: return-object v4
    .line 9: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I
    .line 12: move-result v0
    .line 13: const/4 v1, 0
    .line 14: if-ge v1, v0, :cond_33
    .line 16: invoke-virtual {v4, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 19: move-result-object v2
    .line 20: if-nez v2, :cond_23
    .line 22: goto :goto_30
    .line 23: invoke-direct {v3, v2}, Lcom/titanchess/accessibility/TitanAccessibilityService;->findBoard(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 26: move-result-object v2
    .line 27: if-eqz v2, :cond_30
    .line 29: return-object v2
    .line 30: add-int/lit8 v1, v1, 1
    .line 32: goto :goto_14
    .line 33: const/4 v4, 0
    .line 34: return-object v4
.end method

# direct methods
.method public static synthetic g(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .registers 2

    .line 0: invoke-static {v0, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->compute$lambda$29$lambda$26(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .line 3: return-void
.end method

# direct methods
.method private final getBrain()Lcom/titanchess/accessibility/g;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->brain$delegate:Ls2/b;
    .line 2: invoke-interface {v0}, Ls2/b;->getValue()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lcom/titanchess/accessibility/g;
    .line 8: return-object v0
.end method

# direct methods
.method private final getMimic()Lcom/titanchess/accessibility/k1;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->mimic$delegate:Ls2/b;
    .line 2: invoke-interface {v0}, Ls2/b;->getValue()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lcom/titanchess/accessibility/k1;
    .line 8: return-object v0
.end method

# direct methods
.method private final getSf()Lcom/titanchess/accessibility/s1;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->sf$delegate:Ls2/b;
    .line 2: invoke-interface {v0}, Ls2/b;->getValue()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lcom/titanchess/accessibility/s1;
    .line 8: return-object v0
.end method

# direct methods
.method private final gradeLastMove(Ljava/util/List;)V
    .registers 12

    .line 0: const-string v0, "TitanA11y"
    .line 2: const-string v1, "badge "
    .line 4: invoke-static {v10}, Lcom/titanchess/accessibility/e;->g(Landroid/content/Context;)Z
    .line 7: move-result v2
    .line 8: const/4 v3, 0
    .line 9: if-nez v2, :cond_29
    .line 11: iget-object v11, v10, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 13: if-eqz v11, :cond_25
    .line 15: iget-object v1, v11, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 17: if-nez v1, :cond_20
    .line 19: goto :goto_25
    .line 20: iput-object v3, v11, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 22: invoke-virtual {v11}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 25: return-void
    .line 26: move-exception v11
    .line 27: goto/16 :goto_235
    .line 29: const-string v2, "titan"
    .line 31: const/4 v4, 0
    .line 32: invoke-virtual {v10, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 35: move-result-object v2
    .line 36: const-string v4, "badge_on"
    .line 38: const/4 v5, 1
    .line 39: invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 42: move-result v2
    .line 43: if-nez v2, :cond_60
    .line 45: iget-object v11, v10, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 47: if-eqz v11, :cond_59
    .line 49: iget-object v1, v11, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 51: if-nez v1, :cond_54
    .line 53: goto :goto_59
    .line 54: iput-object v3, v11, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 56: invoke-virtual {v11}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 59: return-void
    .line 60: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 63: move-result v2
    .line 64: const/4 v3, 2
    .line 65: if-ge v2, v3, :cond_68
    .line 67: return-void
    .line 68: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 71: move-result v2
    .line 72: sub-int/2addr v2, v3
    .line 73: invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 76: move-result-object v2
    .line 77: check-cast v2, Ljava/lang/String;
    .line 79: invoke-static {v11}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 82: move-result-object v4
    .line 83: check-cast v4, Ljava/lang/String;
    .line 85: invoke-direct {v10, v11}, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastMove(Ljava/util/List;)Ljava/lang/String;
    .line 88: move-result-object v6
    .line 89: if-nez v6, :cond_92
    .line 91: return-void
    .line 92: const/4 v7, 4
    .line 93: invoke-virtual {v6, v3, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 96: move-result-object v3
    .line 97: const-string v7, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 99: invoke-static {v3, v7}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 102: iget-object v7, v10, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 104: invoke-interface {v7, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 107: move-result-object v3
    .line 108: check-cast v3, Ls2/e;
    .line 110: if-nez v3, :cond_113
    .line 112: return-void
    .line 113: invoke-direct {v10}, Lcom/titanchess/accessibility/TitanAccessibilityService;->squarePx()F
    .line 116: move-result v7
    .line 117: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 120: move-result v8
    .line 121: sub-int/2addr v8, v5
    .line 122: invoke-static {v4}, Lcom/titanchess/accessibility/e;->f(Ljava/lang/String;)Z
    .line 125: move-result v5
    .line 126: if-eqz v5, :cond_131
    .line 128: sget-object v2, Lcom/titanchess/accessibility/k;->j:Lcom/titanchess/accessibility/k;
    .line 130: goto :goto_160
    .line 131: invoke-direct {v10}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 134: move-result-object v5
    .line 135: invoke-virtual {v5, v2, v4, v6}, Lcom/titanchess/accessibility/s1;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/titanchess/accessibility/q1;
    .line 138: move-result-object v2
    .line 139: if-nez v2, :cond_142
    .line 141: return-void
    .line 142: iget-object v4, v2, Lcom/titanchess/accessibility/q1;->a:Lcom/titanchess/accessibility/k;
    .line 144: invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 147: move-result-object v5
    .line 148: iget-object v8, v10, Lcom/titanchess/accessibility/TitanAccessibilityService;->accCp:Ljava/util/concurrent/ConcurrentHashMap;
    .line 150: iget v2, v2, Lcom/titanchess/accessibility/q1;->b:I
    .line 152: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 155: move-result-object v2
    .line 156: invoke-interface {v8, v5, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 159: move-object v2, v4
    .line 160: iget-object v4, v10, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 162: if-eqz v4, :cond_192
    .line 164: new-instance v5, Lcom/titanchess/accessibility/c;
    .line 166: iget-object v8, v3, Ls2/e;->i:Ljava/lang/Object;
    .line 168: check-cast v8, Ljava/lang/Number;
    .line 170: invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F
    .line 173: move-result v8
    .line 174: iget-object v3, v3, Ls2/e;->j:Ljava/lang/Object;
    .line 176: check-cast v3, Ljava/lang/Number;
    .line 178: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 181: move-result v3
    .line 182: iget-object v9, v2, Lcom/titanchess/accessibility/k;->i:Ljava/lang/String;
    .line 184: invoke-direct {v5, v8, v3, v9, v7}, Lcom/titanchess/accessibility/c;-><init>(FFLjava/lang/String;F)V
    .line 187: iput-object v5, v4, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 189: invoke-virtual {v4}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 192: invoke-direct {v10}, Lcom/titanchess/accessibility/TitanAccessibilityService;->renderAccuracy()V
    .line 195: invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;
    .line 198: move-result-object v2
    .line 199: invoke-interface {v11}, Ljava/util/List;->size()I
    .line 202: move-result v11
    .line 203: new-instance v3, Ljava/lang/StringBuilder;
    .line 205: invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 208: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 211: const-string v1, " "
    .line 213: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 216: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 219: const-string v1, " plies="
    .line 221: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 224: invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 227: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 230: move-result-object v11
    .line 231: invoke-static {v0, v11}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 234: goto :goto_240
    .line 235: const-string v1, "grade fail"
    .line 237: invoke-static {v0, v1, v11}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 240: return-void
.end method

# direct methods
.method public static synthetic h(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onServiceConnected$lambda$12(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method public static synthetic i(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .registers 2

    .line 0: invoke-static {v0, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->compute$lambda$29$lambda$28(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .line 3: return-void
.end method

# direct methods
.method public static synthetic j(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->maybeRecheckLicense$lambda$38(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method public static synthetic k(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 1

    .line 0: invoke-static {v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->onAccessibilityEvent$lambda$13(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 3: return-void
.end method

# direct methods
.method public static synthetic l(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;Ljava/util/List;Ljava/lang/String;ILp2/n;)V
    .registers 6

    .line 0: invoke-static/range {v0 .. v5}, Lcom/titanchess/accessibility/TitanAccessibilityService;->recolorWithStockfish$lambda$35(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;Ljava/util/List;Ljava/lang/String;ILp2/n;)V
    .line 3: return-void
.end method

# direct methods
.method private final lastMove(Ljava/util/List;)Ljava/lang/String;
    .registers 9

    .line 0: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 3: move-result v0
    .line 4: const/4 v1, 0
    .line 5: const/4 v2, 2
    .line 6: if-ge v0, v2, :cond_9
    .line 8: return-object v1
    .line 9: new-instance v0, Lp2/e;
    .line 11: invoke-direct {v0}, Lp2/e;-><init>()V
    .line 14: invoke-interface {v8}, Ljava/util/List;->size()I
    .line 17: move-result v3
    .line 18: sub-int/2addr v3, v2
    .line 19: invoke-interface {v8, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 22: move-result-object v2
    .line 23: check-cast v2, Ljava/lang/String;
    .line 25: invoke-virtual {v0, v2}, Lp2/e;->n(Ljava/lang/String;)V
    .line 28: new-instance v2, Lp2/e;
    .line 30: invoke-direct {v2}, Lp2/e;-><init>()V
    .line 33: invoke-static {v8}, Lt2/p;->Q1(Ljava/util/List;)Ljava/lang/Object;
    .line 36: move-result-object v8
    .line 37: check-cast v8, Ljava/lang/String;
    .line 39: invoke-virtual {v2, v8}, Lp2/e;->n(Ljava/lang/String;)V
    .line 42: iget-wide v2, v2, Lp2/e;->x:J
    .line 44: invoke-static {v0}, Ld2/b;->j0(Lp2/e;)Ljava/util/LinkedList;
    .line 47: move-result-object v8
    .line 48: invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 51: move-result-object v8
    .line 52: invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z
    .line 55: move-result v4
    .line 56: if-eqz v4, :cond_102
    .line 58: invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 61: move-result-object v4
    .line 62: check-cast v4, Lr2/a;
    .line 64: invoke-virtual {v0, v4}, Lp2/e;->a(Lr2/a;)V
    .line 67: iget-wide v5, v0, Lp2/e;->x:J
    .line 69: cmp-long v5, v5, v2
    .line 71: if-nez v5, :cond_75
    .line 73: const/4 v5, 1
    .line 74: goto :goto_76
    .line 75: const/4 v5, 0
    .line 76: invoke-virtual {v0}, Lp2/e;->s()V
    .line 79: if-eqz v5, :cond_52
    .line 81: invoke-virtual {v4}, Lr2/a;->toString()Ljava/lang/String;
    .line 84: move-result-object v8
    .line 85: const-string v0, "toString(...)"
    .line 87: invoke-static {v8, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 90: sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;
    .line 92: invoke-virtual {v8, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 95: move-result-object v8
    .line 96: const-string v0, "this as java.lang.String).toLowerCase(Locale.ROOT)"
    .line 98: invoke-static {v8, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 101: return-object v8
    .line 102: return-object v1
.end method

# direct methods
.method public static synthetic m(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;IZLjava/util/List;)V
    .registers 7

    .line 0: invoke-static/range {v0 .. v6}, Lcom/titanchess/accessibility/TitanAccessibilityService;->compute$lambda$29(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;IZLjava/util/List;)V
    .line 3: return-void
.end method

# direct methods
.method private final maybeRecheckLicense()V
    .registers 7

    .line 0: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    .line 3: move-result-wide v0
    .line 4: iget-wide v2, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastLicCheckMs:J
    .line 6: sub-long v2, v0, v2
    .line 8: iget-wide v4, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->LIC_RECHECK_MS:J
    .line 10: cmp-long v2, v2, v4
    .line 12: if-gez v2, :cond_15
    .line 14: return-void
    .line 15: iput-wide v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastLicCheckMs:J
    .line 17: iget-object v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->licWorker:Ljava/util/concurrent/ExecutorService;
    .line 19: new-instance v1, Lcom/titanchess/accessibility/v1;
    .line 21: const/4 v2, 1
    .line 22: invoke-direct {v1, v6, v2}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 25: invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 28: return-void
.end method

# direct methods
.method private static final maybeRecheckLicense$lambda$38(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 5

    .line 0: const-string v0, ""
    .line 2: const-string v1, "this$0"
    .line 4: invoke-static {v4, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: invoke-static {v4}, Lcom/titanchess/accessibility/e;->c(Landroid/content/Context;)V
    .line 10: const-string v1, "titan"
    .line 12: const/4 v2, 0
    .line 13: invoke-virtual {v4, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 16: move-result-object v1
    .line 17: const-string v2, "lic_key"
    .line 19: invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 22: move-result-object v2
    .line 23: if-nez v2, :cond_26
    .line 25: goto :goto_27
    .line 26: move-object v0, v2
    .line 27: invoke-static {v0}, Lm3/j;->R1(Ljava/lang/CharSequence;)Z
    .line 30: move-result v2
    .line 31: xor-int/lit8 v2, v2, 1
    .line 33: if-eqz v2, :cond_57
    .line 35: const-string v2, "lic_status"
    .line 37: const-string v3, "none"
    .line 39: invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 42: move-result-object v1
    .line 43: const-string v2, "active"
    .line 45: invoke-static {v1, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 48: move-result v1
    .line 49: if-eqz v1, :cond_57
    .line 51: invoke-static {v4, v0}, Lcom/titanchess/accessibility/e;->j(Landroid/content/Context;Ljava/lang/String;)Lcom/titanchess/accessibility/w;
    .line 54: goto :goto_57
    .line 55: move-exception v4
    .line 56: goto :goto_60
    .line 57: sget-object v4, Ls2/k;->a:Ls2/k;
    .line 59: goto :goto_64
    .line 60: invoke-static {v4}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 63: move-result-object v4
    .line 64: invoke-static {v4}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 67: move-result-object v4
    .line 68: if-eqz v4, :cond_77
    .line 70: const-string v0, "TitanA11y"
    .line 72: const-string v1, "lic recheck"
    .line 74: invoke-static {v0, v1, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 77: return-void
.end method

# direct methods
.method private static final onAccessibilityEvent$lambda$13(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v1, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 7: if-eqz v1, :cond_12
    .line 9: invoke-virtual {v1}, Lcom/titanchess/accessibility/s;->d()V
    .line 12: return-void
.end method

# direct methods
.method private static final onAccessibilityEvent$lambda$14(ZLcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 3

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: if-eqz v1, :cond_15
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 9: if-eqz v1, :cond_22
    .line 11: invoke-virtual {v1}, Lcom/titanchess/accessibility/s;->d()V
    .line 14: goto :goto_22
    .line 15: iget-object v1, v2, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 17: if-eqz v1, :cond_22
    .line 19: invoke-virtual {v1}, Lcom/titanchess/accessibility/s;->h()V
    .line 22: return-void
.end method

# direct methods
.method private static final onAccessibilityEvent$lambda$16(Lcom/titanchess/accessibility/TitanAccessibilityService;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 3

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "$root"
    .line 7: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v1, v2}, Lcom/titanchess/accessibility/TitanAccessibilityService;->refreshCoords(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .line 13: goto :goto_18
    .line 14: move-exception v1
    .line 15: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 18: return-void
.end method

# direct methods
.method private static final onServiceConnected$lambda$10(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->ensureOverlay()Lcom/titanchess/accessibility/d;
    .line 8: return-void
.end method

# direct methods
.method private static final onServiceConnected$lambda$12(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Lcom/titanchess/accessibility/s;
    .line 7: invoke-direct {v0, v1}, Lcom/titanchess/accessibility/s;-><init>(Landroid/content/Context;)V
    .line 10: invoke-virtual {v0}, Lcom/titanchess/accessibility/s;->h()V
    .line 13: iput-object v0, v1, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 15: return-void
.end method

# direct methods
.method private static final onServiceConnected$lambda$4(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 3

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v2}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getBrain()Lcom/titanchess/accessibility/g;
    .line 8: move-result-object v2
    .line 9: invoke-virtual {v2}, Lcom/titanchess/accessibility/g;->a()V
    .line 12: sget-object v2, Ls2/k;->a:Ls2/k;
    .line 14: goto :goto_20
    .line 15: move-exception v2
    .line 16: invoke-static {v2}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 19: move-result-object v2
    .line 20: invoke-static {v2}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 23: move-result-object v2
    .line 24: if-eqz v2, :cond_33
    .line 26: const-string v0, "TitanA11y"
    .line 28: const-string v1, "warmup"
    .line 30: invoke-static {v0, v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 33: return-void
.end method

# direct methods
.method private static final onServiceConnected$lambda$9(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 4

    .line 0: const-string v0, "this$0"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Lcom/titanchess/accessibility/e;->b:Lcom/titanchess/accessibility/e;
    .line 7: invoke-virtual {v0, v3}, Lcom/titanchess/accessibility/e;->i(Landroid/content/Context;)V
    .line 10: sget-object v0, Ls2/k;->a:Ls2/k;
    .line 12: goto :goto_18
    .line 13: move-exception v0
    .line 14: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 17: move-result-object v0
    .line 18: invoke-static {v0}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 21: move-result-object v0
    .line 22: const-string v1, "TitanA11y"
    .line 24: if-eqz v0, :cond_31
    .line 26: const-string v2, "book load"
    .line 28: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 31: invoke-direct {v3}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 34: move-result-object v3
    .line 35: invoke-virtual {v3}, Lcom/titanchess/accessibility/s1;->e()Z
    .line 38: move-result v3
    .line 39: invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 42: move-result-object v3
    .line 43: goto :goto_49
    .line 44: move-exception v3
    .line 45: invoke-static {v3}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 48: move-result-object v3
    .line 49: invoke-static {v3}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 52: move-result-object v3
    .line 53: if-eqz v3, :cond_60
    .line 55: const-string v0, "sf warm"
    .line 57: invoke-static {v1, v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 60: return-void
.end method

# direct methods
.method private final probeDepthVsNodes(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/titanchess/accessibility/k;I)V
    .registers 36

    .line 0: move-object/from16 v0, v31
    .line 2: move-object/from16 v1, v33
    .line 4: const-string v2, "INSTRUMENT"
    .line 6: const-string v3, "format(this, *args)"
    .line 8: const-string v4, "%.1f"
    .line 10: const-string v5, " d10="
    .line 12: const-string v6, "ply="
    .line 14: const-string v7, " w "
    .line 16: const/4 v8, 0
    .line 17: invoke-static {v0, v7, v8}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 20: move-result v7
    .line 21: invoke-direct/range {v30 .. v30}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 24: move-result-object v9
    .line 25: invoke-virtual {v9, v0}, Lcom/titanchess/accessibility/s1;->c(Ljava/lang/String;)Lcom/titanchess/accessibility/r1;
    .line 28: move-result-object v0
    .line 29: if-nez v0, :cond_32
    .line 31: return-void
    .line 32: iget v9, v0, Lcom/titanchess/accessibility/r1;->a:I
    .line 34: invoke-direct/range {v30 .. v30}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 37: move-result-object v10
    .line 38: move-object/from16 v11, v32
    .line 40: invoke-virtual {v10, v11}, Lcom/titanchess/accessibility/s1;->c(Ljava/lang/String;)Lcom/titanchess/accessibility/r1;
    .line 43: move-result-object v10
    .line 44: if-nez v10, :cond_47
    .line 46: return-void
    .line 47: iget v11, v10, Lcom/titanchess/accessibility/r1;->a:I
    .line 49: neg-int v11, v11
    .line 50: invoke-virtual/range {v33 .. v33}, Ljava/lang/String;->length()I
    .line 53: move-result v12
    .line 54: if-lez v12, :cond_70
    .line 56: iget-object v12, v0, Lcom/titanchess/accessibility/r1;->b:Ljava/lang/String;
    .line 58: invoke-static {v1, v12}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 61: move-result v12
    .line 62: if-eqz v12, :cond_70
    .line 64: const/4 v12, 1
    .line 65: goto :goto_71
    .line 66: move-exception v0
    .line 67: move-object v1, v2
    .line 68: goto/16 :goto_419
    .line 70: move v12, v8
    .line 71: invoke-static {v9, v11, v12}, Ld2/c;->u(IIZ)Lcom/titanchess/accessibility/k;
    .line 74: move-result-object v14
    .line 75: invoke-static {v9}, Ld2/c;->F(I)D
    .line 78: move-result-wide v15
    .line 79: const-wide/high16 v17, 0x4059
    .line 81: mul-double v15, v15, v17
    .line 83: invoke-static {v11}, Ld2/c;->F(I)D
    .line 86: move-result-wide v19
    .line 87: mul-double v19, v19, v17
    .line 89: cmpl-double v21, v19, v15
    .line 91: if-ltz v21, :cond_96
    .line 93: move-object/from16 v8, v34
    .line 95: goto :goto_136
    .line 96: sub-double v17, v15, v19
    .line 98: const-wide v21, 0xbfa64b6b5996dcf
    .line 103: mul-double v17, v17, v21
    .line 105: invoke-static/range {v17 .. v18}, Ljava/lang/Math;->exp(D)D
    .line 108: move-result-wide v17
    .line 109: const-wide v21, 0x4059caad42612fd
    .line 114: mul-double v17, v17, v21
    .line 116: const-wide v21, 0x400955dca3601f8e
    .line 121: sub-double v17, v17, v21
    .line 123: const-wide/high16 v21, 0x3ff0
    .line 125: add-double v23, v17, v21
    .line 127: const-wide/16 v25, 0
    .line 129: const-wide/high16 v27, 0x4059
    .line 131: invoke-static/range {v23 .. v28}, Ld2/b;->E(DDD)D
    .line 134: move-result-wide v17
    .line 135: goto :goto_93
    .line 136: if-ne v8, v14, :cond_143
    .line 138: const-string v22, "SAME"
    .line 140: move-object/from16 v29, v22
    .line 142: goto :goto_146
    .line 143: const-string v22, "DIFF"
    .line 145: goto :goto_140
    .line 146: invoke-direct/range {v30 .. v30}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 149: move-result-object v22
    .line 150: invoke-virtual/range {v22 .. v22}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 153: invoke-virtual/range {v34 .. v34}, Ljava/lang/Enum;->name()Ljava/lang/String;
    .line 156: move-result-object v8
    .line 157: invoke-virtual {v14}, Ljava/lang/Enum;->name()Ljava/lang/String;
    .line 160: move-result-object v14
    .line 161: iget v13, v0, Lcom/titanchess/accessibility/r1;->d:I
    .line 163: move-object/from16 v22, v2
    .line 165: iget v2, v10, Lcom/titanchess/accessibility/r1;->d:I
    .line 167: move/from16 v23, v11
    .line 169: move/from16 v24, v12
    .line 171: iget-wide v11, v0, Lcom/titanchess/accessibility/r1;->c:J
    .line 173: move v0, v9
    .line 174: iget-wide v9, v10, Lcom/titanchess/accessibility/r1;->c:J
    .line 176: move/from16 v25, v13
    .line 178: move-object/from16 v32, v14
    .line 180: add-long v13, v11, v9
    .line 182: move/from16 v27, v0
    .line 184: move/from16 v26, v7
    .line 186: const/4 v7, 1
    .line 187: new-array v0, v7, [Ljava/lang/Object;
    .line 189: invoke-static/range {v15 .. v16}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 192: move-result-object v15
    .line 193: const/16 v16, 0
    .line 195: aput-object v15, v0, v16
    .line 197: invoke-static {v0, v7}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 200: move-result-object v0
    .line 201: invoke-static {v4, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 204: move-result-object v0
    .line 205: invoke-static {v0, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 208: new-array v15, v7, [Ljava/lang/Object;
    .line 210: invoke-static/range {v19 .. v20}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 213: move-result-object v16
    .line 214: const/16 v19, 0
    .line 216: aput-object v16, v15, v19
    .line 218: invoke-static {v15, v7}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 221: move-result-object v15
    .line 222: invoke-static {v4, v15}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 225: move-result-object v15
    .line 226: invoke-static {v15, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 229: move-object/from16 v31, v15
    .line 231: new-array v15, v7, [Ljava/lang/Object;
    .line 233: invoke-static/range {v17 .. v18}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 236: move-result-object v16
    .line 237: const/16 v17, 0
    .line 239: aput-object v16, v15, v17
    .line 241: invoke-static {v15, v7}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 244: move-result-object v7
    .line 245: invoke-static {v4, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 248: move-result-object v4
    .line 249: invoke-static {v4, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 252: new-instance v3, Ljava/lang/StringBuilder;
    .line 254: invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 257: move/from16 v6, v35
    .line 259: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 262: const-string v6, " "
    .line 264: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 267: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 270: invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 273: invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 276: const-string v1, " nodes200000="
    .line 278: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 281: move-object/from16 v1, v32
    .line 283: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 286: const-string v1, "["
    .line 288: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 291: move-object/from16 v1, v29
    .line 293: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 296: const-string v1, "] reachedDepth="
    .line 298: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 301: move/from16 v1, v25
    .line 303: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 306: const-string v1, "/"
    .line 308: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 311: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 314: const-string v1, " probeMs="
    .line 316: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 319: invoke-virtual {v3, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 322: const-string v1, "+"
    .line 324: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 327: invoke-virtual {v3, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 330: const-string v1, "="
    .line 332: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 335: invoke-virtual {v3, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 338: const-string v1, " winBefore="
    .line 340: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 343: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 346: const-string v0, " winAfter="
    .line 348: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 351: move-object/from16 v0, v31
    .line 353: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 356: const-string v0, " moveAcc="
    .line 358: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 361: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 364: const-string v0, " cpBefore="
    .line 366: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 369: move/from16 v0, v27
    .line 371: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 374: const-string v0, " cpAfterMover="
    .line 376: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 379: move/from16 v0, v23
    .line 381: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 384: const-string v0, " exactBest="
    .line 386: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 389: move/from16 v13, v24
    .line 391: invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 394: const-string v0, " wtmPrev="
    .line 396: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 399: move/from16 v0, v26
    .line 401: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 404: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 407: move-result-object v0
    .line 408: move-object/from16 v1, v22
    .line 410: invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 413: goto :goto_424
    .line 414: move-exception v0
    .line 415: goto :goto_419
    .line 416: move-exception v0
    .line 417: move-object/from16 v1, v22
    .line 419: const-string v2, "probe fail"
    .line 421: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 424: return-void
.end method

# direct methods
.method private final recolorWithStockfish(Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;Ljava/util/List;I)V
    .registers 14

    .line 0: new-instance v3, Ljava/util/ArrayList;
    .line 2: invoke-static {v12}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 5: move-result v0
    .line 6: invoke-direct {v3, v0}, Ljava/util/ArrayList;-><init>(I)V
    .line 9: invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 12: move-result-object v12
    .line 13: invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z
    .line 16: move-result v0
    .line 17: if-eqz v0, :cond_48
    .line 19: invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 22: move-result-object v0
    .line 23: check-cast v0, Lcom/titanchess/accessibility/f;
    .line 25: iget-object v1, v0, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 27: new-instance v2, Ljava/lang/StringBuilder;
    .line 29: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    .line 32: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 35: iget-object v0, v0, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 37: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 40: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 43: move-result-object v0
    .line 44: invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 47: goto :goto_13
    .line 48: iget-object v12, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->evalWorker:Ljava/util/concurrent/ExecutorService;
    .line 50: new-instance v7, Lcom/titanchess/accessibility/u1;
    .line 52: move-object v0, v7
    .line 53: move-object v1, v8
    .line 54: move-object v2, v10
    .line 55: move-object v4, v9
    .line 56: move v5, v13
    .line 57: move-object v6, v11
    .line 58: invoke-direct/range {v0 .. v6}, Lcom/titanchess/accessibility/u1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;Ljava/util/ArrayList;Ljava/lang/String;ILp2/n;)V
    .line 61: invoke-interface {v12, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 64: return-void
.end method

# direct methods
.method private static final recolorWithStockfish$lambda$35(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;Ljava/util/List;Ljava/lang/String;ILp2/n;)V
    .registers 23

    .line 0: move-object/from16 v8, v17
    .line 2: move-object/from16 v9, v18
    .line 4: move-object/from16 v0, v19
    .line 6: move-object/from16 v7, v20
    .line 8: move-object/from16 v10, v22
    .line 10: const-string v11, "go nodes 20000 searchmoves "
    .line 12: const-string v1, "this$0"
    .line 14: invoke-static {v8, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 17: const-string v1, "$s"
    .line 19: invoke-static {v9, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: const-string v1, "$moves"
    .line 24: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 27: const-string v1, "$model"
    .line 29: invoke-static {v7, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 32: const-string v1, "$my"
    .line 34: invoke-static {v10, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 40: move-result-wide v12
    .line 41: invoke-direct/range {v17 .. v17}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 44: move-result-object v14
    .line 45: iget-object v1, v9, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 47: const-string v2, "position fen "
    .line 49: monitor-enter v14
    .line 50: const-string v3, "fen"
    .line 52: invoke-static {v1, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 55: invoke-virtual {v14}, Lcom/titanchess/accessibility/s1;->e()Z
    .line 58: move-result v3
    .line 59: const/4 v15, 0
    .line 60: const/4 v6, 3
    .line 61: if-eqz v3, :cond_227
    .line 63: invoke-interface/range {v19 .. v19}, Ljava/util/List;->size()I
    .line 66: move-result v3
    .line 67: if-ne v3, v6, :cond_227
    .line 69: invoke-static/range {v19 .. v19}, Lt2/p;->I1(Ljava/lang/Iterable;)Ljava/util/List;
    .line 72: move-result-object v3
    .line 73: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 76: move-result v3
    .line 77: if-eq v3, v6, :cond_81
    .line 79: goto/16 :goto_227
    .line 81: const-string v3, "setoption name MultiPV value 3"
    .line 83: invoke-virtual {v14, v3}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 86: invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 89: move-result-object v1
    .line 90: invoke-virtual {v14, v1}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 93: invoke-interface/range {v19 .. v19}, Ljava/util/List;->size()I
    .line 96: move-result v1
    .line 97: if-ne v1, v6, :cond_180
    .line 99: invoke-static/range {v19 .. v19}, Lt2/p;->I1(Ljava/lang/Iterable;)Ljava/util/List;
    .line 102: move-result-object v1
    .line 103: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 106: move-result v1
    .line 107: if-ne v1, v6, :cond_180
    .line 109: const-string v2, " "
    .line 111: const/4 v3, 0
    .line 112: const/4 v4, 0
    .line 113: const/4 v5, 0
    .line 114: const/16 v16, 62
    .line 116: move-object/from16 v1, v19
    .line 118: move/from16 v6, v16
    .line 120: invoke-static/range {v1 .. v6}, Lt2/p;->P1(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ld3/c;I)Ljava/lang/String;
    .line 123: move-result-object v1
    .line 124: invoke-virtual {v11, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 127: move-result-object v1
    .line 128: invoke-virtual {v14, v1}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 131: new-instance v1, Ljava/lang/StringBuilder;
    .line 133: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 136: iget-object v2, v14, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 138: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 141: invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    .line 144: move-result-object v3
    .line 145: if-nez v3, :cond_148
    .line 147: goto :goto_164
    .line 148: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 151: const/16 v4, 10
    .line 153: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 156: const-string v4, "bestmove"
    .line 158: invoke-static {v3, v4, v15}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 161: move-result v3
    .line 162: if-eqz v3, :cond_141
    .line 164: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 167: move-result-object v1
    .line 168: const-string v2, "toString(...)"
    .line 170: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 173: invoke-static {v1, v0}, Ld2/b;->O0(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
    .line 176: move-result-object v0
    .line 177: goto :goto_196
    .line 178: move-exception v0
    .line 179: goto :goto_192
    .line 180: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 182: const-string v1, "Failed requirement."
    .line 184: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 187: move-result-object v1
    .line 188: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 191: throw v0
    .line 192: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 195: move-result-object v0
    .line 196: invoke-static {v0}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 199: move-result-object v1
    .line 200: if-nez v1, :cond_203
    .line 202: goto :goto_212
    .line 203: const-string v0, "TitanEval"
    .line 205: const-string v2, "candidate rank fail"
    .line 207: invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 210: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 212: move-object v1, v0
    .line 213: check-cast v1, Ljava/util/List;
    .line 215: const-string v1, "setoption name MultiPV value 1"
    .line 217: invoke-virtual {v14, v1}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 220: check-cast v0, Ljava/util/List;
    .line 222: monitor-exit v14
    .line 223: goto :goto_230
    .line 224: move-exception v0
    .line 225: goto/16 :goto_507
    .line 227: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 229: monitor-exit v14
    .line 230: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 233: move-result-wide v1
    .line 234: sub-long/2addr v1, v12
    .line 235: const v3, 0xf4240
    .line 238: int-to-long v3, v3
    .line 239: div-long v11, v1, v3
    .line 241: iget-object v1, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->snap:Lcom/titanchess/accessibility/a2;
    .line 243: const/4 v2, 1
    .line 244: if-eqz v1, :cond_262
    .line 246: iget-object v3, v1, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 248: iget-object v4, v9, Lcom/titanchess/accessibility/a2;->a:Ljava/lang/String;
    .line 250: invoke-static {v3, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 253: move-result v3
    .line 254: if-eqz v3, :cond_262
    .line 256: iget-object v1, v1, Lcom/titanchess/accessibility/a2;->c:Lp2/n;
    .line 258: if-ne v1, v10, :cond_262
    .line 260: move v10, v2
    .line 261: goto :goto_263
    .line 262: move v10, v15
    .line 263: const-string v1, "titan"
    .line 265: invoke-virtual {v8, v1, v15}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 268: move-result-object v1
    .line 269: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 272: move-result v3
    .line 273: const/4 v4, 3
    .line 274: if-ne v3, v4, :cond_499
    .line 276: if-eqz v10, :cond_499
    .line 278: const-string v3, "arrow_on"
    .line 280: invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 283: move-result v3
    .line 284: if-eqz v3, :cond_499
    .line 286: const-string v3, "model"
    .line 288: const-string v5, "A"
    .line 290: invoke-interface {v1, v3, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 293: move-result-object v3
    .line 294: invoke-static {v3, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 297: move-result v3
    .line 298: if-eqz v3, :cond_499
    .line 300: new-instance v13, Ljava/util/ArrayList;
    .line 302: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 305: move-result v3
    .line 306: invoke-direct {v13, v3}, Ljava/util/ArrayList;-><init>(I)V
    .line 309: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 312: move-result-object v0
    .line 313: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 316: move-result v3
    .line 317: if-eqz v3, :cond_363
    .line 319: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 322: move-result-object v3
    .line 323: check-cast v3, Lcom/titanchess/accessibility/o1;
    .line 325: new-instance v5, Lcom/titanchess/accessibility/f;
    .line 327: iget-object v6, v3, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 329: const/4 v7, 2
    .line 330: invoke-virtual {v6, v15, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 333: move-result-object v6
    .line 334: const-string v14, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 336: invoke-static {v6, v14}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 339: iget-object v14, v3, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 341: const/4 v2, 4
    .line 342: invoke-virtual {v14, v7, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 345: move-result-object v2
    .line 346: const-string v7, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 348: invoke-static {v2, v7}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 351: iget v7, v3, Lcom/titanchess/accessibility/o1;->b:I
    .line 353: iget v3, v3, Lcom/titanchess/accessibility/o1;->c:F
    .line 355: invoke-direct {v5, v6, v2, v7, v3}, Lcom/titanchess/accessibility/f;-><init>(Ljava/lang/String;Ljava/lang/String;IF)V
    .line 358: invoke-virtual {v13, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 361: const/4 v2, 1
    .line 362: goto :goto_313
    .line 363: invoke-static/range {v17 .. v17}, Lcom/titanchess/accessibility/e;->g(Landroid/content/Context;)Z
    .line 366: move-result v0
    .line 367: if-eqz v0, :cond_377
    .line 369: const-string v0, "arrow_count"
    .line 371: invoke-interface {v1, v0, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 374: move-result v0
    .line 375: move v3, v0
    .line 376: goto :goto_378
    .line 377: const/4 v3, 1
    .line 378: iget-object v0, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 380: if-eqz v0, :cond_404
    .line 382: const/4 v4, 0
    .line 383: const/4 v5, 0
    .line 384: const/16 v6, 8
    .line 386: const/4 v7, 0
    .line 387: move-object/from16 v1, v17
    .line 389: move-object v2, v13
    .line 390: invoke-static/range {v1 .. v7}, Lcom/titanchess/accessibility/TitanAccessibilityService;->toOverlayArrows$default(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;IZZILjava/lang/Object;)Ljava/util/List;
    .line 393: move-result-object v1
    .line 394: const-string v2, "list"
    .line 396: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 399: iput-object v1, v0, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 401: invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 404: move/from16 v1, v21
    .line 406: invoke-direct {v8, v9, v13, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->writeStatus(Lcom/titanchess/accessibility/a2;Ljava/util/List;I)V
    .line 409: const-string v0, "TitanA11y"
    .line 411: new-instance v1, Ljava/util/ArrayList;
    .line 413: invoke-static {v13}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 416: move-result v2
    .line 417: invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V
    .line 420: invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 423: move-result-object v2
    .line 424: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 427: move-result v3
    .line 428: if-eqz v3, :cond_474
    .line 430: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 433: move-result-object v3
    .line 434: check-cast v3, Lcom/titanchess/accessibility/f;
    .line 436: iget-object v4, v3, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 438: iget-object v5, v3, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 440: iget v3, v3, Lcom/titanchess/accessibility/f;->d:F
    .line 442: const/16 v6, 100
    .line 444: int-to-float v6, v6
    .line 445: mul-float/2addr v3, v6
    .line 446: float-to-int v3, v3
    .line 447: new-instance v6, Ljava/lang/StringBuilder;
    .line 449: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    .line 452: invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 455: invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 458: const-string v4, "@"
    .line 460: invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 463: invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 466: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 469: move-result-object v3
    .line 470: invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 473: goto :goto_424
    .line 474: new-instance v2, Ljava/lang/StringBuilder;
    .line 476: const-string v3, "sf-color "
    .line 478: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 481: invoke-virtual {v2, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 484: const-string v3, "ms nodes=20000 "
    .line 486: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 489: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 492: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 495: move-result-object v1
    .line 496: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 499: if-eqz v10, :cond_506
    .line 501: iget-object v0, v9, Lcom/titanchess/accessibility/a2;->b:Ljava/util/List;
    .line 503: invoke-direct {v8, v0}, Lcom/titanchess/accessibility/TitanAccessibilityService;->gradeLastMove(Ljava/util/List;)V
    .line 506: return-void
    .line 507: monitor-exit v14
    .line 508: throw v0
.end method

# direct methods
.method private final refreshCoords(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 10

    .line 0: invoke-direct {v8, v9}, Lcom/titanchess/accessibility/TitanAccessibilityService;->findBoard(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 3: move-result-object v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-void
    .line 7: new-instance v1, Landroid/graphics/Rect;
    .line 9: invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V
    .line 12: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V
    .line 15: invoke-virtual {v1}, Landroid/graphics/Rect;->width()I
    .line 18: move-result v2
    .line 19: if-lez v2, :cond_31
    .line 21: invoke-virtual {v1}, Landroid/graphics/Rect;->width()I
    .line 24: move-result v1
    .line 25: int-to-float v1, v1
    .line 26: const/high16 v2, 0x4100
    .line 28: div-float/2addr v1, v2
    .line 29: iput v1, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->boardPx:F
    .line 31: invoke-direct {v8, v9}, Lcom/titanchess/accessibility/TitanAccessibilityService;->findAvatars(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .line 34: new-instance v9, Ljava/util/HashMap;
    .line 36: const/16 v1, 64
    .line 38: invoke-direct {v9, v1}, Ljava/util/HashMap;-><init>(I)V
    .line 41: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I
    .line 44: move-result v2
    .line 45: const/4 v3, 0
    .line 46: if-ge v3, v2, :cond_123
    .line 48: invoke-virtual {v0, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 51: move-result-object v4
    .line 52: if-nez v4, :cond_55
    .line 54: goto :goto_120
    .line 55: sget-object v5, Lcom/titanchess/accessibility/TitanAccessibilityService;->SQUARE:Lm3/f;
    .line 57: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;
    .line 60: move-result-object v6
    .line 61: if-eqz v6, :cond_69
    .line 63: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 66: move-result-object v6
    .line 67: if-nez v6, :cond_71
    .line 69: const-string v6, ""
    .line 71: invoke-static {v5, v6}, Lm3/f;->a(Lm3/f;Ljava/lang/String;)Lm3/e;
    .line 74: move-result-object v5
    .line 75: if-eqz v5, :cond_120
    .line 77: iget-object v5, v5, Lm3/e;->a:Ljava/util/regex/Matcher;
    .line 79: invoke-virtual {v5}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;
    .line 82: move-result-object v5
    .line 83: const-string v6, "matchResult.group()"
    .line 85: invoke-static {v5, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 88: new-instance v6, Landroid/graphics/Rect;
    .line 90: invoke-direct {v6}, Landroid/graphics/Rect;-><init>()V
    .line 93: invoke-virtual {v4, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V
    .line 96: invoke-virtual {v6}, Landroid/graphics/Rect;->exactCenterX()F
    .line 99: move-result v4
    .line 100: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 103: move-result-object v4
    .line 104: invoke-virtual {v6}, Landroid/graphics/Rect;->exactCenterY()F
    .line 107: move-result v6
    .line 108: invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 111: move-result-object v6
    .line 112: new-instance v7, Ls2/e;
    .line 114: invoke-direct {v7, v4, v6}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 117: invoke-virtual {v9, v5, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 120: add-int/lit8 v3, v3, 1
    .line 122: goto :goto_46
    .line 123: invoke-virtual {v9}, Ljava/util/HashMap;->size()I
    .line 126: move-result v0
    .line 127: if-ne v0, v1, :cond_267
    .line 129: iput-object v9, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 131: invoke-virtual {v9}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;
    .line 134: move-result-object v9
    .line 135: check-cast v9, Ljava/lang/Iterable;
    .line 137: invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 140: move-result-object v9
    .line 141: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 144: move-result v0
    .line 145: if-nez v0, :cond_149
    .line 147: const/4 v9, 0
    .line 148: goto :goto_214
    .line 149: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 152: move-result-object v0
    .line 153: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 156: move-result v1
    .line 157: if-nez v1, :cond_161
    .line 159: move-object v9, v0
    .line 160: goto :goto_214
    .line 161: move-object v1, v0
    .line 162: check-cast v1, Ljava/util/Map$Entry;
    .line 164: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 167: move-result-object v1
    .line 168: check-cast v1, Ls2/e;
    .line 170: iget-object v1, v1, Ls2/e;->j:Ljava/lang/Object;
    .line 172: check-cast v1, Ljava/lang/Number;
    .line 174: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 177: move-result v1
    .line 178: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 181: move-result-object v2
    .line 182: move-object v3, v2
    .line 183: check-cast v3, Ljava/util/Map$Entry;
    .line 185: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 188: move-result-object v3
    .line 189: check-cast v3, Ls2/e;
    .line 191: iget-object v3, v3, Ls2/e;->j:Ljava/lang/Object;
    .line 193: check-cast v3, Ljava/lang/Number;
    .line 195: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 198: move-result v3
    .line 199: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 202: move-result v4
    .line 203: if-gez v4, :cond_207
    .line 205: move-object v0, v2
    .line 206: move v1, v3
    .line 207: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 210: move-result v2
    .line 211: if-nez v2, :cond_178
    .line 213: goto :goto_159
    .line 214: check-cast v9, Ljava/util/Map$Entry;
    .line 216: invoke-static {v9}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 219: invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 222: move-result-object v9
    .line 223: check-cast v9, Ljava/lang/String;
    .line 225: const/4 v0, 1
    .line 226: invoke-virtual {v9, v0}, Ljava/lang/String;->charAt(I)C
    .line 229: move-result v9
    .line 230: const/16 v1, 49
    .line 232: if-ne v9, v1, :cond_237
    .line 234: sget-object v9, Lp2/n;->i:Lp2/n;
    .line 236: goto :goto_239
    .line 237: sget-object v9, Lp2/n;->j:Lp2/n;
    .line 239: iput-object v9, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->mySide:Lp2/n;
    .line 241: iget-object v9, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->snap:Lcom/titanchess/accessibility/a2;
    .line 243: if-eqz v9, :cond_267
    .line 245: iget-boolean v9, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->coordsReadyOnce:Z
    .line 247: if-nez v9, :cond_267
    .line 249: iput-boolean v0, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->coordsReadyOnce:Z
    .line 251: iget-object v9, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 253: iget-object v0, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 255: invoke-virtual {v9, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    .line 258: iget-object v9, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 260: iget-object v0, v8, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 262: const-wide/16 v1, 20
    .line 264: invoke-virtual {v9, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    .line 267: return-void
.end method

# direct methods
.method private final renderAccuracy()V
    .registers 31

    .line 0: move-object/from16 v0, v30
    .line 2: invoke-static/range {v30 .. v30}, Lcom/titanchess/accessibility/e;->g(Landroid/content/Context;)Z
    .line 5: move-result v1
    .line 6: if-eqz v1, :cond_1001
    .line 8: const-string v1, "titan"
    .line 10: const/4 v3, 0
    .line 11: invoke-virtual {v0, v1, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 14: move-result-object v1
    .line 15: const-string v4, "acc_on"
    .line 17: const/4 v5, 1
    .line 18: invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 21: move-result v1
    .line 22: if-eqz v1, :cond_1001
    .line 24: iget-object v1, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->accCp:Ljava/util/concurrent/ConcurrentHashMap;
    .line 26: const-string v4, "byPly"
    .line 28: invoke-static {v1, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 31: invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z
    .line 34: move-result v4
    .line 35: const/4 v6, 2
    .line 36: const-wide/high16 v7, 0x4059
    .line 38: if-eqz v4, :cond_43
    .line 40: const/4 v4, 0
    .line 41: goto/16 :goto_598
    .line 43: invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;
    .line 46: move-result-object v4
    .line 47: check-cast v4, Ljava/lang/Iterable;
    .line 49: invoke-static {v4}, Lt2/p;->S1(Ljava/lang/Iterable;)Ljava/lang/Comparable;
    .line 52: move-result-object v4
    .line 53: check-cast v4, Ljava/lang/Number;
    .line 55: invoke-virtual {v4}, Ljava/lang/Number;->intValue()I
    .line 58: move-result v4
    .line 59: new-instance v9, Ljava/util/ArrayList;
    .line 61: invoke-direct {v9, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 64: const/16 v10, 15
    .line 66: if-gt v5, v4, :cond_98
    .line 68: move v11, v5
    .line 69: move v12, v10
    .line 70: invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 73: move-result-object v13
    .line 74: invoke-interface {v1, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 77: move-result-object v13
    .line 78: check-cast v13, Ljava/lang/Integer;
    .line 80: if-eqz v13, :cond_86
    .line 82: invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I
    .line 85: move-result v12
    .line 86: invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 89: move-result-object v13
    .line 90: invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 93: if-eq v11, v4, :cond_98
    .line 95: add-int/lit8 v11, v11, 1
    .line 97: goto :goto_70
    .line 98: invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z
    .line 101: move-result v1
    .line 102: if-eqz v1, :cond_105
    .line 104: goto :goto_40
    .line 105: new-instance v1, Ljava/util/ArrayList;
    .line 107: invoke-virtual {v9}, Ljava/util/ArrayList;->size()I
    .line 110: move-result v4
    .line 111: add-int/2addr v4, v5
    .line 112: invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 115: const/16 v4, -1000
    .line 117: const/16 v11, 1000
    .line 119: invoke-static {v10, v4, v11}, Ld2/b;->G(III)I
    .line 122: move-result v10
    .line 123: int-to-double v12, v10
    .line 124: const-wide v14, 0xbf6e29e1a5ccd8b6
    .line 129: mul-double/2addr v12, v14
    .line 130: invoke-static {v12, v13}, Ljava/lang/Math;->exp(D)D
    .line 133: move-result-wide v12
    .line 134: const-wide/high16 v16, 0x3ff0
    .line 136: add-double v12, v12, v16
    .line 138: const-wide/high16 v18, 0x4000
    .line 140: div-double v12, v18, v12
    .line 142: sub-double v12, v12, v16
    .line 144: const-wide/high16 v20, 0x3fe0
    .line 146: mul-double v12, v12, v20
    .line 148: add-double v12, v12, v20
    .line 150: mul-double/2addr v12, v7
    .line 151: invoke-static {v12, v13}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 154: move-result-object v10
    .line 155: invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 158: invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 161: move-result-object v10
    .line 162: invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z
    .line 165: move-result v12
    .line 166: if-eqz v12, :cond_207
    .line 168: invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 171: move-result-object v12
    .line 172: check-cast v12, Ljava/lang/Number;
    .line 174: invoke-virtual {v12}, Ljava/lang/Number;->intValue()I
    .line 177: move-result v12
    .line 178: invoke-static {v12, v4, v11}, Ld2/b;->G(III)I
    .line 181: move-result v12
    .line 182: int-to-double v12, v12
    .line 183: mul-double/2addr v12, v14
    .line 184: invoke-static {v12, v13}, Ljava/lang/Math;->exp(D)D
    .line 187: move-result-wide v12
    .line 188: add-double v12, v12, v16
    .line 190: div-double v12, v18, v12
    .line 192: sub-double v12, v12, v16
    .line 194: mul-double v12, v12, v20
    .line 196: add-double v12, v12, v20
    .line 198: mul-double/2addr v12, v7
    .line 199: invoke-static {v12, v13}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 202: move-result-object v12
    .line 203: invoke-virtual {v1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 206: goto :goto_162
    .line 207: invoke-virtual {v9}, Ljava/util/ArrayList;->size()I
    .line 210: move-result v4
    .line 211: div-int/lit8 v4, v4, 10
    .line 213: const/16 v9, 8
    .line 215: invoke-static {v4, v6, v9}, Ld2/b;->G(III)I
    .line 218: move-result v4
    .line 219: new-instance v9, Ljava/util/ArrayList;
    .line 221: invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V
    .line 224: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 227: move-result v10
    .line 228: if-le v4, v10, :cond_231
    .line 230: goto :goto_232
    .line 231: move v10, v4
    .line 232: invoke-static {v1, v10}, Lt2/p;->X1(Ljava/lang/Iterable;I)Ljava/util/List;
    .line 235: move-result-object v10
    .line 236: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 239: move-result v11
    .line 240: if-le v4, v11, :cond_243
    .line 242: goto :goto_244
    .line 243: move v11, v4
    .line 244: sub-int/2addr v11, v6
    .line 245: if-gez v11, :cond_248
    .line 247: move v11, v3
    .line 248: move v12, v3
    .line 249: if-ge v12, v11, :cond_257
    .line 251: invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 254: add-int/lit8 v12, v12, 1
    .line 256: goto :goto_249
    .line 257: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 260: move-result v10
    .line 261: sub-int/2addr v10, v4
    .line 262: if-gez v10, :cond_265
    .line 264: move v10, v3
    .line 265: if-ltz v10, :cond_288
    .line 267: move v11, v3
    .line 268: add-int v12, v11, v4
    .line 270: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 273: move-result v13
    .line 274: if-gt v12, v13, :cond_283
    .line 276: invoke-virtual {v1, v11, v12}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;
    .line 279: move-result-object v12
    .line 280: invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 283: if-eq v11, v10, :cond_288
    .line 285: add-int/lit8 v11, v11, 1
    .line 287: goto :goto_268
    .line 288: new-instance v4, Ljava/util/ArrayList;
    .line 290: invoke-static {v9}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 293: move-result v10
    .line 294: invoke-direct {v4, v10}, Ljava/util/ArrayList;-><init>(I)V
    .line 297: invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 300: move-result-object v9
    .line 301: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 304: move-result v10
    .line 305: if-eqz v10, :cond_382
    .line 307: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 310: move-result-object v10
    .line 311: check-cast v10, Ljava/util/List;
    .line 313: invoke-interface {v10}, Ljava/util/List;->size()I
    .line 316: move-result v11
    .line 317: const-wide/16 v12, 0
    .line 319: if-ge v11, v6, :cond_324
    .line 321: move-wide/from16 v18, v12
    .line 323: goto :goto_366
    .line 324: invoke-static {v10}, Lt2/p;->H1(Ljava/util/List;)D
    .line 327: move-result-wide v14
    .line 328: invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 331: move-result-object v11
    .line 332: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 335: move-result v18
    .line 336: if-eqz v18, :cond_355
    .line 338: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 341: move-result-object v18
    .line 342: check-cast v18, Ljava/lang/Number;
    .line 344: invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->doubleValue()D
    .line 347: move-result-wide v18
    .line 348: sub-double v18, v18, v14
    .line 350: mul-double v18, v18, v18
    .line 352: add-double v12, v18, v12
    .line 354: goto :goto_332
    .line 355: invoke-interface {v10}, Ljava/util/List;->size()I
    .line 358: move-result v10
    .line 359: int-to-double v10, v10
    .line 360: div-double/2addr v12, v10
    .line 361: invoke-static {v12, v13}, Ljava/lang/Math;->sqrt(D)D
    .line 364: move-result-wide v12
    .line 365: goto :goto_321
    .line 366: const-wide/high16 v20, 0x3fe0
    .line 368: const-wide/high16 v22, 0x4028
    .line 370: invoke-static/range {v18 .. v23}, Ld2/b;->E(DDD)D
    .line 373: move-result-wide v10
    .line 374: invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 377: move-result-object v10
    .line 378: invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 381: goto :goto_301
    .line 382: new-instance v9, Ljava/util/ArrayList;
    .line 384: invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V
    .line 387: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 390: move-result v10
    .line 391: sub-int/2addr v10, v5
    .line 392: move v11, v3
    .line 393: if-ge v11, v10, :cond_565
    .line 395: invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 398: move-result-object v12
    .line 399: const-string v13, "get(...)"
    .line 401: invoke-static {v12, v13}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 404: check-cast v12, Ljava/lang/Number;
    .line 406: invoke-virtual {v12}, Ljava/lang/Number;->doubleValue()D
    .line 409: move-result-wide v14
    .line 410: add-int/lit8 v12, v11, 1
    .line 412: invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 415: move-result-object v2
    .line 416: invoke-static {v2, v13}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 419: check-cast v2, Ljava/lang/Number;
    .line 421: invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D
    .line 424: move-result-wide v19
    .line 425: rem-int/lit8 v2, v11, 2
    .line 427: if-nez v2, :cond_432
    .line 429: move/from16 v26, v5
    .line 431: goto :goto_434
    .line 432: move/from16 v26, v3
    .line 434: const-wide v21, 0x400955dca3601f8e
    .line 439: const-wide v23, 0x4059caad42612fd
    .line 444: const-wide v27, 0xbfa64b6b5996dcf
    .line 449: if-eqz v26, :cond_482
    .line 451: cmpl-double v2, v19, v14
    .line 453: if-ltz v2, :cond_457
    .line 455: move-wide v13, v7
    .line 456: goto :goto_479
    .line 457: sub-double v14, v14, v19
    .line 459: mul-double v14, v14, v27
    .line 461: invoke-static {v14, v15}, Ljava/lang/Math;->exp(D)D
    .line 464: move-result-wide v13
    .line 465: mul-double v13, v13, v23
    .line 467: sub-double v13, v13, v21
    .line 469: add-double v19, v13, v16
    .line 471: const-wide/16 v21, 0
    .line 473: const-wide/high16 v23, 0x4059
    .line 475: invoke-static/range {v19 .. v24}, Ld2/b;->E(DDD)D
    .line 478: move-result-wide v13
    .line 479: move-wide/from16 v22, v13
    .line 481: goto :goto_514
    .line 482: sub-double v13, v7, v14
    .line 484: sub-double v19, v7, v19
    .line 486: cmpl-double v2, v19, v13
    .line 488: if-ltz v2, :cond_491
    .line 490: goto :goto_455
    .line 491: sub-double v13, v13, v19
    .line 493: mul-double v13, v13, v27
    .line 495: invoke-static {v13, v14}, Ljava/lang/Math;->exp(D)D
    .line 498: move-result-wide v13
    .line 499: mul-double v13, v13, v23
    .line 501: sub-double v13, v13, v21
    .line 503: add-double v19, v13, v16
    .line 505: const-wide/16 v21, 0
    .line 507: const-wide/high16 v23, 0x4059
    .line 509: invoke-static/range {v19 .. v24}, Ld2/b;->E(DDD)D
    .line 512: move-result-wide v13
    .line 513: goto :goto_479
    .line 514: if-ltz v11, :cond_527
    .line 516: invoke-static {v4}, Ld2/b;->r0(Ljava/util/List;)I
    .line 519: move-result v2
    .line 520: if-gt v11, v2, :cond_527
    .line 522: invoke-virtual {v4, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 525: move-result-object v2
    .line 526: goto :goto_546
    .line 527: invoke-static {v4}, Lt2/p;->R1(Ljava/util/List;)Ljava/lang/Object;
    .line 530: move-result-object v2
    .line 531: check-cast v2, Ljava/lang/Double;
    .line 533: if-eqz v2, :cond_540
    .line 535: invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D
    .line 538: move-result-wide v13
    .line 539: goto :goto_542
    .line 540: move-wide/from16 v13, v16
    .line 542: invoke-static {v13, v14}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 545: move-result-object v2
    .line 546: check-cast v2, Ljava/lang/Number;
    .line 548: invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D
    .line 551: move-result-wide v24
    .line 552: new-instance v2, Lcom/titanchess/accessibility/v;
    .line 554: move-object/from16 v21, v2
    .line 556: invoke-direct/range {v21 .. v26}, Lcom/titanchess/accessibility/v;-><init>(DDZ)V
    .line 559: invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 562: move v11, v12
    .line 563: goto/16 :goto_393
    .line 565: invoke-static {v9, v5}, Ld2/c;->z(Ljava/util/ArrayList;Z)Ljava/lang/Double;
    .line 568: move-result-object v1
    .line 569: if-eqz v1, :cond_40
    .line 571: invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D
    .line 574: move-result-wide v1
    .line 575: invoke-static {v9, v3}, Ld2/c;->z(Ljava/util/ArrayList;Z)Ljava/lang/Double;
    .line 578: move-result-object v4
    .line 579: if-eqz v4, :cond_40
    .line 581: invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D
    .line 584: move-result-wide v9
    .line 585: invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 588: move-result-object v1
    .line 589: invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 592: move-result-object v2
    .line 593: new-instance v4, Ls2/e;
    .line 595: invoke-direct {v4, v1, v2}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 598: if-nez v4, :cond_613
    .line 600: invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 603: move-result-object v1
    .line 604: invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 607: move-result-object v2
    .line 608: new-instance v4, Ls2/e;
    .line 610: invoke-direct {v4, v1, v2}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 613: iget-object v1, v4, Ls2/e;->i:Ljava/lang/Object;
    .line 615: check-cast v1, Ljava/lang/Number;
    .line 617: invoke-virtual {v1}, Ljava/lang/Number;->doubleValue()D
    .line 620: move-result-wide v1
    .line 621: iget-object v4, v4, Ls2/e;->j:Ljava/lang/Object;
    .line 623: check-cast v4, Ljava/lang/Number;
    .line 625: invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D
    .line 628: move-result-wide v7
    .line 629: iget-object v4, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 631: invoke-direct/range {v30 .. v30}, Lcom/titanchess/accessibility/TitanAccessibilityService;->squarePx()F
    .line 634: move-result v24
    .line 635: const/high16 v9, 0x3f00
    .line 637: mul-float v9, v9, v24
    .line 639: iget-object v10, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->mySide:Lp2/n;
    .line 641: sget-object v11, Lp2/n;->i:Lp2/n;
    .line 643: if-ne v10, v11, :cond_648
    .line 645: move/from16 v29, v5
    .line 647: goto :goto_650
    .line 648: move/from16 v29, v3
    .line 650: invoke-interface {v4}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 653: move-result-object v3
    .line 654: check-cast v3, Ljava/lang/Iterable;
    .line 656: invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 659: move-result-object v3
    .line 660: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 663: move-result v5
    .line 664: if-nez v5, :cond_668
    .line 666: const/4 v3, 0
    .line 667: goto :goto_711
    .line 668: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 671: move-result-object v5
    .line 672: check-cast v5, Ls2/e;
    .line 674: iget-object v5, v5, Ls2/e;->j:Ljava/lang/Object;
    .line 676: check-cast v5, Ljava/lang/Number;
    .line 678: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 681: move-result v5
    .line 682: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 685: move-result v10
    .line 686: if-eqz v10, :cond_707
    .line 688: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 691: move-result-object v10
    .line 692: check-cast v10, Ls2/e;
    .line 694: iget-object v10, v10, Ls2/e;->j:Ljava/lang/Object;
    .line 696: check-cast v10, Ljava/lang/Number;
    .line 698: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 701: move-result v10
    .line 702: invoke-static {v5, v10}, Ljava/lang/Math;->min(FF)F
    .line 705: move-result v5
    .line 706: goto :goto_682
    .line 707: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 710: move-result-object v3
    .line 711: if-eqz v3, :cond_1000
    .line 713: invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F
    .line 716: move-result v3
    .line 717: int-to-float v5, v6
    .line 718: div-float v5, v24, v5
    .line 720: sub-float/2addr v3, v5
    .line 721: invoke-interface {v4}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 724: move-result-object v6
    .line 725: check-cast v6, Ljava/lang/Iterable;
    .line 727: invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 730: move-result-object v6
    .line 731: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 734: move-result v10
    .line 735: if-nez v10, :cond_739
    .line 737: const/4 v6, 0
    .line 738: goto :goto_782
    .line 739: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 742: move-result-object v10
    .line 743: check-cast v10, Ls2/e;
    .line 745: iget-object v10, v10, Ls2/e;->j:Ljava/lang/Object;
    .line 747: check-cast v10, Ljava/lang/Number;
    .line 749: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 752: move-result v10
    .line 753: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    .line 756: move-result v11
    .line 757: if-eqz v11, :cond_778
    .line 759: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 762: move-result-object v11
    .line 763: check-cast v11, Ls2/e;
    .line 765: iget-object v11, v11, Ls2/e;->j:Ljava/lang/Object;
    .line 767: check-cast v11, Ljava/lang/Number;
    .line 769: invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F
    .line 772: move-result v11
    .line 773: invoke-static {v10, v11}, Ljava/lang/Math;->max(FF)F
    .line 776: move-result v10
    .line 777: goto :goto_753
    .line 778: invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 781: move-result-object v6
    .line 782: if-eqz v6, :cond_1000
    .line 784: invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F
    .line 787: move-result v6
    .line 788: add-float/2addr v6, v5
    .line 789: invoke-interface {v4}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 792: move-result-object v4
    .line 793: check-cast v4, Ljava/lang/Iterable;
    .line 795: invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 798: move-result-object v4
    .line 799: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 802: move-result v10
    .line 803: if-nez v10, :cond_808
    .line 805: const/16 v18, 0
    .line 807: goto :goto_853
    .line 808: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 811: move-result-object v10
    .line 812: check-cast v10, Ls2/e;
    .line 814: iget-object v10, v10, Ls2/e;->i:Ljava/lang/Object;
    .line 816: check-cast v10, Ljava/lang/Number;
    .line 818: invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F
    .line 821: move-result v10
    .line 822: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 825: move-result v11
    .line 826: if-eqz v11, :cond_847
    .line 828: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 831: move-result-object v11
    .line 832: check-cast v11, Ls2/e;
    .line 834: iget-object v11, v11, Ls2/e;->i:Ljava/lang/Object;
    .line 836: check-cast v11, Ljava/lang/Number;
    .line 838: invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F
    .line 841: move-result v11
    .line 842: invoke-static {v10, v11}, Ljava/lang/Math;->min(FF)F
    .line 845: move-result v10
    .line 846: goto :goto_822
    .line 847: invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 850: move-result-object v4
    .line 851: move-object/from16 v18, v4
    .line 853: if-eqz v18, :cond_1000
    .line 855: invoke-virtual/range {v18 .. v18}, Ljava/lang/Float;->floatValue()F
    .line 858: move-result v4
    .line 859: sub-float/2addr v4, v5
    .line 860: iget-object v5, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->avatarBottom:Ls2/e;
    .line 862: if-eqz v5, :cond_885
    .line 864: iget-object v6, v5, Ls2/e;->i:Ljava/lang/Object;
    .line 866: iget-object v5, v5, Ls2/e;->j:Ljava/lang/Object;
    .line 868: check-cast v5, Ljava/lang/Number;
    .line 870: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 873: move-result v5
    .line 874: sub-float/2addr v5, v9
    .line 875: invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 878: move-result-object v5
    .line 879: new-instance v10, Ls2/e;
    .line 881: invoke-direct {v10, v6, v5}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 884: goto :goto_899
    .line 885: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 888: move-result-object v5
    .line 889: add-float/2addr v6, v9
    .line 890: invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 893: move-result-object v6
    .line 894: new-instance v10, Ls2/e;
    .line 896: invoke-direct {v10, v5, v6}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 899: iget-object v5, v10, Ls2/e;->i:Ljava/lang/Object;
    .line 901: check-cast v5, Ljava/lang/Number;
    .line 903: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 906: move-result v20
    .line 907: iget-object v5, v10, Ls2/e;->j:Ljava/lang/Object;
    .line 909: check-cast v5, Ljava/lang/Number;
    .line 911: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 914: move-result v21
    .line 915: iget-object v5, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->avatarTop:Ls2/e;
    .line 917: if-eqz v5, :cond_940
    .line 919: iget-object v3, v5, Ls2/e;->i:Ljava/lang/Object;
    .line 921: iget-object v4, v5, Ls2/e;->j:Ljava/lang/Object;
    .line 923: check-cast v4, Ljava/lang/Number;
    .line 925: invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F
    .line 928: move-result v4
    .line 929: sub-float/2addr v4, v9
    .line 930: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 933: move-result-object v4
    .line 934: new-instance v5, Ls2/e;
    .line 936: invoke-direct {v5, v3, v4}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 939: goto :goto_954
    .line 940: invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 943: move-result-object v4
    .line 944: sub-float/2addr v3, v9
    .line 945: invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 948: move-result-object v3
    .line 949: new-instance v5, Ls2/e;
    .line 951: invoke-direct {v5, v4, v3}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 954: iget-object v3, v5, Ls2/e;->i:Ljava/lang/Object;
    .line 956: check-cast v3, Ljava/lang/Number;
    .line 958: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 961: move-result v22
    .line 962: iget-object v3, v5, Ls2/e;->j:Ljava/lang/Object;
    .line 964: check-cast v3, Ljava/lang/Number;
    .line 966: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 969: move-result v23
    .line 970: if-eqz v29, :cond_975
    .line 972: move-wide/from16 v25, v1
    .line 974: goto :goto_977
    .line 975: move-wide/from16 v25, v7
    .line 977: if-eqz v29, :cond_982
    .line 979: move-wide/from16 v27, v7
    .line 981: goto :goto_984
    .line 982: move-wide/from16 v27, v1
    .line 984: iget-object v1, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 986: if-eqz v1, :cond_1000
    .line 988: new-instance v2, Lcom/titanchess/accessibility/a;
    .line 990: move-object/from16 v19, v2
    .line 992: invoke-direct/range {v19 .. v29}, Lcom/titanchess/accessibility/a;-><init>(FFFFFDDZ)V
    .line 995: iput-object v2, v1, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 997: invoke-virtual {v1}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 1000: return-void
    .line 1001: iget-object v1, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 1003: if-eqz v1, :cond_1016
    .line 1005: iget-object v2, v1, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 1007: if-nez v2, :cond_1010
    .line 1009: goto :goto_1016
    .line 1010: const/4 v2, 0
    .line 1011: iput-object v2, v1, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 1013: invoke-virtual {v1}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 1016: return-void
.end method

# direct methods
.method private final squarePx()F
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 2: const-string v1, "a1"
    .line 4: invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 7: move-result-object v1
    .line 8: check-cast v1, Ls2/e;
    .line 10: const-string v2, "a2"
    .line 12: invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 15: move-result-object v2
    .line 16: check-cast v2, Ls2/e;
    .line 18: if-eqz v1, :cond_44
    .line 20: if-eqz v2, :cond_44
    .line 22: iget-object v0, v1, Ls2/e;->j:Ljava/lang/Object;
    .line 24: check-cast v0, Ljava/lang/Number;
    .line 26: invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F
    .line 29: move-result v0
    .line 30: iget-object v1, v2, Ls2/e;->j:Ljava/lang/Object;
    .line 32: check-cast v1, Ljava/lang/Number;
    .line 34: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 37: move-result v1
    .line 38: sub-float/2addr v0, v1
    .line 39: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    .line 42: move-result v0
    .line 43: return v0
    .line 44: const-string v1, "e4"
    .line 46: invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 49: move-result-object v1
    .line 50: check-cast v1, Ls2/e;
    .line 52: const-string v2, "e5"
    .line 54: invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 57: move-result-object v0
    .line 58: check-cast v0, Ls2/e;
    .line 60: if-eqz v1, :cond_86
    .line 62: if-eqz v0, :cond_86
    .line 64: iget-object v1, v1, Ls2/e;->j:Ljava/lang/Object;
    .line 66: check-cast v1, Ljava/lang/Number;
    .line 68: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 71: move-result v1
    .line 72: iget-object v0, v0, Ls2/e;->j:Ljava/lang/Object;
    .line 74: check-cast v0, Ljava/lang/Number;
    .line 76: invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F
    .line 79: move-result v0
    .line 80: sub-float/2addr v1, v0
    .line 81: invoke-static {v1}, Ljava/lang/Math;->abs(F)F
    .line 84: move-result v0
    .line 85: return v0
    .line 86: iget v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->boardPx:F
    .line 88: const/4 v1, 0
    .line 89: cmpl-float v0, v0, v1
    .line 91: if-lez v0, :cond_96
    .line 93: iget v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->boardPx:F
    .line 95: return v0
    .line 96: const/high16 v0, 0x42b4
    .line 98: return v0
.end method

# direct methods
.method private final toOverlayArrows(Ljava/util/List;IZZ)Ljava/util/List;
    .registers 20

    .line 0: move-object v0, v15
    .line 1: iget-object v1, v0, Lcom/titanchess/accessibility/TitanAccessibilityService;->centers:Ljava/util/Map;
    .line 3: invoke-direct {v15}, Lcom/titanchess/accessibility/TitanAccessibilityService;->squarePx()F
    .line 6: move-result v11
    .line 7: invoke-static/range {v16 .. v17}, Lt2/p;->X1(Ljava/lang/Iterable;I)Ljava/util/List;
    .line 10: move-result-object v2
    .line 11: new-instance v12, Ljava/util/ArrayList;
    .line 13: invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V
    .line 16: invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 19: move-result-object v13
    .line 20: invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z
    .line 23: move-result v2
    .line 24: if-eqz v2, :cond_124
    .line 26: invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 29: move-result-object v2
    .line 30: check-cast v2, Lcom/titanchess/accessibility/f;
    .line 32: iget-object v3, v2, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 34: invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 37: move-result-object v3
    .line 38: check-cast v3, Ls2/e;
    .line 40: iget-object v4, v2, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 42: invoke-interface {v1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 45: move-result-object v4
    .line 46: check-cast v4, Ls2/e;
    .line 48: if-eqz v3, :cond_117
    .line 50: if-nez v4, :cond_53
    .line 52: goto :goto_117
    .line 53: new-instance v14, Lcom/titanchess/accessibility/b;
    .line 55: iget-object v5, v3, Ls2/e;->i:Ljava/lang/Object;
    .line 57: check-cast v5, Ljava/lang/Number;
    .line 59: invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F
    .line 62: move-result v5
    .line 63: iget-object v3, v3, Ls2/e;->j:Ljava/lang/Object;
    .line 65: check-cast v3, Ljava/lang/Number;
    .line 67: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 70: move-result v6
    .line 71: iget-object v3, v4, Ls2/e;->i:Ljava/lang/Object;
    .line 73: check-cast v3, Ljava/lang/Number;
    .line 75: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 78: move-result v7
    .line 79: iget-object v3, v4, Ls2/e;->j:Ljava/lang/Object;
    .line 81: check-cast v3, Ljava/lang/Number;
    .line 83: invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F
    .line 86: move-result v8
    .line 87: if-eqz v19, :cond_92
    .line 89: const/4 v3, 0
    .line 90: move v9, v3
    .line 91: goto :goto_95
    .line 92: iget v3, v2, Lcom/titanchess/accessibility/f;->c:I
    .line 94: goto :goto_90
    .line 95: if-eqz v19, :cond_100
    .line 97: const/4 v2, 0
    .line 98: move v10, v2
    .line 99: goto :goto_103
    .line 100: iget v2, v2, Lcom/titanchess/accessibility/f;->d:F
    .line 102: goto :goto_98
    .line 103: move-object v2, v14
    .line 104: move v3, v5
    .line 105: move v4, v6
    .line 106: move v5, v7
    .line 107: move v6, v8
    .line 108: move v7, v9
    .line 109: move v8, v10
    .line 110: move v9, v11
    .line 111: move/from16 v10, v18
    .line 113: invoke-direct/range {v2 .. v10}, Lcom/titanchess/accessibility/b;-><init>(FFFFIFFZ)V
    .line 116: goto :goto_118
    .line 117: const/4 v14, 0
    .line 118: if-eqz v14, :cond_20
    .line 120: invoke-interface {v12, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 123: goto :goto_20
    .line 124: return-object v12
.end method

# direct methods
.method public static synthetic toOverlayArrows$default(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;IZZILjava/lang/Object;)Ljava/util/List;
    .registers 7

    .line 0: and-int/lit8 v5, v5, 8
    .line 2: if-eqz v5, :cond_5
    .line 4: const/4 v4, 0
    .line 5: invoke-direct {v0, v1, v2, v3, v4}, Lcom/titanchess/accessibility/TitanAccessibilityService;->toOverlayArrows(Ljava/util/List;IZZ)Ljava/util/List;
    .line 8: move-result-object v0
    .line 9: return-object v0
.end method

# direct methods
.method private final writeStatus(Lcom/titanchess/accessibility/a2;Ljava/util/List;I)V
    .registers 9

    .line 0: iget v0, v6, Lcom/titanchess/accessibility/a2;->d:I
    .line 2: const-string v1, " "
    .line 4: const-string v2, "-"
    .line 6: if-gez v0, :cond_10
    .line 8: move-object v6, v2
    .line 9: goto :goto_64
    .line 10: iget v6, v6, Lcom/titanchess/accessibility/a2;->e:I
    .line 12: mul-int/lit8 v3, v6, 40
    .line 14: add-int/2addr v3, v0
    .line 15: const/16 v4, 179
    .line 17: if-ge v3, v4, :cond_22
    .line 19: const-string v3, "Bullet"
    .line 21: goto :goto_38
    .line 22: const/16 v4, 479
    .line 24: if-ge v3, v4, :cond_29
    .line 26: const-string v3, "Blitz"
    .line 28: goto :goto_38
    .line 29: const/16 v4, 1499
    .line 31: if-ge v3, v4, :cond_36
    .line 33: const-string v3, "Rapid"
    .line 35: goto :goto_38
    .line 36: const-string v3, "Classical"
    .line 38: new-instance v4, Ljava/lang/StringBuilder;
    .line 40: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    .line 43: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 46: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 49: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 52: const-string v0, "+"
    .line 54: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 60: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 63: move-result-object v6
    .line 64: invoke-static {v7}, Lt2/p;->L1(Ljava/util/List;)Ljava/lang/Object;
    .line 67: move-result-object v7
    .line 68: check-cast v7, Lcom/titanchess/accessibility/f;
    .line 70: if-eqz v7, :cond_109
    .line 72: const/16 v0, 100
    .line 74: int-to-float v0, v0
    .line 75: iget v2, v7, Lcom/titanchess/accessibility/f;->d:F
    .line 77: mul-float/2addr v2, v0
    .line 78: float-to-int v0, v2
    .line 79: new-instance v2, Ljava/lang/StringBuilder;
    .line 81: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    .line 84: iget-object v3, v7, Lcom/titanchess/accessibility/f;->a:Ljava/lang/String;
    .line 86: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 89: iget-object v7, v7, Lcom/titanchess/accessibility/f;->b:Ljava/lang/String;
    .line 91: invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 94: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 97: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 100: const-string v7, "%"
    .line 102: invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 105: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 108: move-result-object v2
    .line 109: const-string v7, "titan"
    .line 111: const/4 v0, 0
    .line 112: invoke-virtual {v5, v7, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 115: move-result-object v7
    .line 116: invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 119: move-result-object v7
    .line 120: const-string v0, "st_tc"
    .line 122: invoke-interface {v7, v0, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 125: move-result-object v6
    .line 126: const-string v7, "st_arrow"
    .line 128: invoke-interface {v6, v7, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 131: move-result-object v6
    .line 132: const-string v7, "st_ms"
    .line 134: invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    .line 137: move-result-object v6
    .line 138: const-string v7, "st_stamp"
    .line 140: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    .line 143: move-result-wide v0
    .line 144: invoke-interface {v6, v7, v0, v1}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    .line 147: move-result-object v6
    .line 148: invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 151: return-void
.end method

# virtual methods
.method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 8

    .line 0: const-string v0, "event"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I
    .line 8: move-result v0
    .line 9: const-string v1, "com.chess"
    .line 11: const/4 v2, 0
    .line 12: const/16 v3, 32
    .line 14: if-ne v0, v3, :cond_122
    .line 16: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;
    .line 19: move-result-object v0
    .line 20: if-eqz v0, :cond_122
    .line 22: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;
    .line 25: move-result-object v0
    .line 26: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 29: move-result v0
    .line 30: if-nez v0, :cond_122
    .line 32: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;
    .line 35: move-result-object v0
    .line 36: invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 39: move-result-object v4
    .line 40: invoke-static {v0, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 43: move-result v0
    .line 44: if-nez v0, :cond_122
    .line 46: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;
    .line 49: move-result-object v0
    .line 50: const-string v4, "com.android.systemui"
    .line 52: invoke-static {v0, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 55: move-result v0
    .line 56: if-nez v0, :cond_122
    .line 58: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;
    .line 61: move-result-object v0
    .line 62: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 65: move-result-object v0
    .line 66: const-string v4, "inputmethod"
    .line 68: invoke-static {v0, v4, v2}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 71: move-result v0
    .line 72: if-nez v0, :cond_122
    .line 74: iget-object v7, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 76: if-eqz v7, :cond_81
    .line 78: invoke-virtual {v7}, Lcom/titanchess/accessibility/d;->a()V
    .line 81: iget-object v7, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 83: const/4 v0, 0
    .line 84: if-eqz v7, :cond_96
    .line 86: iget-object v1, v7, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 88: if-nez v1, :cond_91
    .line 90: goto :goto_96
    .line 91: iput-object v0, v7, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 93: invoke-virtual {v7}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 96: iget-object v7, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 98: if-eqz v7, :cond_110
    .line 100: iget-object v1, v7, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 102: if-nez v1, :cond_105
    .line 104: goto :goto_110
    .line 105: iput-object v0, v7, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 107: invoke-virtual {v7}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 110: iget-object v7, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 112: new-instance v0, Lcom/titanchess/accessibility/v1;
    .line 114: const/4 v1, 6
    .line 115: invoke-direct {v0, v6, v1}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 118: invoke-virtual {v7, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 121: return-void
    .line 122: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;
    .line 125: move-result-object v0
    .line 126: invoke-static {v0, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 129: move-result v0
    .line 130: if-nez v0, :cond_133
    .line 132: return-void
    .line 133: const-string v0, "titan"
    .line 135: invoke-virtual {v6, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 138: move-result-object v0
    .line 139: const-string v1, "float_hidden"
    .line 141: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 144: move-result v0
    .line 145: iget-object v1, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 147: new-instance v4, Lcom/titanchess/accessibility/x1;
    .line 149: invoke-direct {v4, v0, v6, v2}, Lcom/titanchess/accessibility/x1;-><init>(ZLcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 152: invoke-virtual {v1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 155: invoke-direct {v6}, Lcom/titanchess/accessibility/TitanAccessibilityService;->maybeRecheckLicense()V
    .line 158: invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I
    .line 161: move-result v7
    .line 162: if-eq v7, v3, :cond_173
    .line 164: const/16 v0, 2048
    .line 166: if-eq v7, v0, :cond_173
    .line 168: const/16 v0, 4096
    .line 170: if-eq v7, v0, :cond_173
    .line 172: goto :goto_208
    .line 173: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    .line 176: move-result-wide v0
    .line 177: iget-wide v2, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastCoordMs:J
    .line 179: sub-long v2, v0, v2
    .line 181: const-wide/16 v4, 400
    .line 183: cmp-long v7, v2, v4
    .line 185: if-gez v7, :cond_188
    .line 187: return-void
    .line 188: iput-wide v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->lastCoordMs:J
    .line 190: invoke-virtual {v6}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 193: move-result-object v7
    .line 194: if-nez v7, :cond_197
    .line 196: return-void
    .line 197: iget-object v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->coordWorker:Ljava/util/concurrent/ExecutorService;
    .line 199: new-instance v1, Lk2/f;
    .line 201: const/4 v2, 1
    .line 202: invoke-direct {v1, v6, v2, v7}, Lk2/f;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .line 205: invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 208: return-void
.end method

# virtual methods
.method public onDestroy()V
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->fenReceiver:Lcom/titanchess/accessibility/c2;
    .line 2: invoke-virtual {v3, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    .line 5: goto :goto_10
    .line 6: move-exception v0
    .line 7: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 10: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->floatSyncReceiver:Lcom/titanchess/accessibility/d2;
    .line 12: invoke-virtual {v3, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    .line 15: goto :goto_20
    .line 16: move-exception v0
    .line 17: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 20: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 22: iget-object v1, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->debounced:Ljava/lang/Runnable;
    .line 24: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    .line 27: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->computeThread:Landroid/os/HandlerThread;
    .line 29: invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z
    .line 32: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 34: if-eqz v0, :cond_52
    .line 36: const-string v1, "window"
    .line 38: invoke-virtual {v3, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    .line 41: move-result-object v1
    .line 42: const-string v2, "null cannot be cast to non-null type android.view.WindowManager"
    .line 44: invoke-static {v1, v2}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 47: check-cast v1, Landroid/view/WindowManager;
    .line 49: invoke-interface {v1, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    .line 52: const/4 v0, 0
    .line 53: iput-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->overlay:Lcom/titanchess/accessibility/d;
    .line 55: iget-object v1, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 57: if-eqz v1, :cond_62
    .line 59: invoke-virtual {v1}, Lcom/titanchess/accessibility/s;->d()V
    .line 62: iput-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->floating:Lcom/titanchess/accessibility/s;
    .line 64: iget-object v1, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->worker:Ljava/util/concurrent/ExecutorService;
    .line 66: invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;
    .line 69: iget-object v1, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->coordWorker:Ljava/util/concurrent/ExecutorService;
    .line 71: invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;
    .line 74: invoke-direct {v3}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getSf()Lcom/titanchess/accessibility/s1;
    .line 77: move-result-object v1
    .line 78: monitor-enter v1
    .line 79: const-string v2, "quit"
    .line 81: invoke-virtual {v1, v2}, Lcom/titanchess/accessibility/s1;->d(Ljava/lang/String;)V
    .line 84: goto :goto_89
    .line 85: move-exception v2
    .line 86: invoke-static {v2}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 89: iget-object v2, v1, Lcom/titanchess/accessibility/s1;->b:Ljava/lang/Process;
    .line 91: if-eqz v2, :cond_101
    .line 93: invoke-virtual {v2}, Ljava/lang/Process;->destroy()V
    .line 96: goto :goto_101
    .line 97: move-exception v2
    .line 98: invoke-static {v2}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 101: iput-object v0, v1, Lcom/titanchess/accessibility/s1;->b:Ljava/lang/Process;
    .line 103: iput-object v0, v1, Lcom/titanchess/accessibility/s1;->c:Ljava/io/OutputStreamWriter;
    .line 105: iput-object v0, v1, Lcom/titanchess/accessibility/s1;->d:Ljava/io/BufferedReader;
    .line 107: monitor-exit v1
    .line 108: goto :goto_116
    .line 109: move-exception v2
    .line 110: monitor-exit v1
    .line 111: throw v2
    .line 112: move-exception v1
    .line 113: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 116: invoke-direct {v3}, Lcom/titanchess/accessibility/TitanAccessibilityService;->getMimic()Lcom/titanchess/accessibility/k1;
    .line 119: move-result-object v1
    .line 120: monitor-enter v1
    .line 121: iget-object v2, v1, Lcom/titanchess/accessibility/k1;->g:Lcom/titanchess/accessibility/j1;
    .line 123: if-eqz v2, :cond_138
    .line 125: iget-object v2, v2, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 127: invoke-virtual {v2}, Lai/onnxruntime/OrtSession;->close()V
    .line 130: goto :goto_138
    .line 131: move-exception v2
    .line 132: invoke-static {v2}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 135: goto :goto_138
    .line 136: move-exception v0
    .line 137: goto :goto_144
    .line 138: iput-object v0, v1, Lcom/titanchess/accessibility/k1;->g:Lcom/titanchess/accessibility/j1;
    .line 140: iput-object v0, v1, Lcom/titanchess/accessibility/k1;->f:Ljava/lang/String;
    .line 142: monitor-exit v1
    .line 143: goto :goto_150
    .line 144: monitor-exit v1
    .line 145: throw v0
    .line 146: move-exception v0
    .line 147: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 150: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->evalWorker:Ljava/util/concurrent/ExecutorService;
    .line 152: invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;
    .line 155: iget-object v0, v3, Lcom/titanchess/accessibility/TitanAccessibilityService;->licWorker:Ljava/util/concurrent/ExecutorService;
    .line 157: invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;
    .line 160: invoke-super {v3}, Landroid/app/Service;->onDestroy()V
    .line 163: return-void
.end method

# virtual methods
.method public onInterrupt()V
    .registers 1

    .line 0: return-void
.end method

# virtual methods
.method public onServiceConnected()V
    .registers 7

    .line 0: invoke-super {v6}, Landroid/accessibilityservice/AccessibilityService;->onServiceConnected()V
    .line 3: new-instance v0, Landroid/content/IntentFilter;
    .line 5: const-string v1, "com.titanchess.accessibility.POSITION"
    .line 7: invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V
    .line 10: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 12: const/16 v2, 33
    .line 14: if-lt v1, v2, :cond_24
    .line 16: iget-object v3, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->fenReceiver:Lcom/titanchess/accessibility/c2;
    .line 18: iget-object v4, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 20: invoke-static {v6, v3, v0, v4}, Lai/onnxruntime/a;->x(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/c2;Landroid/content/IntentFilter;Landroid/os/Handler;)V
    .line 23: goto :goto_32
    .line 24: iget-object v3, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->fenReceiver:Lcom/titanchess/accessibility/c2;
    .line 26: const/4 v4, 0
    .line 27: iget-object v5, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->bg:Landroid/os/Handler;
    .line 29: invoke-virtual {v6, v3, v0, v4, v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    .line 32: new-instance v0, Landroid/content/IntentFilter;
    .line 34: const-string v3, "com.titanchess.accessibility.FLOAT_SYNC"
    .line 36: invoke-direct {v0, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V
    .line 39: if-lt v1, v2, :cond_47
    .line 41: iget-object v1, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->floatSyncReceiver:Lcom/titanchess/accessibility/d2;
    .line 43: invoke-static {v6, v1, v0}, Lai/onnxruntime/a;->y(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/d2;Landroid/content/IntentFilter;)V
    .line 46: goto :goto_52
    .line 47: iget-object v1, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->floatSyncReceiver:Lcom/titanchess/accessibility/d2;
    .line 49: invoke-virtual {v6, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    .line 52: iget-object v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->worker:Ljava/util/concurrent/ExecutorService;
    .line 54: new-instance v1, Lcom/titanchess/accessibility/v1;
    .line 56: const/4 v2, 2
    .line 57: invoke-direct {v1, v6, v2}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 60: invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 63: iget-object v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->evalWorker:Ljava/util/concurrent/ExecutorService;
    .line 65: new-instance v1, Lcom/titanchess/accessibility/v1;
    .line 67: const/4 v2, 3
    .line 68: invoke-direct {v1, v6, v2}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 71: invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    .line 74: iget-object v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 76: new-instance v1, Lcom/titanchess/accessibility/v1;
    .line 78: const/4 v2, 4
    .line 79: invoke-direct {v1, v6, v2}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 82: invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 85: iget-object v0, v6, Lcom/titanchess/accessibility/TitanAccessibilityService;->main:Landroid/os/Handler;
    .line 87: new-instance v1, Lcom/titanchess/accessibility/v1;
    .line 89: const/4 v2, 5
    .line 90: invoke-direct {v1, v6, v2}, Lcom/titanchess/accessibility/v1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 93: invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 96: const-string v0, "TitanA11y"
    .line 98: const-string v1, "connected + FEN receiver registered; warming model"
    .line 100: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 103: return-void
.end method

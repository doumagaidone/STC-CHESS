.class public final Lcom/titanchess/accessibility/e;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lcom/titanchess/accessibility/e;
.field public static final b:Lcom/titanchess/accessibility/e;
.field public static final c:[J
.field public static d:[J

# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Lcom/titanchess/accessibility/e;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Lcom/titanchess/accessibility/e;->a:Lcom/titanchess/accessibility/e;
    .line 7: new-instance v0, Lcom/titanchess/accessibility/e;
    .line 9: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 12: sput-object v0, Lcom/titanchess/accessibility/e;->b:Lcom/titanchess/accessibility/e;
    .line 14: const/16 v0, 781
    .line 16: new-array v0, v0, [J
    .line 18: fill-array-data v0, :data_24
    .line 21: sput-object v0, Lcom/titanchess/accessibility/e;->c:[J
    .line 23: return-void
    .line 24: nop
    .line 25: move-object/from16 v0, v781
    .line 27: nop
    .line 28: 0x41 ; unknown opcode
    .line 29: invoke-static/range {v40249 .. v40299}, Lkotlinx/coroutines/internal/r;-><init>(I)V
    .line 32: sub-float/2addr v5, v10
    .line 33: rem-float v5, v128, v57
    .line 35: 0xf7 ; unknown opcode
    .line 36: aget-boolean v53, v98, v36
    .line 38: aput-char v1, v219, v68
    .line 40: ushr-int/lit8 v106, v167, 98
    .line 42: 0x3e ; unknown opcode
    .line 43: const/high16 v156, 0xc89
    .line 45: sub-long v72, v101, v68
    .line 47: int-to-double v5, v7
    .line 48: rem-long/2addr v1, v0
    .line 49: cmpg-double v32, v58, v172
    .line 51: add-int v50, v121, v34
    .line 53: move-wide v1, v6
    .line 54: check-cast v173, type@4027
    .line 56: rem-float/2addr v0, v6
    .line 57: 0xfb ; unknown opcode
    .line 58: int-to-short v0, v9
    .line 59: if-ltz v232, :cond_23627
    .line 61: invoke-super/range {v3454 .. v3541}, method@30301
    .line 64: cmpl-float v224, v175, v206
    .line 66: new-instance v56, type@6664
    .line 68: add-int/2addr v3, v12
    .line 69: iput-char v2, v14, field@54768
    .line 71: move-wide/from16 v150, v11989
    .line 73: if-ltz v209, :cond_-91
    .line 75: array-length v0, v13
    .line 76: if-eq v14, v2, :cond_19123
    .line 78: iput-byte v1, v15, field@16573
    .line 80: and-int v99, v213, v111
    .line 82: const v85, 0xd9e50113
    .line 85: 0xf3 ; unknown opcode
    .line 86: instance-of v3, v8, type@23988
    .line 88: sub-double/2addr v9, v1
    .line 89: 0xf7 ; unknown opcode
    .line 90: cmpl-float v139, v159, v35
    .line 92: or-long v154, v180, v133
    .line 94: div-double v161, v209, v5
    .line 96: invoke-static {v15, v8, v4, v8, v9}, method@28303
    .line 99: rem-long v103, v11, v237
    .line 101: check-cast v128, type@48127
    .line 103: aget-char v116, v240, v173
    .line 105: xor-int/2addr v3, v12
    .line 106: sub-int/2addr v13, v12
    .line 107: return-object v125
    .line 108: sub-double/2addr v7, v11
    .line 109: monitor-exit v120
    .line 110: div-long v112, v199, v130
    .line 112: sput-char v120, field@38160
    .line 114: const-class v143, type@62241
    .line 116: 0xe6 ; unknown opcode
    .line 117: aput-short v175, v243, v120
    .line 119: const v51, 0xe7219443
    .line 122: 0xe5 ; unknown opcode
    .line 123: div-int/2addr v11, v4
    .line 124: 0xfc ; unknown opcode
    .line 125: 0xfd ; unknown opcode
    .line 126: invoke-virtual {v11, v0, v4, v13, v12}, method@43620
    .line 129: rem-double v82, v163, v152
    .line 131: mul-long/2addr v13, v8
    .line 132: const-wide/32 v146, 0x74b81d7
    .line 135: mul-int/lit16 v7, v8, 10977
    .line 137: 0xe9 ; unknown opcode
    .line 138: aput-short v199, v243, v25
    .line 140: rem-long/2addr v10, v9
    .line 141: sub-int/2addr v2, v6
    .line 142: 0xf0 ; unknown opcode
    .line 143: add-double v180, v196, v122
    .line 145: move-wide v2, v4
    .line 146: sub-double v0, v5, v123
    .line 148: iput-byte v8, v13, Lo0/m;->c:F
    .line 150: mul-float v44, v69, v201
    .line 152: nop
    .line 153: xor-long v77, v81, v108
    .line 155: rem-float v36, v71, v180
    .line 157: move v5, v7
    .line 158: 0x42 ; unknown opcode
    .line 159: rem-long v76, v65, v8
    .line 161: sub-int v60, v215, v143
    .line 163: add-float v20, v147, v189
    .line 165: const-class v70, type@39811
    .line 167: const-string/jumbo ; decode error
.end method

# direct methods
.method public static a([B)[B
    .registers 7

    .line 0: array-length v0, v6
    .line 1: const/16 v1, 73
    .line 3: if-le v0, v1, :cond_79
    .line 5: const/4 v0, 0
    .line 6: aget-byte v0, v6, v0
    .line 8: const/4 v2, 2
    .line 9: if-ne v0, v2, :cond_63
    .line 11: const/4 v0, 1
    .line 12: const/16 v3, 13
    .line 14: invoke-static {v6, v0, v3}, Lt2/k;->Q0([BII)[B
    .line 17: move-result-object v0
    .line 18: const/16 v4, 61
    .line 20: invoke-static {v6, v3, v4}, Lt2/k;->Q0([BII)[B
    .line 23: move-result-object v3
    .line 24: invoke-static {v6, v4, v1}, Lt2/k;->Q0([BII)[B
    .line 27: move-result-object v4
    .line 28: invoke-static {}, Lcom/titanchess/accessibility/e;->h()Ljavax/crypto/SecretKey;
    .line 31: move-result-object v5
    .line 32: invoke-static {v2, v5, v0}, Lcom/titanchess/accessibility/e;->d(ILjavax/crypto/SecretKey;[B)Ljavax/crypto/Cipher;
    .line 35: move-result-object v0
    .line 36: invoke-virtual {v0, v3}, Ljavax/crypto/Cipher;->doFinal([B)[B
    .line 39: move-result-object v0
    .line 40: new-instance v3, Ljavax/crypto/spec/SecretKeySpec;
    .line 42: const-string v5, "AES"
    .line 44: invoke-direct {v3, v0, v5}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V
    .line 47: invoke-static {v2, v3, v4}, Lcom/titanchess/accessibility/e;->d(ILjavax/crypto/SecretKey;[B)Ljavax/crypto/Cipher;
    .line 50: move-result-object v0
    .line 51: array-length v2, v6
    .line 52: sub-int/2addr v2, v1
    .line 53: invoke-virtual {v0, v6, v1, v2}, Ljavax/crypto/Cipher;->doFinal([BII)[B
    .line 56: move-result-object v6
    .line 57: const-string v0, "doFinal(...)"
    .line 59: invoke-static {v6, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 62: return-object v6
    .line 63: const-string v6, "unsupported band format v"
    .line 65: invoke-static {v6, v0}, Lai/onnxruntime/b;->f(Ljava/lang/String;I)Ljava/lang/String;
    .line 68: move-result-object v6
    .line 69: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 71: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 74: move-result-object v6
    .line 75: invoke-direct {v0, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 78: throw v0
    .line 79: array-length v6, v6
    .line 80: const-string v0, "band blob too short ("
    .line 82: const-string v1, ")"
    .line 84: invoke-static {v0, v6, v1}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 87: move-result-object v6
    .line 88: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 90: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 93: move-result-object v6
    .line 94: invoke-direct {v0, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 97: throw v0
.end method

# direct methods
.method public static c(Landroid/content/Context;)V
    .registers 5

    .line 0: const-string v0, "ctx"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "titan"
    .line 7: const/4 v1, 0
    .line 8: invoke-virtual {v4, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 11: move-result-object v4
    .line 12: const-string v0, "lic_status"
    .line 14: const-string v1, "none"
    .line 16: invoke-interface {v4, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 19: move-result-object v1
    .line 20: const-string v2, "active"
    .line 22: invoke-static {v1, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 25: move-result v1
    .line 26: if-nez v1, :cond_29
    .line 28: return-void
    .line 29: const-string v1, "lic_expires"
    .line 31: const/4 v2, 0
    .line 32: invoke-interface {v4, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 35: move-result-object v1
    .line 36: if-nez v1, :cond_39
    .line 38: return-void
    .line 39: invoke-static {}, Lai/onnxruntime/a;->o()Ljava/time/LocalDate;
    .line 42: move-result-object v2
    .line 43: invoke-static {v2}, Lai/onnxruntime/a;->k(Ljava/time/LocalDate;)Ljava/lang/String;
    .line 46: move-result-object v2
    .line 47: const-string v3, "toString(...)"
    .line 49: invoke-static {v2, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 52: invoke-virtual {v1, v2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I
    .line 55: move-result v1
    .line 56: if-gez v1, :cond_79
    .line 58: invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 61: move-result-object v4
    .line 62: const-string v1, "expired"
    .line 64: invoke-interface {v4, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 67: move-result-object v4
    .line 68: const-string v0, "lic_msg"
    .line 70: const-string v1, "license expired"
    .line 72: invoke-interface {v4, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 75: move-result-object v4
    .line 76: invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 79: return-void
.end method

# direct methods
.method public static d(ILjavax/crypto/SecretKey;[B)Ljavax/crypto/Cipher;
    .registers 6

    .line 0: const-string v0, "AES/GCM/NoPadding"
    .line 2: invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;
    .line 5: move-result-object v0
    .line 6: if-nez v5, :cond_12
    .line 8: invoke-virtual {v0, v3, v4}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V
    .line 11: goto :goto_22
    .line 12: new-instance v1, Ljavax/crypto/spec/GCMParameterSpec;
    .line 14: const/16 v2, 128
    .line 16: invoke-direct {v1, v2, v5}, Ljavax/crypto/spec/GCMParameterSpec;-><init>(I[B)V
    .line 19: invoke-virtual {v0, v3, v4, v1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V
    .line 22: return-object v0
.end method

# direct methods
.method public static e(Landroid/content/Context;)Ljava/lang/String;
    .registers 5

    .line 0: const-string v0, "ctx"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    .line 8: move-result-object v0
    .line 9: const-string v1, "android_id"
    .line 11: invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    .line 14: move-result-object v0
    .line 15: if-nez v0, :cond_19
    .line 17: const-string v0, "UNKNOWN"
    .line 19: sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;
    .line 21: sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;
    .line 23: new-instance v3, Ljava/lang/StringBuilder;
    .line 25: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 28: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 31: const-string v0, "|"
    .line 33: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 36: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 45: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 48: move-result-object v0
    .line 49: const-string v1, "SHA-256"
    .line 51: invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;
    .line 54: move-result-object v1
    .line 55: sget-object v2, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 57: invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B
    .line 60: move-result-object v0
    .line 61: const-string v2, "this as java.lang.String).getBytes(charset)"
    .line 63: invoke-static {v0, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 66: invoke-virtual {v1, v0}, Ljava/security/MessageDigest;->digest([B)[B
    .line 69: move-result-object v0
    .line 70: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 73: sget-object v1, Lcom/titanchess/accessibility/x;->k:Lcom/titanchess/accessibility/x;
    .line 75: invoke-static {v0, v1}, Lt2/k;->V0([BLcom/titanchess/accessibility/x;)Ljava/lang/String;
    .line 78: move-result-object v0
    .line 79: const/16 v1, 16
    .line 81: invoke-static {v1, v0}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 84: move-result-object v0
    .line 85: sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;
    .line 87: invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 90: move-result-object v0
    .line 91: const-string v1, "this as java.lang.String).toUpperCase(Locale.ROOT)"
    .line 93: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 96: const-string v1, "AND-"
    .line 98: invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 101: move-result-object v0
    .line 102: sget-object v1, Lcom/titanchess/accessibility/TitanGuard;->INSTANCE:Lcom/titanchess/accessibility/TitanGuard;
    .line 104: invoke-virtual {v1, v4, v0}, Lcom/titanchess/accessibility/TitanGuard;->check(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .line 107: move-result-object v4
    .line 108: return-object v4
.end method

# direct methods
.method public static f(Ljava/lang/String;)Z
    .registers 26

    .line 0: const-string v0, "fen"
    .line 2: move-object/from16 v1, v25
    .line 4: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: sget-object v0, Lcom/titanchess/accessibility/e;->d:[J
    .line 9: const/4 v2, 0
    .line 10: if-nez v0, :cond_13
    .line 12: return v2
    .line 13: invoke-static/range {v25 .. v25}, Lm3/j;->m2(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .line 16: move-result-object v1
    .line 17: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 20: move-result-object v1
    .line 21: const-string v3, "\\s+"
    .line 23: invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;
    .line 26: move-result-object v3
    .line 27: const-string v4, "compile(pattern)"
    .line 29: invoke-static {v3, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 32: const-string v4, "input"
    .line 34: invoke-static {v1, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: invoke-static {v2}, Lm3/j;->b2(I)V
    .line 40: invoke-virtual {v3, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    .line 43: move-result-object v3
    .line 44: invoke-virtual {v3}, Ljava/util/regex/Matcher;->find()Z
    .line 47: move-result v4
    .line 48: const/16 v5, 10
    .line 50: if-nez v4, :cond_61
    .line 52: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 55: move-result-object v1
    .line 56: invoke-static {v1}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 59: move-result-object v1
    .line 60: goto :goto_108
    .line 61: new-instance v4, Ljava/util/ArrayList;
    .line 63: invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V
    .line 66: move v6, v2
    .line 67: invoke-virtual {v3}, Ljava/util/regex/Matcher;->start()I
    .line 70: move-result v7
    .line 71: invoke-virtual {v1, v6, v7}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;
    .line 74: move-result-object v6
    .line 75: invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 78: move-result-object v6
    .line 79: invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 82: invoke-virtual {v3}, Ljava/util/regex/Matcher;->end()I
    .line 85: move-result v6
    .line 86: invoke-virtual {v3}, Ljava/util/regex/Matcher;->find()Z
    .line 89: move-result v7
    .line 90: if-nez v7, :cond_67
    .line 92: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 95: move-result v3
    .line 96: invoke-virtual {v1, v6, v3}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;
    .line 99: move-result-object v1
    .line 100: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 103: move-result-object v1
    .line 104: invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 107: move-object v1, v4
    .line 108: invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 111: move-result-object v3
    .line 112: check-cast v3, Ljava/lang/String;
    .line 114: invoke-static {v1}, Ld2/b;->r0(Ljava/util/List;)I
    .line 117: move-result v4
    .line 118: const/4 v6, 1
    .line 119: const-string v7, "w"
    .line 121: if-gt v6, v4, :cond_128
    .line 123: invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 126: move-result-object v4
    .line 127: goto :goto_129
    .line 128: move-object v4, v7
    .line 129: check-cast v4, Ljava/lang/String;
    .line 131: invoke-static {v1}, Ld2/b;->r0(Ljava/util/List;)I
    .line 134: move-result v8
    .line 135: const-string v9, "-"
    .line 137: const/4 v10, 2
    .line 138: if-gt v10, v8, :cond_145
    .line 140: invoke-interface {v1, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 143: move-result-object v8
    .line 144: goto :goto_146
    .line 145: move-object v8, v9
    .line 146: check-cast v8, Ljava/lang/String;
    .line 148: invoke-static {v1}, Ld2/b;->r0(Ljava/util/List;)I
    .line 151: move-result v11
    .line 152: const/4 v12, 3
    .line 153: if-gt v12, v11, :cond_160
    .line 155: invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 158: move-result-object v1
    .line 159: goto :goto_161
    .line 160: move-object v1, v9
    .line 161: check-cast v1, Ljava/lang/String;
    .line 163: new-array v11, v6, [C
    .line 165: const/16 v13, 47
    .line 167: aput-char v13, v11, v2
    .line 169: invoke-static {v3, v11}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 172: move-result-object v11
    .line 173: invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 176: move-result-object v11
    .line 177: const-wide/16 v15, 0
    .line 179: const/16 v17, 7
    .line 181: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 184: move-result v18
    .line 185: sget-object v19, Lcom/titanchess/accessibility/e;->c:[J
    .line 187: const/16 v21, 4
    .line 189: const/16 v13, 80
    .line 191: const/16 v5, 112
    .line 193: if-eqz v18, :cond_364
    .line 195: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 198: move-result-object v18
    .line 199: move-object/from16 v14, v18
    .line 201: check-cast v14, Ljava/lang/String;
    .line 203: invoke-virtual {v14}, Ljava/lang/String;->length()I
    .line 206: move-result v12
    .line 207: move v10, v2
    .line 208: move/from16 v22, v10
    .line 210: if-ge v10, v12, :cond_353
    .line 212: invoke-virtual {v14, v10}, Ljava/lang/String;->charAt(I)C
    .line 215: move-result v6
    .line 216: invoke-static {v6}, Ljava/lang/Character;->isDigit(C)Z
    .line 219: move-result v24
    .line 220: if-eqz v24, :cond_230
    .line 222: add-int/lit8 v6, v6, -48
    .line 224: add-int v6, v6, v22
    .line 226: move/from16 v22, v6
    .line 228: goto/16 :goto_346
    .line 230: if-ne v6, v5, :cond_237
    .line 232: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 235: move-result-object v6
    .line 236: goto :goto_322
    .line 237: if-ne v6, v13, :cond_246
    .line 239: const/16 v23, 1
    .line 241: invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 244: move-result-object v6
    .line 245: goto :goto_322
    .line 246: const/16 v5, 110
    .line 248: if-ne v6, v5, :cond_256
    .line 250: const/4 v5, 2
    .line 251: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 254: move-result-object v6
    .line 255: goto :goto_322
    .line 256: const/16 v5, 78
    .line 258: if-ne v6, v5, :cond_262
    .line 260: const/4 v5, 3
    .line 261: goto :goto_251
    .line 262: const/16 v5, 98
    .line 264: if-ne v6, v5, :cond_271
    .line 266: invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 269: move-result-object v6
    .line 270: goto :goto_322
    .line 271: const/16 v5, 66
    .line 273: if-ne v6, v5, :cond_277
    .line 275: const/4 v5, 5
    .line 276: goto :goto_251
    .line 277: const/16 v5, 114
    .line 279: if-ne v6, v5, :cond_287
    .line 281: const/4 v5, 6
    .line 282: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 285: move-result-object v6
    .line 286: goto :goto_322
    .line 287: const/16 v5, 82
    .line 289: if-ne v6, v5, :cond_293
    .line 291: const/4 v5, 7
    .line 292: goto :goto_282
    .line 293: const/16 v5, 113
    .line 295: if-ne v6, v5, :cond_300
    .line 297: const/16 v5, 8
    .line 299: goto :goto_282
    .line 300: const/16 v5, 81
    .line 302: if-ne v6, v5, :cond_307
    .line 304: const/16 v5, 9
    .line 306: goto :goto_282
    .line 307: const/16 v5, 107
    .line 309: if-ne v6, v5, :cond_314
    .line 311: const/16 v5, 10
    .line 313: goto :goto_282
    .line 314: const/16 v5, 75
    .line 316: if-ne v6, v5, :cond_321
    .line 318: const/16 v5, 11
    .line 320: goto :goto_282
    .line 321: const/4 v6, 0
    .line 322: if-eqz v6, :cond_329
    .line 324: invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I
    .line 327: move-result v5
    .line 328: goto :goto_332
    .line 329: add-int/lit8 v22, v22, 1
    .line 331: const/4 v5, -1
    .line 332: if-ltz v5, :cond_344
    .line 334: mul-int/lit8 v5, v5, 64
    .line 336: mul-int/lit8 v6, v17, 8
    .line 338: add-int/2addr v6, v5
    .line 339: add-int v6, v6, v22
    .line 341: aget-wide v5, v19, v6
    .line 343: xor-long/2addr v15, v5
    .line 344: add-int/lit8 v22, v22, 1
    .line 346: add-int/lit8 v10, v10, 1
    .line 348: const/16 v5, 112
    .line 350: const/4 v6, 1
    .line 351: goto/16 :goto_210
    .line 353: add-int/lit8 v17, v17, -1
    .line 355: const/16 v5, 10
    .line 357: const/4 v6, 1
    .line 358: const/4 v10, 2
    .line 359: const/4 v12, 3
    .line 360: const/16 v13, 47
    .line 362: goto/16 :goto_181
    .line 364: const/16 v5, 75
    .line 366: invoke-static {v8, v5}, Lm3/j;->H1(Ljava/lang/CharSequence;C)Z
    .line 369: move-result v5
    .line 370: if-eqz v5, :cond_377
    .line 372: const/16 v5, 768
    .line 374: aget-wide v5, v19, v5
    .line 376: xor-long/2addr v15, v5
    .line 377: const/16 v5, 81
    .line 379: invoke-static {v8, v5}, Lm3/j;->H1(Ljava/lang/CharSequence;C)Z
    .line 382: move-result v5
    .line 383: if-eqz v5, :cond_390
    .line 385: const/16 v5, 769
    .line 387: aget-wide v5, v19, v5
    .line 389: xor-long/2addr v15, v5
    .line 390: const/16 v5, 107
    .line 392: invoke-static {v8, v5}, Lm3/j;->H1(Ljava/lang/CharSequence;C)Z
    .line 395: move-result v5
    .line 396: if-eqz v5, :cond_403
    .line 398: const/16 v5, 770
    .line 400: aget-wide v5, v19, v5
    .line 402: xor-long/2addr v15, v5
    .line 403: const/16 v5, 113
    .line 405: invoke-static {v8, v5}, Lm3/j;->H1(Ljava/lang/CharSequence;C)Z
    .line 408: move-result v5
    .line 409: if-eqz v5, :cond_416
    .line 411: const/16 v5, 771
    .line 413: aget-wide v5, v19, v5
    .line 415: xor-long/2addr v15, v5
    .line 416: invoke-static {v1, v9}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 419: move-result v5
    .line 420: if-nez v5, :cond_578
    .line 422: invoke-virtual {v1}, Ljava/lang/String;->length()I
    .line 425: move-result v5
    .line 426: const/4 v6, 2
    .line 427: if-ne v5, v6, :cond_578
    .line 429: invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C
    .line 432: move-result v1
    .line 433: add-int/lit8 v5, v1, -97
    .line 435: invoke-static {v4, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 438: move-result v6
    .line 439: const/16 v8, 8
    .line 441: new-array v9, v8, [[C
    .line 443: move v10, v2
    .line 444: if-ge v10, v8, :cond_467
    .line 446: new-array v11, v8, [C
    .line 448: move v12, v2
    .line 449: if-ge v12, v8, :cond_460
    .line 451: const/16 v8, 32
    .line 453: aput-char v8, v11, v12
    .line 455: add-int/lit8 v12, v12, 1
    .line 457: const/16 v8, 8
    .line 459: goto :goto_449
    .line 460: aput-object v11, v9, v10
    .line 462: add-int/lit8 v10, v10, 1
    .line 464: const/16 v8, 8
    .line 466: goto :goto_444
    .line 467: const/4 v8, 1
    .line 468: new-array v10, v8, [C
    .line 470: const/16 v8, 47
    .line 472: aput-char v8, v10, v2
    .line 474: invoke-static {v3, v10}, Lm3/j;->d2(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .line 477: move-result-object v3
    .line 478: invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 481: move-result-object v3
    .line 482: const/4 v14, 7
    .line 483: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 486: move-result v8
    .line 487: if-eqz v8, :cond_532
    .line 489: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 492: move-result-object v8
    .line 493: check-cast v8, Ljava/lang/String;
    .line 495: invoke-virtual {v8}, Ljava/lang/String;->length()I
    .line 498: move-result v10
    .line 499: move v11, v2
    .line 500: move v12, v11
    .line 501: if-ge v11, v10, :cond_529
    .line 503: invoke-virtual {v8, v11}, Ljava/lang/String;->charAt(I)C
    .line 506: move-result v17
    .line 507: invoke-static/range {v17 .. v17}, Ljava/lang/Character;->isDigit(C)Z
    .line 510: move-result v20
    .line 511: if-eqz v20, :cond_520
    .line 513: add-int/lit8 v17, v17, -48
    .line 515: add-int v17, v17, v12
    .line 517: move/from16 v12, v17
    .line 519: goto :goto_526
    .line 520: aget-object v20, v9, v14
    .line 522: aput-char v17, v20, v12
    .line 524: add-int/lit8 v12, v12, 1
    .line 526: add-int/lit8 v11, v11, 1
    .line 528: goto :goto_501
    .line 529: add-int/lit8 v14, v14, -1
    .line 531: goto :goto_483
    .line 532: if-eqz v6, :cond_537
    .line 534: move/from16 v12, v21
    .line 536: goto :goto_538
    .line 537: const/4 v12, 3
    .line 538: const/4 v3, 1
    .line 539: if-eqz v6, :cond_543
    .line 541: const/4 v6, -1
    .line 542: goto :goto_546
    .line 543: const/4 v6, -1
    .line 544: const/16 v13, 112
    .line 546: filled-new-array {v6, v3}, [I
    .line 549: move-result-object v6
    .line 550: move v8, v2
    .line 551: const/4 v3, 2
    .line 552: if-ge v8, v3, :cond_578
    .line 554: aget v10, v6, v8
    .line 556: add-int/2addr v10, v5
    .line 557: const/16 v11, 8
    .line 559: if-ltz v10, :cond_575
    .line 561: if-ge v10, v11, :cond_575
    .line 563: aget-object v14, v9, v12
    .line 565: aget-char v10, v14, v10
    .line 567: if-ne v10, v13, :cond_575
    .line 569: add-int/lit16 v1, v1, 675
    .line 571: aget-wide v5, v19, v1
    .line 573: xor-long/2addr v15, v5
    .line 574: goto :goto_578
    .line 575: add-int/lit8 v8, v8, 1
    .line 577: goto :goto_552
    .line 578: invoke-static {v4, v7}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 581: move-result v1
    .line 582: if-eqz v1, :cond_589
    .line 584: const/16 v1, 780
    .line 586: aget-wide v3, v19, v1
    .line 588: xor-long/2addr v15, v3
    .line 589: array-length v1, v0
    .line 590: const/4 v3, 1
    .line 591: sub-int/2addr v1, v3
    .line 592: move v4, v2
    .line 593: if-gt v4, v1, :cond_621
    .line 595: add-int v5, v4, v1
    .line 597: ushr-int/2addr v5, v3
    .line 598: aget-wide v6, v0, v5
    .line 600: const-wide/high16 v8, 0x8000
    .line 602: xor-long/2addr v6, v8
    .line 603: xor-long/2addr v8, v15
    .line 604: invoke-static {v6, v7, v8, v9}, Ljava/lang/Long;->compare(JJ)I
    .line 607: move-result v3
    .line 608: if-gez v3, :cond_614
    .line 610: add-int/lit8 v4, v5, 1
    .line 612: const/4 v3, 1
    .line 613: goto :goto_593
    .line 614: if-lez v3, :cond_619
    .line 616: add-int/lit8 v1, v5, -1
    .line 618: goto :goto_612
    .line 619: const/4 v1, 1
    .line 620: return v1
    .line 621: return v2
.end method

# direct methods
.method public static g(Landroid/content/Context;)Z
    .registers 7

    .line 0: const-string v0, "ctx"
    .line 2: invoke-static {v6, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "titan"
    .line 7: const/4 v1, 0
    .line 8: invoke-virtual {v6, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 11: move-result-object v6
    .line 12: const-string v0, "lic_status"
    .line 14: const-string v2, "none"
    .line 16: invoke-interface {v6, v0, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 19: move-result-object v0
    .line 20: const-string v2, "active"
    .line 22: invoke-static {v0, v2}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 25: move-result v0
    .line 26: if-nez v0, :cond_29
    .line 28: return v1
    .line 29: const-string v0, "lic_products"
    .line 31: const-string v2, ""
    .line 33: invoke-interface {v6, v0, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 36: move-result-object v0
    .line 37: if-nez v0, :cond_40
    .line 39: goto :goto_41
    .line 40: move-object v2, v0
    .line 41: sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;
    .line 43: invoke-virtual {v2, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 46: move-result-object v0
    .line 47: const-string v2, "this as java.lang.String).toLowerCase(Locale.ROOT)"
    .line 49: invoke-static {v0, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 52: const-string v2, "mimic"
    .line 54: invoke-static {v0, v2, v1}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 57: move-result v2
    .line 58: if-nez v2, :cond_77
    .line 60: const-string v2, "native"
    .line 62: invoke-static {v0, v2, v1}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 65: move-result v2
    .line 66: if-nez v2, :cond_77
    .line 68: const-string v2, "qwen"
    .line 70: invoke-static {v0, v2, v1}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 73: move-result v0
    .line 74: if-nez v0, :cond_77
    .line 76: return v1
    .line 77: const-string v0, "lic_checked"
    .line 79: const-wide/16 v2, 0
    .line 81: invoke-interface {v6, v0, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J
    .line 84: move-result-wide v4
    .line 85: cmp-long v6, v4, v2
    .line 87: if-lez v6, :cond_102
    .line 89: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    .line 92: move-result-wide v2
    .line 93: sub-long/2addr v2, v4
    .line 94: const-wide/32 v4, 0x5265c00
    .line 97: cmp-long v6, v2, v4
    .line 99: if-gtz v6, :cond_102
    .line 101: const/4 v1, 1
    .line 102: return v1
.end method

# direct methods
.method public static h()Ljavax/crypto/SecretKey;
    .registers 5

    .line 0: const-string v0, "AndroidKeyStore"
    .line 2: invoke-static {v0}, Ljava/security/KeyStore;->getInstance(Ljava/lang/String;)Ljava/security/KeyStore;
    .line 5: move-result-object v1
    .line 6: const/4 v2, 0
    .line 7: invoke-virtual {v1, v2}, Ljava/security/KeyStore;->load(Ljava/security/KeyStore$LoadStoreParameter;)V
    .line 10: const-string v3, "titan_band_key"
    .line 12: invoke-virtual {v1, v3, v2}, Ljava/security/KeyStore;->getEntry(Ljava/lang/String;Ljava/security/KeyStore$ProtectionParameter;)Ljava/security/KeyStore$Entry;
    .line 15: move-result-object v1
    .line 16: instance-of v4, v1, Ljava/security/KeyStore$SecretKeyEntry;
    .line 18: if-eqz v4, :cond_23
    .line 20: move-object v2, v1
    .line 21: check-cast v2, Ljava/security/KeyStore$SecretKeyEntry;
    .line 23: if-eqz v2, :cond_35
    .line 25: invoke-virtual {v2}, Ljava/security/KeyStore$SecretKeyEntry;->getSecretKey()Ljavax/crypto/SecretKey;
    .line 28: move-result-object v0
    .line 29: const-string v1, "getSecretKey(...)"
    .line 31: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 34: return-object v0
    .line 35: const-string v1, "AES"
    .line 37: invoke-static {v1, v0}, Ljavax/crypto/KeyGenerator;->getInstance(Ljava/lang/String;Ljava/lang/String;)Ljavax/crypto/KeyGenerator;
    .line 40: move-result-object v0
    .line 41: new-instance v1, Landroid/security/keystore/KeyGenParameterSpec$Builder;
    .line 43: const/4 v2, 3
    .line 44: invoke-direct {v1, v3, v2}, Landroid/security/keystore/KeyGenParameterSpec$Builder;-><init>(Ljava/lang/String;I)V
    .line 47: const-string v2, "GCM"
    .line 49: filled-new-array {v2}, [Ljava/lang/String;
    .line 52: move-result-object v2
    .line 53: invoke-virtual {v1, v2}, Landroid/security/keystore/KeyGenParameterSpec$Builder;->setBlockModes([Ljava/lang/String;)Landroid/security/keystore/KeyGenParameterSpec$Builder;
    .line 56: move-result-object v1
    .line 57: const-string v2, "NoPadding"
    .line 59: filled-new-array {v2}, [Ljava/lang/String;
    .line 62: move-result-object v2
    .line 63: invoke-virtual {v1, v2}, Landroid/security/keystore/KeyGenParameterSpec$Builder;->setEncryptionPaddings([Ljava/lang/String;)Landroid/security/keystore/KeyGenParameterSpec$Builder;
    .line 66: move-result-object v1
    .line 67: const/16 v2, 256
    .line 69: invoke-virtual {v1, v2}, Landroid/security/keystore/KeyGenParameterSpec$Builder;->setKeySize(I)Landroid/security/keystore/KeyGenParameterSpec$Builder;
    .line 72: move-result-object v1
    .line 73: invoke-virtual {v1}, Landroid/security/keystore/KeyGenParameterSpec$Builder;->build()Landroid/security/keystore/KeyGenParameterSpec;
    .line 76: move-result-object v1
    .line 77: invoke-virtual {v0, v1}, Ljavax/crypto/KeyGenerator;->init(Ljava/security/spec/AlgorithmParameterSpec;)V
    .line 80: invoke-virtual {v0}, Ljavax/crypto/KeyGenerator;->generateKey()Ljavax/crypto/SecretKey;
    .line 83: move-result-object v0
    .line 84: const-string v1, "generateKey(...)"
    .line 86: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 89: return-object v0
.end method

# direct methods
.method public static j(Landroid/content/Context;Ljava/lang/String;)Lcom/titanchess/accessibility/w;
    .registers 28

    .line 0: move-object/from16 v0, v26
    .line 2: const-string v1, "ctx"
    .line 4: invoke-static {v0, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: const-string v1, "titan"
    .line 9: const/4 v7, 0
    .line 10: invoke-virtual {v0, v1, v7}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 13: move-result-object v8
    .line 14: invoke-static/range {v26 .. v26}, Lcom/titanchess/accessibility/e;->e(Landroid/content/Context;)Ljava/lang/String;
    .line 17: move-result-object v3
    .line 18: invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 21: move-result-object v1
    .line 22: const-string v2, "lic_hwid"
    .line 24: invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 27: move-result-object v1
    .line 28: const-string v2, "lic_key"
    .line 30: move-object/from16 v4, v27
    .line 32: invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 35: move-result-object v1
    .line 36: invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 39: new-instance v1, Lr3/u;
    .line 41: invoke-direct {v1}, Lr3/u;-><init>()V
    .line 44: sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;
    .line 46: const-string v5, "unit"
    .line 48: invoke-static {v2, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 51: const-wide/16 v9, 12
    .line 53: invoke-static {v9, v10, v2}, Ls3/b;->b(JLjava/util/concurrent/TimeUnit;)I
    .line 56: move-result v5
    .line 57: iput v5, v1, Lr3/u;->x:I
    .line 59: invoke-static {v9, v10, v2}, Ls3/b;->b(JLjava/util/concurrent/TimeUnit;)I
    .line 62: move-result v2
    .line 63: iput v2, v1, Lr3/u;->y:I
    .line 65: new-instance v11, Lr3/v;
    .line 67: invoke-direct {v11, v1}, Lr3/v;-><init>(Lr3/u;)V
    .line 70: new-instance v12, Ljava/util/concurrent/CountDownLatch;
    .line 72: const/4 v13, 1
    .line 73: invoke-direct {v12, v13}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V
    .line 76: new-instance v14, Ljava/util/concurrent/atomic/AtomicReference;
    .line 78: const/4 v15, 0
    .line 79: invoke-direct {v14, v15}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V
    .line 82: new-instance v19, Lcom/titanchess/accessibility/y;
    .line 84: move-object/from16 v1, v19
    .line 86: move-object/from16 v2, v27
    .line 88: move-object/from16 v4, v26
    .line 90: move-object v5, v14
    .line 91: move-object v6, v12
    .line 92: invoke-direct/range {v1 .. v6}, Lcom/titanchess/accessibility/y;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/CountDownLatch;)V
    .line 95: const/16 v24, 0
    .line 97: new-instance v0, Ljava/util/LinkedHashMap;
    .line 99: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 102: const-string v22, "GET"
    .line 104: new-instance v1, Lr3/p;
    .line 106: invoke-direct {v1}, Lr3/p;-><init>()V
    .line 109: const-string v2, "wss://native-lic.titanchess.space/ws"
    .line 111: const-string v3, "ws:"
    .line 113: invoke-static {v2, v3, v13}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 116: move-result v3
    .line 117: if-eqz v3, :cond_128
    .line 119: const-string v2, "://native-lic.titanchess.space/ws"
    .line 121: const-string v3, "http:"
    .line 123: invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 126: move-result-object v2
    .line 127: goto :goto_144
    .line 128: const-string v3, "wss:"
    .line 130: invoke-static {v2, v3, v13}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 133: move-result v3
    .line 134: if-eqz v3, :cond_144
    .line 136: const-string v2, "//native-lic.titanchess.space/ws"
    .line 138: const-string v3, "https:"
    .line 140: invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 143: move-result-object v2
    .line 144: sget-object v3, Lr3/s;->j:[C
    .line 146: const-string v3, "<this>"
    .line 148: invoke-static {v2, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 151: new-instance v3, Lr3/r;
    .line 153: invoke-direct {v3}, Lr3/r;-><init>()V
    .line 156: invoke-virtual {v3, v15, v2}, Lr3/r;->b(Lr3/s;Ljava/lang/String;)V
    .line 159: invoke-virtual {v3}, Lr3/r;->a()Lr3/s;
    .line 162: move-result-object v21
    .line 163: const-string v2, "User-Agent"
    .line 165: const-string v3, "TitanNative/1 (Android)"
    .line 167: invoke-virtual {v1, v2, v3}, Lr3/p;->d(Ljava/lang/String;Ljava/lang/String;)V
    .line 170: invoke-virtual {v1}, Lr3/p;->b()Lr3/q;
    .line 173: move-result-object v23
    .line 174: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    .line 177: move-result v1
    .line 178: if-eqz v1, :cond_185
    .line 180: sget-object v0, Lt2/s;->i:Lt2/s;
    .line 182: move-object/from16 v25, v0
    .line 184: goto :goto_200
    .line 185: new-instance v1, Ljava/util/LinkedHashMap;
    .line 187: invoke-direct {v1, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V
    .line 190: invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;
    .line 193: move-result-object v0
    .line 194: const-string v1, "{\n    Collections.unmodi…(LinkedHashMap(this))\n  }"
    .line 196: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 199: goto :goto_182
    .line 200: new-instance v18, La1/b;
    .line 202: move-object/from16 v20, v18
    .line 204: invoke-direct/range {v20 .. v25}, La1/b;-><init>(Lr3/s;Ljava/lang/String;Lr3/q;Ld2/c;Ljava/util/Map;)V
    .line 207: new-instance v0, Ld4/g;
    .line 209: sget-object v17, Lu3/f;->i:Lu3/f;
    .line 211: new-instance v20, Ljava/util/Random;
    .line 213: invoke-direct/range {v20 .. v20}, Ljava/util/Random;-><init>()V
    .line 216: iget v1, v11, Lr3/v;->I:I
    .line 218: int-to-long v1, v1
    .line 219: iget-wide v3, v11, Lr3/v;->J:J
    .line 221: move-object/from16 v16, v0
    .line 223: move-wide/from16 v21, v1
    .line 225: move-wide/from16 v23, v3
    .line 227: invoke-direct/range {v16 .. v24}, Ld4/g;-><init>(Lu3/f;La1/b;Lcom/titanchess/accessibility/y;Ljava/util/Random;JJ)V
    .line 230: iget-object v1, v0, Ld4/g;->a:La1/b;
    .line 232: const-string v2, "Sec-WebSocket-Extensions"
    .line 234: iget-object v1, v1, La1/b;->d:Ljava/lang/Object;
    .line 236: check-cast v1, Lr3/q;
    .line 238: invoke-virtual {v1, v2}, Lr3/q;->b(Ljava/lang/String;)Ljava/lang/String;
    .line 241: move-result-object v1
    .line 242: const/4 v2, 2
    .line 243: if-eqz v1, :cond_257
    .line 245: new-instance v1, Ljava/net/ProtocolException;
    .line 247: const-string v3, "Request header not permitted: 'Sec-WebSocket-Extensions'"
    .line 249: invoke-direct {v1, v3}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 252: invoke-virtual {v0, v1}, Ld4/g;->c(Ljava/lang/Exception;)V
    .line 255: goto/16 :goto_716
    .line 257: new-instance v1, Lr3/u;
    .line 259: invoke-direct {v1}, Lr3/u;-><init>()V
    .line 262: iget-object v3, v11, Lr3/v;->i:Lr3/k;
    .line 264: iput-object v3, v1, Lr3/u;->a:Lr3/k;
    .line 266: iget-object v3, v11, Lr3/v;->j:Lu/d;
    .line 268: iput-object v3, v1, Lr3/u;->b:Lu/d;
    .line 270: iget-object v3, v1, Lr3/u;->c:Ljava/util/ArrayList;
    .line 272: iget-object v4, v11, Lr3/v;->k:Ljava/util/List;
    .line 274: invoke-static {v4, v3}, Lt2/m;->G1(Ljava/lang/Iterable;Ljava/util/Collection;)V
    .line 277: iget-object v3, v1, Lr3/u;->d:Ljava/util/ArrayList;
    .line 279: iget-object v4, v11, Lr3/v;->l:Ljava/util/List;
    .line 281: invoke-static {v4, v3}, Lt2/m;->G1(Ljava/lang/Iterable;Ljava/util/Collection;)V
    .line 284: iget-boolean v3, v11, Lr3/v;->n:Z
    .line 286: iput-boolean v3, v1, Lr3/u;->f:Z
    .line 288: iget-object v3, v11, Lr3/v;->o:Lr3/b;
    .line 290: iput-object v3, v1, Lr3/u;->g:Lr3/b;
    .line 292: iget-boolean v3, v11, Lr3/v;->p:Z
    .line 294: iput-boolean v3, v1, Lr3/u;->h:Z
    .line 296: iget-boolean v3, v11, Lr3/v;->q:Z
    .line 298: iput-boolean v3, v1, Lr3/u;->i:Z
    .line 300: iget-object v3, v11, Lr3/v;->r:Lr3/j;
    .line 302: iput-object v3, v1, Lr3/u;->j:Lr3/j;
    .line 304: iget-object v3, v11, Lr3/v;->s:Lr3/l;
    .line 306: iput-object v3, v1, Lr3/u;->k:Lr3/l;
    .line 308: iget-object v3, v11, Lr3/v;->t:Ljava/net/Proxy;
    .line 310: iput-object v3, v1, Lr3/u;->l:Ljava/net/Proxy;
    .line 312: iget-object v3, v11, Lr3/v;->u:Ljava/net/ProxySelector;
    .line 314: iput-object v3, v1, Lr3/u;->m:Ljava/net/ProxySelector;
    .line 316: iget-object v3, v11, Lr3/v;->v:Lr3/b;
    .line 318: iput-object v3, v1, Lr3/u;->n:Lr3/b;
    .line 320: iget-object v3, v11, Lr3/v;->w:Ljavax/net/SocketFactory;
    .line 322: iput-object v3, v1, Lr3/u;->o:Ljavax/net/SocketFactory;
    .line 324: iget-object v3, v11, Lr3/v;->x:Ljavax/net/ssl/SSLSocketFactory;
    .line 326: iput-object v3, v1, Lr3/u;->p:Ljavax/net/ssl/SSLSocketFactory;
    .line 328: iget-object v3, v11, Lr3/v;->y:Ljavax/net/ssl/X509TrustManager;
    .line 330: iput-object v3, v1, Lr3/u;->q:Ljavax/net/ssl/X509TrustManager;
    .line 332: iget-object v3, v11, Lr3/v;->z:Ljava/util/List;
    .line 334: iput-object v3, v1, Lr3/u;->r:Ljava/util/List;
    .line 336: iget-object v3, v11, Lr3/v;->A:Ljava/util/List;
    .line 338: iput-object v3, v1, Lr3/u;->s:Ljava/util/List;
    .line 340: iget-object v3, v11, Lr3/v;->B:Ljavax/net/ssl/HostnameVerifier;
    .line 342: iput-object v3, v1, Lr3/u;->t:Ljavax/net/ssl/HostnameVerifier;
    .line 344: iget-object v3, v11, Lr3/v;->C:Lr3/e;
    .line 346: iput-object v3, v1, Lr3/u;->u:Lr3/e;
    .line 348: iget-object v3, v11, Lr3/v;->D:Ld2/b;
    .line 350: iput-object v3, v1, Lr3/u;->v:Ld2/b;
    .line 352: iget v3, v11, Lr3/v;->E:I
    .line 354: iput v3, v1, Lr3/u;->w:I
    .line 356: iget v3, v11, Lr3/v;->F:I
    .line 358: iput v3, v1, Lr3/u;->x:I
    .line 360: iget v3, v11, Lr3/v;->G:I
    .line 362: iput v3, v1, Lr3/u;->y:I
    .line 364: iget v3, v11, Lr3/v;->H:I
    .line 366: iput v3, v1, Lr3/u;->z:I
    .line 368: iget v3, v11, Lr3/v;->I:I
    .line 370: iput v3, v1, Lr3/u;->A:I
    .line 372: iget-wide v3, v11, Lr3/v;->J:J
    .line 374: iput-wide v3, v1, Lr3/u;->B:J
    .line 376: iget-object v3, v11, Lr3/v;->K:Lu/d;
    .line 378: iput-object v3, v1, Lr3/u;->C:Lu/d;
    .line 380: sget-object v3, Lr3/m;->d:Lr3/m;
    .line 382: new-instance v4, Lk0/u;
    .line 384: invoke-direct {v4, v2, v3}, Lk0/u;-><init>(ILjava/lang/Object;)V
    .line 387: iput-object v4, v1, Lr3/u;->e:Lk0/u;
    .line 389: sget-object v3, Ld4/g;->x:Ljava/util/List;
    .line 391: const-string v4, "protocols"
    .line 393: invoke-static {v3, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 396: invoke-static {v3}, Lt2/p;->c2(Ljava/util/Collection;)Ljava/util/ArrayList;
    .line 399: move-result-object v3
    .line 400: sget-object v4, Lr3/w;->n:Lr3/w;
    .line 402: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z
    .line 405: move-result v5
    .line 406: if-nez v5, :cond_441
    .line 408: sget-object v5, Lr3/w;->k:Lr3/w;
    .line 410: invoke-virtual {v3, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z
    .line 413: move-result v5
    .line 414: if-eqz v5, :cond_417
    .line 416: goto :goto_441
    .line 417: new-instance v0, Ljava/lang/StringBuilder;
    .line 419: const-string v1, "protocols must contain h2_prior_knowledge or http/1.1: "
    .line 421: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 424: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 427: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 430: move-result-object v0
    .line 431: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 433: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 436: move-result-object v0
    .line 437: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 440: throw v1
    .line 441: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z
    .line 444: move-result v4
    .line 445: if-eqz v4, :cond_478
    .line 447: invoke-virtual {v3}, Ljava/util/ArrayList;->size()I
    .line 450: move-result v4
    .line 451: if-gt v4, v13, :cond_454
    .line 453: goto :goto_478
    .line 454: new-instance v0, Ljava/lang/StringBuilder;
    .line 456: const-string v1, "protocols containing h2_prior_knowledge cannot use other protocols: "
    .line 458: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 461: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 464: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 467: move-result-object v0
    .line 468: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 470: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 473: move-result-object v0
    .line 474: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 477: throw v1
    .line 478: sget-object v4, Lr3/w;->j:Lr3/w;
    .line 480: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z
    .line 483: move-result v4
    .line 484: xor-int/2addr v4, v13
    .line 485: if-eqz v4, :cond_884
    .line 487: invoke-virtual {v3, v15}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z
    .line 490: move-result v4
    .line 491: xor-int/2addr v4, v13
    .line 492: if-eqz v4, :cond_872
    .line 494: sget-object v4, Lr3/w;->l:Lr3/w;
    .line 496: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    .line 499: iget-object v4, v1, Lr3/u;->s:Ljava/util/List;
    .line 501: invoke-static {v3, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 504: move-result v4
    .line 505: if-nez v4, :cond_509
    .line 507: iput-object v15, v1, Lr3/u;->C:Lu/d;
    .line 509: invoke-static {v3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;
    .line 512: move-result-object v3
    .line 513: const-string v4, "unmodifiableList(protocolsCopy)"
    .line 515: invoke-static {v3, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 518: iput-object v3, v1, Lr3/u;->s:Ljava/util/List;
    .line 520: new-instance v3, Lr3/v;
    .line 522: invoke-direct {v3, v1}, Lr3/v;-><init>(Lr3/u;)V
    .line 525: iget-object v1, v0, Ld4/g;->a:La1/b;
    .line 527: invoke-virtual {v1}, La1/b;->c()Lr3/x;
    .line 530: move-result-object v1
    .line 531: const-string v4, "Upgrade"
    .line 533: const-string v5, "websocket"
    .line 535: invoke-virtual {v1, v4, v5}, Lr3/x;->b(Ljava/lang/String;Ljava/lang/String;)V
    .line 538: const-string v4, "Connection"
    .line 540: const-string v5, "Upgrade"
    .line 542: invoke-virtual {v1, v4, v5}, Lr3/x;->b(Ljava/lang/String;Ljava/lang/String;)V
    .line 545: const-string v4, "Sec-WebSocket-Key"
    .line 547: iget-object v5, v0, Ld4/g;->g:Ljava/lang/String;
    .line 549: invoke-virtual {v1, v4, v5}, Lr3/x;->b(Ljava/lang/String;Ljava/lang/String;)V
    .line 552: const-string v4, "Sec-WebSocket-Version"
    .line 554: const-string v5, "13"
    .line 556: invoke-virtual {v1, v4, v5}, Lr3/x;->b(Ljava/lang/String;Ljava/lang/String;)V
    .line 559: const-string v4, "Sec-WebSocket-Extensions"
    .line 561: const-string v5, "permessage-deflate"
    .line 563: invoke-virtual {v1, v4, v5}, Lr3/x;->b(Ljava/lang/String;Ljava/lang/String;)V
    .line 566: invoke-virtual {v1}, Lr3/x;->a()La1/b;
    .line 569: move-result-object v1
    .line 570: new-instance v4, Lv3/j;
    .line 572: invoke-direct {v4, v3, v1, v13}, Lv3/j;-><init>(Lr3/v;La1/b;Z)V
    .line 575: iput-object v4, v0, Ld4/g;->h:Lv3/j;
    .line 577: new-instance v3, Ld4/f;
    .line 579: invoke-direct {v3, v0, v1}, Ld4/f;-><init>(Ld4/g;La1/b;)V
    .line 582: iget-object v0, v4, Lv3/j;->o:Ljava/util/concurrent/atomic/AtomicBoolean;
    .line 584: invoke-virtual {v0, v7, v13}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z
    .line 587: move-result v0
    .line 588: if-eqz v0, :cond_860
    .line 590: sget-object v0, Lz3/m;->a:Lz3/m;
    .line 592: sget-object v0, Lz3/m;->a:Lz3/m;
    .line 594: invoke-virtual {v0}, Lz3/m;->g()Ljava/lang/Object;
    .line 597: move-result-object v0
    .line 598: iput-object v0, v4, Lv3/j;->p:Ljava/lang/Object;
    .line 600: iget-object v0, v4, Lv3/j;->m:Lr3/m;
    .line 602: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 605: iget-object v0, v4, Lv3/j;->i:Lr3/v;
    .line 607: iget-object v1, v0, Lr3/v;->i:Lr3/k;
    .line 609: new-instance v0, Lv3/g;
    .line 611: invoke-direct {v0, v4, v3}, Lv3/g;-><init>(Lv3/j;Ld4/f;)V
    .line 614: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 617: monitor-enter v1
    .line 618: iget-object v3, v1, Lr3/k;->b:Ljava/util/ArrayDeque;
    .line 620: invoke-virtual {v3, v0}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z
    .line 623: iget-boolean v3, v4, Lv3/j;->k:Z
    .line 625: if-nez v3, :cond_712
    .line 627: iget-object v3, v4, Lv3/j;->j:La1/b;
    .line 629: iget-object v3, v3, La1/b;->b:Ljava/lang/Object;
    .line 631: check-cast v3, Lr3/s;
    .line 633: iget-object v3, v3, Lr3/s;->d:Ljava/lang/String;
    .line 635: iget-object v4, v1, Lr3/k;->c:Ljava/util/ArrayDeque;
    .line 637: invoke-virtual {v4}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;
    .line 640: move-result-object v4
    .line 641: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 644: move-result v5
    .line 645: if-eqz v5, :cond_671
    .line 647: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 650: move-result-object v5
    .line 651: check-cast v5, Lv3/g;
    .line 653: iget-object v6, v5, Lv3/g;->k:Lv3/j;
    .line 655: iget-object v6, v6, Lv3/j;->j:La1/b;
    .line 657: iget-object v6, v6, La1/b;->b:Ljava/lang/Object;
    .line 659: check-cast v6, Lr3/s;
    .line 661: iget-object v6, v6, Lr3/s;->d:Ljava/lang/String;
    .line 663: invoke-static {v6, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 666: move-result v6
    .line 667: if-eqz v6, :cond_641
    .line 669: move-object v15, v5
    .line 670: goto :goto_706
    .line 671: iget-object v4, v1, Lr3/k;->b:Ljava/util/ArrayDeque;
    .line 673: invoke-virtual {v4}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;
    .line 676: move-result-object v4
    .line 677: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 680: move-result v5
    .line 681: if-eqz v5, :cond_706
    .line 683: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 686: move-result-object v5
    .line 687: check-cast v5, Lv3/g;
    .line 689: iget-object v6, v5, Lv3/g;->k:Lv3/j;
    .line 691: iget-object v6, v6, Lv3/j;->j:La1/b;
    .line 693: iget-object v6, v6, La1/b;->b:Ljava/lang/Object;
    .line 695: check-cast v6, Lr3/s;
    .line 697: iget-object v6, v6, Lr3/s;->d:Ljava/lang/String;
    .line 699: invoke-static {v6, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 702: move-result v6
    .line 703: if-eqz v6, :cond_677
    .line 705: goto :goto_669
    .line 706: if-eqz v15, :cond_712
    .line 708: iget-object v3, v15, Lv3/g;->j:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 710: iput-object v3, v0, Lv3/g;->j:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 712: monitor-exit v1
    .line 713: invoke-virtual {v1}, Lr3/k;->b()V
    .line 716: int-to-long v0, v2
    .line 717: add-long/2addr v9, v0
    .line 718: sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;
    .line 720: invoke-virtual {v12, v9, v10, v0}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z
    .line 723: goto :goto_728
    .line 724: move-exception v0
    .line 725: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 728: invoke-virtual {v14}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;
    .line 731: move-result-object v0
    .line 732: check-cast v0, Lcom/titanchess/accessibility/w;
    .line 734: if-nez v0, :cond_751
    .line 736: new-instance v0, Lcom/titanchess/accessibility/w;
    .line 738: const-string v10, "none"
    .line 740: const-string v13, "timeout · cek koneksi"
    .line 742: const/4 v11, 0
    .line 743: const/4 v12, 0
    .line 744: const/4 v14, 0
    .line 745: const-wide/16 v15, 0
    .line 747: move-object v9, v0
    .line 748: invoke-direct/range {v9 .. v16}, Lcom/titanchess/accessibility/w;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .line 751: invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 754: move-result-object v1
    .line 755: iget-object v2, v0, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 757: const-string v3, "none"
    .line 759: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 762: move-result v2
    .line 763: if-nez v2, :cond_846
    .line 765: const-string v2, "lic_status"
    .line 767: iget-object v3, v0, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 769: invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 772: move-result-object v2
    .line 773: const-string v3, "lic_expires"
    .line 775: iget-object v4, v0, Lcom/titanchess/accessibility/w;->b:Ljava/lang/String;
    .line 777: invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 780: move-result-object v2
    .line 781: const-string v3, "lic_products"
    .line 783: iget-object v4, v0, Lcom/titanchess/accessibility/w;->c:Ljava/lang/String;
    .line 785: invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 788: move-result-object v2
    .line 789: const-string v3, "lic_msg"
    .line 791: iget-object v4, v0, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 793: invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 796: move-result-object v2
    .line 797: const-string v3, "lic_checked"
    .line 799: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    .line 802: move-result-wide v4
    .line 803: invoke-interface {v2, v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    .line 806: iget-object v2, v0, Lcom/titanchess/accessibility/w;->a:Ljava/lang/String;
    .line 808: const-string v3, "active"
    .line 810: invoke-static {v2, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 813: move-result v2
    .line 814: if-eqz v2, :cond_834
    .line 816: iget-object v2, v0, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 818: if-eqz v2, :cond_834
    .line 820: const-string v3, "lic_token"
    .line 822: invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 825: move-result-object v2
    .line 826: const-string v3, "lic_token_exp"
    .line 828: iget-wide v4, v0, Lcom/titanchess/accessibility/w;->f:J
    .line 830: invoke-interface {v2, v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    .line 833: goto :goto_853
    .line 834: const-string v2, "lic_token"
    .line 836: invoke-interface {v1, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 839: move-result-object v2
    .line 840: const-string v3, "lic_token_exp"
    .line 842: invoke-interface {v2, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 845: goto :goto_853
    .line 846: const-string v2, "lic_msg"
    .line 848: iget-object v3, v0, Lcom/titanchess/accessibility/w;->d:Ljava/lang/String;
    .line 850: invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    .line 853: invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 856: return-object v0
    .line 857: move-exception v0
    .line 858: monitor-exit v1
    .line 859: throw v0
    .line 860: const-string v0, "Already Executed"
    .line 862: new-instance v1, Ljava/lang/IllegalStateException;
    .line 864: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 867: move-result-object v0
    .line 868: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 871: throw v1
    .line 872: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 874: const-string v1, "protocols must not contain null"
    .line 876: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 879: move-result-object v1
    .line 880: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 883: throw v0
    .line 884: new-instance v0, Ljava/lang/StringBuilder;
    .line 886: const-string v1, "protocols must not contain http/1.0: "
    .line 888: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 891: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 894: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 897: move-result-object v0
    .line 898: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 900: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 903: move-result-object v0
    .line 904: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 907: throw v1
.end method

# virtual methods
.method public b([B)[B
    .registers 9

    .line 0: const/16 v0, 32
    .line 2: new-array v0, v0, [B
    .line 4: new-instance v1, Ljava/security/SecureRandom;
    .line 6: invoke-direct {v1}, Ljava/security/SecureRandom;-><init>()V
    .line 9: invoke-virtual {v1, v0}, Ljava/security/SecureRandom;->nextBytes([B)V
    .line 12: invoke-static {}, Lcom/titanchess/accessibility/e;->h()Ljavax/crypto/SecretKey;
    .line 15: move-result-object v1
    .line 16: const/4 v2, 1
    .line 17: const/4 v3, 0
    .line 18: invoke-static {v2, v1, v3}, Lcom/titanchess/accessibility/e;->d(ILjavax/crypto/SecretKey;[B)Ljavax/crypto/Cipher;
    .line 21: move-result-object v1
    .line 22: invoke-virtual {v1, v0}, Ljavax/crypto/Cipher;->doFinal([B)[B
    .line 25: move-result-object v4
    .line 26: new-instance v5, Ljavax/crypto/spec/SecretKeySpec;
    .line 28: const-string v6, "AES"
    .line 30: invoke-direct {v5, v0, v6}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V
    .line 33: invoke-static {v2, v5, v3}, Lcom/titanchess/accessibility/e;->d(ILjavax/crypto/SecretKey;[B)Ljavax/crypto/Cipher;
    .line 36: move-result-object v0
    .line 37: invoke-virtual {v0, v8}, Ljavax/crypto/Cipher;->doFinal([B)[B
    .line 40: move-result-object v8
    .line 41: invoke-virtual {v1}, Ljavax/crypto/Cipher;->getIV()[B
    .line 44: move-result-object v3
    .line 45: array-length v3, v3
    .line 46: const/16 v5, 12
    .line 48: if-ne v3, v5, :cond_121
    .line 50: invoke-virtual {v0}, Ljavax/crypto/Cipher;->getIV()[B
    .line 53: move-result-object v3
    .line 54: array-length v3, v3
    .line 55: if-ne v3, v5, :cond_121
    .line 57: array-length v3, v4
    .line 58: const/16 v5, 48
    .line 60: if-ne v3, v5, :cond_104
    .line 62: new-array v2, v2, [B
    .line 64: const/4 v3, 0
    .line 65: const/4 v5, 2
    .line 66: aput-byte v5, v2, v3
    .line 68: invoke-virtual {v1}, Ljavax/crypto/Cipher;->getIV()[B
    .line 71: move-result-object v1
    .line 72: const-string v3, "getIV(...)"
    .line 74: invoke-static {v1, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 77: invoke-static {v2, v1}, Lt2/k;->X0([B[B)[B
    .line 80: move-result-object v1
    .line 81: invoke-static {v1, v4}, Lt2/k;->X0([B[B)[B
    .line 84: move-result-object v1
    .line 85: invoke-virtual {v0}, Ljavax/crypto/Cipher;->getIV()[B
    .line 88: move-result-object v0
    .line 89: invoke-static {v0, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 92: invoke-static {v1, v0}, Lt2/k;->X0([B[B)[B
    .line 95: move-result-object v0
    .line 96: invoke-static {v8}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 99: invoke-static {v0, v8}, Lt2/k;->X0([B[B)[B
    .line 102: move-result-object v8
    .line 103: return-object v8
    .line 104: array-length v8, v4
    .line 105: const-string v0, "unexpected wrapped-DEK len "
    .line 107: invoke-static {v0, v8}, Lai/onnxruntime/b;->f(Ljava/lang/String;I)Ljava/lang/String;
    .line 110: move-result-object v8
    .line 111: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 113: invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 116: move-result-object v8
    .line 117: invoke-direct {v0, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 120: throw v0
    .line 121: new-instance v8, Ljava/lang/IllegalArgumentException;
    .line 123: const-string v0, "unexpected GCM IV len"
    .line 125: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 128: move-result-object v0
    .line 129: invoke-direct {v8, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 132: throw v8
.end method

# virtual methods
.method public declared-synchronized i(Landroid/content/Context;)V
    .registers 14

    .line 0: monitor-enter v12
    .line 1: const-string v0, "context"
    .line 3: invoke-static {v13, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 6: sget-object v0, Lcom/titanchess/accessibility/e;->d:[J
    .line 8: if-eqz v0, :cond_12
    .line 10: monitor-exit v12
    .line 11: return-void
    .line 12: invoke-virtual {v13}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 15: move-result-object v13
    .line 16: const-string v0, "book.bin"
    .line 18: invoke-virtual {v13, v0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 21: move-result-object v13
    .line 22: invoke-static {v13}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 25: invoke-static {v13}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 28: move-result-object v0
    .line 29: const/4 v1, 0
    .line 30: invoke-static {v13, v1}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 33: array-length v13, v0
    .line 34: div-int/lit8 v13, v13, 16
    .line 36: new-array v1, v13, [J
    .line 38: const/4 v2, 0
    .line 39: move v3, v2
    .line 40: move v4, v3
    .line 41: if-ge v3, v13, :cond_72
    .line 43: const-wide/16 v5, 0
    .line 45: move v7, v2
    .line 46: const/16 v8, 8
    .line 48: if-ge v7, v8, :cond_65
    .line 50: shl-long/2addr v5, v8
    .line 51: add-int v8, v4, v7
    .line 53: aget-byte v8, v0, v8
    .line 55: int-to-long v8, v8
    .line 56: const-wide/16 v10, 255
    .line 58: and-long/2addr v8, v10
    .line 59: or-long/2addr v5, v8
    .line 60: add-int/lit8 v7, v7, 1
    .line 62: goto :goto_46
    .line 63: move-exception v13
    .line 64: goto :goto_84
    .line 65: aput-wide v5, v1, v3
    .line 67: add-int/lit8 v4, v4, 16
    .line 69: add-int/lit8 v3, v3, 1
    .line 71: goto :goto_41
    .line 72: sput-object v1, Lcom/titanchess/accessibility/e;->d:[J
    .line 74: sget-object v13, Ls2/k;->a:Ls2/k;
    .line 76: goto :goto_88
    .line 77: move-exception v0
    .line 78: throw v0
    .line 79: move-exception v1
    .line 80: invoke-static {v13, v0}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 83: throw v1
    .line 84: invoke-static {v13}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 87: move-result-object v13
    .line 88: invoke-static {v13}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 91: move-result-object v13
    .line 92: if-eqz v13, :cond_104
    .line 94: const-string v0, "TitanEval"
    .line 96: const-string v1, "book load fail"
    .line 98: invoke-static {v0, v1, v13}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 101: goto :goto_104
    .line 102: move-exception v13
    .line 103: goto :goto_106
    .line 104: monitor-exit v12
    .line 105: return-void
    .line 106: monitor-exit v12
    .line 107: throw v13
.end method

.class public final Lcom/titanchess/accessibility/o1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:I
.field public final c:F

# direct methods
.method public constructor <init>(Ljava/lang/String;IF)V
    .registers 5

    .line 0: const-string v0, "uci"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 10: iput v3, v1, Lcom/titanchess/accessibility/o1;->b:I
    .line 12: iput v4, v1, Lcom/titanchess/accessibility/o1;->c:F
    .line 14: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/o1;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/o1;
    .line 12: iget-object v1, v5, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 14: iget-object v3, v4, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lcom/titanchess/accessibility/o1;->b:I
    .line 25: iget v3, v5, Lcom/titanchess/accessibility/o1;->b:I
    .line 27: if-eq v1, v3, :cond_30
    .line 29: return v2
    .line 30: iget v1, v4, Lcom/titanchess/accessibility/o1;->c:F
    .line 32: iget v5, v5, Lcom/titanchess/accessibility/o1;->c:F
    .line 34: invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I
    .line 37: move-result v5
    .line 38: if-eqz v5, :cond_41
    .line 40: return v2
    .line 41: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lcom/titanchess/accessibility/o1;->b:I
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 14: move-result v0
    .line 15: iget v1, v3, Lcom/titanchess/accessibility/o1;->c:F
    .line 17: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 20: move-result v1
    .line 21: add-int/2addr v1, v0
    .line 22: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Ranked(uci="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/o1;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", rank="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lcom/titanchess/accessibility/o1;->b:I
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", prob="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v2, Lcom/titanchess/accessibility/o1;->c:F
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ")"
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 40: move-result-object v0
    .line 41: return-object v0
.end method

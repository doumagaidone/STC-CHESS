.class public final Lcom/titanchess/accessibility/n1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:J
.field public final c:J
.field public final d:I
.field public final e:Ljava/lang/String;
.field public final f:Lorg/json/JSONObject;
.field public final g:I
.field public final h:Lorg/json/JSONObject;
.field public final i:Lorg/json/JSONObject;
.field public final j:Lorg/json/JSONObject;
.field public final k:Ljava/util/HashMap;
.field public final l:Lai/onnxruntime/OrtEnvironment;
.field public final m:Lcom/titanchess/accessibility/m1;
.field public n:Lai/onnxruntime/OrtSession;
.field public final o:Ljava/util/ArrayList;
.field public final p:Ljava/util/ArrayList;
.field public q:[J
.field public r:Ljava/util/Map;

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 9

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v8, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    .line 8: const/16 v0, 12
    .line 10: iput v0, v7, Lcom/titanchess/accessibility/n1;->a:I
    .line 12: const-wide/16 v0, 2
    .line 14: iput-wide v0, v7, Lcom/titanchess/accessibility/n1;->b:J
    .line 16: const-wide/16 v0, 96
    .line 18: iput-wide v0, v7, Lcom/titanchess/accessibility/n1;->c:J
    .line 20: const/4 v0, 4
    .line 21: iput v0, v7, Lcom/titanchess/accessibility/n1;->d:I
    .line 23: const-string v0, "TitanBrain"
    .line 25: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->e:Ljava/lang/String;
    .line 27: invoke-virtual {v8}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 30: move-result-object v0
    .line 31: const-string v1, "meta_kv.json"
    .line 33: invoke-virtual {v0, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 36: move-result-object v0
    .line 37: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 40: invoke-static {v0}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 43: move-result-object v1
    .line 44: const/4 v2, 0
    .line 45: invoke-static {v0, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 48: new-instance v0, Ljava/lang/String;
    .line 50: sget-object v3, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 52: invoke-direct {v0, v1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 55: new-instance v1, Lorg/json/JSONObject;
    .line 57: invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    .line 60: invoke-virtual {v8}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 63: move-result-object v0
    .line 64: const-string v4, "uci_vocab.json"
    .line 66: invoke-virtual {v0, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 69: move-result-object v0
    .line 70: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 73: invoke-static {v0}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 76: move-result-object v4
    .line 77: invoke-static {v0, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 80: new-instance v0, Ljava/lang/String;
    .line 82: invoke-direct {v0, v4, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 85: new-instance v2, Lorg/json/JSONObject;
    .line 87: invoke-direct {v2, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    .line 90: iput-object v2, v7, Lcom/titanchess/accessibility/n1;->f:Lorg/json/JSONObject;
    .line 92: const-string v0, "vocab_size"
    .line 94: invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I
    .line 97: move-result v0
    .line 98: iput v0, v7, Lcom/titanchess/accessibility/n1;->g:I
    .line 100: const-string v0, "control_ids"
    .line 102: invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 105: move-result-object v0
    .line 106: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->h:Lorg/json/JSONObject;
    .line 108: const-string v0, "elo_white_ids"
    .line 110: invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 113: move-result-object v0
    .line 114: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->i:Lorg/json/JSONObject;
    .line 116: const-string v0, "elo_black_ids"
    .line 118: invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .line 121: move-result-object v0
    .line 122: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->j:Lorg/json/JSONObject;
    .line 124: new-instance v0, Ljava/util/HashMap;
    .line 126: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 129: invoke-virtual {v2}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;
    .line 132: move-result-object v1
    .line 133: const-string v2, "keys(...)"
    .line 135: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 138: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 141: move-result v2
    .line 142: if-eqz v2, :cond_171
    .line 144: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 147: move-result-object v2
    .line 148: check-cast v2, Ljava/lang/String;
    .line 150: iget-object v3, v7, Lcom/titanchess/accessibility/n1;->f:Lorg/json/JSONObject;
    .line 152: invoke-virtual {v3, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 155: move-result-object v3
    .line 156: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 159: invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    .line 162: move-result v2
    .line 163: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 166: move-result-object v2
    .line 167: invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 170: goto :goto_138
    .line 171: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->k:Ljava/util/HashMap;
    .line 173: invoke-static {}, Lai/onnxruntime/OrtEnvironment;->getEnvironment()Lai/onnxruntime/OrtEnvironment;
    .line 176: move-result-object v0
    .line 177: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 179: new-instance v0, Lcom/titanchess/accessibility/m1;
    .line 181: invoke-direct {v0, v8}, Lcom/titanchess/accessibility/m1;-><init>(Landroid/content/Context;)V
    .line 184: iput-object v0, v7, Lcom/titanchess/accessibility/n1;->m:Lcom/titanchess/accessibility/m1;
    .line 186: iget v8, v7, Lcom/titanchess/accessibility/n1;->a:I
    .line 188: const/4 v0, 0
    .line 189: invoke-static {v0, v8}, Ld2/b;->r1(II)Lj3/d;
    .line 192: move-result-object v8
    .line 193: new-instance v1, Ljava/util/ArrayList;
    .line 195: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 198: invoke-virtual {v8}, Lj3/b;->b()Lj3/c;
    .line 201: move-result-object v8
    .line 202: iget-boolean v2, v8, Lj3/c;->k:Z
    .line 204: const-string v3, ".value"
    .line 206: const-string v4, ".key"
    .line 208: if-eqz v2, :cond_236
    .line 210: invoke-virtual {v8}, Lj3/c;->c()I
    .line 213: move-result v2
    .line 214: const-string v5, "past_key_values."
    .line 216: invoke-static {v5, v2, v4}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 219: move-result-object v4
    .line 220: invoke-static {v5, v2, v3}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 223: move-result-object v2
    .line 224: filled-new-array {v4, v2}, [Ljava/lang/String;
    .line 227: move-result-object v2
    .line 228: invoke-static {v2}, Ld2/b;->I0([Ljava/lang/Object;)Ljava/util/List;
    .line 231: move-result-object v2
    .line 232: invoke-static {v2, v1}, Lt2/m;->G1(Ljava/lang/Iterable;Ljava/util/Collection;)V
    .line 235: goto :goto_202
    .line 236: iput-object v1, v7, Lcom/titanchess/accessibility/n1;->o:Ljava/util/ArrayList;
    .line 238: iget v8, v7, Lcom/titanchess/accessibility/n1;->a:I
    .line 240: invoke-static {v0, v8}, Ld2/b;->r1(II)Lj3/d;
    .line 243: move-result-object v8
    .line 244: new-instance v1, Ljava/util/ArrayList;
    .line 246: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 249: invoke-virtual {v8}, Lj3/b;->b()Lj3/c;
    .line 252: move-result-object v8
    .line 253: iget-boolean v2, v8, Lj3/c;->k:Z
    .line 255: if-eqz v2, :cond_283
    .line 257: invoke-virtual {v8}, Lj3/c;->c()I
    .line 260: move-result v2
    .line 261: const-string v5, "present."
    .line 263: invoke-static {v5, v2, v4}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 266: move-result-object v6
    .line 267: invoke-static {v5, v2, v3}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 270: move-result-object v2
    .line 271: filled-new-array {v6, v2}, [Ljava/lang/String;
    .line 274: move-result-object v2
    .line 275: invoke-static {v2}, Ld2/b;->I0([Ljava/lang/Object;)Ljava/util/List;
    .line 278: move-result-object v2
    .line 279: invoke-static {v2, v1}, Lt2/m;->G1(Ljava/lang/Iterable;Ljava/util/Collection;)V
    .line 282: goto :goto_253
    .line 283: iput-object v1, v7, Lcom/titanchess/accessibility/n1;->p:Ljava/util/ArrayList;
    .line 285: new-array v8, v0, [J
    .line 287: iput-object v8, v7, Lcom/titanchess/accessibility/n1;->q:[J
    .line 289: sget-object v8, Lt2/s;->i:Lt2/s;
    .line 291: iput-object v8, v7, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 293: return-void
    .line 294: move-exception v8
    .line 295: throw v8
    .line 296: move-exception v1
    .line 297: invoke-static {v0, v8}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 300: throw v1
    .line 301: move-exception v8
    .line 302: throw v8
    .line 303: move-exception v1
    .line 304: invoke-static {v0, v8}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 307: throw v1
.end method

# direct methods
.method public static b(Ljava/util/Map;)V
    .registers 2

    .line 0: invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 3: move-result-object v1
    .line 4: check-cast v1, Ljava/lang/Iterable;
    .line 6: invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 9: move-result-object v1
    .line 10: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 13: move-result v0
    .line 14: if-eqz v0, :cond_31
    .line 16: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 19: move-result-object v0
    .line 20: check-cast v0, Lai/onnxruntime/OnnxTensor;
    .line 22: invoke-virtual {v0}, Lai/onnxruntime/OnnxTensor;->close()V
    .line 25: goto :goto_10
    .line 26: move-exception v0
    .line 27: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 30: goto :goto_10
    .line 31: return-void
.end method

# virtual methods
.method public final a(ILjava/util/List;)[J
    .registers 10

    .line 0: int-to-double v0, v8
    .line 1: const-wide/high16 v2, 0x4059
    .line 3: div-double/2addr v0, v2
    .line 4: invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J
    .line 7: move-result-wide v0
    .line 8: const/16 v8, 100
    .line 10: int-to-long v2, v8
    .line 11: mul-long/2addr v0, v2
    .line 12: const-wide/16 v2, 3000
    .line 14: invoke-static {v0, v1, v2, v3}, Ld2/b;->H(JJ)J
    .line 17: move-result-wide v0
    .line 18: invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;
    .line 21: move-result-object v8
    .line 22: const/4 v0, 4
    .line 23: new-array v1, v0, [J
    .line 25: iget-object v2, v7, Lcom/titanchess/accessibility/n1;->h:Lorg/json/JSONObject;
    .line 27: const-string v3, "<BOG>"
    .line 29: invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I
    .line 32: move-result v3
    .line 33: int-to-long v3, v3
    .line 34: const/4 v5, 0
    .line 35: aput-wide v3, v1, v5
    .line 37: iget-object v3, v7, Lcom/titanchess/accessibility/n1;->i:Lorg/json/JSONObject;
    .line 39: invoke-virtual {v3, v8}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I
    .line 42: move-result v3
    .line 43: int-to-long v3, v3
    .line 44: const/4 v6, 1
    .line 45: aput-wide v3, v1, v6
    .line 47: iget-object v3, v7, Lcom/titanchess/accessibility/n1;->j:Lorg/json/JSONObject;
    .line 49: invoke-virtual {v3, v8}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I
    .line 52: move-result v8
    .line 53: int-to-long v3, v8
    .line 54: const/4 v8, 2
    .line 55: aput-wide v3, v1, v8
    .line 57: const-string v8, "<DRAW>"
    .line 59: invoke-virtual {v2, v8}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I
    .line 62: move-result v8
    .line 63: int-to-long v2, v8
    .line 64: const/4 v8, 3
    .line 65: aput-wide v2, v1, v8
    .line 67: new-instance v8, Ljava/util/ArrayList;
    .line 69: invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V
    .line 72: invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 75: move-result-object v9
    .line 76: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 79: move-result v2
    .line 80: if-eqz v2, :cond_115
    .line 82: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 85: move-result-object v2
    .line 86: check-cast v2, Ljava/lang/String;
    .line 88: iget-object v3, v7, Lcom/titanchess/accessibility/n1;->k:Ljava/util/HashMap;
    .line 90: invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 93: move-result-object v2
    .line 94: check-cast v2, Ljava/lang/Integer;
    .line 96: if-eqz v2, :cond_108
    .line 98: invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I
    .line 101: move-result v2
    .line 102: int-to-long v2, v2
    .line 103: invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 106: move-result-object v2
    .line 107: goto :goto_109
    .line 108: const/4 v2, 0
    .line 109: if-eqz v2, :cond_76
    .line 111: invoke-virtual {v8, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 114: goto :goto_76
    .line 115: invoke-static {v8}, Lt2/p;->b2(Ljava/util/ArrayList;)[J
    .line 118: move-result-object v8
    .line 119: array-length v9, v8
    .line 120: add-int v2, v0, v9
    .line 122: invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([JI)[J
    .line 125: move-result-object v1
    .line 126: invoke-static {v8, v5, v1, v0, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    .line 129: const-string v8, "result"
    .line 131: invoke-static {v1, v8}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 134: return-object v1
.end method

# virtual methods
.method public final c(I[F)Ljava/util/ArrayList;
    .registers 15

    .line 0: array-length v0, v14
    .line 1: iget v1, v12, Lcom/titanchess/accessibility/n1;->g:I
    .line 3: sub-int/2addr v0, v1
    .line 4: array-length v1, v14
    .line 5: array-length v2, v14
    .line 6: invoke-static {v1, v2}, Ld2/c;->E(II)V
    .line 9: invoke-static {v14, v0, v1}, Ljava/util/Arrays;->copyOfRange([FII)[F
    .line 12: move-result-object v14
    .line 13: const-string v0, "copyOfRange(this, fromIndex, toIndex)"
    .line 15: invoke-static {v14, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 18: array-length v0, v14
    .line 19: const/4 v1, 0
    .line 20: const/high16 v2, 0xff80
    .line 22: move v3, v1
    .line 23: if-ge v3, v0, :cond_35
    .line 25: aget v4, v14, v3
    .line 27: cmpl-float v5, v4, v2
    .line 29: if-lez v5, :cond_32
    .line 31: move v2, v4
    .line 32: add-int/lit8 v3, v3, 1
    .line 34: goto :goto_23
    .line 35: array-length v0, v14
    .line 36: const-wide/16 v3, 0
    .line 38: move v5, v1
    .line 39: if-ge v5, v0, :cond_53
    .line 41: aget v6, v14, v5
    .line 43: sub-float/2addr v6, v2
    .line 44: float-to-double v6, v6
    .line 45: invoke-static {v6, v7}, Ljava/lang/Math;->exp(D)D
    .line 48: move-result-wide v6
    .line 49: add-double/2addr v3, v6
    .line 50: add-int/lit8 v5, v5, 1
    .line 52: goto :goto_39
    .line 53: new-array v0, v13, [I
    .line 55: move v5, v1
    .line 56: const/4 v6, -1
    .line 57: if-ge v5, v13, :cond_64
    .line 59: aput v6, v0, v5
    .line 61: add-int/lit8 v5, v5, 1
    .line 63: goto :goto_56
    .line 64: array-length v5, v14
    .line 65: move v7, v1
    .line 66: if-ge v7, v5, :cond_106
    .line 68: aget v8, v14, v7
    .line 70: add-int/lit8 v9, v13, -1
    .line 72: aget v10, v0, v9
    .line 74: if-eq v10, v6, :cond_82
    .line 76: aget v10, v14, v10
    .line 78: cmpg-float v10, v8, v10
    .line 80: if-lez v10, :cond_103
    .line 82: if-lez v9, :cond_101
    .line 84: add-int/lit8 v10, v9, -1
    .line 86: aget v10, v0, v10
    .line 88: if-eq v10, v6, :cond_96
    .line 90: aget v11, v14, v10
    .line 92: cmpl-float v11, v8, v11
    .line 94: if-lez v11, :cond_101
    .line 96: aput v10, v0, v9
    .line 98: add-int/lit8 v9, v9, -1
    .line 100: goto :goto_82
    .line 101: aput v7, v0, v9
    .line 103: add-int/lit8 v7, v7, 1
    .line 105: goto :goto_66
    .line 106: new-instance v5, Ljava/util/ArrayList;
    .line 108: invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V
    .line 111: if-ge v1, v13, :cond_127
    .line 113: aget v6, v0, v1
    .line 115: if-ltz v6, :cond_124
    .line 117: invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 120: move-result-object v6
    .line 121: invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 124: add-int/lit8 v1, v1, 1
    .line 126: goto :goto_111
    .line 127: new-instance v13, Ljava/util/ArrayList;
    .line 129: invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V
    .line 132: invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 135: move-result-object v0
    .line 136: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 139: move-result v1
    .line 140: if-eqz v1, :cond_199
    .line 142: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 145: move-result-object v1
    .line 146: check-cast v1, Ljava/lang/Number;
    .line 148: invoke-virtual {v1}, Ljava/lang/Number;->intValue()I
    .line 151: move-result v1
    .line 152: iget-object v5, v12, Lcom/titanchess/accessibility/n1;->f:Lorg/json/JSONObject;
    .line 154: invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 157: move-result-object v6
    .line 158: invoke-virtual {v5, v6}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    .line 161: move-result v6
    .line 162: if-eqz v6, :cond_192
    .line 164: invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 167: move-result-object v6
    .line 168: invoke-virtual {v5, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 171: move-result-object v5
    .line 172: aget v1, v14, v1
    .line 174: sub-float/2addr v1, v2
    .line 175: float-to-double v6, v1
    .line 176: invoke-static {v6, v7}, Ljava/lang/Math;->exp(D)D
    .line 179: move-result-wide v6
    .line 180: div-double/2addr v6, v3
    .line 181: double-to-float v1, v6
    .line 182: invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    .line 185: move-result-object v1
    .line 186: new-instance v6, Ls2/e;
    .line 188: invoke-direct {v6, v5, v1}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 191: goto :goto_193
    .line 192: const/4 v6, 0
    .line 193: if-eqz v6, :cond_136
    .line 195: invoke-virtual {v13, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 198: goto :goto_136
    .line 199: return-object v13
.end method

# virtual methods
.method public final d()Ljava/util/LinkedHashMap;
    .registers 9

    .line 0: iget-object v0, v8, Lcom/titanchess/accessibility/n1;->o:Ljava/util/ArrayList;
    .line 2: new-instance v1, Ljava/util/LinkedHashMap;
    .line 4: invoke-static {v0}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 7: move-result v2
    .line 8: invoke-static {v2}, Ld2/c;->f0(I)I
    .line 11: move-result v2
    .line 12: const/16 v3, 16
    .line 14: if-ge v2, v3, :cond_17
    .line 16: move v2, v3
    .line 17: invoke-direct {v1, v2}, Ljava/util/LinkedHashMap;-><init>(I)V
    .line 20: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 23: move-result-object v0
    .line 24: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 27: move-result v2
    .line 28: if-eqz v2, :cond_74
    .line 30: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 33: move-result-object v2
    .line 34: move-object v3, v2
    .line 35: check-cast v3, Ljava/lang/String;
    .line 37: const/4 v3, 0
    .line 38: invoke-static {v3}, Ljava/nio/FloatBuffer;->allocate(I)Ljava/nio/FloatBuffer;
    .line 41: move-result-object v4
    .line 42: const/4 v5, 4
    .line 43: new-array v5, v5, [J
    .line 45: const-wide/16 v6, 1
    .line 47: aput-wide v6, v5, v3
    .line 49: const/4 v3, 1
    .line 50: iget-wide v6, v8, Lcom/titanchess/accessibility/n1;->b:J
    .line 52: aput-wide v6, v5, v3
    .line 54: const/4 v3, 2
    .line 55: const-wide/16 v6, 0
    .line 57: aput-wide v6, v5, v3
    .line 59: const/4 v3, 3
    .line 60: iget-wide v6, v8, Lcom/titanchess/accessibility/n1;->c:J
    .line 62: aput-wide v6, v5, v3
    .line 64: iget-object v3, v8, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 66: invoke-static {v3, v4, v5}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/FloatBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 69: move-result-object v3
    .line 70: invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 73: goto :goto_24
    .line 74: return-object v1
.end method

# virtual methods
.method public final e([JI)Ljava/util/ArrayList;
    .registers 16

    .line 0: invoke-virtual {v13}, Lcom/titanchess/accessibility/n1;->d()Ljava/util/LinkedHashMap;
    .line 3: move-result-object v0
    .line 4: new-instance v1, Ljava/util/HashMap;
    .line 6: invoke-direct {v1, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V
    .line 9: invoke-static {v14}, Ljava/nio/LongBuffer;->wrap([J)Ljava/nio/LongBuffer;
    .line 12: move-result-object v2
    .line 13: const/4 v3, 2
    .line 14: new-array v4, v3, [J
    .line 16: const/4 v5, 0
    .line 17: const-wide/16 v6, 1
    .line 19: aput-wide v6, v4, v5
    .line 21: array-length v8, v14
    .line 22: int-to-long v8, v8
    .line 23: const/4 v10, 1
    .line 24: aput-wide v8, v4, v10
    .line 26: iget-object v8, v13, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 28: invoke-static {v8, v2, v4}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/LongBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 31: move-result-object v2
    .line 32: const-string v4, "createTensor(...)"
    .line 34: invoke-static {v2, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 37: const-string v9, "input_ids"
    .line 39: invoke-virtual {v1, v9, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 42: array-length v2, v14
    .line 43: new-array v11, v2, [J
    .line 45: move v12, v5
    .line 46: if-ge v12, v2, :cond_53
    .line 48: aput-wide v6, v11, v12
    .line 50: add-int/lit8 v12, v12, 1
    .line 52: goto :goto_46
    .line 53: invoke-static {v11}, Ljava/nio/LongBuffer;->wrap([J)Ljava/nio/LongBuffer;
    .line 56: move-result-object v2
    .line 57: new-array v3, v3, [J
    .line 59: aput-wide v6, v3, v5
    .line 61: array-length v14, v14
    .line 62: int-to-long v6, v14
    .line 63: aput-wide v6, v3, v10
    .line 65: invoke-static {v8, v2, v3}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/LongBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 68: move-result-object v14
    .line 69: invoke-static {v14, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 72: const-string v2, "attention_mask"
    .line 74: invoke-virtual {v1, v2, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 77: invoke-virtual {v13}, Lcom/titanchess/accessibility/n1;->f()Lai/onnxruntime/OrtSession;
    .line 80: move-result-object v14
    .line 81: invoke-virtual {v14, v1}, Lai/onnxruntime/OrtSession;->run(Ljava/util/Map;)Lai/onnxruntime/OrtSession$Result;
    .line 84: move-result-object v14
    .line 85: new-instance v3, Ljava/util/HashMap;
    .line 87: iget-object v6, v13, Lcom/titanchess/accessibility/n1;->o:Ljava/util/ArrayList;
    .line 89: invoke-virtual {v6}, Ljava/util/ArrayList;->size()I
    .line 92: move-result v7
    .line 93: invoke-direct {v3, v7}, Ljava/util/HashMap;-><init>(I)V
    .line 96: invoke-virtual {v6}, Ljava/util/ArrayList;->size()I
    .line 99: move-result v7
    .line 100: const-string v10, "null cannot be cast to non-null type ai.onnxruntime.OnnxTensor"
    .line 102: if-ge v5, v7, :cond_167
    .line 104: iget-object v11, v13, Lcom/titanchess/accessibility/n1;->p:Ljava/util/ArrayList;
    .line 106: invoke-virtual {v11, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 109: move-result-object v11
    .line 110: check-cast v11, Ljava/lang/String;
    .line 112: invoke-virtual {v14, v11}, Lai/onnxruntime/OrtSession$Result;->get(Ljava/lang/String;)Ljava/util/Optional;
    .line 115: move-result-object v11
    .line 116: invoke-virtual {v11}, Ljava/util/Optional;->get()Ljava/lang/Object;
    .line 119: move-result-object v11
    .line 120: invoke-static {v11, v10}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 123: check-cast v11, Lai/onnxruntime/OnnxTensor;
    .line 125: invoke-virtual {v11}, Lai/onnxruntime/OnnxTensorLike;->getInfo()Lai/onnxruntime/TensorInfo;
    .line 128: move-result-object v10
    .line 129: invoke-virtual {v10}, Lai/onnxruntime/TensorInfo;->getShape()[J
    .line 132: move-result-object v10
    .line 133: invoke-virtual {v11}, Lai/onnxruntime/OnnxTensor;->getFloatBuffer()Ljava/nio/FloatBuffer;
    .line 136: move-result-object v11
    .line 137: invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I
    .line 140: move-result v12
    .line 141: new-array v12, v12, [F
    .line 143: invoke-virtual {v11, v12}, Ljava/nio/FloatBuffer;->get([F)Ljava/nio/FloatBuffer;
    .line 146: invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 149: move-result-object v11
    .line 150: invoke-static {v12}, Ljava/nio/FloatBuffer;->wrap([F)Ljava/nio/FloatBuffer;
    .line 153: move-result-object v12
    .line 154: invoke-static {v8, v12, v10}, Lai/onnxruntime/OnnxTensor;->createTensor(Lai/onnxruntime/OrtEnvironment;Ljava/nio/FloatBuffer;[J)Lai/onnxruntime/OnnxTensor;
    .line 157: move-result-object v10
    .line 158: invoke-static {v10, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 161: invoke-virtual {v3, v11, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 164: add-int/lit8 v5, v5, 1
    .line 166: goto :goto_100
    .line 167: const-string v4, "logits"
    .line 169: invoke-virtual {v14, v4}, Lai/onnxruntime/OrtSession$Result;->get(Ljava/lang/String;)Ljava/util/Optional;
    .line 172: move-result-object v4
    .line 173: invoke-virtual {v4}, Ljava/util/Optional;->get()Ljava/lang/Object;
    .line 176: move-result-object v4
    .line 177: invoke-static {v4, v10}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 180: check-cast v4, Lai/onnxruntime/OnnxTensor;
    .line 182: invoke-virtual {v4}, Lai/onnxruntime/OnnxTensor;->getFloatBuffer()Ljava/nio/FloatBuffer;
    .line 185: move-result-object v4
    .line 186: invoke-virtual {v4}, Ljava/nio/Buffer;->remaining()I
    .line 189: move-result v5
    .line 190: new-array v5, v5, [F
    .line 192: invoke-virtual {v4, v5}, Ljava/nio/FloatBuffer;->get([F)Ljava/nio/FloatBuffer;
    .line 195: invoke-virtual {v14}, Lai/onnxruntime/OrtSession$Result;->close()V
    .line 198: invoke-static {v0}, Lcom/titanchess/accessibility/n1;->b(Ljava/util/Map;)V
    .line 201: invoke-virtual {v1, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 204: move-result-object v14
    .line 205: invoke-static {v14, v10}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 208: check-cast v14, Lai/onnxruntime/OnnxTensor;
    .line 210: invoke-virtual {v14}, Lai/onnxruntime/OnnxTensor;->close()V
    .line 213: goto :goto_218
    .line 214: move-exception v14
    .line 215: invoke-static {v14}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 218: invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 221: move-result-object v14
    .line 222: invoke-static {v14, v10}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 225: check-cast v14, Lai/onnxruntime/OnnxTensor;
    .line 227: invoke-virtual {v14}, Lai/onnxruntime/OnnxTensor;->close()V
    .line 230: goto :goto_235
    .line 231: move-exception v14
    .line 232: invoke-static {v14}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 235: iput-object v3, v13, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 237: invoke-virtual {v13, v15, v5}, Lcom/titanchess/accessibility/n1;->c(I[F)Ljava/util/ArrayList;
    .line 240: move-result-object v14
    .line 241: return-object v14
.end method

# virtual methods
.method public final declared-synchronized f()Lai/onnxruntime/OrtSession;
    .registers 7

    .line 0: monitor-enter v6
    .line 1: iget-object v0, v6, Lcom/titanchess/accessibility/n1;->n:Lai/onnxruntime/OrtSession;
    .line 3: if-eqz v0, :cond_7
    .line 5: monitor-exit v6
    .line 6: return-object v0
    .line 7: iget-object v0, v6, Lcom/titanchess/accessibility/n1;->m:Lcom/titanchess/accessibility/m1;
    .line 9: const/4 v1, 0
    .line 10: invoke-virtual {v0, v1}, Lcom/titanchess/accessibility/m1;->c(Ld3/e;)[B
    .line 13: move-result-object v0
    .line 14: iget-object v1, v6, Lcom/titanchess/accessibility/n1;->l:Lai/onnxruntime/OrtEnvironment;
    .line 16: new-instance v2, Lai/onnxruntime/OrtSession$SessionOptions;
    .line 18: invoke-direct {v2}, Lai/onnxruntime/OrtSession$SessionOptions;-><init>()V
    .line 21: iget v3, v6, Lcom/titanchess/accessibility/n1;->d:I
    .line 23: invoke-virtual {v2, v3}, Lai/onnxruntime/OrtSession$SessionOptions;->setIntraOpNumThreads(I)V
    .line 26: const-string v3, "intra_op_num_threads"
    .line 28: iget v4, v6, Lcom/titanchess/accessibility/n1;->d:I
    .line 30: invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 33: move-result-object v4
    .line 34: new-instance v5, Ls2/e;
    .line 36: invoke-direct {v5, v3, v4}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 39: invoke-static {v5}, Ld2/c;->g0(Ls2/e;)Ljava/util/Map;
    .line 42: move-result-object v3
    .line 43: invoke-virtual {v2, v3}, Lai/onnxruntime/OrtSession$SessionOptions;->addXnnpack(Ljava/util/Map;)V
    .line 46: sget-object v3, Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;->ALL_OPT:Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;
    .line 48: invoke-virtual {v2, v3}, Lai/onnxruntime/OrtSession$SessionOptions;->setOptimizationLevel(Lai/onnxruntime/OrtSession$SessionOptions$OptLevel;)V
    .line 51: invoke-virtual {v1, v0, v2}, Lai/onnxruntime/OrtEnvironment;->createSession([BLai/onnxruntime/OrtSession$SessionOptions;)Lai/onnxruntime/OrtSession;
    .line 54: move-result-object v0
    .line 55: iput-object v0, v6, Lcom/titanchess/accessibility/n1;->n:Lai/onnxruntime/OrtSession;
    .line 57: invoke-static {v0}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 60: monitor-exit v6
    .line 61: return-object v0
    .line 62: move-exception v0
    .line 63: monitor-exit v6
    .line 64: throw v0
.end method

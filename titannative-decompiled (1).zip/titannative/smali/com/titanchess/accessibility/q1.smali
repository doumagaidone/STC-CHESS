.class public final Lcom/titanchess/accessibility/q1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lcom/titanchess/accessibility/k;
.field public final b:I

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/k;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/q1;->a:Lcom/titanchess/accessibility/k;
    .line 5: iput v2, v0, Lcom/titanchess/accessibility/q1;->b:I
    .line 7: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/q1;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/q1;
    .line 12: iget-object v1, v5, Lcom/titanchess/accessibility/q1;->a:Lcom/titanchess/accessibility/k;
    .line 14: iget-object v3, v4, Lcom/titanchess/accessibility/q1;->a:Lcom/titanchess/accessibility/k;
    .line 16: if-eq v3, v1, :cond_19
    .line 18: return v2
    .line 19: iget v1, v4, Lcom/titanchess/accessibility/q1;->b:I
    .line 21: iget v5, v5, Lcom/titanchess/accessibility/q1;->b:I
    .line 23: if-eq v1, v5, :cond_26
    .line 25: return v2
    .line 26: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Lcom/titanchess/accessibility/q1;->a:Lcom/titanchess/accessibility/k;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget v1, v2, Lcom/titanchess/accessibility/q1;->b:I
    .line 10: invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Grade(tier="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/q1;->a:Lcom/titanchess/accessibility/k;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", whitePovCp="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lcom/titanchess/accessibility/q1;->b:I
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ")"
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 30: move-result-object v0
    .line 31: return-object v0
.end method

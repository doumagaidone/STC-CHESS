.class public final Lcom/titanchess/accessibility/y;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:Ljava/lang/String;
.field public final synthetic b:Ljava/lang/String;
.field public final synthetic c:Landroid/content/Context;
.field public final synthetic d:Ljava/util/concurrent/atomic/AtomicReference;
.field public final synthetic e:Ljava/util/concurrent/CountDownLatch;

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/CountDownLatch;)V
    .registers 6

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/y;->a:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/y;->b:Ljava/lang/String;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/y;->c:Landroid/content/Context;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/y;->d:Ljava/util/concurrent/atomic/AtomicReference;
    .line 11: iput-object v5, v0, Lcom/titanchess/accessibility/y;->e:Ljava/util/concurrent/CountDownLatch;
    .line 13: return-void
.end method

# virtual methods
.method public final a(Ld4/g;Lr3/z;)V
    .registers 10

    .line 0: const-string v9, "ws"
    .line 2: invoke-static {v8, v9}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v9, Lorg/json/JSONObject;
    .line 7: invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V
    .line 10: const-string v0, "type"
    .line 12: const-string v1, "LOGIN"
    .line 14: invoke-virtual {v9, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    .line 17: move-result-object v9
    .line 18: const-string v0, "key"
    .line 20: iget-object v1, v7, Lcom/titanchess/accessibility/y;->a:Ljava/lang/String;
    .line 22: invoke-virtual {v9, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    .line 25: move-result-object v9
    .line 26: const-string v0, "hwid"
    .line 28: iget-object v1, v7, Lcom/titanchess/accessibility/y;->b:Ljava/lang/String;
    .line 30: invoke-virtual {v9, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    .line 33: move-result-object v9
    .line 34: const-string v0, "source"
    .line 36: const-string v1, "TITANNATIVE"
    .line 38: invoke-virtual {v9, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    .line 41: move-result-object v9
    .line 42: const-string v0, "version"
    .line 44: iget-object v1, v7, Lcom/titanchess/accessibility/y;->c:Landroid/content/Context;
    .line 46: const-string v2, "0"
    .line 48: invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    .line 51: move-result-object v3
    .line 52: invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 55: move-result-object v1
    .line 56: const/4 v4, 0
    .line 57: invoke-virtual {v3, v1, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    .line 60: move-result-object v1
    .line 61: iget-object v1, v1, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    .line 63: if-nez v1, :cond_72
    .line 65: move-object v1, v2
    .line 66: goto :goto_72
    .line 67: move-exception v1
    .line 68: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 71: move-result-object v1
    .line 72: instance-of v3, v1, Ls2/f;
    .line 74: if-eqz v3, :cond_77
    .line 76: goto :goto_78
    .line 77: move-object v2, v1
    .line 78: check-cast v2, Ljava/lang/String;
    .line 80: invoke-virtual {v9, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    .line 83: move-result-object v9
    .line 84: invoke-virtual {v9}, Lorg/json/JSONObject;->toString()Ljava/lang/String;
    .line 87: move-result-object v9
    .line 88: const-string v0, "toString(...)"
    .line 90: invoke-static {v9, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 93: sget-object v0, Le4/k;->l:Le4/k;
    .line 95: invoke-static {v9}, Lz3/b;->s(Ljava/lang/String;)Le4/k;
    .line 98: move-result-object v9
    .line 99: monitor-enter v8
    .line 100: iget-boolean v0, v8, Ld4/g;->u:Z
    .line 102: if-nez v0, :cond_153
    .line 104: iget-boolean v0, v8, Ld4/g;->r:Z
    .line 106: if-eqz v0, :cond_109
    .line 108: goto :goto_153
    .line 109: iget-wide v0, v8, Ld4/g;->q:J
    .line 111: iget-object v2, v9, Le4/k;->i:[B
    .line 113: array-length v3, v2
    .line 114: int-to-long v3, v3
    .line 115: add-long/2addr v3, v0
    .line 116: const-wide/32 v5, 0x1000000
    .line 119: cmp-long v3, v3, v5
    .line 121: if-lez v3, :cond_133
    .line 123: const/16 v9, 1001
    .line 125: const/4 v0, 0
    .line 126: invoke-virtual {v8, v9, v0}, Ld4/g;->b(ILjava/lang/String;)Z
    .line 129: monitor-exit v8
    .line 130: goto :goto_154
    .line 131: move-exception v9
    .line 132: goto :goto_155
    .line 133: array-length v2, v2
    .line 134: int-to-long v2, v2
    .line 135: add-long/2addr v0, v2
    .line 136: iput-wide v0, v8, Ld4/g;->q:J
    .line 138: iget-object v0, v8, Ld4/g;->p:Ljava/util/ArrayDeque;
    .line 140: new-instance v1, Ld4/d;
    .line 142: invoke-direct {v1, v9}, Ld4/d;-><init>(Le4/k;)V
    .line 145: invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z
    .line 148: invoke-virtual {v8}, Ld4/g;->f()V
    .line 151: monitor-exit v8
    .line 152: goto :goto_154
    .line 153: monitor-exit v8
    .line 154: return-void
    .line 155: monitor-exit v8
    .line 156: throw v9
.end method

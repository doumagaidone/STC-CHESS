.class public final Lcom/titanchess/accessibility/v;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:D
.field public final b:D
.field public final c:Z

# direct methods
.method public constructor <init>(DDZ)V
    .registers 6

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-wide v1, v0, Lcom/titanchess/accessibility/v;->a:D
    .line 5: iput-wide v3, v0, Lcom/titanchess/accessibility/v;->b:D
    .line 7: iput-boolean v5, v0, Lcom/titanchess/accessibility/v;->c:Z
    .line 9: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/v;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/v;
    .line 12: iget-wide v3, v8, Lcom/titanchess/accessibility/v;->a:D
    .line 14: iget-wide v5, v7, Lcom/titanchess/accessibility/v;->a:D
    .line 16: invoke-static {v5, v6, v3, v4}, Ljava/lang/Double;->compare(DD)I
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_23
    .line 22: return v2
    .line 23: iget-wide v3, v7, Lcom/titanchess/accessibility/v;->b:D
    .line 25: iget-wide v5, v8, Lcom/titanchess/accessibility/v;->b:D
    .line 27: invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I
    .line 30: move-result v1
    .line 31: if-eqz v1, :cond_34
    .line 33: return v2
    .line 34: iget-boolean v1, v7, Lcom/titanchess/accessibility/v;->c:Z
    .line 36: iget-boolean v8, v8, Lcom/titanchess/accessibility/v;->c:Z
    .line 38: if-eq v1, v8, :cond_41
    .line 40: return v2
    .line 41: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-wide v0, v3, Lcom/titanchess/accessibility/v;->a:D
    .line 2: invoke-static {v0, v1}, Ljava/lang/Double;->hashCode(D)I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-wide v1, v3, Lcom/titanchess/accessibility/v;->b:D
    .line 10: invoke-static {v1, v2}, Ljava/lang/Double;->hashCode(D)I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget-boolean v0, v3, Lcom/titanchess/accessibility/v;->c:Z
    .line 19: if-eqz v0, :cond_22
    .line 21: const/4 v0, 1
    .line 22: add-int/2addr v1, v0
    .line 23: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "WAcc(acc="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-wide v1, v3, Lcom/titanchess/accessibility/v;->a:D
    .line 9: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", weight="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-wide v1, v3, Lcom/titanchess/accessibility/v;->b:D
    .line 19: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", white="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-boolean v1, v3, Lcom/titanchess/accessibility/v;->c:Z
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ")"
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 40: move-result-object v0
    .line 41: return-object v0
.end method

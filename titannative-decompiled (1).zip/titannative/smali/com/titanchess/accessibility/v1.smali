.class public final synthetic Lcom/titanchess/accessibility/v1;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final synthetic j:Lcom/titanchess/accessibility/TitanAccessibilityService;

# direct methods
.method public synthetic constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v2, v0, Lcom/titanchess/accessibility/v1;->i:I
    .line 5: iput-object v1, v0, Lcom/titanchess/accessibility/v1;->j:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 7: return-void
.end method

# virtual methods
.method public final run()V
    .registers 3

    .line 0: iget v0, v2, Lcom/titanchess/accessibility/v1;->i:I
    .line 2: iget-object v1, v2, Lcom/titanchess/accessibility/v1;->j:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 4: packed-switch v0, :data_36
    .line 7: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->k(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 10: return-void
    .line 11: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->h(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 14: return-void
    .line 15: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->d(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 18: return-void
    .line 19: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->a(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 22: return-void
    .line 23: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->b(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 26: return-void
    .line 27: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->j(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 30: return-void
    .line 31: invoke-static {v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->f(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 34: return-void
    .line 35: nop
    .line 36: nop
    .line 37: move-wide/16 v0, v0
    .line 40: const-string/jumbo v0, "string@1507328"
    .line 43: nop
    .line 44: const/16 v0, 0
    .line 46: return v0
    .line 47: nop
    .line 48: move-result-wide v0
    .line 49: nop
    .line 50: move-object v0, v0
    .line 51: nop
.end method

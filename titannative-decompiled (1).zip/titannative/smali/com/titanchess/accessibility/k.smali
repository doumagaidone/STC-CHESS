.class public final enum Lcom/titanchess/accessibility/k;
.super Ljava/lang/Enum;
.source "SourceFile"

.field public static final enum j:Lcom/titanchess/accessibility/k;
.field public static final enum k:Lcom/titanchess/accessibility/k;
.field public static final enum l:Lcom/titanchess/accessibility/k;
.field public static final enum m:Lcom/titanchess/accessibility/k;
.field public static final enum n:Lcom/titanchess/accessibility/k;
.field public static final enum o:Lcom/titanchess/accessibility/k;
.field public static final enum p:Lcom/titanchess/accessibility/k;
.field public static final synthetic q:[Lcom/titanchess/accessibility/k;

.field public final i:Ljava/lang/String;

# direct methods
.method static constructor <clinit>()V
    .registers 10

    .line 0: new-instance v0, Lcom/titanchess/accessibility/k;
    .line 2: const-string v1, "review_book"
    .line 4: const-string v2, "BOOK"
    .line 6: const/4 v3, 0
    .line 7: invoke-direct {v0, v2, v3, v1}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 10: sput-object v0, Lcom/titanchess/accessibility/k;->j:Lcom/titanchess/accessibility/k;
    .line 12: new-instance v1, Lcom/titanchess/accessibility/k;
    .line 14: const-string v2, "review_best"
    .line 16: const-string v3, "BEST"
    .line 18: const/4 v4, 1
    .line 19: invoke-direct {v1, v3, v4, v2}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 22: sput-object v1, Lcom/titanchess/accessibility/k;->k:Lcom/titanchess/accessibility/k;
    .line 24: new-instance v2, Lcom/titanchess/accessibility/k;
    .line 26: const-string v3, "review_excellent"
    .line 28: const-string v4, "EXCELLENT"
    .line 30: const/4 v5, 2
    .line 31: invoke-direct {v2, v4, v5, v3}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 34: sput-object v2, Lcom/titanchess/accessibility/k;->l:Lcom/titanchess/accessibility/k;
    .line 36: new-instance v3, Lcom/titanchess/accessibility/k;
    .line 38: const-string v4, "review_good"
    .line 40: const-string v5, "GOOD"
    .line 42: const/4 v6, 3
    .line 43: invoke-direct {v3, v5, v6, v4}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 46: sput-object v3, Lcom/titanchess/accessibility/k;->m:Lcom/titanchess/accessibility/k;
    .line 48: new-instance v4, Lcom/titanchess/accessibility/k;
    .line 50: const-string v5, "review_inaccuracy"
    .line 52: const-string v6, "INACCURACY"
    .line 54: const/4 v7, 4
    .line 55: invoke-direct {v4, v6, v7, v5}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 58: sput-object v4, Lcom/titanchess/accessibility/k;->n:Lcom/titanchess/accessibility/k;
    .line 60: new-instance v5, Lcom/titanchess/accessibility/k;
    .line 62: const-string v6, "review_mistake"
    .line 64: const-string v7, "MISTAKE"
    .line 66: const/4 v8, 5
    .line 67: invoke-direct {v5, v7, v8, v6}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 70: sput-object v5, Lcom/titanchess/accessibility/k;->o:Lcom/titanchess/accessibility/k;
    .line 72: new-instance v6, Lcom/titanchess/accessibility/k;
    .line 74: const-string v7, "review_blunder"
    .line 76: const-string v8, "BLUNDER"
    .line 78: const/4 v9, 6
    .line 79: invoke-direct {v6, v8, v9, v7}, Lcom/titanchess/accessibility/k;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    .line 82: sput-object v6, Lcom/titanchess/accessibility/k;->p:Lcom/titanchess/accessibility/k;
    .line 84: filled-new-array/range {v0 .. v6}, [Lcom/titanchess/accessibility/k;
    .line 87: move-result-object v0
    .line 88: sput-object v0, Lcom/titanchess/accessibility/k;->q:[Lcom/titanchess/accessibility/k;
    .line 90: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: iput-object v3, v0, Lcom/titanchess/accessibility/k;->i:Ljava/lang/String;
    .line 5: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lcom/titanchess/accessibility/k;
    .registers 2

    .line 0: const-class v0, Lcom/titanchess/accessibility/k;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Lcom/titanchess/accessibility/k;
    .line 8: return-object v1
.end method

# direct methods
.method public static values()[Lcom/titanchess/accessibility/k;
    .registers 1

    .line 0: sget-object v0, Lcom/titanchess/accessibility/k;->q:[Lcom/titanchess/accessibility/k;
    .line 2: invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lcom/titanchess/accessibility/k;
    .line 8: return-object v0
.end method

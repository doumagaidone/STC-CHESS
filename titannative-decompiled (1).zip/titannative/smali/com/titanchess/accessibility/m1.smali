.class public final Lcom/titanchess/accessibility/m1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroid/content/Context;
.field public final b:Ls2/h;
.field public c:Lorg/json/JSONObject;

# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lcom/titanchess/accessibility/m1;->a:Landroid/content/Context;
    .line 10: new-instance v2, Lh/i0;
    .line 12: const/16 v0, 29
    .line 14: invoke-direct {v2, v0, v1}, Lh/i0;-><init>(ILjava/lang/Object;)V
    .line 17: new-instance v0, Ls2/h;
    .line 19: invoke-direct {v0, v2}, Ls2/h;-><init>(Ld3/a;)V
    .line 22: iput-object v0, v1, Lcom/titanchess/accessibility/m1;->b:Ls2/h;
    .line 24: return-void
.end method

# direct methods
.method public static k(Ljava/io/File;[B)V
    .registers 6

    .line 0: new-instance v0, Ljava/io/File;
    .line 2: invoke-virtual {v4}, Ljava/io/File;->getParentFile()Ljava/io/File;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;
    .line 9: move-result-object v2
    .line 10: new-instance v3, Ljava/lang/StringBuilder;
    .line 12: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 15: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 18: const-string v2, ".tmp"
    .line 20: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 23: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 26: move-result-object v2
    .line 27: invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 30: invoke-static {v0, v5}, Ld2/b;->y1(Ljava/io/File;[B)V
    .line 33: invoke-virtual {v0, v4}, Ljava/io/File;->renameTo(Ljava/io/File;)Z
    .line 36: move-result v5
    .line 37: if-nez v5, :cond_45
    .line 39: invoke-static {v0, v4}, Lc3/d;->D1(Ljava/io/File;Ljava/io/File;)V
    .line 42: invoke-virtual {v0}, Ljava/io/File;->delete()Z
    .line 45: return-void
.end method

# virtual methods
.method public final a(Ljava/lang/String;)Ljava/io/File;
    .registers 6

    .line 0: const-string v0, "band"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Ljava/io/File;
    .line 7: iget-object v1, v4, Lcom/titanchess/accessibility/m1;->b:Ls2/h;
    .line 9: invoke-virtual {v1}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 12: move-result-object v1
    .line 13: check-cast v1, Ljava/io/File;
    .line 15: new-instance v2, Ljava/lang/StringBuilder;
    .line 17: const-string v3, "chessmimic_"
    .line 19: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 22: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 25: const-string v5, ".onnx.enc"
    .line 27: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 33: move-result-object v5
    .line 34: invoke-direct {v0, v1, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 37: return-object v0
.end method

# virtual methods
.method public final b(Ljava/lang/String;Ld3/e;)Ls2/e;
    .registers 19

    .line 0: move-object/from16 v1, v16
    .line 2: move-object/from16 v2, v17
    .line 4: iget-object v3, v1, Lcom/titanchess/accessibility/m1;->a:Landroid/content/Context;
    .line 6: const-string v4, "mimic/scalers_"
    .line 8: const-string v5, "mimic/chessmimic_"
    .line 10: const-string v0, "band"
    .line 12: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/io/File;
    .line 17: iget-object v6, v1, Lcom/titanchess/accessibility/m1;->b:Ls2/h;
    .line 19: invoke-virtual {v6}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 22: move-result-object v6
    .line 23: check-cast v6, Ljava/io/File;
    .line 25: new-instance v7, Ljava/lang/StringBuilder;
    .line 27: const-string v8, "chessmimic_"
    .line 29: invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 32: invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 35: const-string v8, ".onnx"
    .line 37: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 40: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 43: move-result-object v7
    .line 44: invoke-direct {v0, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 47: invoke-virtual {v0}, Ljava/io/File;->exists()Z
    .line 50: move-result v6
    .line 51: if-eqz v6, :cond_56
    .line 53: invoke-virtual {v0}, Ljava/io/File;->delete()Z
    .line 56: invoke-virtual/range {v16 .. v17}, Lcom/titanchess/accessibility/m1;->a(Ljava/lang/String;)Ljava/io/File;
    .line 59: move-result-object v6
    .line 60: invoke-virtual/range {v16 .. v17}, Lcom/titanchess/accessibility/m1;->j(Ljava/lang/String;)Ljava/io/File;
    .line 63: move-result-object v7
    .line 64: invoke-virtual/range {v16 .. v17}, Lcom/titanchess/accessibility/m1;->f(Ljava/lang/String;)Z
    .line 67: move-result v0
    .line 68: sget-object v9, Lcom/titanchess/accessibility/e;->a:Lcom/titanchess/accessibility/e;
    .line 70: const v10, 0xf4240
    .line 73: const-string v11, "TitanModelStore"
    .line 75: const-string v13, "band "
    .line 77: if-eqz v0, :cond_245
    .line 79: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 82: move-result-wide v14
    .line 83: invoke-static {v6}, Ld2/b;->S0(Ljava/io/File;)[B
    .line 86: move-result-object v0
    .line 87: invoke-static {v0}, Lcom/titanchess/accessibility/e;->a([B)[B
    .line 90: move-result-object v0
    .line 91: goto :goto_97
    .line 92: move-exception v0
    .line 93: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 96: move-result-object v0
    .line 97: instance-of v12, v0, Ls2/f;
    .line 99: if-eqz v12, :cond_102
    .line 101: const/4 v0, 0
    .line 102: check-cast v0, [B
    .line 104: if-eqz v0, :cond_222
    .line 106: array-length v3, v0
    .line 107: div-int/2addr v3, v10
    .line 108: invoke-static {}, Ljava/lang/System;->nanoTime()J
    .line 111: move-result-wide v4
    .line 112: sub-long/2addr v4, v14
    .line 113: int-to-long v8, v10
    .line 114: div-long/2addr v4, v8
    .line 115: new-instance v6, Ljava/lang/StringBuilder;
    .line 117: invoke-direct {v6, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 120: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 123: const-string v2, " from cache ("
    .line 125: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 128: invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 131: const-string v2, "MB, decrypted in "
    .line 133: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 136: invoke-virtual {v6, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 139: const-string v2, "ms)"
    .line 141: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 144: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 147: move-result-object v2
    .line 148: invoke-static {v11, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 151: sget-object v2, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 153: const-string v3, "charset"
    .line 155: invoke-static {v2, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 158: new-instance v3, Ljava/io/InputStreamReader;
    .line 160: new-instance v4, Ljava/io/FileInputStream;
    .line 162: invoke-direct {v4, v7}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    .line 165: invoke-direct {v3, v4, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
    .line 168: new-instance v2, Ljava/io/StringWriter;
    .line 170: invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V
    .line 173: const/16 v4, 8192
    .line 175: new-array v4, v4, [C
    .line 177: invoke-virtual {v3, v4}, Ljava/io/Reader;->read([C)I
    .line 180: move-result v5
    .line 181: if-ltz v5, :cond_192
    .line 183: const/4 v6, 0
    .line 184: invoke-virtual {v2, v4, v6, v5}, Ljava/io/Writer;->write([CII)V
    .line 187: invoke-virtual {v3, v4}, Ljava/io/Reader;->read([C)I
    .line 190: move-result v5
    .line 191: goto :goto_181
    .line 192: invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;
    .line 195: move-result-object v2
    .line 196: const-string v4, "buffer.toString()"
    .line 198: invoke-static {v2, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 201: const/4 v4, 0
    .line 202: invoke-static {v3, v4}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 205: new-instance v3, Ls2/e;
    .line 207: invoke-direct {v3, v0, v2}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 210: return-object v3
    .line 211: move-object v2, v0
    .line 212: goto :goto_215
    .line 213: move-exception v0
    .line 214: goto :goto_211
    .line 215: throw v2
    .line 216: move-exception v0
    .line 217: move-object v4, v0
    .line 218: invoke-static {v3, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 221: throw v4
    .line 222: new-instance v0, Ljava/lang/StringBuilder;
    .line 224: invoke-direct {v0, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 227: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 230: const-string v12, " cache decrypt failed → re-fetch"
    .line 232: invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 235: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 238: move-result-object v0
    .line 239: invoke-static {v11, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    .line 242: invoke-virtual {v6}, Ljava/io/File;->delete()Z
    .line 245: invoke-virtual {v3}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 248: move-result-object v0
    .line 249: new-instance v12, Ljava/lang/StringBuilder;
    .line 251: invoke-direct {v12, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 254: invoke-virtual {v12, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 257: invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 260: invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 263: move-result-object v5
    .line 264: invoke-virtual {v0, v5}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 267: move-result-object v5
    .line 268: invoke-static {v5}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 271: invoke-static {v5}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 274: move-result-object v0
    .line 275: const/4 v8, 0
    .line 276: invoke-static {v5, v8}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 279: invoke-virtual {v3}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 282: move-result-object v3
    .line 283: new-instance v5, Ljava/lang/StringBuilder;
    .line 285: invoke-direct {v5, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 288: invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 291: const-string v4, ".json"
    .line 293: invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 296: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 299: move-result-object v4
    .line 300: invoke-virtual {v3, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 303: move-result-object v3
    .line 304: invoke-static {v3}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 307: invoke-static {v3}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 310: move-result-object v4
    .line 311: const/4 v5, 0
    .line 312: invoke-static {v3, v5}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 315: sget-object v3, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 317: new-instance v5, Ljava/lang/String;
    .line 319: invoke-direct {v5, v4, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 322: invoke-virtual {v9, v0}, Lcom/titanchess/accessibility/e;->b([B)[B
    .line 325: move-result-object v3
    .line 326: invoke-static {v6, v3}, Lcom/titanchess/accessibility/m1;->k(Ljava/io/File;[B)V
    .line 329: invoke-static {v7, v5}, Ld2/b;->z1(Ljava/io/File;Ljava/lang/String;)V
    .line 332: new-instance v3, Ljava/lang/StringBuilder;
    .line 334: invoke-direct {v3, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 337: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 340: const-string v4, " copied from asset → cache (encrypted)"
    .line 342: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 345: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 348: move-result-object v3
    .line 349: invoke-static {v11, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 352: new-instance v3, Ls2/e;
    .line 354: invoke-direct {v3, v0, v5}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 357: return-object v3
    .line 358: move-exception v0
    .line 359: goto :goto_378
    .line 360: move-exception v0
    .line 361: move-object v4, v0
    .line 362: throw v4
    .line 363: move-exception v0
    .line 364: move-object v5, v0
    .line 365: invoke-static {v3, v4}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 368: throw v5
    .line 369: move-exception v0
    .line 370: move-object v3, v0
    .line 371: throw v3
    .line 372: move-exception v0
    .line 373: move-object v4, v0
    .line 374: invoke-static {v5, v3}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 377: throw v4
    .line 378: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 381: invoke-virtual/range {v16 .. v17}, Lcom/titanchess/accessibility/m1;->h(Ljava/lang/String;)Ljava/lang/String;
    .line 384: move-result-object v0
    .line 385: const-string v3, "https://titan-models.sukhazulusitepu.workers.dev/band/"
    .line 387: invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 390: move-result-object v3
    .line 391: move-object/from16 v4, v18
    .line 393: invoke-virtual {v1, v3, v4}, Lcom/titanchess/accessibility/m1;->e(Ljava/lang/String;Ld3/e;)[B
    .line 396: move-result-object v3
    .line 397: const/16 v4, 12
    .line 399: if-eqz v0, :cond_475
    .line 401: const-string v5, "SHA-256"
    .line 403: invoke-static {v5}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;
    .line 406: move-result-object v5
    .line 407: invoke-virtual {v5, v3}, Ljava/security/MessageDigest;->digest([B)[B
    .line 410: move-result-object v5
    .line 411: const-string v6, "digest(...)"
    .line 413: invoke-static {v5, v6}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 416: sget-object v6, Lcom/titanchess/accessibility/x;->n:Lcom/titanchess/accessibility/x;
    .line 418: invoke-static {v5, v6}, Lt2/k;->V0([BLcom/titanchess/accessibility/x;)Ljava/lang/String;
    .line 421: move-result-object v5
    .line 422: invoke-static {v5, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 425: move-result v6
    .line 426: if-eqz v6, :cond_429
    .line 428: goto :goto_475
    .line 429: invoke-static {v4, v5}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 432: move-result-object v3
    .line 433: invoke-static {v4, v0}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 436: move-result-object v0
    .line 437: new-instance v4, Ljava/lang/StringBuilder;
    .line 439: invoke-direct {v4, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 442: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 445: const-string v2, " SHA mismatch: got "
    .line 447: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 450: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 453: const-string v2, " want "
    .line 455: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 458: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 461: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 464: move-result-object v0
    .line 465: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 467: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 470: move-result-object v0
    .line 471: invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 474: throw v2
    .line 475: new-instance v5, Ljava/lang/String;
    .line 477: const-string v6, "https://titan-models.sukhazulusitepu.workers.dev/scalers/"
    .line 479: invoke-virtual {v6, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 482: move-result-object v6
    .line 483: const/4 v7, 0
    .line 484: invoke-virtual {v1, v6, v7}, Lcom/titanchess/accessibility/m1;->e(Ljava/lang/String;Ld3/e;)[B
    .line 487: move-result-object v6
    .line 488: sget-object v7, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 490: invoke-direct {v5, v6, v7}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 493: invoke-virtual/range {v16 .. v17}, Lcom/titanchess/accessibility/m1;->a(Ljava/lang/String;)Ljava/io/File;
    .line 496: move-result-object v6
    .line 497: invoke-virtual {v9, v3}, Lcom/titanchess/accessibility/e;->b([B)[B
    .line 500: move-result-object v7
    .line 501: invoke-static {v6, v7}, Lcom/titanchess/accessibility/m1;->k(Ljava/io/File;[B)V
    .line 504: invoke-virtual/range {v16 .. v17}, Lcom/titanchess/accessibility/m1;->j(Ljava/lang/String;)Ljava/io/File;
    .line 507: move-result-object v6
    .line 508: invoke-static {v6, v5}, Ld2/b;->z1(Ljava/io/File;Ljava/lang/String;)V
    .line 511: array-length v6, v3
    .line 512: div-int/2addr v6, v10
    .line 513: if-eqz v0, :cond_520
    .line 515: invoke-static {v4, v0}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 518: move-result-object v0
    .line 519: goto :goto_522
    .line 520: const-string v0, "unverified"
    .line 522: new-instance v4, Ljava/lang/StringBuilder;
    .line 524: invoke-direct {v4, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 527: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 530: const-string v2, " DOWNLOADED ("
    .line 532: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 535: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 538: const-string v2, "MB, sha "
    .line 540: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 543: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 546: const-string v0, ", encrypted)"
    .line 548: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 551: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 554: move-result-object v0
    .line 555: invoke-static {v11, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 558: new-instance v0, Ls2/e;
    .line 560: invoke-direct {v0, v3, v5}, Ls2/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 563: return-object v0
.end method

# virtual methods
.method public final c(Ld3/e;)[B
    .registers 21

    .line 0: move-object/from16 v1, v19
    .line 2: move-object/from16 v2, v20
    .line 4: const-string v3, " for https://titan-models.sukhazulusitepu.workers.dev/orion"
    .line 6: new-instance v0, Ljava/io/File;
    .line 8: iget-object v4, v1, Lcom/titanchess/accessibility/m1;->b:Ls2/h;
    .line 10: invoke-virtual {v4}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 13: move-result-object v5
    .line 14: check-cast v5, Ljava/io/File;
    .line 16: const-string v6, "orion.onnx.enc"
    .line 18: invoke-direct {v0, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 21: invoke-virtual {v0}, Ljava/io/File;->exists()Z
    .line 24: move-result v5
    .line 25: if-eqz v5, :cond_30
    .line 27: invoke-virtual {v0}, Ljava/io/File;->delete()Z
    .line 30: new-instance v5, Ljava/io/File;
    .line 32: invoke-virtual {v4}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 35: move-result-object v0
    .line 36: check-cast v0, Ljava/io/File;
    .line 38: const-string v4, "orion.onnx"
    .line 40: invoke-direct {v5, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 43: invoke-virtual {v5}, Ljava/io/File;->isFile()Z
    .line 46: move-result v0
    .line 47: const-wide/16 v6, 0
    .line 49: const v4, 0xf4240
    .line 52: const-string v8, "TitanModelStore"
    .line 54: if-eqz v0, :cond_97
    .line 56: invoke-virtual {v5}, Ljava/io/File;->length()J
    .line 59: move-result-wide v9
    .line 60: cmp-long v0, v9, v6
    .line 62: if-lez v0, :cond_97
    .line 64: invoke-virtual {v5}, Ljava/io/File;->length()J
    .line 67: move-result-wide v2
    .line 68: int-to-long v6, v4
    .line 69: div-long/2addr v2, v6
    .line 70: new-instance v0, Ljava/lang/StringBuilder;
    .line 72: const-string v4, "orion from cache ("
    .line 74: invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 77: invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 80: const-string v2, "MB, plain)"
    .line 82: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 85: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 88: move-result-object v0
    .line 89: invoke-static {v8, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 92: invoke-static {v5}, Ld2/b;->S0(Ljava/io/File;)[B
    .line 95: move-result-object v0
    .line 96: return-object v0
    .line 97: const/4 v9, 0
    .line 98: iget-object v0, v1, Lcom/titanchess/accessibility/m1;->a:Landroid/content/Context;
    .line 100: invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 103: move-result-object v0
    .line 104: const-string v10, "model_kv_int8.onnx"
    .line 106: invoke-virtual {v0, v10}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 109: move-result-object v10
    .line 110: invoke-static {v10}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 113: invoke-static {v10}, Ld2/b;->T0(Ljava/io/InputStream;)[B
    .line 116: move-result-object v0
    .line 117: invoke-static {v10, v9}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 120: goto :goto_131
    .line 121: move-exception v0
    .line 122: move-object v11, v0
    .line 123: throw v11
    .line 124: move-exception v0
    .line 125: move-object v12, v0
    .line 126: invoke-static {v10, v11}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 129: throw v12
    .line 130: move-object v0, v9
    .line 131: if-eqz v0, :cond_158
    .line 133: array-length v2, v0
    .line 134: div-int/2addr v2, v4
    .line 135: new-instance v3, Ljava/lang/StringBuilder;
    .line 137: const-string v4, "orion from asset ("
    .line 139: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 142: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 145: const-string v2, "MB, direct)"
    .line 147: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 150: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 153: move-result-object v2
    .line 154: invoke-static {v8, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 157: return-object v0
    .line 158: const-string v0, "orion"
    .line 160: invoke-virtual {v1, v0}, Lcom/titanchess/accessibility/m1;->h(Ljava/lang/String;)Ljava/lang/String;
    .line 163: move-result-object v0
    .line 164: const-string v10, "HTTP "
    .line 166: new-instance v11, Ljava/net/URL;
    .line 168: const-string v12, "https://titan-models.sukhazulusitepu.workers.dev/orion"
    .line 170: invoke-direct {v11, v12}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    .line 173: invoke-virtual {v11}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
    .line 176: move-result-object v11
    .line 177: const-string v12, "null cannot be cast to non-null type java.net.HttpURLConnection"
    .line 179: invoke-static {v11, v12}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 182: check-cast v11, Ljava/net/HttpURLConnection;
    .line 184: const-string v12, "GET"
    .line 186: invoke-virtual {v11, v12}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    .line 189: const v12, 0xea60
    .line 192: invoke-virtual {v11, v12}, Ljava/net/URLConnection;->setConnectTimeout(I)V
    .line 195: invoke-virtual {v11, v12}, Ljava/net/URLConnection;->setReadTimeout(I)V
    .line 198: const-string v12, "User-Agent"
    .line 200: const-string v13, "TitanNative/1 (Android)"
    .line 202: invoke-virtual {v11, v12, v13}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    .line 205: invoke-virtual/range {v19 .. v19}, Lcom/titanchess/accessibility/m1;->d()Ljava/lang/String;
    .line 208: move-result-object v12
    .line 209: if-eqz v12, :cond_222
    .line 211: const-string v13, "Bearer "
    .line 213: invoke-virtual {v13, v12}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 216: move-result-object v12
    .line 217: const-string v13, "Authorization"
    .line 219: invoke-virtual {v11, v13, v12}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    .line 222: new-instance v12, Ljava/io/File;
    .line 224: invoke-virtual {v5}, Ljava/io/File;->getParentFile()Ljava/io/File;
    .line 227: move-result-object v13
    .line 228: invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;
    .line 231: move-result-object v14
    .line 232: new-instance v15, Ljava/lang/StringBuilder;
    .line 234: invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    .line 237: invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 240: const-string v14, ".tmp"
    .line 242: invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 245: invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 248: move-result-object v14
    .line 249: invoke-direct {v12, v13, v14}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 252: invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getResponseCode()I
    .line 255: move-result v13
    .line 256: const/16 v14, 200
    .line 258: if-ne v13, v14, :cond_531
    .line 260: invoke-virtual {v11}, Ljava/net/URLConnection;->getContentLengthLong()J
    .line 263: move-result-wide v13
    .line 264: const-string v3, "SHA-256"
    .line 266: invoke-static {v3}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;
    .line 269: move-result-object v3
    .line 270: invoke-virtual {v11}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;
    .line 273: move-result-object v10
    .line 274: new-instance v15, Ljava/io/FileOutputStream;
    .line 276: invoke-direct {v15, v12}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    .line 279: instance-of v6, v15, Ljava/io/BufferedOutputStream;
    .line 281: const/high16 v7, 0x1
    .line 283: if-eqz v6, :cond_293
    .line 285: check-cast v15, Ljava/io/BufferedOutputStream;
    .line 287: goto :goto_299
    .line 288: move-exception v0
    .line 289: move-object v2, v0
    .line 290: move-object v4, v10
    .line 291: goto/16 :goto_524
    .line 293: new-instance v6, Ljava/io/BufferedOutputStream;
    .line 295: invoke-direct {v6, v15, v7}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;I)V
    .line 298: move-object v15, v6
    .line 299: new-array v6, v7, [B
    .line 301: const-wide/16 v16, 0
    .line 303: invoke-virtual {v10, v6}, Ljava/io/InputStream;->read([B)I
    .line 306: move-result v7
    .line 307: if-ltz v7, :cond_352
    .line 309: const/4 v4, 0
    .line 310: invoke-virtual {v15, v6, v4, v7}, Ljava/io/BufferedOutputStream;->write([BII)V
    .line 313: invoke-virtual {v3, v6, v4, v7}, Ljava/security/MessageDigest;->update([BII)V
    .line 316: move-object/from16 v18, v10
    .line 318: int-to-long v9, v7
    .line 319: add-long v16, v16, v9
    .line 321: if-eqz v2, :cond_341
    .line 323: invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 326: move-result-object v7
    .line 327: invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 330: move-result-object v9
    .line 331: invoke-interface {v2, v7, v9}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 334: goto :goto_341
    .line 335: move-exception v0
    .line 336: move-object v2, v0
    .line 337: move-object/from16 v4, v18
    .line 339: goto/16 :goto_512
    .line 341: move-object/from16 v10, v18
    .line 343: const v4, 0xf4240
    .line 346: const/4 v9, 0
    .line 347: goto :goto_303
    .line 348: move-exception v0
    .line 349: move-object/from16 v18, v10
    .line 351: goto :goto_336
    .line 352: move-object v2, v9
    .line 353: move-object/from16 v18, v10
    .line 355: invoke-static {v15, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 358: move-object/from16 v4, v18
    .line 360: invoke-static {v4, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 363: invoke-virtual {v12, v5}, Ljava/io/File;->renameTo(Ljava/io/File;)Z
    .line 366: move-result v2
    .line 367: if-nez v2, :cond_379
    .line 369: invoke-static {v12, v5}, Lc3/d;->D1(Ljava/io/File;Ljava/io/File;)V
    .line 372: invoke-virtual {v12}, Ljava/io/File;->delete()Z
    .line 375: goto :goto_379
    .line 376: move-exception v0
    .line 377: goto/16 :goto_560
    .line 379: invoke-virtual {v3}, Ljava/security/MessageDigest;->digest()[B
    .line 382: move-result-object v2
    .line 383: const-string v3, "digest(...)"
    .line 385: invoke-static {v2, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 388: sget-object v3, Lcom/titanchess/accessibility/x;->m:Lcom/titanchess/accessibility/x;
    .line 390: invoke-static {v2, v3}, Lt2/k;->V0([BLcom/titanchess/accessibility/x;)Ljava/lang/String;
    .line 393: move-result-object v2
    .line 394: invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V
    .line 397: const/16 v3, 12
    .line 399: if-eqz v0, :cond_451
    .line 401: invoke-static {v2, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 404: move-result v4
    .line 405: if-eqz v4, :cond_408
    .line 407: goto :goto_451
    .line 408: invoke-virtual {v5}, Ljava/io/File;->delete()Z
    .line 411: new-instance v4, Ljava/lang/IllegalStateException;
    .line 413: invoke-static {v3, v2}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 416: move-result-object v2
    .line 417: invoke-static {v3, v0}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 420: move-result-object v0
    .line 421: new-instance v3, Ljava/lang/StringBuilder;
    .line 423: const-string v5, "orion SHA mismatch: got "
    .line 425: invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 428: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 431: const-string v2, " want "
    .line 433: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 436: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 439: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 442: move-result-object v0
    .line 443: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 446: move-result-object v0
    .line 447: invoke-direct {v4, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 450: throw v4
    .line 451: invoke-virtual {v5}, Ljava/io/File;->length()J
    .line 454: move-result-wide v6
    .line 455: const v2, 0xf4240
    .line 458: int-to-long v9, v2
    .line 459: div-long/2addr v6, v9
    .line 460: if-eqz v0, :cond_467
    .line 462: invoke-static {v3, v0}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 465: move-result-object v0
    .line 466: goto :goto_469
    .line 467: const-string v0, "unverified"
    .line 469: new-instance v2, Ljava/lang/StringBuilder;
    .line 471: const-string v3, "orion DOWNLOADED ("
    .line 473: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 476: invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 479: const-string v3, "MB, sha "
    .line 481: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 484: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 487: const-string v0, ", plain)"
    .line 489: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 492: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 495: move-result-object v0
    .line 496: invoke-static {v8, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 499: invoke-static {v5}, Ld2/b;->S0(Ljava/io/File;)[B
    .line 502: move-result-object v0
    .line 503: return-object v0
    .line 504: move-exception v0
    .line 505: move-object/from16 v4, v18
    .line 507: move-object v2, v0
    .line 508: goto :goto_524
    .line 509: move-exception v0
    .line 510: move-object v4, v10
    .line 511: move-object v2, v0
    .line 512: throw v2
    .line 513: move-exception v0
    .line 514: move-object v3, v0
    .line 515: invoke-static {v15, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 518: throw v3
    .line 519: move-exception v0
    .line 520: goto :goto_507
    .line 521: move-exception v0
    .line 522: move-object v4, v10
    .line 523: goto :goto_507
    .line 524: throw v2
    .line 525: move-exception v0
    .line 526: move-object v3, v0
    .line 527: invoke-static {v4, v2}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 530: throw v3
    .line 531: new-instance v0, Ljava/lang/IllegalStateException;
    .line 533: invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getResponseCode()I
    .line 536: move-result v2
    .line 537: new-instance v4, Ljava/lang/StringBuilder;
    .line 539: invoke-direct {v4, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 542: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 545: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 548: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 551: move-result-object v2
    .line 552: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 555: move-result-object v2
    .line 556: invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 559: throw v0
    .line 560: invoke-virtual {v12}, Ljava/io/File;->delete()Z
    .line 563: throw v0
    .line 564: move-exception v0
    .line 565: invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V
    .line 568: throw v0
.end method

# virtual methods
.method public final d()Ljava/lang/String;
    .registers 14

    .line 0: iget-object v0, v13, Lcom/titanchess/accessibility/m1;->a:Landroid/content/Context;
    .line 2: const-string v1, "titan"
    .line 4: const/4 v2, 0
    .line 5: invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 8: move-result-object v1
    .line 9: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    .line 12: move-result-wide v2
    .line 13: const/16 v4, 1000
    .line 15: int-to-long v4, v4
    .line 16: div-long/2addr v2, v4
    .line 17: const-string v4, "lic_token"
    .line 19: const/4 v5, 0
    .line 20: invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 23: move-result-object v6
    .line 24: const-string v7, "lic_token_exp"
    .line 26: const-wide/16 v8, 0
    .line 28: invoke-interface {v1, v7, v8, v9}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J
    .line 31: move-result-wide v7
    .line 32: if-eqz v6, :cond_43
    .line 34: sub-long v9, v7, v2
    .line 36: const-wide/16 v11, 120
    .line 38: cmp-long v9, v9, v11
    .line 40: if-lez v9, :cond_43
    .line 42: return-object v6
    .line 43: const-string v9, "lic_key"
    .line 45: invoke-interface {v1, v9, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 48: move-result-object v9
    .line 49: if-nez v9, :cond_52
    .line 51: return-object v6
    .line 52: sub-long/2addr v7, v2
    .line 53: new-instance v2, Ljava/lang/StringBuilder;
    .line 55: const-string v3, "download-token stale (exp in "
    .line 57: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 60: invoke-virtual {v2, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 63: const-string v3, "s) → re-LOGIN"
    .line 65: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 68: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 71: move-result-object v2
    .line 72: const-string v3, "TitanModelStore"
    .line 74: invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 77: invoke-static {v0, v9}, Lcom/titanchess/accessibility/e;->j(Landroid/content/Context;Ljava/lang/String;)Lcom/titanchess/accessibility/w;
    .line 80: move-result-object v0
    .line 81: goto :goto_87
    .line 82: move-exception v0
    .line 83: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 86: move-result-object v0
    .line 87: instance-of v2, v0, Ls2/f;
    .line 89: if-eqz v2, :cond_92
    .line 91: move-object v0, v5
    .line 92: check-cast v0, Lcom/titanchess/accessibility/w;
    .line 94: if-eqz v0, :cond_100
    .line 96: iget-object v0, v0, Lcom/titanchess/accessibility/w;->e:Ljava/lang/String;
    .line 98: if-nez v0, :cond_104
    .line 100: invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 103: move-result-object v0
    .line 104: return-object v0
.end method

# virtual methods
.method public final e(Ljava/lang/String;Ld3/e;)[B
    .registers 12

    .line 0: const-string v0, "HTTP "
    .line 2: new-instance v1, Ljava/net/URL;
    .line 4: invoke-direct {v1, v10}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    .line 7: invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
    .line 10: move-result-object v1
    .line 11: const-string v2, "null cannot be cast to non-null type java.net.HttpURLConnection"
    .line 13: invoke-static {v1, v2}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: check-cast v1, Ljava/net/HttpURLConnection;
    .line 18: const-string v2, "GET"
    .line 20: invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    .line 23: const v2, 0xea60
    .line 26: invoke-virtual {v1, v2}, Ljava/net/URLConnection;->setConnectTimeout(I)V
    .line 29: invoke-virtual {v1, v2}, Ljava/net/URLConnection;->setReadTimeout(I)V
    .line 32: const-string v2, "User-Agent"
    .line 34: const-string v3, "TitanNative/1 (Android)"
    .line 36: invoke-virtual {v1, v2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    .line 39: invoke-virtual {v9}, Lcom/titanchess/accessibility/m1;->d()Ljava/lang/String;
    .line 42: move-result-object v2
    .line 43: if-eqz v2, :cond_56
    .line 45: const-string v3, "Bearer "
    .line 47: invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 50: move-result-object v2
    .line 51: const-string v3, "Authorization"
    .line 53: invoke-virtual {v1, v3, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    .line 56: invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I
    .line 59: move-result v2
    .line 60: const/16 v3, 200
    .line 62: if-ne v2, v3, :cond_144
    .line 64: invoke-virtual {v1}, Ljava/net/URLConnection;->getContentLengthLong()J
    .line 67: move-result-wide v2
    .line 68: new-instance v10, Ljava/io/ByteArrayOutputStream;
    .line 70: const-wide/16 v4, 0
    .line 72: cmp-long v0, v2, v4
    .line 74: if-lez v0, :cond_78
    .line 76: long-to-int v0, v2
    .line 77: goto :goto_80
    .line 78: const/high16 v0, 0x10
    .line 80: invoke-direct {v10, v0}, Ljava/io/ByteArrayOutputStream;-><init>(I)V
    .line 83: invoke-virtual {v1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;
    .line 86: move-result-object v0
    .line 87: const/high16 v6, 0x1
    .line 89: new-array v6, v6, [B
    .line 91: invoke-virtual {v0, v6}, Ljava/io/InputStream;->read([B)I
    .line 94: move-result v7
    .line 95: if-ltz v7, :cond_119
    .line 97: const/4 v8, 0
    .line 98: invoke-virtual {v10, v6, v8, v7}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    .line 101: int-to-long v7, v7
    .line 102: add-long/2addr v4, v7
    .line 103: if-eqz v11, :cond_91
    .line 105: invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 108: move-result-object v7
    .line 109: invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    .line 112: move-result-object v8
    .line 113: invoke-interface {v11, v7, v8}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 116: goto :goto_91
    .line 117: move-exception v10
    .line 118: goto :goto_138
    .line 119: const/4 v11, 0
    .line 120: invoke-static {v0, v11}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 123: invoke-virtual {v10}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    .line 126: move-result-object v10
    .line 127: const-string v11, "toByteArray(...)"
    .line 129: invoke-static {v10, v11}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 132: invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    .line 135: return-object v10
    .line 136: move-exception v10
    .line 137: goto :goto_178
    .line 138: throw v10
    .line 139: move-exception v11
    .line 140: invoke-static {v0, v10}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 143: throw v11
    .line 144: new-instance v11, Ljava/lang/IllegalStateException;
    .line 146: invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I
    .line 149: move-result v2
    .line 150: new-instance v3, Ljava/lang/StringBuilder;
    .line 152: invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 155: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 158: const-string v0, " for "
    .line 160: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 163: invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 166: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 169: move-result-object v10
    .line 170: invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 173: move-result-object v10
    .line 174: invoke-direct {v11, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 177: throw v11
    .line 178: invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    .line 181: throw v10
.end method

# virtual methods
.method public final f(Ljava/lang/String;)Z
    .registers 6

    .line 0: const-string v0, "band"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-virtual {v4, v5}, Lcom/titanchess/accessibility/m1;->a(Ljava/lang/String;)Ljava/io/File;
    .line 8: move-result-object v0
    .line 9: invoke-virtual {v0}, Ljava/io/File;->isFile()Z
    .line 12: move-result v1
    .line 13: if-eqz v1, :cond_45
    .line 15: invoke-virtual {v0}, Ljava/io/File;->length()J
    .line 18: move-result-wide v0
    .line 19: const-wide/16 v2, 0
    .line 21: cmp-long v0, v0, v2
    .line 23: if-lez v0, :cond_45
    .line 25: invoke-virtual {v4, v5}, Lcom/titanchess/accessibility/m1;->j(Ljava/lang/String;)Ljava/io/File;
    .line 28: move-result-object v5
    .line 29: invoke-virtual {v5}, Ljava/io/File;->isFile()Z
    .line 32: move-result v0
    .line 33: if-eqz v0, :cond_45
    .line 35: invoke-virtual {v5}, Ljava/io/File;->length()J
    .line 38: move-result-wide v0
    .line 39: cmp-long v5, v0, v2
    .line 41: if-lez v5, :cond_45
    .line 43: const/4 v5, 1
    .line 44: goto :goto_46
    .line 45: const/4 v5, 0
    .line 46: return v5
.end method

# virtual methods
.method public final g(Ljava/lang/String;)Z
    .registers 5

    .line 0: const-string v0, "mimic/chessmimic_"
    .line 2: const-string v1, "band"
    .line 4: invoke-static {v4, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 7: invoke-virtual {v3, v4}, Lcom/titanchess/accessibility/m1;->f(Ljava/lang/String;)Z
    .line 10: move-result v1
    .line 11: if-eqz v1, :cond_15
    .line 13: const/4 v4, 1
    .line 14: return v4
    .line 15: iget-object v1, v3, Lcom/titanchess/accessibility/m1;->a:Landroid/content/Context;
    .line 17: invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 20: move-result-object v1
    .line 21: new-instance v2, Ljava/lang/StringBuilder;
    .line 23: invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 26: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 29: const-string v4, ".onnx"
    .line 31: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 34: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 37: move-result-object v4
    .line 38: invoke-virtual {v1, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 41: move-result-object v4
    .line 42: invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    .line 45: sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 47: goto :goto_53
    .line 48: move-exception v4
    .line 49: invoke-static {v4}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 52: move-result-object v4
    .line 53: sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 55: instance-of v1, v4, Ls2/f;
    .line 57: if-eqz v1, :cond_60
    .line 59: move-object v4, v0
    .line 60: check-cast v4, Ljava/lang/Boolean;
    .line 62: invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z
    .line 65: move-result v4
    .line 66: return v4
.end method

# virtual methods
.method public final h(Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    .line 0: const/4 v0, 0
    .line 1: iget-object v1, v5, Lcom/titanchess/accessibility/m1;->c:Lorg/json/JSONObject;
    .line 3: if-nez v1, :cond_28
    .line 5: new-instance v1, Lorg/json/JSONObject;
    .line 7: new-instance v2, Ljava/lang/String;
    .line 9: const-string v3, "https://titan-models.sukhazulusitepu.workers.dev/manifest"
    .line 11: invoke-virtual {v5, v3, v0}, Lcom/titanchess/accessibility/m1;->e(Ljava/lang/String;Ld3/e;)[B
    .line 14: move-result-object v3
    .line 15: sget-object v4, Lm3/a;->a:Ljava/nio/charset/Charset;
    .line 17: invoke-direct {v2, v3, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 20: invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    .line 23: iput-object v1, v5, Lcom/titanchess/accessibility/m1;->c:Lorg/json/JSONObject;
    .line 25: goto :goto_28
    .line 26: move-exception v6
    .line 27: goto :goto_116
    .line 28: const-string v2, "bands"
    .line 30: invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;
    .line 33: move-result-object v1
    .line 34: invoke-virtual {v1}, Lorg/json/JSONArray;->length()I
    .line 37: move-result v2
    .line 38: const/4 v3, 0
    .line 39: invoke-static {v3, v2}, Ld2/b;->r1(II)Lj3/d;
    .line 42: move-result-object v2
    .line 43: new-instance v3, Ljava/util/ArrayList;
    .line 45: invoke-static {v2}, Lc3/d;->C1(Ljava/lang/Iterable;)I
    .line 48: move-result v4
    .line 49: invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 52: invoke-virtual {v2}, Lj3/b;->b()Lj3/c;
    .line 55: move-result-object v2
    .line 56: iget-boolean v4, v2, Lj3/c;->k:Z
    .line 58: if-eqz v4, :cond_72
    .line 60: invoke-virtual {v2}, Lj3/c;->c()I
    .line 63: move-result v4
    .line 64: invoke-virtual {v1, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;
    .line 67: move-result-object v4
    .line 68: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 71: goto :goto_56
    .line 72: invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 75: move-result-object v1
    .line 76: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 79: move-result v2
    .line 80: if-eqz v2, :cond_102
    .line 82: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 85: move-result-object v2
    .line 86: move-object v3, v2
    .line 87: check-cast v3, Lorg/json/JSONObject;
    .line 89: const-string v4, "band"
    .line 91: invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 94: move-result-object v3
    .line 95: invoke-static {v3, v6}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 98: move-result v3
    .line 99: if-eqz v3, :cond_76
    .line 101: goto :goto_103
    .line 102: move-object v2, v0
    .line 103: check-cast v2, Lorg/json/JSONObject;
    .line 105: if-eqz v2, :cond_114
    .line 107: const-string v6, "onnx_sha256"
    .line 109: invoke-virtual {v2, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 112: move-result-object v6
    .line 113: goto :goto_120
    .line 114: move-object v6, v0
    .line 115: goto :goto_120
    .line 116: invoke-static {v6}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 119: move-result-object v6
    .line 120: instance-of v1, v6, Ls2/f;
    .line 122: if-eqz v1, :cond_125
    .line 124: goto :goto_126
    .line 125: move-object v0, v6
    .line 126: check-cast v0, Ljava/lang/String;
    .line 128: return-object v0
.end method

# virtual methods
.method public final i()Z
    .registers 5

    .line 0: new-instance v0, Ljava/io/File;
    .line 2: iget-object v1, v4, Lcom/titanchess/accessibility/m1;->b:Ls2/h;
    .line 4: invoke-virtual {v1}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 7: move-result-object v1
    .line 8: check-cast v1, Ljava/io/File;
    .line 10: const-string v2, "orion.onnx"
    .line 12: invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 15: invoke-virtual {v0}, Ljava/io/File;->isFile()Z
    .line 18: move-result v1
    .line 19: if-eqz v1, :cond_33
    .line 21: invoke-virtual {v0}, Ljava/io/File;->length()J
    .line 24: move-result-wide v0
    .line 25: const-wide/16 v2, 0
    .line 27: cmp-long v0, v0, v2
    .line 29: if-lez v0, :cond_33
    .line 31: const/4 v0, 1
    .line 32: return v0
    .line 33: iget-object v0, v4, Lcom/titanchess/accessibility/m1;->a:Landroid/content/Context;
    .line 35: invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    .line 38: move-result-object v0
    .line 39: const-string v1, "model_kv_int8.onnx"
    .line 41: invoke-virtual {v0, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    .line 44: move-result-object v0
    .line 45: invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    .line 48: sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    .line 50: goto :goto_56
    .line 51: move-exception v0
    .line 52: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 55: move-result-object v0
    .line 56: sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    .line 58: instance-of v2, v0, Ls2/f;
    .line 60: if-eqz v2, :cond_63
    .line 62: move-object v0, v1
    .line 63: check-cast v0, Ljava/lang/Boolean;
    .line 65: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 68: move-result v0
    .line 69: return v0
.end method

# virtual methods
.method public final j(Ljava/lang/String;)Ljava/io/File;
    .registers 6

    .line 0: const-string v0, "band"
    .line 2: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: new-instance v0, Ljava/io/File;
    .line 7: iget-object v1, v4, Lcom/titanchess/accessibility/m1;->b:Ls2/h;
    .line 9: invoke-virtual {v1}, Ls2/h;->getValue()Ljava/lang/Object;
    .line 12: move-result-object v1
    .line 13: check-cast v1, Ljava/io/File;
    .line 15: new-instance v2, Ljava/lang/StringBuilder;
    .line 17: const-string v3, "scalers_"
    .line 19: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 22: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 25: const-string v5, ".json"
    .line 27: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 33: move-result-object v5
    .line 34: invoke-direct {v0, v1, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    .line 37: return-object v0
.end method

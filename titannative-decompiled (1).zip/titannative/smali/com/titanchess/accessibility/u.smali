.class public final Lcom/titanchess/accessibility/u;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:I
.field public c:D

# direct methods
.method public constructor <init>(Ljava/lang/String;ID)V
    .registers 6

    .line 0: const-string v0, "uci"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Lcom/titanchess/accessibility/u;->a:Ljava/lang/String;
    .line 10: iput v3, v1, Lcom/titanchess/accessibility/u;->b:I
    .line 12: iput-wide v4, v1, Lcom/titanchess/accessibility/u;->c:D
    .line 14: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/u;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/u;
    .line 12: iget-object v1, v8, Lcom/titanchess/accessibility/u;->a:Ljava/lang/String;
    .line 14: iget-object v3, v7, Lcom/titanchess/accessibility/u;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v7, Lcom/titanchess/accessibility/u;->b:I
    .line 25: iget v3, v8, Lcom/titanchess/accessibility/u;->b:I
    .line 27: if-eq v1, v3, :cond_30
    .line 29: return v2
    .line 30: iget-wide v3, v7, Lcom/titanchess/accessibility/u;->c:D
    .line 32: iget-wide v5, v8, Lcom/titanchess/accessibility/u;->c:D
    .line 34: invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I
    .line 37: move-result v8
    .line 38: if-eqz v8, :cond_41
    .line 40: return v2
    .line 41: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/u;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lcom/titanchess/accessibility/u;->b:I
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->c(III)I
    .line 14: move-result v0
    .line 15: iget-wide v1, v3, Lcom/titanchess/accessibility/u;->c:D
    .line 17: invoke-static {v1, v2}, Ljava/lang/Double;->hashCode(D)I
    .line 20: move-result v1
    .line 21: add-int/2addr v1, v0
    .line 22: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 5

    .line 0: iget-wide v0, v4, Lcom/titanchess/accessibility/u;->c:D
    .line 2: new-instance v2, Ljava/lang/StringBuilder;
    .line 4: const-string v3, "W(uci="
    .line 6: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 9: iget-object v3, v4, Lcom/titanchess/accessibility/u;->a:Ljava/lang/String;
    .line 11: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 14: const-string v3, ", cpLoss="
    .line 16: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 19: iget v3, v4, Lcom/titanchess/accessibility/u;->b:I
    .line 21: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 24: const-string v3, ", prob="
    .line 26: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 29: invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 32: const-string v0, ")"
    .line 34: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 40: move-result-object v0
    .line 41: return-object v0
.end method

.class public final synthetic Lcom/titanchess/accessibility/u1;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:Lcom/titanchess/accessibility/TitanAccessibilityService;
.field public final synthetic j:Lcom/titanchess/accessibility/a2;
.field public final synthetic k:Ljava/util/List;
.field public final synthetic l:Ljava/lang/String;
.field public final synthetic m:I
.field public final synthetic n:Lp2/n;

# direct methods
.method public synthetic constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;Ljava/util/ArrayList;Ljava/lang/String;ILp2/n;)V
    .registers 7

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/u1;->i:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/u1;->j:Lcom/titanchess/accessibility/a2;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/u1;->k:Ljava/util/List;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/u1;->l:Ljava/lang/String;
    .line 11: iput v5, v0, Lcom/titanchess/accessibility/u1;->m:I
    .line 13: iput-object v6, v0, Lcom/titanchess/accessibility/u1;->n:Lp2/n;
    .line 15: return-void
.end method

# virtual methods
.method public final run()V
    .registers 7

    .line 0: iget-object v0, v6, Lcom/titanchess/accessibility/u1;->i:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 2: iget-object v1, v6, Lcom/titanchess/accessibility/u1;->j:Lcom/titanchess/accessibility/a2;
    .line 4: iget-object v2, v6, Lcom/titanchess/accessibility/u1;->k:Ljava/util/List;
    .line 6: iget-object v3, v6, Lcom/titanchess/accessibility/u1;->l:Ljava/lang/String;
    .line 8: iget v4, v6, Lcom/titanchess/accessibility/u1;->m:I
    .line 10: iget-object v5, v6, Lcom/titanchess/accessibility/u1;->n:Lp2/n;
    .line 12: invoke-static/range {v0 .. v5}, Lcom/titanchess/accessibility/TitanAccessibilityService;->l(Lcom/titanchess/accessibility/TitanAccessibilityService;Lcom/titanchess/accessibility/a2;Ljava/util/List;Ljava/lang/String;ILp2/n;)V
    .line 15: return-void
.end method

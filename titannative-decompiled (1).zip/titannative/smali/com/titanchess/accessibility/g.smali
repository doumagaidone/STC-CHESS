.class public final Lcom/titanchess/accessibility/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lcom/titanchess/accessibility/n1;
.field public final b:Ljava/util/ArrayList;
.field public c:Ljava/util/ArrayList;

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 3

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: new-instance v0, Lcom/titanchess/accessibility/n1;
    .line 10: invoke-direct {v0, v2}, Lcom/titanchess/accessibility/n1;-><init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 13: iput-object v0, v1, Lcom/titanchess/accessibility/g;->a:Lcom/titanchess/accessibility/n1;
    .line 15: new-instance v2, Ljava/util/ArrayList;
    .line 17: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 20: iput-object v2, v1, Lcom/titanchess/accessibility/g;->b:Ljava/util/ArrayList;
    .line 22: new-instance v2, Ljava/util/ArrayList;
    .line 24: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 27: iput-object v2, v1, Lcom/titanchess/accessibility/g;->c:Ljava/util/ArrayList;
    .line 29: return-void
.end method

# virtual methods
.method public final a()V
    .registers 5

    .line 0: iget-object v0, v4, Lcom/titanchess/accessibility/g;->a:Lcom/titanchess/accessibility/n1;
    .line 2: monitor-enter v0
    .line 3: sget-object v1, Lt2/r;->i:Lt2/r;
    .line 5: const/16 v2, 1500
    .line 7: invoke-virtual {v0, v2, v1}, Lcom/titanchess/accessibility/n1;->a(ILjava/util/List;)[J
    .line 10: move-result-object v1
    .line 11: const/4 v2, 1
    .line 12: invoke-virtual {v0, v1, v2}, Lcom/titanchess/accessibility/n1;->e([JI)Ljava/util/ArrayList;
    .line 15: iget-object v1, v0, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 17: invoke-static {v1}, Lcom/titanchess/accessibility/n1;->b(Ljava/util/Map;)V
    .line 20: sget-object v1, Lt2/s;->i:Lt2/s;
    .line 22: iput-object v1, v0, Lcom/titanchess/accessibility/n1;->r:Ljava/util/Map;
    .line 24: const/4 v1, 0
    .line 25: new-array v1, v1, [J
    .line 27: iput-object v1, v0, Lcom/titanchess/accessibility/n1;->q:[J
    .line 29: iget-object v1, v0, Lcom/titanchess/accessibility/n1;->e:Ljava/lang/String;
    .line 31: const-string v2, "warmup done"
    .line 33: invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    .line 36: move-result v1
    .line 37: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 40: move-result-object v1
    .line 41: goto :goto_47
    .line 42: move-exception v1
    .line 43: invoke-static {v1}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 46: move-result-object v1
    .line 47: invoke-static {v1}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 50: move-result-object v1
    .line 51: if-eqz v1, :cond_63
    .line 53: iget-object v2, v0, Lcom/titanchess/accessibility/n1;->e:Ljava/lang/String;
    .line 55: const-string v3, "warmup fail"
    .line 57: invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 60: goto :goto_63
    .line 61: move-exception v1
    .line 62: goto :goto_65
    .line 63: monitor-exit v0
    .line 64: return-void
    .line 65: monitor-exit v0
    .line 66: throw v1
.end method

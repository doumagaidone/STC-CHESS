.class public final Lcom/titanchess/accessibility/TitanGuard;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final $stable:I
.field public static final INSTANCE:Lcom/titanchess/accessibility/TitanGuard;
.field private static ok:Z

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: new-instance v0, Lcom/titanchess/accessibility/TitanGuard;
    .line 2: invoke-direct {v0}, Lcom/titanchess/accessibility/TitanGuard;-><init>()V
    .line 5: sput-object v0, Lcom/titanchess/accessibility/TitanGuard;->INSTANCE:Lcom/titanchess/accessibility/TitanGuard;
    .line 7: const-string v0, "titanguard"
    .line 9: invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    .line 12: sget-object v0, Ls2/k;->a:Ls2/k;
    .line 14: goto :goto_20
    .line 15: move-exception v0
    .line 16: invoke-static {v0}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 19: move-result-object v0
    .line 20: instance-of v1, v0, Ls2/f;
    .line 22: const/4 v2, 1
    .line 23: xor-int/2addr v1, v2
    .line 24: if-eqz v1, :cond_31
    .line 26: move-object v1, v0
    .line 27: check-cast v1, Ls2/k;
    .line 29: sput-boolean v2, Lcom/titanchess/accessibility/TitanGuard;->ok:Z
    .line 31: invoke-static {v0}, Ls2/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;
    .line 34: move-result-object v0
    .line 35: if-eqz v0, :cond_44
    .line 37: const-string v1, "TitanGuard"
    .line 39: const-string v2, "native load failed → fail-open"
    .line 41: invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .line 44: const/16 v0, 8
    .line 46: sput v0, Lcom/titanchess/accessibility/TitanGuard;->$stable:I
    .line 48: return-void
.end method

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method private final native guard(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
.end method

# virtual methods
.method public final check(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 0: const-string v0, "ctx"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "cleanHwid"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: sget-boolean v0, Lcom/titanchess/accessibility/TitanGuard;->ok:Z
    .line 12: if-nez v0, :cond_15
    .line 14: goto :goto_42
    .line 15: invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    .line 18: move-result-object v2
    .line 19: const-string v0, "getApplicationContext(...)"
    .line 21: invoke-static {v2, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 24: invoke-direct {v1, v2, v3}, Lcom/titanchess/accessibility/TitanGuard;->guard(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .line 27: move-result-object v2
    .line 28: goto :goto_34
    .line 29: move-exception v2
    .line 30: invoke-static {v2}, Ld2/c;->G(Ljava/lang/Throwable;)Ls2/f;
    .line 33: move-result-object v2
    .line 34: instance-of v0, v2, Ls2/f;
    .line 36: if-eqz v0, :cond_39
    .line 38: goto :goto_40
    .line 39: move-object v3, v2
    .line 40: check-cast v3, Ljava/lang/String;
    .line 42: return-object v3
.end method

.class public final Lcom/titanchess/accessibility/d;
.super Landroid/view/View;
.source "SourceFile"

.field public volatile i:Ljava/util/List;
.field public volatile j:Lcom/titanchess/accessibility/c;
.field public volatile k:Lcom/titanchess/accessibility/a;
.field public final l:Ljava/util/HashMap;
.field public m:F
.field public n:F
.field public final o:[I
.field public final p:I
.field public final q:I
.field public final r:Landroid/graphics/Paint;
.field public final s:Landroid/graphics/Paint;
.field public final t:Landroid/graphics/Paint;
.field public final u:Landroid/graphics/Paint;
.field public final v:Landroid/graphics/Paint;
.field public final w:Landroid/graphics/Paint;

# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 8

    .line 0: const-string v0, "context"
    .line 2: invoke-static {v7, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v6, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V
    .line 8: sget-object v7, Lt2/r;->i:Lt2/r;
    .line 10: iput-object v7, v6, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 12: new-instance v7, Ljava/util/HashMap;
    .line 14: invoke-direct {v7}, Ljava/util/HashMap;-><init>()V
    .line 17: iput-object v7, v6, Lcom/titanchess/accessibility/d;->l:Ljava/util/HashMap;
    .line 19: const/16 v7, 205
    .line 21: const/4 v0, 0
    .line 22: const/16 v1, 200
    .line 24: const/16 v2, 255
    .line 26: invoke-static {v7, v0, v1, v2}, Landroid/graphics/Color;->argb(IIII)I
    .line 29: move-result v7
    .line 30: const/16 v3, 165
    .line 32: invoke-static {v3, v2, v1, v0}, Landroid/graphics/Color;->argb(IIII)I
    .line 35: move-result v3
    .line 36: const/16 v4, 125
    .line 38: const/16 v5, 60
    .line 40: invoke-static {v4, v2, v5, v5}, Landroid/graphics/Color;->argb(IIII)I
    .line 43: move-result v2
    .line 44: filled-new-array {v7, v3, v2}, [I
    .line 47: move-result-object v7
    .line 48: iput-object v7, v6, Lcom/titanchess/accessibility/d;->o:[I
    .line 50: const/16 v7, 145
    .line 52: const/16 v2, 190
    .line 54: invoke-static {v7, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I
    .line 57: move-result v7
    .line 58: iput v7, v6, Lcom/titanchess/accessibility/d;->p:I
    .line 60: const/16 v7, 230
    .line 62: const/16 v2, 143
    .line 64: const/16 v3, 153
    .line 66: invoke-static {v3, v7, v2, v0}, Landroid/graphics/Color;->argb(IIII)I
    .line 69: move-result v7
    .line 70: iput v7, v6, Lcom/titanchess/accessibility/d;->q:I
    .line 72: new-instance v7, Landroid/graphics/Paint;
    .line 74: const/4 v2, 1
    .line 75: invoke-direct {v7, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 78: sget-object v3, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;
    .line 80: invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V
    .line 83: iput-object v7, v6, Lcom/titanchess/accessibility/d;->r:Landroid/graphics/Paint;
    .line 85: new-instance v7, Landroid/graphics/Paint;
    .line 87: invoke-direct {v7, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 90: const/4 v3, -1
    .line 91: invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setColor(I)V
    .line 94: sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;
    .line 96: invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V
    .line 99: sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;
    .line 101: invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 104: iput-object v7, v6, Lcom/titanchess/accessibility/d;->s:Landroid/graphics/Paint;
    .line 106: new-instance v7, Landroid/graphics/Paint;
    .line 108: invoke-direct {v7, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 111: invoke-static {v1, v0, v0, v0}, Landroid/graphics/Color;->argb(IIII)I
    .line 114: move-result v1
    .line 115: invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setColor(I)V
    .line 118: invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V
    .line 121: invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 124: sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;
    .line 126: invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V
    .line 129: iput-object v7, v6, Lcom/titanchess/accessibility/d;->t:Landroid/graphics/Paint;
    .line 131: new-instance v7, Landroid/graphics/Paint;
    .line 133: invoke-direct {v7, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 136: sget-object v3, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;
    .line 138: invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V
    .line 141: invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 144: iput-object v7, v6, Lcom/titanchess/accessibility/d;->u:Landroid/graphics/Paint;
    .line 146: new-instance v7, Landroid/graphics/Paint;
    .line 148: invoke-direct {v7, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 151: const/16 v5, 220
    .line 153: invoke-static {v5, v0, v0, v0}, Landroid/graphics/Color;->argb(IIII)I
    .line 156: move-result v5
    .line 157: invoke-virtual {v7, v5}, Landroid/graphics/Paint;->setColor(I)V
    .line 160: invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V
    .line 163: invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .line 166: invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V
    .line 169: iput-object v7, v6, Lcom/titanchess/accessibility/d;->v:Landroid/graphics/Paint;
    .line 171: new-instance v7, Landroid/graphics/Paint;
    .line 173: invoke-direct {v7, v2}, Landroid/graphics/Paint;-><init>(I)V
    .line 176: sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;
    .line 178: invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V
    .line 181: iput-object v7, v6, Lcom/titanchess/accessibility/d;->w:Landroid/graphics/Paint;
    .line 183: invoke-virtual {v6, v0}, Landroid/view/View;->setWillNotDraw(Z)V
    .line 186: invoke-virtual {v6, v0}, Landroid/view/View;->setBackgroundColor(I)V
    .line 189: return-void
.end method

# virtual methods
.method public final a()V
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 2: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_9
    .line 8: return-void
    .line 9: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 11: iput-object v0, v1, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 13: invoke-virtual {v1}, Landroid/view/View;->postInvalidateOnAnimation()V
    .line 16: return-void
.end method

# virtual methods
.method public final b(Landroid/graphics/Canvas;FFFDZ)V
    .registers 24

    .line 0: move-object/from16 v0, v16
    .line 2: move-object/from16 v9, v17
    .line 4: const/high16 v1, 0x4220
    .line 6: move/from16 v2, v20
    .line 8: invoke-static {v2, v1}, Ld2/b;->D(FF)F
    .line 11: move-result v1
    .line 12: const v2, 0x3e851eb8
    .line 15: mul-float/2addr v1, v2
    .line 16: const/high16 v2, 0x4190
    .line 18: const/high16 v3, 0x4208
    .line 20: invoke-static {v1, v2, v3}, Ld2/b;->F(FFF)F
    .line 23: move-result v1
    .line 24: const/high16 v2, 0x3f00
    .line 26: mul-float/2addr v2, v1
    .line 27: iget v3, v0, Lcom/titanchess/accessibility/d;->m:F
    .line 29: sub-float v10, v18, v3
    .line 31: iget v3, v0, Lcom/titanchess/accessibility/d;->n:F
    .line 33: sub-float v11, v19, v3
    .line 35: invoke-static/range {v21 .. v22}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    .line 38: move-result-object v3
    .line 39: filled-new-array {v3}, [Ljava/lang/Object;
    .line 42: move-result-object v3
    .line 43: const/4 v4, 1
    .line 44: invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .line 47: move-result-object v3
    .line 48: const-string v4, "%.1f"
    .line 50: invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 53: move-result-object v12
    .line 54: const-string v3, "format(this, *args)"
    .line 56: invoke-static {v12, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 59: iget-object v13, v0, Lcom/titanchess/accessibility/d;->u:Landroid/graphics/Paint;
    .line 61: invoke-virtual {v13, v1}, Landroid/graphics/Paint;->setTextSize(F)V
    .line 64: iget-object v14, v0, Lcom/titanchess/accessibility/d;->v:Landroid/graphics/Paint;
    .line 66: invoke-virtual {v14, v1}, Landroid/graphics/Paint;->setTextSize(F)V
    .line 69: const v3, 0x3e23d70a
    .line 72: mul-float/2addr v3, v1
    .line 73: invoke-virtual {v14, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V
    .line 76: invoke-virtual {v13, v12}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F
    .line 79: move-result v3
    .line 80: iget-object v8, v0, Lcom/titanchess/accessibility/d;->w:Landroid/graphics/Paint;
    .line 82: const/16 v4, 18
    .line 84: const/16 v5, 28
    .line 86: const/16 v6, 210
    .line 88: const/16 v7, 20
    .line 90: invoke-static {v6, v7, v4, v5}, Landroid/graphics/Color;->argb(IIII)I
    .line 93: move-result v4
    .line 94: invoke-virtual {v8, v4}, Landroid/graphics/Paint;->setColor(I)V
    .line 97: sub-float v4, v10, v2
    .line 99: sub-float v5, v11, v1
    .line 101: add-float/2addr v3, v10
    .line 102: add-float v6, v3, v2
    .line 104: const v3, 0x3f19999a
    .line 107: mul-float/2addr v2, v3
    .line 108: add-float v7, v2, v11
    .line 110: const v2, 0x3ecccccd
    .line 113: mul-float v15, v1, v2
    .line 115: move-object/from16 v1, v17
    .line 117: move v2, v4
    .line 118: move v3, v5
    .line 119: move v4, v6
    .line 120: move v5, v7
    .line 121: move v6, v15
    .line 122: move v7, v15
    .line 123: invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V
    .line 126: invoke-virtual {v9, v12, v10, v11, v14}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V
    .line 129: if-eqz v23, :cond_134
    .line 131: const/16 v1, -16338
    .line 133: goto :goto_137
    .line 134: const v1, 0xffff4d9d
    .line 137: invoke-virtual {v13, v1}, Landroid/graphics/Paint;->setColor(I)V
    .line 140: invoke-virtual {v9, v12, v10, v11, v13}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V
    .line 143: return-void
.end method

# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .registers 26

    .line 0: move-object/from16 v8, v24
    .line 2: move-object/from16 v9, v25
    .line 4: const-string v0, "canvas"
    .line 6: invoke-static {v9, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 9: const/4 v6, 2
    .line 10: new-array v0, v6, [I
    .line 12: invoke-virtual {v8, v0}, Landroid/view/View;->getLocationOnScreen([I)V
    .line 15: const/4 v7, 0
    .line 16: aget v1, v0, v7
    .line 18: int-to-float v1, v1
    .line 19: iput v1, v8, Lcom/titanchess/accessibility/d;->m:F
    .line 21: const/4 v10, 1
    .line 22: aget v0, v0, v10
    .line 24: int-to-float v0, v0
    .line 25: iput v0, v8, Lcom/titanchess/accessibility/d;->n:F
    .line 27: iget-object v0, v8, Lcom/titanchess/accessibility/d;->i:Ljava/util/List;
    .line 29: invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 32: move-result-object v11
    .line 33: invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z
    .line 36: move-result v0
    .line 37: if-eqz v0, :cond_365
    .line 39: invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 42: move-result-object v0
    .line 43: move-object v13, v0
    .line 44: check-cast v13, Lcom/titanchess/accessibility/b;
    .line 46: iget v0, v13, Lcom/titanchess/accessibility/b;->a:F
    .line 48: iget v1, v8, Lcom/titanchess/accessibility/d;->m:F
    .line 50: sub-float v2, v0, v1
    .line 52: iget v0, v13, Lcom/titanchess/accessibility/b;->b:F
    .line 54: iget v3, v8, Lcom/titanchess/accessibility/d;->n:F
    .line 56: sub-float v4, v0, v3
    .line 58: iget v0, v13, Lcom/titanchess/accessibility/b;->c:F
    .line 60: sub-float v14, v0, v1
    .line 62: iget v0, v13, Lcom/titanchess/accessibility/b;->d:F
    .line 64: sub-float v15, v0, v3
    .line 66: iget v0, v13, Lcom/titanchess/accessibility/b;->e:I
    .line 68: if-nez v0, :cond_74
    .line 70: iget v0, v8, Lcom/titanchess/accessibility/d;->p:I
    .line 72: move v5, v0
    .line 73: goto :goto_94
    .line 74: iget-boolean v1, v13, Lcom/titanchess/accessibility/b;->h:Z
    .line 76: if-eqz v1, :cond_81
    .line 78: iget v0, v8, Lcom/titanchess/accessibility/d;->q:I
    .line 80: goto :goto_72
    .line 81: iget-object v1, v8, Lcom/titanchess/accessibility/d;->o:[I
    .line 83: add-int/lit8 v0, v0, -1
    .line 85: array-length v3, v1
    .line 86: sub-int/2addr v3, v10
    .line 87: invoke-static {v0, v7, v3}, Ld2/b;->G(III)I
    .line 90: move-result v0
    .line 91: aget v0, v1, v0
    .line 93: goto :goto_72
    .line 94: iget-object v0, v8, Lcom/titanchess/accessibility/d;->r:Landroid/graphics/Paint;
    .line 96: invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setColor(I)V
    .line 99: iget-object v0, v8, Lcom/titanchess/accessibility/d;->r:Landroid/graphics/Paint;
    .line 101: sget-object v1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;
    .line 103: invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V
    .line 106: iget v0, v13, Lcom/titanchess/accessibility/b;->g:F
    .line 108: const/high16 v1, 0x3e20
    .line 110: mul-float v3, v0, v1
    .line 112: iget-object v0, v8, Lcom/titanchess/accessibility/d;->r:Landroid/graphics/Paint;
    .line 114: invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V
    .line 117: sub-float v0, v15, v4
    .line 119: float-to-double v0, v0
    .line 120: sub-float v7, v14, v2
    .line 122: float-to-double v6, v7
    .line 123: invoke-static {v0, v1, v6, v7}, Ljava/lang/Math;->atan2(DD)D
    .line 126: move-result-wide v6
    .line 127: const v0, 0x40266666
    .line 130: mul-float/2addr v0, v3
    .line 131: const v1, 0x3fa66666
    .line 134: mul-float/2addr v1, v3
    .line 135: move-object/from16 v16, v11
    .line 137: float-to-double v10, v14
    .line 138: move-object/from16 v17, v13
    .line 140: float-to-double v12, v0
    .line 141: invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D
    .line 144: move-result-wide v18
    .line 145: mul-double v18, v18, v12
    .line 147: move/from16 v20, v1
    .line 149: sub-double v0, v10, v18
    .line 151: double-to-float v1, v0
    .line 152: move-wide/from16 v18, v10
    .line 154: float-to-double v10, v15
    .line 155: invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D
    .line 158: move-result-wide v21
    .line 159: mul-double v21, v21, v12
    .line 161: sub-double v12, v10, v21
    .line 163: double-to-float v12, v12
    .line 164: iget-object v13, v8, Lcom/titanchess/accessibility/d;->r:Landroid/graphics/Paint;
    .line 166: move-object/from16 v0, v25
    .line 168: move-wide/from16 v21, v10
    .line 170: move/from16 v10, v20
    .line 172: move v11, v1
    .line 173: move v1, v2
    .line 174: move v2, v4
    .line 175: move/from16 v20, v3
    .line 177: move v3, v11
    .line 178: move v4, v12
    .line 179: move/from16 v23, v5
    .line 181: move-object v5, v13
    .line 182: invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V
    .line 185: new-instance v0, Landroid/graphics/Path;
    .line 187: invoke-direct {v0}, Landroid/graphics/Path;-><init>()V
    .line 190: invoke-virtual {v0, v14, v15}, Landroid/graphics/Path;->moveTo(FF)V
    .line 193: float-to-double v1, v11
    .line 194: float-to-double v3, v10
    .line 195: invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D
    .line 198: move-result-wide v10
    .line 199: mul-double/2addr v10, v3
    .line 200: sub-double v10, v1, v10
    .line 202: double-to-float v5, v10
    .line 203: float-to-double v10, v12
    .line 204: invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D
    .line 207: move-result-wide v12
    .line 208: mul-double/2addr v12, v3
    .line 209: add-double/2addr v12, v10
    .line 210: double-to-float v12, v12
    .line 211: invoke-virtual {v0, v5, v12}, Landroid/graphics/Path;->lineTo(FF)V
    .line 214: invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D
    .line 217: move-result-wide v12
    .line 218: mul-double/2addr v12, v3
    .line 219: add-double/2addr v12, v1
    .line 220: double-to-float v1, v12
    .line 221: invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D
    .line 224: move-result-wide v12
    .line 225: mul-double/2addr v12, v3
    .line 226: sub-double/2addr v10, v12
    .line 227: double-to-float v2, v10
    .line 228: invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V
    .line 231: invoke-virtual {v0}, Landroid/graphics/Path;->close()V
    .line 234: iget-object v1, v8, Lcom/titanchess/accessibility/d;->r:Landroid/graphics/Paint;
    .line 236: invoke-virtual {v9, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V
    .line 239: move-object/from16 v0, v17
    .line 241: iget v1, v0, Lcom/titanchess/accessibility/b;->f:F
    .line 243: const/4 v2, 0
    .line 244: cmpl-float v2, v1, v2
    .line 246: if-lez v2, :cond_358
    .line 248: const/16 v2, 100
    .line 250: int-to-float v2, v2
    .line 251: mul-float/2addr v1, v2
    .line 252: float-to-int v1, v1
    .line 253: new-instance v2, Ljava/lang/StringBuilder;
    .line 255: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    .line 258: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 261: const-string v1, "%"
    .line 263: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 266: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 269: move-result-object v1
    .line 270: iget v2, v0, Lcom/titanchess/accessibility/b;->g:F
    .line 272: const v3, 0x3e99999a
    .line 275: mul-float/2addr v2, v3
    .line 276: const/high16 v3, 0x41b0
    .line 278: const/high16 v4, 0x4220
    .line 280: invoke-static {v2, v3, v4}, Ld2/b;->F(FFF)F
    .line 283: move-result v2
    .line 284: iget-object v3, v8, Lcom/titanchess/accessibility/d;->s:Landroid/graphics/Paint;
    .line 286: invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setTextSize(F)V
    .line 289: iget-object v3, v8, Lcom/titanchess/accessibility/d;->t:Landroid/graphics/Paint;
    .line 291: invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setTextSize(F)V
    .line 294: iget-object v3, v8, Lcom/titanchess/accessibility/d;->t:Landroid/graphics/Paint;
    .line 296: const v4, 0x3e0f5c29
    .line 299: mul-float/2addr v4, v2
    .line 300: invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V
    .line 303: const v3, 0x3f99999a
    .line 306: mul-float v3, v3, v20
    .line 308: const/high16 v4, 0x4100
    .line 310: add-float/2addr v3, v4
    .line 311: float-to-double v3, v3
    .line 312: invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D
    .line 315: move-result-wide v10
    .line 316: mul-double/2addr v10, v3
    .line 317: add-double v10, v10, v18
    .line 319: double-to-float v5, v10
    .line 320: invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D
    .line 323: move-result-wide v6
    .line 324: mul-double/2addr v6, v3
    .line 325: add-double v6, v6, v21
    .line 327: double-to-float v3, v6
    .line 328: iget v0, v0, Lcom/titanchess/accessibility/b;->e:I
    .line 330: const/4 v4, 1
    .line 331: sub-int/2addr v0, v4
    .line 332: int-to-float v0, v0
    .line 333: const v4, 0x3f333333
    .line 336: mul-float/2addr v2, v4
    .line 337: mul-float/2addr v2, v0
    .line 338: add-float/2addr v2, v3
    .line 339: iget-object v0, v8, Lcom/titanchess/accessibility/d;->t:Landroid/graphics/Paint;
    .line 341: invoke-virtual {v9, v1, v5, v2, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V
    .line 344: iget-object v0, v8, Lcom/titanchess/accessibility/d;->s:Landroid/graphics/Paint;
    .line 346: const/high16 v3, 0xff00
    .line 348: or-int v3, v23, v3
    .line 350: invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V
    .line 353: iget-object v0, v8, Lcom/titanchess/accessibility/d;->s:Landroid/graphics/Paint;
    .line 355: invoke-virtual {v9, v1, v5, v2, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V
    .line 358: move-object/from16 v11, v16
    .line 360: const/4 v6, 2
    .line 361: const/4 v7, 0
    .line 362: const/4 v10, 1
    .line 363: goto/16 :goto_33
    .line 365: iget-object v0, v8, Lcom/titanchess/accessibility/d;->j:Lcom/titanchess/accessibility/c;
    .line 367: if-eqz v0, :cond_469
    .line 369: iget-object v1, v0, Lcom/titanchess/accessibility/c;->c:Ljava/lang/String;
    .line 371: iget-object v2, v8, Lcom/titanchess/accessibility/d;->l:Ljava/util/HashMap;
    .line 373: invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 376: move-result-object v3
    .line 377: const/4 v4, 0
    .line 378: if-nez v3, :cond_413
    .line 380: invoke-virtual/range {v24 .. v24}, Landroid/view/View;->getResources()Landroid/content/res/Resources;
    .line 383: move-result-object v3
    .line 384: invoke-virtual/range {v24 .. v24}, Landroid/view/View;->getContext()Landroid/content/Context;
    .line 387: move-result-object v5
    .line 388: invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    .line 391: move-result-object v5
    .line 392: const-string v6, "drawable"
    .line 394: invoke-virtual {v3, v1, v6, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    .line 397: move-result v3
    .line 398: if-nez v3, :cond_402
    .line 400: move-object v3, v4
    .line 401: goto :goto_410
    .line 402: invoke-virtual/range {v24 .. v24}, Landroid/view/View;->getResources()Landroid/content/res/Resources;
    .line 405: move-result-object v5
    .line 406: invoke-static {v5, v3}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;
    .line 409: move-result-object v3
    .line 410: invoke-virtual {v2, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 413: check-cast v3, Landroid/graphics/Bitmap;
    .line 415: if-nez v3, :cond_418
    .line 417: goto :goto_469
    .line 418: iget v1, v0, Lcom/titanchess/accessibility/c;->d:F
    .line 420: const v2, 0x3ed70a3d
    .line 423: mul-float/2addr v1, v2
    .line 424: const/high16 v2, 0x41e0
    .line 426: const/high16 v5, 0x4280
    .line 428: invoke-static {v1, v2, v5}, Ld2/b;->F(FFF)F
    .line 431: move-result v1
    .line 432: iget v2, v0, Lcom/titanchess/accessibility/c;->a:F
    .line 434: iget v5, v8, Lcom/titanchess/accessibility/d;->m:F
    .line 436: sub-float/2addr v2, v5
    .line 437: iget v5, v0, Lcom/titanchess/accessibility/c;->d:F
    .line 439: const v6, 0x3e99999a
    .line 442: mul-float v12, v5, v6
    .line 444: add-float/2addr v12, v2
    .line 445: iget v0, v0, Lcom/titanchess/accessibility/c;->b:F
    .line 447: iget v2, v8, Lcom/titanchess/accessibility/d;->n:F
    .line 449: sub-float/2addr v0, v2
    .line 450: mul-float/2addr v5, v6
    .line 451: sub-float/2addr v0, v5
    .line 452: new-instance v2, Landroid/graphics/RectF;
    .line 454: const/4 v5, 2
    .line 455: int-to-float v5, v5
    .line 456: div-float/2addr v1, v5
    .line 457: sub-float v5, v12, v1
    .line 459: sub-float v6, v0, v1
    .line 461: add-float/2addr v12, v1
    .line 462: add-float/2addr v0, v1
    .line 463: invoke-direct {v2, v5, v6, v12, v0}, Landroid/graphics/RectF;-><init>(FFFF)V
    .line 466: invoke-virtual {v9, v3, v4, v2, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    .line 469: iget-object v10, v8, Lcom/titanchess/accessibility/d;->k:Lcom/titanchess/accessibility/a;
    .line 471: if-eqz v10, :cond_510
    .line 473: iget v2, v10, Lcom/titanchess/accessibility/a;->a:F
    .line 475: iget v3, v10, Lcom/titanchess/accessibility/a;->b:F
    .line 477: iget v4, v10, Lcom/titanchess/accessibility/a;->e:F
    .line 479: iget-wide v5, v10, Lcom/titanchess/accessibility/a;->f:D
    .line 481: iget-boolean v7, v10, Lcom/titanchess/accessibility/a;->h:Z
    .line 483: move-object/from16 v0, v24
    .line 485: move-object/from16 v1, v25
    .line 487: invoke-virtual/range {v0 .. v7}, Lcom/titanchess/accessibility/d;->b(Landroid/graphics/Canvas;FFFDZ)V
    .line 490: iget v2, v10, Lcom/titanchess/accessibility/a;->c:F
    .line 492: iget v3, v10, Lcom/titanchess/accessibility/a;->d:F
    .line 494: iget v4, v10, Lcom/titanchess/accessibility/a;->e:F
    .line 496: iget-wide v5, v10, Lcom/titanchess/accessibility/a;->g:D
    .line 498: iget-boolean v0, v10, Lcom/titanchess/accessibility/a;->h:Z
    .line 500: const/4 v1, 1
    .line 501: xor-int/lit8 v7, v0, 1
    .line 503: move-object/from16 v0, v24
    .line 505: move-object/from16 v1, v25
    .line 507: invoke-virtual/range {v0 .. v7}, Lcom/titanchess/accessibility/d;->b(Landroid/graphics/Canvas;FFFDZ)V
    .line 510: return-void
.end method

.class public final synthetic Lcom/titanchess/accessibility/y1;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:Lcom/titanchess/accessibility/TitanAccessibilityService;
.field public final synthetic j:Ljava/lang/String;
.field public final synthetic k:Lcom/titanchess/accessibility/a2;
.field public final synthetic l:Lp2/n;
.field public final synthetic m:I
.field public final synthetic n:Z
.field public final synthetic o:Ljava/util/List;

# direct methods
.method public synthetic constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;IZLjava/util/List;)V
    .registers 8

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/y1;->i:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/y1;->j:Ljava/lang/String;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/y1;->k:Lcom/titanchess/accessibility/a2;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/y1;->l:Lp2/n;
    .line 11: iput v5, v0, Lcom/titanchess/accessibility/y1;->m:I
    .line 13: iput-boolean v6, v0, Lcom/titanchess/accessibility/y1;->n:Z
    .line 15: iput-object v7, v0, Lcom/titanchess/accessibility/y1;->o:Ljava/util/List;
    .line 17: return-void
.end method

# virtual methods
.method public final run()V
    .registers 8

    .line 0: iget-object v0, v7, Lcom/titanchess/accessibility/y1;->i:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 2: iget-object v1, v7, Lcom/titanchess/accessibility/y1;->j:Ljava/lang/String;
    .line 4: iget-object v2, v7, Lcom/titanchess/accessibility/y1;->k:Lcom/titanchess/accessibility/a2;
    .line 6: iget-object v3, v7, Lcom/titanchess/accessibility/y1;->l:Lp2/n;
    .line 8: iget v4, v7, Lcom/titanchess/accessibility/y1;->m:I
    .line 10: iget-boolean v5, v7, Lcom/titanchess/accessibility/y1;->n:Z
    .line 12: iget-object v6, v7, Lcom/titanchess/accessibility/y1;->o:Ljava/util/List;
    .line 14: invoke-static/range {v0 .. v6}, Lcom/titanchess/accessibility/TitanAccessibilityService;->m(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/lang/String;Lcom/titanchess/accessibility/a2;Lp2/n;IZLjava/util/List;)V
    .line 17: return-void
.end method

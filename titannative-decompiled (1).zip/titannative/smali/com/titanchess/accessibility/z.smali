.class public final Lcom/titanchess/accessibility/z;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/lang/String;
.field public final c:I
.field public final d:J

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;IJ)V
    .registers 6

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/z;->a:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/z;->b:Ljava/lang/String;
    .line 7: iput v3, v0, Lcom/titanchess/accessibility/z;->c:I
    .line 9: iput-wide v4, v0, Lcom/titanchess/accessibility/z;->d:J
    .line 11: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/z;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/z;
    .line 12: iget-object v1, v8, Lcom/titanchess/accessibility/z;->a:Ljava/lang/String;
    .line 14: iget-object v3, v7, Lcom/titanchess/accessibility/z;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v7, Lcom/titanchess/accessibility/z;->b:Ljava/lang/String;
    .line 25: iget-object v3, v8, Lcom/titanchess/accessibility/z;->b:Ljava/lang/String;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget v1, v7, Lcom/titanchess/accessibility/z;->c:I
    .line 36: iget v3, v8, Lcom/titanchess/accessibility/z;->c:I
    .line 38: if-eq v1, v3, :cond_41
    .line 40: return v2
    .line 41: iget-wide v3, v7, Lcom/titanchess/accessibility/z;->d:J
    .line 43: iget-wide v5, v8, Lcom/titanchess/accessibility/z;->d:J
    .line 45: cmp-long v8, v3, v5
    .line 47: if-eqz v8, :cond_50
    .line 49: return v2
    .line 50: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/z;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget-object v2, v3, Lcom/titanchess/accessibility/z;->b:Ljava/lang/String;
    .line 11: invoke-virtual {v2}, Ljava/lang/String;->hashCode()I
    .line 14: move-result v2
    .line 15: add-int/2addr v2, v0
    .line 16: mul-int/2addr v2, v1
    .line 17: iget v0, v3, Lcom/titanchess/accessibility/z;->c:I
    .line 19: invoke-static {v0, v2, v1}, Lai/onnxruntime/b;->c(III)I
    .line 22: move-result v0
    .line 23: iget-wide v1, v3, Lcom/titanchess/accessibility/z;->d:J
    .line 25: invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I
    .line 28: move-result v1
    .line 29: add-int/2addr v1, v0
    .line 30: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "LiveStatus(tc="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v3, Lcom/titanchess/accessibility/z;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", arrow="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Lcom/titanchess/accessibility/z;->b:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", ms="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v3, Lcom/titanchess/accessibility/z;->c:I
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", stamp="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-wide v1, v3, Lcom/titanchess/accessibility/z;->d:J
    .line 39: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ")"
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 50: move-result-object v0
    .line 51: return-object v0
.end method

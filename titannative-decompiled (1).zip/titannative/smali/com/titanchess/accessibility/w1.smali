.class public final synthetic Lcom/titanchess/accessibility/w1;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final synthetic j:Lcom/titanchess/accessibility/TitanAccessibilityService;
.field public final synthetic k:Ljava/util/List;

# direct methods
.method public synthetic constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;I)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v3, v0, Lcom/titanchess/accessibility/w1;->i:I
    .line 5: iput-object v1, v0, Lcom/titanchess/accessibility/w1;->j:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 7: iput-object v2, v0, Lcom/titanchess/accessibility/w1;->k:Ljava/util/List;
    .line 9: return-void
.end method

# virtual methods
.method public final run()V
    .registers 4

    .line 0: iget v0, v3, Lcom/titanchess/accessibility/w1;->i:I
    .line 2: iget-object v1, v3, Lcom/titanchess/accessibility/w1;->k:Ljava/util/List;
    .line 4: iget-object v2, v3, Lcom/titanchess/accessibility/w1;->j:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 6: packed-switch v0, :data_18
    .line 9: invoke-static {v2, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->i(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .line 12: return-void
    .line 13: invoke-static {v2, v1}, Lcom/titanchess/accessibility/TitanAccessibilityService;->g(Lcom/titanchess/accessibility/TitanAccessibilityService;Ljava/util/List;)V
    .line 16: return-void
    .line 17: nop
    .line 18: nop
    .line 19: move v0, v0
    .line 20: nop
    .line 21: nop
    .line 22: move-object v0, v0
    .line 23: nop
.end method

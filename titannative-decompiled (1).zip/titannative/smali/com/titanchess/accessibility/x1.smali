.class public final synthetic Lcom/titanchess/accessibility/x1;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/lang/Runnable;

.field public final synthetic i:I
.field public final synthetic j:Z
.field public final synthetic k:Lcom/titanchess/accessibility/TitanAccessibilityService;

# direct methods
.method public synthetic constructor <init>(ZLcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v3, v0, Lcom/titanchess/accessibility/x1;->i:I
    .line 5: iput-boolean v1, v0, Lcom/titanchess/accessibility/x1;->j:Z
    .line 7: iput-object v2, v0, Lcom/titanchess/accessibility/x1;->k:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 9: return-void
.end method

# virtual methods
.method public final run()V
    .registers 4

    .line 0: iget v0, v3, Lcom/titanchess/accessibility/x1;->i:I
    .line 2: iget-boolean v1, v3, Lcom/titanchess/accessibility/x1;->j:Z
    .line 4: iget-object v2, v3, Lcom/titanchess/accessibility/x1;->k:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 6: packed-switch v0, :data_38
    .line 9: sget v0, Lcom/titanchess/accessibility/d2;->b:I
    .line 11: const-string v0, "this$0"
    .line 13: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: invoke-static {v2}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getFloating$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Lcom/titanchess/accessibility/s;
    .line 19: move-result-object v0
    .line 20: if-eqz v1, :cond_28
    .line 22: if-eqz v0, :cond_33
    .line 24: invoke-virtual {v0}, Lcom/titanchess/accessibility/s;->d()V
    .line 27: goto :goto_33
    .line 28: if-eqz v0, :cond_33
    .line 30: invoke-virtual {v0}, Lcom/titanchess/accessibility/s;->h()V
    .line 33: return-void
    .line 34: invoke-static {v1, v2}, Lcom/titanchess/accessibility/TitanAccessibilityService;->c(ZLcom/titanchess/accessibility/TitanAccessibilityService;)V
    .line 37: return-void
    .line 38: nop
    .line 39: move v0, v0
    .line 40: nop
    .line 41: nop
    .line 42: const-class v0, B
.end method

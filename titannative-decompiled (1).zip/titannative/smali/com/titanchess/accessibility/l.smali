.class public final synthetic Lcom/titanchess/accessibility/l;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;

.field public final synthetic a:I
.field public final synthetic b:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lcom/titanchess/accessibility/l;->a:I
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/l;->b:Ljava/lang/Object;
    .line 7: return-void
.end method

# virtual methods
.method public final onSharedPreferenceChanged(Landroid/content/SharedPreferences;Ljava/lang/String;)V
    .registers 10

    .line 0: const-string v0, "A"
    .line 2: iget v1, v7, Lcom/titanchess/accessibility/l;->a:I
    .line 4: const/16 v2, 1500
    .line 6: const-string v3, "elo"
    .line 8: const-string v4, "model"
    .line 10: iget-object v5, v7, Lcom/titanchess/accessibility/l;->b:Ljava/lang/Object;
    .line 12: packed-switch v1, :data_144
    .line 15: check-cast v5, Lu/j1;
    .line 17: const-string v1, "$elo$delegate"
    .line 19: invoke-static {v5, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 22: invoke-interface {v8, v4, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 25: move-result-object v0
    .line 26: invoke-interface {v8, v3, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 29: move-result v8
    .line 30: invoke-static {v9, v8, v0}, Lcom/titanchess/accessibility/i1;->C(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/Integer;
    .line 33: move-result-object v8
    .line 34: if-eqz v8, :cond_45
    .line 36: invoke-virtual {v8}, Ljava/lang/Number;->intValue()I
    .line 39: move-result v8
    .line 40: check-cast v5, Lu/a3;
    .line 42: invoke-virtual {v5, v8}, Lu/a3;->g(I)V
    .line 45: return-void
    .line 46: check-cast v5, Lcom/titanchess/accessibility/s;
    .line 48: const-string v1, "this$0"
    .line 50: invoke-static {v5, v1}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 53: if-eqz v9, :cond_143
    .line 55: invoke-virtual {v9}, Ljava/lang/String;->hashCode()I
    .line 58: move-result v1
    .line 59: const v6, 0x188a8
    .line 62: if-eq v1, v6, :cond_85
    .line 64: const v8, 0x633fb29
    .line 67: if-eq v1, v8, :cond_70
    .line 69: goto :goto_143
    .line 70: invoke-virtual {v9, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 73: move-result v8
    .line 74: if-nez v8, :cond_77
    .line 76: goto :goto_143
    .line 77: iget-object v8, v5, Lcom/titanchess/accessibility/s;->e:Landroid/widget/FrameLayout;
    .line 79: if-eqz v8, :cond_143
    .line 81: invoke-virtual {v5}, Lcom/titanchess/accessibility/s;->g()V
    .line 84: goto :goto_143
    .line 85: invoke-virtual {v9, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 88: move-result v9
    .line 89: if-nez v9, :cond_92
    .line 91: goto :goto_143
    .line 92: sget-object v9, Lcom/titanchess/accessibility/MainActivity;->Companion:Lcom/titanchess/accessibility/a0;
    .line 94: iget-object v1, v5, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 96: invoke-interface {v1, v4, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .line 99: move-result-object v0
    .line 100: invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 103: invoke-static {v0}, Lcom/titanchess/accessibility/a0;->a(Ljava/lang/String;)Ls2/e;
    .line 106: move-result-object v9
    .line 107: iget-object v0, v9, Ls2/e;->i:Ljava/lang/Object;
    .line 109: check-cast v0, Ljava/lang/Number;
    .line 111: invoke-virtual {v0}, Ljava/lang/Number;->intValue()I
    .line 114: move-result v0
    .line 115: iget-object v9, v9, Ls2/e;->j:Ljava/lang/Object;
    .line 117: check-cast v9, Ljava/lang/Number;
    .line 119: invoke-virtual {v9}, Ljava/lang/Number;->intValue()I
    .line 122: move-result v9
    .line 123: iget-object v1, v5, Lcom/titanchess/accessibility/s;->j:Landroid/widget/TextView;
    .line 125: if-nez v1, :cond_128
    .line 127: goto :goto_143
    .line 128: invoke-interface {v8, v3, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    .line 131: move-result v8
    .line 132: invoke-static {v8, v0, v9}, Ld2/b;->G(III)I
    .line 135: move-result v8
    .line 136: invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 139: move-result-object v8
    .line 140: invoke-virtual {v1, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    .line 143: return-void
    .line 144: nop
    .line 145: move v0, v0
    .line 146: nop
    .line 147: nop
    .line 148: new-instance v0, B
.end method

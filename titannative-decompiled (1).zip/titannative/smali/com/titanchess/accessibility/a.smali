.class public final Lcom/titanchess/accessibility/a;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:F
.field public final b:F
.field public final c:F
.field public final d:F
.field public final e:F
.field public final f:D
.field public final g:D
.field public final h:Z

# direct methods
.method public constructor <init>(FFFFFDDZ)V
    .registers 11

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lcom/titanchess/accessibility/a;->a:F
    .line 5: iput v2, v0, Lcom/titanchess/accessibility/a;->b:F
    .line 7: iput v3, v0, Lcom/titanchess/accessibility/a;->c:F
    .line 9: iput v4, v0, Lcom/titanchess/accessibility/a;->d:F
    .line 11: iput v5, v0, Lcom/titanchess/accessibility/a;->e:F
    .line 13: iput-wide v6, v0, Lcom/titanchess/accessibility/a;->f:D
    .line 15: iput-wide v8, v0, Lcom/titanchess/accessibility/a;->g:D
    .line 17: iput-boolean v10, v0, Lcom/titanchess/accessibility/a;->h:Z
    .line 19: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .line 0: const/4 v0, 1
    .line 1: if-ne v7, v8, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v8, Lcom/titanchess/accessibility/a;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v8, Lcom/titanchess/accessibility/a;
    .line 12: iget v1, v8, Lcom/titanchess/accessibility/a;->a:F
    .line 14: iget v3, v7, Lcom/titanchess/accessibility/a;->a:F
    .line 16: invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I
    .line 19: move-result v1
    .line 20: if-eqz v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v7, Lcom/titanchess/accessibility/a;->b:F
    .line 25: iget v3, v8, Lcom/titanchess/accessibility/a;->b:F
    .line 27: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 30: move-result v1
    .line 31: if-eqz v1, :cond_34
    .line 33: return v2
    .line 34: iget v1, v7, Lcom/titanchess/accessibility/a;->c:F
    .line 36: iget v3, v8, Lcom/titanchess/accessibility/a;->c:F
    .line 38: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 41: move-result v1
    .line 42: if-eqz v1, :cond_45
    .line 44: return v2
    .line 45: iget v1, v7, Lcom/titanchess/accessibility/a;->d:F
    .line 47: iget v3, v8, Lcom/titanchess/accessibility/a;->d:F
    .line 49: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 52: move-result v1
    .line 53: if-eqz v1, :cond_56
    .line 55: return v2
    .line 56: iget v1, v7, Lcom/titanchess/accessibility/a;->e:F
    .line 58: iget v3, v8, Lcom/titanchess/accessibility/a;->e:F
    .line 60: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 63: move-result v1
    .line 64: if-eqz v1, :cond_67
    .line 66: return v2
    .line 67: iget-wide v3, v7, Lcom/titanchess/accessibility/a;->f:D
    .line 69: iget-wide v5, v8, Lcom/titanchess/accessibility/a;->f:D
    .line 71: invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I
    .line 74: move-result v1
    .line 75: if-eqz v1, :cond_78
    .line 77: return v2
    .line 78: iget-wide v3, v7, Lcom/titanchess/accessibility/a;->g:D
    .line 80: iget-wide v5, v8, Lcom/titanchess/accessibility/a;->g:D
    .line 82: invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I
    .line 85: move-result v1
    .line 86: if-eqz v1, :cond_89
    .line 88: return v2
    .line 89: iget-boolean v1, v7, Lcom/titanchess/accessibility/a;->h:Z
    .line 91: iget-boolean v8, v8, Lcom/titanchess/accessibility/a;->h:Z
    .line 93: if-eq v1, v8, :cond_96
    .line 95: return v2
    .line 96: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 6

    .line 0: iget v0, v5, Lcom/titanchess/accessibility/a;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v5, Lcom/titanchess/accessibility/a;->b:F
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 14: move-result v0
    .line 15: iget v2, v5, Lcom/titanchess/accessibility/a;->c:F
    .line 17: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 20: move-result v0
    .line 21: iget v2, v5, Lcom/titanchess/accessibility/a;->d:F
    .line 23: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 26: move-result v0
    .line 27: iget v2, v5, Lcom/titanchess/accessibility/a;->e:F
    .line 29: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 32: move-result v0
    .line 33: iget-wide v2, v5, Lcom/titanchess/accessibility/a;->f:D
    .line 35: invoke-static {v2, v3}, Ljava/lang/Double;->hashCode(D)I
    .line 38: move-result v2
    .line 39: add-int/2addr v2, v0
    .line 40: mul-int/2addr v2, v1
    .line 41: iget-wide v3, v5, Lcom/titanchess/accessibility/a;->g:D
    .line 43: invoke-static {v3, v4}, Ljava/lang/Double;->hashCode(D)I
    .line 46: move-result v0
    .line 47: add-int/2addr v0, v2
    .line 48: mul-int/2addr v0, v1
    .line 49: iget-boolean v1, v5, Lcom/titanchess/accessibility/a;->h:Z
    .line 51: if-eqz v1, :cond_54
    .line 53: const/4 v1, 1
    .line 54: add-int/2addr v0, v1
    .line 55: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "AccChip(meX="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Lcom/titanchess/accessibility/a;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", meY="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v3, Lcom/titanchess/accessibility/a;->b:F
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", oppX="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v3, Lcom/titanchess/accessibility/a;->c:F
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", oppY="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v3, Lcom/titanchess/accessibility/a;->d:F
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", boardPx="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget v1, v3, Lcom/titanchess/accessibility/a;->e:F
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", me="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget-wide v1, v3, Lcom/titanchess/accessibility/a;->f:D
    .line 59: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ", opp="
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: iget-wide v1, v3, Lcom/titanchess/accessibility/a;->g:D
    .line 69: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;
    .line 72: const-string v1, ", meWhite="
    .line 74: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: iget-boolean v1, v3, Lcom/titanchess/accessibility/a;->h:Z
    .line 79: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 82: const-string v1, ")"
    .line 84: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 87: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 90: move-result-object v0
    .line 91: return-object v0
.end method

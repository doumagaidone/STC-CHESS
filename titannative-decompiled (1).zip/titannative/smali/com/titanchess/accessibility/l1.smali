.class public final Lcom/titanchess/accessibility/l1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ljava/lang/String;
.field public final c:Ljava/lang/String;
.field public final d:Ljava/lang/String;
.field public final e:Ljava/lang/String;
.field public final f:Z

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 7

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/l1;->a:Ljava/lang/String;
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/l1;->b:Ljava/lang/String;
    .line 7: iput-object v3, v0, Lcom/titanchess/accessibility/l1;->c:Ljava/lang/String;
    .line 9: iput-object v4, v0, Lcom/titanchess/accessibility/l1;->d:Ljava/lang/String;
    .line 11: iput-object v5, v0, Lcom/titanchess/accessibility/l1;->e:Ljava/lang/String;
    .line 13: iput-boolean v6, v0, Lcom/titanchess/accessibility/l1;->f:Z
    .line 15: return-void
.end method

# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/l1;->c:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public final b()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Lcom/titanchess/accessibility/l1;->f:Z
    .line 2: return v0
.end method

# virtual methods
.method public final c()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/l1;->a:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public final d()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/l1;->b:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public final e()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/l1;->d:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/l1;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/l1;
    .line 12: iget-object v1, v5, Lcom/titanchess/accessibility/l1;->a:Ljava/lang/String;
    .line 14: iget-object v3, v4, Lcom/titanchess/accessibility/l1;->a:Ljava/lang/String;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget-object v1, v4, Lcom/titanchess/accessibility/l1;->b:Ljava/lang/String;
    .line 25: iget-object v3, v5, Lcom/titanchess/accessibility/l1;->b:Ljava/lang/String;
    .line 27: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 30: move-result v1
    .line 31: if-nez v1, :cond_34
    .line 33: return v2
    .line 34: iget-object v1, v4, Lcom/titanchess/accessibility/l1;->c:Ljava/lang/String;
    .line 36: iget-object v3, v5, Lcom/titanchess/accessibility/l1;->c:Ljava/lang/String;
    .line 38: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 41: move-result v1
    .line 42: if-nez v1, :cond_45
    .line 44: return v2
    .line 45: iget-object v1, v4, Lcom/titanchess/accessibility/l1;->d:Ljava/lang/String;
    .line 47: iget-object v3, v5, Lcom/titanchess/accessibility/l1;->d:Ljava/lang/String;
    .line 49: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v1
    .line 53: if-nez v1, :cond_56
    .line 55: return v2
    .line 56: iget-object v1, v4, Lcom/titanchess/accessibility/l1;->e:Ljava/lang/String;
    .line 58: iget-object v3, v5, Lcom/titanchess/accessibility/l1;->e:Ljava/lang/String;
    .line 60: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 63: move-result v1
    .line 64: if-nez v1, :cond_67
    .line 66: return v2
    .line 67: iget-boolean v1, v4, Lcom/titanchess/accessibility/l1;->f:Z
    .line 69: iget-boolean v5, v5, Lcom/titanchess/accessibility/l1;->f:Z
    .line 71: if-eq v1, v5, :cond_74
    .line 73: return v2
    .line 74: return v0
.end method

# virtual methods
.method public final f()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Lcom/titanchess/accessibility/l1;->e:Ljava/lang/String;
    .line 2: return-object v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget-object v0, v2, Lcom/titanchess/accessibility/l1;->a:Ljava/lang/String;
    .line 2: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->b:Ljava/lang/String;
    .line 10: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget-object v0, v2, Lcom/titanchess/accessibility/l1;->c:Ljava/lang/String;
    .line 19: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 22: move-result v0
    .line 23: add-int/2addr v0, v1
    .line 24: mul-int/lit8 v0, v0, 31
    .line 26: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->d:Ljava/lang/String;
    .line 28: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 31: move-result v1
    .line 32: add-int/2addr v1, v0
    .line 33: mul-int/lit8 v1, v1, 31
    .line 35: iget-object v0, v2, Lcom/titanchess/accessibility/l1;->e:Ljava/lang/String;
    .line 37: invoke-virtual {v0}, Ljava/lang/String;->hashCode()I
    .line 40: move-result v0
    .line 41: add-int/2addr v0, v1
    .line 42: mul-int/lit8 v0, v0, 31
    .line 44: iget-boolean v1, v2, Lcom/titanchess/accessibility/l1;->f:Z
    .line 46: if-eqz v1, :cond_49
    .line 48: const/4 v1, 1
    .line 49: add-int/2addr v0, v1
    .line 50: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ModelInfo(id="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", name="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->b:Ljava/lang/String;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", desc="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->c:Ljava/lang/String;
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", range="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->d:Ljava/lang/String;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", size="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-object v1, v2, Lcom/titanchess/accessibility/l1;->e:Ljava/lang/String;
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", free="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget-boolean v1, v2, Lcom/titanchess/accessibility/l1;->f:Z
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 62: const-string v1, ")"
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 70: move-result-object v0
    .line 71: return-object v0
.end method

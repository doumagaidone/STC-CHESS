.class public final Lcom/titanchess/accessibility/d2;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"

.field public static final synthetic b:I

.field public final synthetic a:Lcom/titanchess/accessibility/TitanAccessibilityService;

# direct methods
.method public constructor <init>(Lcom/titanchess/accessibility/TitanAccessibilityService;)V
    .registers 2

    .line 0: iput-object v1, v0, Lcom/titanchess/accessibility/d2;->a:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 2: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 6

    .line 0: iget-object v4, v3, Lcom/titanchess/accessibility/d2;->a:Lcom/titanchess/accessibility/TitanAccessibilityService;
    .line 2: const-string v5, "titan"
    .line 4: const/4 v0, 0
    .line 5: invoke-virtual {v4, v5, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    .line 8: move-result-object v5
    .line 9: const-string v1, "float_hidden"
    .line 11: invoke-interface {v5, v1, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    .line 14: move-result v5
    .line 15: invoke-static {v4}, Lcom/titanchess/accessibility/TitanAccessibilityService;->access$getMain$p(Lcom/titanchess/accessibility/TitanAccessibilityService;)Landroid/os/Handler;
    .line 18: move-result-object v0
    .line 19: new-instance v1, Lcom/titanchess/accessibility/x1;
    .line 21: const/4 v2, 1
    .line 22: invoke-direct {v1, v5, v4, v2}, Lcom/titanchess/accessibility/x1;-><init>(ZLcom/titanchess/accessibility/TitanAccessibilityService;I)V
    .line 25: invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 28: return-void
.end method

.class public abstract Lcom/titanchess/accessibility/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lb0/c;
.field public static final b:Lb0/c;
.field public static final c:Lb0/c;
.field public static final d:Lb0/c;
.field public static final e:Lb0/c;
.field public static final f:Lb0/c;
.field public static final g:Lb0/c;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: sget-object v0, Lcom/titanchess/accessibility/h;->k:Lcom/titanchess/accessibility/h;
    .line 2: const v1, 0xf07a798a
    .line 5: const/4 v2, 0
    .line 6: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 9: move-result-object v0
    .line 10: sput-object v0, Lcom/titanchess/accessibility/j;->a:Lb0/c;
    .line 12: sget-object v0, Lcom/titanchess/accessibility/i;->k:Lcom/titanchess/accessibility/i;
    .line 14: const v1, 0x1c96506c
    .line 17: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 20: move-result-object v0
    .line 21: sput-object v0, Lcom/titanchess/accessibility/j;->b:Lb0/c;
    .line 23: sget-object v0, Lcom/titanchess/accessibility/h;->l:Lcom/titanchess/accessibility/h;
    .line 25: const v1, 0xa2505f64
    .line 28: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 31: move-result-object v0
    .line 32: sput-object v0, Lcom/titanchess/accessibility/j;->c:Lb0/c;
    .line 34: sget-object v0, Lcom/titanchess/accessibility/h;->m:Lcom/titanchess/accessibility/h;
    .line 36: const v1, 0x7c1daa80
    .line 39: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 42: move-result-object v0
    .line 43: sput-object v0, Lcom/titanchess/accessibility/j;->d:Lb0/c;
    .line 45: sget-object v0, Lcom/titanchess/accessibility/i;->l:Lcom/titanchess/accessibility/i;
    .line 47: const v1, 0xba4c0ac8
    .line 50: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 53: move-result-object v0
    .line 54: sput-object v0, Lcom/titanchess/accessibility/j;->e:Lb0/c;
    .line 56: sget-object v0, Lcom/titanchess/accessibility/h;->n:Lcom/titanchess/accessibility/h;
    .line 58: const v1, 0x4ed23010
    .line 61: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 64: move-result-object v0
    .line 65: sput-object v0, Lcom/titanchess/accessibility/j;->f:Lb0/c;
    .line 67: sget-object v0, Lcom/titanchess/accessibility/h;->o:Lcom/titanchess/accessibility/h;
    .line 69: const v1, 0xc936c33a
    .line 72: invoke-static {v1, v0, v2}, Ln3/a0;->B(ILe3/h;Z)Lb0/c;
    .line 75: move-result-object v0
    .line 76: sput-object v0, Lcom/titanchess/accessibility/j;->g:Lb0/c;
    .line 78: return-void
.end method

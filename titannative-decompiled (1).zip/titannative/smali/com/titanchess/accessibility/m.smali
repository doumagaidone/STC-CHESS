.class public final synthetic Lcom/titanchess/accessibility/m;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Landroid/view/View$OnClickListener;

.field public final synthetic a:I
.field public final synthetic b:Ljava/lang/Object;

# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Lcom/titanchess/accessibility/m;->a:I
    .line 5: iput-object v2, v0, Lcom/titanchess/accessibility/m;->b:Ljava/lang/Object;
    .line 7: return-void
.end method

# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 0: iget v4, v3, Lcom/titanchess/accessibility/m;->a:I
    .line 2: iget-object v0, v3, Lcom/titanchess/accessibility/m;->b:Ljava/lang/Object;
    .line 4: packed-switch v4, :data_48
    .line 7: check-cast v0, Ld3/a;
    .line 9: const-string v4, "$onClick"
    .line 11: invoke-static {v0, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 14: invoke-interface {v0}, Ld3/a;->s()Ljava/lang/Object;
    .line 17: return-void
    .line 18: check-cast v0, Lcom/titanchess/accessibility/s;
    .line 20: const-string v4, "this$0"
    .line 22: invoke-static {v0, v4}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 25: const/4 v4, 0
    .line 26: iput-boolean v4, v0, Lcom/titanchess/accessibility/s;->g:Z
    .line 28: iget-object v1, v0, Lcom/titanchess/accessibility/s;->c:Landroid/content/SharedPreferences;
    .line 30: invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    .line 33: move-result-object v1
    .line 34: const-string v2, "float_expanded"
    .line 36: invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    .line 39: move-result-object v4
    .line 40: invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V
    .line 43: invoke-virtual {v0}, Lcom/titanchess/accessibility/s;->g()V
    .line 46: return-void
    .line 47: nop
    .line 48: nop
    .line 49: move v0, v0
    .line 50: nop
    .line 51: nop
    .line 52: return-void
    .line 53: nop
.end method

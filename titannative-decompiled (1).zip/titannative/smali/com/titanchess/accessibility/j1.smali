.class public final Lcom/titanchess/accessibility/j1;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lai/onnxruntime/OrtSession;
.field public final b:F
.field public final c:F
.field public final d:F
.field public final e:F

# direct methods
.method public constructor <init>(Lai/onnxruntime/OrtSession;FFFF)V
    .registers 6

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 5: iput v2, v0, Lcom/titanchess/accessibility/j1;->b:F
    .line 7: iput v3, v0, Lcom/titanchess/accessibility/j1;->c:F
    .line 9: iput v4, v0, Lcom/titanchess/accessibility/j1;->d:F
    .line 11: iput v5, v0, Lcom/titanchess/accessibility/j1;->e:F
    .line 13: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Lcom/titanchess/accessibility/j1;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Lcom/titanchess/accessibility/j1;
    .line 12: iget-object v1, v5, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 14: iget-object v3, v4, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 16: invoke-static {v3, v1}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 19: move-result v1
    .line 20: if-nez v1, :cond_23
    .line 22: return v2
    .line 23: iget v1, v4, Lcom/titanchess/accessibility/j1;->b:F
    .line 25: iget v3, v5, Lcom/titanchess/accessibility/j1;->b:F
    .line 27: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 30: move-result v1
    .line 31: if-eqz v1, :cond_34
    .line 33: return v2
    .line 34: iget v1, v4, Lcom/titanchess/accessibility/j1;->c:F
    .line 36: iget v3, v5, Lcom/titanchess/accessibility/j1;->c:F
    .line 38: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 41: move-result v1
    .line 42: if-eqz v1, :cond_45
    .line 44: return v2
    .line 45: iget v1, v4, Lcom/titanchess/accessibility/j1;->d:F
    .line 47: iget v3, v5, Lcom/titanchess/accessibility/j1;->d:F
    .line 49: invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I
    .line 52: move-result v1
    .line 53: if-eqz v1, :cond_56
    .line 55: return v2
    .line 56: iget v1, v4, Lcom/titanchess/accessibility/j1;->e:F
    .line 58: iget v5, v5, Lcom/titanchess/accessibility/j1;->e:F
    .line 60: invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I
    .line 63: move-result v5
    .line 64: if-eqz v5, :cond_67
    .line 66: return v2
    .line 67: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 4

    .line 0: iget-object v0, v3, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    .line 5: move-result v0
    .line 6: const/16 v1, 31
    .line 8: mul-int/2addr v0, v1
    .line 9: iget v2, v3, Lcom/titanchess/accessibility/j1;->b:F
    .line 11: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 14: move-result v0
    .line 15: iget v2, v3, Lcom/titanchess/accessibility/j1;->c:F
    .line 17: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 20: move-result v0
    .line 21: iget v2, v3, Lcom/titanchess/accessibility/j1;->d:F
    .line 23: invoke-static {v2, v0, v1}, Lai/onnxruntime/b;->b(FII)I
    .line 26: move-result v0
    .line 27: iget v1, v3, Lcom/titanchess/accessibility/j1;->e:F
    .line 29: invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I
    .line 32: move-result v1
    .line 33: add-int/2addr v1, v0
    .line 34: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "Band(session="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Lcom/titanchess/accessibility/j1;->a:Lai/onnxruntime/OrtSession;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", ratingMean="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget v1, v2, Lcom/titanchess/accessibility/j1;->b:F
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", ratingStd="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v2, Lcom/titanchess/accessibility/j1;->c:F
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", logTimeMean="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget v1, v2, Lcom/titanchess/accessibility/j1;->d:F
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", logTimeStd="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget v1, v2, Lcom/titanchess/accessibility/j1;->e:F
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ")"
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 60: move-result-object v0
    .line 61: return-object v0
.end method

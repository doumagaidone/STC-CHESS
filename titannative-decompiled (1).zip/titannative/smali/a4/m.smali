.class public abstract interface La4/m;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a(Ljavax/net/ssl/SSLSocket;)Z
.end method

# virtual methods
.method public abstract b(Ljavax/net/ssl/SSLSocket;)La4/o;
.end method

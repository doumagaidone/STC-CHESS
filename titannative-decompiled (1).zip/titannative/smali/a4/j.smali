.class public final La4/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/reflect/Method;
.field public final b:Ljava/lang/reflect/Method;
.field public final c:Ljava/lang/reflect/Method;

# direct methods
.method public constructor <init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, La4/j;->a:Ljava/lang/reflect/Method;
    .line 5: iput-object v2, v0, La4/j;->b:Ljava/lang/reflect/Method;
    .line 7: iput-object v3, v0, La4/j;->c:Ljava/lang/reflect/Method;
    .line 9: return-void
.end method

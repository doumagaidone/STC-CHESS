.class public abstract interface La4/o;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a(Ljavax/net/ssl/SSLSocket;)Z
.end method

# virtual methods
.method public abstract b(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;
.end method

# virtual methods
.method public abstract c()Z
.end method

# virtual methods
.method public abstract d(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V
.end method

.class public final La4/e;
.super Ljava/util/logging/Handler;
.source "SourceFile"

.field public static final a:La4/e;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, La4/e;
    .line 2: invoke-direct {v0}, Ljava/util/logging/Handler;-><init>()V
    .line 5: sput-object v0, La4/e;->a:La4/e;
    .line 7: return-void
.end method

# virtual methods
.method public final close()V
    .registers 1

    .line 0: return-void
.end method

# virtual methods
.method public final flush()V
    .registers 1

    .line 0: return-void
.end method

# virtual methods
.method public final publish(Ljava/util/logging/LogRecord;)V
    .registers 12

    .line 0: const-string v0, "record"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, La4/d;->a:Ljava/util/concurrent/CopyOnWriteArraySet;
    .line 7: invoke-virtual {v11}, Ljava/util/logging/LogRecord;->getLoggerName()Ljava/lang/String;
    .line 10: move-result-object v0
    .line 11: const-string v1, "record.loggerName"
    .line 13: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 16: invoke-virtual {v11}, Ljava/util/logging/LogRecord;->getLevel()Ljava/util/logging/Level;
    .line 19: move-result-object v1
    .line 20: invoke-virtual {v1}, Ljava/util/logging/Level;->intValue()I
    .line 23: move-result v1
    .line 24: sget-object v2, Ljava/util/logging/Level;->INFO:Ljava/util/logging/Level;
    .line 26: invoke-virtual {v2}, Ljava/util/logging/Level;->intValue()I
    .line 29: move-result v3
    .line 30: const/4 v4, 4
    .line 31: if-le v1, v3, :cond_35
    .line 33: const/4 v1, 5
    .line 34: goto :goto_52
    .line 35: invoke-virtual {v11}, Ljava/util/logging/LogRecord;->getLevel()Ljava/util/logging/Level;
    .line 38: move-result-object v1
    .line 39: invoke-virtual {v1}, Ljava/util/logging/Level;->intValue()I
    .line 42: move-result v1
    .line 43: invoke-virtual {v2}, Ljava/util/logging/Level;->intValue()I
    .line 46: move-result v2
    .line 47: if-ne v1, v2, :cond_51
    .line 49: move v1, v4
    .line 50: goto :goto_52
    .line 51: const/4 v1, 3
    .line 52: invoke-virtual {v11}, Ljava/util/logging/LogRecord;->getMessage()Ljava/lang/String;
    .line 55: move-result-object v2
    .line 56: const-string v3, "record.message"
    .line 58: invoke-static {v2, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 61: invoke-virtual {v11}, Ljava/util/logging/LogRecord;->getThrown()Ljava/lang/Throwable;
    .line 64: move-result-object v11
    .line 65: sget-object v3, La4/d;->b:Ljava/util/Map;
    .line 67: invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 70: move-result-object v3
    .line 71: check-cast v3, Ljava/lang/String;
    .line 73: if-nez v3, :cond_81
    .line 75: const/16 v3, 23
    .line 77: invoke-static {v3, v0}, Lm3/k;->n2(ILjava/lang/String;)Ljava/lang/String;
    .line 80: move-result-object v3
    .line 81: invoke-static {v3, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z
    .line 84: move-result v0
    .line 85: if-eqz v0, :cond_155
    .line 87: const/16 v0, 10
    .line 89: if-eqz v11, :cond_113
    .line 91: new-instance v5, Ljava/lang/StringBuilder;
    .line 93: invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V
    .line 96: invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 99: invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 102: invoke-static {v11}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;
    .line 105: move-result-object v11
    .line 106: invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 109: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 112: move-result-object v2
    .line 113: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 116: move-result v11
    .line 117: const/4 v5, 0
    .line 118: move v6, v5
    .line 119: if-ge v6, v11, :cond_155
    .line 121: invoke-static {v2, v0, v6, v5, v4}, Lm3/j;->O1(Ljava/lang/CharSequence;CIZI)I
    .line 124: move-result v7
    .line 125: const/4 v8, -1
    .line 126: if-eq v7, v8, :cond_129
    .line 128: goto :goto_130
    .line 129: move v7, v11
    .line 130: add-int/lit16 v8, v6, 4000
    .line 132: invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I
    .line 135: move-result v8
    .line 136: invoke-virtual {v2, v6, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 139: move-result-object v6
    .line 140: const-string v9, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 142: invoke-static {v6, v9}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 145: invoke-static {v1, v3, v6}, Landroid/util/Log;->println(ILjava/lang/String;Ljava/lang/String;)I
    .line 148: if-lt v8, v7, :cond_153
    .line 150: add-int/lit8 v6, v8, 1
    .line 152: goto :goto_119
    .line 153: move v6, v8
    .line 154: goto :goto_130
    .line 155: return-void
.end method

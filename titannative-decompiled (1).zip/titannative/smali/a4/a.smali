.class public abstract synthetic La4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static bridge synthetic A(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setTranslationY(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic B(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setAlpha(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic C(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setScaleX(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic D(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setRotationY(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic a(Landroid/graphics/RenderNode;)F
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getElevation()F
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic b(Landroid/graphics/RenderNode;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getLeft()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic c(Landroid/graphics/Canvas;Landroid/graphics/RenderNode;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/Canvas;->drawRenderNode(Landroid/graphics/RenderNode;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic d(Landroid/graphics/RenderNode;)V
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->endRecording()V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic e(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setCameraDistance(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic f(Landroid/graphics/RenderNode;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setAmbientShadowColor(I)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic g(Landroid/graphics/RenderNode;Landroid/graphics/Outline;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setOutline(Landroid/graphics/Outline;)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic h(Landroid/graphics/RenderNode;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setClipToBounds(Z)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic i(Landroid/view/View;)V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Landroid/view/View;->setForceDarkAllowed(Z)V
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic j(Landroid/view/View;Landroid/graphics/Matrix;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/View;->transformMatrixToGlobal(Landroid/graphics/Matrix;)V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic k(Ljavax/net/ssl/SSLSocket;)V
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: invoke-static {v1, v0}, Landroid/net/ssl/SSLSockets;->setUseSessionTickets(Ljavax/net/ssl/SSLSocket;Z)V
    .line 4: return-void
.end method

# direct methods
.method public static bridge synthetic l(Landroid/graphics/RenderNode;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic m(Ljavax/net/ssl/SSLSocket;)Z
    .registers 1

    .line 0: invoke-static {v0}, Landroid/net/ssl/SSLSockets;->isSupportedSocket(Ljavax/net/ssl/SSLSocket;)Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic n(Landroid/graphics/RenderNode;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getHeight()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic o(Landroid/graphics/RenderNode;)V
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->discardDisplayList()V
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic p(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setElevation(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic q(Landroid/graphics/RenderNode;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setSpotShadowColor(I)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic r(Landroid/graphics/RenderNode;)Z
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: invoke-virtual {v1, v0}, Landroid/graphics/RenderNode;->setHasOverlappingRendering(Z)Z
    .line 4: move-result v1
    .line 5: return v1
.end method

# direct methods
.method public static bridge synthetic s(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setPivotX(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic t(Landroid/graphics/RenderNode;)I
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/RenderNode;->getTop()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic u(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setTranslationX(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic v(Landroid/graphics/RenderNode;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->offsetTopAndBottom(I)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic w(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setPivotY(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic x(Landroid/graphics/RenderNode;I)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->offsetLeftAndRight(I)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic y(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setRotationZ(F)Z
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic z(Landroid/graphics/RenderNode;F)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/RenderNode;->setRotationX(F)Z
    .line 3: return-void
.end method

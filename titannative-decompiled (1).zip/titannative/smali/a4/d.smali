.class public abstract La4/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/concurrent/CopyOnWriteArraySet;
.field public static final b:Ljava/util/Map;

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;
    .line 2: invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V
    .line 5: sput-object v0, La4/d;->a:Ljava/util/concurrent/CopyOnWriteArraySet;
    .line 7: new-instance v0, Ljava/util/LinkedHashMap;
    .line 9: invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V
    .line 12: const-class v1, Lr3/v;
    .line 14: invoke-virtual {v1}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;
    .line 17: move-result-object v2
    .line 18: if-eqz v2, :cond_25
    .line 20: invoke-virtual {v2}, Ljava/lang/Package;->getName()Ljava/lang/String;
    .line 23: move-result-object v2
    .line 24: goto :goto_26
    .line 25: const/4 v2, 0
    .line 26: if-eqz v2, :cond_33
    .line 28: const-string v3, "OkHttp"
    .line 30: invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 33: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 36: move-result-object v1
    .line 37: const-string v2, "okhttp.OkHttpClient"
    .line 39: invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 42: const-class v1, Ly3/g;
    .line 44: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 47: move-result-object v1
    .line 48: const-string v2, "okhttp.Http2"
    .line 50: invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 53: const-class v1, Lu3/f;
    .line 55: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 58: move-result-object v1
    .line 59: const-string v2, "okhttp.TaskRunner"
    .line 61: invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 64: const-string v1, "okhttp3.mockwebserver.MockWebServer"
    .line 66: const-string v2, "okhttp.MockWebServer"
    .line 68: invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 71: invoke-interface {v0}, Ljava/util/Map;->size()I
    .line 74: move-result v1
    .line 75: if-eqz v1, :cond_118
    .line 77: const/4 v2, 1
    .line 78: if-eq v1, v2, :cond_86
    .line 80: new-instance v1, Ljava/util/LinkedHashMap;
    .line 82: invoke-direct {v1, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V
    .line 85: goto :goto_120
    .line 86: invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;
    .line 89: move-result-object v0
    .line 90: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 93: move-result-object v0
    .line 94: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 97: move-result-object v0
    .line 98: check-cast v0, Ljava/util/Map$Entry;
    .line 100: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 103: move-result-object v1
    .line 104: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 107: move-result-object v0
    .line 108: invoke-static {v1, v0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;
    .line 111: move-result-object v1
    .line 112: const-string v0, "with(entries.iterator().…ingletonMap(key, value) }"
    .line 114: invoke-static {v1, v0}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 117: goto :goto_120
    .line 118: sget-object v1, Lt2/s;->i:Lt2/s;
    .line 120: sput-object v1, La4/d;->b:Ljava/util/Map;
    .line 122: return-void
.end method

.class public abstract Lc2/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final synthetic a:I

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Ljava/util/Locale;
    .line 2: const-string v1, ""
    .line 4: invoke-direct {v0, v1, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    .line 7: return-void
.end method

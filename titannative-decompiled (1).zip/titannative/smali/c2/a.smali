.class public abstract Lc2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Ljava/util/Locale;)I
    .registers 1

    .line 0: invoke-static {v0}, Landroid/text/TextUtils;->getLayoutDirectionFromLocale(Ljava/util/Locale;)I
    .line 3: move-result v0
    .line 4: return v0
.end method

.class public final Lc4/c;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljavax/net/ssl/HostnameVerifier;

.field public static final a:Lc4/c;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Lc4/c;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Lc4/c;->a:Lc4/c;
    .line 7: return-void
.end method

# direct methods
.method public static a(Ljava/security/cert/X509Certificate;I)Ljava/util/List;
    .registers 7

    .line 0: sget-object v0, Lt2/r;->i:Lt2/r;
    .line 2: invoke-virtual {v5}, Ljava/security/cert/X509Certificate;->getSubjectAlternativeNames()Ljava/util/Collection;
    .line 5: move-result-object v5
    .line 6: if-nez v5, :cond_9
    .line 8: return-object v0
    .line 9: new-instance v1, Ljava/util/ArrayList;
    .line 11: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 14: invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 17: move-result-object v5
    .line 18: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 21: move-result v2
    .line 22: if-eqz v2, :cond_69
    .line 24: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 27: move-result-object v2
    .line 28: check-cast v2, Ljava/util/List;
    .line 30: if-eqz v2, :cond_18
    .line 32: invoke-interface {v2}, Ljava/util/List;->size()I
    .line 35: move-result v3
    .line 36: const/4 v4, 2
    .line 37: if-ge v3, v4, :cond_40
    .line 39: goto :goto_18
    .line 40: const/4 v3, 0
    .line 41: invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 44: move-result-object v3
    .line 45: invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 48: move-result-object v4
    .line 49: invoke-static {v3, v4}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 52: move-result v3
    .line 53: if-eqz v3, :cond_18
    .line 55: const/4 v3, 1
    .line 56: invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 59: move-result-object v2
    .line 60: if-nez v2, :cond_63
    .line 62: goto :goto_18
    .line 63: check-cast v2, Ljava/lang/String;
    .line 65: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 68: goto :goto_18
    .line 69: return-object v1
    .line 70: return-object v0
.end method

# direct methods
.method public static b(Ljava/lang/String;)Z
    .registers 14

    .line 0: invoke-virtual {v13}, Ljava/lang/String;->length()I
    .line 3: move-result v0
    .line 4: invoke-virtual {v13}, Ljava/lang/String;->length()I
    .line 7: move-result v1
    .line 8: if-ltz v1, :cond_130
    .line 10: invoke-virtual {v13}, Ljava/lang/String;->length()I
    .line 13: move-result v2
    .line 14: if-gt v1, v2, :cond_94
    .line 16: const/4 v2, 0
    .line 17: const-wide/16 v3, 0
    .line 19: move v5, v2
    .line 20: if-ge v5, v1, :cond_89
    .line 22: invoke-virtual {v13, v5}, Ljava/lang/String;->charAt(I)C
    .line 25: move-result v6
    .line 26: const/16 v7, 128
    .line 28: const-wide/16 v8, 1
    .line 30: if-ge v6, v7, :cond_36
    .line 32: add-long/2addr v3, v8
    .line 33: add-int/lit8 v5, v5, 1
    .line 35: goto :goto_20
    .line 36: const/16 v7, 2048
    .line 38: if-ge v6, v7, :cond_44
    .line 40: const/4 v6, 2
    .line 41: int-to-long v6, v6
    .line 42: add-long/2addr v3, v6
    .line 43: goto :goto_33
    .line 44: const v7, 0xd800
    .line 47: if-lt v6, v7, :cond_87
    .line 49: const v7, 0xdfff
    .line 52: if-le v6, v7, :cond_55
    .line 54: goto :goto_87
    .line 55: add-int/lit8 v10, v5, 1
    .line 57: if-ge v10, v1, :cond_64
    .line 59: invoke-virtual {v13, v10}, Ljava/lang/String;->charAt(I)C
    .line 62: move-result v11
    .line 63: goto :goto_65
    .line 64: move v11, v2
    .line 65: const v12, 0xdbff
    .line 68: if-gt v6, v12, :cond_84
    .line 70: const v6, 0xdc00
    .line 73: if-lt v11, v6, :cond_84
    .line 75: if-le v11, v7, :cond_78
    .line 77: goto :goto_84
    .line 78: const/4 v6, 4
    .line 79: int-to-long v6, v6
    .line 80: add-long/2addr v3, v6
    .line 81: add-int/lit8 v5, v5, 2
    .line 83: goto :goto_20
    .line 84: add-long/2addr v3, v8
    .line 85: move v5, v10
    .line 86: goto :goto_20
    .line 87: const/4 v6, 3
    .line 88: goto :goto_41
    .line 89: long-to-int v13, v3
    .line 90: if-ne v0, v13, :cond_93
    .line 92: const/4 v2, 1
    .line 93: return v2
    .line 94: new-instance v0, Ljava/lang/StringBuilder;
    .line 96: const-string v2, "endIndex > string.length: "
    .line 98: invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 101: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 104: const-string v1, " > "
    .line 106: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 109: invoke-virtual {v13}, Ljava/lang/String;->length()I
    .line 112: move-result v13
    .line 113: invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 116: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 119: move-result-object v13
    .line 120: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 122: invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 125: move-result-object v13
    .line 126: invoke-direct {v0, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 129: throw v0
    .line 130: const-string v13, "endIndex < beginIndex: "
    .line 132: const-string v0, " < 0"
    .line 134: invoke-static {v13, v1, v0}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 137: move-result-object v13
    .line 138: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 140: invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 143: move-result-object v13
    .line 144: invoke-direct {v0, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 147: throw v0
.end method

# direct methods
.method public static c(Ljava/lang/String;Ljava/security/cert/X509Certificate;)Z
    .registers 13

    .line 0: const-string v0, "host"
    .line 2: invoke-static {v11, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: sget-object v0, Ls3/b;->a:[B
    .line 7: sget-object v0, Ls3/b;->e:Lm3/f;
    .line 9: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 12: iget-object v0, v0, Lm3/f;->i:Ljava/util/regex/Pattern;
    .line 14: invoke-virtual {v0, v11}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    .line 17: move-result-object v0
    .line 18: invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z
    .line 21: move-result v0
    .line 22: const/4 v1, 1
    .line 23: const/4 v2, 0
    .line 24: if-eqz v0, :cond_72
    .line 26: invoke-static {v11}, Lkotlinx/coroutines/flow/c0;->m(Ljava/lang/String;)Ljava/lang/String;
    .line 29: move-result-object v11
    .line 30: const/4 v0, 7
    .line 31: invoke-static {v12, v0}, Lc4/c;->a(Ljava/security/cert/X509Certificate;I)Ljava/util/List;
    .line 34: move-result-object v12
    .line 35: invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z
    .line 38: move-result v0
    .line 39: if-eqz v0, :cond_44
    .line 41: move v1, v2
    .line 42: goto/16 :goto_303
    .line 44: invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 47: move-result-object v12
    .line 48: invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z
    .line 51: move-result v0
    .line 52: if-eqz v0, :cond_41
    .line 54: invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 57: move-result-object v0
    .line 58: check-cast v0, Ljava/lang/String;
    .line 60: invoke-static {v0}, Lkotlinx/coroutines/flow/c0;->m(Ljava/lang/String;)Ljava/lang/String;
    .line 63: move-result-object v0
    .line 64: invoke-static {v11, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 67: move-result v0
    .line 68: if-eqz v0, :cond_48
    .line 70: goto/16 :goto_303
    .line 72: invoke-static {v11}, Lc4/c;->b(Ljava/lang/String;)Z
    .line 75: move-result v0
    .line 76: const-string v3, "this as java.lang.String).toLowerCase(locale)"
    .line 78: const-string v4, "US"
    .line 80: if-eqz v0, :cond_94
    .line 82: sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;
    .line 84: invoke-static {v0, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 87: invoke-virtual {v11, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 90: move-result-object v11
    .line 91: invoke-static {v11, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 94: const/4 v0, 2
    .line 95: invoke-static {v12, v0}, Lc4/c;->a(Ljava/security/cert/X509Certificate;I)Ljava/util/List;
    .line 98: move-result-object v12
    .line 99: invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z
    .line 102: move-result v0
    .line 103: if-eqz v0, :cond_106
    .line 105: goto :goto_41
    .line 106: invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    .line 109: move-result-object v12
    .line 110: invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z
    .line 113: move-result v0
    .line 114: if-eqz v0, :cond_41
    .line 116: invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 119: move-result-object v0
    .line 120: check-cast v0, Ljava/lang/String;
    .line 122: invoke-virtual {v11}, Ljava/lang/String;->length()I
    .line 125: move-result v5
    .line 126: if-nez v5, :cond_129
    .line 128: goto :goto_110
    .line 129: const-string v5, "."
    .line 131: invoke-static {v11, v5, v2}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 134: move-result v6
    .line 135: if-nez v6, :cond_110
    .line 137: const-string v6, ".."
    .line 139: invoke-virtual {v11, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z
    .line 142: move-result v7
    .line 143: if-eqz v7, :cond_146
    .line 145: goto :goto_110
    .line 146: if-eqz v0, :cond_110
    .line 148: invoke-virtual {v0}, Ljava/lang/String;->length()I
    .line 151: move-result v7
    .line 152: if-nez v7, :cond_155
    .line 154: goto :goto_110
    .line 155: invoke-static {v0, v5, v2}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 158: move-result v7
    .line 159: if-nez v7, :cond_110
    .line 161: invoke-virtual {v0, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z
    .line 164: move-result v6
    .line 165: if-eqz v6, :cond_168
    .line 167: goto :goto_110
    .line 168: invoke-virtual {v11, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z
    .line 171: move-result v6
    .line 172: if-nez v6, :cond_179
    .line 174: invoke-virtual {v11, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 177: move-result-object v6
    .line 178: goto :goto_180
    .line 179: move-object v6, v11
    .line 180: invoke-virtual {v0, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z
    .line 183: move-result v7
    .line 184: if-nez v7, :cond_190
    .line 186: invoke-virtual {v0, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 189: move-result-object v0
    .line 190: invoke-static {v0}, Lc4/c;->b(Ljava/lang/String;)Z
    .line 193: move-result v5
    .line 194: if-eqz v5, :cond_208
    .line 196: sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;
    .line 198: invoke-static {v5, v4}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 201: invoke-virtual {v0, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;
    .line 204: move-result-object v0
    .line 205: invoke-static {v0, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 208: const-string v5, "*"
    .line 210: invoke-static {v0, v5, v2}, Lm3/j;->G1(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .line 213: move-result v5
    .line 214: if-nez v5, :cond_223
    .line 216: invoke-static {v6, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 219: move-result v0
    .line 220: if-eqz v0, :cond_110
    .line 222: goto :goto_303
    .line 223: const-string v5, "*."
    .line 225: invoke-static {v0, v5, v2}, Lm3/j;->g2(Ljava/lang/String;Ljava/lang/String;Z)Z
    .line 228: move-result v7
    .line 229: if-eqz v7, :cond_110
    .line 231: const/16 v7, 42
    .line 233: const/4 v8, 4
    .line 234: invoke-static {v0, v7, v1, v2, v8}, Lm3/j;->O1(Ljava/lang/CharSequence;CIZI)I
    .line 237: move-result v7
    .line 238: const/4 v9, -1
    .line 239: if-eq v7, v9, :cond_243
    .line 241: goto/16 :goto_110
    .line 243: invoke-virtual {v6}, Ljava/lang/String;->length()I
    .line 246: move-result v7
    .line 247: invoke-virtual {v0}, Ljava/lang/String;->length()I
    .line 250: move-result v10
    .line 251: if-ge v7, v10, :cond_255
    .line 253: goto/16 :goto_110
    .line 255: invoke-static {v5, v0}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 258: move-result v5
    .line 259: if-eqz v5, :cond_263
    .line 261: goto/16 :goto_110
    .line 263: invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 266: move-result-object v0
    .line 267: const-string v5, "this as java.lang.String).substring(startIndex)"
    .line 269: invoke-static {v0, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 272: invoke-virtual {v6, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z
    .line 275: move-result v5
    .line 276: if-nez v5, :cond_280
    .line 278: goto/16 :goto_110
    .line 280: invoke-virtual {v6}, Ljava/lang/String;->length()I
    .line 283: move-result v5
    .line 284: invoke-virtual {v0}, Ljava/lang/String;->length()I
    .line 287: move-result v0
    .line 288: sub-int/2addr v5, v0
    .line 289: if-lez v5, :cond_303
    .line 291: add-int/lit8 v5, v5, -1
    .line 293: const/16 v0, 46
    .line 295: invoke-static {v6, v0, v5, v8}, Lm3/j;->S1(Ljava/lang/CharSequence;CII)I
    .line 298: move-result v0
    .line 299: if-eq v0, v9, :cond_303
    .line 301: goto/16 :goto_110
    .line 303: return v1
.end method

# virtual methods
.method public final verify(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z
    .registers 5

    .line 0: const-string v0, "host"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "session"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-static {v3}, Lc4/c;->b(Ljava/lang/String;)Z
    .line 13: move-result v0
    .line 14: const/4 v1, 0
    .line 15: if-nez v0, :cond_18
    .line 17: goto :goto_35
    .line 18: invoke-interface {v4}, Ljavax/net/ssl/SSLSession;->getPeerCertificates()[Ljava/security/cert/Certificate;
    .line 21: move-result-object v4
    .line 22: aget-object v4, v4, v1
    .line 24: const-string v0, "null cannot be cast to non-null type java.security.cert.X509Certificate"
    .line 26: invoke-static {v4, v0}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 29: check-cast v4, Ljava/security/cert/X509Certificate;
    .line 31: invoke-static {v3, v4}, Lc4/c;->c(Ljava/lang/String;Ljava/security/cert/X509Certificate;)Z
    .line 34: move-result v1
    .line 35: return v1
.end method

.class public abstract Ld4/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Le4/k;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: sget-object v0, Le4/k;->l:Le4/k;
    .line 2: const-string v0, "000000ffff"
    .line 4: invoke-static {v0}, Lz3/b;->q(Ljava/lang/String;)Le4/k;
    .line 7: move-result-object v0
    .line 8: sput-object v0, Ld4/b;->a:Le4/k;
    .line 10: return-void
.end method

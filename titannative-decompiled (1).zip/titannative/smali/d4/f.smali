.class public final Ld4/f;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:Ld4/g;
.field public final synthetic b:La1/b;

# direct methods
.method public constructor <init>(Ld4/g;La1/b;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Ld4/f;->a:Ld4/g;
    .line 5: iput-object v2, v0, Ld4/f;->b:La1/b;
    .line 7: return-void
.end method

# virtual methods
.method public final a(Lv3/j;Ljava/io/IOException;)V
    .registers 4

    .line 0: const-string v0, "call"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: iget-object v2, v1, Ld4/f;->a:Ld4/g;
    .line 7: invoke-virtual {v2, v3}, Ld4/g;->c(Ljava/lang/Exception;)V
    .line 10: return-void
.end method

# virtual methods
.method public final b(Lv3/j;Lr3/z;)V
    .registers 22

    .line 0: move-object/from16 v1, v19
    .line 2: move-object/from16 v2, v21
    .line 4: iget-object v3, v2, Lr3/z;->u:Lv3/e;
    .line 6: const/4 v5, 1
    .line 7: iget-object v0, v1, Ld4/f;->a:Ld4/g;
    .line 9: invoke-virtual {v0, v2, v3}, Ld4/g;->a(Lr3/z;Lv3/e;)V
    .line 12: invoke-virtual {v3}, Lv3/e;->b()Lv3/l;
    .line 15: move-result-object v0
    .line 16: iget-object v3, v2, Lr3/z;->n:Lr3/q;
    .line 18: const-string v6, "responseHeaders"
    .line 20: invoke-static {v3, v6}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 23: invoke-virtual {v3}, Lr3/q;->size()I
    .line 26: move-result v6
    .line 27: const/4 v7, 0
    .line 28: move v8, v7
    .line 29: move v10, v8
    .line 30: move v12, v10
    .line 31: move v14, v12
    .line 32: move/from16 v18, v14
    .line 34: const/16 v16, 0
    .line 36: const/16 v17, 0
    .line 38: if-ge v8, v6, :cond_277
    .line 40: invoke-virtual {v3, v8}, Lr3/q;->c(I)Ljava/lang/String;
    .line 43: move-result-object v9
    .line 44: const-string v11, "Sec-WebSocket-Extensions"
    .line 46: invoke-static {v9, v11}, Lm3/j;->K1(Ljava/lang/String;Ljava/lang/String;)Z
    .line 49: move-result v9
    .line 50: if-nez v9, :cond_54
    .line 52: goto/16 :goto_271
    .line 54: invoke-virtual {v3, v8}, Lr3/q;->f(I)Ljava/lang/String;
    .line 57: move-result-object v9
    .line 58: move v11, v7
    .line 59: invoke-virtual {v9}, Ljava/lang/String;->length()I
    .line 62: move-result v13
    .line 63: if-ge v11, v13, :cond_271
    .line 65: const/16 v13, 44
    .line 67: const/4 v15, 4
    .line 68: invoke-static {v9, v13, v11, v7, v15}, Ls3/b;->g(Ljava/lang/String;CIII)I
    .line 71: move-result v13
    .line 72: const/16 v15, 59
    .line 74: invoke-static {v9, v15, v11, v13}, Ls3/b;->e(Ljava/lang/String;CII)I
    .line 77: move-result v7
    .line 78: invoke-static {v9, v11, v7}, Ls3/b;->y(Ljava/lang/String;II)Ljava/lang/String;
    .line 81: move-result-object v11
    .line 82: add-int/2addr v7, v5
    .line 83: const-string v4, "permessage-deflate"
    .line 85: invoke-static {v11, v4}, Lm3/j;->K1(Ljava/lang/String;Ljava/lang/String;)Z
    .line 88: move-result v4
    .line 89: if-eqz v4, :cond_264
    .line 91: if-eqz v10, :cond_95
    .line 93: move/from16 v18, v5
    .line 95: move v11, v7
    .line 96: if-ge v11, v13, :cond_259
    .line 98: invoke-static {v9, v15, v11, v13}, Ls3/b;->e(Ljava/lang/String;CII)I
    .line 101: move-result v4
    .line 102: const/16 v7, 61
    .line 104: invoke-static {v9, v7, v11, v4}, Ls3/b;->e(Ljava/lang/String;CII)I
    .line 107: move-result v7
    .line 108: invoke-static {v9, v11, v7}, Ls3/b;->y(Ljava/lang/String;II)Ljava/lang/String;
    .line 111: move-result-object v10
    .line 112: if-ge v7, v4, :cond_157
    .line 114: add-int/lit8 v7, v7, 1
    .line 116: invoke-static {v9, v7, v4}, Ls3/b;->y(Ljava/lang/String;II)Ljava/lang/String;
    .line 119: move-result-object v7
    .line 120: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 123: move-result v11
    .line 124: const-string v15, "\""
    .line 126: const/4 v5, 2
    .line 127: if-lt v11, v5, :cond_158
    .line 129: invoke-static {v7, v15}, Lm3/j;->h2(Ljava/lang/CharSequence;Ljava/lang/String;)Z
    .line 132: move-result v5
    .line 133: if-eqz v5, :cond_158
    .line 135: invoke-static {v7, v15}, Lm3/j;->I1(Ljava/lang/CharSequence;Ljava/lang/String;)Z
    .line 138: move-result v5
    .line 139: if-eqz v5, :cond_158
    .line 141: invoke-virtual {v7}, Ljava/lang/String;->length()I
    .line 144: move-result v5
    .line 145: const/4 v11, 1
    .line 146: sub-int/2addr v5, v11
    .line 147: invoke-virtual {v7, v11, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    .line 150: move-result-object v7
    .line 151: const-string v5, "this as java.lang.String…ing(startIndex, endIndex)"
    .line 153: invoke-static {v7, v5}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 156: goto :goto_158
    .line 157: const/4 v7, 0
    .line 158: add-int/lit8 v11, v4, 1
    .line 160: const-string v4, "client_max_window_bits"
    .line 162: invoke-static {v10, v4}, Lm3/j;->K1(Ljava/lang/String;Ljava/lang/String;)Z
    .line 165: move-result v4
    .line 166: if-eqz v4, :cond_195
    .line 168: if-eqz v16, :cond_172
    .line 170: const/16 v18, 1
    .line 172: if-eqz v7, :cond_181
    .line 174: invoke-static {v7}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 177: move-result-object v4
    .line 178: move-object/from16 v16, v4
    .line 180: goto :goto_183
    .line 181: const/16 v16, 0
    .line 183: if-nez v16, :cond_191
    .line 185: const/4 v5, 1
    .line 186: const/16 v15, 59
    .line 188: const/16 v18, 1
    .line 190: goto :goto_96
    .line 191: const/4 v5, 1
    .line 192: const/16 v15, 59
    .line 194: goto :goto_96
    .line 195: const-string v4, "client_no_context_takeover"
    .line 197: invoke-static {v10, v4}, Lm3/j;->K1(Ljava/lang/String;Ljava/lang/String;)Z
    .line 200: move-result v4
    .line 201: if-eqz v4, :cond_214
    .line 203: if-eqz v12, :cond_207
    .line 205: const/16 v18, 1
    .line 207: if-eqz v7, :cond_211
    .line 209: const/16 v18, 1
    .line 211: const/4 v5, 1
    .line 212: const/4 v12, 1
    .line 213: goto :goto_192
    .line 214: const-string v4, "server_max_window_bits"
    .line 216: invoke-static {v10, v4}, Lm3/j;->K1(Ljava/lang/String;Ljava/lang/String;)Z
    .line 219: move-result v4
    .line 220: if-eqz v4, :cond_240
    .line 222: if-eqz v17, :cond_226
    .line 224: const/16 v18, 1
    .line 226: if-eqz v7, :cond_235
    .line 228: invoke-static {v7}, Lm3/h;->F1(Ljava/lang/String;)Ljava/lang/Integer;
    .line 231: move-result-object v4
    .line 232: move-object/from16 v17, v4
    .line 234: goto :goto_237
    .line 235: const/16 v17, 0
    .line 237: if-nez v17, :cond_191
    .line 239: goto :goto_185
    .line 240: const-string v4, "server_no_context_takeover"
    .line 242: invoke-static {v10, v4}, Lm3/j;->K1(Ljava/lang/String;Ljava/lang/String;)Z
    .line 245: move-result v4
    .line 246: if-eqz v4, :cond_185
    .line 248: if-eqz v14, :cond_252
    .line 250: const/16 v18, 1
    .line 252: if-eqz v7, :cond_256
    .line 254: const/16 v18, 1
    .line 256: const/4 v5, 1
    .line 257: const/4 v14, 1
    .line 258: goto :goto_192
    .line 259: const/4 v5, 1
    .line 260: const/4 v7, 0
    .line 261: const/4 v10, 1
    .line 262: goto/16 :goto_59
    .line 264: move v11, v7
    .line 265: const/4 v5, 1
    .line 266: const/4 v7, 0
    .line 267: const/16 v18, 1
    .line 269: goto/16 :goto_59
    .line 271: add-int/lit8 v8, v8, 1
    .line 273: const/4 v5, 1
    .line 274: const/4 v7, 0
    .line 275: goto/16 :goto_38
    .line 277: new-instance v3, Ld4/h;
    .line 279: move-object v9, v3
    .line 280: move-object/from16 v11, v16
    .line 282: move-object/from16 v13, v17
    .line 284: move/from16 v15, v18
    .line 286: invoke-direct/range {v9 .. v15}, Ld4/h;-><init>(ZLjava/lang/Integer;ZLjava/lang/Integer;ZZ)V
    .line 289: iget-object v4, v1, Ld4/f;->a:Ld4/g;
    .line 291: iput-object v3, v4, Ld4/g;->e:Ld4/h;
    .line 293: if-eqz v18, :cond_296
    .line 295: goto :goto_322
    .line 296: if-eqz v16, :cond_299
    .line 298: goto :goto_322
    .line 299: if-eqz v17, :cond_342
    .line 301: new-instance v3, Lj3/d;
    .line 303: const/16 v4, 15
    .line 305: const/16 v5, 8
    .line 307: const/4 v6, 1
    .line 308: invoke-direct {v3, v5, v4, v6}, Lj3/b;-><init>(III)V
    .line 311: invoke-virtual/range {v17 .. v17}, Ljava/lang/Integer;->intValue()I
    .line 314: move-result v4
    .line 315: if-gt v5, v4, :cond_322
    .line 317: iget v3, v3, Lj3/b;->j:I
    .line 319: if-gt v4, v3, :cond_322
    .line 321: goto :goto_342
    .line 322: iget-object v3, v1, Ld4/f;->a:Ld4/g;
    .line 324: monitor-enter v3
    .line 325: iget-object v4, v3, Ld4/g;->p:Ljava/util/ArrayDeque;
    .line 327: invoke-virtual {v4}, Ljava/util/ArrayDeque;->clear()V
    .line 330: const-string v4, "unexpected Sec-WebSocket-Extensions in response header"
    .line 332: const/16 v5, 1010
    .line 334: invoke-virtual {v3, v5, v4}, Ld4/g;->b(ILjava/lang/String;)Z
    .line 337: monitor-exit v3
    .line 338: goto :goto_342
    .line 339: move-exception v0
    .line 340: monitor-exit v3
    .line 341: throw v0
    .line 342: new-instance v3, Ljava/lang/StringBuilder;
    .line 344: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 347: sget-object v4, Ls3/b;->f:Ljava/lang/String;
    .line 349: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 352: const-string v4, " WebSocket "
    .line 354: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 357: iget-object v4, v1, Ld4/f;->b:La1/b;
    .line 359: iget-object v4, v4, La1/b;->b:Ljava/lang/Object;
    .line 361: check-cast v4, Lr3/s;
    .line 363: invoke-virtual {v4}, Lr3/s;->f()Ljava/lang/String;
    .line 366: move-result-object v4
    .line 367: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 370: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 373: move-result-object v3
    .line 374: iget-object v4, v1, Ld4/f;->a:Ld4/g;
    .line 376: invoke-virtual {v4, v3, v0}, Ld4/g;->d(Ljava/lang/String;Lv3/l;)V
    .line 379: iget-object v0, v1, Ld4/f;->a:Ld4/g;
    .line 381: iget-object v3, v0, Ld4/g;->b:Lcom/titanchess/accessibility/y;
    .line 383: invoke-virtual {v3, v0, v2}, Lcom/titanchess/accessibility/y;->a(Ld4/g;Lr3/z;)V
    .line 386: iget-object v0, v1, Ld4/f;->a:Ld4/g;
    .line 388: invoke-virtual {v0}, Ld4/g;->e()V
    .line 391: goto :goto_398
    .line 392: move-exception v0
    .line 393: iget-object v2, v1, Ld4/f;->a:Ld4/g;
    .line 395: invoke-virtual {v2, v0}, Ld4/g;->c(Ljava/lang/Exception;)V
    .line 398: return-void
    .line 399: move-exception v0
    .line 400: iget-object v4, v1, Ld4/f;->a:Ld4/g;
    .line 402: invoke-virtual {v4, v0}, Ld4/g;->c(Ljava/lang/Exception;)V
    .line 405: invoke-static/range {v21 .. v21}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 408: if-eqz v3, :cond_415
    .line 410: const/4 v2, 0
    .line 411: const/4 v4, 1
    .line 412: invoke-virtual {v3, v4, v4, v2}, Lv3/e;->a(ZZLjava/io/IOException;)Ljava/io/IOException;
    .line 415: return-void
.end method

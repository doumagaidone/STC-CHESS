.class public final Ld4/a;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Closeable;

.field public final synthetic i:I
.field public final j:Z
.field public final k:Le4/h;
.field public final l:Ljava/lang/Object;
.field public final m:Ljava/io/Closeable;

# direct methods
.method public constructor <init>(IZ)V
    .registers 5

    .line 0: iput v3, v2, Ld4/a;->i:I
    .line 2: const/4 v0, 1
    .line 3: if-eq v3, v0, :cond_33
    .line 5: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 8: iput-boolean v4, v2, Ld4/a;->j:Z
    .line 10: new-instance v3, Le4/h;
    .line 12: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 15: iput-object v3, v2, Ld4/a;->k:Le4/h;
    .line 17: new-instance v4, Ljava/util/zip/Deflater;
    .line 19: const/4 v1, -1
    .line 20: invoke-direct {v4, v1, v0}, Ljava/util/zip/Deflater;-><init>(IZ)V
    .line 23: iput-object v4, v2, Ld4/a;->l:Ljava/lang/Object;
    .line 25: new-instance v0, Lx3/f;
    .line 27: invoke-direct {v0, v3, v4}, Lx3/f;-><init>(Le4/h;Ljava/util/zip/Deflater;)V
    .line 30: iput-object v0, v2, Ld4/a;->m:Ljava/io/Closeable;
    .line 32: return-void
    .line 33: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 36: iput-boolean v4, v2, Ld4/a;->j:Z
    .line 38: new-instance v3, Le4/h;
    .line 40: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 43: iput-object v3, v2, Ld4/a;->k:Le4/h;
    .line 45: new-instance v4, Ljava/util/zip/Inflater;
    .line 47: invoke-direct {v4, v0}, Ljava/util/zip/Inflater;-><init>(Z)V
    .line 50: iput-object v4, v2, Ld4/a;->l:Ljava/lang/Object;
    .line 52: new-instance v0, Le4/n;
    .line 54: new-instance v1, Le4/r;
    .line 56: invoke-direct {v1, v3}, Le4/r;-><init>(Le4/x;)V
    .line 59: invoke-direct {v0, v1, v4}, Le4/n;-><init>(Le4/r;Ljava/util/zip/Inflater;)V
    .line 62: iput-object v0, v2, Ld4/a;->m:Ljava/io/Closeable;
    .line 64: return-void
.end method

# virtual methods
.method public final close()V
    .registers 3

    .line 0: iget v0, v2, Ld4/a;->i:I
    .line 2: iget-object v1, v2, Ld4/a;->m:Ljava/io/Closeable;
    .line 4: packed-switch v0, :data_20
    .line 7: check-cast v1, Le4/n;
    .line 9: invoke-virtual {v1}, Le4/n;->close()V
    .line 12: return-void
    .line 13: check-cast v1, Lx3/f;
    .line 15: invoke-virtual {v1}, Lx3/f;->close()V
    .line 18: return-void
    .line 19: nop
    .line 20: nop
    .line 21: move v0, v0
    .line 22: nop
    .line 23: nop
    .line 24: move-object/16 v0, v3
.end method

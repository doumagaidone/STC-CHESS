.class public final Ld4/j;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Closeable;

.field public final i:Z
.field public final j:Le4/j;
.field public final k:Ld4/i;
.field public final l:Z
.field public final m:Z
.field public n:Z
.field public o:I
.field public p:J
.field public q:Z
.field public r:Z
.field public s:Z
.field public final t:Le4/h;
.field public final u:Le4/h;
.field public v:Ld4/a;
.field public final w:[B
.field public final x:Le4/g;

# direct methods
.method public constructor <init>(ZLe4/j;Ld4/g;ZZ)V
    .registers 7

    .line 0: const-string v0, "source"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "frameCallback"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 13: iput-boolean v2, v1, Ld4/j;->i:Z
    .line 15: iput-object v3, v1, Ld4/j;->j:Le4/j;
    .line 17: iput-object v4, v1, Ld4/j;->k:Ld4/i;
    .line 19: iput-boolean v5, v1, Ld4/j;->l:Z
    .line 21: iput-boolean v6, v1, Ld4/j;->m:Z
    .line 23: new-instance v3, Le4/h;
    .line 25: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 28: iput-object v3, v1, Ld4/j;->t:Le4/h;
    .line 30: new-instance v3, Le4/h;
    .line 32: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 35: iput-object v3, v1, Ld4/j;->u:Le4/h;
    .line 37: const/4 v3, 0
    .line 38: if-eqz v2, :cond_42
    .line 40: move-object v4, v3
    .line 41: goto :goto_45
    .line 42: const/4 v4, 4
    .line 43: new-array v4, v4, [B
    .line 45: iput-object v4, v1, Ld4/j;->w:[B
    .line 47: if-eqz v2, :cond_50
    .line 49: goto :goto_55
    .line 50: new-instance v3, Le4/g;
    .line 52: invoke-direct {v3}, Le4/g;-><init>()V
    .line 55: iput-object v3, v1, Ld4/j;->x:Le4/g;
    .line 57: return-void
.end method

# virtual methods
.method public final a()V
    .registers 10

    .line 0: iget-wide v0, v9, Ld4/j;->p:J
    .line 2: const-wide/16 v2, 0
    .line 4: cmp-long v4, v0, v2
    .line 6: if-lez v4, :cond_49
    .line 8: iget-object v4, v9, Ld4/j;->j:Le4/j;
    .line 10: iget-object v5, v9, Ld4/j;->t:Le4/h;
    .line 12: invoke-interface {v4, v5, v0, v1}, Le4/j;->G(Le4/h;J)V
    .line 15: iget-boolean v0, v9, Ld4/j;->i:Z
    .line 17: if-nez v0, :cond_49
    .line 19: iget-object v0, v9, Ld4/j;->t:Le4/h;
    .line 21: iget-object v1, v9, Ld4/j;->x:Le4/g;
    .line 23: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 26: invoke-virtual {v0, v1}, Le4/h;->i(Le4/g;)Le4/g;
    .line 29: iget-object v0, v9, Ld4/j;->x:Le4/g;
    .line 31: invoke-virtual {v0, v2, v3}, Le4/g;->b(J)I
    .line 34: iget-object v0, v9, Ld4/j;->x:Le4/g;
    .line 36: iget-object v1, v9, Ld4/j;->w:[B
    .line 38: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 41: invoke-static {v0, v1}, Ld2/b;->m1(Le4/g;[B)V
    .line 44: iget-object v0, v9, Ld4/j;->x:Le4/g;
    .line 46: invoke-virtual {v0}, Le4/g;->close()V
    .line 49: iget v0, v9, Ld4/j;->o:I
    .line 51: packed-switch v0, :data_382
    .line 54: new-instance v0, Ljava/net/ProtocolException;
    .line 56: iget v1, v9, Ld4/j;->o:I
    .line 58: sget-object v2, Ls3/b;->a:[B
    .line 60: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    .line 63: move-result-object v1
    .line 64: const-string v2, "toHexString(this)"
    .line 66: invoke-static {v1, v2}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 69: const-string v2, "Unknown control opcode: "
    .line 71: invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    .line 74: move-result-object v1
    .line 75: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 78: throw v0
    .line 79: iget-object v0, v9, Ld4/j;->k:Ld4/i;
    .line 81: iget-object v1, v9, Ld4/j;->t:Le4/h;
    .line 83: iget-wide v2, v1, Le4/h;->j:J
    .line 85: invoke-virtual {v1, v2, v3}, Le4/h;->v(J)Le4/k;
    .line 88: move-result-object v1
    .line 89: check-cast v0, Ld4/g;
    .line 91: monitor-enter v0
    .line 92: const-string v2, "payload"
    .line 94: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 97: const/4 v1, 0
    .line 98: iput-boolean v1, v0, Ld4/g;->w:Z
    .line 100: monitor-exit v0
    .line 101: goto/16 :goto_331
    .line 103: move-exception v1
    .line 104: monitor-exit v0
    .line 105: throw v1
    .line 106: iget-object v0, v9, Ld4/j;->k:Ld4/i;
    .line 108: iget-object v1, v9, Ld4/j;->t:Le4/h;
    .line 110: iget-wide v2, v1, Le4/h;->j:J
    .line 112: invoke-virtual {v1, v2, v3}, Le4/h;->v(J)Le4/k;
    .line 115: move-result-object v1
    .line 116: check-cast v0, Ld4/g;
    .line 118: monitor-enter v0
    .line 119: const-string v2, "payload"
    .line 121: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 124: iget-boolean v2, v0, Ld4/g;->u:Z
    .line 126: if-nez v2, :cond_154
    .line 128: iget-boolean v2, v0, Ld4/g;->r:Z
    .line 130: if-eqz v2, :cond_143
    .line 132: iget-object v2, v0, Ld4/g;->p:Ljava/util/ArrayDeque;
    .line 134: invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z
    .line 137: move-result v2
    .line 138: if-eqz v2, :cond_143
    .line 140: goto :goto_154
    .line 141: move-exception v1
    .line 142: goto :goto_157
    .line 143: iget-object v2, v0, Ld4/g;->o:Ljava/util/ArrayDeque;
    .line 145: invoke-virtual {v2, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z
    .line 148: invoke-virtual {v0}, Ld4/g;->f()V
    .line 151: monitor-exit v0
    .line 152: goto/16 :goto_331
    .line 154: monitor-exit v0
    .line 155: goto/16 :goto_331
    .line 157: monitor-exit v0
    .line 158: throw v1
    .line 159: const-string v0, ""
    .line 161: iget-object v1, v9, Ld4/j;->t:Le4/h;
    .line 163: iget-wide v4, v1, Le4/h;->j:J
    .line 165: const-wide/16 v6, 1
    .line 167: cmp-long v6, v4, v6
    .line 169: if-eqz v6, :cond_374
    .line 171: cmp-long v2, v4, v2
    .line 173: const/4 v3, 0
    .line 174: if-eqz v2, :cond_238
    .line 176: invoke-virtual {v1}, Le4/h;->F()S
    .line 179: move-result v0
    .line 180: iget-object v1, v9, Ld4/j;->t:Le4/h;
    .line 182: invoke-virtual {v1}, Le4/h;->n()Ljava/lang/String;
    .line 185: move-result-object v1
    .line 186: const/16 v2, 1000
    .line 188: if-lt v0, v2, :cond_223
    .line 190: const/16 v2, 5000
    .line 192: if-lt v0, v2, :cond_195
    .line 194: goto :goto_223
    .line 195: const/16 v2, 1004
    .line 197: if-gt v2, v0, :cond_204
    .line 199: const/16 v2, 1007
    .line 201: if-ge v0, v2, :cond_204
    .line 203: goto :goto_212
    .line 204: const/16 v2, 1015
    .line 206: if-gt v2, v0, :cond_221
    .line 208: const/16 v2, 3000
    .line 210: if-ge v0, v2, :cond_221
    .line 212: const-string v2, "Code "
    .line 214: const-string v4, " is reserved and may not be used."
    .line 216: invoke-static {v2, v0, v4}, Lai/onnxruntime/b;->g(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .line 219: move-result-object v2
    .line 220: goto :goto_229
    .line 221: move-object v2, v3
    .line 222: goto :goto_229
    .line 223: const-string v2, "Code must be in range [1000,5000): "
    .line 225: invoke-static {v2, v0}, Lai/onnxruntime/b;->f(Ljava/lang/String;I)Ljava/lang/String;
    .line 228: move-result-object v2
    .line 229: if-nez v2, :cond_232
    .line 231: goto :goto_243
    .line 232: new-instance v0, Ljava/net/ProtocolException;
    .line 234: invoke-direct {v0, v2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 237: throw v0
    .line 238: const/16 v1, 1005
    .line 240: move v8, v1
    .line 241: move-object v1, v0
    .line 242: move v0, v8
    .line 243: iget-object v2, v9, Ld4/j;->k:Ld4/i;
    .line 245: check-cast v2, Ld4/g;
    .line 247: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 250: const/4 v4, -1
    .line 251: if-eq v0, v4, :cond_362
    .line 253: monitor-enter v2
    .line 254: iget v5, v2, Ld4/g;->s:I
    .line 256: if-ne v5, v4, :cond_348
    .line 258: iput v0, v2, Ld4/g;->s:I
    .line 260: iput-object v1, v2, Ld4/g;->t:Ljava/lang/String;
    .line 262: iget-boolean v0, v2, Ld4/g;->r:Z
    .line 264: if-eqz v0, :cond_295
    .line 266: iget-object v0, v2, Ld4/g;->p:Ljava/util/ArrayDeque;
    .line 268: invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z
    .line 271: move-result v0
    .line 272: if-eqz v0, :cond_295
    .line 274: iget-object v0, v2, Ld4/g;->n:Lv3/l;
    .line 276: iput-object v3, v2, Ld4/g;->n:Lv3/l;
    .line 278: iget-object v1, v2, Ld4/g;->j:Ld4/j;
    .line 280: iput-object v3, v2, Ld4/g;->j:Ld4/j;
    .line 282: iget-object v4, v2, Ld4/g;->k:Ld4/k;
    .line 284: iput-object v3, v2, Ld4/g;->k:Ld4/k;
    .line 286: iget-object v3, v2, Ld4/g;->l:Lu3/c;
    .line 288: invoke-virtual {v3}, Lu3/c;->e()V
    .line 291: move-object v3, v0
    .line 292: goto :goto_297
    .line 293: move-exception v0
    .line 294: goto :goto_360
    .line 295: move-object v1, v3
    .line 296: move-object v4, v1
    .line 297: monitor-exit v2
    .line 298: iget-object v0, v2, Ld4/g;->b:Lcom/titanchess/accessibility/y;
    .line 300: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 303: if-eqz v3, :cond_313
    .line 305: iget-object v0, v2, Ld4/g;->b:Lcom/titanchess/accessibility/y;
    .line 307: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 310: goto :goto_313
    .line 311: move-exception v0
    .line 312: goto :goto_332
    .line 313: if-eqz v3, :cond_318
    .line 315: invoke-static {v3}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 318: if-eqz v1, :cond_323
    .line 320: invoke-static {v1}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 323: if-eqz v4, :cond_328
    .line 325: invoke-static {v4}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 328: const/4 v0, 1
    .line 329: iput-boolean v0, v9, Ld4/j;->n:Z
    .line 331: return-void
    .line 332: if-eqz v3, :cond_337
    .line 334: invoke-static {v3}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 337: if-eqz v1, :cond_342
    .line 339: invoke-static {v1}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 342: if-eqz v4, :cond_347
    .line 344: invoke-static {v4}, Ls3/b;->c(Ljava/io/Closeable;)V
    .line 347: throw v0
    .line 348: const-string v0, "already closed"
    .line 350: new-instance v1, Ljava/lang/IllegalStateException;
    .line 352: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 355: move-result-object v0
    .line 356: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 359: throw v1
    .line 360: monitor-exit v2
    .line 361: throw v0
    .line 362: const-string v0, "Failed requirement."
    .line 364: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 366: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 369: move-result-object v0
    .line 370: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 373: throw v1
    .line 374: new-instance v0, Ljava/net/ProtocolException;
    .line 376: const-string v1, "Malformed close payload length of 1."
    .line 378: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 381: throw v0
    .line 382: nop
    .line 383: move/16 v8, v0
    .line 386: sput-char v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 388: if-le v0, v0, :cond_388
    .line 390: const-class v0, B
.end method

# virtual methods
.method public final b()V
    .registers 9

    .line 0: iget-boolean v0, v8, Ld4/j;->n:Z
    .line 2: if-nez v0, :cond_284
    .line 4: iget-object v0, v8, Ld4/j;->j:Le4/j;
    .line 6: invoke-interface {v0}, Le4/x;->d()Le4/z;
    .line 9: move-result-object v1
    .line 10: invoke-virtual {v1}, Le4/z;->h()J
    .line 13: move-result-wide v1
    .line 14: invoke-interface {v0}, Le4/x;->d()Le4/z;
    .line 17: move-result-object v3
    .line 18: invoke-virtual {v3}, Le4/z;->b()Le4/z;
    .line 21: invoke-interface {v0}, Le4/j;->K()B
    .line 24: move-result v3
    .line 25: sget-object v4, Ls3/b;->a:[B
    .line 27: invoke-interface {v0}, Le4/x;->d()Le4/z;
    .line 30: move-result-object v4
    .line 31: sget-object v5, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;
    .line 33: invoke-virtual {v4, v1, v2, v5}, Le4/z;->g(JLjava/util/concurrent/TimeUnit;)Le4/z;
    .line 36: and-int/lit8 v1, v3, 15
    .line 38: iput v1, v8, Ld4/j;->o:I
    .line 40: and-int/lit16 v2, v3, 128
    .line 42: const/4 v4, 0
    .line 43: const/4 v5, 1
    .line 44: if-eqz v2, :cond_48
    .line 46: move v2, v5
    .line 47: goto :goto_49
    .line 48: move v2, v4
    .line 49: iput-boolean v2, v8, Ld4/j;->q:Z
    .line 51: and-int/lit8 v6, v3, 8
    .line 53: if-eqz v6, :cond_57
    .line 55: move v6, v5
    .line 56: goto :goto_58
    .line 57: move v6, v4
    .line 58: iput-boolean v6, v8, Ld4/j;->r:Z
    .line 60: if-eqz v6, :cond_73
    .line 62: if-eqz v2, :cond_65
    .line 64: goto :goto_73
    .line 65: new-instance v0, Ljava/net/ProtocolException;
    .line 67: const-string v1, "Control frames must be final."
    .line 69: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 72: throw v0
    .line 73: and-int/lit8 v2, v3, 64
    .line 75: if-eqz v2, :cond_79
    .line 77: move v2, v5
    .line 78: goto :goto_80
    .line 79: move v2, v4
    .line 80: const-string v6, "Unexpected rsv1 flag"
    .line 82: if-eq v1, v5, :cond_96
    .line 84: const/4 v7, 2
    .line 85: if-eq v1, v7, :cond_96
    .line 87: if-nez v2, :cond_90
    .line 89: goto :goto_113
    .line 90: new-instance v0, Ljava/net/ProtocolException;
    .line 92: invoke-direct {v0, v6}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 95: throw v0
    .line 96: if-eqz v2, :cond_110
    .line 98: iget-boolean v1, v8, Ld4/j;->l:Z
    .line 100: if-eqz v1, :cond_104
    .line 102: move v1, v5
    .line 103: goto :goto_111
    .line 104: new-instance v0, Ljava/net/ProtocolException;
    .line 106: invoke-direct {v0, v6}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 109: throw v0
    .line 110: move v1, v4
    .line 111: iput-boolean v1, v8, Ld4/j;->s:Z
    .line 113: and-int/lit8 v1, v3, 32
    .line 115: if-nez v1, :cond_265
    .line 117: and-int/lit8 v1, v3, 16
    .line 119: if-nez v1, :cond_257
    .line 121: invoke-interface {v0}, Le4/j;->K()B
    .line 124: move-result v1
    .line 125: and-int/lit16 v2, v1, 128
    .line 127: if-eqz v2, :cond_130
    .line 129: move v4, v5
    .line 130: iget-boolean v2, v8, Ld4/j;->i:Z
    .line 132: if-ne v4, v2, :cond_147
    .line 134: new-instance v0, Ljava/net/ProtocolException;
    .line 136: if-eqz v2, :cond_141
    .line 138: const-string v1, "Server-sent frames must not be masked."
    .line 140: goto :goto_143
    .line 141: const-string v1, "Client-sent frames must be masked."
    .line 143: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 146: throw v0
    .line 147: and-int/lit8 v1, v1, 127
    .line 149: int-to-long v1, v1
    .line 150: iput-wide v1, v8, Ld4/j;->p:J
    .line 152: const-wide/16 v5, 126
    .line 154: cmp-long v3, v1, v5
    .line 156: if-nez v3, :cond_170
    .line 158: invoke-interface {v0}, Le4/j;->F()S
    .line 161: move-result v1
    .line 162: const v2, 0xffff
    .line 165: and-int/2addr v1, v2
    .line 166: int-to-long v1, v1
    .line 167: iput-wide v1, v8, Ld4/j;->p:J
    .line 169: goto :goto_225
    .line 170: const-wide/16 v5, 127
    .line 172: cmp-long v1, v1, v5
    .line 174: if-nez v1, :cond_225
    .line 176: invoke-interface {v0}, Le4/j;->m()J
    .line 179: move-result-wide v1
    .line 180: iput-wide v1, v8, Ld4/j;->p:J
    .line 182: const-wide/16 v5, 0
    .line 184: cmp-long v1, v1, v5
    .line 186: if-ltz v1, :cond_189
    .line 188: goto :goto_225
    .line 189: new-instance v0, Ljava/net/ProtocolException;
    .line 191: new-instance v1, Ljava/lang/StringBuilder;
    .line 193: const-string v2, "Frame length 0x"
    .line 195: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 198: iget-wide v2, v8, Ld4/j;->p:J
    .line 200: invoke-static {v2, v3}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;
    .line 203: move-result-object v2
    .line 204: const-string v3, "toHexString(this)"
    .line 206: invoke-static {v2, v3}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 209: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 212: const-string v2, " > 0x7FFFFFFFFFFFFFFF"
    .line 214: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 217: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 220: move-result-object v1
    .line 221: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 224: throw v0
    .line 225: iget-boolean v1, v8, Ld4/j;->r:Z
    .line 227: if-eqz v1, :cond_246
    .line 229: iget-wide v1, v8, Ld4/j;->p:J
    .line 231: const-wide/16 v5, 125
    .line 233: cmp-long v1, v1, v5
    .line 235: if-gtz v1, :cond_238
    .line 237: goto :goto_246
    .line 238: new-instance v0, Ljava/net/ProtocolException;
    .line 240: const-string v1, "Control frame must be less than 125B."
    .line 242: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 245: throw v0
    .line 246: if-eqz v4, :cond_256
    .line 248: iget-object v1, v8, Ld4/j;->w:[B
    .line 250: invoke-static {v1}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 253: invoke-interface {v0, v1}, Le4/j;->l([B)V
    .line 256: return-void
    .line 257: new-instance v0, Ljava/net/ProtocolException;
    .line 259: const-string v1, "Unexpected rsv3 flag"
    .line 261: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 264: throw v0
    .line 265: new-instance v0, Ljava/net/ProtocolException;
    .line 267: const-string v1, "Unexpected rsv2 flag"
    .line 269: invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V
    .line 272: throw v0
    .line 273: move-exception v3
    .line 274: invoke-interface {v0}, Le4/x;->d()Le4/z;
    .line 277: move-result-object v0
    .line 278: sget-object v4, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;
    .line 280: invoke-virtual {v0, v1, v2, v4}, Le4/z;->g(JLjava/util/concurrent/TimeUnit;)Le4/z;
    .line 283: throw v3
    .line 284: new-instance v0, Ljava/io/IOException;
    .line 286: const-string v1, "closed"
    .line 288: invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 291: throw v0
.end method

# virtual methods
.method public final close()V
    .registers 2

    .line 0: iget-object v0, v1, Ld4/j;->v:Ld4/a;
    .line 2: if-eqz v0, :cond_7
    .line 4: invoke-virtual {v0}, Ld4/a;->close()V
    .line 7: return-void
.end method

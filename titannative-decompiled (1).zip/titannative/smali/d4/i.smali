.class public abstract interface Ld4/i;
.super Ljava/lang/Object;
.source "SourceFile"

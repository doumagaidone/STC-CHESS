.class public final Ld4/k;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Closeable;

.field public final i:Z
.field public final j:Le4/i;
.field public final k:Ljava/util/Random;
.field public final l:Z
.field public final m:Z
.field public final n:J
.field public final o:Le4/h;
.field public final p:Le4/h;
.field public q:Z
.field public r:Ld4/a;
.field public final s:[B
.field public final t:Le4/g;

# direct methods
.method public constructor <init>(ZLe4/i;Ljava/util/Random;ZZJ)V
    .registers 9

    .line 0: const-string v0, "sink"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "random"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 13: iput-boolean v2, v1, Ld4/k;->i:Z
    .line 15: iput-object v3, v1, Ld4/k;->j:Le4/i;
    .line 17: iput-object v4, v1, Ld4/k;->k:Ljava/util/Random;
    .line 19: iput-boolean v5, v1, Ld4/k;->l:Z
    .line 21: iput-boolean v6, v1, Ld4/k;->m:Z
    .line 23: iput-wide v7, v1, Ld4/k;->n:J
    .line 25: new-instance v4, Le4/h;
    .line 27: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    .line 30: iput-object v4, v1, Ld4/k;->o:Le4/h;
    .line 32: invoke-interface {v3}, Le4/i;->c()Le4/h;
    .line 35: move-result-object v3
    .line 36: iput-object v3, v1, Ld4/k;->p:Le4/h;
    .line 38: const/4 v3, 0
    .line 39: if-eqz v2, :cond_45
    .line 41: const/4 v4, 4
    .line 42: new-array v4, v4, [B
    .line 44: goto :goto_46
    .line 45: move-object v4, v3
    .line 46: iput-object v4, v1, Ld4/k;->s:[B
    .line 48: if-eqz v2, :cond_55
    .line 50: new-instance v3, Le4/g;
    .line 52: invoke-direct {v3}, Le4/g;-><init>()V
    .line 55: iput-object v3, v1, Ld4/k;->t:Le4/g;
    .line 57: return-void
.end method

# virtual methods
.method public final a(ILe4/k;)V
    .registers 8

    .line 0: iget-boolean v0, v5, Ld4/k;->q:Z
    .line 2: if-nez v0, :cond_93
    .line 4: invoke-virtual {v7}, Le4/k;->c()I
    .line 7: move-result v0
    .line 8: int-to-long v1, v0
    .line 9: const-wide/16 v3, 125
    .line 11: cmp-long v1, v1, v3
    .line 13: if-gtz v1, :cond_81
    .line 15: or-int/lit16 v6, v6, 128
    .line 17: iget-object v1, v5, Ld4/k;->p:Le4/h;
    .line 19: invoke-virtual {v1, v6}, Le4/h;->O(I)V
    .line 22: iget-boolean v6, v5, Ld4/k;->i:Z
    .line 24: if-eqz v6, :cond_69
    .line 26: or-int/lit16 v6, v0, 128
    .line 28: invoke-virtual {v1, v6}, Le4/h;->O(I)V
    .line 31: iget-object v6, v5, Ld4/k;->s:[B
    .line 33: invoke-static {v6}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 36: iget-object v2, v5, Ld4/k;->k:Ljava/util/Random;
    .line 38: invoke-virtual {v2, v6}, Ljava/util/Random;->nextBytes([B)V
    .line 41: invoke-virtual {v1, v6}, Le4/h;->I([B)V
    .line 44: if-lez v0, :cond_75
    .line 46: iget-wide v2, v1, Le4/h;->j:J
    .line 48: invoke-virtual {v1, v7}, Le4/h;->x(Le4/k;)V
    .line 51: iget-object v7, v5, Ld4/k;->t:Le4/g;
    .line 53: invoke-static {v7}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 56: invoke-virtual {v1, v7}, Le4/h;->i(Le4/g;)Le4/g;
    .line 59: invoke-virtual {v7, v2, v3}, Le4/g;->b(J)I
    .line 62: invoke-static {v7, v6}, Ld2/b;->m1(Le4/g;[B)V
    .line 65: invoke-virtual {v7}, Le4/g;->close()V
    .line 68: goto :goto_75
    .line 69: invoke-virtual {v1, v0}, Le4/h;->O(I)V
    .line 72: invoke-virtual {v1, v7}, Le4/h;->x(Le4/k;)V
    .line 75: iget-object v6, v5, Ld4/k;->j:Le4/i;
    .line 77: invoke-interface {v6}, Le4/i;->flush()V
    .line 80: return-void
    .line 81: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 83: const-string v7, "Payload size must be less than or equal to 125"
    .line 85: invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 88: move-result-object v7
    .line 89: invoke-direct {v6, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 92: throw v6
    .line 93: new-instance v6, Ljava/io/IOException;
    .line 95: const-string v7, "closed"
    .line 97: invoke-direct {v6, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 100: throw v6
.end method

# virtual methods
.method public final b(ILe4/k;)V
    .registers 21

    .line 0: move-object/from16 v1, v18
    .line 2: move/from16 v0, v19
    .line 4: move-object/from16 v2, v20
    .line 6: const-string v3, "data"
    .line 8: invoke-static {v2, v3}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: iget-boolean v3, v1, Ld4/k;->q:Z
    .line 13: if-nez v3, :cond_387
    .line 15: iget-object v3, v1, Ld4/k;->o:Le4/h;
    .line 17: invoke-virtual {v3, v2}, Le4/h;->x(Le4/k;)V
    .line 20: or-int/lit16 v4, v0, 128
    .line 22: iget-boolean v5, v1, Ld4/k;->l:Z
    .line 24: const-wide/16 v6, 0
    .line 26: const/4 v8, 0
    .line 27: if-eqz v5, :cond_181
    .line 29: invoke-virtual/range {v20 .. v20}, Le4/k;->c()I
    .line 32: move-result v2
    .line 33: int-to-long v9, v2
    .line 34: iget-wide v11, v1, Ld4/k;->n:J
    .line 36: cmp-long v2, v9, v11
    .line 38: if-ltz v2, :cond_181
    .line 40: iget-object v2, v1, Ld4/k;->r:Ld4/a;
    .line 42: if-nez v2, :cond_53
    .line 44: new-instance v2, Ld4/a;
    .line 46: iget-boolean v4, v1, Ld4/k;->m:Z
    .line 48: invoke-direct {v2, v8, v4}, Ld4/a;-><init>(IZ)V
    .line 51: iput-object v2, v1, Ld4/k;->r:Ld4/a;
    .line 53: iget-object v4, v2, Ld4/a;->k:Le4/h;
    .line 55: iget-wide v9, v4, Le4/h;->j:J
    .line 57: cmp-long v5, v9, v6
    .line 59: if-nez v5, :cond_169
    .line 61: iget-boolean v5, v2, Ld4/a;->j:Z
    .line 63: if-eqz v5, :cond_72
    .line 65: iget-object v5, v2, Ld4/a;->l:Ljava/lang/Object;
    .line 67: check-cast v5, Ljava/util/zip/Deflater;
    .line 69: invoke-virtual {v5}, Ljava/util/zip/Deflater;->reset()V
    .line 72: iget-object v2, v2, Ld4/a;->m:Ljava/io/Closeable;
    .line 74: check-cast v2, Lx3/f;
    .line 76: iget-wide v9, v3, Le4/h;->j:J
    .line 78: invoke-virtual {v2, v3, v9, v10}, Lx3/f;->y(Le4/h;J)V
    .line 81: invoke-virtual {v2}, Lx3/f;->flush()V
    .line 84: sget-object v2, Ld4/b;->a:Le4/k;
    .line 86: iget-wide v9, v4, Le4/h;->j:J
    .line 88: iget-object v5, v2, Le4/k;->i:[B
    .line 90: array-length v11, v5
    .line 91: int-to-long v11, v11
    .line 92: sub-long v11, v9, v11
    .line 94: array-length v13, v5
    .line 95: cmp-long v14, v11, v6
    .line 97: if-ltz v14, :cond_158
    .line 99: if-ltz v13, :cond_158
    .line 101: sub-long/2addr v9, v11
    .line 102: int-to-long v14, v13
    .line 103: cmp-long v9, v9, v14
    .line 105: if-ltz v9, :cond_158
    .line 107: array-length v5, v5
    .line 108: if-ge v5, v13, :cond_111
    .line 110: goto :goto_158
    .line 111: move v5, v8
    .line 112: if-ge v5, v13, :cond_130
    .line 114: int-to-long v9, v5
    .line 115: add-long/2addr v9, v11
    .line 116: invoke-virtual {v4, v9, v10}, Le4/h;->b(J)B
    .line 119: move-result v9
    .line 120: iget-object v10, v2, Le4/k;->i:[B
    .line 122: aget-byte v10, v10, v5
    .line 124: if-eq v9, v10, :cond_127
    .line 126: goto :goto_158
    .line 127: add-int/lit8 v5, v5, 1
    .line 129: goto :goto_112
    .line 130: iget-wide v9, v4, Le4/h;->j:J
    .line 132: const/4 v2, 4
    .line 133: int-to-long v11, v2
    .line 134: sub-long/2addr v9, v11
    .line 135: sget-object v2, Le4/b;->a:Le4/g;
    .line 137: invoke-virtual {v4, v2}, Le4/h;->i(Le4/g;)Le4/g;
    .line 140: move-result-object v2
    .line 141: invoke-virtual {v2, v9, v10}, Le4/g;->a(J)V
    .line 144: const/4 v5, 0
    .line 145: invoke-static {v2, v5}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 148: goto :goto_161
    .line 149: move-exception v0
    .line 150: move-object v3, v0
    .line 151: throw v3
    .line 152: move-exception v0
    .line 153: move-object v4, v0
    .line 154: invoke-static {v2, v3}, Ld2/c;->v(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .line 157: throw v4
    .line 158: invoke-virtual {v4, v8}, Le4/h;->O(I)V
    .line 161: iget-wide v9, v4, Le4/h;->j:J
    .line 163: invoke-virtual {v3, v4, v9, v10}, Le4/h;->y(Le4/h;J)V
    .line 166: or-int/lit16 v4, v0, 192
    .line 168: goto :goto_181
    .line 169: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 171: const-string v2, "Failed requirement."
    .line 173: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 176: move-result-object v2
    .line 177: invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 180: throw v0
    .line 181: iget-wide v9, v3, Le4/h;->j:J
    .line 183: iget-object v0, v1, Ld4/k;->p:Le4/h;
    .line 185: invoke-virtual {v0, v4}, Le4/h;->O(I)V
    .line 188: iget-boolean v2, v1, Ld4/k;->i:Z
    .line 190: if-eqz v2, :cond_194
    .line 192: const/16 v8, 128
    .line 194: const-wide/16 v4, 125
    .line 196: cmp-long v4, v9, v4
    .line 198: if-gtz v4, :cond_207
    .line 200: long-to-int v4, v9
    .line 201: or-int/2addr v4, v8
    .line 202: invoke-virtual {v0, v4}, Le4/h;->O(I)V
    .line 205: goto/16 :goto_340
    .line 207: const-wide/32 v4, 0xffff
    .line 210: cmp-long v4, v9, v4
    .line 212: if-gtz v4, :cond_224
    .line 214: or-int/lit8 v4, v8, 126
    .line 216: invoke-virtual {v0, v4}, Le4/h;->O(I)V
    .line 219: long-to-int v4, v9
    .line 220: invoke-virtual {v0, v4}, Le4/h;->R(I)V
    .line 223: goto :goto_340
    .line 224: or-int/lit8 v4, v8, 127
    .line 226: invoke-virtual {v0, v4}, Le4/h;->O(I)V
    .line 229: const/16 v4, 8
    .line 231: invoke-virtual {v0, v4}, Le4/h;->t(I)Le4/s;
    .line 234: move-result-object v5
    .line 235: iget v8, v5, Le4/s;->c:I
    .line 237: add-int/lit8 v11, v8, 1
    .line 239: const/16 v12, 56
    .line 241: ushr-long v12, v9, v12
    .line 243: const-wide/16 v14, 255
    .line 245: and-long/2addr v12, v14
    .line 246: long-to-int v12, v12
    .line 247: int-to-byte v12, v12
    .line 248: iget-object v13, v5, Le4/s;->a:[B
    .line 250: aput-byte v12, v13, v8
    .line 252: add-int/lit8 v12, v8, 2
    .line 254: const/16 v16, 48
    .line 256: ushr-long v16, v9, v16
    .line 258: and-long v6, v16, v14
    .line 260: long-to-int v6, v6
    .line 261: int-to-byte v6, v6
    .line 262: aput-byte v6, v13, v11
    .line 264: add-int/lit8 v6, v8, 3
    .line 266: const/16 v7, 40
    .line 268: ushr-long v16, v9, v7
    .line 270: move-object/from16 v20, v5
    .line 272: and-long v4, v16, v14
    .line 274: long-to-int v4, v4
    .line 275: int-to-byte v4, v4
    .line 276: aput-byte v4, v13, v12
    .line 278: add-int/lit8 v4, v8, 4
    .line 280: const/16 v5, 32
    .line 282: ushr-long v11, v9, v5
    .line 284: and-long/2addr v11, v14
    .line 285: long-to-int v5, v11
    .line 286: int-to-byte v5, v5
    .line 287: aput-byte v5, v13, v6
    .line 289: add-int/lit8 v5, v8, 5
    .line 291: const/16 v6, 24
    .line 293: ushr-long v6, v9, v6
    .line 295: and-long/2addr v6, v14
    .line 296: long-to-int v6, v6
    .line 297: int-to-byte v6, v6
    .line 298: aput-byte v6, v13, v4
    .line 300: add-int/lit8 v4, v8, 6
    .line 302: const/16 v6, 16
    .line 304: ushr-long v6, v9, v6
    .line 306: and-long/2addr v6, v14
    .line 307: long-to-int v6, v6
    .line 308: int-to-byte v6, v6
    .line 309: aput-byte v6, v13, v5
    .line 311: add-int/lit8 v5, v8, 7
    .line 313: const/16 v6, 8
    .line 315: ushr-long v11, v9, v6
    .line 317: and-long/2addr v11, v14
    .line 318: long-to-int v7, v11
    .line 319: int-to-byte v7, v7
    .line 320: aput-byte v7, v13, v4
    .line 322: add-int/2addr v8, v6
    .line 323: and-long v6, v9, v14
    .line 325: long-to-int v4, v6
    .line 326: int-to-byte v4, v4
    .line 327: aput-byte v4, v13, v5
    .line 329: move-object/from16 v4, v20
    .line 331: iput v8, v4, Le4/s;->c:I
    .line 333: iget-wide v4, v0, Le4/h;->j:J
    .line 335: const-wide/16 v6, 8
    .line 337: add-long/2addr v4, v6
    .line 338: iput-wide v4, v0, Le4/h;->j:J
    .line 340: if-eqz v2, :cond_378
    .line 342: iget-object v2, v1, Ld4/k;->s:[B
    .line 344: invoke-static {v2}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 347: iget-object v4, v1, Ld4/k;->k:Ljava/util/Random;
    .line 349: invoke-virtual {v4, v2}, Ljava/util/Random;->nextBytes([B)V
    .line 352: invoke-virtual {v0, v2}, Le4/h;->I([B)V
    .line 355: const-wide/16 v4, 0
    .line 357: cmp-long v6, v9, v4
    .line 359: if-lez v6, :cond_378
    .line 361: iget-object v6, v1, Ld4/k;->t:Le4/g;
    .line 363: invoke-static {v6}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 366: invoke-virtual {v3, v6}, Le4/h;->i(Le4/g;)Le4/g;
    .line 369: invoke-virtual {v6, v4, v5}, Le4/g;->b(J)I
    .line 372: invoke-static {v6, v2}, Ld2/b;->m1(Le4/g;[B)V
    .line 375: invoke-virtual {v6}, Le4/g;->close()V
    .line 378: invoke-virtual {v0, v3, v9, v10}, Le4/h;->y(Le4/h;J)V
    .line 381: iget-object v0, v1, Ld4/k;->j:Le4/i;
    .line 383: invoke-interface {v0}, Le4/i;->E()Le4/i;
    .line 386: return-void
    .line 387: new-instance v0, Ljava/io/IOException;
    .line 389: const-string v2, "closed"
    .line 391: invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    .line 394: throw v0
.end method

# virtual methods
.method public final close()V
    .registers 2

    .line 0: iget-object v0, v1, Ld4/k;->r:Ld4/a;
    .line 2: if-eqz v0, :cond_7
    .line 4: invoke-virtual {v0}, Ld4/a;->close()V
    .line 7: return-void
.end method

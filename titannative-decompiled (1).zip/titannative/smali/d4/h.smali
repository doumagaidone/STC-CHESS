.class public final Ld4/h;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Z
.field public final b:Ljava/lang/Integer;
.field public final c:Z
.field public final d:Ljava/lang/Integer;
.field public final e:Z
.field public final f:Z

# direct methods
.method public constructor <init>(ZLjava/lang/Integer;ZLjava/lang/Integer;ZZ)V
    .registers 7

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-boolean v1, v0, Ld4/h;->a:Z
    .line 5: iput-object v2, v0, Ld4/h;->b:Ljava/lang/Integer;
    .line 7: iput-boolean v3, v0, Ld4/h;->c:Z
    .line 9: iput-object v4, v0, Ld4/h;->d:Ljava/lang/Integer;
    .line 11: iput-boolean v5, v0, Ld4/h;->e:Z
    .line 13: iput-boolean v6, v0, Ld4/h;->f:Z
    .line 15: return-void
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Ld4/h;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Ld4/h;
    .line 12: iget-boolean v1, v5, Ld4/h;->a:Z
    .line 14: iget-boolean v3, v4, Ld4/h;->a:Z
    .line 16: if-eq v3, v1, :cond_19
    .line 18: return v2
    .line 19: iget-object v1, v4, Ld4/h;->b:Ljava/lang/Integer;
    .line 21: iget-object v3, v5, Ld4/h;->b:Ljava/lang/Integer;
    .line 23: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 26: move-result v1
    .line 27: if-nez v1, :cond_30
    .line 29: return v2
    .line 30: iget-boolean v1, v4, Ld4/h;->c:Z
    .line 32: iget-boolean v3, v5, Ld4/h;->c:Z
    .line 34: if-eq v1, v3, :cond_37
    .line 36: return v2
    .line 37: iget-object v1, v4, Ld4/h;->d:Ljava/lang/Integer;
    .line 39: iget-object v3, v5, Ld4/h;->d:Ljava/lang/Integer;
    .line 41: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 44: move-result v1
    .line 45: if-nez v1, :cond_48
    .line 47: return v2
    .line 48: iget-boolean v1, v4, Ld4/h;->e:Z
    .line 50: iget-boolean v3, v5, Ld4/h;->e:Z
    .line 52: if-eq v1, v3, :cond_55
    .line 54: return v2
    .line 55: iget-boolean v1, v4, Ld4/h;->f:Z
    .line 57: iget-boolean v5, v5, Ld4/h;->f:Z
    .line 59: if-eq v1, v5, :cond_62
    .line 61: return v2
    .line 62: return v0
.end method

# virtual methods
.method public final hashCode()I
    .registers 5

    .line 0: const/4 v0, 1
    .line 1: iget-boolean v1, v4, Ld4/h;->a:Z
    .line 3: if-eqz v1, :cond_6
    .line 5: move v1, v0
    .line 6: mul-int/lit8 v1, v1, 31
    .line 8: const/4 v2, 0
    .line 9: iget-object v3, v4, Ld4/h;->b:Ljava/lang/Integer;
    .line 11: if-nez v3, :cond_15
    .line 13: move v3, v2
    .line 14: goto :goto_19
    .line 15: invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I
    .line 18: move-result v3
    .line 19: add-int/2addr v1, v3
    .line 20: mul-int/lit8 v1, v1, 31
    .line 22: iget-boolean v3, v4, Ld4/h;->c:Z
    .line 24: if-eqz v3, :cond_27
    .line 26: move v3, v0
    .line 27: add-int/2addr v1, v3
    .line 28: mul-int/lit8 v1, v1, 31
    .line 30: iget-object v3, v4, Ld4/h;->d:Ljava/lang/Integer;
    .line 32: if-nez v3, :cond_35
    .line 34: goto :goto_39
    .line 35: invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I
    .line 38: move-result v2
    .line 39: add-int/2addr v1, v2
    .line 40: mul-int/lit8 v1, v1, 31
    .line 42: iget-boolean v2, v4, Ld4/h;->e:Z
    .line 44: if-eqz v2, :cond_47
    .line 46: move v2, v0
    .line 47: add-int/2addr v1, v2
    .line 48: mul-int/lit8 v1, v1, 31
    .line 50: iget-boolean v2, v4, Ld4/h;->f:Z
    .line 52: if-eqz v2, :cond_55
    .line 54: goto :goto_56
    .line 55: move v0, v2
    .line 56: add-int/2addr v1, v0
    .line 57: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "WebSocketExtensions(perMessageDeflate="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-boolean v1, v2, Ld4/h;->a:Z
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", clientMaxWindowBits="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v2, Ld4/h;->b:Ljava/lang/Integer;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", clientNoContextTakeover="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-boolean v1, v2, Ld4/h;->c:Z
    .line 29: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 32: const-string v1, ", serverMaxWindowBits="
    .line 34: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: iget-object v1, v2, Ld4/h;->d:Ljava/lang/Integer;
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", serverNoContextTakeover="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-boolean v1, v2, Ld4/h;->e:Z
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 52: const-string v1, ", unknownValues="
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: iget-boolean v1, v2, Ld4/h;->f:Z
    .line 59: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 62: const/16 v1, 41
    .line 64: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 67: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 70: move-result-object v0
    .line 71: return-object v0
.end method

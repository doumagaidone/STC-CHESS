.class public final Ld4/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:Le4/k;
.field public final c:J

# direct methods
.method public constructor <init>(ILe4/k;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Ld4/c;->a:I
    .line 5: iput-object v2, v0, Ld4/c;->b:Le4/k;
    .line 7: const-wide/32 v1, 0xea60
    .line 10: iput-wide v1, v0, Ld4/c;->c:J
    .line 12: return-void
.end method

.class public final Ld4/d;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I
.field public final b:Le4/k;

# direct methods
.method public constructor <init>(Le4/k;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 1
    .line 4: iput v0, v1, Ld4/d;->a:I
    .line 6: iput-object v2, v1, Ld4/d;->b:Le4/k;
    .line 8: return-void
.end method

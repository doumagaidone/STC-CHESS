.class public final Lf2/a;
.super Landroid/text/style/ClickableSpan;
.source "SourceFile"

.field public final a:I
.field public final b:Lf2/k;
.field public final c:I

# direct methods
.method public constructor <init>(ILf2/k;I)V
    .registers 4

    .line 0: invoke-direct {v0}, Landroid/text/style/ClickableSpan;-><init>()V
    .line 3: iput v1, v0, Lf2/a;->a:I
    .line 5: iput-object v2, v0, Lf2/a;->b:Lf2/k;
    .line 7: iput v3, v0, Lf2/a;->c:I
    .line 9: return-void
.end method

# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0: new-instance v3, Landroid/os/Bundle;
    .line 2: invoke-direct {v3}, Landroid/os/Bundle;-><init>()V
    .line 5: const-string v0, "ACCESSIBILITY_CLICKABLE_SPAN_ID"
    .line 7: iget v1, v2, Lf2/a;->a:I
    .line 9: invoke-virtual {v3, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V
    .line 12: iget-object v0, v2, Lf2/a;->b:Lf2/k;
    .line 14: iget-object v0, v0, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 16: iget v1, v2, Lf2/a;->c:I
    .line 18: invoke-virtual {v0, v1, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z
    .line 21: return-void
.end method

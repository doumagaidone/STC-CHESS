.class public final Lf2/k;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static d:I

.field public final a:Landroid/view/accessibility/AccessibilityNodeInfo;
.field public b:I
.field public c:I

# direct methods
.method public constructor <init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, -1
    .line 4: iput v0, v1, Lf2/k;->b:I
    .line 6: iput v0, v1, Lf2/k;->c:I
    .line 8: iput-object v2, v1, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 10: return-void
.end method

# direct methods
.method public constructor <init>(Landroid/view/accessibility/AccessibilityNodeInfo;I)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v2, -1
    .line 4: iput v2, v0, Lf2/k;->b:I
    .line 6: iput v2, v0, Lf2/k;->c:I
    .line 8: iput-object v1, v0, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 10: return-void
.end method

# direct methods
.method public static c(I)Ljava/lang/String;
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: if-eq v1, v0, :cond_144
    .line 3: const/4 v0, 2
    .line 4: if-eq v1, v0, :cond_141
    .line 6: sparse-switch v1, :data_148
    .line 9: packed-switch v1, :data_234
    .line 12: packed-switch v1, :data_254
    .line 15: packed-switch v1, :data_272
    .line 18: const-string v1, "ACTION_UNKNOWN"
    .line 20: return-object v1
    .line 21: const-string v1, "ACTION_DRAG_CANCEL"
    .line 23: return-object v1
    .line 24: const-string v1, "ACTION_DRAG_DROP"
    .line 26: return-object v1
    .line 27: const-string v1, "ACTION_DRAG_START"
    .line 29: return-object v1
    .line 30: const-string v1, "ACTION_IME_ENTER"
    .line 32: return-object v1
    .line 33: const-string v1, "ACTION_PRESS_AND_HOLD"
    .line 35: return-object v1
    .line 36: const-string v1, "ACTION_PAGE_RIGHT"
    .line 38: return-object v1
    .line 39: const-string v1, "ACTION_PAGE_LEFT"
    .line 41: return-object v1
    .line 42: const-string v1, "ACTION_PAGE_DOWN"
    .line 44: return-object v1
    .line 45: const-string v1, "ACTION_PAGE_UP"
    .line 47: return-object v1
    .line 48: const-string v1, "ACTION_HIDE_TOOLTIP"
    .line 50: return-object v1
    .line 51: const-string v1, "ACTION_SHOW_TOOLTIP"
    .line 53: return-object v1
    .line 54: const-string v1, "ACTION_SET_PROGRESS"
    .line 56: return-object v1
    .line 57: const-string v1, "ACTION_CONTEXT_CLICK"
    .line 59: return-object v1
    .line 60: const-string v1, "ACTION_SCROLL_RIGHT"
    .line 62: return-object v1
    .line 63: const-string v1, "ACTION_SCROLL_DOWN"
    .line 65: return-object v1
    .line 66: const-string v1, "ACTION_SCROLL_LEFT"
    .line 68: return-object v1
    .line 69: const-string v1, "ACTION_SCROLL_UP"
    .line 71: return-object v1
    .line 72: const-string v1, "ACTION_SCROLL_TO_POSITION"
    .line 74: return-object v1
    .line 75: const-string v1, "ACTION_SHOW_ON_SCREEN"
    .line 77: return-object v1
    .line 78: const-string v1, "ACTION_SCROLL_IN_DIRECTION"
    .line 80: return-object v1
    .line 81: const-string v1, "ACTION_MOVE_WINDOW"
    .line 83: return-object v1
    .line 84: const-string v1, "ACTION_SET_TEXT"
    .line 86: return-object v1
    .line 87: const-string v1, "ACTION_COLLAPSE"
    .line 89: return-object v1
    .line 90: const-string v1, "ACTION_EXPAND"
    .line 92: return-object v1
    .line 93: const-string v1, "ACTION_SET_SELECTION"
    .line 95: return-object v1
    .line 96: const-string v1, "ACTION_CUT"
    .line 98: return-object v1
    .line 99: const-string v1, "ACTION_PASTE"
    .line 101: return-object v1
    .line 102: const-string v1, "ACTION_COPY"
    .line 104: return-object v1
    .line 105: const-string v1, "ACTION_SCROLL_BACKWARD"
    .line 107: return-object v1
    .line 108: const-string v1, "ACTION_SCROLL_FORWARD"
    .line 110: return-object v1
    .line 111: const-string v1, "ACTION_PREVIOUS_HTML_ELEMENT"
    .line 113: return-object v1
    .line 114: const-string v1, "ACTION_NEXT_HTML_ELEMENT"
    .line 116: return-object v1
    .line 117: const-string v1, "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY"
    .line 119: return-object v1
    .line 120: const-string v1, "ACTION_NEXT_AT_MOVEMENT_GRANULARITY"
    .line 122: return-object v1
    .line 123: const-string v1, "ACTION_CLEAR_ACCESSIBILITY_FOCUS"
    .line 125: return-object v1
    .line 126: const-string v1, "ACTION_ACCESSIBILITY_FOCUS"
    .line 128: return-object v1
    .line 129: const-string v1, "ACTION_LONG_CLICK"
    .line 131: return-object v1
    .line 132: const-string v1, "ACTION_CLICK"
    .line 134: return-object v1
    .line 135: const-string v1, "ACTION_CLEAR_SELECTION"
    .line 137: return-object v1
    .line 138: const-string v1, "ACTION_SELECT"
    .line 140: return-object v1
    .line 141: const-string v1, "ACTION_CLEAR_FOCUS"
    .line 143: return-object v1
    .line 144: const-string v1, "ACTION_FOCUS"
    .line 146: return-object v1
    .line 147: nop
    .line 148: nop
    .line 149: const/high16 v0, 0x4
    .line 151: nop
    .line 152: move-object/from16 v0, v0
    .line 154: return-wide v0
    .line 155: nop
    .line 156: instance-of v0, v0, B
    .line 158: 0x40 ; unknown opcode
    .line 159: nop
    .line 160: neg-double v0, v0
    .line 161: nop
    .line 162: nop
    .line 163: nop
    .line 164: nop
    .line 165: nop
    .line 166: nop
    .line 167: nop
    .line 168: nop
    .line 169: nop
    .line 170: nop
    .line 171: nop
    .line 172: nop
    .line 173: nop
    .line 174: nop
    .line 175: nop
    .line 176: nop
    .line 177: nop
    .line 178: nop
    .line 179: move v0, v0
    .line 180: nop
    .line 181: move/from16 v0, v0
    .line 183: move-wide v0, v0
    .line 184: nop
    .line 185: move-object/from16 v0, v0
    .line 187: instance-of v0, v0, Lai/onnxruntime/OrtProviderOptions;
    .line 189: move/from16 v1, v94
    .line 191: move/from16 v1, v132
    .line 193: nop
    .line 194: int-to-long v0, v0
    .line 195: nop
    .line 196: not-long v0, v0
    .line 197: nop
    .line 198: neg-int v0, v0
    .line 199: nop
    .line 200: invoke-interface/range {}, La/a;-><clinit>()V
    .line 203: nop
    .line 204: invoke-interface {}, La/a;-><clinit>()V
    .line 207: nop
    .line 208: sput-char v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 210: sput-object v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 212: sget-short v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 214: sget-boolean v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 216: sget v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 218: iput-byte v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 220: iput-wide v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 222: iget-char v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 224: iget-object v0, v0, La/a;->a:Landroid/view/ViewGroup$LayoutParams;
    .line 226: aput-short v0, v0, v0
    .line 228: aput-boolean v0, v0, v0
    .line 230: aput v0, v0, v0
    .line 232: aget-byte v0, v0, v0
    .line 234: nop
    .line 235: move-object/from16 v0, v54
    .line 237: move/from16 v1, v66
    .line 239: nop
    .line 240: 0x3f ; unknown opcode
    .line 241: nop
    .line 242: if-gtz v0, :cond_242
    .line 244: if-nez v0, :cond_244
    .line 246: if-gt v0, v0, :cond_246
    .line 248: if-ne v0, v0, :cond_248
    .line 250: cmpg-double v0, v0, v0
    .line 252: cmpl-float v0, v0, v0
    .line 254: nop
    .line 255: move-object v0, v0
    .line 256: aget v0, v2, v1
    .line 258: throw v0
    .line 259: nop
    .line 260: filled-new-array {}, B
    .line 263: nop
    .line 264: monitor-exit v0
    .line 265: nop
    .line 266: const-string/jumbo v0, "string@1572864"
    .line 269: nop
    .line 270: const/high16 v0, 0x0
    .line 272: nop
    .line 273: move-wide v0, v0
    .line 274: iget-object v0, v0, Lai/onnxruntime/OrtTrainingSession;->evalInputNames:Ljava/util/Set;
    .line 276: return v0
    .line 277: nop
    .line 278: move-result-object v0
    .line 279: nop
    .line 280: move-object/16 v0, v6
    .line 283: nop
.end method

# virtual methods
.method public final a(Lf2/e;)V
    .registers 3

    .line 0: iget-object v2, v2, Lf2/e;->a:Ljava/lang/Object;
    .line 2: check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 4: iget-object v0, v1, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 6: invoke-virtual {v0, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V
    .line 9: return-void
.end method

# virtual methods
.method public final b(Ljava/lang/String;)Ljava/util/ArrayList;
    .registers 4

    .line 0: iget-object v0, v2, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 2: invoke-static {v0}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v1, v3}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 9: move-result-object v1
    .line 10: if-nez v1, :cond_24
    .line 12: new-instance v1, Ljava/util/ArrayList;
    .line 14: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 17: invoke-static {v0}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 20: move-result-object v0
    .line 21: invoke-virtual {v0, v3, v1}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V
    .line 24: return-object v1
.end method

# virtual methods
.method public final d(I)Z
    .registers 5

    .line 0: iget-object v0, v3, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 2: invoke-static {v0}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 5: move-result-object v0
    .line 6: const/4 v1, 0
    .line 7: if-nez v0, :cond_10
    .line 9: return v1
    .line 10: const-string v2, "androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY"
    .line 12: invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I
    .line 15: move-result v0
    .line 16: and-int/2addr v0, v4
    .line 17: if-ne v0, v4, :cond_20
    .line 19: const/4 v1, 1
    .line 20: return v1
.end method

# virtual methods
.method public final e()Ljava/lang/CharSequence;
    .registers 12

    .line 0: const-string v0, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY"
    .line 2: invoke-virtual {v11, v0}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 5: move-result-object v1
    .line 6: invoke-interface {v1}, Ljava/util/List;->isEmpty()Z
    .line 9: move-result v1
    .line 10: xor-int/lit8 v1, v1, 1
    .line 12: iget-object v2, v11, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 14: if-eqz v1, :cond_128
    .line 16: invoke-virtual {v11, v0}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 19: move-result-object v0
    .line 20: const-string v1, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY"
    .line 22: invoke-virtual {v11, v1}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 25: move-result-object v1
    .line 26: const-string v3, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY"
    .line 28: invoke-virtual {v11, v3}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 31: move-result-object v3
    .line 32: const-string v4, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY"
    .line 34: invoke-virtual {v11, v4}, Lf2/k;->b(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 37: move-result-object v4
    .line 38: new-instance v5, Landroid/text/SpannableString;
    .line 40: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;
    .line 43: move-result-object v6
    .line 44: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;
    .line 47: move-result-object v7
    .line 48: invoke-interface {v7}, Ljava/lang/CharSequence;->length()I
    .line 51: move-result v7
    .line 52: const/4 v8, 0
    .line 53: invoke-static {v6, v8, v7}, Landroid/text/TextUtils;->substring(Ljava/lang/CharSequence;II)Ljava/lang/String;
    .line 56: move-result-object v6
    .line 57: invoke-direct {v5, v6}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V
    .line 60: invoke-interface {v0}, Ljava/util/List;->size()I
    .line 63: move-result v6
    .line 64: if-ge v8, v6, :cond_127
    .line 66: new-instance v6, Lf2/a;
    .line 68: invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 71: move-result-object v7
    .line 72: check-cast v7, Ljava/lang/Integer;
    .line 74: invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I
    .line 77: move-result v7
    .line 78: invoke-static {v2}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 81: move-result-object v9
    .line 82: const-string v10, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY"
    .line 84: invoke-virtual {v9, v10}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I
    .line 87: move-result v9
    .line 88: invoke-direct {v6, v7, v11, v9}, Lf2/a;-><init>(ILf2/k;I)V
    .line 91: invoke-interface {v0, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 94: move-result-object v7
    .line 95: check-cast v7, Ljava/lang/Integer;
    .line 97: invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I
    .line 100: move-result v7
    .line 101: invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 104: move-result-object v9
    .line 105: check-cast v9, Ljava/lang/Integer;
    .line 107: invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I
    .line 110: move-result v9
    .line 111: invoke-interface {v3, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 114: move-result-object v10
    .line 115: check-cast v10, Ljava/lang/Integer;
    .line 117: invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I
    .line 120: move-result v10
    .line 121: invoke-virtual {v5, v6, v7, v9, v10}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V
    .line 124: add-int/lit8 v8, v8, 1
    .line 126: goto :goto_60
    .line 127: return-object v5
    .line 128: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;
    .line 131: move-result-object v0
    .line 132: return-object v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: const/4 v1, 0
    .line 5: if-nez v5, :cond_8
    .line 7: return v1
    .line 8: instance-of v2, v5, Lf2/k;
    .line 10: if-nez v2, :cond_13
    .line 12: return v1
    .line 13: check-cast v5, Lf2/k;
    .line 15: iget-object v2, v5, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 17: iget-object v3, v4, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 19: if-nez v3, :cond_24
    .line 21: if-eqz v2, :cond_31
    .line 23: return v1
    .line 24: invoke-virtual {v3, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->equals(Ljava/lang/Object;)Z
    .line 27: move-result v2
    .line 28: if-nez v2, :cond_31
    .line 30: return v1
    .line 31: iget v2, v4, Lf2/k;->c:I
    .line 33: iget v3, v5, Lf2/k;->c:I
    .line 35: if-eq v2, v3, :cond_38
    .line 37: return v1
    .line 38: iget v2, v4, Lf2/k;->b:I
    .line 40: iget v5, v5, Lf2/k;->b:I
    .line 42: if-eq v2, v5, :cond_45
    .line 44: return v1
    .line 45: return v0
.end method

# virtual methods
.method public final f(Ljava/lang/String;)V
    .registers 3

    .line 0: iget-object v0, v1, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 2: invoke-virtual {v0, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V
    .line 5: return-void
.end method

# virtual methods
.method public final hashCode()I
    .registers 2

    .line 0: iget-object v0, v1, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, 0
    .line 5: goto :goto_10
    .line 6: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->hashCode()I
    .line 9: move-result v0
    .line 10: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 10

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 5: invoke-super {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 8: move-result-object v1
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: new-instance v1, Landroid/graphics/Rect;
    .line 14: invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V
    .line 17: iget-object v2, v9, Lf2/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 19: invoke-virtual {v2, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInParent(Landroid/graphics/Rect;)V
    .line 22: new-instance v3, Ljava/lang/StringBuilder;
    .line 24: const-string v4, "; boundsInParent: "
    .line 26: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 29: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 32: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 35: move-result-object v3
    .line 36: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 39: invoke-virtual {v2, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V
    .line 42: new-instance v3, Ljava/lang/StringBuilder;
    .line 44: const-string v4, "; boundsInScreen: "
    .line 46: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 49: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 52: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 55: move-result-object v3
    .line 56: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 59: sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 61: const/16 v4, 34
    .line 63: if-lt v3, v4, :cond_69
    .line 65: invoke-static {v2, v1}, Lf2/i;->a(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Rect;)V
    .line 68: goto :goto_94
    .line 69: invoke-static {v2}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 72: move-result-object v5
    .line 73: const-string v6, "androidx.view.accessibility.AccessibilityNodeInfoCompat.BOUNDS_IN_WINDOW_KEY"
    .line 75: invoke-virtual {v5, v6}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    .line 78: move-result-object v5
    .line 79: check-cast v5, Landroid/graphics/Rect;
    .line 81: if-eqz v5, :cond_94
    .line 83: iget v6, v5, Landroid/graphics/Rect;->left:I
    .line 85: iget v7, v5, Landroid/graphics/Rect;->top:I
    .line 87: iget v8, v5, Landroid/graphics/Rect;->right:I
    .line 89: iget v5, v5, Landroid/graphics/Rect;->bottom:I
    .line 91: invoke-virtual {v1, v6, v7, v8, v5}, Landroid/graphics/Rect;->set(IIII)V
    .line 94: new-instance v5, Ljava/lang/StringBuilder;
    .line 96: const-string v6, "; boundsInWindow: "
    .line 98: invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 101: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 104: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 107: move-result-object v1
    .line 108: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 111: const-string v1, "; packageName: "
    .line 113: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 116: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;
    .line 119: move-result-object v1
    .line 120: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 123: const-string v1, "; className: "
    .line 125: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 128: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;
    .line 131: move-result-object v1
    .line 132: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 135: const-string v1, "; text: "
    .line 137: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 140: invoke-virtual {v9}, Lf2/k;->e()Ljava/lang/CharSequence;
    .line 143: move-result-object v1
    .line 144: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 147: const-string v1, "; error: "
    .line 149: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 152: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getError()Ljava/lang/CharSequence;
    .line 155: move-result-object v1
    .line 156: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 159: const-string v1, "; maxTextLength: "
    .line 161: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 164: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getMaxTextLength()I
    .line 167: move-result v1
    .line 168: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 171: const-string v1, "; stateDescription: "
    .line 173: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 176: const/16 v1, 30
    .line 178: if-lt v3, v1, :cond_185
    .line 180: invoke-static {v2}, Lf2/g;->b(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/CharSequence;
    .line 183: move-result-object v1
    .line 184: goto :goto_195
    .line 185: invoke-static {v2}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 188: move-result-object v1
    .line 189: const-string v5, "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"
    .line 191: invoke-virtual {v1, v5}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;
    .line 194: move-result-object v1
    .line 195: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 198: const-string v1, "; contentDescription: "
    .line 200: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 203: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;
    .line 206: move-result-object v1
    .line 207: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 210: const-string v1, "; tooltipText: "
    .line 212: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 215: const/16 v1, 28
    .line 217: if-lt v3, v1, :cond_224
    .line 219: invoke-static {v2}, Landroidx/compose/ui/platform/r2;->e(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/CharSequence;
    .line 222: move-result-object v1
    .line 223: goto :goto_234
    .line 224: invoke-static {v2}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 227: move-result-object v1
    .line 228: const-string v5, "androidx.view.accessibility.AccessibilityNodeInfoCompat.TOOLTIP_TEXT_KEY"
    .line 230: invoke-virtual {v1, v5}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;
    .line 233: move-result-object v1
    .line 234: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 237: const-string v1, "; viewIdResName: "
    .line 239: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 242: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;
    .line 245: move-result-object v1
    .line 246: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 249: const-string v1, "; uniqueId: "
    .line 251: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 254: const/16 v1, 33
    .line 256: if-lt v3, v1, :cond_263
    .line 258: invoke-static {v2}, Lf2/h;->g(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;
    .line 261: move-result-object v5
    .line 262: goto :goto_273
    .line 263: invoke-static {v2}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 266: move-result-object v5
    .line 267: const-string v6, "androidx.view.accessibility.AccessibilityNodeInfoCompat.UNIQUE_ID_KEY"
    .line 269: invoke-virtual {v5, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    .line 272: move-result-object v5
    .line 273: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 276: const-string v5, "; checkable: "
    .line 278: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 281: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isCheckable()Z
    .line 284: move-result v5
    .line 285: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 288: const-string v5, "; checked: "
    .line 290: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 293: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isChecked()Z
    .line 296: move-result v5
    .line 297: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 300: const-string v5, "; focusable: "
    .line 302: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 305: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocusable()Z
    .line 308: move-result v5
    .line 309: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 312: const-string v5, "; focused: "
    .line 314: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 317: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z
    .line 320: move-result v5
    .line 321: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 324: const-string v5, "; selected: "
    .line 326: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 329: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isSelected()Z
    .line 332: move-result v5
    .line 333: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 336: const-string v5, "; clickable: "
    .line 338: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 341: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z
    .line 344: move-result v5
    .line 345: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 348: const-string v5, "; longClickable: "
    .line 350: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 353: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isLongClickable()Z
    .line 356: move-result v5
    .line 357: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 360: const-string v5, "; contextClickable: "
    .line 362: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 365: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isContextClickable()Z
    .line 368: move-result v5
    .line 369: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 372: const-string v5, "; enabled: "
    .line 374: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 377: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isEnabled()Z
    .line 380: move-result v5
    .line 381: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 384: const-string v5, "; password: "
    .line 386: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 389: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isPassword()Z
    .line 392: move-result v5
    .line 393: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 396: new-instance v5, Ljava/lang/StringBuilder;
    .line 398: const-string v6, "; scrollable: "
    .line 400: invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 403: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isScrollable()Z
    .line 406: move-result v6
    .line 407: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 410: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 413: move-result-object v5
    .line 414: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 417: const-string v5, "; containerTitle: "
    .line 419: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 422: if-lt v3, v4, :cond_429
    .line 424: invoke-static {v2}, Lf2/i;->b(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/CharSequence;
    .line 427: move-result-object v5
    .line 428: goto :goto_439
    .line 429: invoke-static {v2}, Lf2/f;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .line 432: move-result-object v5
    .line 433: const-string v6, "androidx.view.accessibility.AccessibilityNodeInfoCompat.CONTAINER_TITLE_KEY"
    .line 435: invoke-virtual {v5, v6}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;
    .line 438: move-result-object v5
    .line 439: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
    .line 442: const-string v5, "; granularScrollingSupported: "
    .line 444: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 447: const/high16 v5, 0x400
    .line 449: invoke-virtual {v9, v5}, Lf2/k;->d(I)Z
    .line 452: move-result v5
    .line 453: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 456: const-string v5, "; importantForAccessibility: "
    .line 458: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 461: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isImportantForAccessibility()Z
    .line 464: move-result v5
    .line 465: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 468: const-string v5, "; visible: "
    .line 470: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 473: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z
    .line 476: move-result v5
    .line 477: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 480: const-string v5, "; isTextSelectable: "
    .line 482: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 485: if-lt v3, v1, :cond_492
    .line 487: invoke-static {v2}, Lf2/h;->h(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .line 490: move-result v1
    .line 491: goto :goto_498
    .line 492: const/high16 v1, 0x80
    .line 494: invoke-virtual {v9, v1}, Lf2/k;->d(I)Z
    .line 497: move-result v1
    .line 498: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 501: const-string v1, "; accessibilityDataSensitive: "
    .line 503: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 506: if-lt v3, v4, :cond_513
    .line 508: invoke-static {v2}, Lf2/i;->e(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .line 511: move-result v1
    .line 512: goto :goto_519
    .line 513: const/16 v1, 64
    .line 515: invoke-virtual {v9, v1}, Lf2/k;->d(I)Z
    .line 518: move-result v1
    .line 519: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 522: const-string v1, "; ["
    .line 524: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 527: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getActionList()Ljava/util/List;
    .line 530: move-result-object v1
    .line 531: const/4 v2, 0
    .line 532: if-eqz v1, :cond_562
    .line 534: new-instance v3, Ljava/util/ArrayList;
    .line 536: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    .line 539: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 542: move-result v4
    .line 543: move v5, v2
    .line 544: if-ge v5, v4, :cond_566
    .line 546: invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 549: move-result-object v6
    .line 550: new-instance v7, Lf2/e;
    .line 552: const/4 v8, 0
    .line 553: invoke-direct {v7, v6, v2, v8, v8}, Lf2/e;-><init>(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Class;)V
    .line 556: invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 559: add-int/lit8 v5, v5, 1
    .line 561: goto :goto_544
    .line 562: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    .line 565: move-result-object v3
    .line 566: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 569: move-result v1
    .line 570: if-ge v2, v1, :cond_638
    .line 572: invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 575: move-result-object v1
    .line 576: check-cast v1, Lf2/e;
    .line 578: iget-object v4, v1, Lf2/e;->a:Ljava/lang/Object;
    .line 580: check-cast v4, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 582: invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getId()I
    .line 585: move-result v4
    .line 586: invoke-static {v4}, Lf2/k;->c(I)Ljava/lang/String;
    .line 589: move-result-object v4
    .line 590: const-string v5, "ACTION_UNKNOWN"
    .line 592: invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 595: move-result v5
    .line 596: if-eqz v5, :cond_619
    .line 598: iget-object v1, v1, Lf2/e;->a:Ljava/lang/Object;
    .line 600: move-object v5, v1
    .line 601: check-cast v5, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 603: invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getLabel()Ljava/lang/CharSequence;
    .line 606: move-result-object v5
    .line 607: if-eqz v5, :cond_619
    .line 609: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 611: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getLabel()Ljava/lang/CharSequence;
    .line 614: move-result-object v1
    .line 615: invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;
    .line 618: move-result-object v4
    .line 619: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 622: invoke-interface {v3}, Ljava/util/List;->size()I
    .line 625: move-result v1
    .line 626: add-int/lit8 v1, v1, -1
    .line 628: if-eq v2, v1, :cond_635
    .line 630: const-string v1, ", "
    .line 632: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 635: add-int/lit8 v2, v2, 1
    .line 637: goto :goto_566
    .line 638: const-string v1, "]"
    .line 640: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 643: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 646: move-result-object v0
    .line 647: return-object v0
.end method

.class public abstract synthetic Lf2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static synthetic a()Landroid/graphics/text/LineBreakConfig$Builder;
    .registers 1

    .line 0: new-instance v0, Landroid/graphics/text/LineBreakConfig$Builder;
    .line 2: invoke-direct {v0}, Landroid/graphics/text/LineBreakConfig$Builder;-><init>()V
    .line 5: return-object v0
.end method

# direct methods
.method public static bridge synthetic b(Landroid/graphics/text/LineBreakConfig$Builder;I)Landroid/graphics/text/LineBreakConfig$Builder;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/text/LineBreakConfig$Builder;->setLineBreakStyle(I)Landroid/graphics/text/LineBreakConfig$Builder;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic c(Landroid/graphics/text/LineBreakConfig$Builder;)Landroid/graphics/text/LineBreakConfig;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/graphics/text/LineBreakConfig$Builder;->build()Landroid/graphics/text/LineBreakConfig;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static bridge synthetic d(Ljava/lang/CharSequence;Landroid/text/TextPaint;Landroid/text/TextDirectionHeuristic;)Landroid/text/BoringLayout$Metrics;
    .registers 5

    .line 0: const/4 v0, 1
    .line 1: const/4 v1, 0
    .line 2: invoke-static {v2, v3, v4, v0, v1}, Landroid/text/BoringLayout;->isBoring(Ljava/lang/CharSequence;Landroid/text/TextPaint;Landroid/text/TextDirectionHeuristic;ZLandroid/text/BoringLayout$Metrics;)Landroid/text/BoringLayout$Metrics;
    .line 5: move-result-object v2
    .line 6: return-object v2
.end method

# direct methods
.method public static synthetic e(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFLandroid/text/BoringLayout$Metrics;ZLandroid/text/TextUtils$TruncateAt;IZ)Landroid/text/BoringLayout;
    .registers 24

    .line 0: new-instance v12, Landroid/text/BoringLayout;
    .line 2: move-object v0, v12
    .line 3: move-object v1, v13
    .line 4: move-object v2, v14
    .line 5: move v3, v15
    .line 6: move-object/from16 v4, v16
    .line 8: move/from16 v5, v17
    .line 10: move/from16 v6, v18
    .line 12: move-object/from16 v7, v19
    .line 14: move/from16 v8, v20
    .line 16: move-object/from16 v9, v21
    .line 18: move/from16 v10, v22
    .line 20: move/from16 v11, v23
    .line 22: invoke-direct/range {v0 .. v11}, Landroid/text/BoringLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFLandroid/text/BoringLayout$Metrics;ZLandroid/text/TextUtils$TruncateAt;IZ)V
    .line 25: return-object v12
.end method

# direct methods
.method public static bridge synthetic f()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .registers 1

    .line 0: sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SHOW_TEXT_SUGGESTIONS:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;
    .line 2: return-object v0
.end method

# direct methods
.method public static bridge synthetic g(Landroid/text/StaticLayout$Builder;Landroid/graphics/text/LineBreakConfig;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setLineBreakConfig(Landroid/graphics/text/LineBreakConfig;)Landroid/text/StaticLayout$Builder;
    .line 3: return-void
.end method

# direct methods
.method public static bridge synthetic h(Landroid/text/BoringLayout;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/text/BoringLayout;->isFallbackLineSpacingEnabled()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic i(Landroid/text/StaticLayout;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/text/StaticLayout;->isFallbackLineSpacingEnabled()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static bridge synthetic j(Landroid/graphics/text/LineBreakConfig$Builder;I)Landroid/graphics/text/LineBreakConfig$Builder;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/graphics/text/LineBreakConfig$Builder;->setLineBreakWordStyle(I)Landroid/graphics/text/LineBreakConfig$Builder;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

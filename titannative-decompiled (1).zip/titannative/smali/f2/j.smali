.class public final Lf2/j;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/Object;

# direct methods
.method public constructor <init>(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

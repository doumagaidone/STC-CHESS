.class public abstract Lf2/i;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Rect;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInWindow(Landroid/graphics/Rect;)V
    .line 3: return-void
.end method

# direct methods
.method public static b(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/CharSequence;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContainerTitle()Ljava/lang/CharSequence;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static c(Landroid/view/accessibility/AccessibilityNodeInfo;)J
    .registers 3

    .line 0: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getMinDurationBetweenContentChanges()Ljava/time/Duration;
    .line 3: move-result-object v2
    .line 4: invoke-virtual {v2}, Ljava/time/Duration;->toMillis()J
    .line 7: move-result-wide v0
    .line 8: return-wide v0
.end method

# direct methods
.method public static d(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->hasRequestInitialAccessibilityFocus()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static e(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->isAccessibilityDataSensitive()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static f(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityDataSensitive(Z)V
    .line 3: return-void
.end method

# direct methods
.method public static g(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Rect;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInWindow(Landroid/graphics/Rect;)V
    .line 3: return-void
.end method

# direct methods
.method public static h(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContainerTitle(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

# direct methods
.method public static i(Landroid/view/accessibility/AccessibilityNodeInfo;J)V
    .registers 3

    .line 0: invoke-static {v1, v2}, Ljava/time/Duration;->ofMillis(J)Ljava/time/Duration;
    .line 3: move-result-object v1
    .line 4: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMinDurationBetweenContentChanges(Ljava/time/Duration;)V
    .line 7: return-void
.end method

# direct methods
.method public static j(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/view/View;Z)V
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setQueryFromAppProcessEnabled(Landroid/view/View;Z)V
    .line 3: return-void
.end method

# direct methods
.method public static k(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setRequestInitialAccessibilityFocus(Z)V
    .line 3: return-void
.end method

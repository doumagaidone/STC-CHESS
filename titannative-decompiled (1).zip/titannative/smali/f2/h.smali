.class public abstract Lf2/h;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(ZIIIIZLjava/lang/String;Ljava/lang/String;)Lf2/j;
    .registers 10

    .line 0: new-instance v0, Lf2/j;
    .line 2: new-instance v1, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 4: invoke-direct {v1}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;-><init>()V
    .line 7: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setHeading(Z)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 10: move-result-object v2
    .line 11: invoke-virtual {v2, v3}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setColumnIndex(I)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 14: move-result-object v2
    .line 15: invoke-virtual {v2, v4}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setRowIndex(I)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 18: move-result-object v2
    .line 19: invoke-virtual {v2, v5}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setColumnSpan(I)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 22: move-result-object v2
    .line 23: invoke-virtual {v2, v6}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setRowSpan(I)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 26: move-result-object v2
    .line 27: invoke-virtual {v2, v7}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setSelected(Z)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 30: move-result-object v2
    .line 31: invoke-virtual {v2, v8}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setRowTitle(Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 34: move-result-object v2
    .line 35: invoke-virtual {v2, v9}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->setColumnTitle(Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;
    .line 38: move-result-object v2
    .line 39: invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo$Builder;->build()Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;
    .line 42: move-result-object v2
    .line 43: invoke-direct {v0, v2}, Lf2/j;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V
    .line 46: return-object v0
.end method

# direct methods
.method public static b(Landroid/view/accessibility/AccessibilityNodeInfo;II)Lf2/k;
    .registers 3

    .line 0: invoke-virtual {v0, v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(II)Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_13
    .line 6: new-instance v1, Lf2/k;
    .line 8: const/4 v2, 0
    .line 9: invoke-direct {v1, v0, v2}, Lf2/k;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;I)V
    .line 12: goto :goto_14
    .line 13: const/4 v1, 0
    .line 14: return-object v1
.end method

# direct methods
.method public static c(Ljava/lang/Object;)Ljava/lang/String;
    .registers 1

    .line 0: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;
    .line 2: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->getColumnTitle()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# direct methods
.method public static d(Ljava/lang/Object;)Ljava/lang/String;
    .registers 1

    .line 0: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;
    .line 2: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->getRowTitle()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# direct methods
.method public static e(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo$ExtraRenderingInfo;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtraRenderingInfo()Landroid/view/accessibility/AccessibilityNodeInfo$ExtraRenderingInfo;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static f(Landroid/view/accessibility/AccessibilityNodeInfo;I)Lf2/k;
    .registers 3

    .line 0: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getParent(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .line 3: move-result-object v1
    .line 4: if-eqz v1, :cond_13
    .line 6: new-instance v2, Lf2/k;
    .line 8: const/4 v0, 0
    .line 9: invoke-direct {v2, v1, v0}, Lf2/k;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;I)V
    .line 12: goto :goto_14
    .line 13: const/4 v2, 0
    .line 14: return-object v2
.end method

# direct methods
.method public static g(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getUniqueId()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static h(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->isTextSelectable()Z
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method public static i(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTextSelectable(Z)V
    .line 3: return-void
.end method

# direct methods
.method public static j(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setUniqueId(Ljava/lang/String;)V
    .line 3: return-void
.end method

.class public abstract Lf2/f;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(IIIIZ)Lf2/j;
    .registers 6

    .line 0: new-instance v0, Lf2/j;
    .line 2: invoke-static {v1, v2, v3, v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->obtain(IIIIZ)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;
    .line 5: move-result-object v1
    .line 6: invoke-direct {v0, v1}, Lf2/j;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V
    .line 9: return-object v0
.end method

# direct methods
.method public static b(IFFF)Ljava/lang/Object;
    .registers 4

    .line 0: invoke-static {v0, v1, v2, v3}, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;->obtain(IFFF)Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

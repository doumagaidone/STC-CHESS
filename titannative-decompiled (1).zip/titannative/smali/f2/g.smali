.class public abstract Lf2/g;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(IFFF)Ljava/lang/Object;
    .registers 5

    .line 0: new-instance v0, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;
    .line 2: invoke-direct {v0, v1, v2, v3, v4}, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;-><init>(IFFF)V
    .line 5: return-object v0
.end method

# direct methods
.method public static b(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/CharSequence;
    .registers 1

    .line 0: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getStateDescription()Ljava/lang/CharSequence;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method public static c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setStateDescription(Ljava/lang/CharSequence;)V
    .line 3: return-void
.end method

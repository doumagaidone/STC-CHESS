.class public final Le3/s;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Serializable;

.field public i:Ljava/lang/Object;

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Le3/s;->i:Ljava/lang/Object;
    .line 2: invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

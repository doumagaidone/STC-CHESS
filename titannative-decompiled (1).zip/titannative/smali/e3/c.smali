.class public abstract interface Le3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a()Ljava/lang/Class;
.end method

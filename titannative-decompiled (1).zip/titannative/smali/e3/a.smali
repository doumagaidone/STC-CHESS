.class public final Le3/a;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Serializable;

.field public static final i:Le3/a;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Le3/a;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: sput-object v0, Le3/a;->i:Le3/a;
    .line 7: return-void
.end method

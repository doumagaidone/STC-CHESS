.class public abstract Le3/t;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Le3/u;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: const-string v1, "kotlin.reflect.jvm.internal.ReflectionFactoryImpl"
    .line 3: invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    .line 6: move-result-object v1
    .line 7: invoke-virtual {v1}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;
    .line 10: move-result-object v1
    .line 11: check-cast v1, Le3/u;
    .line 13: move-object v0, v1
    .line 14: if-eqz v0, :cond_17
    .line 16: goto :goto_22
    .line 17: new-instance v0, Le3/u;
    .line 19: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 22: sput-object v0, Le3/t;->a:Le3/u;
    .line 24: return-void
.end method

# direct methods
.method public static a(Ljava/lang/Class;)Le3/d;
    .registers 2

    .line 0: sget-object v0, Le3/t;->a:Le3/u;
    .line 2: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: new-instance v0, Le3/d;
    .line 7: invoke-direct {v0, v1}, Le3/d;-><init>(Ljava/lang/Class;)V
    .line 10: return-object v0
.end method

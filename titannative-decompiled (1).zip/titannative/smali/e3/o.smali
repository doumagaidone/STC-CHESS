.class public final Le3/o;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Serializable;

.field public i:Z

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget-boolean v0, v1, Le3/o;->i:Z
    .line 2: invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

.class public final Le3/r;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Serializable;

.field public i:J

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: iget-wide v0, v2, Le3/r;->i:J
    .line 2: invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

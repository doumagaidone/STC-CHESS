.class public final Le3/u;
.super Ljava/lang/Object;
.source "SourceFile"

# direct methods
.method public static a(Le3/e;)Ljava/lang/String;
    .registers 2

    .line 0: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: move-result-object v1
    .line 4: invoke-virtual {v1}, Ljava/lang/Class;->getGenericInterfaces()[Ljava/lang/reflect/Type;
    .line 7: move-result-object v1
    .line 8: const/4 v0, 0
    .line 9: aget-object v1, v1, v0
    .line 11: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 14: move-result-object v1
    .line 15: const-string v0, "kotlin.jvm.functions."
    .line 17: invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    .line 20: move-result v0
    .line 21: if-eqz v0, :cond_29
    .line 23: const/16 v0, 21
    .line 25: invoke-virtual {v1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 28: move-result-object v1
    .line 29: return-object v1
.end method

.class public final Le3/p;
.super Ljava/lang/Object;
.source "SourceFile"
.implements Ljava/io/Serializable;

.field public i:F

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 0: iget v0, v1, Le3/p;->i:F
    .line 2: invoke-static {v0}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

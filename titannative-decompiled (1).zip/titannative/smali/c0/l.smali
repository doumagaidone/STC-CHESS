.class public final Lc0/l;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:Ld3/e;
.field public final synthetic b:Ld3/c;

# direct methods
.method public constructor <init>(Ld3/e;Ld3/c;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lc0/l;->a:Ld3/e;
    .line 5: iput-object v2, v0, Lc0/l;->b:Ld3/c;
    .line 7: return-void
.end method

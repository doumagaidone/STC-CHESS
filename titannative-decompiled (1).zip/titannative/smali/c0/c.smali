.class public final Lc0/c;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:Lc0/e;

# direct methods
.method public constructor <init>(Lc0/e;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lc0/c;->a:Lc0/e;
    .line 5: return-void
.end method

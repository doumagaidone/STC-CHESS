.class public final Lc0/f;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:Lc0/g;
.field public final synthetic b:Ljava/lang/String;
.field public final synthetic c:Ld3/a;

# direct methods
.method public constructor <init>(Lc0/g;Ljava/lang/String;Lc0/d;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Lc0/f;->a:Lc0/g;
    .line 5: iput-object v2, v0, Lc0/f;->b:Ljava/lang/String;
    .line 7: iput-object v3, v0, Lc0/f;->c:Ld3/a;
    .line 9: return-void
.end method

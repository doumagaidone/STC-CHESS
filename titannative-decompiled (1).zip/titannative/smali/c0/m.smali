.class public abstract Lc0/m;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Lc0/l;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: sget-object v0, Lc0/j;->j:Lc0/j;
    .line 2: sget-object v1, Lc0/k;->j:Lc0/k;
    .line 4: invoke-static {v0, v1}, Lc0/m;->a(Ld3/e;Ld3/c;)Lc0/l;
    .line 7: move-result-object v0
    .line 8: sput-object v0, Lc0/m;->a:Lc0/l;
    .line 10: return-void
.end method

# direct methods
.method public static final a(Ld3/e;Ld3/c;)Lc0/l;
    .registers 3

    .line 0: new-instance v0, Lc0/l;
    .line 2: invoke-direct {v0, v1, v2}, Lc0/l;-><init>(Ld3/e;Ld3/c;)V
    .line 5: return-object v0
.end method

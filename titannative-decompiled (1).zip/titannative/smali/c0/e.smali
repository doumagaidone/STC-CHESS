.class public abstract interface Lc0/e;
.super Ljava/lang/Object;
.source "SourceFile"

# virtual methods
.method public abstract a(Ljava/lang/String;)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract b(Ljava/lang/String;Lc0/d;)Lc0/f;
.end method

# virtual methods
.method public abstract c(Ljava/lang/Object;)Z
.end method

# virtual methods
.method public abstract d()Ljava/util/Map;
.end method

.class public final Lb4/a;
.super Ljava/net/ProxySelector;
.source "SourceFile"

.field public static final a:Lb4/a;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Lb4/a;
    .line 2: invoke-direct {v0}, Ljava/net/ProxySelector;-><init>()V
    .line 5: sput-object v0, Lb4/a;->a:Lb4/a;
    .line 7: return-void
.end method

# virtual methods
.method public final connectFailed(Ljava/net/URI;Ljava/net/SocketAddress;Ljava/io/IOException;)V
    .registers 4

    .line 0: return-void
.end method

# virtual methods
.method public final select(Ljava/net/URI;)Ljava/util/List;
    .registers 3

    .line 0: if-eqz v2, :cond_9
    .line 2: sget-object v2, Ljava/net/Proxy;->NO_PROXY:Ljava/net/Proxy;
    .line 4: invoke-static {v2}, Ld2/b;->H0(Ljava/lang/Object;)Ljava/util/List;
    .line 7: move-result-object v2
    .line 8: return-object v2
    .line 9: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 11: const-string v0, "uri must not be null"
    .line 13: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 16: move-result-object v0
    .line 17: invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 20: throw v2
.end method

.class public final La1/a;
.super Landroid/view/ActionMode$Callback2;
.source "SourceFile"

.field public final a:La1/b;

# direct methods
.method public constructor <init>(La1/b;)V
    .registers 3

    .line 0: const-string v0, "callback"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Landroid/view/ActionMode$Callback2;-><init>()V
    .line 8: iput-object v2, v1, La1/a;->a:La1/b;
    .line 10: return-void
.end method

# virtual methods
.method public final onActionItemClicked(Landroid/view/ActionMode;Landroid/view/MenuItem;)Z
    .registers 4

    .line 0: iget-object v0, v1, La1/a;->a:La1/b;
    .line 2: invoke-virtual {v0, v2, v3}, La1/b;->d(Landroid/view/ActionMode;Landroid/view/MenuItem;)Z
    .line 5: move-result v2
    .line 6: return v2
.end method

# virtual methods
.method public final onCreateActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z
    .registers 4

    .line 0: iget-object v0, v1, La1/a;->a:La1/b;
    .line 2: invoke-virtual {v0, v2, v3}, La1/b;->e(Landroid/view/ActionMode;Landroid/view/Menu;)V
    .line 5: const/4 v2, 1
    .line 6: return v2
.end method

# virtual methods
.method public final onDestroyActionMode(Landroid/view/ActionMode;)V
    .registers 2

    .line 0: iget-object v1, v0, La1/a;->a:La1/b;
    .line 2: iget-object v1, v1, La1/b;->b:Ljava/lang/Object;
    .line 4: check-cast v1, Ld3/a;
    .line 6: if-eqz v1, :cond_11
    .line 8: invoke-interface {v1}, Ld3/a;->s()Ljava/lang/Object;
    .line 11: return-void
.end method

# virtual methods
.method public final onGetContentRect(Landroid/view/ActionMode;Landroid/view/View;Landroid/graphics/Rect;)V
    .registers 6

    .line 0: iget-object v3, v2, La1/a;->a:La1/b;
    .line 2: iget-object v3, v3, La1/b;->g:Ljava/lang/Object;
    .line 4: check-cast v3, Lj0/d;
    .line 6: if-eqz v5, :cond_23
    .line 8: iget v4, v3, Lj0/d;->a:F
    .line 10: float-to-int v4, v4
    .line 11: iget v0, v3, Lj0/d;->b:F
    .line 13: float-to-int v0, v0
    .line 14: iget v1, v3, Lj0/d;->c:F
    .line 16: float-to-int v1, v1
    .line 17: iget v3, v3, Lj0/d;->d:F
    .line 19: float-to-int v3, v3
    .line 20: invoke-virtual {v5, v4, v0, v1, v3}, Landroid/graphics/Rect;->set(IIII)V
    .line 23: return-void
.end method

# virtual methods
.method public final onPrepareActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z
    .registers 4

    .line 0: iget-object v0, v1, La1/a;->a:La1/b;
    .line 2: invoke-virtual {v0, v2, v3}, La1/b;->f(Landroid/view/ActionMode;Landroid/view/Menu;)Z
    .line 5: move-result v2
    .line 6: return v2
.end method

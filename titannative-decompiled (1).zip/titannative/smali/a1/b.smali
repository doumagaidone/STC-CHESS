.class public final La1/b;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final synthetic a:I
.field public final b:Ljava/lang/Object;
.field public c:Ljava/lang/Object;
.field public d:Ljava/lang/Object;
.field public e:Ljava/lang/Object;
.field public f:Ljava/lang/Object;
.field public g:Ljava/lang/Object;

# direct methods
.method public constructor <init>(Ld3/a;Lj0/d;Ld3/a;Ld3/a;Ld3/a;Ld3/a;)V
    .registers 8

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 0
    .line 4: iput v0, v1, La1/b;->a:I
    .line 6: const-string v0, "rect"
    .line 8: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: iput-object v2, v1, La1/b;->b:Ljava/lang/Object;
    .line 13: iput-object v3, v1, La1/b;->g:Ljava/lang/Object;
    .line 15: iput-object v4, v1, La1/b;->c:Ljava/lang/Object;
    .line 17: iput-object v5, v1, La1/b;->d:Ljava/lang/Object;
    .line 19: iput-object v6, v1, La1/b;->e:Ljava/lang/Object;
    .line 21: iput-object v7, v1, La1/b;->f:Ljava/lang/Object;
    .line 23: return-void
.end method

# direct methods
.method public synthetic constructor <init>(Lh/i0;)V
    .registers 10

    .line 0: const/4 v0, 0
    .line 1: iput v0, v8, La1/b;->a:I
    .line 3: sget-object v3, Lj0/d;->e:Lj0/d;
    .line 5: const/4 v4, 0
    .line 6: const/4 v5, 0
    .line 7: const/4 v6, 0
    .line 8: const/4 v7, 0
    .line 9: move-object v1, v8
    .line 10: move-object v2, v9
    .line 11: invoke-direct/range {v1 .. v7}, La1/b;-><init>(Ld3/a;Lj0/d;Ld3/a;Ld3/a;Ld3/a;Ld3/a;)V
    .line 14: return-void
.end method

# direct methods
.method public constructor <init>(Lr3/s;Ljava/lang/String;Lr3/q;Ld2/c;Ljava/util/Map;)V
    .registers 7

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: const/4 v0, 1
    .line 4: iput v0, v1, La1/b;->a:I
    .line 6: const-string v0, "method"
    .line 8: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 11: iput-object v2, v1, La1/b;->b:Ljava/lang/Object;
    .line 13: iput-object v3, v1, La1/b;->c:Ljava/lang/Object;
    .line 15: iput-object v4, v1, La1/b;->d:Ljava/lang/Object;
    .line 17: iput-object v5, v1, La1/b;->e:Ljava/lang/Object;
    .line 19: iput-object v6, v1, La1/b;->f:Ljava/lang/Object;
    .line 21: return-void
.end method

# direct methods
.method public static a(Landroid/view/Menu;I)V
    .registers 6

    .line 0: const-string v0, "menu"
    .line 2: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "item"
    .line 7: invoke-static {v5, v0}, Lai/onnxruntime/b;->q(ILjava/lang/String;)V
    .line 10: const/4 v0, 0
    .line 11: if-eqz v5, :cond_62
    .line 13: add-int/lit8 v1, v5, -1
    .line 15: const/4 v2, 1
    .line 16: if-eqz v1, :cond_44
    .line 18: if-eq v1, v2, :cond_40
    .line 20: const/4 v3, 2
    .line 21: if-eq v1, v3, :cond_36
    .line 23: const/4 v3, 3
    .line 24: if-ne v1, v3, :cond_30
    .line 26: const v3, 0x104000d
    .line 29: goto :goto_47
    .line 30: new-instance v4, Lkotlinx/coroutines/internal/z;
    .line 32: invoke-direct {v4}, Ljava/lang/RuntimeException;-><init>()V
    .line 35: throw v4
    .line 36: const v3, 0x1040003
    .line 39: goto :goto_47
    .line 40: const v3, 0x104000b
    .line 43: goto :goto_47
    .line 44: const v3, 0x1040001
    .line 47: if-eqz v5, :cond_61
    .line 49: if-eqz v5, :cond_60
    .line 51: const/4 v5, 0
    .line 52: invoke-interface {v4, v5, v1, v1, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;
    .line 55: move-result-object v4
    .line 56: invoke-interface {v4, v2}, Landroid/view/MenuItem;->setShowAsAction(I)V
    .line 59: return-void
    .line 60: throw v0
    .line 61: throw v0
    .line 62: throw v0
.end method

# direct methods
.method public static b(Landroid/view/Menu;ILd3/a;)V
    .registers 5

    .line 0: const/4 v0, 0
    .line 1: if-eqz v4, :cond_18
    .line 3: if-eqz v3, :cond_17
    .line 5: add-int/lit8 v1, v3, -1
    .line 7: invoke-interface {v2, v1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;
    .line 10: move-result-object v1
    .line 11: if-nez v1, :cond_18
    .line 13: invoke-static {v2, v3}, La1/b;->a(Landroid/view/Menu;I)V
    .line 16: goto :goto_38
    .line 17: throw v0
    .line 18: if-nez v4, :cond_38
    .line 20: if-eqz v3, :cond_37
    .line 22: add-int/lit8 v4, v3, -1
    .line 24: invoke-interface {v2, v4}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;
    .line 27: move-result-object v1
    .line 28: if-eqz v1, :cond_38
    .line 30: if-eqz v3, :cond_36
    .line 32: invoke-interface {v2, v4}, Landroid/view/Menu;->removeItem(I)V
    .line 35: goto :goto_38
    .line 36: throw v0
    .line 37: throw v0
    .line 38: return-void
.end method

# virtual methods
.method public final c()Lr3/x;
    .registers 4

    .line 0: new-instance v0, Lr3/x;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: new-instance v1, Ljava/util/LinkedHashMap;
    .line 7: invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V
    .line 10: iput-object v1, v0, Lr3/x;->d:Ljava/util/LinkedHashMap;
    .line 12: iget-object v1, v3, La1/b;->b:Ljava/lang/Object;
    .line 14: check-cast v1, Lr3/s;
    .line 16: iput-object v1, v0, Lr3/x;->a:Lr3/s;
    .line 18: iget-object v1, v3, La1/b;->c:Ljava/lang/Object;
    .line 20: check-cast v1, Ljava/lang/String;
    .line 22: iput-object v1, v0, Lr3/x;->b:Ljava/lang/String;
    .line 24: iget-object v1, v3, La1/b;->f:Ljava/lang/Object;
    .line 26: check-cast v1, Ljava/util/Map;
    .line 28: invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z
    .line 31: move-result v1
    .line 32: if-eqz v1, :cond_40
    .line 34: new-instance v1, Ljava/util/LinkedHashMap;
    .line 36: invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V
    .line 39: goto :goto_55
    .line 40: iget-object v1, v3, La1/b;->f:Ljava/lang/Object;
    .line 42: check-cast v1, Ljava/util/Map;
    .line 44: const-string v2, "<this>"
    .line 46: invoke-static {v1, v2}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 49: new-instance v2, Ljava/util/LinkedHashMap;
    .line 51: invoke-direct {v2, v1}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V
    .line 54: move-object v1, v2
    .line 55: iput-object v1, v0, Lr3/x;->d:Ljava/util/LinkedHashMap;
    .line 57: iget-object v1, v3, La1/b;->d:Ljava/lang/Object;
    .line 59: check-cast v1, Lr3/q;
    .line 61: invoke-virtual {v1}, Lr3/q;->e()Lr3/p;
    .line 64: move-result-object v1
    .line 65: iput-object v1, v0, Lr3/x;->c:Lr3/p;
    .line 67: return-object v0
.end method

# virtual methods
.method public final d(Landroid/view/ActionMode;Landroid/view/MenuItem;)Z
    .registers 5

    .line 0: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 3: invoke-interface {v4}, Landroid/view/MenuItem;->getItemId()I
    .line 6: move-result v4
    .line 7: const/4 v0, 1
    .line 8: if-nez v4, :cond_20
    .line 10: iget-object v4, v2, La1/b;->c:Ljava/lang/Object;
    .line 12: check-cast v4, Ld3/a;
    .line 14: if-eqz v4, :cond_57
    .line 16: invoke-interface {v4}, Ld3/a;->s()Ljava/lang/Object;
    .line 19: goto :goto_57
    .line 20: if-ne v4, v0, :cond_32
    .line 22: iget-object v4, v2, La1/b;->d:Ljava/lang/Object;
    .line 24: check-cast v4, Ld3/a;
    .line 26: if-eqz v4, :cond_57
    .line 28: invoke-interface {v4}, Ld3/a;->s()Ljava/lang/Object;
    .line 31: goto :goto_57
    .line 32: const/4 v1, 2
    .line 33: if-ne v4, v1, :cond_45
    .line 35: iget-object v4, v2, La1/b;->e:Ljava/lang/Object;
    .line 37: check-cast v4, Ld3/a;
    .line 39: if-eqz v4, :cond_57
    .line 41: invoke-interface {v4}, Ld3/a;->s()Ljava/lang/Object;
    .line 44: goto :goto_57
    .line 45: const/4 v1, 3
    .line 46: if-ne v4, v1, :cond_63
    .line 48: iget-object v4, v2, La1/b;->f:Ljava/lang/Object;
    .line 50: check-cast v4, Ld3/a;
    .line 52: if-eqz v4, :cond_57
    .line 54: invoke-interface {v4}, Ld3/a;->s()Ljava/lang/Object;
    .line 57: if-eqz v3, :cond_62
    .line 59: invoke-virtual {v3}, Landroid/view/ActionMode;->finish()V
    .line 62: return v0
    .line 63: const/4 v3, 0
    .line 64: return v3
.end method

# virtual methods
.method public final e(Landroid/view/ActionMode;Landroid/view/Menu;)V
    .registers 4

    .line 0: const-string v0, "Required value was null."
    .line 2: if-eqz v3, :cond_57
    .line 4: if-eqz v2, :cond_47
    .line 6: iget-object v2, v1, La1/b;->c:Ljava/lang/Object;
    .line 8: check-cast v2, Ld3/a;
    .line 10: if-eqz v2, :cond_16
    .line 12: const/4 v2, 1
    .line 13: invoke-static {v3, v2}, La1/b;->a(Landroid/view/Menu;I)V
    .line 16: iget-object v2, v1, La1/b;->d:Ljava/lang/Object;
    .line 18: check-cast v2, Ld3/a;
    .line 20: if-eqz v2, :cond_26
    .line 22: const/4 v2, 2
    .line 23: invoke-static {v3, v2}, La1/b;->a(Landroid/view/Menu;I)V
    .line 26: iget-object v2, v1, La1/b;->e:Ljava/lang/Object;
    .line 28: check-cast v2, Ld3/a;
    .line 30: if-eqz v2, :cond_36
    .line 32: const/4 v2, 3
    .line 33: invoke-static {v3, v2}, La1/b;->a(Landroid/view/Menu;I)V
    .line 36: iget-object v2, v1, La1/b;->f:Ljava/lang/Object;
    .line 38: check-cast v2, Ld3/a;
    .line 40: if-eqz v2, :cond_46
    .line 42: const/4 v2, 4
    .line 43: invoke-static {v3, v2}, La1/b;->a(Landroid/view/Menu;I)V
    .line 46: return-void
    .line 47: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 49: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 52: move-result-object v3
    .line 53: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 56: throw v2
    .line 57: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 59: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 62: move-result-object v3
    .line 63: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 66: throw v2
.end method

# virtual methods
.method public final f(Landroid/view/ActionMode;Landroid/view/Menu;)Z
    .registers 5

    .line 0: if-eqz v3, :cond_38
    .line 2: if-nez v4, :cond_5
    .line 4: goto :goto_38
    .line 5: iget-object v3, v2, La1/b;->c:Ljava/lang/Object;
    .line 7: check-cast v3, Ld3/a;
    .line 9: const/4 v0, 1
    .line 10: invoke-static {v4, v0, v3}, La1/b;->b(Landroid/view/Menu;ILd3/a;)V
    .line 13: iget-object v3, v2, La1/b;->d:Ljava/lang/Object;
    .line 15: check-cast v3, Ld3/a;
    .line 17: const/4 v1, 2
    .line 18: invoke-static {v4, v1, v3}, La1/b;->b(Landroid/view/Menu;ILd3/a;)V
    .line 21: iget-object v3, v2, La1/b;->e:Ljava/lang/Object;
    .line 23: check-cast v3, Ld3/a;
    .line 25: const/4 v1, 3
    .line 26: invoke-static {v4, v1, v3}, La1/b;->b(Landroid/view/Menu;ILd3/a;)V
    .line 29: iget-object v3, v2, La1/b;->f:Ljava/lang/Object;
    .line 31: check-cast v3, Ld3/a;
    .line 33: const/4 v1, 4
    .line 34: invoke-static {v4, v1, v3}, La1/b;->b(Landroid/view/Menu;ILd3/a;)V
    .line 37: return v0
    .line 38: const/4 v3, 0
    .line 39: return v3
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 7

    .line 0: iget v0, v6, La1/b;->a:I
    .line 2: packed-switch v0, :data_156
    .line 5: invoke-super {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 8: move-result-object v0
    .line 9: return-object v0
    .line 10: new-instance v0, Ljava/lang/StringBuilder;
    .line 12: const-string v1, "Request{method="
    .line 14: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 17: iget-object v1, v6, La1/b;->c:Ljava/lang/Object;
    .line 19: check-cast v1, Ljava/lang/String;
    .line 21: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 24: const-string v1, ", url="
    .line 26: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 29: iget-object v1, v6, La1/b;->b:Ljava/lang/Object;
    .line 31: check-cast v1, Lr3/s;
    .line 33: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 36: iget-object v1, v6, La1/b;->d:Ljava/lang/Object;
    .line 38: check-cast v1, Lr3/q;
    .line 40: invoke-virtual {v1}, Lr3/q;->size()I
    .line 43: move-result v1
    .line 44: if-eqz v1, :cond_117
    .line 46: const-string v1, ", headers=["
    .line 48: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 51: iget-object v1, v6, La1/b;->d:Ljava/lang/Object;
    .line 53: check-cast v1, Lr3/q;
    .line 55: invoke-virtual {v1}, Lr3/q;->iterator()Ljava/util/Iterator;
    .line 58: move-result-object v1
    .line 59: const/4 v2, 0
    .line 60: move-object v3, v1
    .line 61: check-cast v3, Lv/c;
    .line 63: invoke-virtual {v3}, Lv/c;->hasNext()Z
    .line 66: move-result v4
    .line 67: if-eqz v4, :cond_112
    .line 69: invoke-virtual {v3}, Lv/c;->next()Ljava/lang/Object;
    .line 72: move-result-object v3
    .line 73: add-int/lit8 v4, v2, 1
    .line 75: if-ltz v2, :cond_107
    .line 77: check-cast v3, Ls2/e;
    .line 79: iget-object v5, v3, Ls2/e;->i:Ljava/lang/Object;
    .line 81: check-cast v5, Ljava/lang/String;
    .line 83: iget-object v3, v3, Ls2/e;->j:Ljava/lang/Object;
    .line 85: check-cast v3, Ljava/lang/String;
    .line 87: if-lez v2, :cond_94
    .line 89: const-string v2, ", "
    .line 91: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 94: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 97: const/16 v2, 58
    .line 99: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 102: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 105: move v2, v4
    .line 106: goto :goto_60
    .line 107: invoke-static {}, Ld2/b;->g1()V
    .line 110: const/4 v0, 0
    .line 111: throw v0
    .line 112: const/16 v1, 93
    .line 114: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 117: iget-object v1, v6, La1/b;->f:Ljava/lang/Object;
    .line 119: check-cast v1, Ljava/util/Map;
    .line 121: invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z
    .line 124: move-result v1
    .line 125: xor-int/lit8 v1, v1, 1
    .line 127: if-eqz v1, :cond_141
    .line 129: const-string v1, ", tags="
    .line 131: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 134: iget-object v1, v6, La1/b;->f:Ljava/lang/Object;
    .line 136: check-cast v1, Ljava/util/Map;
    .line 138: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 141: const/16 v1, 125
    .line 143: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 146: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 149: move-result-object v0
    .line 150: const-string v1, "StringBuilder().apply(builderAction).toString()"
    .line 152: invoke-static {v0, v1}, Ld2/b;->w(Ljava/lang/Object;Ljava/lang/String;)V
    .line 155: return-object v0
    .line 156: nop
    .line 157: move v0, v0
    .line 158: move v0, v0
    .line 159: nop
    .line 160: move-object/from16 v0, v0
.end method

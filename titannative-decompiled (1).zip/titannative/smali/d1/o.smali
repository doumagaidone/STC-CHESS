.class public final Ld1/o;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Landroidx/compose/ui/node/a;

# direct methods
.method public constructor <init>(Landroidx/compose/ui/node/a;)V
    .registers 3

    .line 0: const-string v0, "rootNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Ld1/o;->a:Landroidx/compose/ui/node/a;
    .line 10: return-void
.end method

# virtual methods
.method public final a()Ld1/n;
    .registers 11

    .line 0: iget-object v0, v10, Ld1/o;->a:Landroidx/compose/ui/node/a;
    .line 2: iget-object v1, v0, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 4: iget-object v1, v1, Lz0/v0;->e:Lf0/o;
    .line 6: iget v2, v1, Lf0/o;->l:I
    .line 8: and-int/lit8 v2, v2, 8
    .line 10: const/4 v3, 0
    .line 11: const/4 v4, 0
    .line 12: if-eqz v2, :cond_107
    .line 14: if-eqz v1, :cond_107
    .line 16: iget v2, v1, Lf0/o;->k:I
    .line 18: and-int/lit8 v2, v2, 8
    .line 20: if-eqz v2, :cond_98
    .line 22: move-object v2, v1
    .line 23: move-object v5, v4
    .line 24: if-eqz v2, :cond_98
    .line 26: instance-of v6, v2, Lz0/p1;
    .line 28: if-eqz v6, :cond_32
    .line 30: move-object v4, v2
    .line 31: goto :goto_107
    .line 32: iget v6, v2, Lf0/o;->k:I
    .line 34: and-int/lit8 v6, v6, 8
    .line 36: if-eqz v6, :cond_93
    .line 38: instance-of v6, v2, Lz0/p;
    .line 40: if-eqz v6, :cond_93
    .line 42: move-object v6, v2
    .line 43: check-cast v6, Lz0/p;
    .line 45: iget-object v6, v6, Lz0/p;->w:Lf0/o;
    .line 47: move v7, v3
    .line 48: const/4 v8, 1
    .line 49: if-eqz v6, :cond_90
    .line 51: iget v9, v6, Lf0/o;->k:I
    .line 53: and-int/lit8 v9, v9, 8
    .line 55: if-eqz v9, :cond_87
    .line 57: add-int/lit8 v7, v7, 1
    .line 59: if-ne v7, v8, :cond_63
    .line 61: move-object v2, v6
    .line 62: goto :goto_87
    .line 63: if-nez v5, :cond_78
    .line 65: new-instance v5, Lv/j;
    .line 67: const/16 v8, 16
    .line 69: new-array v8, v8, [Lf0/o;
    .line 71: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 74: iput-object v8, v5, Lv/j;->i:[Ljava/lang/Object;
    .line 76: iput v3, v5, Lv/j;->k:I
    .line 78: if-eqz v2, :cond_84
    .line 80: invoke-virtual {v5, v2}, Lv/j;->b(Ljava/lang/Object;)V
    .line 83: move-object v2, v4
    .line 84: invoke-virtual {v5, v6}, Lv/j;->b(Ljava/lang/Object;)V
    .line 87: iget-object v6, v6, Lf0/o;->n:Lf0/o;
    .line 89: goto :goto_48
    .line 90: if-ne v7, v8, :cond_93
    .line 92: goto :goto_24
    .line 93: invoke-static {v5}, Lz0/h;->f(Lv/j;)Lf0/o;
    .line 96: move-result-object v2
    .line 97: goto :goto_24
    .line 98: iget v2, v1, Lf0/o;->l:I
    .line 100: and-int/lit8 v2, v2, 8
    .line 102: if-eqz v2, :cond_107
    .line 104: iget-object v1, v1, Lf0/o;->n:Lf0/o;
    .line 106: goto :goto_14
    .line 107: invoke-static {v4}, Ld2/b;->u(Ljava/lang/Object;)V
    .line 110: check-cast v4, Lz0/p1;
    .line 112: check-cast v4, Lf0/o;
    .line 114: iget-object v1, v4, Lf0/o;->i:Lf0/o;
    .line 116: new-instance v2, Ld1/i;
    .line 118: invoke-direct {v2}, Ld1/i;-><init>()V
    .line 121: new-instance v4, Ld1/n;
    .line 123: invoke-direct {v4, v1, v3, v0, v2}, Ld1/n;-><init>(Lf0/o;ZLandroidx/compose/ui/node/a;Ld1/i;)V
    .line 126: return-object v4
.end method

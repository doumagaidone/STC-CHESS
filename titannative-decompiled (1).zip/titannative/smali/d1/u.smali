.class public abstract interface Ld1/u;
.super Ljava/lang/Object;
.source "SourceFile"

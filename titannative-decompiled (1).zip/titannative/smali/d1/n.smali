.class public final Ld1/n;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Lf0/o;
.field public final b:Z
.field public final c:Landroidx/compose/ui/node/a;
.field public final d:Ld1/i;
.field public e:Z
.field public f:Ld1/n;
.field public final g:I

# direct methods
.method public constructor <init>(Lf0/o;ZLandroidx/compose/ui/node/a;Ld1/i;)V
    .registers 6

    .line 0: const-string v0, "outerSemanticsNode"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "layoutNode"
    .line 7: invoke-static {v4, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: const-string v0, "unmergedConfig"
    .line 12: invoke-static {v5, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 15: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 18: iput-object v2, v1, Ld1/n;->a:Lf0/o;
    .line 20: iput-boolean v3, v1, Ld1/n;->b:Z
    .line 22: iput-object v4, v1, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 24: iput-object v5, v1, Ld1/n;->d:Ld1/i;
    .line 26: iget v2, v4, Landroidx/compose/ui/node/a;->j:I
    .line 28: iput v2, v1, Ld1/n;->g:I
    .line 30: return-void
.end method

# virtual methods
.method public final a(Ld1/f;Ld3/c;)Ld1/n;
    .registers 8

    .line 0: new-instance v0, Ld1/i;
    .line 2: invoke-direct {v0}, Ld1/i;-><init>()V
    .line 5: const/4 v1, 0
    .line 6: iput-boolean v1, v0, Ld1/i;->j:Z
    .line 8: iput-boolean v1, v0, Ld1/i;->k:Z
    .line 10: invoke-interface {v7, v0}, Ld3/c;->a0(Ljava/lang/Object;)Ljava/lang/Object;
    .line 13: new-instance v2, Ld1/n;
    .line 15: new-instance v3, Ld1/l;
    .line 17: invoke-direct {v3, v7}, Ld1/l;-><init>(Ld3/c;)V
    .line 20: new-instance v7, Landroidx/compose/ui/node/a;
    .line 22: iget v4, v5, Ld1/n;->g:I
    .line 24: if-eqz v6, :cond_31
    .line 26: const v6, 0x3b9aca00
    .line 29: add-int/2addr v4, v6
    .line 30: goto :goto_35
    .line 31: const v6, 0x77359400
    .line 34: goto :goto_29
    .line 35: const/4 v6, 1
    .line 36: invoke-direct {v7, v4, v6}, Landroidx/compose/ui/node/a;-><init>(IZ)V
    .line 39: invoke-direct {v2, v3, v1, v7, v0}, Ld1/n;-><init>(Lf0/o;ZLandroidx/compose/ui/node/a;Ld1/i;)V
    .line 42: iput-boolean v6, v2, Ld1/n;->e:Z
    .line 44: iput-object v5, v2, Ld1/n;->f:Ld1/n;
    .line 46: return-object v2
.end method

# virtual methods
.method public final b(Landroidx/compose/ui/node/a;Ljava/util/ArrayList;)V
    .registers 8

    .line 0: invoke-virtual {v6}, Landroidx/compose/ui/node/a;->q()Lv/j;
    .line 3: move-result-object v6
    .line 4: iget v0, v6, Lv/j;->k:I
    .line 6: if-lez v0, :cond_48
    .line 8: iget-object v6, v6, Lv/j;->i:[Ljava/lang/Object;
    .line 10: const/4 v1, 0
    .line 11: aget-object v2, v6, v1
    .line 13: check-cast v2, Landroidx/compose/ui/node/a;
    .line 15: invoke-virtual {v2}, Landroidx/compose/ui/node/a;->x()Z
    .line 18: move-result v3
    .line 19: if-eqz v3, :cond_44
    .line 21: iget-object v3, v2, Landroidx/compose/ui/node/a;->D:Lz0/v0;
    .line 23: const/16 v4, 8
    .line 25: invoke-virtual {v3, v4}, Lz0/v0;->d(I)Z
    .line 28: move-result v3
    .line 29: if-eqz v3, :cond_41
    .line 31: iget-boolean v3, v5, Ld1/n;->b:Z
    .line 33: invoke-static {v2, v3}, Ll0/j;->d(Landroidx/compose/ui/node/a;Z)Ld1/n;
    .line 36: move-result-object v2
    .line 37: invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 40: goto :goto_44
    .line 41: invoke-virtual {v5, v2, v7}, Ld1/n;->b(Landroidx/compose/ui/node/a;Ljava/util/ArrayList;)V
    .line 44: add-int/lit8 v1, v1, 1
    .line 46: if-lt v1, v0, :cond_11
    .line 48: return-void
.end method

# virtual methods
.method public final c()Lz0/a1;
    .registers 3

    .line 0: iget-boolean v0, v2, Ld1/n;->e:Z
    .line 2: if-eqz v0, :cond_17
    .line 4: invoke-virtual {v2}, Ld1/n;->i()Ld1/n;
    .line 7: move-result-object v0
    .line 8: if-eqz v0, :cond_15
    .line 10: invoke-virtual {v0}, Ld1/n;->c()Lz0/a1;
    .line 13: move-result-object v0
    .line 14: goto :goto_16
    .line 15: const/4 v0, 0
    .line 16: return-object v0
    .line 17: iget-object v0, v2, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 19: invoke-static {v0}, Ll0/j;->p(Landroidx/compose/ui/node/a;)Lz0/p1;
    .line 22: move-result-object v0
    .line 23: if-eqz v0, :cond_26
    .line 25: goto :goto_28
    .line 26: iget-object v0, v2, Ld1/n;->a:Lf0/o;
    .line 28: const/16 v1, 8
    .line 30: invoke-static {v0, v1}, Lz0/h;->w(Lz0/o;I)Lz0/a1;
    .line 33: move-result-object v0
    .line 34: return-object v0
.end method

# virtual methods
.method public final d(Ljava/util/List;)V
    .registers 7

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v5, v0}, Ld1/n;->l(Z)Ljava/util/List;
    .line 4: move-result-object v1
    .line 5: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 8: move-result v2
    .line 9: if-ge v0, v2, :cond_39
    .line 11: invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 14: move-result-object v3
    .line 15: check-cast v3, Ld1/n;
    .line 17: invoke-virtual {v3}, Ld1/n;->j()Z
    .line 20: move-result v4
    .line 21: if-eqz v4, :cond_27
    .line 23: invoke-interface {v6, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 26: goto :goto_36
    .line 27: iget-object v4, v3, Ld1/n;->d:Ld1/i;
    .line 29: iget-boolean v4, v4, Ld1/i;->k:Z
    .line 31: if-nez v4, :cond_36
    .line 33: invoke-virtual {v3, v6}, Ld1/n;->d(Ljava/util/List;)V
    .line 36: add-int/lit8 v0, v0, 1
    .line 38: goto :goto_9
    .line 39: return-void
.end method

# virtual methods
.method public final e()Lj0/d;
    .registers 4

    .line 0: invoke-virtual {v3}, Ld1/n;->c()Lz0/a1;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_27
    .line 6: invoke-virtual {v0}, Lz0/a1;->H()Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_13
    .line 12: goto :goto_14
    .line 13: const/4 v0, 0
    .line 14: if-eqz v0, :cond_27
    .line 16: invoke-static {v0}, Landroidx/compose/ui/layout/a;->d(Lx0/q;)Lx0/q;
    .line 19: move-result-object v1
    .line 20: const/4 v2, 1
    .line 21: invoke-interface {v1, v0, v2}, Lx0/q;->D(Lx0/q;Z)Lj0/d;
    .line 24: move-result-object v0
    .line 25: if-nez v0, :cond_29
    .line 27: sget-object v0, Lj0/d;->e:Lj0/d;
    .line 29: return-object v0
.end method

# virtual methods
.method public final f()Lj0/d;
    .registers 3

    .line 0: invoke-virtual {v2}, Ld1/n;->c()Lz0/a1;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_21
    .line 6: invoke-virtual {v0}, Lz0/a1;->H()Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_13
    .line 12: goto :goto_14
    .line 13: const/4 v0, 0
    .line 14: if-eqz v0, :cond_21
    .line 16: invoke-static {v0}, Landroidx/compose/ui/layout/a;->c(Lx0/q;)Lj0/d;
    .line 19: move-result-object v0
    .line 20: goto :goto_23
    .line 21: sget-object v0, Lj0/d;->e:Lj0/d;
    .line 23: return-object v0
.end method

# virtual methods
.method public final g(ZZ)Ljava/util/List;
    .registers 3

    .line 0: if-nez v1, :cond_11
    .line 2: iget-object v1, v0, Ld1/n;->d:Ld1/i;
    .line 4: iget-boolean v1, v1, Ld1/i;->k:Z
    .line 6: if-eqz v1, :cond_11
    .line 8: sget-object v1, Lt2/r;->i:Lt2/r;
    .line 10: return-object v1
    .line 11: invoke-virtual {v0}, Ld1/n;->j()Z
    .line 14: move-result v1
    .line 15: if-eqz v1, :cond_26
    .line 17: new-instance v1, Ljava/util/ArrayList;
    .line 19: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 22: invoke-virtual {v0, v1}, Ld1/n;->d(Ljava/util/List;)V
    .line 25: return-object v1
    .line 26: invoke-virtual {v0, v2}, Ld1/n;->l(Z)Ljava/util/List;
    .line 29: move-result-object v1
    .line 30: return-object v1
.end method

# virtual methods
.method public final h()Ld1/i;
    .registers 4

    .line 0: invoke-virtual {v3}, Ld1/n;->j()Z
    .line 3: move-result v0
    .line 4: iget-object v1, v3, Ld1/n;->d:Ld1/i;
    .line 6: if-eqz v0, :cond_35
    .line 8: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 11: new-instance v0, Ld1/i;
    .line 13: invoke-direct {v0}, Ld1/i;-><init>()V
    .line 16: iget-boolean v2, v1, Ld1/i;->j:Z
    .line 18: iput-boolean v2, v0, Ld1/i;->j:Z
    .line 20: iget-boolean v2, v1, Ld1/i;->k:Z
    .line 22: iput-boolean v2, v0, Ld1/i;->k:Z
    .line 24: iget-object v2, v0, Ld1/i;->i:Ljava/util/LinkedHashMap;
    .line 26: iget-object v1, v1, Ld1/i;->i:Ljava/util/LinkedHashMap;
    .line 28: invoke-interface {v2, v1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V
    .line 31: invoke-virtual {v3, v0}, Ld1/n;->k(Ld1/i;)V
    .line 34: return-object v0
    .line 35: return-object v1
.end method

# virtual methods
.method public final i()Ld1/n;
    .registers 5

    .line 0: iget-object v0, v4, Ld1/n;->f:Ld1/n;
    .line 2: if-eqz v0, :cond_5
    .line 4: return-object v0
    .line 5: iget-object v0, v4, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 7: iget-boolean v1, v4, Ld1/n;->b:Z
    .line 9: const/4 v2, 0
    .line 10: if-eqz v1, :cond_19
    .line 12: sget-object v3, Ld1/m;->l:Ld1/m;
    .line 14: invoke-static {v0, v3}, Ll0/j;->k(Landroidx/compose/ui/node/a;Ld1/m;)Landroidx/compose/ui/node/a;
    .line 17: move-result-object v3
    .line 18: goto :goto_20
    .line 19: move-object v3, v2
    .line 20: if-nez v3, :cond_28
    .line 22: sget-object v3, Ld1/m;->m:Ld1/m;
    .line 24: invoke-static {v0, v3}, Ll0/j;->k(Landroidx/compose/ui/node/a;Ld1/m;)Landroidx/compose/ui/node/a;
    .line 27: move-result-object v3
    .line 28: if-nez v3, :cond_31
    .line 30: return-object v2
    .line 31: invoke-static {v3, v1}, Ll0/j;->d(Landroidx/compose/ui/node/a;Z)Ld1/n;
    .line 34: move-result-object v0
    .line 35: return-object v0
.end method

# virtual methods
.method public final j()Z
    .registers 2

    .line 0: iget-boolean v0, v1, Ld1/n;->b:Z
    .line 2: if-eqz v0, :cond_12
    .line 4: iget-object v0, v1, Ld1/n;->d:Ld1/i;
    .line 6: iget-boolean v0, v0, Ld1/i;->j:Z
    .line 8: if-eqz v0, :cond_12
    .line 10: const/4 v0, 1
    .line 11: goto :goto_13
    .line 12: const/4 v0, 0
    .line 13: return v0
.end method

# virtual methods
.method public final k(Ld1/i;)V
    .registers 12

    .line 0: iget-object v0, v10, Ld1/n;->d:Ld1/i;
    .line 2: iget-boolean v0, v0, Ld1/i;->k:Z
    .line 4: if-nez v0, :cond_97
    .line 6: const/4 v0, 0
    .line 7: invoke-virtual {v10, v0}, Ld1/n;->l(Z)Ljava/util/List;
    .line 10: move-result-object v1
    .line 11: invoke-interface {v1}, Ljava/util/List;->size()I
    .line 14: move-result v2
    .line 15: if-ge v0, v2, :cond_97
    .line 17: invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 20: move-result-object v3
    .line 21: check-cast v3, Ld1/n;
    .line 23: invoke-virtual {v3}, Ld1/n;->j()Z
    .line 26: move-result v4
    .line 27: if-nez v4, :cond_94
    .line 29: iget-object v4, v3, Ld1/n;->d:Ld1/i;
    .line 31: const-string v5, "child"
    .line 33: invoke-static {v4, v5}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 36: iget-object v4, v4, Ld1/i;->i:Ljava/util/LinkedHashMap;
    .line 38: invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;
    .line 41: move-result-object v4
    .line 42: invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 45: move-result-object v4
    .line 46: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 49: move-result v5
    .line 50: if-eqz v5, :cond_91
    .line 52: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 55: move-result-object v5
    .line 56: check-cast v5, Ljava/util/Map$Entry;
    .line 58: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 61: move-result-object v6
    .line 62: check-cast v6, Ld1/t;
    .line 64: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 67: move-result-object v5
    .line 68: iget-object v7, v11, Ld1/i;->i:Ljava/util/LinkedHashMap;
    .line 70: invoke-virtual {v7, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 73: move-result-object v8
    .line 74: const-string v9, "null cannot be cast to non-null type androidx.compose.ui.semantics.SemanticsPropertyKey<kotlin.Any?>"
    .line 76: invoke-static {v6, v9}, Ld2/b;->v(Ljava/lang/Object;Ljava/lang/String;)V
    .line 79: iget-object v9, v6, Ld1/t;->b:Ld3/e;
    .line 81: invoke-interface {v9, v8, v5}, Ld3/e;->N(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 84: move-result-object v5
    .line 85: if-eqz v5, :cond_46
    .line 87: invoke-interface {v7, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 90: goto :goto_46
    .line 91: invoke-virtual {v3, v11}, Ld1/n;->k(Ld1/i;)V
    .line 94: add-int/lit8 v0, v0, 1
    .line 96: goto :goto_15
    .line 97: return-void
.end method

# virtual methods
.method public final l(Z)Ljava/util/List;
    .registers 7

    .line 0: iget-boolean v0, v5, Ld1/n;->e:Z
    .line 2: if-eqz v0, :cond_7
    .line 4: sget-object v6, Lt2/r;->i:Lt2/r;
    .line 6: return-object v6
    .line 7: new-instance v0, Ljava/util/ArrayList;
    .line 9: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 12: iget-object v1, v5, Ld1/n;->c:Landroidx/compose/ui/node/a;
    .line 14: invoke-virtual {v5, v1, v0}, Ld1/n;->b(Landroidx/compose/ui/node/a;Ljava/util/ArrayList;)V
    .line 17: if-eqz v6, :cond_108
    .line 19: sget-object v6, Ld1/q;->r:Ld1/t;
    .line 21: iget-object v1, v5, Ld1/n;->d:Ld1/i;
    .line 23: invoke-static {v1, v6}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 26: move-result-object v6
    .line 27: check-cast v6, Ld1/f;
    .line 29: const/4 v2, 1
    .line 30: if-eqz v6, :cond_57
    .line 32: iget-boolean v3, v1, Ld1/i;->j:Z
    .line 34: if-eqz v3, :cond_57
    .line 36: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    .line 39: move-result v3
    .line 40: xor-int/2addr v3, v2
    .line 41: if-eqz v3, :cond_57
    .line 43: new-instance v3, Lg/n;
    .line 45: const/16 v4, 29
    .line 47: invoke-direct {v3, v4, v6}, Lg/n;-><init>(ILjava/lang/Object;)V
    .line 50: invoke-virtual {v5, v6, v3}, Ld1/n;->a(Ld1/f;Ld3/c;)Ld1/n;
    .line 53: move-result-object v6
    .line 54: invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 57: sget-object v6, Ld1/q;->a:Ld1/t;
    .line 59: invoke-virtual {v1, v6}, Ld1/i;->b(Ld1/t;)Z
    .line 62: move-result v3
    .line 63: if-eqz v3, :cond_108
    .line 65: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    .line 68: move-result v3
    .line 69: xor-int/2addr v3, v2
    .line 70: if-eqz v3, :cond_108
    .line 72: iget-boolean v3, v1, Ld1/i;->j:Z
    .line 74: if-eqz v3, :cond_108
    .line 76: invoke-static {v1, v6}, Ld2/c;->W(Ld1/i;Ld1/t;)Ljava/lang/Object;
    .line 79: move-result-object v6
    .line 80: check-cast v6, Ljava/util/List;
    .line 82: const/4 v1, 0
    .line 83: if-eqz v6, :cond_92
    .line 85: invoke-static {v6}, Lt2/p;->L1(Ljava/util/List;)Ljava/lang/Object;
    .line 88: move-result-object v6
    .line 89: check-cast v6, Ljava/lang/String;
    .line 91: goto :goto_93
    .line 92: move-object v6, v1
    .line 93: if-eqz v6, :cond_108
    .line 95: new-instance v3, Li/f1;
    .line 97: invoke-direct {v3, v2, v6}, Li/f1;-><init>(ILjava/lang/String;)V
    .line 100: invoke-virtual {v5, v1, v3}, Ld1/n;->a(Ld1/f;Ld3/c;)Ld1/n;
    .line 103: move-result-object v6
    .line 104: const/4 v1, 0
    .line 105: invoke-virtual {v0, v1, v6}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V
    .line 108: return-object v0
.end method

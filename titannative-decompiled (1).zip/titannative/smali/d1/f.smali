.class public final Ld1/f;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:I

# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput v1, v0, Ld1/f;->a:I
    .line 5: return-void
.end method

# direct methods
.method public static final a(II)Z
    .registers 2

    .line 0: if-ne v0, v1, :cond_4
    .line 2: const/4 v0, 1
    .line 3: goto :goto_5
    .line 4: const/4 v0, 0
    .line 5: return v0
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 0: instance-of v0, v3, Ld1/f;
    .line 2: const/4 v1, 0
    .line 3: if-nez v0, :cond_6
    .line 5: goto :goto_16
    .line 6: check-cast v3, Ld1/f;
    .line 8: iget v3, v3, Ld1/f;->a:I
    .line 10: iget v0, v2, Ld1/f;->a:I
    .line 12: if-eq v0, v3, :cond_15
    .line 14: goto :goto_16
    .line 15: const/4 v1, 1
    .line 16: return v1
.end method

# virtual methods
.method public final hashCode()I
    .registers 2

    .line 0: iget v0, v1, Ld1/f;->a:I
    .line 2: invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: const/4 v0, 0
    .line 1: iget v1, v2, Ld1/f;->a:I
    .line 3: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 6: move-result v0
    .line 7: if-eqz v0, :cond_12
    .line 9: const-string v0, "Button"
    .line 11: goto :goto_74
    .line 12: const/4 v0, 1
    .line 13: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 16: move-result v0
    .line 17: if-eqz v0, :cond_22
    .line 19: const-string v0, "Checkbox"
    .line 21: goto :goto_74
    .line 22: const/4 v0, 2
    .line 23: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 26: move-result v0
    .line 27: if-eqz v0, :cond_32
    .line 29: const-string v0, "Switch"
    .line 31: goto :goto_74
    .line 32: const/4 v0, 3
    .line 33: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 36: move-result v0
    .line 37: if-eqz v0, :cond_42
    .line 39: const-string v0, "RadioButton"
    .line 41: goto :goto_74
    .line 42: const/4 v0, 4
    .line 43: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 46: move-result v0
    .line 47: if-eqz v0, :cond_52
    .line 49: const-string v0, "Tab"
    .line 51: goto :goto_74
    .line 52: const/4 v0, 5
    .line 53: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 56: move-result v0
    .line 57: if-eqz v0, :cond_62
    .line 59: const-string v0, "Image"
    .line 61: goto :goto_74
    .line 62: const/4 v0, 6
    .line 63: invoke-static {v1, v0}, Ld1/f;->a(II)Z
    .line 66: move-result v0
    .line 67: if-eqz v0, :cond_72
    .line 69: const-string v0, "DropdownList"
    .line 71: goto :goto_74
    .line 72: const-string v0, "Unknown"
    .line 74: return-object v0
.end method

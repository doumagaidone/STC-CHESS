.class public final Ld1/t;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ljava/lang/String;
.field public final b:Ld3/e;

# direct methods
.method public constructor <init>(Ljava/lang/String;Ld3/e;)V
    .registers 4

    .line 0: const-string v0, "mergePolicy"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput-object v2, v1, Ld1/t;->a:Ljava/lang/String;
    .line 10: iput-object v3, v1, Ld1/t;->b:Ld3/e;
    .line 12: return-void
.end method

# virtual methods
.method public final a(Ld1/u;Lk3/e;Ljava/lang/Object;)V
    .registers 5

    .line 0: const-string v0, "thisRef"
    .line 2: invoke-static {v2, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "property"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: check-cast v2, Ld1/i;
    .line 12: invoke-virtual {v2, v1, v4}, Ld1/i;->e(Ld1/t;Ljava/lang/Object;)V
    .line 15: return-void
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "SemanticsPropertyKey: "
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Ld1/t;->a:Ljava/lang/String;
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 12: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 15: move-result-object v0
    .line 16: return-object v0
.end method

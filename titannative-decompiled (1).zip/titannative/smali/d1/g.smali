.class public final Ld1/g;
.super Ljava/lang/Object;
.source "SourceFile"

.field public final a:Ld3/a;
.field public final b:Ld3/a;
.field public final c:Z

# direct methods
.method public constructor <init>(Li/o2;Li/o2;Z)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Ld1/g;->a:Ld3/a;
    .line 5: iput-object v2, v0, Ld1/g;->b:Ld3/a;
    .line 7: iput-boolean v3, v0, Ld1/g;->c:Z
    .line 9: return-void
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ScrollAxisRange(value="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget-object v1, v2, Ld1/g;->a:Ld3/a;
    .line 9: invoke-interface {v1}, Ld3/a;->s()Ljava/lang/Object;
    .line 12: move-result-object v1
    .line 13: check-cast v1, Ljava/lang/Number;
    .line 15: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 18: move-result v1
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", maxValue="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget-object v1, v2, Ld1/g;->b:Ld3/a;
    .line 29: invoke-interface {v1}, Ld3/a;->s()Ljava/lang/Object;
    .line 32: move-result-object v1
    .line 33: check-cast v1, Ljava/lang/Number;
    .line 35: invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F
    .line 38: move-result v1
    .line 39: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 42: const-string v1, ", reverseScrolling="
    .line 44: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: iget-boolean v1, v2, Ld1/g;->c:Z
    .line 49: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    .line 52: const/16 v1, 41
    .line 54: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 60: move-result-object v0
    .line 61: return-object v0
.end method

.class public final Ld1/e;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final d:Ld1/e;

.field public final a:F
.field public final b:Lj3/a;
.field public final c:I

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: new-instance v0, Ld1/e;
    .line 2: new-instance v1, Lj3/a;
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v1, v2, v2}, Lj3/a;-><init>(FF)V
    .line 8: const/4 v3, 0
    .line 9: invoke-direct {v0, v2, v1, v3}, Ld1/e;-><init>(FLj3/a;I)V
    .line 12: sput-object v0, Ld1/e;->d:Ld1/e;
    .line 14: return-void
.end method

# direct methods
.method public constructor <init>(FLj3/a;I)V
    .registers 5

    .line 0: const-string v0, "range"
    .line 2: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 8: iput v2, v1, Ld1/e;->a:F
    .line 10: iput-object v3, v1, Ld1/e;->b:Lj3/a;
    .line 12: iput v4, v1, Ld1/e;->c:I
    .line 14: invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z
    .line 17: move-result v2
    .line 18: xor-int/lit8 v2, v2, 1
    .line 20: if-eqz v2, :cond_23
    .line 22: return-void
    .line 23: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 25: const-string v3, "current must not be NaN"
    .line 27: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 30: move-result-object v3
    .line 31: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 34: throw v2
.end method

# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 0: const/4 v0, 1
    .line 1: if-ne v4, v5, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v5, Ld1/e;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: check-cast v5, Ld1/e;
    .line 12: iget v1, v5, Ld1/e;->a:F
    .line 14: iget v3, v4, Ld1/e;->a:F
    .line 16: cmpg-float v1, v3, v1
    .line 18: if-nez v1, :cond_39
    .line 20: iget-object v1, v4, Ld1/e;->b:Lj3/a;
    .line 22: iget-object v3, v5, Ld1/e;->b:Lj3/a;
    .line 24: invoke-static {v1, v3}, Ld2/b;->n(Ljava/lang/Object;Ljava/lang/Object;)Z
    .line 27: move-result v1
    .line 28: if-nez v1, :cond_31
    .line 30: return v2
    .line 31: iget v1, v4, Ld1/e;->c:I
    .line 33: iget v5, v5, Ld1/e;->c:I
    .line 35: if-eq v1, v5, :cond_38
    .line 37: return v2
    .line 38: return v0
    .line 39: return v2
.end method

# virtual methods
.method public final hashCode()I
    .registers 3

    .line 0: iget v0, v2, Ld1/e;->a:F
    .line 2: invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I
    .line 5: move-result v0
    .line 6: mul-int/lit8 v0, v0, 31
    .line 8: iget-object v1, v2, Ld1/e;->b:Lj3/a;
    .line 10: invoke-virtual {v1}, Lj3/a;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v1, v0
    .line 15: mul-int/lit8 v1, v1, 31
    .line 17: iget v0, v2, Ld1/e;->c:I
    .line 19: add-int/2addr v1, v0
    .line 20: return v1
.end method

# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: const-string v1, "ProgressBarRangeInfo(current="
    .line 4: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    .line 7: iget v1, v3, Ld1/e;->a:F
    .line 9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;
    .line 12: const-string v1, ", range="
    .line 14: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 17: iget-object v1, v3, Ld1/e;->b:Lj3/a;
    .line 19: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 22: const-string v1, ", steps="
    .line 24: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: iget v1, v3, Ld1/e;->c:I
    .line 29: const/16 v2, 41
    .line 31: invoke-static {v0, v1, v2}, Lai/onnxruntime/b;->j(Ljava/lang/StringBuilder;IC)Ljava/lang/String;
    .line 34: move-result-object v0
    .line 35: return-object v0
.end method

.class public abstract Ld1/r;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ld1/t;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: new-instance v0, Ld1/t;
    .line 2: sget-object v1, Ld1/p;->s:Ld1/p;
    .line 4: const-string v2, "TestTagsAsResourceId"
    .line 6: invoke-direct {v0, v2, v1}, Ld1/t;-><init>(Ljava/lang/String;Ld3/e;)V
    .line 9: sput-object v0, Ld1/r;->a:Ld1/t;
    .line 11: return-void
.end method

.class public abstract Ld1/k;
.super Ljava/lang/Object;
.source "SourceFile"

.field public static final a:Ljava/util/concurrent/atomic/AtomicInteger;

# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 0: new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    .line 6: sput-object v0, Ld1/k;->a:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 8: return-void
.end method

# direct methods
.method public static final a(Lf0/p;ZLd3/c;)Lf0/p;
    .registers 4

    .line 0: const-string v0, "<this>"
    .line 2: invoke-static {v1, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 5: const-string v0, "properties"
    .line 7: invoke-static {v3, v0}, Ld2/b;->x(Ljava/lang/Object;Ljava/lang/String;)V
    .line 10: new-instance v0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;
    .line 12: invoke-direct {v0, v3, v2}, Landroidx/compose/ui/semantics/AppendedSemanticsElement;-><init>(Ld3/c;Z)V
    .line 15: invoke-interface {v1, v0}, Lf0/p;->j(Lf0/p;)Lf0/p;
    .line 18: move-result-object v1
    .line 19: return-object v1
.end method
